python -m SimpleHTTPServer
