package com.hehe.integration.user1;

import java.util.List;

import com.hehe.integration.user.User;

public interface UserService {

     List<User> list();
}
