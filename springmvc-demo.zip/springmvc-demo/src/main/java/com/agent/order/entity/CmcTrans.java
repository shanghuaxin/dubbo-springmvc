package com.agent.order.entity;

import java.math.BigDecimal;
import java.util.Date;

public class CmcTrans {
    private Long id;

    private Integer bbknbr;

    private String accnbr;

    private String refnbr;

    private Integer reqnbr;

    private String frmcod;

    private BigDecimal trsamt;

    private BigDecimal trsblv;

    private String etydat;

    private String etytim;

    private String rpynam;

    private String rpyacc;

    private String rpybbn;

    private String rpybnk;

    private String rpyadr;

    private String status;

    private Integer cnt;

    private String emsg;

    private Date ctime;

    private Date utime;
    
    private String content;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getBbknbr() {
        return bbknbr;
    }

    public void setBbknbr(Integer bbknbr) {
        this.bbknbr = bbknbr;
    }

    public String getAccnbr() {
        return accnbr;
    }

    public void setAccnbr(String accnbr) {
        this.accnbr = accnbr == null ? null : accnbr.trim();
    }

    public String getRefnbr() {
        return refnbr;
    }

    public void setRefnbr(String refnbr) {
        this.refnbr = refnbr == null ? null : refnbr.trim();
    }

    public Integer getReqnbr() {
        return reqnbr;
    }

    public void setReqnbr(Integer reqnbr) {
        this.reqnbr = reqnbr;
    }

    public String getFrmcod() {
        return frmcod;
    }

    public void setFrmcod(String frmcod) {
        this.frmcod = frmcod == null ? null : frmcod.trim();
    }

    public BigDecimal getTrsamt() {
        return trsamt;
    }

    public void setTrsamt(BigDecimal trsamt) {
        this.trsamt = trsamt;
    }

    public BigDecimal getTrsblv() {
        return trsblv;
    }

    public void setTrsblv(BigDecimal trsblv) {
        this.trsblv = trsblv;
    }

    public String getEtydat() {
        return etydat;
    }

    public void setEtydat(String etydat) {
        this.etydat = etydat == null ? null : etydat.trim();
    }

    public String getEtytim() {
        return etytim;
    }

    public void setEtytim(String etytim) {
        this.etytim = etytim == null ? null : etytim.trim();
    }

    public String getRpynam() {
        return rpynam;
    }

    public void setRpynam(String rpynam) {
        this.rpynam = rpynam == null ? null : rpynam.trim();
    }

    public String getRpyacc() {
        return rpyacc;
    }

    public void setRpyacc(String rpyacc) {
        this.rpyacc = rpyacc == null ? null : rpyacc.trim();
    }

    public String getRpybbn() {
        return rpybbn;
    }

    public void setRpybbn(String rpybbn) {
        this.rpybbn = rpybbn == null ? null : rpybbn.trim();
    }

    public String getRpybnk() {
        return rpybnk;
    }

    public void setRpybnk(String rpybnk) {
        this.rpybnk = rpybnk == null ? null : rpybnk.trim();
    }

    public String getRpyadr() {
        return rpyadr;
    }

    public void setRpyadr(String rpyadr) {
        this.rpyadr = rpyadr == null ? null : rpyadr.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }

    public String getEmsg() {
        return emsg;
    }

    public void setEmsg(String emsg) {
        this.emsg = emsg == null ? null : emsg.trim();
    }

    public Date getCtime() {
        return ctime;
    }

    public void setCtime(Date ctime) {
        this.ctime = ctime;
    }

    public Date getUtime() {
        return utime;
    }

    public void setUtime(Date utime) {
        this.utime = utime;
    }
    
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }    
}