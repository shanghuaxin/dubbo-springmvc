package com.agent.order.common.constant;
/**
 * 
 * 系统常量
 * 
 * @author kangy
 *
 */
public interface SysConstant {
	
	public static final String UTF8 = "utf-8";
	public static final String APPLICATION_JOSN = "application/json";
	public static final String APPLICATION_JSON_UTF8 = APPLICATION_JOSN + ";charset=" + UTF8;
	
	public static final String EMPTY_STRING      = "";
	public static final String COMMA             = ",";
	public static final String DOT               = ".";
	public static final String BLANK_STRING      = " ";
	public static final String COLON             = "\"";
	public static final String HYPHEN            = "-";
	public static final String SLASH             = "/";
	public static final String AND               = "&";
	public static final String EQUAL_MARK        = "=";
	public static final String TRUE              = "true";
	public static final String FALSE             = "false";
	public static final String UNDERLINED        = "_";
	
	public static final String API_CODE_SUCESS  = "200";
	public static final String API_CODE_ERROR   = "500";
}
