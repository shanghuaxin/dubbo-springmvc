package com.agent.order.mapper;

import java.util.List;

import com.agent.order.entity.PayGoods;

public interface PayGoodsMapper{
	
	PayGoods select(Integer goodsId);
	
	int insert(PayGoods payGoods);
	
	List<PayGoods> selectBuyGoods(String goodsType);
}