package com.agent.order.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.agent.order.entity.Order;
import com.agent.order.mapper.OrderMapper;

@Service
public class OrderService {
    
    @Resource
    OrderMapper orderMapper;
    
    /**
     * 根据订单号查询订单信息
     * @param Order 订单记录
     * @return
     */
    public Order select(String orderNo){
        return orderMapper.select(orderNo);
    }
    
    /**
     * 插入订单主表
     */
    public int insert(Order order){
        return orderMapper.insert(order);
    }
    
    /**
     * 删除订单主表
     */
    public int delete(Integer id){
        return orderMapper.delete(id);
    }
}
