package com.agent.order.job;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.agent.order.web.biz.TransactionBiz;

@Component
public class FailOrderJob {


    private static final Logger  log = LoggerFactory.getLogger(FailOrderJob.class);

	
	@Resource
	TransactionBiz transactionBiz;
	
    public void execute() {
    	long start = System.currentTimeMillis();
    	log.info("处理失败订单任务开始执行=============================================");
    	
    	transactionBiz.handleFailOrders();
		
    	long end = System.currentTimeMillis();
    	log.info("处理失败订单任务结束,执行时间:{}ms=============================================",(end-start));
    }


}
