/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.agent.order.common.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * Title:读取系统xml配置文件的实用类。
 * </p>
 * @author 黄鲲
 * @version 1.0
 */
public class SysConfigApp
{

    private static final Log log = LogFactory.getLog(SysConfigApp.class);

    // 行分隔符
    static final public String LINE_SEPARATOR = System
            .getProperty("line.separator");
    //  在类路径下取配置文件
    static final private String configXML = "SysConfig.xml";
    // 配置根节点
    static private org.dom4j.Document root = null;
    static
    {
        try
        {
            root = XMLUtilApp.parseXml(configXML);
        } catch (Exception e)
        {
            System.err.println("========= 在类路径上读取配置文件sysconfig.xml异常！");
            log.error("读取配置文件sysconfig.xml异常", e);
        }
    }

    /**
     * 私有构造方法，不可实例化
     */
    private SysConfigApp()
    {
    }

    /**
     * 取配置值
     * @param xql
     * @return
     */
    public static String getValue(String xql)
    {
        return XMLUtilApp.getString(root, "/sysconfig/" + xql);
    }
    
    public static String getValue(String xql, String def)
    {
    	return XMLUtilApp.getString(root, "/sysconfig/" + xql, def);
    }

    /**
     * 取配置值
     * @param xql
     * @return
     */
    public static int getIntValue(String xql, int defValue)
    {
        return XMLUtilApp.getInt(root, "/sysconfig/" + xql, defValue);
    }



    public static void main(String[] args) {
        String bb = SysConfigApp.getValue("email/smtp");
        System.out.println(bb);
    }


}
