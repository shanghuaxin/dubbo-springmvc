package com.agent.order.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;

public class OrderDetail extends BaseDomain {
    
    private static final long serialVersionUID = 4617157231493711029L;
    // 订单ID
    private Integer orderId;
    // 订单编号
    private String orderNo;
    // 渠道编号
    private Integer channelId;
    // 账户类型
    private Integer accountType;
    // 状态0:待处理 1:处理完成 2:处理失败 3:取消
    private Integer status;
    // 手机号码
    private String msisdn;
    // 订单金额
    private BigDecimal money;
    // 账号扣款金额
    private BigDecimal accountBalance;
    // 冻结账户扣款金额
    private BigDecimal freezeBalance;
    // 业务ID
    private Integer businessId;
    // 业务类型
    private String businessType;
    // 计算类型 +或-
    private String calcType;
    // t_channel_account_transaction表的json格式数据
    private String acctTransactionObj;
    // 备注
    private String remark;
    
    public Integer getOrderId() {
        return orderId;
    }
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public Integer getChannelId() {
        return channelId;
    }
    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }
    public Integer getAccountType() {
        return accountType;
    }
    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }
    public String getMsisdn() {
        return msisdn;
    }
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public BigDecimal getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }
    public BigDecimal getFreezeBalance() {
        return freezeBalance;
    }
    public void setFreezeBalance(BigDecimal freezeBalance) {
        this.freezeBalance = freezeBalance;
    }
    public Integer getBusinessId() {
        return businessId;
    }
    public void setBusinessId(Integer businessId) {
        this.businessId = businessId;
    }
    public String getBusinessType() {
        return businessType;
    }
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }
    public String getCalcType() {
        return calcType;
    }
    public void setCalcType(String calcType) {
        this.calcType = calcType;
    }
    public String getAcctTransactionObj() {
        return acctTransactionObj;
    }
    public void setAcctTransactionObj(String acctTransactionObj) {
        this.acctTransactionObj = acctTransactionObj;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
}

