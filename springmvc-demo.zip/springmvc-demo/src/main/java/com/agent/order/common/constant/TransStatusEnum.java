package com.agent.order.common.constant;

public enum TransStatusEnum {
	/** 请求 */
	REQUEST("0", "请求"), 
	/** 交易成功 */
	SUCCESS("1", "交易成功"), 
	/** 交易失败 */
	FAILURE("2", "交易失败");
	private String id;
	private String name;
	private TransStatusEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

}
