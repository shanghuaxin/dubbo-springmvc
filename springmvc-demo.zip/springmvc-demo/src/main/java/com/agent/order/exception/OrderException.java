package com.agent.order.exception;

/**
 * 自定义异常类，供其它自定义异常类继承
 * @author kangy
 *	20150918
 */
public class OrderException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5459423115527815368L;
	
	protected Integer code;

	public OrderException(String msg) {
		super(msg);
	}
	
	public OrderException(Integer code,String msg) {
		super(msg);
		this.code = code;
	}	

	public OrderException(String msg, Throwable t) {
		super(msg, t);
	}
	
	public OrderException(Integer code,String msg, Throwable t) {
		super(msg, t);
		this.code = code;
	}

	public Integer getCode() {
		return code;
	}
	

}
