package com.agent.order.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.agent.order.common.util.third.weixin.WXUtil;


@Service
public class WxPayService{
    /**
     * 生成预支付订单信息
     * @param PayOrder payOrder
     * @return
     */
    public Map<String, Object> genprepay(Map<String, Object> map,String url){
		String rs=WXUtil.sendPost(map,url);
		map.put("rsp", rs);
		return map;
    }
}
