package com.agent.order.web.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.agent.order.common.util.JSONUtil;
import com.agent.order.entity.OrderFail;
import com.agent.order.service.OrderInfoService;
import com.agent.order.service.TransactionService;
import com.agent.order.web.biz.TransactionBiz;
import com.agent.order.web.dto.PayNotifyDto;

@Component("transactionBiz")
public class TransactionBizImpl implements TransactionBiz {
	
	private static final Logger log = LoggerFactory.getLogger(TransactionBizImpl.class);
	
	@Resource
	OrderInfoService orderInfoService;
	@Resource
	TransactionService transactionService;
	
	/**
	 * （支付宝、微信等）异步返回成功后处理
	 * @param payNotifyDto
	 */
	@Override
	public void successProcess(PayNotifyDto payNotifyDto) {

		transactionService.saveOrderPayResult(payNotifyDto);

	}

	/**
	 * 
	 * @param payNotifyDto
	 * @param errMsg 错误信息
	 * @param orderFailType 错误类型  01： 第三方通知失败 02 ： 通知成功业务处理失败（加钱、发货等）;
	 * @return
	 */
	@Override
	public OrderFail getOrderFail(PayNotifyDto dto,String errMsg,String orderFailType) {
		OrderFail orderFail = new OrderFail();
		orderFail.setOrderNo(dto.getTransId());
		orderFail.setOutTransId(dto.getOutTransId());
		orderFail.setPayType(dto.getPayType());
		orderFail.setChargeMoney(dto.getChargeMoney());
		orderFail.setOrderMoney(dto.getOrderMoney());
		orderFail.setErrorMsg(errMsg);
		orderFail.setType(orderFailType);
		return orderFail;
	}

	
	/**
	 * 处理所有失败订单
	 */
	@Override
	public void handleFailOrders() {
		//获取待处理的失败订单列表（每次取5条，优先取最后更新时间早的记录）
    	List<OrderFail> list = transactionService.getOrderFails4Job();
		log.info("待处理失败订单数：{}", list.size());
		for(OrderFail orderFail:list){
			try {
				transactionService.handleFailOrder(orderFail);
				log.info("处理成功失败订单数据：{}",JSONUtil.objectToJson(orderFail));
			} catch (Exception e) {
				log.error("处理失败订单出错,订单信息："+JSONUtil.objectToJson(orderFail),e);
				try {
					//处理次数+1
					String msg = e.getMessage();
					if(msg.length() > 1000){
						msg = msg.substring(0, 1000);
					}
					orderFail.setErrorMsg(msg);
					orderFail.setHandleStatus(null);//不更新处理状态
					transactionService.updateHandleFailOrder(orderFail);
				} catch (Exception ex) {
					log.error("更新处理次数+1出错,订单信息："+JSONUtil.objectToJson(orderFail), ex);
				}
			}
		}
		
	}
}
