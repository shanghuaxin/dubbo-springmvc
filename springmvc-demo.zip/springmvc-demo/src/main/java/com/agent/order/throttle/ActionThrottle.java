package com.agent.order.throttle;

/**
 * 流量控制器 通过队列来串行化请求,实现流量控制：如果队列里已经存在一个请求的关键参数，则不接受后续的具有相同关键字的请求
 * 
 */
public interface ActionThrottle {

    /**
     * 将关键字存入队列
     * 
     * @param keywords
     * @return true=存入成功；false=关键字已存在，无法存入
     */
    boolean add(String keywords);

    /**
     * 移除关键字
     * 
     * @param keywords
     */
    void remove(String keywords);
}
