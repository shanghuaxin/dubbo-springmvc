package com.agent.order.common.constant;

/**
 * 充值结果枚举，用于消息转发状态
 * @author kangy
 *
 */
public enum PayResultEnum {
	/**
	 * 支付成功
	 */
	success,
	/**
	 * 支付失败
	 */
	fail,
	
	/**
	 * 扣减失败
	 */
	deduct_fail
}
