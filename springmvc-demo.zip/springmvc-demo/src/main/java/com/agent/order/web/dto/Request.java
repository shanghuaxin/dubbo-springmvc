package com.agent.order.web.dto;


/**
 * 请求
 */
public class Request {

    /**
     * 请求的封装
     */
    private ThirdOrder thirdOrder;
    /**
     * 请求的内容，POST的时候需要
     */
    private String    content;



    public ThirdOrder getThirdOrder() {
		return thirdOrder;
	}

	public void setThirdOrder(ThirdOrder thirdOrder) {
		this.thirdOrder = thirdOrder;
	}

	public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
