package com.agent.order.common.constant;

public enum ChannelEnum {
	WEB,WAP,APP
}
