package com.agent.order.common.constant;

public enum NotifyStatusEnum {

	/** 未通知 */
	NOT_NOTIFY(1, "未通知"), 
	/** 已通知 */
	NOTIFIED (2, "已通知");
	private Integer id;
	private String name;
	private NotifyStatusEnum(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

}
