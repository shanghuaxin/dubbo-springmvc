package com.agent.order.service;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.order.common.constant.OrderTypeEnum;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.SequenceUtil;
import com.agent.order.entity.CmcTrans;
import com.agent.order.entity.CmcTransLog;
import com.agent.order.entity.OrderInfo;
import com.agent.order.entity.PayTracode;
import com.agent.order.mapper.CmcTransLogMapper;
import com.agent.order.mapper.CmcTransMapper;
import com.agent.order.mapper.PayTracodeMapper;

@Service
public class CMCBankService {
    
	private static final Logger  log = LoggerFactory.getLogger(CMCBankService.class);
	
	@Resource
	CmcTransMapper cmcTransMapper;
	@Resource
	CmcTransLogMapper cmcTransLogMapper;
	@Resource
	PayTracodeMapper payTracodeMapper;
	@Resource
	OrderInfoService orderInfoService;
	
	
	/**
	 * 查询CMC交易记录-流水号
	 * 
	 * @param List<String> refnbrs
	 * 
	 * @return
	 */
	public List<String> selectRefnbrs(List<String> refnbrs){
		return cmcTransMapper.selectRefnbrs(refnbrs);
	}
	
	
	/**
	 * 保存CMC交易记录
	 * 
	 * @param CmcTrans cmcTrans 
	 * 
	 * @return
	 */
    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public CmcTrans saveCmcTransInfo(CmcTrans cmcTrans){
		cmcTransMapper.insert(cmcTrans);
		
		CmcTransLog cmcTransLog = new CmcTransLog();
		cmcTransLog.setTid(cmcTrans.getId());
		cmcTransLog.setRefnbr(cmcTrans.getRefnbr());
		cmcTransLog.setContent(cmcTrans.getContent());
		cmcTransLogMapper.insert(cmcTransLog);
		
		return cmcTrans;
    }	
	
	
	/**
	 * 处理CMC交易记录-下单-处理订单-加值-更新CMC表状态
	 * 
	 * '是否加值成功(0: 未处理 1: 成功 2: 失败)'
	 * 
	 * @param CmcTrans cmcTrans 
	 * 
	 * @return OrderInfo
	 */
    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public OrderInfo saveCmcOrderInfo(CmcTrans cmcTrans){
		
    	OrderInfo orderInfo = new OrderInfo();
    	orderInfo.setOrderType(OrderTypeEnum.CHARGE.getId());
		orderInfo.setPayType(PayTypeEnum.CMC_BANK_PAY.getCode());
		orderInfo.setGoodsId(0);
		orderInfo.setGoodsNum(0);
		//查询充值网点
		PayTracode payTracode = payTracodeMapper.selectByTracode(cmcTrans.getFrmcod());
		if(null == payTracode){
			log.error("通过CMC交易明细中的企业识别码未能找对应的充值网点, 企业识别码={}", cmcTrans.getFrmcod());
			throw new RuntimeException("通过CMC交易明细中的企业识别码未能找对应的充值网点, 企业识别码=" + cmcTrans.getFrmcod());
		}
		orderInfo.setPayUid(payTracode.getUserId());
		orderInfo.setChannelId(payTracode.getChannelId());
		int orderMoney = Math.abs((int)(cmcTrans.getTrsamt().doubleValue()*100.0));
		orderInfo.setOrderMoney(orderMoney);
		//生成订单号
		String orderNo = SequenceUtil.getOrderNo(orderInfo.getChannelId()+"");
		orderInfo.setOrderNo(orderNo);
		
		log.info("CMC交易 orderInfo={}, cmcTrans={}", JSONUtil.objectToJson(orderInfo), JSONUtil.objectToJson(cmcTrans));
		orderInfoService.saveOrderInfo(orderInfo, null);
		
		cmcTrans.setStatus("1");
		cmcTrans.setEmsg("");
		cmcTransMapper.update(cmcTrans);
		
		return orderInfo;
	}	
	
	
	/**
	 * 处理CMC交易记录失败记录日志
	 * 
	 * @param CmcTrans cmcTrans 
	 * 
	 * @return
	 */
	public int saveCmcTransLog(CmcTrans cmcTrans){
		return cmcTransMapper.update(cmcTrans);
	}

    
	/**
	 * 获取下单失败的交易
	 * 
	 * @param 
	 * 
	 * @return
	 */
	public List<CmcTrans> getFailTransList(){
		return cmcTransMapper.selectFailTrans();
	}
}
