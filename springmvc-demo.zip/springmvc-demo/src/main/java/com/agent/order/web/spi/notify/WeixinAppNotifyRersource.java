package com.agent.order.web.spi.notify;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.constant.SysConstant;
import com.agent.order.common.util.DateUtil;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.third.weixin.WXUtil;
import com.agent.order.exception.OrderException;
import com.agent.order.web.dto.PayNotifyDto;

/**
 * 微信支付通知
 * @author kangy
 *
 */
@RestController
@Scope("prototype")
public class WeixinAppNotifyRersource extends NotifyRersource {
	private static final Logger log = LoggerFactory.getLogger(WeixinAppNotifyRersource.class);
	@Resource 
	private  HttpServletRequest request;
	Map<String, String> rMap;//pasXml得到的Map参数
	
	@RequestMapping(value = "/notify/wx_app", method = RequestMethod.POST, produces = SysConstant.APPLICATION_JSON_UTF8)
	public String weixin(){
		try {
			super.process();
		} catch (Exception e) {
			log.error("支付失败", e);
			return "fail";
		}
		return "success";
	}
	
	@Override
	PayNotifyDto buildPayNotifyDto() {
		this.getData(request);
		String out_trade_no = rMap.get("out_trade_no"); // 订单号
		String trade_no = rMap.get("transaction_id"); // 支付宝交易号
		String total_fee = rMap.get("total_fee"); // 交易金额
		String notifyTime = rMap.get("time_end"); // 交易完成时间 
		//获取code
		String rcode=rMap.get("return_code");

		PayNotifyDto payNotifyDto = new PayNotifyDto();
		payNotifyDto.setTransId(out_trade_no);
		payNotifyDto.setOutTransId(trade_no);// 支付宝交易号
		payNotifyDto.setOrderNo(out_trade_no);// 订单号
		payNotifyDto.setReceipt("");
		payNotifyDto.setReturnData(JSONUtil.objectToJson(rMap));		
		payNotifyDto.setChargeMoney(Integer.parseInt(total_fee));// 精确到分
		try {
			if (StringUtils.isNotBlank(notifyTime)) {
				payNotifyDto.setNotifyTime(DateUtil.parse(notifyTime,
						DateUtil.FMT_TYPE4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		payNotifyDto.setPayType(PayTypeEnum.WX_APP.getCode());
		payNotifyDto.setThirdPaySuccess("SUCCESS".equals(rcode));
    
		return payNotifyDto;
	}
	
    private void getData(HttpServletRequest req) {
        
		try {
			rMap = WXUtil.parseXml(req);
			log.info("微信支付通知:{}",rMap.toString());
			
		} catch (Exception e) {
			throw new OrderException("WXUtil.xmlTomap异常",e);
		}
     }
    
	@Override
	boolean validateSign() {
		return true;
	}
}
