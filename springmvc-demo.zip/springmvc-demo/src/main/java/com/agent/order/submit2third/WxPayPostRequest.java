package com.agent.order.submit2third;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.third.weixin.WXUtil;
import com.agent.order.exception.OrderException;
import com.agent.order.service.WxPayService;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.Request;
import com.agent.order.web.dto.Result;
import com.agent.order.web.dto.ThirdOrder;
import com.fasterxml.jackson.core.type.TypeReference;


/**
 * 微信支付post
 * 
 */
@Service
public class WxPayPostRequest extends SubmitRequest {

    private static final Logger log = LoggerFactory.getLogger(WxPayPostRequest.class);
    @Resource
    private WxPayService wxPayService;

    @Override
    Result submit(Request request) throws Exception {
        Result result = new Result();
        String requestUrl = request.getThirdOrder().getUrl();
        if (WXUtil.isEmpty(requestUrl)) {
            throw new OrderException("The given url is empty.");
        }
        log.info("微信支付的订单请求，\n请求URL:" + requestUrl + "，\n请求内容：" + request.getThirdOrder().getParamMap());
        
        Map<String, Object> rsp= wxPayService.genprepay(request.getThirdOrder().getParamMap(), requestUrl);
        String resultString = rsp.get("rsp")+"";
        result.setResponse(resultString);
        return result;
    }

    /**
     * 
     */
    @Override
    void handleResponseResult(Result result, ThirdOrder thirdOrder) {
        String resultString = result.getResponse();
        Map<String, String> rMap=null;
        try {
        	Map<String, Object> rs=new HashMap<String, Object>();
			rMap=WXUtil.parseXml(resultString);
			//获取code
			String rcode=rMap.get("result_code");
			if(rcode.equals("SUCCESS")){
				rs.put("result", 0);
			}else{
				rs.put("result", 1);
			}
			
			// 获取prepay_id
			if(rMap.get("prepay_id")!=null&&rMap.get("prepay_id").toString().length()>0){
				rs.put("prepay_id", rMap.get("prepay_id"));
			}
			//获取sign
			if(rMap.get("sign")!=null&&rMap.get("sign").toString().length()>0){
				rs.put("sign", rMap.get("sign"));
			}
			//获取return_msg
			if(rMap.get("return_msg")!=null&&rMap.get("return_msg").toString().length()>0){
				rs.put("return_msg", rMap.get("return_msg"));
			}
			//获取nonce_str
			if(rMap.get("nonce_str")!=null&&rMap.get("nonce_str").toString().length()>0){
				rs.put("nonce_str", rMap.get("nonce_str"));
			}
			//获取sign
			if(rMap.get("trade_type")!=null&&rMap.get("trade_type").toString().length()>0){
				rs.put("trade_type", rMap.get("trade_type"));
			}

			String tojson = JSONUtil.objectToJson(rs);
			result.setResponseResult(tojson);
		} catch (Exception e) {
			log.error("微信统一下单解析反回结果失败", e);
			throw new OrderException("微信统一下单解析反回结果失败", e);
		}
    }

    @Override
    void setPayResultCode(Result result) {
        result.setPayResultCode("rsp_result");
    }

	@Override
	boolean isSubmitSuccess(String rsp) {
        Map<String,String> resData = new HashMap<String,String>();
        try {
			resData=WXUtil.parseXml(rsp);
		} catch (Exception e) {
			e.printStackTrace();
		}
        if(resData!=null && resData.get("return_code")!=null&&resData.get("return_code").toString().length()>0){
        	String rcode=resData.get("return_code")+"";
        	// 响应码表示成功
        	if ("SUCCESS".equals(rcode)) {
        		return true;
        	}
        }
        return false;
	}
	
    /**
     * 获取反回支付信息
     * 
     * @return
     */
	public Map<String, Object> getPayTransInfo(Result result){
    	Map<String,Object> ret = JSONUtil.jsonToObject(result.getResponseResult(), new TypeReference<Map<String,Object>>() {});
    	String timestamp =  WXUtil.getTimeStamp();
    	SortedMap<String,Object>  packageOrderParams=new TreeMap<String,Object>();
		packageOrderParams.put("appid", PaymentCache.getValue("wx_app.appid"));//微信分配的公众账号ID  APP_ID 对应acct中的sign_key
		packageOrderParams.put("noncestr", WXUtil.MD5Encode(timestamp, "UTF-8"));//随机字符串，不长于32位
		packageOrderParams.put("package", "Sign=WXPay");
		packageOrderParams.put("partnerid", PaymentCache.getValue("wx_app.mch_id"));
		packageOrderParams.put("prepayid", ret.get("prepay_id"));
		packageOrderParams.put("timestamp", timestamp);
		
		WXUtil.createSign(packageOrderParams,PaymentCache.getValue("wx_app.key"));//得到加密key(ma5(mch_id)而来)	
    	return packageOrderParams;
    }

}
