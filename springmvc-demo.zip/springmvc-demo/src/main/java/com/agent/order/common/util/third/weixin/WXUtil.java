package com.agent.order.common.util.third.weixin;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WXUtil {
	 private static final Logger log              = LoggerFactory.getLogger(WXUtil.class);
	 
	private static final String hexDigits[] = { "0", "1", "2", "3", "4", "5",
		"6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };
	public static String getNonceStr() {
		Random random = new Random();
		return MD5Encode(String.valueOf(random.nextInt(10000)), "GBK");
	}

	public static String getTimeStamp() {
		return String.valueOf(System.currentTimeMillis() / 1000);
	}
	
	public static String getSha1(String str) {
		if (str == null || str.length() == 0) {
			return null;
		}

		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'a', 'b', 'c', 'd', 'e', 'f' };

		try {
			MessageDigest mdTemp = MessageDigest.getInstance("SHA1");
			mdTemp.update(str.getBytes());

			byte[] md = mdTemp.digest();
			int j = md.length;
			char buf[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				buf[k++] = hexDigits[byte0 >>> 4 & 0xf];
				buf[k++] = hexDigits[byte0 & 0xf];
			}
			return new String(buf);
		} catch (Exception e) {
			return null;
		}
	}
	private static String byteArrayToHexString(byte b[]) {
		StringBuffer resultSb = new StringBuffer();
		for (int i = 0; i < b.length; i++)
			resultSb.append(byteToHexString(b[i]));

		return resultSb.toString();
	}

	private static String byteToHexString(byte b) {
		int n = b;
		if (n < 0)
			n += 256;
		int d1 = n / 16;
		int d2 = n % 16;
		return hexDigits[d1] + hexDigits[d2];
	}

	public static String MD5Encode(String origin, String charsetname) {
		String resultString = null;
		try {
			resultString = new String(origin);
			MessageDigest md = MessageDigest.getInstance("MD5");
			if (charsetname == null || "".equals(charsetname))
				resultString = byteArrayToHexString(md.digest(resultString
						.getBytes()));
			else
				resultString = byteArrayToHexString(md.digest(resultString
						.getBytes(charsetname)));
		} catch (Exception exception) {
		}
		return resultString;
	}

	
	public  static Map<String, String> parseXml(String xmlString) throws IOException, DocumentException{
		Document document = DocumentHelper.parseText(xmlString);
		return parseXml(document);
	}
	
	public  static Map<String, String> parseXml(HttpServletRequest request) throws IOException, DocumentException{
		InputStream   inputStream   =  request.getInputStream(); 
		return parseXml(inputStream);
	}
	
    /** 

     * 解析微信发来的请求（XML） 
     * @param request 

     * @return 
     * @throws IOException 
     * @throws DocumentException 

     * @throws Exception 

     */  

    public  static Map<String, String> parseXml(InputStream inputStream) throws IOException, DocumentException  {  

        // 将解析结果存储在HashMap中  
        SAXReader reader = new SAXReader();

        Document document = reader.read(inputStream); 
        return parseXml(document);

    }
    
    @SuppressWarnings("unchecked")
    public  static Map<String, String> parseXml(Document document) {  

        // 将解析结果存储在HashMap中  

        Map<String, String> map = new HashMap<String, String>();  

        // 得到xml根元素  

        Element root = document.getRootElement();  

        // 得到根元素的全部子节点  

        List<Element> elementList = root.elements();  

        // 遍历全部子节点  

        for (Element e : elementList)  {

            map.put(e.getName(), e.getText()); 

           }

        return map;  

    }
	/**
	 * 判断给入的字符串是否为空,null、""、" "都表示空字符串
	 * 
	 * @param str
	 *            待判定的字符串
	 * @return 空符串返回true，否则返回false
	 */
	public static boolean isEmpty(String str) {
		if (null == str || "".equals(str.trim())) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	@SuppressWarnings("rawtypes")
    public static void createSign(Map <String,Object> map,String key) {
		StringBuffer sb = new StringBuffer();
		Set es = map.entrySet();
		Iterator it = es.iterator();
		while(it.hasNext()) {
			Map.Entry entry = (Map.Entry)it.next();
			String k = entry.getKey()+"";
			String v = entry.getValue()+"";
			if(null != v && !"".equals(v) 
					&& !"sign".equals(k) && !"key".equals(k)) {
				sb.append(k + "=" + v + "&");
			}
		}
		sb.append("key=" + key);
		String enc = "UTF-8";
		log.info("微信签名串:{}", sb.toString());
		String sign = WXUtil.MD5Encode(sb.toString(), enc).toUpperCase();
		map.put("sign", sign);
	}
	
	
	@SuppressWarnings("rawtypes")
    public static String sendPost(Map<String,Object> map,String requestUrl) {
		StringBuffer sb = new StringBuffer("");
		Set es = map.entrySet();
		Iterator it = es.iterator();
		sb.append("<xml>"+"\n");
		while (it.hasNext()) {
			Map.Entry entry = (Map.Entry) it.next();
			String k =  entry.getKey()+"";
			String v = entry.getValue()+"";
			if (null != v && !"".equals(v) && !"appkey".equals(k)) {
				sb.append(" <"+k+">"+v+"</"+k+">"+"\n");
			}
		}
		sb.append("</xml>");
		log.info("requestUrl="+requestUrl);
		TenpayHttpClient httpClient = new TenpayHttpClient();
		httpClient.setReqContent(requestUrl);
		String resContent = "";
		log.info("post data:" + sb.toString());
		if (httpClient.callHttpPost(requestUrl, sb.toString())) {
			resContent = httpClient.getResContent();
		}
		log.info("resContent:" + resContent);
		return resContent;
	}
	
}
