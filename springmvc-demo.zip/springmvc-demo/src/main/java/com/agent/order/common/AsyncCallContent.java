package com.agent.order.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.agent.order.exception.OrderException;
import com.agent.order.web.dto.PayNotifyDto;

public abstract class AsyncCallContent {
	private static final Logger log = LoggerFactory.getLogger(AsyncCallContent.class);	
	
	public void onSuccess() { // 执行成功的动作。用户可以覆盖此方法
		log.debug("onSuccess");
	}

	public void onFailure(PayNotifyDto dto,OrderException e){
		log.error("异步调用异常",e);
	}

	public abstract void doSomeThing(PayNotifyDto dto); // 用户必须实现这个抽象方法，告诉子线程要做什么
}
