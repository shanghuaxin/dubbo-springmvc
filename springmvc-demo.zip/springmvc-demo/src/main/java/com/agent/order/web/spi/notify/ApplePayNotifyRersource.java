package com.agent.order.web.spi.notify;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.constant.SysConstant;
import com.agent.order.common.util.HttpTransport;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.exception.OrderException;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.PayNotifyDto;
import com.agent.order.web.dto.ResultDto;
import com.fasterxml.jackson.core.type.TypeReference;


@RestController
@Scope("prototype")
@SuppressWarnings("unchecked")
public class ApplePayNotifyRersource extends NotifyRersource {
	private static final Logger log = LoggerFactory.getLogger(ApplePayNotifyRersource.class);
	private Map<String,Object> rMap;
	
	@RequestMapping(value = "/notify/apple_pay", method = RequestMethod.POST, produces = SysConstant.APPLICATION_JSON_UTF8)
	public ResultDto applePay(@RequestBody String jsonStr) {
		ResultDto result = new ResultDto(OrderErrorCode.SUCCESS,"成功");
		log.info("苹果支付客户端通知：{}",jsonStr);
		try {
			this.rMap = JSONUtil.jsonToObject(jsonStr, new TypeReference<Map<String,Object>>() {
			});
			process();
		} catch (OrderException e) {
			result.setCode(e.getCode());
			result.setMsg(e.getMessage());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			result.setCode(OrderErrorCode.UNKOWN_ERR);
			result.setMsg("未知错误");
			log.error("未知错误",e);
		}
		log.info("苹果支付客户端通知结束，返回：{}",JSONUtil.objectToJson(result));
		return result;

	}
	
    @Override
	PayNotifyDto buildPayNotifyDto() {

		String out_trade_no = rMap.get("order_no")==null?"":rMap.get("order_no")+""; // 订单号

		Map<String,Object> apple_pay_info = (Map<String,Object>)rMap.get("apple_pay_info");
		String trade_no = apple_pay_info.get("transactionIdentifier")==null?"":apple_pay_info.get("transactionIdentifier")+""; // 交易号

		PayNotifyDto payNotifyDto = new PayNotifyDto();
		payNotifyDto.setTransId(out_trade_no);
		payNotifyDto.setOutTransId(trade_no);// 苹果交易号
		payNotifyDto.setOrderNo(out_trade_no);// 订单号
		String transactionReceipt = ((Map<String,Object>)rMap.get("apple_pay_info")).get("transactionReceipt")+""; // 收据号
		payNotifyDto.setReceipt(transactionReceipt);
		payNotifyDto.setReturnData(JSONUtil.objectToJson(rMap));		
		payNotifyDto.setThirdPaySuccess(true);//第三方支付默认成功
		payNotifyDto.setPayType(PayTypeEnum.APPLE_PAY.getCode());
		return payNotifyDto;
	}

	@Override
	boolean validateSign() {
		String url = PaymentCache.getValue("URL_OUTER_SYSTEM_APPLE_RECEIPT");
		//验证收据
		String orderNo = rMap.get("order_no")==null?"":rMap.get("order_no")+""; // 订单号
		String transactionReceipt = ((Map<String,Object>)rMap.get("apple_pay_info")).get("transactionReceipt")+""; // 交易号
		
		
		String receiptdata = "{\"receipt-data\":\"" + transactionReceipt + "\"}";

		log.info("苹果充值验证收据,订单号:{},苹果验证地址:{},收据:{}" ,orderNo,url,receiptdata);
        
        String rsp = HttpTransport.getInstance().doPost(url, receiptdata);

        log.info("苹果充值验证收据,订单号：{},响应结果：{}" ,orderNo,rsp);

        
        Map<String,Object> rspMap = JSONUtil.jsonToObject(rsp,new TypeReference<Map<String,Object>>() {
		});
        
        if (!"0".equals(rspMap.get("status")+"")) {
            /** 验证失败 */
        	return false;
        }
        
        return true;
	}

}
