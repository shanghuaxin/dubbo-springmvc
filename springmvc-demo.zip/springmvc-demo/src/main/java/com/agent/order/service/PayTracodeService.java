package com.agent.order.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.agent.order.entity.PayTracode;
import com.agent.order.mapper.PayTracodeMapper;

@Service
public class PayTracodeService{
	
	@Resource
	PayTracodeMapper payTracodeMapper;

	/**
	 * 查询交易码
	 * 
	 * @param userId
	 * 
	 * @return
	 */
	public PayTracode queryPayTracode(Integer userId){
		return payTracodeMapper.selectByUid(userId);
	}
	
	/**
     * 查询交易码
     * 
     * @param userId
     * 
     * @return
     */
    public PayTracode selectByChannelId(Integer channelId){
        return payTracodeMapper.selectByChannelId(channelId);
    }
	
}
