package com.agent.order.common.controller;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.agent.number.service.NumberService;
import com.agent.order.entity.OrderInfo;
import com.agent.order.service.OrderInfoService;
import com.agent.system.entity.User;
import com.agent.util.DecimalUtil;

/**
 * 支付宝回调控制器
 *
 * @author fenglu
 */
@Controller
@RequestMapping(value="alipay")
public class AlipayPaymentController {
    
    private static Logger logger = LoggerFactory.getLogger(AlipayPaymentController.class);
    
    @Autowired
    private OrderInfoService orderInfoService;
    @Autowired
    private NumberService numberService;
    
    /**
     * 支付宝回调处理，修改订单状态和账户加值
     */
    @RequestMapping("alipayPaymentNotify")
    public void payNotify(HttpServletRequest request, HttpServletResponse response) {
        String out_trade_no = request.getParameter("out_trade_no"); // 订单号
        String trade_no = request.getParameter("trade_no"); // 支付宝交易号
        String total_fee = request.getParameter("total_fee"); // 交易金额(元)
        String trade_status = request.getParameter("trade_status"); // 交易状态
        String notifyId = request.getParameter("notify_id"); // 通知ID
        String notifyTime = request.getParameter("notify_time"); // 通知时间
        logger.info("AlipayPaymentController--->"+out_trade_no+"---"+trade_no+"---"+total_fee+"---"+trade_status+"---"+notifyId+"---"+notifyTime);
        
        PrintWriter out = null;
        try {
            out = response.getWriter();
            User curUser = (User) request.getSession().getAttribute("user");
            OrderInfo order = orderInfoService.findByOrderNo(out_trade_no);
            if (null != order) {
                if ("TRADE_SUCCESS".equals(trade_status)) {
                    order.setStatus("1");
                } else {
                    // 异常订单
                    order.setStatus("2");
                }
                orderInfoService.updateStatus(order);
            }
            
            if ("TRADE_SUCCESS".equals(trade_status)) {
                BigDecimal orderMoneyReal = new BigDecimal(total_fee);
                double money = DecimalUtil.mul(Double.valueOf(total_fee), 0.99);
                BigDecimal orderMoney = new BigDecimal(money);
                // 保留小数点后四位
                orderMoney = orderMoney.setScale(4,BigDecimal.ROUND_DOWN);
                // 充值类型：2.直充
                int payType = 2;

                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", null);
                param.put("channelId", order.getChannelId());
                param.put("accountType", 3);
                param.put("operationType", 2);
                param.put("money", orderMoney);
                param.put("busMoney", orderMoneyReal);
                param.put("remark", "代理商加值");
                param.put("transactionAccount", "总部加值：系统加值");
                param.put("transId", out_trade_no);
                param.put("transactionType", "t_pay_order_info");
                param.put("calcType", "+");
                param.put("transactionFlow", trade_no);
                param.put("payType", payType);
                param.put("us", curUser);
                // 往直充账户里加值
                numberService.takeMoney(param);
            }
            out.print("success");
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
    
    /**
     * 支付宝回调处理
     */
    @RequestMapping("alipayPaymentReturn")
    public String payReturn(HttpServletRequest request, HttpServletResponse response) {
        String out_trade_no = request.getParameter("out_trade_no"); // 订单号
        String trade_no = request.getParameter("trade_no"); // 支付宝交易号
        String total_fee = request.getParameter("total_fee"); // 交易金额（单位：元）
        String trade_status = request.getParameter("trade_status"); // 交易状态
        String notifyId = request.getParameter("notify_id"); // 通知ID
        String notifyTime = request.getParameter("notify_time"); // 通知时间
        logger.info("AlipayPaymentController--->"+out_trade_no+"---"+trade_no+"---"+total_fee+"---"+trade_status+"---"+notifyId+"---"+notifyTime);
        
        String result = null;
        if ("TRADE_SUCCESS".equals(trade_status)) {
            result = "../views/pay/paySuccess.jsp";
        } else {
            // 异常订单
            result = "../views/pay/payFail.jsp";
        }
        return result;
    }
}
