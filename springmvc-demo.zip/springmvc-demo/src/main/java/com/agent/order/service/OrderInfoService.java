package com.agent.order.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.SpringContextHolder;
import com.agent.order.common.constant.OrderStatusEnum;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.util.MD5;
import com.agent.order.common.util.third.alipay.AlipayConfig;
import com.agent.order.entity.OrderInfo;
import com.agent.order.entity.PayGoods;
import com.agent.order.entity.PayResult;
import com.agent.order.exception.OrderException;
import com.agent.order.handle.BuildThirdOrderHandle;
import com.agent.order.mapper.OrderInfoMapper;
import com.agent.order.mapper.PayResultMapper;
import com.agent.order.submit2third.SubmitRequest;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.PayNotifyDto;
import com.agent.order.web.dto.Result;
import com.agent.order.web.dto.Rs4OrderInfoDto;
import com.agent.order.web.dto.ThirdOrder;
import com.agent.util.Utils;

@Service
public class OrderInfoService{

	private static final Logger log = LoggerFactory.getLogger(OrderInfoService.class);
	
	@Resource
	OrderInfoMapper orderInfoMapper;
	@Resource
	PayResultMapper payResultMapper;
    /** 根据不同的支付发起不同的Http请求的Handler **/
    @Resource(name = "payHttpHandler")
    private Map<String, SubmitRequest> payHttpHandler;
    
	@Resource
	TransactionService transactionService;
	@Resource
	SpringContextHolder springContextHolder;
	
	/**
	 * 下单
	 * 
	 * @param orderInfo
	 * 
	 * @return
	 */
    @Transactional(readOnly = false,rollbackFor = Exception.class)
	public Rs4OrderInfoDto saveOrderInfo(OrderInfo orderInfo, PayGoods payGoods){
		Rs4OrderInfoDto rs4OrderInfoDto = new Rs4OrderInfoDto();
		
		rs4OrderInfoDto.setNotifyUrl(orderInfo.getNotifyUrl());
		rs4OrderInfoDto.setOrderNo(orderInfo.getOrderNo());
		rs4OrderInfoDto.setOrderMoney(orderInfo.getOrderMoney());
		rs4OrderInfoDto.setMemo("");
		
		//保存到数据库
		//1、新增订单表
		orderInfo.setStatus(OrderStatusEnum.NON_PAYMENT.getValue());
		orderInfoMapper.insert(orderInfo);
		//2、新增支付结果
		PayResult payResult = this.getPayResultEntity(orderInfo);
		payResult.setTransId(orderInfo.getOrderNo());
		payResultMapper.insert(payResult);
		
		if (PayTypeEnum.CMC_BANK_PAY.getCode().equals(orderInfo.getPayType())) {
			log.info("单号{}, 支付方式为-招行转账支付, 直接发货", orderInfo.getOrderNo());
			//成功发货
			PayNotifyDto payNotifyDto = this.getPayNotifyDto(orderInfo);
			//transactionBiz.successProcess(payNotifyDto);
			transactionService.saveOrderPayResult(payNotifyDto);
			log.info("单号{}, 支付方式为-招行转账支付, 直接发货成功", orderInfo.getOrderNo());
		} else if (PayTypeEnum.ALIPAY_PC.getCode().equals(orderInfo.getPayType())) {
			//刲装支付宝参数
			String alipayOrderInfo = getOrderInfo(orderInfo, payGoods);
			log.info("支付宝下单 orderInfo:{}", alipayOrderInfo);
			//String sign = RSA.sign(alipayOrderInfo, PaymentCache.getValue("alipay_mobile.privatekey"), "UTF-8");
			String sign = MD5.sign(alipayOrderInfo, AlipayConfig.getValue(AlipayConfig.SECURITY_KEY), "UTF-8");
			if(null == sign){
				throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "支付宝下单  sign 异常");
			}
			try {
				/**
				 * 仅需对sign 做URL编码
				 */
				sign = URLEncoder.encode(sign, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				log.error("支付宝下单  sign 做URL编码 异常");
				throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "支付宝下单  sign 做URL编码 异常");
			}
			/**
			 * 完整的符合支付宝参数规范的订单信息
			 */
			final String payInfo = alipayOrderInfo + "&sign=\"" + sign + "\"&sign_type=\"MD5\"";
			log.info("支付宝下单 payInfo:{}", payInfo);
			rs4OrderInfoDto.setAlipayInfo(payInfo);
			rs4OrderInfoDto.setWx_ret(new HashMap<String, Object>());
		} else {
			/** 将银行订单后台提交到银行(weixin需要) **/
			SubmitRequest request = payHttpHandler.get(orderInfo.getPayType());
			if(request != null){
				//生成银行订单
				//支付方式处理器 不同的支付方式用不同的支付方式处理器
				BuildThirdOrderHandle handle = this.getBuilThirdOrderHandleByPayType(orderInfo.getPayType());
				ThirdOrder thirdOrder =  handle.buildThirdOrder(orderInfo.getOrderNo(), orderInfo);
				thirdOrder.setTransId(orderInfo.getOrderNo());
				Result result = request.submitAndGetResult(thirdOrder);
				log.info("微信下单" + (result.isPayResult() ? "成功" : "失败"));
				log.info("返回数据：{}",result.getResponse());
				log.info("处理后：{}",result.getResponseResult());
				Map<String, Object> rt = request.getPayTransInfo(result);
				log.info("微信生成app调起支付订单数据", rt.toString());
				rs4OrderInfoDto.setAlipayInfo("");
				rs4OrderInfoDto.setWx_ret(rt);
			}
		}
		
		return rs4OrderInfoDto;
	}
    
	
	/**
	 * 撤单
	 * 
	 * @param orderInfo
	 * 
	 * @return
	 */
	public int cancelOrderInfo(String orderNo){
		return orderInfoMapper.delete(orderNo);
	}
	
	/**
	 * 查询订单
	 * 
	 * @param orderNo
	 * 
	 * @return
	 */
	public OrderInfo queryOrderInfo(String orderNo){
		return orderInfoMapper.select(orderNo);
	}
	

	/**
	 * 得到ProcResult实体
	 * @param OrderInfo
	 * @return
	 */
	private PayResult getPayResultEntity(OrderInfo orderInfo){
		PayResult payResult = new PayResult();
		payResult.setPayType(orderInfo.getPayType());
		payResult.setOrderMoney(orderInfo.getOrderMoney());
		payResult.setSettleDate(new Date());
		return payResult;
	}
	
	/**
	 * 根据支付方式获取支付处理器
	 * @param payType
	 */
	private BuildThirdOrderHandle getBuilThirdOrderHandleByPayType(String payType){
		payType = Utils.replaceUnderlineAndfirstToUpper(payType, "_", "");
		String handerStr = payType+"BuildThirdOrderHandle";
		return (BuildThirdOrderHandle)springContextHolder.getBean(handerStr);
	}	
	
	private PayNotifyDto getPayNotifyDto(OrderInfo orderInfo) {
		PayNotifyDto payNotifyDto = new PayNotifyDto();
		payNotifyDto.setTransId(orderInfo.getOrderNo());
		payNotifyDto.setOrderNo(orderInfo.getOrderNo());
		payNotifyDto.setPayType(orderInfo.getPayType());
		payNotifyDto.setChargeMoney(orderInfo.getOrderMoney());
		payNotifyDto.setOrderMoney(orderInfo.getOrderMoney());
		payNotifyDto.setThirdPaySuccess(true);
		return payNotifyDto;
	}
	
	/**
	 * create the order info. 创建订单信息
	 * 
	 */
	private String getOrderInfo(OrderInfo order, PayGoods payGoods) {

		// 签约合作者身份ID
		String orderInfo = "partner=" + "\"" + PaymentCache.getValue("alipay_pc.partner") + "\"";

		// 签约卖家支付宝账号
		orderInfo += "&seller_id=" + "\"" + PaymentCache.getValue("alipay_pc.email") + "\"";

		// 商户网站唯一订单号
		orderInfo += "&out_trade_no=" + "\"" + order.getOrderNo() + "\"";

		// 商品名称
		orderInfo += "&subject=" + "\"" + payGoods.getGoodsName() + "\"";

		// 商品详情
		orderInfo += "&body=" + "\"" + payGoods.getDescr() + "\"";

		// 商品金额
		orderInfo += "&total_fee=" + "\"" + order.getOrderMoney()/100.0 + "\"";

		// 服务器异步通知页面路径
		orderInfo += "&notify_url=" + "\"" + order.getNotifyUrl() + "\"";
		//orderInfo += "&notify_url=" + "\"" + AlipayConfig.NOTIFY_URL + "\"";

		// 服务接口名称， 固定值
		orderInfo += "&service=\"create_direct_pay_by_user\"";

		// 支付类型， 固定值
		orderInfo += "&payment_type=\"1\"";

		// 参数编码， 固定值
		orderInfo += "&_input_charset=\"utf-8\"";

		// 设置未付款交易的超时时间
		// 默认30分钟，一旦超时，该笔交易就会自动被关闭。
		// 取值范围：1m～15d。
		// m-分钟，h-小时，d-天，1c-当天（无论交易何时创建，都在0点关闭）。
		// 该参数数值不接受小数点，如1.5h，可转换为90m。
		orderInfo += "&it_b_pay=\"30m\"";

		// extern_token为经过快登授权获取到的alipay_open_id,带上此参数用户将使用授权的账户进行支付
		// orderInfo += "&extern_token=" + "\"" + extern_token + "\"";

		// 支付宝处理完请求后，当前页面跳转到商户指定页面的路径，可空
		//orderInfo += "&return_url=\"m.alipay.com\"";
		orderInfo += "&return_url=\"" + AlipayConfig.getValue(AlipayConfig.RETURN_URL) + "\"";

		// 调用银行卡支付，需配置此参数，参与签名， 固定值 （需要签约《无线银行卡快捷支付》才能使用）
		// orderInfo += "&paymethod=\"expressGateway\"";

		return orderInfo;
	}
    
    /**
     * 根据订单号获取订单信息
     * @param orderNo
     * @return
     */
    public OrderInfo findByOrderNo(String orderNo) {
        return orderInfoMapper.select(orderNo);
    }
    
    public int updateStatus(OrderInfo orderInfo) {
        return orderInfoMapper.updateStatus(orderInfo);
    }
}
