package com.agent.order.common.constant;

/**
 * 支付方式
 */
public enum PayTypeEnum {
    ALIPAY_MOBILE("alipay_mobile", "支付宝移动支付"),
    ALIPAY_PC("alipay_pc", "支付宝PC支付"),
    WX_APP("wx_app", "微信app支付"),
    WX_PC("wx_pc", "微信PC支付"),
    SCANPAY("wx_pc_scan","微信扫码支付"),
    YEEPAY_YJPAY("yeepay_yjpay", "易宝一键支付"),
    YEEPAY_CARD("yeepay_card", "易宝卡支付"),
    APPLE_PAY("apple_pay","苹果支付"),
    CMC_BANK_PAY("cmc_bank_pay","招行转账支付"),
    DIRECT_PAY("direct_pay","直充");
	
	private String code;
	private String name;
	
	private PayTypeEnum( String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
}
