package com.agent.order.mapper;

import com.agent.common.BaseMapper;
import com.agent.order.entity.Order;

public interface OrderMapper extends BaseMapper<Order,Integer>{

    Order select(String orderNo);
}