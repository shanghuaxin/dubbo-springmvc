package com.agent.order.mapper;

import java.util.List;

import com.agent.order.entity.OrderFail;

public interface OrderFailMapper{
	
	OrderFail select(String orderNo);
	
	int insert(OrderFail orderFail);
	
	int update(OrderFail orderFail);
	
	List<OrderFail> getOrderFails4Job();
}