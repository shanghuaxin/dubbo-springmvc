package com.agent.order.mapper;

import com.agent.order.entity.OrderInfo;

public interface OrderInfoMapper{
	
	
	OrderInfo select(String orderNo);
	
	int insert(OrderInfo orderInfo);
	
	int update(OrderInfo orderInfo);
	
	int updateStatus(OrderInfo orderInfo);
	
	int delete(String orderNo);

}