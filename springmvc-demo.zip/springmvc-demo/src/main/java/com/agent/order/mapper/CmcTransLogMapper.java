package com.agent.order.mapper;

import com.agent.order.entity.CmcTransLog;

public interface CmcTransLogMapper {

    int insert(CmcTransLog record);

    CmcTransLog selectByPrimaryKey(Long id);

}