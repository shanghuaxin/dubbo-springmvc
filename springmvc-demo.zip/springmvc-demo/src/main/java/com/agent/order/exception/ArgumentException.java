package com.agent.order.exception;

/**
 * 参数验证异常
 * @author kangy
 * 20150918
 *
 */
public class ArgumentException extends OrderException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3165759030719430847L;

	public ArgumentException(String msg) {
        super(msg);
    }
    
    public ArgumentException(Integer code, String msg) {
        super(code, msg);
    }
    
    public ArgumentException(String msg, Throwable t) {
        super(msg, t);
    }

    public ArgumentException(Integer code, String msg, Throwable t) {
    	super(code, msg, t);
    }
    
}
