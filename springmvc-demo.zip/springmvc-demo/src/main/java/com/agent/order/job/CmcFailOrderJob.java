package com.agent.order.job;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.agent.order.web.biz.CMCBankBiz;


@Component
public class CmcFailOrderJob {

    private static final Logger  log = LoggerFactory.getLogger(CmcFailOrderJob.class);
	
	@Resource
	CMCBankBiz cMCBankBiz;
	
    public void execute() {
    	long start = System.currentTimeMillis();
    	log.info("处理CMC失败订单任务开始执行=============================================");
    	try{
    		cMCBankBiz.procFailTransInfo();
    	}catch (Exception e){
    		log.error("处理CMC失败订单任务异常", e);
    	}
    	long end = System.currentTimeMillis();
    	log.info("处理CMC失败订单任务结束,执行时间:{}ms=============================================",(end-start));
    }


}
