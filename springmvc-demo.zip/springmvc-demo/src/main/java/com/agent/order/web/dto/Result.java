package com.agent.order.web.dto;

public class Result {

    /**
     * 请求的原始响应结果
     */
    private String             response;

    /**
     * 经过处理的请求的响应结果，该结果用于向请求支付系统的系统输出结果，也可能和原始的响应结果相同，如NewTcl
     */
    private String             responseResult;
    /**
     * 请求发生错误时的错误信息
     */
    private String             errmsg;
    /**
     * 请求结果的状态：fail表示失败，success表示成功
     */
    private String             status;
    /**
     * 表示远程支付系统是否处理成功
     */
    private boolean            payResult;
    /**
     * 支付结果码
     */
    private String             payResultCode;

    /**
     * fail：表示网络传输出现异常
     */
    public static final String FAIL    = "fail";
    /**
     * success
     */
    public static final String SUCCESS = "success";

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isPayResult() {
        return payResult;
    }

    public void setPayResult(boolean payResult) {
        this.payResult = payResult;
    }

    public String getPayResultCode() {
        return payResultCode;
    }

    public void setPayResultCode(String payResultCode) {
        this.payResultCode = payResultCode;
    }

}
