package com.agent.order.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.agent.order.entity.OrderDetail;
import com.agent.order.mapper.OrderDetailMapper;

@Service
public class OrderDetailService {
    
    @Resource
    OrderDetailMapper orderDetailMapper;
    
    /**
     * 根据订单号查询订单信息
     * @param OrderDetail 订单记录
     * @return
     */
    public List<OrderDetail> selectByOrderNo(String orderNo){
        return orderDetailMapper.selectByOrderNo(orderNo);
    }
    
    /**
     * 计算未处理订单的划拨和充值账户的金额
     * @param param
     * @return
     */
    public BigDecimal calcOrderMoney(Map<String, Object> param) {
        return orderDetailMapper.calcOrderMoney(param);
    }
    
    /**
     * 插入订单主表
     */
    public int insert(OrderDetail orderDetail){
        return orderDetailMapper.insert(orderDetail);
    }
}
