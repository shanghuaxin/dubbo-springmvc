package com.agent.order.web.dto;

import java.util.Date;

public class OrderInfoDto {

    private String orderNo;
    
    private String orderType;//"00", "充值订单"
    
    private String payType;//'支付方式("alipay_mobile", "支付宝移动支付"  "wx_app", "微信app支付"  "yeepay_yjpay", "易宝一键支付" "yeepay_card", "易宝卡支付"  "apple_pay","苹果支付"   "direct_pay","直充" )',

    private Integer payUid;//用户id

    private Integer channelId;//渠道ID
    
    private Integer goodsId;//商品ID

    private Integer goodsNum; //商品数量      
    
    private Integer orderMoney;//订单总金额(单位：分)
    
    private String status;
    
    private String notifyUrl;//通知地址
    
    private String plat;

    private String ver;
    
    private String ip;
    
    private String devices;
    
    private String descr;

    private Date createTime;

    private Date updateTime;
    
    private String returnUrl; // 支付宝处理完请求后，当前页面跳转到商户指定页面的路径，可空
    
    private String queryMonth;

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public Integer getPayUid() {
        return payUid;
    }

    public void setPayUid(Integer payUid) {
        this.payUid = payUid;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	public Integer getGoodsNum() {
		return goodsNum;
	}

	public void setGoodsNum(Integer goodsNum) {
		this.goodsNum = goodsNum;
	}	
	
	public Integer getOrderMoney() {
		return orderMoney;
	}

	public void setOrderMoney(Integer orderMoney) {
		this.orderMoney = orderMoney;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getPlat() {
		return plat;
	}

	public void setPlat(String plat) {
		this.plat = plat;
	}

	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getDevices() {
		return devices;
	}

	public void setDevices(String devices) {
		this.devices = devices;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getReturnUrl() {
		return returnUrl;
	}

	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

	public String getQueryMonth() {
		return queryMonth;
	}

	public void setQueryMonth(String queryMonth) {
		this.queryMonth = queryMonth;
	}
}
