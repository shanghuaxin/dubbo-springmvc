package com.agent.order.common.constant;

/**
 * 业务类型
 * @author kangy
 *
 */
public enum OrderFailHandleStatusEnum {
	NOT_HANDLE("00", "未处理"), ALREADY_HANDLE("01", "已处理");
	private String id;
	private String name;
	
	private OrderFailHandleStatusEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
}
