package com.agent.order.common.constant;

public enum ClientReturnStatusEnum {

	UNDO_OR_FAIL(0, "撤销或支付失败"), 
	SUCCESS (1, "支付成功"),
	OTHER (2, "其它");
	private Integer id;
	private String name;
	private ClientReturnStatusEnum(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

}
