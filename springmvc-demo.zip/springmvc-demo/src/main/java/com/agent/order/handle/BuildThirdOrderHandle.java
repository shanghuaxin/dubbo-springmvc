package com.agent.order.handle;

import com.agent.order.entity.OrderInfo;
import com.agent.order.web.dto.ThirdOrder;

/**
 * 支付处理器
 * 
 */
public interface BuildThirdOrderHandle {

    /**
     * 将内部订单转换为银行订单
     * 
     * @param transId 交易号
     * @param orderInfoDto
     * @return
     */
	ThirdOrder buildThirdOrder(String transId, OrderInfo orderInfo);
}
