package com.agent.order.common.util;

import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;


/**
 * 序列工具
 * kangy
 * 
 */
public class SequenceUtil {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
	// 随机数
	private static final Random RND = new Random(UUID.randomUUID().hashCode());
	private static final char[] chars = new char[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	
	private static int seq = 0;
	private static final Lock lock = new ReentrantLock();
	/** 生成一个16位的唯一id值 **/
	public static final String id() {
		StringBuilder id = new StringBuilder(16);
		lock.lock();
		try {
			id.append(System.currentTimeMillis());
			seq++;
			if (seq > 999)
				seq = 0;
			if (seq > 99) {
				id.append(seq);
			} else if (seq > 9) {
				id.append('0').append(seq);
			} else {
				id.append("00").append(seq);
			}
		} finally {
			lock.unlock();
		}
		return id.toString();
	}
	
	
	/**
	 * 生成len长度的随机数序列
	 * 
	 * @param len 长度
	 * @return String 随机数字符
	 */
	public static String generateRandomString(int len) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < len; i++) {
			sb.append(chars[RND.nextInt(chars.length)]);
		}
		return sb.toString();
	}
	
    public static String getOrderNo(String ditchId) {
    	String no = getPrefix(ditchId);
    	
    	StringBuilder sb = new StringBuilder();
		sb.append(no)
		  .append(sdf.format(System.currentTimeMillis()))
		  .append(generateRandomString(10));
		return sb.toString();
    }
    
    /**
     * 根据渠道获取3位数字前缀
     * @param ditchId
     * @return
     */
    private static String getPrefix(String ditchId){
    	String resultV = "888888";
    	if(StringUtils.isEmpty(ditchId)){
    		return resultV;
    	}
    	String data = DigestUtils.md5Hex(ditchId);
    	data = data.replaceAll("[^1-9]", "");
    	if(data.length()>=5){
    		return data.substring(0,5);
    	}else{
    		return data.toString() + generateRandomString(5-data.length());
    	}
    }
}
