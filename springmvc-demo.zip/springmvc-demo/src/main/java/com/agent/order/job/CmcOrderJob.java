package com.agent.order.job;

import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.agent.order.common.util.DateUtil;
import com.agent.order.web.biz.CMCBankBiz;
import com.agent.order.web.cache.PaymentCache;

@Component
public class CmcOrderJob {

    private static final Logger  log = LoggerFactory.getLogger(CmcOrderJob.class);
	
	@Resource
	CMCBankBiz cMCBankBiz;
	
    public void execute() {
    	long start = System.currentTimeMillis();
    	log.info("处理CMC订单任务开始执行=============================================");
    	try{
    		String BBKNBR = PaymentCache.getValue("CMC_BBKNBR");
    		String ACCNBR = PaymentCache.getValue("CMC_ACCNBR"); 
    		String BGNDAT = DateUtil.getNowyyyyMMdd(new Date());
    		String ENDDAT = DateUtil.getNowyyyyMMdd(new Date());
    		//String BGNDAT = "20150621";
    		//String ENDDAT = "20150921";
    		cMCBankBiz.procTransInfo(BBKNBR, ACCNBR, BGNDAT, ENDDAT);
    	}catch (Exception e){
    		log.error("处理CMC订单任务异常", e);
    	}
    	long end = System.currentTimeMillis();
    	log.info("处理CMC订单任务结束,执行时间:{}ms=============================================",(end-start));
    }


}
