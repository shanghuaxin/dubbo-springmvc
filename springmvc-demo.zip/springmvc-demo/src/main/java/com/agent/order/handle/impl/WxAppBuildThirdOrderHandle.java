package com.agent.order.handle.impl;

import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.agent.order.common.util.third.weixin.WXUtil;
import com.agent.order.entity.OrderInfo;
import com.agent.order.handle.BuildThirdOrderHandle;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.ThirdOrder;

@Component(value="wxAppBuildThirdOrderHandle")
public class WxAppBuildThirdOrderHandle implements BuildThirdOrderHandle {
	
	public static final Logger log = LoggerFactory.getLogger(WxAppBuildThirdOrderHandle.class);
    
	public static final String WX_ORDER_URL = "https://api.mch.weixin.qq.com/pay/unifiedorder";

	@Override
	public ThirdOrder buildThirdOrder(String transId, OrderInfo orderInfo) {

    	//注释掉的为代码为非必输参数
    	SortedMap<String,Object>  packageOrderParams=new TreeMap<String,Object>();
		packageOrderParams.put("appid", PaymentCache.getValue("wx_app.appid"));//微信分配的公众账号ID  APP_ID 对应acct中的sign_key
		packageOrderParams.put("mch_id", PaymentCache.getValue("wx_app.mch_id"));//微信支付分配的商户号  PARTNER 对应acct中的acct_id
//		packageOrderParams.put("device_info", value);//终端设备号(门店号或收银设备ID)，注意：PC网页或公众号内支付请传"WEB"
		packageOrderParams.put("nonce_str", WXUtil.getNonceStr());//随机字符串，不长于32位
		String proDesc = orderInfo.getOrderMoney()+"分(CNY)";
		packageOrderParams.put("body",proDesc);//商品描述
//		packageOrderParams.put("detail", "");//详情	
//		packageOrderParams.put("attach",payOrder.getProductDesc());// 	附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据 
		packageOrderParams.put("out_trade_no", transId);//系统内部订单号
//		packageOrderParams.put("fee_type ", value);//符合ISO 4217标准的三位字母代码，默认人民币：CNY
		packageOrderParams.put("total_fee", orderInfo.getOrderMoney());//订单总金额
		String cip=orderInfo.getIp();
		if(StringUtils.isEmpty(cip)||cip.equals("null")){
			cip="127.0.0.1";
		}
		packageOrderParams.put("spbill_create_ip", cip);//APP和网页支付提交用户端ip，Native支付填调用微信支付API的机器IP。
//		packageOrderParams.put("time_start", "20091225091010");//订单生成时间，格式为yyyyMMddHHmmss，如2009年12月25日9点10分10秒表示为20091225091010。
//		packageOrderParams.put("time_expire", "20091225091010");//订单失效时间
//		packageOrderParams.put("goods_tag", "127.0.0.1");// 	商品标记，代金券或立减优惠功能的参数
		packageOrderParams.put("notify_url",orderInfo.getNotifyUrl());//通知地址
		packageOrderParams.put("trade_type", "APP");//取值如下：JSAPI，NATIVE，APP，详细说明见
//		packageOrderParams.put("product_id", "127.0.0.1");//trade_type=NATIVE，此参数必传。此id为二维码中包含的商品ID，商户自行定义
//		packageOrderParams.put("openid", "oUpF8uMuAJO_M2pxb1Q9zNjWeS6o");//trade_type=JSAPI，此参数必传，用户在商户appid下的唯一标识。下单前需要调用
		WXUtil.createSign(packageOrderParams,PaymentCache.getValue("wx_app.key"));//得到加密key(ma5(mch_id)而来)
		
		String requestUrl=WX_ORDER_URL;
		ThirdOrder thirdOrder = new ThirdOrder();
		thirdOrder.setParamMap(packageOrderParams);

		thirdOrder.setUrl(requestUrl);
		thirdOrder.setMethod("post");

        return thirdOrder;
    
	}
	


}
