package com.agent.order.common.util.third.weixin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.agent.order.common.util.third.weixin.entity.ScanPayResultVo;
import com.agent.order.common.util.third.weixin.entity.WeiXinPrePay;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * <b>功能说明:交易模块管理实现类实现</b>
 */
public class WeixinPaySubmit {

    private static Logger logger = LoggerFactory.getLogger(WeixinPaySubmit.class);

    /**
     * 通过支付订单及商户费率生成支付记录
     * @param rpTradePaymentOrder   支付订单
     * @param payWay   商户支付配置
     * @return
     * @throws Exception 
     */
    public ScanPayResultVo getScanPayResultVo(Map<String , Object> paramMap) throws Exception{

        ScanPayResultVo scanPayResultVo = new ScanPayResultVo();
        
        String appid = WeixinConfigUtil.readConfig("wx_pc.appId");
        String mch_id = WeixinConfigUtil.readConfig("wx_pc.mch_id");
        String partnerKey = WeixinConfigUtil.readConfig("wx_pc.partnerKey");
        String prepayUrl = WeixinConfigUtil.readConfig("wx_pc.prepay_url");
        String productName = paramMap.get("productName").toString();
        String orderNo = paramMap.get("orderNo").toString();
        String orderPrice = paramMap.get("orderPrice").toString();
        String orderIp = paramMap.get("orderIp").toString();

        WeiXinPrePay weiXinPrePay = sealWeixinPerPay(productName, orderNo, orderPrice, orderIp);
        String prePayXml = WeixinPayUtils.getPrePayXml(weiXinPrePay, partnerKey);
        // 调用微信支付的功能,获取微信支付code_url
        logger.info("调用微信支付入参--->"+prePayXml);
        Map<String, Object> prePayRequest = WeixinPayUtils.httpXmlRequest(prepayUrl, "POST", prePayXml);
        logger.info("调用微信支付出参--->"+prePayRequest);
        if ("SUCCESS".equals(prePayRequest.get("return_code")) && "SUCCESS".equals(prePayRequest.get("result_code"))) {
            String weiXinPrePaySign = WeixinPayUtils.geWeiXintPrePaySign(appid, mch_id, weiXinPrePay.getDeviceInfo(), "NATIVE", prePayRequest, partnerKey);
            String codeUrl = String.valueOf(prePayRequest.get("code_url"));
            logger.info("预支付生成成功,{}",codeUrl);
            if (prePayRequest.get("sign").equals(weiXinPrePaySign)) {
                scanPayResultVo.setCodeUrl(codeUrl);//设置微信跳转地址
                scanPayResultVo.setPayWayCode("WEIXIN");
                scanPayResultVo.setProductName(paramMap.get("productName").toString());
                scanPayResultVo.setOrderAmount(new BigDecimal(paramMap.get("orderPrice").toString()));
            }else{
                throw new Exception("微信返回结果签名异常");
            }
        }else{
            throw new Exception("请求微信异常");
        }

        return scanPayResultVo;
    }


    /**
     * 封装预支付实体
     * @return
     */
    private WeiXinPrePay sealWeixinPerPay(String productName, String orderNo, String orderPrice, 
            String orderIp){
        WeiXinPrePay weiXinPrePay = new WeiXinPrePay();
        
        String appId = WeixinConfigUtil.readConfig("wx_pc.appId");
        String mchId = WeixinConfigUtil.readConfig("wx_pc.mch_id");
        String notifyUrl = WeixinConfigUtil.readConfig("wx_pc.notify_url");
        Integer totalFee = new BigDecimal(orderPrice).multiply(BigDecimal.valueOf(100d)).intValue();

        // 公众号ID
        weiXinPrePay.setAppid(appId);
        // 商户ID
        weiXinPrePay.setMchId(mchId);
        // 商品描述
        weiXinPrePay.setBody(productName);
        // 订单号
        weiXinPrePay.setOutTradeNo(orderNo);
        // 订单金额
        weiXinPrePay.setTotalFee(totalFee);
        // 订单开始时间
        weiXinPrePay.setTimeStart(DateUtils.formatDate(new Date(), "yyyyMMddHHmmss"));
        // 订单到期时间
        weiXinPrePay.setTimeExpire(DateUtils.formatDate(DateUtils.addMinute(new Date(), 5), "yyyyMMddHHmmss"));
        // 通知地址
        weiXinPrePay.setNotifyUrl(notifyUrl);
        // 交易类型
        weiXinPrePay.setTradeType("NATIVE");
        // 商品ID
        weiXinPrePay.setProductId(productName);
        // 下单IP
        weiXinPrePay.setSpbillCreateIp(orderIp);

        return weiXinPrePay;
    }
}
