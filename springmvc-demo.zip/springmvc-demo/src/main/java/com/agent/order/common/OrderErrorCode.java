package com.agent.order.common;

public interface OrderErrorCode {

	
	/** 成功 */
	public static final Integer SUCCESS = 0;
	/**
	 * 系统内部错误
	 */
	public static final  Integer SYSTEM_INTRA_ERR = 500;
	/**
	 *  参数错误
	 */
	public static final  Integer PARAM_ERR = 101;
	
	/**
	 * ip限制
	 */
	public static final  Integer IP_LIMIT = 102;
	
	/**
	 * sign错误
	 */
	public static final  Integer SIGN_ERR = 103;	
	
	/** 未知错误 */
	public static final  Integer UNKOWN_ERR = 104;
	
	/** json错误 */
	public static final  Integer JSON_ERR = 108;
	/** bean copy错误 */
	public static final  Integer BEAN_COPY_ERROR = 109;
	
	
	/**
	 * 参数异常：无商品信息
	 */
	public static final Integer GOODS_INFO_IS_NULL=1300;
	
	/**
	 * 订单价格为0
	 */
	public static final Integer ORDER_PRICE_IS_ZERO=1301;
	
	/**
	 * 支付方式不能为空
	 */
	public static final Integer PAY_TYPE_IS_NULL=1302;
	
	/**
	 * 支付方式不支持
	 */
	public static final Integer PAY_TYPE_NONSUPPORT=1303;
	/**
	 * 第三方通知返回失败
	 */
	public static final Integer THIRD_NOTIFY_RETURN_FAIL=1304;
	
	/**
	 * 支付宝通知返回【 等待买家付款】
	 */
	public static final Integer ALIPAY_NOTIFY_WAIT_BUYER_PAY=1305;
	/**
	 * 重复通知
	 */
	public static final Integer PAY_NOTIFY_REPEATED=1306;
	/**
	 * 支付通知sign验证失败
	 */
	public static final Integer PAY_NOTIFY_SIGN_ERROR=1307;
	/**
	 * 支付同步通知处理错误
	 */
	public static final Integer PAY_RETURN_HANDLE_ERROR=1308;
	
	/**
	 * 支付异步通知处理错误
	 */
	public static final Integer PAY_NOTIFY_HANDLE_ERROR=1309;
	
	/**
	 * 支付异步通知状态错误
	 */
	public static final Integer PAY_NOTIFY_SYNC_STATS_ERROR=1310;
	
	/**
	 * 支付通知没找到交易号
	 */
	public static final Integer PAY_NOTIFY_TRANS_ID_NOT_FOUND=1311;
	
	/**
	 * 远程调用返回失败
	 */
	public static final Integer RPC_RETURN_ERROR=1312;

	/**
	 * 支付金额大于订单金额
	 */
	public static final Integer CHARGE_MONEY_GREATER_THAN_ORDER_MONEY=1313;
	/**
	 * 支付金额小于订单金额
	 */
	public static final Integer CHARGE_MONEY_LESS_THAN_ORDER_MONEY=1314;
	
	/**
	 * 手机号没有找到对应的UID
	 */
	public static final Integer PHONE_NOT_FOUND_UID=1315;
	
	/**
	 * UID不存在
	 */
	public static final Integer UID_NOT_EXIST=1316;
	
	/**
	 * 暂不支持非中兴视通170号码充值
	 */
	public static final Integer CHARGE_CASH_NOT_170_PHONE_NO=1317;

}
