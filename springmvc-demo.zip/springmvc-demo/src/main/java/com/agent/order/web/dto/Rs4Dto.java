package com.agent.order.web.dto;

public abstract class Rs4Dto<T> {

}
