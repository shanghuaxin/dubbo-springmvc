package com.agent.order.web.biz;

public interface CMCBankBiz {

	/**
	 * 查询CMC交易明细-并且处理
	 * 
	 * @param BBKNBR 分行号
	 * @param ACCNBR 账号
	 * @param BGNDAT 起始日期
	 * @param ENDDAT 结束日期 
	 * 
	 * @return
	 */
	public void procTransInfo(String BBKNBR, String ACCNBR, String BGNDAT, String ENDDAT);
	
	
	
	/**
	 * 查询CMC交易失败的记录-并且处理
	 * 
	 * @return
	 */
	public void procFailTransInfo();
}
