package com.agent.order.common.constant;

/**
 * 订单状态
 * @author kangy
 *
 */
public enum OrderStatusEnum {
	NON_PAYMENT("0", "未支付"), PAID("1", "已到账"), FAILURE("2", "支付失败"), DELETED("3", "已删除");
	private String value;
	private String name;
	
	private OrderStatusEnum(String value, String name) {
		this.value = value;
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
