package com.agent.order.web.biz;

import java.util.List;
import java.util.Map;

import com.agent.order.web.dto.OrderInfoDto;
import com.agent.order.web.dto.PayGoodsDto;
import com.agent.order.web.dto.Rs4OrderInfoDto;
import com.agent.order.web.dto.Rs4PayGoodsDto;

/**
 * 订单业务
 * @author kangy
 *
 */
public interface OrderInfoBiz {
	
	/**
	 * 得到用户的订单列表
	 * @param bid
	 * @param uid
	 * @return
	 */
	public List<Rs4PayGoodsDto> getPayGoodsList(PayGoodsDto payGoodsDto);	

	/**
	 * 新增普通订单
	 * @param orderInfoDto
	 * @return
	 */
	public Rs4OrderInfoDto addOrder(OrderInfoDto dto);
	
	
	/**
	 * 查询订单列表
	 * @param orderInfoDto
	 * @return
	 */
	/*public Map<String,Object> orderList(OrderInfoDto dto);*/

	/**
	 * 获取招行转账信息
	 * @return
	 */
	public Map<String,Object> getCmcBankInfo();
}
