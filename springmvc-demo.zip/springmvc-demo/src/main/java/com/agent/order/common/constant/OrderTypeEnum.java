package com.agent.order.common.constant;

/**
 * 业务类型
 * @author kangy
 *
 */
public enum OrderTypeEnum {
	CHARGE("00", "充值订单");
	private String id;
	private String name;
	
	private OrderTypeEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
}
