package com.agent.order.web.dto;

import java.math.BigDecimal;
import java.util.Map;

public class Rs4OrderInfoDto extends Rs4Dto<Rs4OrderInfoDto>{
	private String orderNo;//订单号
    private Integer orderMoney;//订单总金额(单位：分)
	private String notifyUrl;//传递给第三方支付（比如支付宝）的回调url
	private String memo;//支付说明
	private BigDecimal orderMoneyYuan;// 订单总金额(单位：元)
	
//	微信，增加返回值：wx_ret, json对象，属性如下：
//	{prepay_id, 微信生成的预支付回话标识，用于后续接口调用中使用，该值有效期为2小时
//	sign,微信返回的签名}
	private Map<String,Object> wx_ret;
	
	private String alipayInfo;

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getOrderMoney() {
		return orderMoney;
	}

	public void setOrderMoney(Integer orderMoney) {
		this.orderMoney = orderMoney;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public Map<String, Object> getWx_ret() {
		return wx_ret;
	}

	public void setWx_ret(Map<String, Object> wx_ret) {
		this.wx_ret = wx_ret;
	}

	public String getAlipayInfo() {
		return alipayInfo;
	}

	public void setAlipayInfo(String alipayInfo) {
		this.alipayInfo = alipayInfo;
	}

    public BigDecimal getOrderMoneyYuan() {
        orderMoneyYuan = new BigDecimal(orderMoney);
        return orderMoneyYuan.divide(new BigDecimal(100));
    }

    public void setOrderMoneyYuan(BigDecimal orderMoneyYuan) {
        this.orderMoneyYuan = orderMoneyYuan;
    }
}
