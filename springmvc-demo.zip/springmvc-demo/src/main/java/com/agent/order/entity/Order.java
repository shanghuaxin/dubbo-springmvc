package com.agent.order.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;

public class Order extends BaseDomain {
    
    private static final long serialVersionUID = 5594448867733121869L;
    private String orderNo;
    private Integer businessType;
    private BigDecimal money;
    // 状态0:待处理 1:处理完成 2:处理失败 3:取消
    private Integer status;
    // 是否需要扫描：0:否（默认） 1:是
    private Integer scanStatus;
    private String remark;
    // 失败原因
    private String reason;
    
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public Integer getBusinessType() {
        return businessType;
    }
    public void setBusinessType(Integer businessType) {
        this.businessType = businessType;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getScanStatus() {
        return scanStatus;
    }
    public void setScanStatus(Integer scanStatus) {
        this.scanStatus = scanStatus;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
}

