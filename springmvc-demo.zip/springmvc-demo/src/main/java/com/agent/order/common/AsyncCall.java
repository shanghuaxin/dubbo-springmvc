package com.agent.order.common;

import com.agent.order.exception.OrderException;
import com.agent.order.web.dto.PayNotifyDto;

public class AsyncCall {
	private AsyncCallContent acc;// 请求主体
	private PayNotifyDto param;

	public AsyncCall(AsyncCallContent acc,PayNotifyDto param) {
		this.acc = acc;
		this.param = param;
	}

	public void start() { // 开始请求
		final Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					acc.doSomeThing(param);// 响应请求
					acc.onSuccess();// 如果执行成功
				} catch (Exception e) {
					acc.onFailure(param,new OrderException("异步调用失败",e)); // 如果执行失败
				}
				
			}
		});
		t.start();
	}
}
