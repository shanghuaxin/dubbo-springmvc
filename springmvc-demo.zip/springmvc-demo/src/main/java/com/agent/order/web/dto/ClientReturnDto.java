package com.agent.order.web.dto;

public class ClientReturnDto {
	private String bid;
	private String orderNo;
	private String uid;
	private String payType;//支付方式,（alipay_mobile/wx_app/yeepay_card/yeepay_yjpay/apple_pay, 分别对应 支付宝/微信支付/易宝银行卡支付/易宝充值卡wap支付/苹果支付）
	Integer resultCode;//(1-已支付/0-撤销或支付失败/2-其他状态)
	
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	
	public Integer getResultCode() {
		return resultCode;
	}
	public void setResultCode(Integer resultCode) {
		this.resultCode = resultCode;
	}

	
	
}
