package com.agent.order.web.dto;

/**
 * 标签类 这个类用于在form表单中输出hidden标签的name和value 例如： &lt;input type="hidden" name=? value=? /&gt;
 * 
 * @author ZHANGYAN
 */
public class Tag {

    private String name;
    private String value;

    public Tag(String name, String value){
        super();
        this.name = name;
        this.value = value == null ? "" : value.trim();
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return new StringBuilder().append(name).append('=').append(value).toString();
    }

}
