package com.agent.order.mapper;

import com.agent.order.entity.PayResult;

public interface PayResultMapper{
	
	PayResult select(String transId);
	
	int insert(PayResult payResult);
	
	int update(PayResult payResult);
}