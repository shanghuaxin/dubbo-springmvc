package com.agent.order.web.biz;

import com.agent.order.entity.OrderFail;
import com.agent.order.web.dto.PayNotifyDto;

/**
 * 交易业务
 * @author kangy
 *
 */
public interface TransactionBiz {

	/**
	 * （支付宝、微信等）异步返回成功后处理
	 * @param payNotifyDto
	 */
	public void successProcess(PayNotifyDto payNotifyDto);
	
	
	/**
	 * 
	 * @param payNotifyDto
	 * @param errMsg 错误信息
	 * @param orderFailType 错误类型  01： 第三方通知失败 02 ： 通知成功业务处理失败（加钱、发货等）;
	 * @return
	 */
	public OrderFail getOrderFail(PayNotifyDto payNotifyDto,String errMsg,String orderFailType);
	
	/**
	 * 处理所有失败订单
	 */
	public void handleFailOrders();

}
