package com.agent.order.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.agent.common.BaseMapper;
import com.agent.order.entity.OrderDetail;

public interface OrderDetailMapper extends BaseMapper<OrderDetail,Integer>{

    List<OrderDetail> selectByOrderNo(String orderNo);
    
    /**
     * 计算未处理订单的划拨和充值账户的金额
     * @param param
     * @return
     */
    BigDecimal calcOrderMoney(Map<String, Object> param);
}