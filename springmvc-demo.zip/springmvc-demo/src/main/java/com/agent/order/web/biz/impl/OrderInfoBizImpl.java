package com.agent.order.web.biz.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.OrderTypeEnum;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.SequenceUtil;
import com.agent.order.common.util.third.alipay.AlipayConfig;
import com.agent.order.common.util.third.weixin.WeixinConfigUtil;
import com.agent.order.entity.OrderInfo;
import com.agent.order.entity.PayGoods;
import com.agent.order.entity.PayTracode;
import com.agent.order.exception.ArgumentException;
import com.agent.order.service.OrderInfoService;
import com.agent.order.service.PayGoodsService;
import com.agent.order.service.PayTracodeService;
import com.agent.order.web.biz.OrderInfoBiz;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.OrderInfoDto;
import com.agent.order.web.dto.PayGoodsDto;
import com.agent.order.web.dto.Rs4OrderInfoDto;
import com.agent.order.web.dto.Rs4PayGoodsDto;

@Component("orderInfoBiz")
public class OrderInfoBizImpl implements OrderInfoBiz {

    private static final Logger log = LoggerFactory.getLogger(OrderInfoBizImpl.class);
    
    @Resource
    OrderInfoService orderInfoService;
    @Resource
    PayGoodsService payGoodsService;
    @Resource
    PayTracodeService payTracodeService;
    @Autowired
    private ChannelsMapper channelsMapper;
    
    @Override
    public List<Rs4PayGoodsDto> getPayGoodsList(PayGoodsDto payGoodsDto){
        PayGoods payGoods = new PayGoods();
        payGoods.setGoodsType(payGoodsDto.getGoodsType());
        
        List<Rs4PayGoodsDto> dtoList = new ArrayList<Rs4PayGoodsDto>();
        //查出所有商品列表
        List<PayGoods> goodsList = payGoodsService.queryPayGoodsList(payGoods);
        Rs4PayGoodsDto dto = null;
        for(PayGoods goods: goodsList){
            dto = new Rs4PayGoodsDto();
            BeanUtils.copyProperties(goods, dto);
            dtoList.add(dto);
        }
        
        return dtoList;
    }
    

    @Override
    public Rs4OrderInfoDto addOrder(OrderInfoDto dto) {
        //验证支付方式
        String payType = dto.getPayType();
        if(StringUtils.isBlank(payType)){
            throw new ArgumentException(OrderErrorCode.PARAM_ERR, "支付方式不能为空");
        }else{
            if(!PayTypeEnum.ALIPAY_PC.getCode().equals(payType) && !PayTypeEnum.WX_PC.getCode().equals(payType)){
                throw new ArgumentException(OrderErrorCode.PARAM_ERR, "支付方式:"+ payType +", 暂不支持, 请使用微信和支付宝支付");
            }
        }
        //验证orderType
        String orderType = dto.getOrderType();
        if(StringUtils.isBlank(dto.getOrderType())){
            dto.setOrderType(OrderTypeEnum.CHARGE.getId());
        }else{
            if(!OrderTypeEnum.CHARGE.getId().equals(orderType)){
                throw new ArgumentException(OrderErrorCode.PARAM_ERR, "订单类型: "+ payType +", 非法, 暂时只支持充值订单");
            }
        }
        
        PayGoods payGoods = new PayGoods();
        dto.setGoodsId(0);
        dto.setGoodsNum(0);
        
        OrderInfo orderInfo = new OrderInfo();
        BeanUtils.copyProperties(dto, orderInfo);
        
        //生成订单号
        String orderNo = SequenceUtil.getOrderNo(dto.getChannelId()+"");
        orderInfo.setOrderNo(orderNo);
        
        //设置通知地址
        String notifyUrl= "";
        if (payType.equals(PayTypeEnum.ALIPAY_PC.getCode()) ) {
            notifyUrl = AlipayConfig.getValue(AlipayConfig.NOTIFY_URL);
        } else if (PayTypeEnum.WX_PC.getCode().equals(payType)) {
            notifyUrl = WeixinConfigUtil.readConfig("wx_pc.notify_url");
        }
        orderInfo.setNotifyUrl(notifyUrl);
        
        if(log.isDebugEnabled()){
            log.debug("下单检查通过, 下单信息={}", JSONUtil.objectToJson(orderInfo));
        }
        
        //下单
        Rs4OrderInfoDto rs4OrderInfoDto = orderInfoService.saveOrderInfo(orderInfo, payGoods);
        
        return rs4OrderInfoDto;
    }

    
    /**
     * 查询订单列表
     * @param orderInfoDto
     * @return
     */
    /*public Map<String,Object> orderList(OrderInfoDto dto){
        Map<String,Object> map= new HashMap<String,Object>();
        Long uid = null;
        try{
            uid = Users.id();
        }catch(Exception e){
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "对不起您的登录已超时，请重新登录！");
        }
        Channels ditch = channelsMapper.findByUserId(dto.getPayUid());
        if (null == ditch) {
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "对不起您的登录已超时，请重新登录！");
        }
        if(ditch !=null && "1".equals(ditch.getStatus())) {
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "帐号已被冻结，不能进行业务办理！");
        }
        Map<String,Object> searchParams= new HashMap<String,Object>();
        searchParams.put("TIMELIKE_create_time", dto.getQueryMonth());
        DataTable<DitchAccountDetailDTO> dt = new DataTable<DitchAccountDetailDTO>();
        dt.setiDisplayStart(0);
        dt.setiDisplayLength(10000);
        dt = rs.ListOfFecAccount(dt, searchParams, ditch);
        List<DitchAccountDetailDTO> dtos = dt.getAaData();
        List<Map<String,String>> listReturn = new ArrayList<Map<String,String>>();
        Map<String,String> temp = null;
        NumberFormat nf = NumberFormat.getInstance();
        String str = "";
        if(null != dtos && dtos.size()>0){
            for(DitchAccountDetailDTO a : dtos){
                temp = new HashMap<String,String>();
                temp.put("record", a.getAccountType());
                if(a.getOptionType().indexOf("_ADD")>-1){
                    str = "+";
                }else{
                    str = "-";
                }
                temp.put("money", str+nf.format(a.getMoney()).toString());
                temp.put("ctime", a.getCreateTimeStr());
                temp.put("balance", nf.format(a.getBalance()).toString());
                listReturn.add(temp);
            }
        }
        map.put("list", listReturn);
        return map;
    }*/
    
    /**
     * 获取招行转账信息
     * @return
     */
    public Map<String,Object> getCmcBankInfo(){
        Map<String,Object> map= new HashMap<String,Object>();
        Integer uid = null;
        try{
//            uid = Users.id();
        }catch(Exception e){
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "对不起您的登录已超时，请重新登录！");
        }
        Channels ditch = channelsMapper.findByUserId(uid);
        if (null == ditch) {
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "对不起您的登录已超时，请重新登录！");
        }
        if(ditch !=null && "1".equals(ditch.getStatus())) {
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "帐号已被冻结，不能进行业务办理！");
        }
        PayTracode payTracode = payTracodeService.queryPayTracode(uid);
        if(null == payTracode){
            throw new ArgumentException(OrderErrorCode.SYSTEM_INTRA_ERR, "对不起未获取到您的交易码，请联系管理员！");
        }
        map.put("bankName", PaymentCache.getValue("CMC_BANK_NAME"));
        map.put("accountName", PaymentCache.getValue("CMC_NAME"));
        map.put("accountNbr", PaymentCache.getValue("CMC_ACCNBR"));
        map.put("tracode", payTracode.getTracode());
        return map;
    }
}
