package com.agent.order.throttle.impl;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.agent.order.throttle.ActionThrottle;

public class ActionThrottleImpl implements ActionThrottle {

    private List<String> cache = new LinkedList<String>();
    private Lock         lock  = new ReentrantLock();

    @Override
    public boolean add(String keywords) {
        lock.lock();
        try {
            if (cache.contains(keywords)) {
                return false;
            } else {
                cache.add(keywords);
                return true;
            }
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void remove(String keywords) {
        lock.lock();
        try {
            cache.remove(keywords);
        } finally {
            lock.unlock();
        }
    }

}
