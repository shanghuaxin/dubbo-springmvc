package com.agent.order.web.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 第三方支付订单
 * 
 */
public class ThirdOrder {

    /** 银行支付接口的url地址 **/
    private String              url, sign;
    /** 提交表单的方法 get/post **/
    private String              method, charset;

    /** 提交到银行的参数和值，在web页面上用hidden标签来传递 **/
    private List<Tag>           tags;
    /** 这个属性目前仅手机支付宝用到 **/
    private Object              object;
    /** 商户ID **/
    private String              merId;
    
    private String transId;//交易号（传给第三方）
    /** 组装键值参数的map **/
    private Map<String, Object> paramMap;

    public ThirdOrder(){
        method = "get";
        tags = new ArrayList<Tag>();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public void put(String tagName, String tagValue) {
        tags.add(new Tag(tagName, tagValue));
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

//    public Paylog getPaylog() {
//        return paylog;
//    }
//
//    public void setPaylog(Paylog paylog) {
//        this.paylog = paylog;
//    }

    public String getMerId() {
        return merId;
    }

    public void setMerId(String merId) {
        this.merId = merId;
    }

    public void setParamMap(Map<String, Object> paramMap) {
        this.paramMap = paramMap;
    }

    public Map<String, Object> getParamMap() {
        return paramMap;
    }

    public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	@Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        buf.append("BankOrder [");
        buf.append("url=").append(url).append(',');
        buf.append("method=").append(method).append(',');
        buf.append("merId=").append(merId).append(',');
        buf.append("tags=").append(tags).append(']');
        return buf.toString();
    }

}
