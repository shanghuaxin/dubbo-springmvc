package com.agent.order.mapper;

import java.util.List;

import com.agent.order.entity.OrderFail;

public interface ExtendMapper {
	
	public List<OrderFail> getOrderFails4Job();
}
