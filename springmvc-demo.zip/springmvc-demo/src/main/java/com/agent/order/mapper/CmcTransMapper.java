package com.agent.order.mapper;

import java.util.List;

import com.agent.order.entity.CmcTrans;

public interface CmcTransMapper {

    CmcTrans selectByPrimaryKey(Long id);
    
    List<CmcTrans> selectFailTrans();
    
    List<String> selectRefnbrs(List<String> list);
    
    int insert(CmcTrans record);

    int update(CmcTrans record);
}