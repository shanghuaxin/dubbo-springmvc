package com.agent.order.web.biz.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.util.third.cmc.CmcHttpRequest;
import com.agent.order.common.util.third.cmc.XmlPacket;
import com.agent.order.entity.CmcTrans;
import com.agent.order.entity.OrderInfo;
import com.agent.order.exception.OrderException;
import com.agent.order.service.CMCBankService;
import com.agent.order.throttle.ActionThrottle;
import com.agent.order.throttle.impl.ActionThrottleImpl;
import com.agent.order.web.biz.CMCBankBiz;
import com.agent.order.web.cache.PaymentCache;

@Component("cMCBankBiz")
public class CMCBankBizImpl implements CMCBankBiz {

	private static final Logger log = LoggerFactory.getLogger(CMCBankBizImpl.class);
	private static final String CMC_PROC_JOB_RUNNING_FLAG = "proc-fail-trans";
	private static ActionThrottle actionThrottle = new ActionThrottleImpl();
	
	
	
	@Resource
	CMCBankService cMCBankService;
	@Resource
	CmcHttpRequest cmcHttpRequest;
	
	/**
	 * 查询CMC交易明细-并且处理
	 * 
	 * @param BBKNBR 分行号
	 * @param ACCNBR 账号
	 * @param BGNDAT 起始日期
	 * @param ENDDAT 结束日期 
	 * 
	 * @return
	 */
	public void procTransInfo(String BBKNBR, String ACCNBR, String BGNDAT, String ENDDAT){
		
		if(actionThrottle.add(ACCNBR)){
            try {
        		// 生成请求报文
        		String reqData = this.getRequestStr(BBKNBR, ACCNBR, BGNDAT, ENDDAT);
        		log.info("查询CMC交易明细,请求报文{}", reqData);
        		
        		String url = PaymentCache.getValue("CMC_TRANS_URL");
        		log.info("查询CMC交易明细,请求url{}", url);
        		
        		// 连接前置机，发送请求报文，获得返回报文
        		String result = cmcHttpRequest.sendRequest(url, reqData);
        		if(null != result){
        			if(!"".equals(result)){
	            		// 处理返回的结果
	            		this.processResult(result, Integer.parseInt(BBKNBR), ACCNBR);
        			}else{
        				log.warn("查询CMC交易明细, 没有反回数据, 请求报文{}, 请求url{}", reqData, url);
        			}
        		}else{
        			log.error("查询CMC交易明细出错, 没有反回数据, 请求报文{}, 请求url{}", reqData, url);
        			throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "查询CMC交易明细出错, 没有反回数据");
        		}
            }finally {
                actionThrottle.remove(ACCNBR);
            }
        } else {
        	throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "CMC取账户交易明细其它线程正在进行中,本次操作被取消, ACCNBR=" + ACCNBR);
        }
		
	}
	
	/**
	 * 生成请求报文
	 * 
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String getRequestStr(String BBKNBR, String ACCNBR, String BGNDAT, String ENDDAT) {
		// 构造查询账户明细的请求报文
		String loginName = PaymentCache.getValue("CMC_LGNNAM");
		XmlPacket xmlPkt = new XmlPacket("GetTransInfo", loginName);
		Map mpAccInfo = new Properties();
		mpAccInfo.put("BBKNBR", BBKNBR);
		mpAccInfo.put("ACCNBR", ACCNBR);
		mpAccInfo.put("BGNDAT", BGNDAT);
		mpAccInfo.put("ENDDAT", ENDDAT);
		xmlPkt.putProperty("SDKTSINFX", mpAccInfo);
		return xmlPkt.toXmlString();
	}
	
	/**
	 * 处理返回的结果
	 * 
	 * @param result
	 */
	@SuppressWarnings("rawtypes")
	private void processResult(String result, Integer BBKNBR, String ACCNBR) {
		if (result != null && result.length() > 0) {
			XmlPacket pktRsp = XmlPacket.valueOf(result);
			if (pktRsp != null) {
				if (pktRsp.isError()) {
					log.error("CMC取账户交易明细失败：" + pktRsp.getERRMSG());
					throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "CMC取账户交易明细失败：" + pktRsp.getERRMSG());
				} else {
					int size = pktRsp.getSectionSize("NTQTSINFZ");
					log.info("CMC取账户交易明细-查询结果明细数："+size);
					if(size <= 0){
						log.info("CMC取账户交易明细-查询结果明细数小于等于0, 无需处理, 直接反回");
						return;
					}
					Map propDtl = null;
					CmcTrans cmcTrans = null;
					List<String> refnbrs = new ArrayList<String>();
					List<CmcTrans> cmcTransList = new ArrayList<CmcTrans>();
					for(int i=0; i<size; i++){
						propDtl = pktRsp.getProperty("NTQTSINFZ", i);
						cmcTrans = new CmcTrans();
						cmcTrans.setBbknbr(BBKNBR);
						cmcTrans.setAccnbr(ACCNBR);
						cmcTrans.setRefnbr(propDtl.get("REFNBR")==null?"":propDtl.get("REFNBR").toString());
						cmcTrans.setReqnbr(propDtl.get("REQNBR")==null?null:Integer.parseInt(propDtl.get("REQNBR").toString()));
						cmcTrans.setFrmcod(propDtl.get("FRMCOD")==null?"":propDtl.get("FRMCOD").toString());
						cmcTrans.setTrsamt(new BigDecimal(propDtl.get("TRSAMT")==null?"0":propDtl.get("TRSAMT").toString()));
						cmcTrans.setTrsblv(new BigDecimal(propDtl.get("TRSBLV")==null?"0":propDtl.get("TRSBLV").toString()));
						cmcTrans.setEtydat(propDtl.get("ETYDAT")==null?"":propDtl.get("ETYDAT").toString());
						cmcTrans.setEtytim(propDtl.get("ETYTIM")==null?"":propDtl.get("ETYTIM").toString());
						cmcTrans.setRpynam(propDtl.get("RPYNAM")==null?"":propDtl.get("RPYNAM").toString());
						cmcTrans.setRpyacc(propDtl.get("RPYACC")==null?"":propDtl.get("RPYACC").toString());
						cmcTrans.setRpybbn(propDtl.get("RPYBBN")==null?"":propDtl.get("RPYBBN").toString());
						cmcTrans.setRpybnk(propDtl.get("RPYBNK")==null?"":propDtl.get("RPYBNK").toString());
						cmcTrans.setRpyadr(propDtl.get("RPYADR")==null?"":propDtl.get("RPYADR").toString());
						cmcTrans.setStatus("0");
						cmcTrans.setCnt(0);
						cmcTrans.setEmsg("");
						cmcTrans.setContent(propDtl.toString());
						
						refnbrs.add(cmcTrans.getRefnbr());
						cmcTransList.add(cmcTrans);
					}
					
					if(refnbrs.size()>0){
						List<String> existsRefnubs = cMCBankService.selectRefnbrs(refnbrs);
						if(existsRefnubs.size() == refnbrs.size()){
							log.info("本次扫描CMC账户交易明细新交易记录为0");
						}else{
							for(CmcTrans cmcTransTem : cmcTransList){
								if(!existsRefnubs.contains(cmcTransTem.getRefnbr())){
									try{
										//保存数据
										cMCBankService.saveCmcTransInfo(cmcTransTem);
										log.info("CMC账户交易明细新交易记录保存成功, 流水号:{}", cmcTrans.getRefnbr());
										//异步下单
										asyncCmcOrder(cmcTransTem);
									}catch(Exception e){
										log.error("CMC新增账户交易明细-流水号{}, 处理失败", cmcTransTem.getRefnbr(), e);
									}
								}
							}
						}
						
					}
				}
			} else {
				log.error("CMC取账户交易明细失败-响应报文解析失败");
				throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "CMC取账户交易明细失败-响应报文解析失败");
			}
		}
	}		
	
	
    //异步下单
    private void asyncCmcOrder(final CmcTrans cmcTrans){
		//异步处理 		
		new Thread(new Runnable() {
			public void run() {
				try {
					//调用业务方法
					OrderInfo orderInfo = cMCBankService.saveCmcOrderInfo(cmcTrans);
					log.info("CMC异步下单成功返回,流水号:{}, 订单号:{}", cmcTrans.getRefnbr(), orderInfo.getOrderNo());
				} catch (Exception e) {
					log.error("CMC异步下单处理失败, 流水号:" + cmcTrans.getRefnbr(),e);
					try{
						cmcTrans.setStatus("2");
						String msg = e.getMessage();
						if(msg.length() > 800){
							msg = msg.substring(0, 800);
						}
						cmcTrans.setEmsg(msg);
						cMCBankService.saveCmcTransLog(cmcTrans);
					}catch(Exception ex){
						log.error("CMC异步下单处理失败-保存失败日志又出错", ex);
					}
				}
				
			}
		}).start();
    }

	/**
	 * 查询CMC交易失败的记录-并且处理
	 * 
	 * @return
	 */
	public void procFailTransInfo(){
		
		if(actionThrottle.add(CMC_PROC_JOB_RUNNING_FLAG)){
            try {
        		List<CmcTrans> cmcTransList = cMCBankService.getFailTransList();
        		if(null == cmcTransList || cmcTransList.size() <=0){
        			log.info("查询CMC交易失败的记录并且处理job-查询记录数小于等于0, 无需处理直接反回");
					return;
        		}
        		for(CmcTrans cmcTrans : cmcTransList){	
    				try{
    					log.info("查询CMC交易失败的记录并且处理job, 流水号:{}, 开始处理", cmcTrans.getRefnbr());
    					//异步下单
    					asyncCmcOrder(cmcTrans);
    				}catch(Exception e){
    					log.error("查询CMC交易失败的记录并且处理job-流水号{}, 处理失败", cmcTrans.getRefnbr(), e);
    				}
        		}
            }finally {
                actionThrottle.remove(CMC_PROC_JOB_RUNNING_FLAG);
            }
        } else {
        	throw new OrderException(OrderErrorCode.SYSTEM_INTRA_ERR, "查询CMC交易失败的记录并且处理job, 其它线程正在进行中,本次操作被取消, CMC_PROC_JOB_RUNNING_FLAG=" + CMC_PROC_JOB_RUNNING_FLAG);
        }
	}
}
