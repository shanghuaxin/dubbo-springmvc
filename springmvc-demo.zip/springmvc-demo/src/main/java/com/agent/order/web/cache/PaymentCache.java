package com.agent.order.web.cache;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaymentCache {

	private static final Logger log = LoggerFactory.getLogger(PaymentCache.class);
	private static final Properties props = new Properties();
	private static final String DEFAULT_MAPPING_FILE = "payment.properties";
	
	static {
		InputStream in = null;
		try {
			in = PaymentCache.class.getClassLoader().getResourceAsStream(DEFAULT_MAPPING_FILE);
			props.load(new InputStreamReader(in, "UTF-8"));
		} catch (Exception e) {
			log.error("加载配置文件:payment.properties读取配置出错!", e);
			throw new RuntimeException("加载配置文件:payment.properties读取配置出错!",e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}


	/**
	 * 没品牌时用这个
	 * @param key
	 * @return
	 */
	public static String getValue(String key) {
		String value = props.getProperty(key);
		return StringUtils.isEmpty(value) ? null : value;
	}
	
	
	/**
	 * 优先用这个
	 * @param bid
	 * @param key
	 * @return
	 */
	public static String getValue(String bid,String key) {
		String value = props.getProperty(bid+"."+key);
		return StringUtils.isEmpty(value) ? getValue(key) : value;
	}
}
