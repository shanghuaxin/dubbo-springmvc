package com.agent.order.common.constant;

/**
 * 业务类型
 * @author kangy
 *
 */
public enum GoodsTypeEnum {
	CASH("cash", "充值");
	private String code;
	private String name;
	
	private GoodsTypeEnum(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}
	
}
