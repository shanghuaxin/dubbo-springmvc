package com.agent.order.submit2third;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.agent.order.exception.OrderException;
import com.agent.order.web.dto.Request;
import com.agent.order.web.dto.Result;
import com.agent.order.web.dto.Tag;
import com.agent.order.web.dto.ThirdOrder;

/**
 * 提交请求的接口
 */
public abstract class SubmitRequest {

    private static final Logger log = LoggerFactory.getLogger(SubmitRequest.class);

    /**
     * 组装请求
     * 
     * @param thirdOrder
     * @return
     */
    Request makeRequest(ThirdOrder thirdOrder) {
        Request request = new Request();
        request.setThirdOrder(thirdOrder);
        request.setContent(getKeyValueContent(thirdOrder));
        return request;
    }

    /**
     * 提交请求
     * 
     * @param request
     * @return
     */
    abstract Result submit(Request request) throws Exception;

    /**
     * 根据请求响应结果，获取用户需要的响应结果
     * 
     * @param result
     * @return
     */
    abstract void handleResponseResult(Result result, ThirdOrder thirdOrder);

    /**
     * 设置远程支付系统的支付结果码
     * 
     * @return
     */
    abstract void setPayResultCode(Result result);
    
    /**
     * 获取反回支付信息
     * 
     * @return
     */
    public abstract Map<String, Object> getPayTransInfo(Result result);    

    /**
     * 发送请求，并获取返回结果
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public Result submitAndGetResult(ThirdOrder thirdOrder) throws OrderException {
        if (StringUtils.isEmpty(thirdOrder.getUrl())) {
            throw new OrderException("The given url is empty.");
        }
        Result result = new Result();
        Request request = null;
        try {
            request = makeRequest(thirdOrder);
            result = submit(request);
            handleResponseResult(result, thirdOrder);
            result.setStatus(Result.SUCCESS);
            /** 解析银行的返回 **/
            boolean submitStatus = this.isSubmitSuccess(result.getResponse());
            if (!submitStatus) {
                log.error("提交到第三方支付返回失败！,交易号：{}", thirdOrder.getTransId());
            }
            result.setPayResult(submitStatus);
            setPayResultCode(result);
        } catch (Exception e) {
            String errmsg = "Http request exception happended, request url is:" + thirdOrder.getUrl();
            log.error(errmsg, e);
            throw new OrderException("微信统一下单失败", e);
            //result.setErrmsg(errmsg);
            //result.setStatus(Result.FAIL);
        }
        return result;
    }

    /**
     * 将请求内容拼装成Key-Value的键值串返回
     * 
     * @param bankOrder
     * @return Key-Value的键值串返回
     */
    String getKeyValueContent(ThirdOrder thirdOrder) {
        StringBuilder content = new StringBuilder();
        for (Tag tag : thirdOrder.getTags()) {
            /**
             * Key和Value都不为空的时候才拼上
             */
            if (!StringUtils.isEmpty(tag.getName()) && !StringUtils.isEmpty(tag.getValue())) {
                content.append(tag.getName()).append('=').append(tag.getValue()).append("&");
            }
        }
        if (content.length() > 0) {
            return content.substring(0, content.length() - 1);
        }
        return "";
    }
    
    abstract boolean isSubmitSuccess(String rsp); 

}
