package com.agent.order.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.agent.order.entity.PayGoods;
import com.agent.order.mapper.PayGoodsMapper;

@Service
public class PayGoodsService{
	
	@Resource
	PayGoodsMapper payGoodsMapper;

	/**
	 * 查询商品
	 * 
	 * @param goodsId
	 * 
	 * @return
	 */
	public PayGoods queryPayGoods(Integer goodsId){
		return payGoodsMapper.select(goodsId);
	}
	
	
	/**
	 * 查询商品列表
	 * 
	 * @param payGoods
	 * 
	 * @return
	 */
	public List<PayGoods> queryPayGoodsList(PayGoods payGoods){
		return payGoodsMapper.selectBuyGoods(payGoods.getGoodsType());
	}
	
}
