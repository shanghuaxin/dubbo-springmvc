package com.agent.order.common.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

/**
 * ip工具类
 * @author kangy
 *
 */
public class IpUtil {
	public static String getIp(HttpServletRequest request) {
        String forwaredFor = request.getHeader("X-Forwarded-For");
        String remoteAddr = request.getRemoteAddr();
        if (StringUtils.isNotEmpty(forwaredFor)) {
            String[] ipArray = forwaredFor.split(",");
            return ipArray[0];
        } else
            return remoteAddr;
    }

}
