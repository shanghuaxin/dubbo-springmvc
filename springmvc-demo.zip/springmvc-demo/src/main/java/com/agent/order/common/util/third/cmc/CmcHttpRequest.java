package com.agent.order.common.util.third.cmc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * HTTP通讯范例: 直接支付
 * 
 * @author 徐蓓
 */
@Component
public class CmcHttpRequest {

	private static final Logger log = LoggerFactory.getLogger(CmcHttpRequest.class);

	/**
	 * 连接前置机，发送请求报文，获得返回报文
	 * 
	 * @param data
	 * @return
	 * @throws MalformedURLException
	 */
	public String sendRequest(String urlStr, String data) {
		StringBuffer sb = new StringBuffer();
		try {
			URL url = new URL(urlStr);

			HttpURLConnection conn;
			conn = (HttpURLConnection) url.openConnection();
			conn.setReadTimeout(60 * 1000);
            conn.setConnectTimeout(50 * 1000);

			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			conn.setDoOutput(true);
			OutputStream os;
			os = conn.getOutputStream();
			os.write(data.toString().getBytes("gbk"));
			os.close();

			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "GBK"));
			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
			br.close();
		} catch (MalformedURLException e) {
			log.error("连接前置机error1:", e);
			return null;
		} catch (UnsupportedEncodingException e) {
			log.error("连接前置机error2:", e);
			return null;
		} catch (ProtocolException e) {
			log.error("连接前置机error3:", e);
			return null;
		} catch (IOException e) {
			log.error("连接前置机error4:", e);
			return null;
		}
		return sb.toString();
	}

}