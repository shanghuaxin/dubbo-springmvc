package com.agent.order.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;


public class DateUtil {
	/**
	 * 格式：yyyy-MM-dd HH:mm:ss
	 */
	public static final String FMT_TYPE1 = "yyyy-MM-dd HH:mm:ss";
	/**
	 * 格式：yyyy-MM-dd
	 */
	public static final String FMT_TYPE2 = "yyyy-MM-dd";
	/**
	 * 格式：HH:mm:ss
	 */
	public static final String FMT_TYPE3 = "HH:mm:ss";
	/**
	 * 格式：yyyyMMddHHmmss
	 */
	public static final String FMT_TYPE4 = "yyyyMMddHHmmss";
	/**
	 * 格式：yyyyMMdd
	 */
	public static final String FMT_TYPE5 = "yyyyMMdd";
	/**
	 * 格式：HHmmss
	 */
	public static final String FMT_TYPE6 = "HHmmss";
	/**
	 * 格式：HHmmssSSS
	 */
	public static final String FMT_TYPE7 = "HHmmssSSS";
	/**
	 * 格式：yyyyMMddHHmmssSSS
	 */
	public static final String FMT_TYPE8 = "yyyyMMddHHmmssSSS";
	
	
	
	
	/**
     * 变量：日期格式化类型 - 格式:yyyy/MM/dd
     */
	public static final int DEFAULT = 0;
	public static final int YM = 1;

    /**
     * 变量：日期格式化类型 - 格式:yyyy-MM-dd
     * 
     */
    public static final int YMR_SLASH = 11;

    /**
     * 变量：日期格式化类型 - 格式:yyyyMMdd
     * 
     */
    public static final int NO_SLASH = 2;

    /**
     * 变量：日期格式化类型 - 格式:yyyyMM
     * 
     */
    public static final int YM_NO_SLASH = 3;

    /**
     * 变量：日期格式化类型 - 格式:yyyy/MM/dd HH:mm:ss
     * 
     */
    public static final int DATE_TIME = 4;

    /**
     * 变量：日期格式化类型 - 格式:yyyyMMddHHmmss
     * 
     */
    public static final int DATE_TIME_NO_SLASH = 5;

    /**
     * 变量：日期格式化类型 - 格式:yyyy/MM/dd HH:mm
     * 
     */
    public static final int DATE_HM = 6;

    /**
     * 变量：日期格式化类型 - 格式:HH:mm:ss
     * 
     */
    public static final int TIME = 7;

    /**
     * 变量：日期格式化类型 - 格式:HH:mm
     * 
     */
    public static final int HM = 8;
    
    /**
     * 变量：日期格式化类型 - 格式:HHmmss
     * 
     */
    public static final int LONG_TIME = 9;
    /**
     * 变量：日期格式化类型 - 格式:HHmm
     * 
     */
    
    public static final int SHORT_TIME = 10;

    /**
     * 变量：日期格式化类型 - 格式:yyyy-MM-dd HH:mm:ss
     */
    public static final int DATE_TIME_LINE = 12;
	public static String dateToStr(Date date, int type) {
        switch (type) {
        case DEFAULT:
            return dateToStr(date);
        case YM:
            return dateToStr(date, "yyyy/MM");
        case NO_SLASH:
            return dateToStr(date, "yyyyMMdd");
        case YMR_SLASH:
        	return dateToStr(date, "yyyy-MM-dd");
        case YM_NO_SLASH:
            return dateToStr(date, "yyyyMM");
        case DATE_TIME:
            return dateToStr(date, "yyyy/MM/dd HH:mm:ss");
        case DATE_TIME_NO_SLASH:
            return dateToStr(date, "yyyyMMddHHmmss");
        case DATE_HM:
            return dateToStr(date, "yyyy/MM/dd HH:mm");
        case TIME:
            return dateToStr(date, "HH:mm:ss");
        case HM:
            return dateToStr(date, "HH:mm");
        case LONG_TIME:
            return dateToStr(date, "HHmmss");
        case SHORT_TIME:
            return dateToStr(date, "HHmm");
        case DATE_TIME_LINE:
            return dateToStr(date, "yyyy-MM-dd HH:mm:ss");
        default:
            throw new IllegalArgumentException("Type undefined : " + type);
        }
    }
	public static String dateToStr(Date date,String pattern) {
	       if (date == null)
	    	 return null;
	       SimpleDateFormat formatter = new SimpleDateFormat(pattern);
	       return formatter.format(date);
    } 

    public static String dateToStr(Date date) {
        return dateToStr(date, "yyyy/MM/dd");
    }
    
    

	
	/**
	 * 返回指定格式化的日期<br>
	 * 如果 date为null，返回当前时间<br>
	 * 如果 fmt为null，返回 yyyy-MM-dd HH:mm:ss格式时间<br>
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午06:11:18 
	 * @param date 时间
	 * @param fmt 格式化
	 * @return 指定格式化的日期
	 */
	public static String getDateByFmt(Date date,String fmt){
		if (StringUtils.isBlank(fmt)) {
			fmt = FMT_TYPE1;
		}
		SimpleDateFormat format = new SimpleDateFormat(fmt);
		if (date == null) {
			return format.format(new Date());
		}
		return format.format(date);
	}
	
	/**
	 * 获取 yyyyMMddHHmmss 格式时间<br>
	 * 如果date为null，返回当前时间
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午05:56:57 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static String getNowyyyyMMddHHmmss(Date date){
		SimpleDateFormat fmt = new SimpleDateFormat(FMT_TYPE4);
		if (date == null) {
			return fmt.format(new Date());
		}
		return fmt.format(date);
	}
	
	/**
	 * 获取 yyyyMMdd 格式时间<br>
	 * 如果date为null，返回当前时间
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午05:57:25 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static String getNowyyyyMMdd(Date date){
		SimpleDateFormat fmt = new SimpleDateFormat(FMT_TYPE5);
		if (date == null) {
			return fmt.format(new Date());
		}
		return fmt.format(date);
	}
	
	/**
	 * 获取 HHmmss 格式时间 <br>
	 * 如果date为null，返回当前时间
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午05:59:21 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static String getNowHHmmss(Date date){
		SimpleDateFormat fmt = new SimpleDateFormat(FMT_TYPE6);
		if (date == null) {
			return fmt.format(new Date());
		}
		return fmt.format(date);
	}
	
	/**
	 * 获取 HHmmssSSS 格式时间<br>
	 * 如果date为null，返回当前时间
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午05:59:25 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static String getNowHHmmssSSS(Date date){
		SimpleDateFormat fmt = new SimpleDateFormat(FMT_TYPE7);
		if (date == null) {
			return fmt.format(new Date());
		}
		return fmt.format(date);
	}
	
	/**
	 * 获取 yyyyMMddHHmmssSSS 格式时间<br>
	 * 如果date为null，返回当前时间
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午05:59:33 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static String getNowyyyyMMddHHmmssSSS(Date date){
		SimpleDateFormat fmt = new SimpleDateFormat(FMT_TYPE8);
		if (date == null) {
			return fmt.format(new Date());
		}
		return fmt.format(date);
	}

	/**
	 * 获取 yyyy-MM-dd HH:mm:ss 格式时间<br>
	 * 如果date为null，返回当前时间
	 * @author Jerry
	 * @version v1.0 2013-9-25 下午05:59:36 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static String getSimpleDate(Date date){
		SimpleDateFormat fmt = new SimpleDateFormat(FMT_TYPE1);
		if (date == null) {
			return fmt.format(new Date());
		}
		return fmt.format(date);
	}
	/**
	 * 获取 yyyy-MM-dd HH:mm:ss 格式时间<br>
	 * 如果date为null，返回当前时间
	 * @author Jamin
	 * @version v1.0 2013-10-11 下午05:59:36 
	 * @param date 时间
	 * @return 格式化后的时间字符串
	 */
	public static Date getStartTime() {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		return c.getTime();
	}
	
	/**
	 * 获取当前时间  N天前后   的日期</br>
	 * 如：-1=当前日期  一天前  的日期，1=当前日期  一天后  的日期
	 * @author Jerry
	 * @version v1.0 2013-10-14 下午02:47:39 
	 * @param day 天数
	 * @param fmt_type 格式化类型
	 * @return 格式化后的日期
	 */
	public static String getDayBeforeDate(int day,String fmt_type){
		Calendar rightNow = Calendar.getInstance();
		rightNow.add(Calendar.DAY_OF_MONTH, day);
		return getDateByFmt(rightNow.getTime(), fmt_type);
	}
	
	/**
	 * 获取当前时间  N个月前后  日期，n可为正负整数</br>
	 * 如：-1=当前日期  一月前  的日期，1=当前日期  一月后  的日期
	 * @author Jerry
	 * @version v1.0 2013-10-14 下午02:44:03 
	 * @param month 月数
	 * @param fmt_type 格式化类型
	 * @return 按照参数 fmt_type 格式化后的日期
	 */
	public static String getMonthBeforeDate(int month,String fmt_type){
		Calendar rightNow = Calendar.getInstance();
		rightNow.add(Calendar.MONTH, month);
		return getDateByFmt(rightNow.getTime(), fmt_type);
	}
	
	/**
	 * 获取几个小时之后的小时
	 * @param date
	 * @param hour
	 * @return
	 */
	public static Integer getHourAfterHour(Date date,int hour){
		if(date ==null){
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR_OF_DAY, hour);
		return cal.get(Calendar.HOUR_OF_DAY);
	}
	
	/**
	 * 获取几个小时之后的日期
	 * @param date
	 * @param hour
	 * @return
	 */
	public static Date getDateAfterHour(Date date,int hour){
		if(date ==null){
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR_OF_DAY, hour);
		return cal.getTime();
	}
	
	/**
	 * 获取指定日期n天前（后）的日期
	 * @param date
	 * @param day
	 * @return
	 */
	public static Date getDateAfterDay(Date date,int day){
		if(date ==null){
			date = new Date();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, day);
		return cal.getTime();
	}

	/**
	 * 获取指定日期n天前（后）的日期
	 * @param date
	 * @param day
	 * @return
	 */
	public static Date getDateAfterMonth(Date date,int month){
		if(date ==null){
			date = new Date();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, month);
		return cal.getTime();
	}
	
	
	/**
	 * 将字符串的转换成date类型</br>
	 * @param date 日期
	 * @param fmt_type 格式化类型
	 * @return 按照参数 fmt_type 格式化后的日期
	 * @throws ParseException 
	 */
	public static Date parse(String date,String fmt_type ) throws ParseException{
		SimpleDateFormat fmt = new SimpleDateFormat(fmt_type);
			if (date != null) {
				return fmt.parse(date);
			}
			return null;
	}


    /*** 
         * 两个日期相差多少秒 
         *  
         * @param date1 
         * @param date2 
         * @return 
         */  
        public static int getTimeDelta(Date date1,Date date2){  
            long timeDelta=(date1.getTime()-date2.getTime())/1000;//单位是秒  
            int secondsDelta=timeDelta>0?(int)timeDelta:(int)Math.abs(timeDelta);  
            return secondsDelta;  
        }  
          
        /*** 
         * 两个日期相差多少秒 
         * @param dateStr1  :yyyy-MM-dd HH:mm:ss 
         * @param dateStr2 :yyyy-MM-dd HH:mm:ss 
     
         */  
        public static int getTimeDelta(String dateStr1,String dateStr2){  
            Date date1=parseDateByPattern(dateStr1, FMT_TYPE1);  
            Date date2=parseDateByPattern(dateStr2, FMT_TYPE1);  
            return getTimeDelta(date1, date2);  
        }  
          
        public static Date parseDateByPattern(String dateStr,String dateFormat){  
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);  
            try {  
                return sdf.parse(dateStr);  
            } catch (ParseException e) {  
                e.printStackTrace();  
            }  
            return null;  
        } 
        
        /**	
         * 获取当前到当天 23:59：59的秒数
         * @return 秒
         */
        public static int getTodatRemainingTime(){
        	String nowStr =DateUtil.getDateByFmt(new Date(),null);
        	String now_yyyyMMdd = DateUtil.getDateByFmt(new Date(),DateUtil.FMT_TYPE2);
        	String endStr= now_yyyyMMdd+" 23:59:59";
        	return DateUtil.getTimeDelta(nowStr,endStr);
        }
	
	public static void main(String[] args) {
		Date day =  DateUtil.getDateAfterDay(new Date(),3);
		
		System.out.println(DateUtil.getNowyyyyMMddHHmmss(day));
		
		Date day1 =  DateUtil.getDateAfterMonth(new Date(),1);
		
		System.out.println(DateUtil.getNowyyyyMMddHHmmss(day1));
		
	}
}
