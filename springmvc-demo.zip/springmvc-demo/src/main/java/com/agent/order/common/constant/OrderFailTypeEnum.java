package com.agent.order.common.constant;

/**
 * 业务类型
 * @author kangy
 *
 */
public enum OrderFailTypeEnum {
	THIRD_NOTIFY_FAIL("01", "第三方通知失败"), BIZ_PROCESS_FAIL("02", "通知成功业务处理失败（加钱、发货等）");
	private String id;
	private String name;
	
	private OrderFailTypeEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
}
