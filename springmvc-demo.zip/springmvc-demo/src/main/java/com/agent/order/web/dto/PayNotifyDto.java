package com.agent.order.web.dto;

import java.util.Date;

import com.agent.order.common.constant.PayResultEnum;

public class PayNotifyDto {

    private String transId;//交易号（支付时提交第三方）
    private String outTransId;//外部交易号（支付宝等）
    private String payType;//支付方式
    private Integer orderMoney;//订单总金额
    private Integer chargeMoney;//支付金额
    private String orderNo;//订单号
    private String tradeStatus;//交易状态
    private Date notifyTime;//通知时间
    private boolean isThirdPaySuccess;//是否第三方支付成功
    
    private String receipt;//苹果支付收据号
    private String returnData;//第三方返回
    
    private String payResult=PayResultEnum.fail.name();// 默认失败 "success","fail","deduct_fail"

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getOutTransId() {
		return outTransId;
	}

	public void setOutTransId(String outTransId) {
		this.outTransId = outTransId;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public Integer getOrderMoney() {
		return orderMoney;
	}

	public void setOrderMoney(Integer orderMoney) {
		this.orderMoney = orderMoney;
	}

	public Integer getChargeMoney() {
		return chargeMoney;
	}

	public void setChargeMoney(Integer chargeMoney) {
		this.chargeMoney = chargeMoney;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}


	public String getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public Date getNotifyTime() {
		return notifyTime;
	}

	public void setNotifyTime(Date notifyTime) {
		this.notifyTime = notifyTime;
	}

	public String getPayResult() {
		return payResult;
	}

	public void setPayResult(String payResult) {
		this.payResult = payResult;
	}

	public boolean isThirdPaySuccess() {
		return isThirdPaySuccess;
	}

	public void setThirdPaySuccess(boolean isThirdPaySuccess) {
		if(isThirdPaySuccess){
			payResult=PayResultEnum.success.name();
		}else{
			payResult=PayResultEnum.fail.name();
		}
		
		this.isThirdPaySuccess = isThirdPaySuccess;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getReturnData() {
		return returnData;
	}

	public void setReturnData(String returnData) {
		this.returnData = returnData;
	}
 
}
