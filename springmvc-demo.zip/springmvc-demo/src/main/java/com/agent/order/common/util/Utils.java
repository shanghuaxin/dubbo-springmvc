package com.agent.order.common.util;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.ServletRequest;

import org.springframework.data.domain.Sort;

import com.agent.order.common.DataTable;
import com.agent.order.common.util.third.weixin.DateUtils;
import com.agent.util.Encodes;
import com.agent.util.Setting;

import sun.misc.BASE64Decoder;
/**
 * @author auto
 */
@SuppressWarnings("restriction")
public class Utils{
    /**
     * 判断一个字符串是否为空
     *
     * @param str
     *
     * @return
     */
    public static boolean isEmptyStr(String str){
        if(str==null){
            return true;
        }
        str=str.trim();
        return str.isEmpty();
    }
    
    @SuppressWarnings("rawtypes")
    public static Sort getSort(DataTable dt,ServletRequest request){
        Sort sort=null;
        String iSortCol_0=dt.getiSortCol_0();
        String sSortDir_0=dt.getsSortDir_0();
        String isSort_="bSortable_"+iSortCol_0;
        String orderParamter="mDataProp_"+iSortCol_0;
        boolean isSort=Boolean.parseBoolean(request.getParameter(isSort_));
        String orderName=null;
        if(isSort==true){
            orderName=request.getParameter(orderParamter);
            if(orderName!=null&&!orderName.equals("")&&sSortDir_0!=null){
                if(sSortDir_0.equalsIgnoreCase("asc")){
                    sort=new Sort(Sort.Direction.ASC,new String[]{orderName});
                }else if(sSortDir_0.equalsIgnoreCase("desc")){
                    sort=new Sort(Sort.Direction.DESC,new String[]{orderName});
                }
                return sort;
            }
        }
        return null;
    }
    
    /**
     * 对集合去重 （无顺序）
     *
     * @param arlList 带去重的集合
     *
     * @return 返回去重后的集合
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static List removeDuplicate(List arlList){
        if(Utils.isEmpityCollection(arlList)){
            return new ArrayList();
        }
        HashSet h=new HashSet(arlList);
        arlList.clear();
        arlList.addAll(h);
        return arlList;
    }
    
    /**
     * 判断对象是否为空
     *
     * @param obj
     *
     * @return
     */
    public static boolean isNotNull(Object obj){
        if(obj!=null){
            return true;
        }
        return false;
    }
    
    /**
     * 判断集合是否为空
     *
     * @param c 待判断的集合
     *
     * @return集合为空,返回true ,反之 false
     */
    @SuppressWarnings("rawtypes")
    public static boolean isEmpityCollection(Collection c){
        if(c==null||c.isEmpty()){
            return true;
        }else{
            return false;
        }
    }
    
    public static boolean isEmptyStr(Object s){
        return (s==null)||(s.toString().trim().length()==0);
    }
    
    /**
     * 判断传入参数是否为空,空字符串""或"null"或"<null> 为了兼容ios的空获取到<null>字符串
     *
     * @param s 待判断参数
     *
     * @return true 空 <br>
     * false 非空
     */
    public static boolean isEmptyString(Object s){
        return (s==null)||(s.toString().trim().length()==0)||s.toString().trim().equalsIgnoreCase("null")||s.toString().trim().equalsIgnoreCase("<null>");
    }
    /**
     * 对传入参数进行判断是否为空,为空则返回"",反之返回传入参数
     *
     * @param v 传入参数
     *
     * @return 处理后的参数
     */
    public static String filterNullValue(String v){
        return isEmptyString(v)?"":v;
    }
    /**
     * 设定安全的密码，生成随机的salt并经过1024次 sha-1 hash
     * 当用户提供明文密码是
     *
     * @param password 用户输入密码
     */
    public static Map<String,String> entryptPassword(String password){
        Map<String,String> map=new HashMap<>();
        password=Utils.isEmptyString(password)?Setting.PASSWORD:password;
        byte[] salt=Digests.generateSalt(Setting.SALT_SIZE);
        byte[] hashPassword=Digests.sha1(password.getBytes(),salt,Setting.HASH_INTERATIONS);
        password=Encodes.encodeHex(hashPassword);
        map.put("password",password);
        map.put("enCodeSalt",Encodes.encodeHex(salt));
        return map;
    }


    /**
     * 将base64编码的字符串转换成图片保存到相应的路径
     *
     * @param imageInf 图片 字符串
     * @param path     保存的路径
     *
     * @return 是否保存成功状态
     *
     * @throws IOException IO读写错误
     */
    public static boolean saveFileToDisk(String imageInf,String path){//对字节数组字符串进行Base64解码并生成图片
        try{
            if(imageInf==null){
                //图像数据为空
                return false;
            }
            BASE64Decoder decoder=new BASE64Decoder();
            //Base64解码
            byte[] b=decoder.decodeBuffer(imageInf);
            for(int i=0;i<b.length;++i){
                if(b[i]<0){//调整异常数据
                    b[i]+=256;
                }
            }
            //生成jpeg图片
            OutputStream out=new FileOutputStream(path);
            out.write(b);
            out.flush();
            out.close();
            return true;
        }catch(IOException e){
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 逗号隔开字符串转换list
     * @param listStr
     * @return
     * @throws Exception
     */
    public static List<String> listStr(String listStr) throws Exception{
        List<String> list = new ArrayList<String>();
        String[] st = listStr.split(",");
        for(int i=0;i<st.length;i++){
            if(!Utils.isEmptyString(st[i])){
                list.add(st[i]);
            }
        }
        return list;
    }
    
    /**
     * 逗号隔开字符串转换list
     * @param listStr
     * @return
     * @throws Exception
     */
    public static List<Integer> listStrByint(String listStr) throws Exception{
        List<Integer> list = new ArrayList<Integer>();
        String[] st = listStr.split(",");
        for(int i=0;i<st.length;i++){
            if(!Utils.isEmptyString(st[i])){
                list.add(Integer.parseInt(st[i]));
            }
        }
        return list;
    }
    
    /**
     * 生成订单号
     * 规则:"F201704171712293380546579"
     * 20170417171229338：年月日时分秒毫秒   0546579：随机7位数
     * @param prefix 前缀
     * @return
     */
    public static String getOrderNo(String prefix) {
        String time = DateUtils.formatDate(new Date(), DateUtil.FMT_TYPE8);
        String randomStr = Utils.getRandomString(7);
        return prefix + time + randomStr;
    }
    
    /**
     * 获取随机数
     * @param length 随机数的长度
     * @return
     */
    public static String getRandomString(int length) {
        String base = "0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
}
