package com.agent.order.web.spi.admin;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.SysConstant;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.exception.OrderException;
import com.agent.order.web.biz.TransactionBiz;
import com.agent.order.web.dto.ResultDto;

/**
 * 管理员维护接口
 * @author kangy
 * 20151015
 */
@RestController
@RequestMapping("/admin")
public class AdminResource {
	Logger log = LoggerFactory.getLogger(AdminResource.class);
	
	@Resource
	TransactionBiz transactionBiz;
	
	
	/**
	 * 补单接口
	 * @param orderNo
	 * @return
	 */
	@RequestMapping(value = "/manualHandle/{orderNo}",method = RequestMethod.GET, produces=SysConstant.APPLICATION_JSON_UTF8)
	public ResultDto manualHandle(@PathVariable String orderNo){
		
		ResultDto result = new ResultDto(OrderErrorCode.SUCCESS,"成功");
		try {
			/*OrderFail orderFail = orderFailService.select(orderNo);
			PayNotifyDto payNotifyDto = transactionBiz.getPayNotifyDto(orderFail);
			transactionBiz.successProcess(payNotifyDto);
			//更新状态为已处理
			orderFail.setHandleStatus(OrderFailHandleStatusEnum.ALREADY_HANDLE.getId());//已处理
			orderFailService.updateByPrimaryKeySelective(orderFail);*/
		} catch (OrderException e) {
			result.setCode(e.getCode());
			result.setMsg(e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			result.setCode(OrderErrorCode.UNKOWN_ERR);
			result.setMsg("未知错误");
			e.printStackTrace();
		}
		log.info("补单结束，返回：{}",JSONUtil.objectToJson(result));
		return result;
	}
	

	
}
