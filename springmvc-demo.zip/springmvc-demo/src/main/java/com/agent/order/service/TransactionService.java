package com.agent.order.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.api.InterfaceUtil;
import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.channel.service.ChannelsService;
import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.OrderFailHandleStatusEnum;
import com.agent.order.common.constant.OrderStatusEnum;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.constant.TransStatusEnum;
import com.agent.order.common.util.DateUtil;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.Utils;
import com.agent.order.entity.OrderFail;
import com.agent.order.entity.OrderInfo;
import com.agent.order.entity.PayResult;
import com.agent.order.exception.OrderException;
import com.agent.order.mapper.OrderFailMapper;
import com.agent.order.mapper.OrderInfoMapper;
import com.agent.order.mapper.PayResultMapper;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.PayNotifyDto;
import com.agent.system.dto.SmsResponseDTO;
import com.agent.util.SysConfig;

@Service
public class TransactionService{
	
	private static final Logger log = LoggerFactory.getLogger(TransactionService.class);
	
	@Resource
	OrderInfoMapper orderInfoMapper;
	@Resource
	PayResultMapper payResultMapper;
	@Resource
	OrderFailMapper orderFailMapper;
//	@Resource
//    FecDitchService fecDitchService;
	@Resource
	ChannelsMapper channelsMapper;
	@Resource
	ChannelsService channelsService;
	
	/**
	 * 支付成功结果处理
	 * 
	 * @param payNotifyDto
	 * 
	 * @return
	 */
	@Transactional(readOnly = false,rollbackFor = Exception.class)
	public void saveOrderPayResult(PayNotifyDto payNotifyDto){
		
		String orderNo = payNotifyDto.getOrderNo();
		
		Date now = new Date();

		OrderInfo orderInfo = orderInfoMapper.select(orderNo); //订单
		
		// 1、如果订单已完成, 则不进行后续处理
		if (OrderStatusEnum.PAID.getValue().equals(orderInfo.getStatus())) {
			log.warn("重复充值操作!订单号:{}", orderNo);
			throw new OrderException(OrderErrorCode.PAY_NOTIFY_REPEATED,"重复通知");
		}
		
		//校验支付金额和订单金额
		int chargeMoney = payNotifyDto.getChargeMoney();//支付金额
		int orderMoney = orderInfo.getOrderMoney();
		if(chargeMoney>orderMoney){
			log.warn("支付金额大于订单金额!订单号:{}", orderNo);
		}else if(chargeMoney<orderMoney){
			log.warn("支付金额小于订单金额!订单号:{}", orderNo);
			//throw new OrderException(OrderErrorCode.CHARGE_MONEY_LESS_THAN_ORDER_MONEY,"支付金额小于订单金额!");
		}
		
		// 2. 更新交易结果状态
		PayResult payResult = new PayResult();
		payResult.setTransId(payNotifyDto.getTransId());
		payResult.setOutTransId(payNotifyDto.getOutTransId());
		payResult.setTransStatus(TransStatusEnum.SUCCESS.getId());
		payResult.setChargeMoney(payNotifyDto.getChargeMoney());
		payResult.setPayType(payNotifyDto.getPayType());
		payResult.setReceipt(payNotifyDto.getReceipt());
		payResult.setReturnData(payNotifyDto.getReturnData());
		payResult.setUpdateTime(now);
		payResultMapper.update(payResult);
		
		// 3. 更新订单状态
		orderInfo.setStatus(OrderStatusEnum.PAID.getValue());
		orderInfo.setUpdateTime(now);
		orderInfoMapper.updateStatus(orderInfo);
		
		try {			
			//4、调用发货
			this.callExeGoods(orderInfo, payResult);
		} catch (Exception e) {
			log.error("调用发货处理错误", e);
			throw new OrderException(OrderErrorCode.PAY_NOTIFY_HANDLE_ERROR,"调用发货处理错误"+e.getMessage(), e);
		}
		
	}
	
	
	/**
	 * 查询支付结果通知
	 * 
	 * @param transId
	 * 
	 * @return
	 */
	public PayResult queryOrderPayResult(String transId){
		return payResultMapper.select(transId);
	}
	
	
	/**
	 * 支付失败-记录数据
	 * 
	 * @param orderFail
	 * 
	 * @return
	 */
	public int saveOrderPayFail(OrderFail orderFail){
		return orderFailMapper.insert(orderFail);
	}
	
	/**
	 * 处理-支付失败-订单
	 * 
	 * @param orderFail
	 * 
	 * @return
	 */
	@Transactional(readOnly = false,rollbackFor = Exception.class)
	public int handleFailOrder(OrderFail orderFail){
		PayNotifyDto payNotifyDto = this.getPayNotifyDto(orderFail);
		this.saveOrderPayResult(payNotifyDto);
		
		//更新状态为已处理
		orderFail.setHandleStatus(OrderFailHandleStatusEnum.ALREADY_HANDLE.getId());//已处理
		orderFail.setErrorMsg("");
		this.updateHandleFailOrder(orderFail);
		
		return 0;
	}
	
	
	/**
	 * 处理-支付失败-订单-更新处理次数
	 * 
	 * @param orderFail
	 * 
	 * @return
	 */
	public int updateHandleFailOrder(OrderFail orderFail){
		return orderFailMapper.update(orderFail);
	}
	
	/**
	 * 查询订单
	 * 
	 *
	 * @return
	 */
	public List<OrderFail> getOrderFails4Job(){
		return orderFailMapper.getOrderFails4Job();
	}

	/**
	 * 调用发货
	 * @param orderInfo
	 * @throws Exception 
	 */
	private void callExeGoods(OrderInfo orderInfo, PayResult payResult) throws Exception{
		
		Integer chargeMoney = payResult.getChargeMoney();
		BigDecimal m1 = new BigDecimal(chargeMoney*1.0);
		BigDecimal mm = new BigDecimal("100");
		BigDecimal money = m1.divide(mm);
		//除了银行转帐其它扣除百分之一的手续费
		if( (!orderInfo.getPayType().equals(PayTypeEnum.CMC_BANK_PAY.getCode())) ){
			money = money.multiply(new BigDecimal("0.99"));
		}
		//调用发货
		String moneyStr = String.valueOf(money.doubleValue());
		log.info("支付成功-调用发货, userId:{}, ditchId:{}, moeny:{}", orderInfo.getPayUid(), orderInfo.getChannelId(), moneyStr);
		channelsService.addRechargeSimServiceSelf(orderInfo.getOrderNo(), orderInfo.getPayUid(), orderInfo.getChannelId(), moneyStr);
		asyncSms(orderInfo, moneyStr);
	}
	

	private PayNotifyDto getPayNotifyDto(OrderFail orderFail) {
		PayNotifyDto payNotifyDto = new PayNotifyDto();
		payNotifyDto.setTransId(orderFail.getOrderNo());
		payNotifyDto.setOrderNo(orderFail.getOrderNo());
		payNotifyDto.setOutTransId(orderFail.getOutTransId());
		payNotifyDto.setPayType(orderFail.getPayType());
		payNotifyDto.setChargeMoney(orderFail.getChargeMoney());
		payNotifyDto.setOrderMoney(orderFail.getOrderMoney());
		payNotifyDto.setThirdPaySuccess(true);
		return payNotifyDto;
	}
	
    //异步发短信通知
    private void asyncSms(final OrderInfo orderInfo, final String moneyStr){
		//异步处理 		
		new Thread(new Runnable() {
			public void run() {
				try {
					//调用业务方法
					Channels fd = channelsMapper.findById(orderInfo.getChannelId());
					if(!StringUtils.isEmpty(fd.getBussContactPhone())){
						String text = PaymentCache.getValue("ADD_VALUE_SMS_TEXT");
						String payType = "";
						if(PayTypeEnum.CMC_BANK_PAY.getCode().equals(orderInfo.getPayType())){
							payType = PayTypeEnum.CMC_BANK_PAY.getName();
						}else if(PayTypeEnum.ALIPAY_MOBILE.getCode().equals(orderInfo.getPayType())){
							payType = PayTypeEnum.ALIPAY_MOBILE.getName();
						}else if(PayTypeEnum.WX_APP.getCode().equals(orderInfo.getPayType())){
							payType = PayTypeEnum.WX_APP.getName();
						}
						text = String.format(text, DateUtil.getSimpleDate(new Date()), payType, moneyStr);
						String phone = fd.getBussContactPhone();
		                /*String smsUrl = SysConfigApp.getValue("smsUrl");
		                String smsSendUser = SysConfigApp.getValue("smsSendUser");
		                String smsSendPwd = SysConfigApp.getValue("smsSendPwd");
						String dtime = String.valueOf(System.currentTimeMillis());
						String pwdString = "key="+MD5App.GetMD5Code(smsSendPwd).toLowerCase()+"&timestamp="+dtime;
						smsUrl = smsUrl+"?user_name="+smsSendUser+"&sub_user=&password="+MD5App.GetMD5Code(pwdString)+
								"&timestamp="+dtime+"&mobile="+phone+"&content="+URLEncoder.encode(text,"utf-8");
						
						String respon = servletReqService.GetResponseData(smsUrl,"");*/
						String urlStr = SysConfig.getValue("CoolUrl")+"services/smsCodeServlet";
			            Map<String, Object> param = new HashMap<String, Object>();
			            param.put("url", urlStr);
			            param.put("mobile", phone);
			            param.put("content", text);
			            String respon = InterfaceUtil.getInstance().httpPost(param);
		                if(Utils.isEmptyStr(respon)){
		                	log.error("调用发货处理成功, 但是短信通知失败, 短信平台未反回数据");
							log.error("发送数据为："+urlStr);
		        			throw new OrderException(OrderErrorCode.PAY_NOTIFY_HANDLE_ERROR,"调用发货处理成功, 但是短信通知失败, 短信平台未反回数据");
		                }
		                SmsResponseDTO resDTO =JSONUtil.jsonToObject(respon, SmsResponseDTO.class);
		                if(!"0".equals(resDTO.getCode())){
		                	log.error("调用发货处理成功, 但是短信通知失败, 短信平台反回失败, 反回信息={}", respon);
		        			throw new OrderException(OrderErrorCode.PAY_NOTIFY_HANDLE_ERROR,"调用发货处理成功, 但是短信通知失败, 短信平台反回失败, 反回信息=" + respon);
		                }
						log.info("调用发货处理成功, 短信通知成功, smsUrl={}, text={}", urlStr, text);
					}else{
						log.warn("根据订单渠道ID, 未找到对应的联系电话, 调用发货处理成功(加值成功)未发送短信通知");
					}
				} catch (Exception e) {
					log.error("调用发货处理成功, 但是短信通知失败 ", e);
				}
				
			}
		}).start();
    }
}
