package com.agent.order.web.spi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelsService;
import com.agent.common.RestStatus;
import com.agent.constant.Constant;
import com.agent.order.common.constant.SysConstant;
import com.agent.order.common.util.IpUtil;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.exception.ArgumentException;
import com.agent.order.exception.OrderException;
import com.agent.order.web.biz.OrderInfoBiz;
import com.agent.order.web.dto.OrderInfoDto;
import com.agent.order.web.dto.PayGoodsDto;
import com.agent.order.web.dto.Rs4OrderInfoDto;
import com.agent.order.web.dto.Rs4PayGoodsDto;
import com.agent.system.entity.User;
import com.ibm.icu.math.BigDecimal;

@RestController
@RequestMapping("order/pay")
public class OrderRersource {
	private static final Logger log = LoggerFactory.getLogger(OrderRersource.class);
	
	@Resource
	private OrderInfoBiz orderInfoBiz;
	
	@Autowired
    private ChannelsService channelsService;
	
	/**
	 * 获取商品接口
	 * @param goodsType 
	 * @return
	 */
    @RequestMapping(value = "/goods", method = {RequestMethod.POST})
    @ResponseBody
	public RestStatus goods(){
		RestStatus restStatus = new RestStatus(Boolean.TRUE, SysConstant.API_CODE_SUCESS, "处理成功！");    
		PayGoodsDto dto = new PayGoodsDto();
		try {
/*			if(StringUtil.isEmpty(goodsType)){
				goodsType = "cash";
			}else{
				if(!GoodsTypeEnum.CASH.getCode().equals(goodsType)){
					throw new ArgumentException(OrderErrorCode.PARAM_ERR, "商品类型:"+ goodsType +", 暂不支持, 请传cash");
				}
			}*/
			dto.setGoodsType("cash");
			List<Rs4PayGoodsDto> data = orderInfoBiz.getPayGoodsList(dto);
			restStatus.setResponseData(data);
		}catch (ArgumentException e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage(e.getMessage());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage("系统异常");
			log.error("系统异常",e);
		}
		log.info("获取商品接口 返回：{}", JSONUtil.objectToJson(restStatus));
		return restStatus;
	}	
	
	/**
	 * 下单接口(购买通用接口)
	 * @param jsonStr 
	 * @return
	 */
	@RequestMapping(value = "/buy",method = RequestMethod.POST)
    @ResponseBody
	public RestStatus buy(HttpServletRequest request, HttpServletResponse response, 
	        OrderInfoDto dto, String payMoney, String payType){
	    dto = new OrderInfoDto();
	    BigDecimal money = new BigDecimal(payMoney);
	    dto.setOrderMoney(money.multiply(new BigDecimal(100)).intValue());
	    dto.setPayType(payType);
	    dto.setOrderType("00");
		String jsonStr = JSONUtil.objectToJson(dto);
		RestStatus restStatus = new RestStatus(Boolean.TRUE, SysConstant.API_CODE_SUCESS, "处理成功！");
		try {
		    User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
		    Channels channels = channelsService.findChannelByUserId(user.getId());
		    dto.setPayUid(user.getId());
		    dto.setChannelId(channels.getId());
//			if(null == dto){
//				throw new ArgumentException(OrderErrorCode.PARAM_ERR, "参数错误");
//			}
			dto.setIp(IpUtil.getIp(request));
			jsonStr = JSONUtil.objectToJson(dto);
	        log.info("下单入参jsonStr:{}", jsonStr);
			Rs4OrderInfoDto data = orderInfoBiz.addOrder(dto);
			restStatus.setResponseData(data);
		} catch (ArgumentException e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage(e.getMessage());
			restStatus.setResponseData(new Rs4OrderInfoDto());
			log.error(e.getMessage(),e);
		} catch (OrderException e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage(e.getMessage());
			restStatus.setResponseData(new Rs4OrderInfoDto());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage("系统异常");
			restStatus.setResponseData(new Rs4OrderInfoDto());
			log.error("系统异常",e);
		}
		log.info("下单入参:{}; 返回：{}", jsonStr, JSONUtil.objectToJson(restStatus));
		return restStatus;
	}
	
	/**
	 * 查询加值充值列表
	 * @param month 
	 * @return
	 */	
	/*@RequestMapping(value = "/charge/list",method = RequestMethod.POST)
    @ResponseBody
	public RestStatus orderList(OrderInfoDto dto){
		String jsonStr = JSONUtil.objectToJson(dto);
		log.info("查询加值充值列表入参jsonStr:{}", jsonStr);
		RestStatus restStatus = new RestStatus(Boolean.TRUE, SysConstant.API_CODE_SUCESS, "处理成功！");        
		try {
			if(null == dto){
				throw new ArgumentException(OrderErrorCode.PARAM_ERR, "参数错误");
			}
			Map<String,Object> data = orderInfoBiz.orderList(dto);
			restStatus.setResponseData(data);
		} catch (ArgumentException e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage(e.getMessage());
			restStatus.setResponseData(new HashMap<String,Object>());
			log.error(e.getMessage(),e);
		} catch (OrderException e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage(e.getMessage());
			restStatus.setResponseData(new HashMap<String,Object>());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage("系统异常");
			restStatus.setResponseData(new HashMap<String,Object>());
			log.error("系统异常",e);
		}
		log.info("查询加值充值列表入参:{}; 返回：{}", jsonStr, JSONUtil.objectToJson(restStatus));
		return restStatus;
	}*/
	
	
	/**
	 * 查询CMC银行信息
	 * 
	 * @return
	 */	
	@RequestMapping(value = "/bankinfo",method = RequestMethod.POST)
    @ResponseBody
	public RestStatus cmcBankInfo(){
		RestStatus restStatus = new RestStatus(Boolean.TRUE, SysConstant.API_CODE_SUCESS, "处理成功！");        
		try {
			Map<String,Object> data = orderInfoBiz.getCmcBankInfo();
			restStatus.setResponseData(data);
		} catch (ArgumentException e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage(e.getMessage());
			restStatus.setResponseData(new HashMap<String,Object>());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			restStatus.setStatus(Boolean.FALSE);
			restStatus.setErrorCode(SysConstant.API_CODE_ERROR);
			restStatus.setErrorMessage("系统异常");
			restStatus.setResponseData(new HashMap<String,Object>());
			log.error("系统异常",e);
		}
		log.info("查询CMC银行信息 返回：{}", JSONUtil.objectToJson(restStatus));
		return restStatus;
	}

}
