package com.agent.order.mapper;

import com.agent.order.entity.PayTracode;

public interface PayTracodeMapper{
	
	PayTracode selectByUid(Integer userId);
	
	PayTracode selectByChannelId(Integer channelId);
	
	PayTracode selectByTracode(String tracode);
	
	int insert(PayTracode payTracode);
	
	public int selectMaxTracode();
}