package com.agent.order.web.spi;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.SysConstant;
import com.agent.order.exception.OrderException;
import com.agent.order.web.biz.CMCBankBiz;
import com.agent.order.web.dto.ResultDto;


/**
 * CMC 手动执行
 * @author kangy
 *
 */

@RestController
@RequestMapping("/admin")
public class CmcRersource {
	private static final Logger log = LoggerFactory.getLogger(CmcRersource.class);
	
	@Resource
	CMCBankBiz cMCBankBiz;
	
	/**
	 * 手动执行获取CMC数据
	 * @param jsonStr
	 * @return
	 */
	@RequestMapping(value = "/cmc",method = RequestMethod.GET, produces=SysConstant.APPLICATION_JSON_UTF8)
	public ResultDto cmcTransOrder(HttpServletRequest request,
								   @RequestParam(value = "BBKNBR") String BBKNBR,
								   @RequestParam(value = "ACCNBR") String ACCNBR,
								   @RequestParam(value = "BGNDAT") String BGNDAT,
								   @RequestParam(value = "ENDDAT") String ENDDAT){
		ResultDto result = new ResultDto(OrderErrorCode.SUCCESS,"成功");
		try {
			cMCBankBiz.procTransInfo(BBKNBR, ACCNBR, BGNDAT, ENDDAT);
		} catch (OrderException e) {
			result.setCode(e.getCode());
			result.setMsg(e.getMessage());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			result.setCode(OrderErrorCode.UNKOWN_ERR);
			result.setMsg("未知错误");
			log.error("未知错误",e);
		}
		return result;
	}
	
	/**
	 * 手动执行处理 CMC处理失败的数据
	 * @param jsonStr
	 * @return
	 */
	@RequestMapping(value = "/cmc/fail",method = RequestMethod.GET, produces=SysConstant.APPLICATION_JSON_UTF8)
	public ResultDto cmcFailTransOrder(){
		ResultDto result = new ResultDto(OrderErrorCode.SUCCESS,"成功");
		try {
			cMCBankBiz.procFailTransInfo();
		} catch (OrderException e) {
			result.setCode(e.getCode());
			result.setMsg(e.getMessage());
			log.error(e.getMessage(),e);
		} catch (Exception e) {
			result.setCode(OrderErrorCode.UNKOWN_ERR);
			result.setMsg("未知错误");
			log.error("未知错误",e);
		}
		return result;
	}	
}
