package com.agent.order.common.controller;

import com.agent.number.service.NumberService;
import com.agent.order.common.util.IpUtil;
import com.agent.order.common.util.third.weixin.JsonUtils;
import com.agent.order.common.util.third.weixin.MerchantApiUtil;
import com.agent.order.common.util.third.weixin.WeixinConfigUtil;
import com.agent.order.common.util.third.weixin.WeixinPaySubmit;
import com.agent.order.common.util.third.weixin.WeixinPayUtils;
import com.agent.order.common.util.third.weixin.entity.OrderPayResultVo;
import com.agent.order.common.util.third.weixin.entity.OrderQueryVo;
import com.agent.order.common.util.third.weixin.entity.ScanPayResultVo;
import com.agent.order.entity.OrderInfo;
import com.agent.order.service.OrderInfoService;
import com.agent.system.entity.User;
import com.agent.util.DecimalUtil;
import com.agent.util.Utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * <b>微信支付控制类</b>
 * @author fenglu
 */
@Controller
@RequestMapping(value = "/weixinPay")
public class WeixinPaymentController extends BaseController {
    
    private static Logger logger = LoggerFactory.getLogger(WeixinPaymentController.class);
    
    @Autowired
    private OrderInfoService orderInfoService;
    @Autowired
    private NumberService numberService;

    @RequestMapping("/scanPay")
    public String scanPay(HttpServletRequest request, HttpServletResponse response, Model model) {
        Map<String, Object> paramMap = new HashMap<String, Object>();

        String orderPriceStr = getString_UrlDecode_UTF8("orderPrice"); // 订单金额 , 单位:元
        paramMap.put("orderPrice", orderPriceStr);

        String orderNo = getString_UrlDecode_UTF8("orderNo"); // 订单编号
        paramMap.put("orderNo", orderNo);

        String productName = getString_UrlDecode_UTF8("productName"); // 商品名称
        paramMap.put("productName", productName);

        String orderIp = IpUtil.getIp(request); // 下单IP
        paramMap.put("orderIp", orderIp);

        String returnUrl = WeixinConfigUtil.readConfig("wx_pc.return_url"); // 页面通知返回url
        paramMap.put("returnUrl", returnUrl);
        String notifyUrl = WeixinConfigUtil.readConfig("wx_pc.notify_url"); // 后台消息通知Url
        paramMap.put("notifyUrl", notifyUrl);

        String buildRequest = MerchantApiUtil.buildRequest(paramMap, "get", "确定",
                WeixinConfigUtil.readConfig("wx_pc.scanPay_url"));
        model.addAttribute("payMessage", buildRequest);

        return "../views/pay/wxpay/toPay.jsp";
    }
    
    /**
     * 扫码支付,预支付页面
     * 用户进行扫码支付时,商户后台调用该接口
     * 支付平台根据商户传入的参数是否包含支付通道,决定需要跳转的页面
     * 1:传入支付通道参数,跳转到相应的支付通道扫码页面
     * 2:未传入支付通道参数,跳转到
     * @return
     * @throws Exception 
     */
    @RequestMapping("/initPay")
    public String initPay(Model model) throws Exception{
        Map<String , Object> paramMap = new HashMap<String , Object>();
        String orderPrice = getString_UrlDecode_UTF8("orderPrice");
        paramMap.put("orderPrice",orderPrice);
        String orderNo = getString_UrlDecode_UTF8("orderNo");
        paramMap.put("orderNo",orderNo);
        String productName = getString_UrlDecode_UTF8("productName");
        paramMap.put("productName",productName);
        String orderIp = getString_UrlDecode_UTF8("orderIp");
        paramMap.put("orderIp",orderIp);
        String returnUrl = getString_UrlDecode_UTF8("returnUrl");
        paramMap.put("returnUrl",returnUrl);
        String notifyUrl = getString_UrlDecode_UTF8("notifyUrl");
        paramMap.put("notifyUrl",notifyUrl);

        String secretKey = WeixinConfigUtil.readConfig("wx_pc.secretKey");
        String sign = MerchantApiUtil.getSign(paramMap, secretKey);
        if (!MerchantApiUtil.isRightSign(paramMap, secretKey, sign)){
            throw new Exception("订单签名异常");
        }

        WeixinPaySubmit weixiniPay = new WeixinPaySubmit();
        ScanPayResultVo scanPayResultVo = weixiniPay.getScanPayResultVo(paramMap);

        BigDecimal orderPrice1 = BigDecimal.valueOf(Double.valueOf(orderPrice));
        String queryUrl = WeixinConfigUtil.readConfig("wx_pc.order_query");
        model.addAttribute("queryUrl", queryUrl + "?orderNO=" + orderNo);
        model.addAttribute("productName", productName);//产品名称
        model.addAttribute("orderPrice", orderPrice1);//订单价格
        model.addAttribute("codeUrl",scanPayResultVo.getCodeUrl());//支付二维码
        return "../views/pay/wxpay/weixinPayScanPay.jsp";
    }

    /**
     * 支付结果查询接口
     * @param orderNO 订单号
     * @param httpServletResponse
     */
    @RequestMapping("/orderQuery")
    public void orderQuery(String orderNO, HttpServletResponse httpServletResponse)throws IOException{

        String appid = WeixinConfigUtil.readConfig("wx_pc.appId");
        String mch_id = WeixinConfigUtil.readConfig("wx_pc.mch_id");
        String partnerKey = WeixinConfigUtil.readConfig("wx_pc.partnerKey");
        // 调用微信API查询订单是否完成
        String orderQueryUrl = WeixinConfigUtil.readConfig("wx_pc.order_query_url");
        // 调用成功后返回的页面
        String returnUrl = WeixinConfigUtil.readConfig("wx_pc.return_url");
        
        OrderQueryVo orderQuery = new OrderQueryVo();
        orderQuery.setAppid(appid);
        orderQuery.setMch_id(mch_id);
        orderQuery.setOut_trade_no(orderNO);
        orderQuery.setNonce_str(Utils.get32UUID());

        String prePayXml = WeixinPayUtils.getOrderQueryXml(orderQuery, partnerKey);
        //调用微信支付的功能,获取微信支付code_url
        Map<String, Object> prePayRequest = WeixinPayUtils.httpXmlRequest(orderQueryUrl, "POST", prePayXml);
        
        OrderPayResultVo payResult = new OrderPayResultVo();
        payResult.setProductName("充值");
        if ("SUCCESS".equals(prePayRequest.get("return_code")) 
                && "SUCCESS".equals(prePayRequest.get("result_code"))
                && "SUCCESS".equals(prePayRequest.get("trade_state"))) {
            logger.info("微信返回的成功报文："+prePayRequest.toString());
            // 处理订单，并
            payResult.setStatus("YES");
            payResult.setReturnUrl(returnUrl);
        } else {
            payResult.setStatus("NO");
        }
        
        httpServletResponse.setContentType("text/text;charset=UTF-8");
        JsonUtils.responseJson(httpServletResponse,payResult);
    }

    @RequestMapping("/notify")
    public void notify(HttpServletRequest request, HttpServletResponse response) throws Exception {

        Map<String , String> notifyMap = new HashMap<String , String >();
        // 从request中取得输入流
        InputStream inputStream = request.getInputStream();
        notifyMap = WeixinPayUtils.parseXml(inputStream);
        logger.info("微信支付回调的参数--->"+notifyMap);
        // 业务结果 成功
        if ("SUCCESS".equals(notifyMap.get("result_code"))
                && "SUCCESS".equals(notifyMap.get("return_code"))) {
            try {
                String out_trade_no = notifyMap.get("out_trade_no");
                // 交易金额(分)
                String total_fee = notifyMap.get("total_fee");
                String transaction_id = notifyMap.get("transaction_id");
                User curUser = (User) request.getSession().getAttribute("user");
                OrderInfo order = orderInfoService.findByOrderNo(out_trade_no);
                if (null != order) {
                    order.setStatus("1");
                    orderInfoService.updateStatus(order);
                }
                
                // total_fee 单位分，需要转换成元
                BigDecimal orderMoneyReal = DecimalUtil.divd(Double.valueOf(total_fee), 100);
                // 扣除1%的手续费
                double money = DecimalUtil.mul(Double.valueOf(total_fee)/100, 0.99);
                BigDecimal orderMoney = new BigDecimal(money);
                // 保留小数点后四位
                orderMoney = orderMoney.setScale(4, BigDecimal.ROUND_DOWN);
                // 充值类型：3.微信支付 直充
                int payType = 3;

                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", null);
                param.put("channelId", order.getChannelId());
                param.put("accountType", 3);
                param.put("operationType", 2);
                param.put("money", orderMoney);
                param.put("busMoney", orderMoneyReal);
                param.put("remark", "代理商加值");
                param.put("transactionAccount", "总部加值：系统加值");
                param.put("transId", out_trade_no);
                param.put("transactionType", "t_pay_order_info");
                param.put("calcType", "+");
                param.put("transactionFlow", transaction_id);
                param.put("payType", payType);
                param.put("us", curUser);
                // 往直充账户里加值
                numberService.takeMoney(param);
                // 返回给微信回调必须的值，XML格式，不包含SUCCESS字符串的话，微信会按照一定的策略一直回调我们
                String returnStr = "<xml>\n" +
                        "  <return_code><![CDATA[SUCCESS]]></return_code>\n" +
                        "  <return_msg><![CDATA[OK]]></return_msg>\n" +
                        "</xml>";
                response.setContentType("text/xml");
                response.getWriter().print(returnStr);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    @RequestMapping("/return")
    public String payReturn(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        logger.info("---微信支付成功，跳转页面---");
        return "../views/pay/paySuccess.jsp";
    }

}
