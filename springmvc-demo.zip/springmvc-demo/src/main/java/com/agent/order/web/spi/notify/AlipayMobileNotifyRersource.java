package com.agent.order.web.spi.notify;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.constant.SysConstant;
import com.agent.order.common.util.DateUtil;
import com.agent.order.common.util.ServletUtil;
import com.agent.order.common.util.third.alipay.AlipayNotify;
import com.agent.order.exception.OrderException;
import com.agent.order.web.dto.PayNotifyDto;

/**
 * 
 * @author kangy
 *
 */
@RestController
@Scope("prototype")
public class AlipayMobileNotifyRersource extends NotifyRersource {
	private static final Logger log = LoggerFactory.getLogger(AlipayMobileNotifyRersource.class);

	@Resource 
	private  HttpServletRequest request; 
	private Map<String, String> rMap;
	
	@RequestMapping(value = "/notify/alipay_mobile", method = RequestMethod.POST, produces = SysConstant.APPLICATION_JSON_UTF8)
	public String alipay() {
		log.info("支付宝移动支付通知：{}",ServletUtil.herf(request));
		try {
			process();
		} catch (OrderException e) {
			log.error("支付宝支付不成功", e);
			//如果支付宝通知状态为WAIT_BUYER_PAY，返回success
			if(e.getCode() == OrderErrorCode.ALIPAY_NOTIFY_WAIT_BUYER_PAY){
				return "success";
			}
			return "fail";
			
		}catch (Exception e) {
			log.error("支付宝支付不成功", e);
			return "fail";
		}
		return "success";
	}
	
	@Override
	PayNotifyDto buildPayNotifyDto() {

		String out_trade_no = request.getParameter("out_trade_no"); // 订单号
		String trade_no = request.getParameter("trade_no"); // 支付宝交易号
		String total_fee = request.getParameter("total_fee"); // 交易金额
		
//		String notifyId = request.getParameter("notify_id"); // 通知ID
		String notifyTime = request.getParameter("notify_time"); // 通知时间
		String trade_status = request.getParameter("trade_status"); // 交易状态

		PayNotifyDto payNotifyDto = new PayNotifyDto();
		payNotifyDto.setTransId(out_trade_no);
		payNotifyDto.setOutTransId(trade_no);// 支付宝交易号
		payNotifyDto.setOrderNo(out_trade_no);// 订单号
		payNotifyDto.setChargeMoney(new Double(Double.parseDouble(total_fee) * 100).intValue());// 精确到分
		payNotifyDto.setReceipt("");
		String reqStr = ServletUtil.herf(request);
		payNotifyDto.setReturnData(reqStr.substring(reqStr.indexOf("?")+1));
		try {
			if (StringUtils.isNotBlank(notifyTime)) {
				payNotifyDto.setNotifyTime(DateUtil.parse(notifyTime,
						DateUtil.FMT_TYPE1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		payNotifyDto.setPayType(PayTypeEnum.ALIPAY_MOBILE.getCode());
		// 支付宝付款是否成功
		if("WAIT_BUYER_PAY".equals(trade_status)){
			String errMsg = "订单号:"+out_trade_no+", 支付宝通知返回【 等待买家付款】";
			throw new OrderException(OrderErrorCode.ALIPAY_NOTIFY_WAIT_BUYER_PAY,errMsg);
		}
		boolean isThirdPaySuccess = "TRADE_FINISHED".equals(trade_status) || "TRADE_SUCCESS".equals(trade_status);
		payNotifyDto.setThirdPaySuccess(isThirdPaySuccess);
		return payNotifyDto;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	boolean validateSign() {
		rMap = new HashMap<String, String>();
        Map<String, String[]> requestParams = request.getParameterMap();
		for (Iterator<String> iter = requestParams.keySet().iterator(); iter
				.hasNext();) {
			String name = iter.next();
			String[] values = (String[]) requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			// 乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
			// valueStr = new String(valueStr.getBytes("ISO-8859-1"), "utf-8");
			rMap.put(name, valueStr);
		}
		// 验证消息源及参数的合法性
		return AlipayNotify.verify(rMap);
	}

}
