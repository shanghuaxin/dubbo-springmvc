package com.agent.order.web.spi.notify;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.agent.order.common.AsyncCall;
import com.agent.order.common.AsyncCallContent;
import com.agent.order.common.OrderErrorCode;
import com.agent.order.common.constant.OrderFailTypeEnum;
import com.agent.order.common.constant.PayTypeEnum;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.entity.OrderFail;
import com.agent.order.entity.PayResult;
import com.agent.order.exception.OrderException;
import com.agent.order.service.TransactionService;
import com.agent.order.web.biz.TransactionBiz;
import com.agent.order.web.cache.PaymentCache;
import com.agent.order.web.dto.PayNotifyDto;

/**
 * 异步通知抽象类，每个第三方通知类（支付宝、微信、易宝等）必须继承
 * @author kangy
 *
 */


public abstract class NotifyRersource {
	private static final Logger log = LoggerFactory.getLogger(NotifyRersource.class);	
	@Resource
	TransactionBiz transactionBiz;
	@Resource
	TransactionService transactionService;
	
	public void process(){
		//1、生成业务对象
		PayNotifyDto dto = this.buildPayNotifyDto();
		
		log.info("1、得到业务对象,返回{},单号:{}",JSONUtil.objectToJson(dto),dto.getTransId());
		String transId =dto.getTransId();//获取交易号
		//2、查询订单
		PayResult payResult = transactionService.queryOrderPayResult(transId);
		
		if(payResult ==null){
			log.error("支付通知没找到交易号,单号：{}",transId);
			String errMsg = "支付通知没找到交易号";
			OrderFail entity = transactionBiz.getOrderFail(dto,errMsg,OrderFailTypeEnum.THIRD_NOTIFY_FAIL.getId());
			transactionService.saveOrderPayFail(entity);
			throw new OrderException(OrderErrorCode.PAY_NOTIFY_TRANS_ID_NOT_FOUND, errMsg);
		}

		dto.setPayType(payResult.getPayType());
		dto.setOrderMoney(payResult.getOrderMoney());
		
		//苹果支付，订单金额和支付金额相等
		if(PayTypeEnum.APPLE_PAY.getCode().equals(dto.getPayType())){
			dto.setChargeMoney(dto.getOrderMoney());
		}
		
		//2、验证签名
		if("y".equals(PaymentCache.getValue("PAY_NOTIFY_SIGN_VALIDATE"))){
			boolean flagA = this.validateSign();
			log.info("2、验证签名,返回{},单号:{}",flagA,transId);
			if(!flagA){
				String errMsg = "支付通知sign验证失败";
				OrderFail entity = transactionBiz.getOrderFail(dto,errMsg,OrderFailTypeEnum.THIRD_NOTIFY_FAIL.getId());
				transactionService.saveOrderPayFail(entity);
				throw new OrderException(OrderErrorCode.PAY_NOTIFY_SIGN_ERROR,errMsg);
			}
		}else{
			log.warn("2、配置PAY_NOTIFY_SIGN_VALIDATE:{},跳过验证(生产环境必须配置为y)！",PaymentCache.getValue("PAY_NOTIFY_SIGN_VALIDATE"));
		}
		
		//3、验证是否支付成功
		boolean flagB = dto.isThirdPaySuccess();
		log.info("3、验证是否支付成功,返回{},单号:{}",flagB,transId);
		if(!flagB){
			//记录日志
			String errMsg = "第三方通知返回失败";
			log.error("单号{}第三方通知返回失败",transId);
			OrderFail entity = transactionBiz.getOrderFail(dto,errMsg,OrderFailTypeEnum.THIRD_NOTIFY_FAIL.getId());
			transactionService.saveOrderPayFail(entity);
			throw new OrderException(OrderErrorCode.THIRD_NOTIFY_RETURN_FAIL,errMsg);
		}
		
		//异步处理 
		new AsyncCall(new AsyncCallContent() {
			@Override
			public void doSomeThing(PayNotifyDto dto) {
				//4、调用业务方法
				transactionBiz.successProcess(dto);
				log.info("4、调用successProcess方法成功返回,单号:{}",dto.getTransId());
			}
			@Override
			public void onFailure(PayNotifyDto dto,OrderException e) {
				log.error("处理业务失败",e);
				
				//重复通知不记录日志
				if(e.getCode()!=OrderErrorCode.PAY_NOTIFY_REPEATED){
					// 记录日志
					OrderFail entity = transactionBiz.getOrderFail(dto,e.getMessage(),OrderFailTypeEnum.BIZ_PROCESS_FAIL.getId());
					entity.setChargeMoney(entity.getChargeMoney());
					entity.setOrderMoney(entity.getOrderMoney());
					transactionService.saveOrderPayFail(entity);
				}
			}
		},dto).start();
	}
	
	/**
	 * 1、构造对象
	 * @return
	 */
	abstract PayNotifyDto buildPayNotifyDto();
	
	/**
	 * 2、验证签名
	 * @return
	 */
	abstract boolean validateSign();
	
}
