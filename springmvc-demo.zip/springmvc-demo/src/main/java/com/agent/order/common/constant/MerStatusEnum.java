package com.agent.order.common.constant;

/**
 * @author kangy
 *
 */
public enum MerStatusEnum {
	NOMAL("00", "正常"), CLOSE("01", "关闭");
	private String id;
	private String name;
	
	private MerStatusEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
}
