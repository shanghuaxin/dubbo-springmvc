package com.agent.channel.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 渠道账户交易流水表，用于订单交互
 * @author 冯路
 *
 */
public class ChannelAccountTransactionDTO implements Serializable{

    private static final long serialVersionUID = 8869478151567762358L;
    private Integer id;               //id
    private Integer channelId;        //渠道ID
    private String channelCode;       //渠道编号
    private Integer channelAccountId; //渠道账户ID
    private String msisdn;            //手机号码
    private String accountName;       //账户名称
    private Integer accountType;      //账户类型
    private Integer operationType;    //操作类型：1：划拨进，2：直充(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货, 16:预开开卡扣款， 17：开卡扣款，18开卡冻结解冻扣款，19开卡退款,20开卡充值佣金
    private String transactionAccount;  //对方账户，交易账户
    private String transactionId;    //交易ID
    private String transactionType;  //交易归属的表名，用于判断transaction_id属于哪个表的主键
    private String transactionFlow;   //交易流水号
    private Integer payType;          //支付方式，1：银行卡支付，2：支付宝支付，3：微信支付，4：佣金转账
    private String payName;           //支付名称，1：银行卡支付，2：支付宝支付，3：微信支付，4：佣金转账
    private BigDecimal transactionMoney;      //交易金额（单位：分）
    private BigDecimal transactionMoneyReal;  //交易金额（含手续费，单位：分）
    private BigDecimal accountBalanceBefore;  //账户变更前余额（单位：分）
    private BigDecimal accountBalanceAfter;   //账户变更后余额（单位：分）
    private String remark;                 //交易备注
    private Integer operatorId;            //操作人ID
    private Date operationTime;            //操作时间
    
    public ChannelAccountTransactionDTO() {
        super();
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public Integer getChannelAccountId() {
        return channelAccountId;
    }

    public void setChannelAccountId(Integer channelAccountId) {
        this.channelAccountId = channelAccountId;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public String getTransactionAccount() {
        return transactionAccount;
    }

    public void setTransactionAccount(String transactionAccount) {
        this.transactionAccount = transactionAccount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionFlow() {
        return transactionFlow;
    }

    public void setTransactionFlow(String transactionFlow) {
        this.transactionFlow = transactionFlow;
    }

    public Integer getPayType() {
        return payType;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public String getPayName() {
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName;
    }
    
    public BigDecimal getTransactionMoney() {
        return transactionMoney;
    }

    public void setTransactionMoney(BigDecimal transactionMoney) {
        this.transactionMoney = transactionMoney;
    }

    public BigDecimal getTransactionMoneyReal() {
        return transactionMoneyReal;
    }

    public void setTransactionMoneyReal(BigDecimal transactionMoneyReal) {
        this.transactionMoneyReal = transactionMoneyReal;
    }

    public BigDecimal getAccountBalanceBefore() {
        return accountBalanceBefore;
    }

    public void setAccountBalanceBefore(BigDecimal accountBalanceBefore) {
        this.accountBalanceBefore = accountBalanceBefore;
    }

    public BigDecimal getAccountBalanceAfter() {
        return accountBalanceAfter;
    }

    public void setAccountBalanceAfter(BigDecimal accountBalanceAfter) {
        this.accountBalanceAfter = accountBalanceAfter;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }
    
}
