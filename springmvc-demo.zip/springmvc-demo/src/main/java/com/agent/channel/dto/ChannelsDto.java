package com.agent.channel.dto;

/**
 * Created by Administrator on 2016/7/22.
 */
public class ChannelsDto {
    private Integer channelId;//渠道
    private String channelCode;
    private String channelName;
    private Integer channelLevel;       //渠道级别，1：一级，2：二级，3：三级
    private Integer channelType;        //渠道属性，1：代理，2：网点
    private Integer channelPar1Id;//归属一级代理商
    private String channelPar1Code;
    private String channelPar1Name;
    private Integer channelPar2Id;//归属二级代理商
    private String channelPar2Code;
    private String channelPar2Name;
    private Integer cardId;
    private String cardNo;//卡密编号
    private Integer channelParId;//父级渠道id
    private Integer productId;//商品id
    private Integer status; //卡密状态：1-待销售，2-销售待激活，3-已激活

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getChannelLevel() {
        return channelLevel;
    }

    public void setChannelLevel(Integer channelLevel) {
        this.channelLevel = channelLevel;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }

    public Integer getChannelPar1Id() {
        return channelPar1Id;
    }

    public void setChannelPar1Id(Integer channelPar1Id) {
        this.channelPar1Id = channelPar1Id;
    }

    public String getChannelPar1Code() {
        return channelPar1Code;
    }

    public void setChannelPar1Code(String channelPar1Code) {
        this.channelPar1Code = channelPar1Code;
    }

    public String getChannelPar1Name() {
        return channelPar1Name;
    }

    public void setChannelPar1Name(String channelPar1Name) {
        this.channelPar1Name = channelPar1Name;
    }

    public Integer getChannelPar2Id() {
        return channelPar2Id;
    }

    public void setChannelPar2Id(Integer channelPar2Id) {
        this.channelPar2Id = channelPar2Id;
    }

    public String getChannelPar2Code() {
        return channelPar2Code;
    }

    public void setChannelPar2Code(String channelPar2Code) {
        this.channelPar2Code = channelPar2Code;
    }

    public String getChannelPar2Name() {
        return channelPar2Name;
    }

    public void setChannelPar2Name(String channelPar2Name) {
        this.channelPar2Name = channelPar2Name;
    }

    public Integer getCardId() {
        return cardId;
    }

    public void setCardId(Integer cardId) {
        this.cardId = cardId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Integer getChannelParId() {
        return channelParId;
    }

    public void setChannelParId(Integer channelParId) {
        this.channelParId = channelParId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
