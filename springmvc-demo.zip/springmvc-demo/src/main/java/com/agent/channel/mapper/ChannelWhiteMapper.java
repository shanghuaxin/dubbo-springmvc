package com.agent.channel.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.channel.entity.ChannelWhite;
import com.agent.common.BaseMapper;

public interface ChannelWhiteMapper extends BaseMapper<ChannelWhite, Integer>{
    
    public ChannelWhite findByChannelId(@Param(value="channelId") Integer channelId);

}
