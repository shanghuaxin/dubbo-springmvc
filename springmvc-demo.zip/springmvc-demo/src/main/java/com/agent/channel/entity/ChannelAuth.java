package com.agent.channel.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 渠道配置表
 * @author weijialiang
 *
 */
public class ChannelAuth implements Serializable{

    private static final long serialVersionUID = 1565343761337731089L;
    
    private Integer id;                  //id
    private Integer channelIdFrom;       //父级渠道ID
    private String channelCodeFrom;  //父级渠道编码
    private String channelNameFrom;  //父级渠道名称
    private Integer channelIdTo;         //渠道ID
    private String channelCodeTo;    //渠道编码
    private String channelNameTo;    //渠道名称
    private Integer isReader;            //读卡器：0-否，1-是
    private Integer isUploadImg;         //是否上传照片：0-否，1- 是
    private Integer isImg;               //照片识别：0-否，1- 是
    private Integer isAuth;              //是否审核：0-否，1- 是
    private Integer isAppImg;            //是否支持APP本地获取照片：0-否，1- 是，默认否
    private Integer isAppFace;           //是否支持APP活体检测：0-否，1- 是，默认是
    private Integer createId;            //创建人ID
    private Date createTime;         //创建时间
    private Integer updateId;            //更新人ID
    private Date updateTime;         //更新时间

    public ChannelAuth() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelIdFrom() {
        return channelIdFrom;
    }

    public void setChannelIdFrom(Integer channelIdFrom) {
        this.channelIdFrom = channelIdFrom;
    }

    public String getChannelCodeFrom() {
        return channelCodeFrom;
    }

    public void setChannelCodeFrom(String channelCodeFrom) {
        this.channelCodeFrom = channelCodeFrom;
    }

    public String getChannelNameFrom() {
        return channelNameFrom;
    }

    public void setChannelNameFrom(String channelNameFrom) {
        this.channelNameFrom = channelNameFrom;
    }

    public Integer getChannelIdTo() {
        return channelIdTo;
    }

    public void setChannelIdTo(Integer channelIdTo) {
        this.channelIdTo = channelIdTo;
    }

    public String getChannelCodeTo() {
        return channelCodeTo;
    }

    public void setChannelCodeTo(String channelCodeTo) {
        this.channelCodeTo = channelCodeTo;
    }

    public String getChannelNameTo() {
        return channelNameTo;
    }

    public void setChannelNameTo(String channelNameTo) {
        this.channelNameTo = channelNameTo;
    }

    public Integer getIsReader() {
        return isReader;
    }

    public void setIsReader(Integer isReader) {
        this.isReader = isReader;
    }

    public Integer getIsUploadImg() {
        return isUploadImg;
    }

    public void setIsUploadImg(Integer isUploadImg) {
        this.isUploadImg = isUploadImg;
    }

    public Integer getIsImg() {
        return isImg;
    }

    public void setIsImg(Integer isImg) {
        this.isImg = isImg;
    }

    public Integer getIsAuth() {
        return isAuth;
    }

    public void setIsAuth(Integer isAuth) {
        this.isAuth = isAuth;
    }

    public Integer getIsAppImg() {
        return isAppImg;
    }

    public void setIsAppImg(Integer isAppImg) {
        this.isAppImg = isAppImg;
    }

    public Integer getIsAppFace() {
        return isAppFace;
    }

    public void setIsAppFace(Integer isAppFace) {
        this.isAppFace = isAppFace;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ChannelAuth [id=" + id + ", channelIdFrom=" + channelIdFrom + ", channelCodeFrom=" + channelCodeFrom
                + ", channelNameFrom=" + channelNameFrom + ", channelIdTo=" + channelIdTo + ", channelCodeTo="
                + channelCodeTo + ", channelNameTo=" + channelNameTo + ", isReader=" + isReader + ", isUploadImg="
                + isUploadImg + ", isImg=" + isImg + ", isAuth=" + isAuth + ", createId=" + createId + ", createTime="
                + createTime + ", updateId=" + updateId + ", updateTime=" + updateTime + "]";
    }
    
}
