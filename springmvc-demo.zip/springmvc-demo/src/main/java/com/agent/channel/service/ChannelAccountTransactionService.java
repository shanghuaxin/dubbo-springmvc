package com.agent.channel.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.mapper.ChannelAccountTransactionMapper;
import com.agent.common.RestStatus;
import com.agent.number.service.NumberService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;

import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service
public class ChannelAccountTransactionService {

    @Autowired
    private ChannelAccountTransactionMapper mapper;
    @Autowired
    private NumberService numberService;
    
    public List<ChannelAccountTransaction> listTransation(Map<String, Object> map) {
        return mapper.listTransation(map);
    }
    
    public int countTotal(Map<String, Object> map) {
        return mapper.countTotal(map);
    }
    
    public List<ChannelAccountTransaction> listAddTransation(Map<String, Object> map) {
        return mapper.listAddTransation(map);
    }
    
    public int countAddTotal(Map<String, Object> map) {
        return mapper.countAddTotal(map);
    }
    
    public List<ChannelAccountTransaction> listOperationTransation(Map<String, Object> map) {
        return mapper.listOperationTransation(map);
    }
    public int countOperationTotal(Map<String, Object> map) {
        return mapper.countOperationTotal(map);
    }
    
    public BigDecimal sumTransactionMoney(Map<String, Object> map) {
        return mapper.sumTransactionMoney(map);
    }
    
    public String maxTransactionId(String ransactionId) {
        return mapper.maxTransactionId(ransactionId);
    }
    
    public RestStatus saveAccountOperation(ChannelAccountTransaction transaction, String transactionAccount, User user) throws Exception{
        
        synchronized(ChannelAccountTransactionService.class) {
            RestStatus restStatus = new RestStatus(Boolean.TRUE, "200", "操作成功！");
            String remark = "代理商加值";      //账户类型
            String calcType = "+";
            if(transaction.getOperationType() == 10){
                remark = "代理商加值(纠正)";
                calcType = "-";
            }
            
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String maxTransactionId = maxTransactionId(dateStr);
            int max = 0;
            if(maxTransactionId != null) {
                max = Integer.parseInt(maxTransactionId.substring(maxTransactionId.length() - 3, maxTransactionId.length()));
            }
            int cur = Integer.parseInt(transaction.getTransactionId().substring(transaction.getTransactionId().length() - 3, transaction.getTransactionId().length()));
            
            if(max >= cur){
                return new RestStatus(Boolean.FALSE, "500", "操作失败，您的工单号不是最新工单号！");
            }else {
                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", null);
                param.put("channelId", transaction.getChannelId());
                param.put("accountType", transaction.getAccountType());
                param.put("operationType", transaction.getOperationType());
                param.put("money", transaction.getTransactionMoney());
                param.put("busMoney", transaction.getTransactionMoney());
                param.put("remark", remark);
                param.put("transactionAccount", transactionAccount);
                param.put("transId", transaction.getTransactionId());
                param.put("transactionType", null);
                param.put("calcType", calcType);
                param.put("transactionFlow", null);
                param.put("payType", 5);
                param.put("us", user);
                restStatus = numberService.takeMoney(param);
            }
            return restStatus;
        }
        
    }
    
    // 获取指定月份的佣金总额(分)
    public BigDecimal countBrokerageMoney(Map<String, Object> map) {
        return mapper.countBrokerageMoney(map);
    }
    
    // 获取佣金详情
    public List<ChannelAccountTransaction> queryBrokerageDetail(Map<String, Object> map) {
        return mapper.queryBrokerageDetail(map);
    }
    // 获取佣金详情总记录数
    public int countBrokerageDetailTotal(Map<String, Object> map) {
        return mapper.countBrokerageDetailTotal(map);
    }
}
