package com.agent.channel.entity;

import java.io.Serializable;

/**
 * 渠道套餐关系表
 * @author weijialiang
 *
 */
public class ChannelProduct implements Serializable {

    private static final long serialVersionUID = 1466664487590619775L;
    private Integer id;            //id
    private Integer productId;     //产品或套餐id
    private Integer channelId;     //渠道id
    private Integer isShow;        //是否可见，0：不可见，1：可见
    private String proType;        //商品类型：商品类型：1-产品，2-套餐

    public ChannelProduct() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getIsShow() {
        return isShow;
    }

    public void setIsShow(Integer isShow) {
        this.isShow = isShow;
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType;
    }

    @Override
    public String toString() {
        return "ChannelProduct{" +
                "id=" + id +
                ", productId=" + productId +
                ", channelId=" + channelId +
                ", isShow=" + isShow +
                ", proType='" + proType + '\'' +
                '}';
    }
}
