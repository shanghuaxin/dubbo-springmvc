package com.agent.channel.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.enumeration.OperationType;
import com.agent.constant.Constant;
import com.agent.util.DateUtil;

/**
 * 渠道账户交易流水表
 * @author weijialiang
 *
 */
public class ChannelAccountTransaction implements Serializable{

    private static final long serialVersionUID = 8869478151567762358L;
    private Integer id;               //id
    private Integer channelId;        //渠道ID
    private String channelCode;       //渠道编号
    private Integer channelAccountId; //渠道账户ID
    private String msisdn;            //手机号码
    private String accountName;       //账户名称
    private Integer accountType;      //账户类型
    /**
     * 操作类型
     * 1：划拨进，2：直充(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)
     * 6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
     * 16:预开开卡扣款， 17：开卡扣款，18开卡冻结解冻扣款，19开卡退款,20开卡充值佣金，21充值佣金转划拨
     */
    private Integer operationType;
    private String transactionAccount;  //对方账户，交易账户
    private String transactionId;    //交易ID
    private String transactionType;  //交易归属的表名，用于判断transaction_id属于哪个表的主键
    private String transactionFlow;   //交易流水号
    private Integer payType;          //支付方式，1：银行卡支付，2：支付宝支付，3：微信支付，4：佣金转账
    private String payName;           //支付名称，1：银行卡支付，2：支付宝支付，3：微信支付，4：佣金转账
    private BigDecimal transactionMoney;      //交易金额（单位：分）
    private BigDecimal transactionMoneyReal;  //交易金额（含手续费，单位：分）
    private BigDecimal accountBalanceBefore;  //账户变更前余额（单位：分）
    private BigDecimal accountBalanceAfter;   //账户变更后余额（单位：分）
    private String remark;                 //交易备注
    private Integer operatorId;            //操作人ID
    private Date operationTime;            //操作时间
    
    //扩充字段
    private String name;            //对方账户名称，实际指操作人名称
    private String channelName;            //渠道名称
    private Integer channelLevel;          //渠道级别
    private Integer channelType;           //渠道类型
    private String channelIdName1;         //归属一级渠道名称
    private String channelIdName2;         //归属二级渠道名称
    // 充值佣金总额（单位：分）
    private BigDecimal rechargeBroTotalMoney;
    
    //时间筛选查询
    private Integer cTime;      //加值时间
    private String lastMonth;   //上月
    private String month;       //本月
    private String sDate;     //开始时间
    private String eDate;     //结束时间
    
    //分页
    private Integer pageIndex;       // 当前页
    private Integer pageSize;        // 页面大小
    private String startTimeStr;       //创建时间
    private String endTimeStr;       //创建时间
    
    public ChannelAccountTransaction() {
        super();
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public Integer getChannelAccountId() {
        return channelAccountId;
    }

    public void setChannelAccountId(Integer channelAccountId) {
        this.channelAccountId = channelAccountId;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public Integer getOperationType() {
        return operationType;
    }
    
    //operationType 操作类型：1：划拨进，2：直充(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
    public String getOperationName() {
        try {
            return OperationType.getName(operationType);
        } catch (Exception e) {
            return operationType + "";
        }
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public String getTransactionAccount() {
        return transactionAccount;
    }

    public void setTransactionAccount(String transactionAccount) {
        this.transactionAccount = transactionAccount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionFlow() {
        return transactionFlow;
    }

    public void setTransactionFlow(String transactionFlow) {
        this.transactionFlow = transactionFlow;
    }

    public Integer getPayType() {
        return payType;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public String getPayName() {
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName;
    }
    
    public BigDecimal getTransactionMoney() {
        return transactionMoney;
    }

    public void setTransactionMoney(BigDecimal transactionMoney) {
        this.transactionMoney = transactionMoney;
    }

    public BigDecimal getTransactionMoneyReal() {
        return transactionMoneyReal;
    }

    public void setTransactionMoneyReal(BigDecimal transactionMoneyReal) {
        this.transactionMoneyReal = transactionMoneyReal;
    }

    public BigDecimal getAccountBalanceBefore() {
        return accountBalanceBefore;
    }

    public void setAccountBalanceBefore(BigDecimal accountBalanceBefore) {
        this.accountBalanceBefore = accountBalanceBefore;
    }

    public BigDecimal getAccountBalanceAfter() {
        return accountBalanceAfter;
    }

    public void setAccountBalanceAfter(BigDecimal accountBalanceAfter) {
        this.accountBalanceAfter = accountBalanceAfter;
    }
    
    public String getTransactionMoneyYuan() {
        if(null != transactionMoney){
            return Constant.df0.format(transactionMoney.divide(Constant.cnt100));
        }
        return "";
    }
    
    public String getTransactionMoneyYuanStr() {
        if(null != transactionMoney){
            return transactionMoney.divide(Constant.cnt100).setScale(4, BigDecimal.ROUND_DOWN).toString();
        }
        return "";
    }
    
    public String getTransactionMoneyJSPYuan() {
        if(null != transactionMoney){
            if(operationType == 9 || operationType == 10 || operationType == 11 || operationType == 13 || operationType == 15 
                    || operationType == 16 || operationType == 17 || operationType == 18 || operationType == 23 || operationType == 24 || operationType == 25) {
                return "<font class='red'>-" + Constant.df0.format(transactionMoney.divide(Constant.cnt100)) + "</font>";
            }else {
                return Constant.df0.format(transactionMoney.divide(Constant.cnt100));
            }
        }
        return "";
    }
    
    public String getTransactionMoneyRealYuan() {
        if(null != transactionMoneyReal){
            return Constant.df0.format(transactionMoneyReal.divide(Constant.cnt100));
        }
        return "";
    }
    
    public String getAccountBalanceBeforeYuan() {
        if(null != accountBalanceBefore){
            return Constant.df0.format(accountBalanceBefore.divide(Constant.cnt100));
        }
        return "";
    }
    
    public String getAccountBalanceAfterYuan() {
        if(null != accountBalanceAfter){
            return Constant.df0.format(accountBalanceAfter.divide(Constant.cnt100));
        }
        return "";
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }

    public Date getOperationTime() {
        return operationTime;
    }
    
    public String getOperationTimeStr() {
        return DateUtil.getInstance().formatDate(operationTime, "yyyy-MM-dd HH:mm:ss");
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getChannelLevel() {
        return channelLevel;
    }
    
    public String getChannelLevelStr() {
        if(channelLevel == 1){
            return "一级渠道";
        }else if(channelLevel == 2 && channelType == 1){
            return "二级渠道";
        }else if(channelLevel == 2 && channelType == 2){
            return "直属网点";
        }else if(channelLevel == 3){
            return "三级网点";
        }
        
        return channelLevel.toString();
    }
    

    public void setChannelLevel(Integer channelLevel) {
        this.channelLevel = channelLevel;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }

    public String getChannelIdName1() {
        return channelIdName1;
    }

    public void setChannelIdName1(String channelIdName1) {
        this.channelIdName1 = channelIdName1;
    }

    public String getChannelIdName2() {
        return channelIdName2;
    }

    public void setChannelIdName2(String channelIdName2) {
        this.channelIdName2 = channelIdName2;
    }
    
    public String getChannelIDName() {
        if (channelLevel == 1) {
            return "--";
        }else if (channelLevel == 2) {
            return channelIdName1;
        }else if (channelLevel == 3) {
            return channelIdName1 + " / " + channelIdName2;
        }
        return "";
    }

    public BigDecimal getRechargeBroTotalMoney() {
        return rechargeBroTotalMoney;
    }
    
    public String getRechargeBroTotalMoneyYuan() {
        if (null != rechargeBroTotalMoney) {
            return rechargeBroTotalMoney.divide(Constant.cnt100).setScale(4, BigDecimal.ROUND_DOWN).toString();
        }
        return "";
    }

    public void setRechargeBroTotalMoney(BigDecimal rechargeBroTotalMoney) {
        this.rechargeBroTotalMoney = rechargeBroTotalMoney;
    }

    public Integer getcTime() {
        return cTime;
    }

    public void setcTime(Integer cTime) {
        this.cTime = cTime;
    }

    public String getLastMonth() {
        return lastMonth;
    }

    public void setLastMonth(String lastMonth) {
        this.lastMonth = lastMonth;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getsDate() {
        return sDate;
    }

    public void setsDate(String sDate) {
        this.sDate = sDate;
    }

    public String geteDate() {
        return eDate;
    }

    public void seteDate(String eDate) {
        this.eDate = eDate;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getStartTimeStr() {
        return startTimeStr;
    }

    public void setStartTimeStr(String startTimeStr) {
        this.startTimeStr = startTimeStr;
    }

    public String getEndTimeStr() {
        return endTimeStr;
    }

    public void setEndTimeStr(String endTimeStr) {
        this.endTimeStr = endTimeStr;
    }

    @Override
    public String toString() {
        return "ChannelAccountTransaction [id=" + id + ", channelId=" + channelId + ", channelCode=" + channelCode
                + ", channelAccountId=" + channelAccountId + ", msisdn=" + msisdn + ", accountName=" + accountName
                + ", accountType=" + accountType + ", operationType=" + operationType + ", transactionId="
                + transactionId + ", transactionType=" + transactionType + ", transactionFlow=" + transactionFlow
                + ", payType=" + payType + ", payName=" + payName + ", transactionMoney=" + transactionMoney
                + ", transactionMoneyReal=" + transactionMoneyReal + ", accountBalanceBefore=" + accountBalanceBefore
                + ", accountBalanceAfter=" + accountBalanceAfter + ", remark=" + remark + ", operatorId=" + operatorId
                + ", operationTime=" + operationTime + ", name=" + name + "]";
    }
    
}
