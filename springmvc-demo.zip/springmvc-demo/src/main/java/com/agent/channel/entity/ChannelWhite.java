package com.agent.channel.entity;

import java.io.Serializable;
import java.util.Date;

public class ChannelWhite implements Serializable {

    /**
     * 渠道白名单表
     * @author weijialiang
     */
    private static final long serialVersionUID = 1279046279354047774L;
    private Integer id;          //id
    private Integer channelId;   //渠道id
    private String channelName;  //渠道名称
    private String channelCode;  //渠道编码
    private int status;          //是否白名单，0：否，1：是
    private Integer createId;    //创建人员ID
    private Date createTime;     //创建时间
    private Integer updateId;    //最后修改人id
    private Date updateTime;     //修改时间

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ChannelWhite [id=" + id + ", channelId=" + channelId + ", channelName=" + channelName + ", channelCode="
                + channelCode + ", status=" + status + ", createId=" + createId + ", createTime=" + createTime
                + ", updateId=" + updateId + ", updateTime=" + updateTime + "]";
    }

}
