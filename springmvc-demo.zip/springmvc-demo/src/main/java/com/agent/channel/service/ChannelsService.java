package com.agent.channel.service;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.dto.ChannelAccountTransactionDTO;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.entity.ChannelAuth;
import com.agent.channel.entity.ChannelUser;
import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelAccountMapper;
import com.agent.channel.mapper.ChannelAuthMapper;
import com.agent.channel.mapper.ChannelCodeSequenceMapper;
import com.agent.channel.mapper.ChannelUserMapper;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.common.RestStatus;
import com.agent.number.service.NumberService;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.Utils;
import com.agent.order.entity.OrderDetail;
import com.agent.order.entity.PayTracode;
import com.agent.order.mapper.PayTracodeMapper;
import com.agent.order.service.OrderDetailService;
import com.agent.product.entity.ProductDefBro;
import com.agent.product.mapper.ProductDefBroMapper;
import com.agent.product.mapper.ProductMapper;
import com.agent.system.entity.User;
import com.agent.system.entity.UserRole;
import com.agent.system.mapper.UserMapper;
import com.agent.technology.entity.MsgPush;
import com.agent.technology.entity.NewsInfo;
import com.agent.technology.mapper.MsgPushMapper;
import com.agent.technology.mapper.NewsInfoMapper;
import com.agent.util.DateUtil;


@Transactional(rollbackFor=Exception.class)
@Service("channelsService")
public class ChannelsService {
    private static Logger logger = LoggerFactory.getLogger(ChannelsService.class);
    @Autowired
    private ChannelsMapper channelsMapper;
    @Autowired
    private ChannelAccountMapper channelAccountMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ChannelUserMapper channelUserMapper;
    @Autowired
    private ChannelCodeSequenceMapper channelCodeSequenceMapper; 
    @Autowired
    private ChannelAuthMapper channelAuthMapper; 
    @Autowired
    private ProductDefBroMapper productDefBroMapper;
    @Autowired
    private PayTracodeMapper payTracodeMapper;
    @Autowired
    private BusinessLogService logService;
    @Resource
    private ProductMapper proMapper;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private NumberService numberService;
    @Autowired
    private OrderDetailService orderDetailService;
    @Autowired
    private MsgPushMapper msgPushMapper;
    @Autowired
    private NewsInfoMapper newsInfoMapper;
    
    public List<Channels> listChannels(Map<String, Object> params) {
        return channelsMapper.listChannels(params);
    }
    
    public int countTotal(Map<String, Object> params) {
        return channelsMapper.countTotal(params);
    }
    
    public List<Channels> newListChannels(Map<String, Object> params) {
        return channelsMapper.newListChannels(params);
    }
    
    public int newCountTotal(Map<String, Object> params) {
        return channelsMapper.newCountTotal(params);
    }
    
    public List<Channels> newListChannelAccount(Map<String, Object> params) {
        return channelsMapper.newListChannelAccount(params);
    }
    
    public int newAccountCountTotal(Map<String, Object> params) {
        return channelsMapper.newAccountCountTotal(params);
    }
    
    public List<Channels> findThreeByProperty(Map<String, Object> params) {
        return channelsMapper.findThreeByProperty(params);
    }
    
    public int authThreeCountTotal(Map<String, Object> params) {
        return channelsMapper.authThreeCountTotal(params);
    }
    
    public Channels findById(Integer id){
        return channelsMapper.findById(id);
    }
    
    public Channels findByCode(String channelCode){
        return channelsMapper.findByCode(channelCode);
    }
    
    //根据开户渠道（编码）查找渠道ID
    public List<Integer> findByCodeOrName(String openChannelName){
        return channelsMapper.findByCodeOrName(openChannelName);
    }
    
    //根据渠道名称查找渠道ID
    public List<Integer> findByName(String channelName){
        return channelsMapper.findByName(channelName);
    }
    
    /**
     * @param channels
     * @throws InvocationTargetException 
     * @throws IllegalAccessException 
     */
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void saveChannel(Channels channels, User us) throws IllegalAccessException, InvocationTargetException, Exception {
        
        //创建用户
        User user = new User();
        user.setLoginName(channels.getLoginName());
        user.setNickName(channels.getChannelName());
        user.setPassword(DigestUtils.md5Hex(channels.getBussContactPhone().substring(channels.getBussContactPhone().length()-6, channels.getBussContactPhone().length())));
        user.setPasswordStatus(0);
        if(channels.getStatus() != 1){
            user.setStatus(0); 
        }else {
            user.setStatus(channels.getStatus());
        }
        user.setPhone(channels.getBussContactPhone());
        user.setEmail(channels.getEmail());
        user.setCreateId(channels.getCreateId());
        user.setCreateTime(channels.getCreateTime());
        
        userMapper.insert(user);
        
        channels.setCheckStatus(1);
        channels.setCheckComment("");
        channels.setCheckTime(new Date());
        channelsMapper.insert(channels);
        
        //记录操作日志
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("channelName",channels.getChannelName());
        logmap.put("channelCode",channels.getChannelCode());
        logmap.put("channelStr",channels.toString());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logService.businessSaveLog(Business.channel_add, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", "渠道新增",logmap);
        
        //创建渠道账户
        List<ChannelAccount> accounts = new ArrayList<ChannelAccount>();
        //创建划拨账户       
        ChannelAccount account2 = new ChannelAccount();
        account2.setChannelId(channels.getId());
        account2.setChannelIdLevel1(channels.getChannelIdLevel1());
        account2.setChannelIdLevel2(channels.getChannelIdLevel2());
        account2.setChannelCode(channels.getChannelCode());
        account2.setAccountType(2);
        account2.setAccountName("划拨账户");
        account2.setAccountBalance(BigDecimal.ZERO);
        account2.setFreezeBalance(BigDecimal.ZERO);
        //创建消费佣金账户
        ChannelAccount account4 = new ChannelAccount();
        //创建充值佣金账户
        ChannelAccount account5 = new ChannelAccount();
        //创建开卡账户
        ChannelAccount account1 = new ChannelAccount();
        //创建直充账户
        ChannelAccount account3 = new ChannelAccount();
        //创建直充佣金账户(移动)
        ChannelAccount account6 = new ChannelAccount();
        //创建直充佣金账户(联通)
        ChannelAccount account206 = new ChannelAccount();

        BeanUtils.copyProperties(account1, account2);
        BeanUtils.copyProperties(account3, account2);
        BeanUtils.copyProperties(account4, account2);
        BeanUtils.copyProperties(account5, account2);
        BeanUtils.copyProperties(account6, account2);
        BeanUtils.copyProperties(account206, account2);
     
        
        account3.setAccountType(3);
        account3.setAccountName("充值账户");
        
        account4.setAccountType(4);
        account4.setAccountName("消费佣金账户");
        
        account5.setAccountType(5);
        account5.setAccountName("充值佣金账户");
        
        account6.setAccountType(6);
        account6.setAccountName("直充佣金账户");
        
        account206.setAccountType(206);
        account206.setAccountName("直充佣金账户(联通)");
        
        accounts.add(account2);
        accounts.add(account3);
        accounts.add(account4);
        accounts.add(account5);
        accounts.add(account6);
        accounts.add(account206);
        if(channels.getChannelLevel() == 1){ 
            account1.setAccountType(1);
            account1.setAccountName("开卡账户");
            
            accounts.add(account1);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", accounts);
        channelAccountMapper.batchInsert(map);
        
        ChannelUser channelUser = new ChannelUser();
        channelUser.setChannelId(channels.getId());
        channelUser.setUserId(user.getId());
        channelUser.setType(1);
        channelUserMapper.insert(channelUser);
        
        UserRole userRole = new UserRole();
        userRole.setUserId(user.getId());
        if(channels.getChannelLevel() == 1){
            userRole.setRoleId(6);
        }else if(channels.getChannelLevel() == 2 && channels.getChannelType() == 1){
            userRole.setRoleId(7);
        }else{
            userRole.setRoleId(8);
        }
        
        List<UserRole> userRoleList = new ArrayList<UserRole>();
        userRoleList.add(userRole);
        
        userMapper.batchInsertUserRole(userRoleList);
        
        //渠道实名设置
        ChannelAuth channelAuth = new ChannelAuth();
        channelAuth.setChannelIdFrom(channels.getParentChannelId());
        channelAuth.setChannelCodeFrom(channels.getParentChannelCode());
        channelAuth.setChannelNameFrom(channels.getParentChannelName());
        channelAuth.setChannelIdTo(channels.getId());
        channelAuth.setChannelCodeTo(channels.getChannelCode());
        channelAuth.setChannelNameTo(channels.getChannelName());
        channelAuth.setCreateId(channels.getCreateId());
        channelAuth.setCreateTime(channels.getCreateTime());
        channelAuth.setUpdateId(channels.getUpdateId());
        channelAuth.setUpdateTime(channels.getUpdateTime());
        if(channels.getChannelLevel() == 1){
            channelAuth.setIsAuth(1);
            channelAuth.setIsReader(1);
            channelAuth.setIsUploadImg(0);
            channelAuth.setIsImg(0);
        }else{
            ChannelAuth auth = channelAuthMapper.findByChannelId(channels.getParentChannelId());
            if(auth != null){
                channelAuth.setIsAuth(auth.getIsAuth());
                channelAuth.setIsReader(auth.getIsReader());
                channelAuth.setIsUploadImg(auth.getIsUploadImg());
                channelAuth.setIsImg(auth.getIsImg());
            }else{
                channelAuth.setIsAuth(1); 
                channelAuth.setIsReader(1);
                channelAuth.setIsUploadImg(0);
                channelAuth.setIsImg(0);
            }
        }
        
        channelAuthMapper.insert(channelAuth);
        
        int tracode = 0;
        tracode = payTracodeMapper.selectMaxTracode();
        if(tracode < 200001){
            tracode = 200001;
        }else{
            tracode += 1;
        }
        //渠道交易码关系，主要适用于银行转账
        PayTracode payTracode = new PayTracode();
        payTracode.setUserId(user.getId());
        payTracode.setChannelId(channels.getId());
        payTracode.setTracode(String.valueOf(tracode));
        payTracode.setStatus("1");
        
        payTracodeMapper.insert(payTracode);
        
        //渠道佣金设置（当新增二级代理商时，设置佣金参数，设置默认佣金时，当网点审核通过时，在审核通过操作完成是设置网点默认佣金）
        if(channels.getChannelLevel().intValue() == 2 && channels.getChannelType().intValue() == 1){
            List<ProductDefBro> list = new ArrayList<ProductDefBro>();
            List<ProductDefBro> productDefBros = productDefBroMapper.findByChannelId(channels.getParentChannelId());
            if(productDefBros != null && productDefBros.size() > 0){
                for (ProductDefBro productDefBro : productDefBros) {
                    ProductDefBro bro = new ProductDefBro();
                    BeanUtils.copyProperties(bro, productDefBro);
                    bro.setChannelId(channels.getId());

                    list.add(bro);
                }
                productDefBroMapper.batchInsert(list);
            }
        }
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void modifyChannel(Channels channels, User us) throws Exception{
        
        //修改用户
        User user = userMapper.findUserByName(channels.getLoginName());
        user.setPassword(null);       //当密码设置为null时，修改用户属性不修改原来的密码
        user.setNickName(channels.getChannelName());
        user.setEmail(channels.getEmail());
        user.setPhone(channels.getBussContactPhone());
        
        userMapper.update(user);
        
        Channels channels2 = channelsMapper.findById(channels.getId());
        
        channels.setCheckStatus(4);
        channels.setCheckComment("重新提交资料");
        channels.setCheckTime(new Date());
        channelsMapper.update(channels);
        
        //记录操作日志
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("channelName",channels.getChannelName());
        logmap.put("channelCode",channels.getChannelCode());
        logmap.put("channelOldStr",channels2.toString());
        logmap.put("channelStr",channels.toString());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logService.businessSaveLog(Business.channel_update, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", "渠道修改",logmap);
        
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void resetPwd(Channels channels, User us) throws Exception {
        
        User user = userMapper.findUserByChannelId(channels.getId());
        user.setPassword(DigestUtils.md5Hex(channels.getBussContactPhone().substring(channels.getBussContactPhone().length()-6, channels.getBussContactPhone().length())));
        user.setPasswordStatus(0);

        userMapper.update(user);
        
        
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void frozenChannel(Channels channels, User us) throws Exception {
        
        if(StringUtils.isNoneBlank(channels.getIds())) {
            String[] idArr = channels.getIds().split(",");
            if(idArr != null && idArr.length > 0) {
                for (int i = 0; i < idArr.length; i++) {
                    Channels c = channelsMapper.findById(Integer.parseInt(idArr[i]));
                    c.setStatus(channels.getStatus());
                    c.setComment(channels.getComment());
                    
                    channelsMapper.updateStatus(c);
                    
                    Integer status = 1;       //解冻时，用户状态设置为正常
                    String logTypeStr = "渠道解冻";
                    String logType = Business.channel_unfrozen;
                    
                    userMapper.updateFrozen(status, c.getId());
                    
                    //记录操作日志
                    Map<String,String> logmap = new HashMap<String,String>();
                    logmap.put("staff", us.getLoginName());
                    logmap.put("channelName",c.getChannelName());
                    logmap.put("channelCode",c.getChannelCode());
                    logmap.put("reason",c.getComment());
                    logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                    logmap.put("result","成功！");
                    logService.businessSaveLog(logType, String.valueOf(us.getId()),us.getLoginName(),null != c.getId() ? String.valueOf(c.getId()) : "0", logTypeStr,logmap);
                }
            }
        }else {
            channelsMapper.updateStatus(channels);
            
            Integer status = 0;
            String logTypeStr = "渠道冻结";
            String logType = Business.channel_frozen;
            if(channels.getStatus() == 1){
                status = 1;       //解冻时，用户状态设置为正常
                logTypeStr = "渠道解冻";
                logType = Business.channel_unfrozen;
            }else if(channels.getStatus() == 3){
                status = 1;       //解冻时，用户状态设置为正常
                logTypeStr = "渠道解冻后，冻结开户";
                logType = Business.channel_unfrozen;
            }

            userMapper.updateFrozen(status, channels.getId());
            
            //记录操作日志
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("channelName",channels.getChannelName());
            logmap.put("channelCode",channels.getChannelCode());
            logmap.put("reason",channels.getComment());
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            logService.businessSaveLog(logType, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", logTypeStr,logmap);
        }
        
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void frozenAccount(Channels channels, User us) throws Exception {
        
        if(StringUtils.isNoneBlank(channels.getIds())) {
            String[] idArr = channels.getIds().split(",");
            if(idArr != null && idArr.length > 0) {
                for (int i = 0; i < idArr.length; i++) {
                    Channels c = channelsMapper.findById(Integer.parseInt(idArr[i]));
                    c.setStatus(channels.getStatus());
                    c.setOperationType(2);          //标记冻结开户、解冻开户
                    channelsMapper.updateStatus(c);
                    
                    String logTypeStr = "渠道解冻开户";
                    String logType = Business.channel_unfrozen_account;
                    //记录操作日志
                    Map<String,String> logmap = new HashMap<String,String>();
                    logmap.put("staff", us.getLoginName());
                    logmap.put("channelName",c.getChannelName());
                    logmap.put("channelCode",c.getChannelCode());
                    logmap.put("reason",c.getComment());
                    logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                    logmap.put("result","成功！");
                    logService.businessSaveLog(logType, String.valueOf(us.getId()),us.getLoginName(),null != c.getId() ? String.valueOf(c.getId()) : "0", logTypeStr,logmap);
                }
            }
        }else {
            channels.setOperationType(2);          //标记冻结开户、解冻开户
            channelsMapper.updateStatus(channels);
            
            String logTypeStr = "渠道冻结开户";
            String logType = Business.channel_frozen_account;
            if(channels.getStatus() == 1){
                logTypeStr = "渠道解冻开户";
                logType = Business.channel_unfrozen_account;
            }
            
            //记录操作日志
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("channelName",channels.getChannelName());
            logmap.put("channelCode",channels.getChannelCode());
            logmap.put("reason",channels.getComment());
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            logService.businessSaveLog(logType, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", logTypeStr,logmap);
        }
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public RestStatus BatchFrozenChannel(Channels channels, User us) throws Exception {
        
        String logTypeStr = "";
        String logType = "";
        
        //批量设置
        String[] idArr = channels.getIds().split(",");
        if(idArr != null && idArr.length > 0) {
            for (int i = 0; i < idArr.length; i++) {
                Channels c = null;
                if(channels.getStatus() == 4){
                    logTypeStr = "渠道冻结（批量）";
                    logType = Business.channel_frozen;
                    
                    c = channelsMapper.findById(Integer.parseInt(idArr[i]));
                    c.setStatus(channels.getStatus());
                    c.setComment(channels.getComment());
                    channelsMapper.updateStatus(c);
                    
                    Integer status = 0;
                    userMapper.updateFrozen(status, c.getId());
                }else {
                    logTypeStr = "渠道冻结开户(批量)";
                    logType = Business.channel_frozen_account;
                    
                    c = channelsMapper.findById(Integer.parseInt(idArr[i]));
                    c.setStatus(channels.getStatus());
                    c.setComment(channels.getComment());
                    c.setOperationType(2);
                    channelsMapper.updateStatus(c);
                }
                //记录操作日志
                Map<String,String> logmap = new HashMap<String,String>();
                logmap.put("staff", us.getLoginName());
                logmap.put("channelName",c.getChannelName());
                logmap.put("channelCode",c.getChannelCode());
                logmap.put("reason",c.getComment());
                logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                logmap.put("result","成功！");
                logService.businessSaveLog(logType, String.valueOf(us.getId()),us.getLoginName(),null != c.getId() ? String.valueOf(c.getId()) : "0", logTypeStr,logmap);
            }
        }else {
            return new RestStatus(Boolean.FALSE, "500", "批量冻结设置失败！");
        }
        
        return new RestStatus(Boolean.TRUE, "200", "批量冻结设置成功！");
    }
    
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void channelAuth(Channels channels, User us) throws Exception {
        
        if(channels.getStatus() == 1){   //当网点审核通过时，如果网点上级渠道状态为3：冻结开户、4：冻结时，更新网点状态与上级渠道状态一致
            Channels channels2 = channelsMapper.findByPid(channels.getId());
            if(channels2.getStatus() == 3 || channels.getStatus() == 4){
                channels.setStatus(channels.getStatus());
            }
            
            //网点审核通过后，增加网点佣金设置
            List<ProductDefBro> list = new ArrayList<ProductDefBro>();
            //通过渠道id查找渠道
            Channels c = channelsMapper.findById(channels.getId());
            List<ProductDefBro> productDefBros = productDefBroMapper.findByChannelId(c.getParentChannelId());
            if(productDefBros != null && productDefBros.size() > 0){
                for (ProductDefBro productDefBro : productDefBros) {
                    ProductDefBro bro = new ProductDefBro();
                    BeanUtils.copyProperties(bro, productDefBro);
                    bro.setChannelId(channels.getId());

                    list.add(bro);
                }
                productDefBroMapper.batchInsert(list);
            }
        }
        
        channels.setAuthTime(new Date());    //设置审核时间
        channelsMapper.channelAuth(channels);
        
        if(channels.getStatus() == 1){
            User user = userMapper.findUserByName(channels.getLoginName());
            
            user.setStatus(1);            //当网点审核通过时，用户状态设置为正常
            user.setPassword(null);       //当密码设置为null时，修改用户属性不修改原来的密码
            userMapper.update(user);
        }
        
        Channels channel = channelsMapper.findById(channels.getId());
        
        //记录操作日志
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("channelName",channel.getChannelName());
        logmap.put("channelCode",channel.getChannelCode());
        logmap.put("reason",channels.getAuthComment());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        String newsStr = "审核不通过！原因："+channels.getAuthComment();
        if(channels.getStatus() == 1){
            logmap.put("result","审核通过！");
            newsStr = "审核通过！";
        }else{
            logmap.put("result","审核不通过！");
        }
        
        try {
            NewsInfo newsInfo = new NewsInfo();
            newsInfo.setNewsType("1");
            newsInfo.setTitle("新增渠道审核");
            newsInfo.setContent("渠道："+channel.getChannelName()+" 上级"+newsStr);
            newsInfo.setCreateTime(new Date());
            newsInfo.setIsRead("0");
            newsInfo.setTargetId(us.getId());
            newsInfoMapper.insert(newsInfo);
            
            MsgPush m = new MsgPush();
            m.setNoticeId(newsInfo.getId());
            m.setNoticeType("t_news_info");
            m.setTitle(newsInfo.getTitle());
            m.setContent(newsInfo.getContent());
            m.setUserId(us.getId());
            m.setStatus("0");
            msgPushMapper.insert(m);
        } catch (Exception e) {
            logger.error("渠道："+channel.getChannelName()+"审核，记录消息出错，原因："+e.getMessage(),e);
            e.printStackTrace();
        }

        logService.businessSaveLog(Business.channel_auth, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", "网点审核",logmap);
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void channelCheck(Channels channels, User us) throws Exception {
        
        channels.setCheckTime(new Date());    //设置稽查时间
        channelsMapper.channelCheck(channels);
        
    }
    
    //总部加值界面（账户记录--加值）
    //操作类型：1：划拨进，2：直充，3：纠正进，4：开卡，5：充值，6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public RestStatus saveAccountJz (Channels channels, Integer id, String transactionAccount, User user) throws Exception {
        synchronized (ChannelsService.class) {
            RestStatus restStatus = new RestStatus(Boolean.TRUE);
            //operationType =2 表示加值

            // 构造takeMoney入参
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("channels", channels);
            param.put("number", null);
            param.put("channelId", channels.getId());
            param.put("accountType", channels.getAccount_type());
            param.put("operationType", 2);
            param.put("money", channels.getAccountBalanceHb());
            param.put("busMoney", channels.getAccountBalanceHb());
            param.put("remark", channels.getComment());
            param.put("transactionAccount", transactionAccount);
            param.put("transId", channels.getTransactionId());
            param.put("transactionType", null);
            param.put("calcType", "+");
            param.put("transactionFlow", null);
            param.put("payType", null);
            param.put("us", user);
            restStatus = numberService.takeMoney(param);
            
            return restStatus;
        }
    }
    
    //总部纠正界面（账户记录--纠正）
    //操作类型：1：划拨进，2：直充，3：纠正进，4：开卡，5：充值，6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public RestStatus saveAccountCor (Channels channels, Integer id, String transactionAccount, User user) throws Exception {
        synchronized (ChannelsService.class) {
            RestStatus restStatus = new RestStatus(Boolean.TRUE);
            //operationType =10 表示纠正出

            // 构造takeMoney入参
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("channels", channels);
            param.put("number", null);
            param.put("channelId", channels.getId());
            param.put("accountType", channels.getAccount_type());
            param.put("operationType", 10);
            param.put("money", channels.getAccountBalanceHb());
            param.put("busMoney", channels.getAccountBalanceHb());
            param.put("remark", channels.getComment());
            param.put("transactionAccount", transactionAccount);
            param.put("transId", channels.getTransactionId());
            param.put("transactionType", null);
            param.put("calcType", "-");
            param.put("transactionFlow", null);
            param.put("payType", null);
            param.put("us", user);
            restStatus = numberService.takeMoney(param);
            
            return restStatus;
        }
    }
    
    //操作类型：1：划拨进，2：直充，3：纠正进，4：开卡，5：充值，6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public RestStatus saveAccountHb(Channels channels, Integer id, String transactionAccount, User user) throws Exception {
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("channels", channels);
        param.put("transactionAccount", transactionAccount);
        param.put("us", user);
        param.put("operationType", 9);
        param.put("money", channels.getAccountBalanceHb());
        RestStatus restStatus = numberService.takeMoney(param);
        return restStatus;
    }
    
    //操作类型：1：划拨进，2：直充，3：纠正进，4：开卡，5：充值，6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public RestStatus saveAccountCorrect(Channels channels, Integer id, String transactionAccount, User user) throws Exception {
        // 构造takeMoney入参
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("channels", channels);
        param.put("number", null);
        param.put("channelId", channels.getId());
        param.put("accountType", 2);
        param.put("operationType", 10);
        param.put("money", channels.getAccountBalanceHb());
        param.put("busMoney", channels.getAccountBalanceHb());
        param.put("remark", "上级纠正(下级扣款)");
        param.put("transactionAccount", transactionAccount);
        param.put("transId", channels.getTransactionId());
        param.put("transactionType", null);
        param.put("calcType", "-");
        param.put("transactionFlow", null);
        param.put("payType", null);
        param.put("us", user);
        param.put("isAgent", "1");
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        restStatus = numberService.takeMoney(param);
        if(!restStatus.getStatus()){
            return new RestStatus(Boolean.FALSE, "500", restStatus.getErrorMessage());
        }
        
        /*if(channels.getParentChannelId() != null){
            String transAccount = "[" + channels.getChannelCode() + "] " + channels.getChannelName();
            param.put("channels", channels);
            param.put("number", null);
            param.put("channelId", channels.getParentChannelId());
            param.put("accountType", 2);
            param.put("operationType", 3);
            param.put("money", channels.getAccountBalanceHb());
            param.put("busMoney", channels.getAccountBalanceHb());
            param.put("remark", "上级纠正(上级加款)");
            param.put("transactionAccount", transAccount);
            param.put("transId", null);
            param.put("transactionType", null);
            param.put("calcType", "+");
            param.put("transactionFlow", null);
            param.put("payType", null);
            param.put("us", user);
            restStatus = numberService.takeMoney(param);
        }*/
        return restStatus;
    }
    
    /**
     * 渠道佣金设置
     * @param productDefBro
     * @param id
     */
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void brokeragesetting(ProductDefBro productDefBro, User us) throws Exception {
        
        //查找下级代理商或网点
        List<Channels> channelList = new ArrayList<Channels>();
        Channels channels = channelsMapper.findById(productDefBro.getChannelId());
        if(channels.getChannelLevel().intValue() == 1){
            channelList = channelsMapper.findChannelDetailByChannelIdLevel1(channels.getId(), null);
        }else if(channels.getChannelLevel().intValue() == 2 && channels.getChannelType().intValue() == 1){
            channelList = channelsMapper.findChannelDetailByChannelIdLevel2(channels.getId(), 3);
        }
        
        //批量新增渠道产品佣金设置
        List<ProductDefBro> batchInsert = new ArrayList<ProductDefBro>();

        Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
        String proType = "";
        String brokerage = "";
        String productName = "";
        //批量删除Id
        List<Integer> chIds = new ArrayList<Integer>();
        
        if(StringUtils.isNoneBlank(productDefBro.getCool1701())){
            String[] cool1701Arr = productDefBro.getCool1701().split(";");
            if(cool1701Arr != null && cool1701Arr.length > 0){
                for (String cool1701Str : cool1701Arr) {
                    String[] cool1701 = cool1701Str.split(":");
                    Integer productId = Integer.valueOf(cool1701[0].substring(0, cool1701[0].lastIndexOf("_")));
                    
                    //获取该产品二级渠道佣金设置
                    BigDecimal channelBro2 = BigDecimal.ZERO;
                    String[] cool1702Arr = productDefBro.getCool1702().split(";");
                    if(cool1702Arr != null && cool1702Arr.length > 0){
                        for (String cool1702Str : cool1702Arr) {
                            String[] cool1702 = cool1702Str.split(":");
                            Integer productId2 = Integer.valueOf(cool1702[0].substring(0, cool1702[0].lastIndexOf("_")));
                            if(productId.intValue() == productId2.intValue()){
                                channelBro2 = new BigDecimal(cool1702[1]);
                            }
                        }
                    }
                    
                    //获取该产品三级渠道佣金设置
                    BigDecimal channelBro3 = BigDecimal.ZERO;
                    String[] cool1703Arr = productDefBro.getCool1703().split(";");
                    if(cool1703Arr != null && cool1703Arr.length > 0){
                        for (String cool1703Str : cool1703Arr) {
                            String[] cool1703 = cool1703Str.split(":");
                            Integer productId3 = Integer.valueOf(cool1703[0].substring(0, cool1703[0].lastIndexOf("_")));
                            if(productId.intValue() == productId3.intValue()){
                                channelBro3 = new BigDecimal(cool1703[1]);
                            }
                        }
                    }
                    
                    //商品类型：商品类型：1-产品，2-套餐
                    ProductDefBro bro = null;
                    
                    if(StringUtils.equals(productDefBro.getProType(), "1")){
                        List<ProductDefBro> list = productDefBroMapper.findByChannelIdAndProductId(productDefBro.getChannelId(), productId);
                        if(list != null && list.size() > 0){
                            bro = list.get(0);
                            productName = bro.getProductName()+"(" + bro.getProductCode() + ")";
                            brokerage = brokerage + "[一级佣金：" + new BigDecimal(cool1701[1]) + "%,二级佣金:" + channelBro2 + "%,三级佣金:" + channelBro3 + "%],";
                        }
                    }else {
                        bro = productDefBroMapper.select(productId);
                    }
                    if(bro == null){
                        bro = new ProductDefBro();
                        bro.setProductId(productId);
                        bro.setChannelId(productDefBro.getChannelId());
                        bro.setChannelBro1(new BigDecimal(cool1701[1]));
                        bro.setChannelBro2(channelBro2);
                        bro.setChannelBro3(channelBro3);
                        bro.setProType(productDefBro.getProType());//商品类型：商品类型：1-产品，2-套餐
//                        bro.setServType(servType);
                        bro.setCreateId(us.getId());
                        bro.setCreateTime(newDate);
                        bro.setUpdateId(us.getId());
                        bro.setUpdateTime(newDate);
                        batchInsert.add(bro);
                        
                        chIds.add(bro.getChannelId());
                    }else{
                        bro.setId(productId);
                        bro.setChannelBro1(new BigDecimal(cool1701[1]));
                        bro.setChannelBro2(channelBro2);
                        bro.setChannelBro3(channelBro3);
                        bro.setProType(productDefBro.getProType());//商品类型：商品类型：1-产品，2-套餐
                        bro.setUpdateId(us.getId());
                        bro.setUpdateTime(newDate);
                        batchInsert.add(bro);
                        
                        chIds.add(bro.getChannelId());
                        
                        //日志记录
                        brokerage = brokerage + "{";
                        if(StringUtils.equals(bro.getServType(), "201")){
                            brokerage = brokerage + "[170语音：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "208")){
                            brokerage = brokerage + "[套餐低消：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "209")){
                            brokerage = brokerage + "[来电显示：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "202")){
                            brokerage = brokerage + "[短信：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "205")){
                            brokerage = brokerage + "[流量包：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "210")){
                            brokerage = brokerage + "[来电提醒：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "203")){
                            brokerage = brokerage + "[彩信：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "206")){
                            brokerage = brokerage + "[套餐月租：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }else if(StringUtils.equals(bro.getServType(), "204")){
                            brokerage = brokerage + "[套餐外流量：一级佣金：" + bro.getChannelBro1() + "%,二级佣金:" + bro.getChannelBro2() + "%,三级佣金:" +bro.getChannelBro3() + "%],";
                        }
                        if(brokerage.lastIndexOf(",") == brokerage.length() - 1) {
                            brokerage = brokerage.substring(0, brokerage.length() - 1);
                        }
                        brokerage = brokerage + "}";
                    }
                    
                    //修改下级佣金设置（注意，此处需要先批量删除下级佣金设置）
                    if(channelList != null && channelList.size() > 0){
                        for (Channels c : channelList) {
                            ProductDefBro defBro = new ProductDefBro();
                            
                            BeanUtils.copyProperties(defBro, bro);
                            defBro.setChannelId(c.getId());
                            
                            batchInsert.add(defBro);
                            
                            chIds.add(defBro.getChannelId());
                        }
                    }
                    
                    if(bro.getProType().equals("2")){
                        proType = "套餐";
                    }else {
                        proType = "产品";
                    }
                }
            }
        }
        
        if(batchInsert != null && batchInsert.size() > 0){
            //先批量删除，在批量插入
            productDefBroMapper.batchDeleteByChIds(chIds, productDefBro.getProductId(), productDefBro.getProType());
            
            //佣金设置表分批入库
            Integer dataCount = batchInsert.size();
            int page = 0;//页数
            int pageCount = 10000;
            if(dataCount > pageCount){
                if(dataCount%pageCount !=0){
                    page = dataCount/pageCount +1;
                }else{
                    page = dataCount/pageCount;
                }
                int start=0,end=0;
                for (int i = 1; i <= page; i++) {
                    if (i * pageCount > dataCount) {
                        end = dataCount;
                    } else {
                        end = i * pageCount;
                    }
                    if (i == 1) {
                        start = i - 1;
                    } else {
                        start = (i - 1) * pageCount;
                    }
                    insertSaveBrokerage(batchInsert, start, end);
                }
            }else {
                insertSaveBrokerage(batchInsert, 0, dataCount);
            }
            
//            productDefBroMapper.batchInsert(batchInsert);
        }
        
        Map<String, String> map = new HashMap<String, String>();
        map.put("staff", us.getLoginName());
        map.put("channelName", channels.getChannelName());
        map.put("channelCode", channels.getChannelCode());
        map.put("proType", proType);
        map.put("productName", productName);
        map.put("brokerage", brokerage);
        map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
        map.put("result", "佣金设置操作完成！");
        logService.businessSaveLog(Business.channel_brokerage_setting, String.valueOf(us.getId()), us.getLoginName(), "",
                "渠道佣金设置", map);
    }
    
    /**
     * 渠道佣金设置
     * @param productDefBro
     * @param us
     */
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void czbrokeragesetting(ProductDefBro productDefBro, User us) throws Exception {

        //查找下级代理商或网点
        List<Channels> channelList = new ArrayList<Channels>();
        Channels channels = channelsMapper.findById(productDefBro.getChannelId());
        if(channels.getChannelLevel().intValue() == 1){
            channelList = channelsMapper.findChannelDetailByChannelIdLevel1(channels.getId(), null);
        }else if(channels.getChannelLevel().intValue() == 2 && channels.getChannelType().intValue() == 1){
            channelList = channelsMapper.findChannelDetailByChannelIdLevel2(channels.getId(), 3);
        }
        //批量新增渠道产品佣金设置--流量
        List<ProductDefBro> batchInsert = new ArrayList<ProductDefBro>();

        //批量删除Id
        List<Integer> chIds = new ArrayList<Integer>();
        
        Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
        productDefBro.setCreateId(us.getId());
        productDefBro.setCreateTime(newDate);
        productDefBro.setUpdateId(us.getId());
        productDefBro.setUpdateTime(newDate);
        
        //流量充值佣金
        List<ProductDefBro> bros = productDefBroMapper.findCZByChannelIdAndProductId(productDefBro.getChannelId(), 0,"3");//商品类型：1-产品，2-套餐， 3-流量充值佣金，4-170话费佣金
        if(bros != null && bros.size() > 0){
            productDefBro.setId(bros.get(0).getId());
            productDefBro.setProType("3");
            productDefBro.setProductId(0);
            batchInsert.add(productDefBro);
            
            chIds.add(productDefBro.getChannelId());
        }else{
            productDefBro.setProType("3");
            productDefBro.setProductId(0);
            batchInsert.add(productDefBro);
            
            chIds.add(productDefBro.getChannelId());
        }
        
        if(channelList != null && channelList.size() > 0){
            for (Channels c : channelList) {
                ProductDefBro defBro = new ProductDefBro();
                
                BeanUtils.copyProperties(defBro, productDefBro);
                defBro.setChannelId(c.getId());
                
                batchInsert.add(defBro);
                
                chIds.add(defBro.getChannelId());
            }
        }
        
        
        if(batchInsert != null && batchInsert.size() > 0){
            // 先批量删除，在批量插入
            productDefBroMapper.batchDeleteByChIds(chIds, 0, "3");  
            
            // 佣金设置表分批入库
            Integer dataCount = batchInsert.size();
            int page = 0;//页数
            int pageCount = 10000;
            if(dataCount > pageCount){
                if(dataCount%pageCount !=0){
                    page = dataCount/pageCount +1;
                }else{
                    page = dataCount/pageCount;
                }
                int start=0,end=0;
                for (int i = 1; i <= page; i++) {
                    if (i * pageCount > dataCount) {
                        end = dataCount;
                    } else {
                        end = i * pageCount;
                    }
                    if (i == 1) {
                        start = i - 1;
                    } else {
                        start = (i - 1) * pageCount;
                    }
                    insertSaveBrokerage(batchInsert, start, end);
                }
            }else {
                insertSaveBrokerage(batchInsert, 0, dataCount);
            }
        }
        
        if(channelList != null && channelList.size() > 0){
            for (Channels c : channelList) {
                ProductDefBro defBro = new ProductDefBro();
                
                BeanUtils.copyProperties(defBro, productDefBro);
                defBro.setChannelId(c.getId());
                
                batchInsert.add(defBro);
                
                chIds.add(defBro.getChannelId());
            }
        }
        
        // 话费充值佣金
        List<ProductDefBro> bros170 = productDefBroMapper.findCZByChannelIdAndProductId(productDefBro.getChannelId(), 0,"4");//商品类型：1-产品，2-套餐， 3-流量充值佣金，4-170话费佣金， 5-联通流量充值佣金，6-联通170话费佣金
        batchInsert = new ArrayList<ProductDefBro>();
        if(bros170 != null && bros170.size() > 0){
            productDefBro.setId(bros170.get(0).getId());
            productDefBro.setProType("4");
            productDefBro.setProductId(0);
            productDefBro.setChannelBro1(productDefBro.getChannelBro4());
            productDefBro.setChannelBro2(productDefBro.getChannelBro5());
            productDefBro.setChannelBro3(productDefBro.getChannelBro6());
            batchInsert.add(productDefBro);
        }else{
            productDefBro.setProType("4");
            productDefBro.setProductId(0);
            productDefBro.setChannelBro1(productDefBro.getChannelBro4());
            productDefBro.setChannelBro2(productDefBro.getChannelBro5());
            productDefBro.setChannelBro3(productDefBro.getChannelBro6());
            batchInsert.add(productDefBro);
        }
        
        if(channelList != null && channelList.size() > 0){
            for (Channels c : channelList) {
                ProductDefBro defBro = new ProductDefBro();
                
                BeanUtils.copyProperties(defBro, productDefBro);
                defBro.setChannelId(c.getId());
                
                batchInsert.add(defBro);
            }
        }
        
        if (batchInsert != null && batchInsert.size() > 0) {
            // 先批量删除，在批量插入
            productDefBroMapper.batchDeleteByChIds(chIds, 0, "4");
            
            // 佣金设置表分批入库
            Integer dataCount = batchInsert.size();
            int page = 0;//页数
            int pageCount = 10000;
            if (dataCount > pageCount){
                if (dataCount%pageCount !=0) {
                    page = dataCount/pageCount +1;
                } else {
                    page = dataCount/pageCount;
                }
                int start=0,end=0;
                for (int i = 1; i <= page; i++) {
                    if (i * pageCount > dataCount) {
                        end = dataCount;
                    } else {
                        end = i * pageCount;
                    }
                    if (i == 1) {
                        start = i - 1;
                    } else {
                        start = (i - 1) * pageCount;
                    }
                    insertSaveBrokerage(batchInsert, start, end);
                }
            } else {
                insertSaveBrokerage(batchInsert, 0, dataCount);
            }
        }
    }
    
    /**
     * 佣金记录表设置
     * @param bros
     * @throws Exception
     */
    public void insertSaveBrokerage(List<ProductDefBro> bros,int start,int end) throws Exception{
        List<ProductDefBro> saveList = new ArrayList<ProductDefBro>();
        for (int i = start; i < end; i++) {
            saveList.add(bros.get(i));
        }
        if(saveList.size() >0){
            productDefBroMapper.batchInsert(saveList);
        }
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = false)
    public void realnameSetting(Channels channels, User us) throws Exception {
        
        Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
        
        if(StringUtils.isNotBlank(channels.getIds())){ 
            String channelNameStr ="";
            String channelCodeStr = "";
            
            //批量设置
            String[] idArr = channels.getIds().split(",");
            if(idArr.length > 0) {
                for (int i = 0; i < idArr.length; i++) {
                    Channels channel = channelsMapper.findById(Integer.parseInt(idArr[i]));
                    if(i < idArr.length - 1){
                        channelNameStr += channel.getChannelName() + ",";
                        channelCodeStr += channel.getChannelCode() + ",";
                    }else {
                        channelNameStr += channel.getChannelName();
                        channelCodeStr += channel.getChannelCode();
                    }
                    ChannelAuth channelAuth = channelAuthMapper.findByChannelId(channel.getId());
                    if(channelAuth == null){
                        channelAuth = new ChannelAuth();
                        channelAuth.setChannelIdFrom(channel.getParentChannelId());
                        channelAuth.setChannelCodeFrom(channel.getParentChannelCode());
                        channelAuth.setChannelNameFrom(channel.getParentChannelName());
                        channelAuth.setChannelIdTo(channel.getId());
                        channelAuth.setChannelCodeTo(channel.getChannelCode());
                        channelAuth.setChannelNameTo(channel.getChannelName());
                        channelAuth.setCreateId(us.getId());
                        channelAuth.setCreateTime(newDate);
                    }
                    
                    
                    channelAuth.setIsAuth(channels.getOpenCardAnth());
                    channelAuth.setIsReader(1);
                    channelAuth.setIsImg(channels.getOpenAccountMode());
                    channelAuth.setIsAppImg(channels.getAppImg());
                    channelAuth.setIsAppFace(channels.getAppFace());
                    channelAuth.setUpdateId(us.getId());
                    channelAuth.setUpdateTime(newDate);
                    
                    if(channelAuth.getId() == null){
                        channelAuthMapper.insert(channelAuth);
                        //批量更新已有实名设置的下级渠道的实名设置信息
                        channelAuthMapper.batchUpdateChildAuth(channelAuth);
                        //批量插入未设置实名设置的下级渠道的实名设置信息
                        channelAuthMapper.batchInsertChildAuth(channelAuth.getChannelIdTo());
                        
                    }else{
                        channelAuthMapper.update(channelAuth);
                        //批量更新已有实名设置的下级渠道的实名设置信息
                        channelAuthMapper.batchUpdateChildAuth(channelAuth);
                        //批量插入未设置实名设置的下级渠道的实名设置信息
                        channelAuthMapper.batchInsertChildAuth(channelAuth.getChannelIdTo());
                    }
                    
                }
                String openCardAnth = "";
                String openAccountMode = "";
                
                if(channels.getOpenCardAnth() == 1){
                    openCardAnth = "开户时审核";
                }else{
                    openCardAnth = "开户后复查";
                }
                
                // 阅读器是始终开启的
                openAccountMode = "阅读器识别";
                if(channels.getOpenAccountMode() == 1){
                    openAccountMode = "照片识别";
                }
                /*if(channels.getOpenAccountMode() == 1){
                    openAccountMode = "阅读器识别";
                }else if(channels.getOpenAccountMode() == 2){
                    openAccountMode = "照片识别";
                }*/
                Map<String,String> logmap = new HashMap<String,String>();
                logmap.put("staff",us.getLoginName());
                logmap.put("channelName",channelNameStr);
                logmap.put("channelCode",channelCodeStr);
                logmap.put("openCardAnth",openCardAnth);
                logmap.put("openAccountMode",openAccountMode);
                logmap.put("createDate",DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                logmap.put("result","批量实名设置成功");
                
                logService.businessSaveLog(Business.channel_realname_setting, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", "（批量）实名设置",logmap);
            }
            
        }else {
            
            ChannelAuth channelAuth = channelAuthMapper.findByChannelId(channels.getId());
            if(channelAuth == null){
                channelAuth = new ChannelAuth();
                channelAuth.setChannelIdFrom(channels.getParentChannelId());
                channelAuth.setChannelCodeFrom(channels.getParentChannelCode());
                channelAuth.setChannelNameFrom(channels.getParentChannelName());
                channelAuth.setChannelIdTo(channels.getId());
                channelAuth.setChannelCodeTo(channels.getChannelCode());
                channelAuth.setChannelNameTo(channels.getChannelName());
                channelAuth.setCreateId(us.getId());
                channelAuth.setCreateTime(newDate);
            }
            
            String openCardAnth = "";
            String openAccountMode = "";
            
            channelAuth.setIsAuth(channels.getOpenCardAnth());
            openCardAnth = "开户时审核";
            if(channels.getOpenCardAnth() == 0){
                openCardAnth = "开户后复查";
            }
            channelAuth.setIsReader(1);
            channelAuth.setIsImg(channels.getOpenAccountMode());
            channelAuth.setIsAppImg(channels.getAppImg());
            channelAuth.setIsAppFace(channels.getAppFace());
            openAccountMode = "阅读器识别";
            if(channels.getOpenAccountMode() == 1){
                openAccountMode = "照片识别";
            }
            /*if(channels.getOpenCardAnth() == 1){
                channelAuth.setIsAuth(1);
                openCardAnth = "开户时审核";
            }else{
                channelAuth.setIsAuth(0);
                openCardAnth = "开户后复查";
            }
            if(channels.getOpenAccountMode() == 1){
                channelAuth.setIsReader(1);
                channelAuth.setIsUploadImg(0);
                channelAuth.setIsImg(0);
                openAccountMode = "阅读器识别";
            }else if(channels.getOpenAccountMode() == 2){
                channelAuth.setIsReader(1);
                channelAuth.setIsUploadImg(0);
                channelAuth.setIsImg(1);
                openAccountMode = "照片识别";
            }*/
            channelAuth.setUpdateId(us.getId());
            channelAuth.setUpdateTime(newDate);
            
            if(channelAuth.getId() == null){
                channelAuthMapper.insert(channelAuth);
                //批量更新已有实名设置的下级渠道的实名设置信息
                channelAuthMapper.batchUpdateChildAuth(channelAuth);
                //批量插入未设置实名设置的下级渠道的实名设置信息
                channelAuthMapper.batchInsertChildAuth(channelAuth.getChannelIdTo());
                
            }else{
                channelAuthMapper.update(channelAuth);
                //批量更新已有实名设置的下级渠道的实名设置信息
                channelAuthMapper.batchUpdateChildAuth(channelAuth);
                //批量插入未设置实名设置的下级渠道的实名设置信息
                channelAuthMapper.batchInsertChildAuth(channelAuth.getChannelIdTo());
            }
            
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff",us.getLoginName());
            logmap.put("channelName",channels.getChannelName());
            logmap.put("channelCode",channels.getChannelCode());
            logmap.put("openCardAnth",openCardAnth);
            logmap.put("openAccountMode",openAccountMode);
            logmap.put("createDate",DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功");
            
            logService.businessSaveLog(Business.channel_realname_setting, String.valueOf(us.getId()),us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", "实名设置",logmap);
        }
        
    }
    
    public Channels findChannelByCodeAndPid(String channelCode, String channelId){
        return channelsMapper.findChannelByCodeAndPid(channelCode, channelId);
    }
    
    /**
     * 渠道查找下级渠道总个数
     * @param channelId  当前渠道ID
     * @param channelLevel   查找的渠道级别
     * @param level    当前渠道级别 ,level=0表示是总部人员
     * @return
     */
    public Integer findChannelByChannelIdLevel(Integer channelId, Integer channelLevel, Integer level){
        if(level == 1 || level == 0){
            return channelsMapper.findChannelByChannelIdLevel1(channelId, channelLevel);
        }
        return channelsMapper.findChannelByChannelIdLevel2(channelId, channelLevel);
    }
    
    /**
     * 渠道查找下级渠道详情
     * @param channelId  当前渠道ID
     * @param channelLevel   查找的渠道级别
     * @param level    当前渠道级别 ,level=0表示是总部人员
     * @return
     */
    public List<Channels> findChannelDetailByChannelIdLevel(Integer channelId, Integer channelLevel, Integer level){
        if(level == 1 || level == 0){
            return channelsMapper.findChannelDetailByChannelIdLevel1(channelId, channelLevel);
        }
        return channelsMapper.findChannelDetailByChannelIdLevel2(channelId, channelLevel);
    }
    
    /*
     * 充值账户-->充值-->网点人员 
     * */
    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public void addRechargeSimServiceSelf(String orderNo, int uid, int id, String moneyNum) throws Exception {

            if(Utils.isEmptyString(moneyNum)){
                return;
            }
            Channels channels = channelsMapper.findById(id); 
            channels.setId(id);
            BigDecimal moneyaaa = new BigDecimal(moneyNum);
            if(moneyaaa.doubleValue()<=0){
                throw new Exception("直充账户充值必须大于0");
            }
            
            // 构造takeMoney入参
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("number", null);
            param.put("channelId", id);
            param.put("accountType", 3);
            param.put("operationType", 2);
            param.put("money", moneyaaa);
            param.put("busMoney", moneyaaa);
            param.put("remark", "代理商加值");
            param.put("transactionAccount", "总部加值：系统加值");
            param.put("transId", null);
            param.put("transactionType", null);
            param.put("calcType", "+");
            param.put("transactionFlow", orderNo);
            param.put("payType", 1);
            param.put("us", null);
            numberService.takeMoney(param);
    }  
    
    
    /**
     * 渠道查找下级渠道总个数
     * @param channelId  当前渠道ID
     * @param channelLevel  当前渠道级别
     * @return
     */
    public Integer findThreeChannelByChannelId(Integer channelId, Integer channelLevel){
        return channelsMapper.findThreeChannelByChannelId(channelId, channelLevel);
    }
    
    
    //根据登录用户获取渠道信息(公共接口)
    public Channels findChannelByUserId(Integer userId){
        Channels channels = channelsMapper.findByUserId(userId);
        User user = userMapper.select(userId);
        // 如果是用户登录，则需要根据用户的归属渠道ID获取渠道信息
        if (null==channels && null!=user && null!=user.getBelongChannelId()) {
            channels = channelsMapper.findById(user.getBelongChannelId());
        }
        if(null == channels){
            return null;
        }
        return channels;
    }
    
    /**
     * 根据登录用户获取用户类别(公共接口)
     * @param user
     * @return 0:总部员工， 1：渠道， 2：渠道员工
     */
    public int findUserTypeByUser(User user){
        Channels channels = channelsMapper.findByUserId(user.getId());
        // 如果是用户登录，则需要根据用户的归属渠道ID获取渠道信息
        if (null==channels && null!=user && null!=user.getBelongChannelId()) {
            channels = channelsMapper.findById(user.getBelongChannelId());
        }
        if(null == channels && user.getChannelId() == null){
            return 0;   
        }else if(null == channels && user.getChannelId() != null) {
            return 2;   
        }
        return 1;   
    }
    
    /**
     * 渠道编码生成
     * @param level  渠道级别，1：一级，2：二级，3：三级
     * @param type  渠道属性   1：代理，2：网点
     * @param areaCode   渠道号
     * @param id    所属渠道
     * @return
     */
    public String findChannelCodeByLevel(Integer level, Integer type, String areaCode, Integer id) {
        StringBuffer code = new StringBuffer();
        if (level == 1) {
            code.append(areaCode);
            code.append(findChannelCodeByLevel(level, type)).append("0000000");
        } else if (level == 2) {
            Channels channels = channelsMapper.findById(id);
            //判断是二级代理还是网点
            if (1 == type) {  
                //二级代理商
                code.append(channels.getChannelCode().substring(0, 6)).append(findChannelCodeByLevel(level, type)).append("0000");
            } else { 
                //直属网点
                code.append(channels.getChannelCode().substring(0, 9)).append(findChannelCodeByLevel(level, type));
            }
        } else {
            //添加三级Code
            Channels channels = channelsMapper.findById(id);
            code.append(channels.getChannelCode().substring(0, 9)).append(findChannelCodeByLevel(level, type));
        }
        return code.toString();
    }
    
    /**
     * 获取编码规则
     * @param level  渠道级别，1：一级，2：二级，3：三级
     * @param type  渠道属性   1：代理，2：网点
     * @return
     */
    public String findChannelCodeByLevel(Integer level, Integer type)
    {
        StringBuffer code = new StringBuffer();
        if(level==1) {
            String sql = "SELECT LPAD(nextval('SEQ_First_Agent'),'3','0')";
            code.append(channelCodeSequenceMapper.selectSeqSql(sql));
        }else if(level==2) {
            //判断是二级代理还是网点
            if(type == 1) {
                String sql = "SELECT LPAD(nextval('SEQ_Lattice_Point'),'3','0')";
                code.append(channelCodeSequenceMapper.selectSeqSql(sql));
            }else {
                String sql = "SELECT LPAD(nextval('SEQ_Second_Agent'),'4','0')";
                code.append(channelCodeSequenceMapper.selectSeqSql(sql));
            }
        }else {
            String sql = "SELECT LPAD(nextval('SEQ_Second_Agent'),'4','0')";
            code.append(channelCodeSequenceMapper.selectSeqSql(sql));
        }
        return code.toString();
    }
    
    /**
     * 单个渠道账户划拨、纠正 公共方法（暂只适用于划拨/纠正/充流量）
     * @param channelId  渠道ID
     * @param accountType 账户类型：1：开卡账户，2：划拨账户，3：直充账户，4：消费佣金账户，5：充值佣金账户，6：直充佣金账户
     * @param operationType 操作类型：1：划拨进，2：直充(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，
     *          6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
     *          16: 开卡冻结，17：开卡扣款，18开卡冻结解冻扣款，19开卡冻结解冻回退，20开卡充值佣金
     * @param money 交易金额
     * @param realMoney  实际交易金额（含手续费）
     * @param remark  操作备注
     * @param transactionAccount  对方账户，交易账户
     * @param msisdn  电话号码
     * @param transactionId  交易ID,可以为null
     * @param transactionType  交易的表名，用于指定交易ID归属于那张表的主键，可以为null
     * @param calcType  账户交易正负类型，账户加款为正："+"，账户扣款为负："-"
     * @param transactionFlow  交易流水号，适用于外部转账银行流水号,可以为null
     * @param payType  支付方式，1：银行卡支付，2：支付宝支付，3：微信支付，4：佣金转账，5：手动加值,可以为null
     * @param us 操作人信息
     */
    public RestStatus channelAccountChange(Map<String, Object> param) throws Exception {
        Integer channelId = (Integer) param.get("channelId");
        Integer accountType = (Integer) param.get("accountType");
        Integer operationType = (Integer) param.get("operationType");
        BigDecimal money = (BigDecimal) param.get("money");
        BigDecimal realMoney = (BigDecimal) param.get("realMoney");
        String remark = (String) param.get("remark");
        String transactionAccount = (String) param.get("transactionAccount");
        String msisdn = (String) param.get("msisdn");
        String transactionId = (String) param.get("transactionId");
        String transactionType = (String) param.get("transactionType");
        String calcType = (String) param.get("calcType");
        String transactionFlow = (String) param.get("transactionFlow");
        Integer payType = (Integer) param.get("payType");
        User us = (User) param.get("us");
        Integer orderId = (Integer) param.get("orderId");
        String orderNo = (String) param.get("orderNo");

        // 适应日志接口
        if(us == null){
            us = new User();
        }

        Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
        
        String logType = "";
        String busName = "";
        if(operationType == 1 || operationType == 9){
            logType = Business.channel_flow;
            busName = "划拨";
        }else if(operationType == 2){
            logType = Business.channel_flow;
            busName = "加值";
        }else if(operationType == 3 || operationType == 10){
            logType = Business.channel_flow;
            busName = "纠正";
        }else if(operationType == 4){
//            return "开卡";
        }else if(operationType == 5){
//            return "号码充值";
        }else if(operationType == 6){
//            return "奖励";
        }else if(operationType == 7){
//            return "罚款";
        }else if(operationType == 8){
//            return "提现";
        }else if(operationType == 11 || operationType == 12){
            logType = Business.channel_flow;
            busName = "充流量";
        }else if(operationType == 13){
            logType = Business.channel_flow;
            busName = "充话费";
        }else if(operationType == 14){
            logType = Business.channel_flow;
            busName = "充话费回退";
        }else if(operationType == 15){
            logType = Business.channel_flow;
            busName = "卡密补货";
        }else if(operationType == 16){
            logType = Business.channel_flow;
            busName = "开卡扣款";
        }else if(operationType == 17){
            logType = Business.channel_flow;
            busName = "开卡扣款";
        }else if(operationType == 18){
            logType = Business.channel_flow;
            busName = "开卡冻结解冻扣款";
        }else if(operationType == 19){
            logType = Business.channel_flow;
            busName = "开卡退款";
        }else if(operationType == 20){
            logType = Business.channel_flow;
            busName = "开卡充值佣金";
        }
            
        /*Map<String, Object> params = new HashMap<String, Object>();
        params.put("channelId", channelId);
        params.put("accountType", accountType);
    
        ChannelAccount channelAccount = channelAccountMapper.findByChannelIdAndType(params);*/
        
        ChannelAccount channelAccount = findJdbcByChannelIdAndType(channelId, accountType);
        
        if(operationType == 16) {  //开户冻结
            BigDecimal balance = channelAccount.getAccountBalance().subtract(money.multiply(new BigDecimal(100)));
            if(balance.compareTo(BigDecimal.ZERO) < 0){
                return new RestStatus(Boolean.FALSE, "500", channelAccount.getAccountName() + busName + "操作失败，您的"+channelAccount.getAccountName()+"余额不足！");
            }
            channelAccount.setAccountBalance(channelAccount.getAccountBalance().subtract(money.multiply(new BigDecimal(100))));
            //channelAccount.setFreezeBalance(channelAccount.getFreezeBalance().add(money.multiply(new BigDecimal(100))));
            channelAccount.setAccountBalanceChange(money.multiply(new BigDecimal(-100)));
            //channelAccount.setFreezeBalanceChange(money.multiply(new BigDecimal(100)));
        }else if(operationType == 18) {  //18开卡冻结解冻扣款
            channelAccount.setFreezeBalance(channelAccount.getFreezeBalance().subtract(money.multiply(new BigDecimal(100))));
            //channelAccount.setFreezeBalanceChange(money.multiply(new BigDecimal(-100)));
        }else if(operationType == 19) {  //19开卡冻结解冻回退
            channelAccount.setAccountBalance(channelAccount.getAccountBalance().add(money.multiply(new BigDecimal(100))));
            //channelAccount.setFreezeBalance(channelAccount.getFreezeBalance().subtract(money.multiply(new BigDecimal(100))));
            channelAccount.setAccountBalanceChange(money.multiply(new BigDecimal(100)));
            //channelAccount.setFreezeBalanceChange(money.multiply(new BigDecimal(-100)));
        }else {
            if(StringUtils.equals(calcType, "+")) {
                channelAccount.setAccountBalance(channelAccount.getAccountBalance().add(money.multiply(new BigDecimal(100))));
                channelAccount.setAccountBalanceChange(money.multiply(new BigDecimal(100)));
            }else {
                BigDecimal balance = channelAccount.getAccountBalance().subtract(money.multiply(new BigDecimal(100)));
                if(balance.compareTo(BigDecimal.ZERO) < 0){
                    return new RestStatus(Boolean.FALSE, "500", channelAccount.getAccountName() + busName + "操作失败，您的"+channelAccount.getAccountName()+"余额不足！");
                }
                
                channelAccount.setAccountBalance(channelAccount.getAccountBalance().subtract(money.multiply(new BigDecimal(100))));
                channelAccount.setAccountBalanceChange(money.multiply(new BigDecimal(-100)));
            }
        }
        
        // 扣款逻辑放入订单中，不在此处理
        //channelAccountMapper.updateBalance(channelAccount);
        
        ChannelAccount account = findJdbcByChannelIdAndType(channelId, accountType);
        ChannelAccountTransaction transaction = new ChannelAccountTransaction();
        transaction.setChannelId(account.getChannelId());
        transaction.setChannelCode(account.getChannelCode());
        transaction.setChannelAccountId(account.getId());
        transaction.setMsisdn(msisdn);
        transaction.setAccountName(account.getAccountName());
        transaction.setAccountType(account.getAccountType());
        transaction.setOperationType(operationType);
        transaction.setTransactionAccount(transactionAccount);
        transaction.setTransactionId(transactionId);
        transaction.setTransactionType(transactionType);
        transaction.setTransactionFlow(transactionFlow);
        transaction.setPayType(payType);
        if(payType != null && payType == 1) {
            transaction.setPayName("银行卡支付");
        }else if(payType != null && payType == 2) {
            transaction.setPayName("支付宝支付");
        }else if(payType != null && payType == 3) {
            transaction.setPayName("微信支付");
        }else if(payType != null && payType == 4) {
            transaction.setPayName("佣金转账");
        }else if(payType != null && payType == 5) {
            transaction.setPayName("手动加值");
        }
        transaction.setTransactionMoney(money.multiply(new BigDecimal(100)));
        transaction.setTransactionMoneyReal(realMoney.multiply(new BigDecimal(100)));
        BigDecimal accountBalanceAfter = BigDecimal.ZERO;
        if(operationType == 16) {  //开户冻结
            accountBalanceAfter = account.getAccountBalance().subtract(money.multiply(new BigDecimal(100)));
        }else if(operationType == 18) {  //18开卡冻结解冻扣款
            accountBalanceAfter = account.getAccountBalance();
        }else if(operationType == 19) {  //19开卡冻结解冻回退
            accountBalanceAfter = account.getAccountBalance().add(money.multiply(new BigDecimal(100)));
        }else {
            if(StringUtils.equals(calcType, "+")) {
                accountBalanceAfter = account.getAccountBalance().add(money.multiply(new BigDecimal(100)));
            }else {
                accountBalanceAfter = account.getAccountBalance().subtract(money.multiply(new BigDecimal(100)));
            }
        }
        transaction.setAccountBalanceBefore(account.getAccountBalance());
        transaction.setRemark(remark);
        if (null != us.getId()) {
            transaction.setOperatorId(us.getId());
        } else {
            transaction.setOperatorId(0);
        }
        transaction.setOperationTime(newDate);
        transaction.setAccountBalanceAfter(accountBalanceAfter);
        
        ChannelAccountTransactionDTO transactionDTO = transToDTO(transaction);
        
        // 在订单中记录账户流水，不在此处理
        //channelAccountTransactionMapper.insert(transaction);
        
        // 生成订单 begin
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setOrderId(orderId);
        orderDetail.setOrderNo(orderNo);
        orderDetail.setChannelId(channelId);
        orderDetail.setAccountType(accountType);
        orderDetail.setStatus(0);
        orderDetail.setMsisdn(msisdn);
        orderDetail.setMoney(money.multiply(new BigDecimal(100)));
        orderDetail.setAccountBalance(channelAccount.getAccountBalanceChange());
        orderDetail.setFreezeBalance(channelAccount.getFreezeBalanceChange());
        orderDetail.setBusinessId(operationType);
        orderDetail.setBusinessType(busName);
        orderDetail.setCalcType(calcType);
        orderDetail.setAcctTransactionObj(JSONUtil.objectToJson(transactionDTO));
        orderDetail.setRemark(remark);
        orderDetail.setCreateId(us.getId());
        orderDetail.setUpdateId(us.getId());
        orderDetailService.insert(orderDetail);
        // 生成订单 end
        
        Channels channels = channelsMapper.findById(channelId);
        
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff",us.getLoginName());
        logmap.put("channelName",channels.getChannelName());
        logmap.put("channelCode",channels.getChannelCode());
        logmap.put("accountName",transaction.getAccountName());
        logmap.put("operationType",transaction.getOperationName());
        logmap.put("beforeMoney",String.valueOf(transaction.getAccountBalanceBeforeYuan()));
        logmap.put("money",String.valueOf(money.doubleValue()));
        logmap.put("afterMoney", String.valueOf(transaction.getAccountBalanceAfterYuan()));
        logmap.put("createDate",DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功");
        
        if(operationType != 18){
            logService.businessSaveLog(logType, us.getId() == null?"0" : String.valueOf(us.getId()),us.getLoginName() == null?"自动加值" : us.getLoginName(),null != channels.getId() ? String.valueOf(channels.getId()) : "0", busName,logmap);
        }
        
        return new RestStatus(Boolean.TRUE, "200", channelAccount.getAccountName() + busName + "操作成功");
    }
    
    public ChannelAccount findJdbcByChannelIdAndType(Integer channelId, Integer accountType) {
        String sql = "select c.* from t_channel_account c  where c.channel_id = " + channelId + " and c.account_type = " + accountType;
        List<Map<String, Object>> list  = jdbcTemplate.queryForList(sql);
        Map<String, Object> map = list.get(0);
        ChannelAccount account = new ChannelAccount();
        // 基类属性
        account.setId((Integer)map.get("id"));
        account.setChannelId((Integer)map.get("channel_id"));
        account.setChannelIdLevel1((Integer)map.get("channel_id_level1"));
        account.setChannelIdLevel2((Integer)map.get("channel_id_level2"));
        account.setChannelCode((String)map.get("channel_code"));
        account.setAccountType((Integer)map.get("account_type"));
        account.setAccountName((String)map.get("account_name"));
        account.setAccountBalance((BigDecimal)map.get("account_balance"));
        account.setFreezeBalance((BigDecimal)map.get("freeze_balance"));
        
        return account;
    }
    
    /**
     * 统计代理商佣金
     * @param params
     * @return
     */
    public List<Channels> countLevelBro(Map<String, Object> params) {
        return channelsMapper.countLevelBro(params);
    }
    
    /**
     * 统计代理商佣金(总记录数)
     * @param params
     * @return
     */
    public int countLevelBroTotal(Map<String, Object> params) {
        return channelsMapper.countLevelBroTotal(params);
    }
    
    /**
     * 根据渠道ID集合，获取渠道集合
     * @param ids
     * @return
     */
    public List<Channels> findChannelsByIds(List<Integer> ids) {
        return channelsMapper.findChannelsByIds(ids);
    }
    
    private ChannelAccountTransactionDTO transToDTO(ChannelAccountTransaction transaction) {
        ChannelAccountTransactionDTO dto = new ChannelAccountTransactionDTO();
        dto.setChannelId(transaction.getChannelId());
        dto.setChannelCode(transaction.getChannelCode());
        dto.setChannelAccountId(transaction.getChannelAccountId());
        dto.setMsisdn(transaction.getMsisdn());
        dto.setAccountName(transaction.getAccountName());
        dto.setAccountType(transaction.getAccountType());
        dto.setOperationType(transaction.getOperationType());
        dto.setTransactionAccount(transaction.getTransactionAccount());
        dto.setTransactionId(transaction.getTransactionId());
        dto.setTransactionType(transaction.getTransactionType());
        dto.setTransactionFlow(transaction.getTransactionFlow());
        dto.setPayType(transaction.getPayType());
        dto.setPayName(transaction.getPayName());
        dto.setTransactionMoney(transaction.getTransactionMoney());
        dto.setTransactionMoneyReal(transaction.getTransactionMoneyReal());
        dto.setAccountBalanceBefore(transaction.getAccountBalanceBefore());
        dto.setAccountBalanceAfter(transaction.getAccountBalanceAfter());
        dto.setRemark(transaction.getRemark());
        dto.setOperatorId(transaction.getOperatorId());
        dto.setOperationTime(transaction.getOperationTime());
        return dto;
    }
}
