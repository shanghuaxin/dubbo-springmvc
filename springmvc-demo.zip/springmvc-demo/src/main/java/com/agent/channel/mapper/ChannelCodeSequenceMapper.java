package com.agent.channel.mapper;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelCodeSequence;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelCodeSequenceMapper extends BaseMapper<ChannelCodeSequence, String> {
    
    public String selectSeqSql(String value);

}
