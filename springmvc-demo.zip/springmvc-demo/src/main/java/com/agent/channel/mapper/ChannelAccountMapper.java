package com.agent.channel.mapper;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelAccount;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelAccountMapper extends BaseMapper<ChannelAccount,Integer>{
    
    public ChannelAccount findByChannelIdAndType(Map<String, Object> map);
    public void batchInsert(Map<String, Object> map);
    
    /**
     * 更新账户余额
     * @param channelAccount
     * @return
     */
    public int updateBalance(ChannelAccount channelAccount);
    
    /**
     * 更新账户冻结金额
     * @param map
     * @return
     */
    public int updateFreezeBalance(Map<String, Object> map);
    
    /**
     * 按渠道等级统计佣金
     * @param map
     * @return
     */
    public BigDecimal statisticsChannelBrokerage(Map<String, Object> map);
}
