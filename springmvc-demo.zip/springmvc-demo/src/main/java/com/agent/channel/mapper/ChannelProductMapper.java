package com.agent.channel.mapper;

import com.agent.product.dto.ChannelProductDto;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelProduct;
import com.agent.common.BaseMapper;

import java.util.List;
import java.util.Map;

@Repository
public interface ChannelProductMapper extends BaseMapper<ChannelProduct, Integer> {
    public List<ChannelProductDto> listProCPD(Map<String, Object> params);
    public int listProCPDCount(Map<String, Object> params);
    public int insertByDto(ChannelProductDto dto);
    public int updateByDto(ChannelProductDto dto);
    public List<ChannelProduct> listChannelPro(Map<String, Object> params);
    public List<ChannelProductDto> listChPacIsShow(Map<String, Object> params);
    public ChannelProduct channelProductShow(@Param(value="channelId") Integer channelId, @Param(value="packageId") Integer packageId);
    
    public int batchInsertByDto(List<ChannelProductDto> list);
    public int batchUpdateByDto(List<ChannelProductDto> list);
}
