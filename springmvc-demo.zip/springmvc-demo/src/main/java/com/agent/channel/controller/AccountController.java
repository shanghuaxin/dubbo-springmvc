package com.agent.channel.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelAccountTransactionService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.constant.Constant;
import com.agent.order.service.OrderDetailService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;

@Controller
@RequestMapping("account")
public class AccountController {
    
    private static Logger logger = LoggerFactory.getLogger(AccountController.class);
    
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private ChannelAccountTransactionService service;
    @Autowired
    private ChannelAccountService channelAccountService;
    @Autowired
    private OrderDetailService orderDetailService;
    
    @RequestMapping("/channelAccountList" )
    public String channelAccountList(HttpServletRequest request, Channels channels, Integer sortByAmount, String flag, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        //以下是渠道主页获取渠道信息
        Channels channel = channelsService.findChannelByUserId(user.getId());     
        PageEntity pageEntity = new PageEntity(channels.getPageSize(), channels.getPageIndex());       
        Map<String, Object> params = new HashMap<String, Object>();
        
        if(channel == null) {
            params.put("channelLevel", 0);  //当前登录渠道级别，总部员工默认为0
            request.setAttribute("channelLevel", 0);
            if(channels.getLevel() == null) {
                params.put("level", 1);
                channels.setLevel(1);
            }
            request.setAttribute("curChannellevel", 0);  //当前渠道级别，界面判断使用
        }else {
            params.put("channelId", channel.getId());
            params.put("channelLevel", channel.getChannelLevel());
            request.setAttribute("curChannellevel", channel.getChannelLevel());
            if(channels.getLevel() == null) {
                params.put("level", channel.getChannelLevel() + 1);
                channels.setLevel(channel.getChannelLevel() + 1);
            }
        }        
        //界面跳转时用到（查询下级渠道列表信息）
        if(channels.getId() != null && channels.getChannelLevel() != null){
            params.put("channelId", channels.getId());
            params.put("channelLevel", channels.getChannelLevel());
        }
        
        // 设置分页初始化数据
        if (StringUtils.isNotBlank(channels.getChannelName())) {
            params.put("channelName", channels.getChannelName());
        }
        if(channels.getLevel() != null ) {
            params.put("level", channels.getLevel());
            if(channels.getLevel() == 0){
                params.remove("level");
            }
        }
        if (StringUtils.isNotBlank(channels.getChannelNameLevel1())) {
            List<Integer> channelIds = channelsService.findByCodeOrName(channels.getChannelNameLevel1().trim());
            if(channelIds != null && channelIds.size() > 0){
                params.put("channelIds", channelIds);
            }else {
                channelIds.add(1);
                params.put("channelIds", channelIds);
            }
        }
        params.put("sortByAmount", sortByAmount);

     // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<Channels> channelList = channelsService.newListChannelAccount(params);
        int total = channelsService.newAccountCountTotal(params);
        pageEntity.setTotal(total);

        request.setAttribute("sortByAmount", sortByAmount);
        request.setAttribute("flag", flag);
        request.setAttribute("channelList", channelList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("channels", channels);
        
        //查找该页面的链接条件
        request.setAttribute("id", channels.getId());   

        return "/views/channel/account/accountList.jsp";
    }
    
    //加值
    @RequestMapping(value = "/accountJz")
    public String accountJz(HttpServletRequest request, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        //用户可操作的账户集合
        List<ChannelAccount> list = new ArrayList<ChannelAccount>();
        //以下是渠道主页获取渠道信息
        Channels channel = channelsService.findChannelByUserId(user.getId());
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        
        if(channel == null) {
            if(channels.getChannelLevel() == 1) {
                ChannelAccount channelAccountKK = channelAccountService.findByChannelIdAndType(channels.getId(), 1);
                ChannelAccount channelAccountHb = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
                ChannelAccount channelAccountZc = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 1);
                // 未处理的开卡账户订单金额(元)
                BigDecimal freezeOpenMoney = orderDetailService.calcOrderMoney(param1);
                freezeOpenMoney = freezeOpenMoney.multiply(new BigDecimal(100));
                param1.put("accountType", 2);
                // 未处理的划拨账户订单金额(元)
                BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
                freezeAllotMoney = freezeAllotMoney.multiply(new BigDecimal(100));
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额(元)
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                freezeRechargeMoney = freezeRechargeMoney.multiply(new BigDecimal(100));
                channelAccountKK.setAccountBalance(channelAccountKK.getAccountBalance().subtract(freezeOpenMoney));
                channelAccountHb.setAccountBalance(channelAccountHb.getAccountBalance().subtract(freezeAllotMoney));
                channelAccountZc.setAccountBalance(channelAccountZc.getAccountBalance().subtract(freezeRechargeMoney));
                list.add(channelAccountKK);
                list.add(channelAccountHb);
                list.add(channelAccountZc);
            }else {
                ChannelAccount channelAccountZc = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额(元)
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                freezeRechargeMoney = freezeRechargeMoney.multiply(new BigDecimal(100));
                channelAccountZc.setAccountBalance(channelAccountZc.getAccountBalance().subtract(freezeRechargeMoney));
                list.add(channelAccountZc);
            }
        }
        
        String ransactionId = ransactionId();
        request.setAttribute("level", channels.getChannelLevel() - 1);
        request.setAttribute("channels", channels);
        request.setAttribute("list", list);
        request.setAttribute("ransactionId", ransactionId);
        
        return "/views/channel/account/accountJz.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountJz"}, method = RequestMethod.POST)
    public RestStatus saveAccountJz(HttpServletRequest request ,Channels channels, HttpSession session){
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount  ="";
            
        Channels channel = channelsService.findChannelByUserId(user.getId());
            
        if(channel != null){
            transactionAccount = "[" + channel.getChannelCode() + "] " + channel.getChannelName();
        }else{
            transactionAccount = "总部：" + user.getNickName();
        }
        
        if(channels.getAccount_type() == null) {
            return new RestStatus(Boolean.FALSE, "500", "请选择账户类型！");
        }
        
        if(channels.getAccountBalanceHb() == null || channels.getAccountBalanceHb().compareTo(BigDecimal.ZERO) <= 0){
            return new RestStatus(Boolean.FALSE, "500", "您输入的划拨金额("+channels.getAccountBalanceHb()+")错误！");
        }
        
        try {
            restStatus = channelsService.saveAccountJz(channels, user.getId(), transactionAccount, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new RestStatus(Boolean.FALSE, "500", "划拨操作失败！");
        }
        
        return restStatus;
    }
    
    //纠正
    @RequestMapping(value = "/accountCorrect")
    public String accountCorrect(HttpServletRequest request, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        //用户可操作的账户集合
        List<ChannelAccount> list = new ArrayList<ChannelAccount>();
        //以下是渠道主页获取渠道信息
        Channels channel = channelsService.findChannelByUserId(user.getId());
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        
        if(channel == null) {
            if(channels.getChannelLevel() == 1) {
                ChannelAccount channelAccountKK = channelAccountService.findByChannelIdAndType(channels.getId(), 1);
                ChannelAccount channelAccountHb = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
                ChannelAccount channelAccountZc = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 1);
                // 未处理的开卡账户订单金额(元)
                BigDecimal freezeOpenMoney = orderDetailService.calcOrderMoney(param1);
                freezeOpenMoney = freezeOpenMoney.multiply(new BigDecimal(100));
                param1.put("accountType", 2);
                // 未处理的划拨账户订单金额(元)
                BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
                freezeAllotMoney = freezeAllotMoney.multiply(new BigDecimal(100));
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额(元)
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                freezeRechargeMoney = freezeRechargeMoney.multiply(new BigDecimal(100));
                channelAccountKK.setAccountBalance(channelAccountKK.getAccountBalance().subtract(freezeOpenMoney));
                channelAccountHb.setAccountBalance(channelAccountHb.getAccountBalance().subtract(freezeAllotMoney));
                channelAccountZc.setAccountBalance(channelAccountZc.getAccountBalance().subtract(freezeRechargeMoney));
                list.add(channelAccountKK);
                list.add(channelAccountHb);
                list.add(channelAccountZc);
            }else {
                ChannelAccount channelAccountZc = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额(元)
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                freezeRechargeMoney = freezeRechargeMoney.multiply(new BigDecimal(100));
                channelAccountZc.setAccountBalance(channelAccountZc.getAccountBalance().subtract(freezeRechargeMoney));
                list.add(channelAccountZc);
            }
        }
        
        String ransactionId = ransactionId();
        request.setAttribute("level", channels.getChannelLevel() - 1);
        request.setAttribute("channels", channels);
        request.setAttribute("list", list);
        request.setAttribute("ransactionId", ransactionId);
        
        return "/views/channel/account/accountCorrect.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountCorrect"}, method = RequestMethod.POST)
    public RestStatus saveAccountCorrect(HttpServletRequest request ,Channels channels, HttpSession session){
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount  ="";
            
        Channels channel = channelsService.findChannelByUserId(user.getId());
            
        if(channel != null){
            transactionAccount = "[" + channel.getChannelCode() + "] " + channel.getChannelName();
        }else{
            transactionAccount = "总部：" + user.getNickName();
        }
        
        if(channels.getAccount_type() == null) {
            return new RestStatus(Boolean.FALSE, "500", "请选择账户类型！");
        }
        
        if(channels.getAccountBalanceHb() == null || channels.getAccountBalanceHb().compareTo(BigDecimal.ZERO) <= 0){
            return new RestStatus(Boolean.FALSE, "500", "您输入的划拨金额("+channels.getAccountBalanceHb()+")错误！");
        }
        
        try {
            restStatus = channelsService.saveAccountCor(channels, user.getId(), transactionAccount, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new RestStatus(Boolean.FALSE, "500", "划拨操作失败！");
        }
        
        return restStatus;
    }
    
    //加值记录[手动加值]
    @RequestMapping("/operationlist")
    public String operationList(HttpServletRequest request, HttpSession session, ChannelAccountTransaction transaction, String flag, Integer pageSize, Integer pageIndex) {
            
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);

        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotBlank(transaction.getChannelName())) {
            params.put("channelName", transaction.getChannelName().trim());
        }
        
        if (StringUtils.isNotBlank(transaction.getChannelIdName1())) {
            List<Integer> channelIds = channelsService.findByCodeOrName(transaction.getChannelIdName1().trim());
            if(channelIds != null && channelIds.size() > 0){
                params.put("channelIds", channelIds);
            }else {
                channelIds.add(0);
                params.put("channelIds", channelIds);
            }
        }
        
        if(transaction.getChannelLevel() != null ) {
            params.put("level", transaction.getChannelLevel());
            if(transaction.getChannelLevel() == 0){
                params.remove("level");
            }
        }
        
        if (StringUtils.isNotBlank(transaction.getsDate())) {
            params.put("sDate", transaction.getsDate());
        }
        if (StringUtils.isNotBlank(transaction.geteDate())) {
            params.put("eDate", transaction.geteDate());
        }
        
        if (transaction.getOperationType() != null) {
            params.put("operationType", transaction.getOperationType());
        }
        
        if (transaction.getAccountType() != null) {
            params.put("accountType", transaction.getAccountType());
        }
        
        if (StringUtils.isNotBlank(transaction.getTransactionId())) {
            params.put("transactionId", transaction.getTransactionId().trim());
        }
        
        if (StringUtils.isNotBlank(transaction.getName())) {
            params.put("name", transaction.getName().trim());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<ChannelAccountTransaction> transactionList = service.listOperationTransation(params);
        int total = service.countOperationTotal(params);
        pageEntity.setTotal(total);

        request.setAttribute("transactionList", transactionList);
        request.setAttribute("flag", flag);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("transaction", transaction);
        
        return "/views/channel/account/autoaccount.jsp";
    }
    
    @RequestMapping(value = "/accountOperation")
    public String accountOperation(HttpServletRequest request){
        
        String ransactionId = ransactionId();
        
        request.setAttribute("ransactionId", ransactionId);
        
        return "/views/channel/account/accountOperation.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountOperation"}, method = RequestMethod.POST)
    public Map<String, Object> saveAccountOperation(HttpServletRequest request ,ChannelAccountTransaction channelAccountTransaction, HttpSession session){
        
        Map<String, Object> map = new HashMap<String, Object>();
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount = "总部加值：手动加值【" + user.getNickName() + "】";
        
        if(channelAccountTransaction.getOperationType() == 10){
            transactionAccount = "总部加值：手动纠正【" + user.getNickName() + "】";
        }
        
        if(channelAccountTransaction.getTransactionMoney() == null || channelAccountTransaction.getTransactionMoney().compareTo(BigDecimal.ZERO) <= 0){
            map.put("status", false);
            map.put("msg", "您输入的金额("+channelAccountTransaction.getTransactionMoney()+")错误！");
            return map;
        }
        
        try {
            RestStatus rest = service.saveAccountOperation(channelAccountTransaction, transactionAccount, user);
            
            if(rest.getStatus()){
                map.put("status", true);
                map.put("msg", rest.getErrorMessage());
                return map;
            }else{
                map.put("status", false);
                map.put("msg", rest.getErrorMessage());
                return map;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "操作失败" + e.getMessage());
            return map;
        }
    }
    
    /**
     * 根据渠道编码、渠道父ID查找渠道信息
     * @param channelCode
     * @param channelId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/findChannelByCode")
    public Channels findChannelByCodeAndPid(String channelCode, Integer type){
        Channels channels = channelsService.findByCode(channelCode);
        if(channels == null) {
            return null;
        }
        ChannelAccount channelAccount = channelAccountService.findByChannelIdAndType(channels.getId(), type);
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("channelId", channels.getId());
        param.put("accountType", type);
        // 未处理的账户订单金额
        BigDecimal freezeMoney = orderDetailService.calcOrderMoney(param);
        if(channelAccount != null){
            channels.setAccountBalanceHb(channelAccount.getAccountBalanceYuan().subtract(freezeMoney));
        }
        return channels;
    }
    
    
  //加值记录导出[财务人员主页]
    @SuppressWarnings({"unchecked", "rawtypes", "static-access" })
    @RequestMapping(value="/operationlistexport",method=RequestMethod.GET)
    public void operationListExport(HttpServletRequest request, HttpServletResponse response, ChannelAccountTransaction transaction, Integer pageSize) {
        try {
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
    
            Map<String, Object> params = new HashMap<String, Object>();
    
            if (StringUtils.isNotBlank(transaction.getChannelName())) {
                params.put("channelName", transaction.getChannelName().trim());
            }
            
            if (StringUtils.isNotBlank(transaction.getChannelIdName1())) {
                List<Integer> channelIds = channelsService.findByCodeOrName(transaction.getChannelIdName1().trim());
                if(channelIds != null && channelIds.size() > 0){
                    params.put("channelIds", channelIds);
                }else {
                    channelIds.add(0);
                    params.put("channelIds", channelIds);
                }
            }
            
            if(transaction.getChannelLevel() != null ) {
                params.put("level", transaction.getChannelLevel());
                if(transaction.getChannelLevel() == 0){
                    params.remove("level");
                }
            }
            
            if (StringUtils.isNotBlank(transaction.getsDate())) {
                params.put("sDate", transaction.getsDate());
            }
            if (StringUtils.isNotBlank(transaction.geteDate())) {
                params.put("eDate", transaction.geteDate());
            }
            
            if (transaction.getOperationType() != null) {
                params.put("operationType", transaction.getOperationType());
            }
            
            if (transaction.getAccountType() != null) {
                params.put("accountType", transaction.getAccountType());
            }
            
            if (StringUtils.isNotBlank(transaction.getTransactionId())) {
                params.put("transactionId", transaction.getTransactionId().trim());
            }
            
            if (StringUtils.isNotBlank(transaction.getName())) {
                params.put("name", transaction.getName().trim());
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
    
            params.put("limit", limit);
            params.put("offset", offset);
            List<ChannelAccountTransaction> list = service.listOperationTransation(params);
            String dateStr = DateUtil.getInstance().getNowDateTimeString("yyyyMMdd");
            String downloadName = "市场人员加值记录详情导出" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"操作时间","渠道名称","渠道编码","渠道属性","金额","操作", "账户", "工单号","备注", "操作者"};
            properties = new String[]{"operationTimeStr","channelName","channelCode","channelLevelStr","transactionMoneyYuan",
                    "operationName", "accountName", "transactionId", "remark", "name"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(),headers,list,properties);
        } catch (IOException e) {
            logger.info("市场人员加值记录导出失败");
            e.printStackTrace();
        }
    }
    
  //工单号
    public String ransactionId() {
        String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
        String timeStr = DateUtil.getNowDateTimeString("HHmmss");
        String ransactionId = service.maxTransactionId(dateStr);
        if(StringUtils.isBlank(ransactionId)){
            ransactionId = dateStr + timeStr + "001";
        }else {
            String maxStr = ransactionId.substring(ransactionId.length()-3, ransactionId.length());
            String str = String.valueOf(Long.parseLong(maxStr) + 1);
            if(str.length() == 1){
                str = "00" + str;
            }else if(maxStr.length() == 2){
                str = "0" + str;
            }
            ransactionId = dateStr + timeStr + str;
        }
        
        return ransactionId;
    }

}
