package com.agent.channel.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelAccountTransactionMapper extends BaseMapper<ChannelAccountTransaction,Integer>{

    public List<ChannelAccountTransaction> listTransation(Map<String, Object> map);
    public int countTotal(Map<String, Object> map);
    public List<ChannelAccountTransaction> listAddTransation(Map<String, Object> map);
    public int countAddTotal(Map<String, Object> map);
    public List<ChannelAccountTransaction> listOperationTransation(Map<String, Object> map);
    public int countOperationTotal(Map<String, Object> map);
    public BigDecimal sumTransactionMoney(Map<String, Object> map);
    public String maxTransactionId(@Param(value="transactionId") String ransactionId);
    //根据手机号码查找号码开户时网点、一级渠道冻结扣款流水（最近一次操作）
    public List<ChannelAccountTransaction> listTransationByPhone(@Param(value="phone") String phone);
    // 获取指定月份的佣金总额(分)
    public BigDecimal countBrokerageMoney(Map<String, Object> map);
    // 获取佣金详情
    public List<ChannelAccountTransaction> queryBrokerageDetail(Map<String, Object> map);
    // 获取佣金详情总记录数
    public int countBrokerageDetailTotal(Map<String, Object> map);
}
