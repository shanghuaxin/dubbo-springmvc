package com.agent.channel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.channel.entity.ChannelWhite;
import com.agent.channel.mapper.ChannelWhiteMapper;

@Transactional(rollbackFor=Exception.class)
@Service("channelWhiteService")
public class ChannelWhiteService {
    
    @Autowired
    private ChannelWhiteMapper channelWhiteMapper;
    
    public ChannelWhite findByChannelId(Integer channelId){
        return channelWhiteMapper.findByChannelId(channelId);
    }

}
