package com.agent.channel.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import com.agent.constant.Constant;

/**
 * 渠道账户表
 * @author weijialiang
 *
 */
public class ChannelAccount implements Serializable{

    private static final long serialVersionUID = 4494085000212623649L;
    
    private Integer id;                //id
    private Integer channelId;         //渠道id
    private Integer channelIdLevel1;   //归属一级渠道ID
    private Integer channelIdLevel2;   //归属二级渠道ID
    private String channelCode;        //渠道编码
    private Integer accountType;       //账户类型：1：开卡账户，2：划拨账户，3：直充账户，4：消费佣金账户，5：充值佣金账户
    private String accountName;        //账户名称：1：开卡账户，2：划拨账户，3：直充账户，4：消费佣金账户，5：充值佣金账户
    private BigDecimal accountBalance;    //账户余额，单位：分
    private BigDecimal freezeBalance;    //冻结账户余额，单位：分
    private BigDecimal accountBalanceChange = new BigDecimal(0);    //账户变动的余额，单位：分
    private BigDecimal freezeBalanceChange = new BigDecimal(0);    //冻结账户变动的余额，单位：分
    
    public ChannelAccount() {
        super();
    }
    
    public ChannelAccount(Integer accountType, String accountName) {
        super();
        this.accountType = accountType;
        this.accountName = accountName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getChannelIdLevel1() {
        return channelIdLevel1;
    }

    public void setChannelIdLevel1(Integer channelIdLevel1) {
        this.channelIdLevel1 = channelIdLevel1;
    }

    public Integer getChannelIdLevel2() {
        return channelIdLevel2;
    }

    public void setChannelIdLevel2(Integer channelIdLevel2) {
        this.channelIdLevel2 = channelIdLevel2;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }
    
    public BigDecimal getAccountBalanceYuan() {
        if(null != accountBalance){
            return accountBalance.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return accountBalance;
    }

    public BigDecimal getFreezeBalance() {
        return freezeBalance;
    }

    public void setFreezeBalance(BigDecimal freezeBalance) {
        this.freezeBalance = freezeBalance;
    }
    
    public BigDecimal getFreezeBalanceYuan() {
        if(null != freezeBalance){
            return freezeBalance.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return freezeBalance;
    }

    public BigDecimal getAccountBalanceChange() {
        return accountBalanceChange;
    }

    public void setAccountBalanceChange(BigDecimal accountBalanceChange) {
        this.accountBalanceChange = accountBalanceChange;
    }

    public BigDecimal getFreezeBalanceChange() {
        return freezeBalanceChange;
    }

    public void setFreezeBalanceChange(BigDecimal freezeBalanceChange) {
        this.freezeBalanceChange = freezeBalanceChange;
    }

    @Override
    public String toString() {
        return "ChannelAccount [id=" + id + ", channelId=" + channelId + ", channelIdLevel1=" + channelIdLevel1
                + ", channelIdLevel2=" + channelIdLevel2 + ", channelCode=" + channelCode + ", accountType="
                + accountType + ", accountName=" + accountName + ", accountBalance=" + accountBalance + ", freezeBalance=" + freezeBalance + "]";
    }
    
}
