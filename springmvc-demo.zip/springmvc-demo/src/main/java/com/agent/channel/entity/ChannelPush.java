package com.agent.channel.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 渠道变更后需要数据推送到cool170
 * @author weijialiang
 *
 */
public class ChannelPush implements Serializable {

    private static final long serialVersionUID = 4843450662787397777L;
    private Integer id;              //id
    private String opType;           //操作类型，add ：新增，modify ：修改，cancel ：冻结
    private String channelCode;      //渠道编号
    private String channelName;      //渠道名称
    private String channelType;      //渠道类型
    private String channelLevel;     //渠道级别
    private String parentChannelCode;//父渠道编码
    private String channelStatus;    //渠道状态：y：有效，n：失效
    private String memo;             //备注
    private Integer status;          //状态：0：未推送，1：已推送，2：失败
    private Date pushDate;           //推送时间
    private Integer portNum;         //推送次数
    private Integer createId;        //创建人ID
    private Date createTime;         //创建时间
    private Integer updateId;        //更新人ID
    private Date updateTime;         //更新时间

    public ChannelPush() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOpType() {
        return opType;
    }

    public void setOpType(String opType) {
        this.opType = opType;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelLevel() {
        return channelLevel;
    }

    public void setChannelLevel(String channelLevel) {
        this.channelLevel = channelLevel;
    }

    public String getParentChannelCode() {
        return parentChannelCode;
    }

    public void setParentChannelCode(String parentChannelCode) {
        this.parentChannelCode = parentChannelCode;
    }

    public String getChannelStatus() {
        return channelStatus;
    }

    public void setChannelStatus(String channelStatus) {
        this.channelStatus = channelStatus;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getPushDate() {
        return pushDate;
    }

    public void setPushDate(Date pushDate) {
        this.pushDate = pushDate;
    }

    public Integer getPortNum() {
        return portNum;
    }

    public void setPortNum(Integer portNum) {
        this.portNum = portNum;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ChannelPush [id=" + id + ", opType=" + opType + ", channelCode=" + channelCode + ", channelName="
                + channelName + ", channelType=" + channelType + ", channelLevel=" + channelLevel
                + ", parentChannelCode=" + parentChannelCode + ", channelStatus=" + channelStatus + ", memo=" + memo
                + ", status=" + status + ", pushDate=" + pushDate + ", portNum=" + portNum + ", createId=" + createId
                + ", createTime=" + createTime + ", updateId=" + updateId + ", updateTime=" + updateTime + "]";
    }
    
}
