package com.agent.channel.entity;

import org.springframework.web.multipart.MultipartFile;

import com.agent.constant.Constant;
import com.agent.util.DateUtil;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;



/**
 * 渠道表
 * @author weijialiang
 *
 */
public class Channels implements Serializable{
    
    private static final long serialVersionUID = 6026819348921523340L;
    /** 渠道属性 代理商 */
    public static Integer CHANNEL_TYPE_1 = 1;
    /** 渠道属性 网点 */
    public static Integer CHANNEL_TYPE_2 = 2;
    /** 渠道级别 一级 */
    public static Integer CHANNEL_LEVEL_1 = 1;
    /** 渠道级别 二级 */
    public static Integer CHANNEL_LEVEL_2 = 2;
    /** 渠道级别 三级 */
    public static Integer CHANNEL_LEVEL_3 = 3;

    private Integer seq;                //排序
    private Integer id;                 //渠道ID
    private String channelName;         //名称
    private String channelCode;         //渠道编号
    private Integer parentChannelId;    //渠道父ID
    private String parentChannelCode;   //父级渠道编号，多个编码使用逗号分割
    private String parentChannelName;   //父级渠道名称，多个编码使用逗号分割
    private Integer channelIdLevel1;    //归属一级渠道ID
    private Integer channelIdLevel2;    //归属二级渠道ID
    private String channelNameLevel1;    //归属一级渠道名称
    private String channelNameLevel2;    //归属二级渠道名称
    private Integer channelLevel;       //渠道级别，1：一级，2：二级，3：三级
    private Integer channelType;        //渠道属性，1：代理，2：网点
    private String bussContactName;     //联系人名称
    private String bussContactPhone;    //联系人电话
    private String contactName;         //法人姓名
    private String contactIdcard;       //法人身份证号码
    private Integer provinceId;         //省份ID
    private String provinceName;        //省份名称
    private Integer cityId;             //城市ID
    private String cityName;            //城市名称
    private Integer areaId;             //区县ID
    private String areaName;            //区县名称
    private String address;             //详细地址
    private String idcardLicense;       //法人身份证证件照
    private String businessLicense;     //营业执照证件
    private String orgcodeLicense;      //组织机构代码证件(存放门店信息)
    private String otherLicense;        //其他证件
    private Integer status;             //状态，1：正常，2：待审核，3：冻结开户，4：冻结，5：审核不通过
    private Integer saleType;           //销售方式，1：线下，2：线上
    private Integer userId;             //市场人员ID
    private String comment;             //描述
    private String authComment;         //网点审核描述
    private Date authTime;              //网点审核时间
    private Integer checkStatus;        //稽查状态
    private String checkComment;        //稽查描述
    private Date checkTime;             //稽查时间
    private Integer createId;           //创建人员ID
    private Date createTime;            //创建时间
    private Integer updateId;           //最后修改人id
    private Date updateTime;            //最后修改时间
    
    //扩充字段
    private String ids;                //批量设置ID
    private BigDecimal accountBalanceKK;   //开卡账户余额
    private BigDecimal accountBalanceHb;   //划拨账户余额,(划拨界面：划拨金额，纠正界面：纠正金额)
    private BigDecimal accountBalanceZc;   //直充账户余额
    private BigDecimal accountBalanceYJ;   //充值账户消费佣金
    private String loginName;           //渠道登录账号
    private String email;               //渠道联系邮箱
    private String areaCode;            //城市编码
    private String createTimeStr;       //创建时间
    private Integer uId;                //用户Id
    private Integer level;                //网点级别level（总部员工查找渠道界面，通过一级渠道查找3级渠道时使用）
    private String transactionId;      //交易ID,手动加值工单号
    private Integer account_type;       //账户类型
    private Integer operationType;      //操作类型
    
    private Integer amount2;            //查询界面统计2级渠道总数
    private Integer amount3;            //查询界面统计3级渠道总数
    private Integer isAuth;            //开卡审核设置：0-否，1- 是
    private Integer isImg;             //手动输入身份证：0-否，1- 是
    
    //实名设置
    private Integer openCardAnth;       //设置开卡审核权限 1：开户时审核，2：开户后复查
    private Integer openAccountMode;    //设置实名开户方式 1：阅读器识别，2：照片识别，3：阅读器识别 + 照片上传
    // 是否支持APP本地获取照片：0-否，1- 是
    private Integer appImg;
    // 是否支持APP活体检测：0-否，1- 是
    private Integer appFace;
    //分页
    private Integer pageIndex;       // 当前页
    private Integer pageSize;        // 页面大小
    
    private String sDate;     //开始时间
    private String eDate;     //结束时间
    //图片文件
    private MultipartFile idcardFile;          //法人身份证照片
    private MultipartFile businessFile;        //营业执照
    private MultipartFile orgcodeFile;         //门店信息
    private MultipartFile otherFile;           //其他证件
    
    // 一级佣金
    private BigDecimal bro1;
    // 二级佣金
    private BigDecimal bro2;
    // 三级佣金
    private BigDecimal bro3;
    // 总佣金
    private BigDecimal bro;

    public Channels() {
        super();
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public Integer getParentChannelId() {
        return parentChannelId;
    }

    public void setParentChannelId(Integer parentChannelId) {
        this.parentChannelId = parentChannelId;
    }

    public String getParentChannelCode() {
        return parentChannelCode;
    }

    public void setParentChannelCode(String parentChannelCode) {
        this.parentChannelCode = parentChannelCode;
    }

    public String getParentChannelName() {
        return parentChannelName;
    }

    public void setParentChannelName(String parentChannelName) {
        this.parentChannelName = parentChannelName;
    }

    public Integer getChannelIdLevel1() {
        return channelIdLevel1;
    }

    public void setChannelIdLevel1(Integer channelIdLevel1) {
        this.channelIdLevel1 = channelIdLevel1;
    }

    public Integer getChannelIdLevel2() {
        return channelIdLevel2;
    }

    public void setChannelIdLevel2(Integer channelIdLevel2) {
        this.channelIdLevel2 = channelIdLevel2;
    }
    
    public String getChannelNameLevel1() {
        return channelNameLevel1;
    }

    public void setChannelNameLevel1(String channelNameLevel1) {
        this.channelNameLevel1 = channelNameLevel1;
    }

    public String getChannelNameLevel2() {
        return channelNameLevel2;
    }

    public void setChannelNameLevel2(String channelNameLevel2) {
        this.channelNameLevel2 = channelNameLevel2;
    }

    public String getChannelNameLevel() {
        if (channelLevel == 1) {
            return "--";
        }else if (channelLevel == 2) {
            return channelNameLevel1;
        }else if (channelLevel == 3) {
            return channelNameLevel1 + " / " + channelNameLevel2;
        }
        return "";
    }

    public Integer getChannelLevel() {
        return channelLevel;
    }

    public void setChannelLevel(Integer channelLevel) {
        this.channelLevel = channelLevel;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }
    
    public String getChannelProperty() {
        if(channelLevel == null || channelType == null){
            return "";
        }
        if (channelLevel == 1) {
            return "一级渠道";
        }else if (channelLevel == 2 && channelType == 1) {
            return "二级渠道";
        }else if (channelLevel == 2 && channelType == 2) {
            return "直属网点";
        }else if (channelLevel == 3) {
            return "网点";
        }
        return "";
    }

    public String getBussContactName() {
        return bussContactName;
    }

    public void setBussContactName(String bussContactName) {
        this.bussContactName = bussContactName;
    }

    public String getBussContactPhone() {
        return bussContactPhone;
    }

    public void setBussContactPhone(String bussContactPhone) {
        this.bussContactPhone = bussContactPhone;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactIdcard() {
        return contactIdcard;
    }

    public void setContactIdcard(String contactIdcard) {
        this.contactIdcard = contactIdcard;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }
    
    public String getProvinceNameStr() {
        return provinceName + cityName;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIdcardLicense() {
        return idcardLicense;
    }

    public void setIdcardLicense(String idcardLicense) {
        this.idcardLicense = idcardLicense;
    }

    public String getBusinessLicense() {
        return businessLicense;
    }

    public void setBusinessLicense(String businessLicense) {
        this.businessLicense = businessLicense;
    }

    public String getOrgcodeLicense() {
        return orgcodeLicense;
    }

    public void setOrgcodeLicense(String orgcodeLicense) {
        this.orgcodeLicense = orgcodeLicense;
    }

    public String getOtherLicense() {
        return otherLicense;
    }

    public void setOtherLicense(String otherLicense) {
        this.otherLicense = otherLicense;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public String getStatusStr() {
        if (status == 1) {
            return "正常";
        }else if (status == 2) {
            return "待审核";
        }else if (status == 3) {
            return "<font class='red'>冻结开户</font>";
        }else if (status == 4) {
            return "<font class='red'>冻结</font>";
        }else if (status == 5) {
            return "审核不通过";
        }
        return status.toString();
    }
    
    public String getStatusExp() {
        if (status == 1) {
            return "正常";
        }else if (status == 2) {
            return "待审核";
        }else if (status == 3) {
            return "冻结开户";
        }else if (status == 4) {
            return "冻结";
        }else if (status == 5) {
            return "审核不通过";
        }
        return status.toString();
    }
    
    public String getAuthStatusStr() {
        if (status == 1) {
            return "审核通过";
        }else if (status == 2) {
            return "待审核";
        }else if (status == 3) {
            return "冻结开户";
        }else if (status == 4) {
            return "冻结";
        }else if (status == 5) {
            return "审核不通过";
        }
        return status.toString();
    }

    public Integer getSaleType() {
        return saleType;
    }
    
    public String getSaleTypeStr() {
        if (saleType == 2) {
            return "线上";
        } else {
            return "线下";
        }
    }

    public void setSaleType(Integer saleType) {
        this.saleType = saleType;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getAuthComment() {
        return authComment;
    }

    public void setAuthComment(String authComment) {
        this.authComment = authComment;
    }

    public Date getAuthTime() {
        return authTime;
    }

    public void setAuthTime(Date authTime) {
        this.authTime = authTime;
    }

    public Integer getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(Integer checkStatus) {
        this.checkStatus = checkStatus;
    }
    
    public String getCheckStatusStr() {
        if(checkStatus == 1) {
            return "待稽查";
        }else if(checkStatus == 2) {
            return "合规";
        }else if(checkStatus == 3) {
            return "" + checkComment ;
        }else if(checkStatus == 4) {
            return "重新提交";
        }
        return checkStatus + "";
    }
    
    public String getCheckStatusExp() {
        if(checkStatus == 1) {
            return "待稽查";
        }else if(checkStatus == 2) {
            return "合规";
        }else if(checkStatus == 3) {
            return "不合规：" + checkComment;
        }else if(checkStatus == 4) {
            return "重新提交";
        }
        return checkStatus + "";
    }

    public String getCheckComment() {
        return checkComment;
    }

    public void setCheckComment(String checkComment) {
        this.checkComment = checkComment;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
    public String getCreateTimeExp() {
        if(createTime == null){
            return "";
        }
        return DateUtil.getInstance().formatDate(createTime, "yyyy-MM-dd");
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getAccountBalanceKK() {
        return accountBalanceKK;
    }

    public void setAccountBalanceKK(BigDecimal accountBalanceKK) {
        this.accountBalanceKK = accountBalanceKK;
    }

    public BigDecimal getAccountBalanceHb() {
        return accountBalanceHb;
    }

    public void setAccountBalanceHb(BigDecimal accountBalanceHb) {
        this.accountBalanceHb = accountBalanceHb;
    }

    public BigDecimal getAccountBalanceZc() {
        return accountBalanceZc;
    }

    public void setAccountBalanceZc(BigDecimal accountBalanceZc) {
        this.accountBalanceZc = accountBalanceZc;
    }

    public BigDecimal getAccountBalanceYJ() {
        return accountBalanceYJ;
    }

    public void setAccountBalanceYJ(BigDecimal accountBalanceYJ) {
        this.accountBalanceYJ = accountBalanceYJ;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getuId() {
        return uId;
    }

    public void setuId(Integer uId) {
        this.uId = uId;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public Integer getOpenCardAnth() {
        return openCardAnth;
    }

    public void setOpenCardAnth(Integer openCardAnth) {
        this.openCardAnth = openCardAnth;
    }

    public Integer getOpenAccountMode() {
        return openAccountMode;
    }

    public void setOpenAccountMode(Integer openAccountMode) {
        this.openAccountMode = openAccountMode;
    }

    public Integer getAppImg() {
        return appImg;
    }

    public void setAppImg(Integer appImg) {
        this.appImg = appImg;
    }

    public Integer getAppFace() {
        return appFace;
    }

    public void setAppFace(Integer appFace) {
        this.appFace = appFace;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }

    public MultipartFile getIdcardFile() {
        return idcardFile;
    }

    public void setIdcardFile(MultipartFile idcardFile) {
        this.idcardFile = idcardFile;
    }

    public MultipartFile getBusinessFile() {
        return businessFile;
    }

    public void setBusinessFile(MultipartFile businessFile) {
        this.businessFile = businessFile;
    }

    public MultipartFile getOrgcodeFile() {
        return orgcodeFile;
    }

    public void setOrgcodeFile(MultipartFile orgcodeFile) {
        this.orgcodeFile = orgcodeFile;
    }

    public MultipartFile getOtherFile() {
        return otherFile;
    }

    public void setOtherFile(MultipartFile otherFile) {
        this.otherFile = otherFile;
    }

    public Integer getAmount2() {
        return amount2;
    }

    public void setAmount2(Integer amount2) {
        this.amount2 = amount2;
    }

    public Integer getAmount3() {
        return amount3;
    }

    public void setAmount3(Integer amount3) {
        this.amount3 = amount3;
    }

    public Integer getIsAuth() {
        return isAuth;
    }

    public void setIsAuth(Integer isAuth) {
        this.isAuth = isAuth;
    }
    
    public String getIsAuthStr() {
        if(isAuth != null){
            if(isAuth == 1){
                return "先审核";
            }else if(isAuth == 0){
                return "后复查";
            }
        }
        return "" + isAuth;
    }

    public Integer getIsImg() {
        return isImg;
    }

    public void setIsImg(Integer isImg) {
        this.isImg = isImg;
    }
    
    public String getIsImgStr() {
        if(isImg != null) {
            if(isImg == 1){
                return "开启";
            }else if(isImg == 0){
                return "关闭";
            }
        }
        return "" + isImg;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public BigDecimal getBro1() {
        return bro1;
    }
    
    public String getBro1Yuan() {
        if (null != bro1) {
            return Constant.df0.format(bro1.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setBro1(BigDecimal bro1) {
        this.bro1 = bro1;
    }

    public BigDecimal getBro2() {
        return bro2;
    }
    
    public String getBro2Yuan() {
        if (null != bro2) {
            return Constant.df0.format(bro2.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setBro2(BigDecimal bro2) {
        this.bro2 = bro2;
    }

    public BigDecimal getBro3() {
        return bro3;
    }
    
    public String getBro3Yuan() {
        if (null != bro3) {
            return Constant.df0.format(bro3.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setBro3(BigDecimal bro3) {
        this.bro3 = bro3;
    }

    public BigDecimal getBro() {
        return bro;
    }
    
    public String getBroYuan() {
        if (bro1 == null) {
            bro1 = new BigDecimal(0);
        }
        if (bro2 == null) {
            bro2 = new BigDecimal(0);
        }
        if (bro3 == null) {
            bro3 = new BigDecimal(0);
        }
        bro = bro1.add(bro2).add(bro3);
        return Constant.df0.format(bro.divide(Constant.cnt100)).toString();
    }

    public void setBro(BigDecimal bro) {
        this.bro = bro;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Integer getAccount_type() {
        return account_type;
    }

    public void setAccount_type(Integer account_type) {
        this.account_type = account_type;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public String getsDate() {
        return sDate;
    }

    public void setsDate(String sDate) {
        this.sDate = sDate;
    }

    public String geteDate() {
        return eDate;
    }

    public void seteDate(String eDate) {
        this.eDate = eDate;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return "Channels [ 渠道名称=" + channelName + ", 渠道编码=" + channelCode
                + ", 上级渠道编码=" + parentChannelCode + ", 上级渠道名称=" + parentChannelName
                + ", 渠道级别=" + channelLevel + ", 渠道类型=" + channelType
                + ", 联系人=" + bussContactName + ", 联系人电话=" + bussContactPhone
                + ", 法人名称=" + contactName + ", 法人身份证信息=" + contactIdcard 
                + ", 所在省份=" + provinceName + ", 所在城市=" + cityName
                + ", 所在地区=" + areaName + ", 地址=" + address + ", 营业执照=" + businessLicense
                + ", 门店信息=" + orgcodeLicense + ", 其他=" + otherLicense + ", 状态=" + getStatusStr()
                + ", 市场人员ID=" + userId + ", 创建人ID=" + createId + ", 创建时间=" + createTime + ", 修改人ID=" + updateId 
                + ", 修改时间=" + updateTime + "]";
    }
    
    
}
