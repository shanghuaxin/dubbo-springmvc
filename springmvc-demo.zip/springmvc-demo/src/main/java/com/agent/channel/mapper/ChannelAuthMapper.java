package com.agent.channel.mapper;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelAuth;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelAuthMapper extends BaseMapper<ChannelAuth,Integer>{
    
    public ChannelAuth findByChannelId(Integer channelId);
    //更新下级代理商实名设置
    public void batchUpdateChildAuth(ChannelAuth channelAuth);
    //添加下级代理商实名设置
    public void batchInsertChildAuth(Integer channelId);

}
