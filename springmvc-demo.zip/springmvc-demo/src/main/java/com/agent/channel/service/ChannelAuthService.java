package com.agent.channel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.channel.entity.ChannelAuth;
import com.agent.channel.mapper.ChannelAuthMapper;

import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service("channelAuthService")
public class ChannelAuthService {
    
    @Autowired
    private ChannelAuthMapper channelAuthMapper;
    
    public ChannelAuth findByChannelId(Integer channelId){
        return channelAuthMapper.findByChannelId(channelId);
    }
    
    //是否使用开卡
//    public Boolean isPhotoOpen(Integer channelId){
//        Boolean isOpen = false;
//        ChannelAuth channelAuth = channelAuthMapper.findByChannelId(channelId);
//        if(channelAuth.getIsImg() == 1 || channelAuth.getIsUploadImg() == 1){
//            isOpen=true;
//        }
//        return isOpen;
//    }

    //是否需要上传照片  1.个性化设置必须上传相片     2.没有个性化设置。配置为准
    public Boolean isUploadFile(Integer channelId){
        Boolean isOpen = false;
        //是否需要上传相片的值
        ChannelAuth channelAuth = channelAuthMapper.findByChannelId(channelId);
        if(channelAuth.getIsImg() == 1 || channelAuth.getIsImg() == 1){
            isOpen = true;
        }
        return isOpen;
    }

    //是否需要开卡审核,默认需要
    public Boolean isCheck(Integer channelId){
        Boolean isOpen = true;
        ChannelAuth channelAuth = channelAuthMapper.findByChannelId(channelId);
        if(channelAuth.getIsAuth() == 0){
            isOpen = false;
        }
        return isOpen;
    }

}
