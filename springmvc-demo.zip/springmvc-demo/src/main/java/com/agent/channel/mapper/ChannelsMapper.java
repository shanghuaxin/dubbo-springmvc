package com.agent.channel.mapper;

import java.util.List;
import java.util.Map;

import com.agent.channel.dto.ChannelsDto;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.agent.channel.entity.Channels;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelsMapper extends BaseMapper<Channels, Integer> {
    
    public List<Channels> listChannels(Map<String, Object> params);
    public Integer countTotal(Map<String, Object> params);
    //v3.2.0版本优化更新列表
    public List<Channels> newListChannels(Map<String, Object> params);
    public Integer newCountTotal(Map<String, Object> params);
    //v3.2.0账户记录
    public List<Channels> newListChannelAccount(Map<String, Object> params);
    public Integer newAccountCountTotal(Map<String, Object> params);
    
    public List<Channels> findThreeByProperty(Map<String, Object> params);
    public Integer authThreeCountTotal(Map<String, Object> params);
    //根据用户Id查找渠道信息
    public Channels findByUserId(Integer userId);
    //根据渠道编码查找渠道信息
    public Channels findChannelByCodeAndPid(@Param(value="channelCode")String channelCode, @Param(value="parentChannelId")String parentChannelId);
    public Channels findById(Integer id);
    public Channels findByCode(@Param(value="channelCode")String channelCode);
    public Channels findByPid(Integer id);
    //根据开户渠道（编码）查找渠道ID
    public List<Integer> findByCodeOrName(@Param(value="openChannelName")String openChannelName);
    //根据开户渠道（名称）查找渠道ID
    public List<Integer> findByName(@Param(value="channelName")String channelName);
    //修改渠道状态
    public void updateStatus(Channels channels);
    //网点审核
    public void channelAuth(Channels channels);
    //资料稽查
    public void channelCheck(Channels channels);
    //一级（或总部）渠道查找下级渠道总个数
    public Integer findChannelByChannelIdLevel1(@Param(value="channelId") Integer channelId, @Param(value="channelLevel") Integer channelLevel);
    //二级渠道查找下级渠道总个数
    public Integer findChannelByChannelIdLevel2(@Param(value="channelId") Integer channelId, @Param(value="channelLevel") Integer channelLevel);
    //一级（或总部）渠道查找下级渠道详情
    public List<Channels> findChannelDetailByChannelIdLevel1(@Param(value="channelId") Integer channelId, @Param(value="channelLevel") Integer channelLevel);
    //二级渠道查找下级渠道详情
    public List<Channels> findChannelDetailByChannelIdLevel2(@Param(value="channelId") Integer channelId, @Param(value="channelLevel") Integer channelLevel);
    
    //一级渠道查找所有下级渠道详情（包含自己）
    public List<Channels> findChannelDetailByChannelId(@Param(value="channelId") Integer channelId);
    /**
     * 一级渠道查找三级网点待审核数
     * @param channelId  当前渠道ID
     * @param channelLevel  当前渠道级别
     * @return
     */
    public Integer findThreeChannelByChannelId(@Param(value="channelId") Integer channelId, @Param(value="channelLevel") Integer channelLevel);

    public List<ChannelsDto> listChannelDtos(Map<String, Object> params);
    
    /**
     * 统计代理商佣金
     * @param params
     * @return
     */
    public List<Channels> countLevelBro(Map<String, Object> params);
    
    /**
     * 统计代理商佣金(总记录数)
     * @param params
     * @return
     */
    public int countLevelBroTotal(Map<String, Object> params);
    
    /**
     * 根据渠道ID集合，获取渠道集合
     * @param ids
     * @return
     */
    public List<Channels> findChannelsByIds(List<Integer> ids);
    
    //根据号码ID查询开户渠道
    public Channels findByPhoneId(@Param(value="phoneId") Integer phoneId);
}
