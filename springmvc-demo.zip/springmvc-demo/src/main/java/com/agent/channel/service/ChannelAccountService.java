package com.agent.channel.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.mapper.ChannelAccountMapper;

import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service("channelAccountService")
public class ChannelAccountService {
    
    @Autowired
    private ChannelAccountMapper channelAccountMapper;
    
    public ChannelAccount findByChannelIdAndType(Integer channelId, Integer accountType){
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("channelId", channelId);
        params.put("accountType", accountType);
        
        return channelAccountMapper.findByChannelIdAndType(params);
    }
    
    /**
     * 更新冻结金额
     * @param map
     * @return
     */
    public int updateFreezeBalance(Map<String, Object> map) {
        return channelAccountMapper.updateFreezeBalance(map);
    }
    
    /**
     * 佣金统计
     * @param map
     * @return
     */
    public BigDecimal statisticsChannelBrokerage(Map<String, Object> map) {
        return channelAccountMapper.statisticsChannelBrokerage(map);
    }
    
    public int update(ChannelAccount channelAccount) {
        return channelAccountMapper.update(channelAccount);
    }
}
