package com.agent.channel.mapper;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.PayTranscode;
import com.agent.common.BaseMapper;

@Repository
public interface PayTranscodeMapper extends BaseMapper<PayTranscode, Integer> {

}
