package com.agent.channel.mapper;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelPush;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelPushMapper extends BaseMapper<ChannelPush, Integer> {

}
