package com.agent.channel.mapper;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelUser;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelUserMapper extends BaseMapper<ChannelUser, Integer> {

}
