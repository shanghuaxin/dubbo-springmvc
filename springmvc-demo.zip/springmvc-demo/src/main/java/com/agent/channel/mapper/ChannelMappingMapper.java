package com.agent.channel.mapper;

import org.springframework.stereotype.Repository;

import com.agent.channel.entity.ChannelMapping;
import com.agent.common.BaseMapper;

@Repository
public interface ChannelMappingMapper extends BaseMapper<ChannelMapping, Integer> {

}
