package com.agent.channel.entity;

/**
 * 渠道与用户关系表
 * @author weijialiang
 *
 */
public class ChannelUser {
    
    private Integer channelId;   //渠道ID
    private Integer userId;      //用户ID
    private Integer type;        //类型，0： Channel admin，1：Channel user
   
    public ChannelUser() {
        super();
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "ChannelUser [channelId=" + channelId + ", userId=" + userId + ", type=" + type + "]";
    }
}
