package com.agent.channel.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.entity.ChannelAuth;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelAccountTransactionService;
import com.agent.channel.service.ChannelAuthService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.constant.Constant;
import com.agent.order.service.OrderDetailService;
import com.agent.product.entity.Packages;
import com.agent.product.entity.Product;
import com.agent.product.service.PackagesService;
import com.agent.product.entity.ProductDefBro;
import com.agent.product.service.ProductDefBroService;

import com.agent.product.service.ProductService;
import com.agent.system.entity.User;
import com.agent.system.service.CityService;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;
import com.agent.util.IDCardUtil;

@Controller
@RequestMapping("channel")
public class ChannelController {
    
    private static Logger logger = LoggerFactory.getLogger(ChannelController.class);
    
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private ChannelAuthService channelAuthService;
    @Autowired
    private ChannelAccountService channelAccountService;
    @Autowired
    private ChannelAccountTransactionService transactionService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ProductDefBroService productDefBorService;
    @Autowired
    private CityService cityService;
    @Autowired
    private PackagesService packagesService;
    @Autowired
    private OrderDetailService orderDetailService;
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    
    @RequestMapping("/channelList" )
    public String channelList(HttpServletRequest request, Channels channels, Integer sortByAmount, String flag, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        //以下是渠道主页获取渠道信息
        Channels channel = channelsService.findChannelByUserId(user.getId());
        
        PageEntity pageEntity = new PageEntity(channels.getPageSize(), channels.getPageIndex());
        
        Map<String, Object> params = new HashMap<String, Object>();
//        Integer channelId = 0;
        
        if(channel == null) {
            params.put("channelLevel", 0);  //当前登录渠道级别，总部员工默认为0
            request.setAttribute("channelLevel", 0);
            if(channels.getLevel() == null) {
                params.put("level", 1);
                channels.setLevel(1);
            }
            request.setAttribute("curChannellevel", 0);  //当前渠道级别，界面判断使用
        }else {
            params.put("channelId", channel.getId());
            params.put("channelLevel", channel.getChannelLevel());
            request.setAttribute("curChannellevel", channel.getChannelLevel());
            if(channels.getLevel() == null) {
                params.put("level", channel.getChannelLevel() + 1);
                channels.setLevel(channel.getChannelLevel() + 1);
            }
        }
        
        //界面跳转时用到（查询下级渠道列表信息）
        if(channels.getId() != null && channels.getChannelLevel() != null){
            params.put("channelId", channels.getId());
            params.put("channelLevel", channels.getChannelLevel());
        }
        
        // 设置分页初始化数据
        if (StringUtils.isNotBlank(channels.getChannelName())) {
            params.put("channelName", channels.getChannelName());
        }
        if(channels.getLevel() != null ) {
            params.put("level", channels.getLevel());
            if(channels.getLevel() == 0){
                params.remove("level");
            }
        }
        if (StringUtils.isNotBlank(channels.getChannelNameLevel1())) {
            List<Integer> channelIds = channelsService.findByCodeOrName(channels.getChannelNameLevel1().trim());
            if(channelIds != null && channelIds.size() > 0){
                params.put("channelIds", channelIds);
            }else {
                channelIds.add(1);
                params.put("channelIds", channelIds);
            }
        }
        if (StringUtils.isNotBlank(channels.getLoginName())) {
            params.put("loginName", channels.getLoginName());
        }
        if (StringUtils.isNotBlank(channels.getProvinceName())) {
            params.put("provinceName", channels.getProvinceName());
        }
        if (channels.getStatus() != null) {
            params.put("status", channels.getStatus());
        }
        if (channels.getIsAuth() != null) {
            params.put("isAuth", channels.getIsAuth());
        }
        if (channels.getIsImg() != null) {
            params.put("isImg", channels.getIsImg());
        }
        if (channels.getCheckStatus() != null) {
            params.put("checkStatus", channels.getCheckStatus());
        }
        if (StringUtils.isNotBlank(channels.getsDate())) {
            params.put("sDate", channels.getsDate());
        }
        if (StringUtils.isNotBlank(channels.geteDate())) {
            params.put("eDate", channels.geteDate());
        }
        
        params.put("sortByAmount", sortByAmount);


     // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<Channels> channelList = channelsService.newListChannels(params);
        int total = channelsService.newCountTotal(params);
        pageEntity.setTotal(total);

        request.setAttribute("sortByAmount", sortByAmount);
        request.setAttribute("flag", flag);
        request.setAttribute("channelList", channelList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("channels", channels);
        
        //查找该页面的链接条件
        request.setAttribute("id", channels.getId());   

        return "/views/channel/channel/list.jsp";
    }
    
    @RequestMapping("/accountTransaction")
    public String accountTransaction(HttpServletRequest request, ChannelAccountTransaction transaction, Integer operation, String mainPage) {
        
//        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        
        //操作类型为空值是排错处理，无其他作用
        if(operation == null){
            operation = 0;
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(transaction.getPageSize(), transaction.getPageIndex());

        Map<String, Object> params = new HashMap<String, Object>();
        if (transaction.getChannelId() != null) {
            params.put("channelId", transaction.getChannelId());
        }
        if (transaction.getAccountType() != null) {
            params.put("accountType", transaction.getAccountType());
        }
        if (StringUtils.isNotBlank(transaction.getStartTimeStr())) {
            params.put("startTimeStr", transaction.getStartTimeStr());
        }
        if (StringUtils.isNotBlank(transaction.getEndTimeStr())) {
            params.put("endTimeStr", transaction.getEndTimeStr());
        }
        params.put("operationType", operation);

        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<ChannelAccountTransaction> transactionList = transactionService.listTransation(params);
        int total = transactionService.countTotal(params);
        pageEntity.setTotal(total);

        request.setAttribute("transactionList", transactionList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("transaction", transaction);
        //一级渠道主页使用
        request.setAttribute("mainPage", mainPage);
        
        //加值记录
        if(operation == 2){
            return "/views/channel/channel/accounttransactionadd.jsp";
        }
        //账户记录
        return "/views/channel/channel/accounttransaction.jsp";
    }
    
    @RequestMapping(value = "/channelAdd")
    public String channelAdd(HttpServletRequest request , HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Channels channels = channelsService.findChannelByUserId(user.getId());
        
        Integer level = 0;
        Integer type = 1;
        // 销售渠道 1：线下(默认)，2： 线上
        Integer saleType = 1;
        if (channels != null) {
            if(channels.getChannelLevel() == 1) {
                level = 1;
            }else if(channels.getChannelLevel() == 2) {
                level = 2;
                type = 2;
            }
            if (null == channels.getSaleType()) {
                saleType = 1;
            } else {
                saleType = channels.getSaleType();
            }
        }
        request.setAttribute("level", level);
        request.setAttribute("type", type);
        request.setAttribute("saleType", saleType);
        
        return "/views/channel/channel/add.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveChannel"}, method = RequestMethod.POST, produces={"text/html;charset=UTF-8"})
    public String saveChannel(HttpServletRequest request ,Channels channels, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer str = new StringBuffer();
        
        if(!IDCardUtil.isIDCard(channels.getContactIdcard())){
            map.put("status", false);
            map.put("result", "请使用正确的身份证号码");
            str.append("FILE@UPLOAD");
            str.append(map.get("status")).append(":");
            str.append(map.get("result"));
            str.append("FILE@UPLOAD");
            return str.toString();
        }
        
        try {
            Channels channels2 = channelsService.findChannelByUserId(user.getId());
            
            Integer parentChannelId = null;
            if(channels2 == null){
                channels.setUserId(user.getId());
                channels.setChannelLevel(1);
                parentChannelId = user.getId();
            }else{
                channels.setUserId(channels2.getUserId());
                channels.setChannelLevel(channels2.getChannelLevel() + 1);
                channels.setParentChannelId(channels2.getId());
                channels.setParentChannelCode(channels2.getChannelCode());
                channels.setParentChannelName(channels2.getChannelName());
                if(channels.getChannelLevel() == 2){
                    channels.setChannelIdLevel1(channels2.getId());
//                    channels.setChannelIdLevel2(0);
                }else{
                    channels.setChannelIdLevel1(channels2.getChannelIdLevel1());
                    channels.setChannelIdLevel2(channels2.getId());
                }
                parentChannelId = channels2.getId();
            }
            
            String areaCode = channels.getAreaCode().substring(channels.getAreaCode().length() - 3, channels.getAreaCode().length());
            
            String channelCode = channelsService.findChannelCodeByLevel(channels.getChannelLevel(), channels.getChannelType(), areaCode, parentChannelId);
            channels.setChannelCode(channelCode);
            
            //保存营业执照image，并获取营业执照图片地址
            channels.setIdcardLicense(saveImageFile(channels.getIdcardFile(), null, channelCode));
            //保存营业执照image，并获取营业执照图片地址
            if(channels.getBusinessFile() != null && channels.getBusinessFile().getSize() > 0){
                channels.setBusinessLicense(saveImageFile(channels.getBusinessFile(), null, channelCode));
            }
            //保存门店信息image，并火气门店信息图片地址
            if(channels.getOrgcodeFile() != null && channels.getOrgcodeFile().getSize() > 0){
                channels.setOrgcodeLicense(saveImageFile(channels.getOrgcodeFile(), null, channelCode));
            }
            //保存营业执照image，并获取营业执照图片地址
            if(channels.getOtherFile() != null && channels.getOtherFile().getSize() > 0){
                channels.setOtherLicense(saveImageFile(channels.getOtherFile(), null, channelCode));
            }
            
            //当创建的渠道为代理商时,如果创建的渠道为3级网点或者直属网点，则渠道状态为“2：待审核”
            if(channels.getChannelType() == 2){
                channels.setStatus(2);
            }else{
                channels.setStatus(1);
            }
            
            Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
            channels.setCreateId(user.getId());
            channels.setCreateTime(newDate);
            channels.setUpdateId(user.getId());
            channels.setUpdateTime(newDate);
            
            channelsService.saveChannel(channels, user);
            map.put("status", true);
        } catch (Exception e) {
            map.put("status", false);
            map.put("result", "操作失败！");
            logger.error(e.getMessage(), e);
        }
        str.append("FILE@UPLOAD");
        str.append(map.get("status")).append(":");
        str.append(map.get("result"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
    
    @RequestMapping(value = "/view")
    public String view(HttpServletRequest request, Channels c, Integer sortByAmount, String flag, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            logger.error("session过期");
            return "login.jsp";
        }
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        String type = request.getParameter("type");  //主要为了审核列表、渠道列表查看
        String channelIdStr = request.getParameter("channelId");
        if(StringUtils.isNotBlank(channelIdStr)){
            Integer channelId = Integer.parseInt(channelIdStr);
            c.setId(channelId);
        }else {
            c.setId(null);
        }
        
        Channels channels = channelsService.findById(id);
        
        if(StringUtils.isNotBlank(channels.getIdcardLicense())){
            channels.setIdcardLicense(resourceIP + channels.getIdcardLicense());
        }
        if(StringUtils.isNotBlank(channels.getBusinessLicense())){
            channels.setBusinessLicense(resourceIP + channels.getBusinessLicense());
        }
        if(StringUtils.isNotBlank(channels.getOrgcodeLicense())){
            channels.setOrgcodeLicense(resourceIP + channels.getOrgcodeLicense());
        }
        if(StringUtils.isNotBlank(channels.getOtherLicense())){
            channels.setOtherLicense(resourceIP + channels.getOtherLicense());
        }
        
        request.setAttribute("channels2", channels);
        
        if(!StringUtils.equals(type, "auth")) {
            request.setAttribute("view", "view");
        }
        request.setAttribute("type", type);
        //以下条件返回渠道列表时使用
        request.setAttribute("sortByAmount1", sortByAmount);
        request.setAttribute("flag1", flag);
        request.setAttribute("channelId1", c.getId());
        request.setAttribute("channelLevel1", c.getChannelLevel());
        try {
            if(StringUtils.isNotBlank(c.getChannelName())){
                c.setChannelName(URLDecoder.decode(c.getChannelName(),"utf-8"));
            }
            if(StringUtils.isNotBlank(c.getChannelNameLevel1())){
                c.setChannelNameLevel1(URLDecoder.decode(c.getChannelNameLevel1(),"utf-8"));
            }
            if(StringUtils.isNotBlank(c.getProvinceName())){
                c.setProvinceName(URLDecoder.decode(c.getProvinceName(),"utf-8"));
            }
        } catch (Exception e) {
            logger.error("渠道名称转换异常："+e.getMessage(), e);
        }
        request.setAttribute("channelName1", c.getChannelName());
        request.setAttribute("level1", c.getLevel());
        request.setAttribute("channelNameLevel11", c.getChannelNameLevel1());
        request.setAttribute("loginName1", c.getLoginName());
        request.setAttribute("provinceName1", c.getProvinceName());
        request.setAttribute("status1", c.getStatus());
        request.setAttribute("isImg1", c.getIsImg());
        request.setAttribute("isAuth1", c.getIsAuth());
        request.setAttribute("checkStatus1", c.getCheckStatus());
        request.setAttribute("sDate1", c.getsDate());
        request.setAttribute("eDate1", c.geteDate());
        request.setAttribute("pageIndex1", c.getPageIndex());
        request.setAttribute("pageSize1", c.getPageSize());
        
        return "/views/channel/channel/view.jsp";
    }
    
    @RequestMapping(value = "/channelUpdate")
    public String channelUpdate(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            logger.error("session过期");
            return "login.jsp";
        }
        //获取当前登录渠道信息
        Channels channel = channelsService.findChannelByUserId(user.getId());
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        String type = request.getParameter("type");  //主要为了审核列表、渠道列表查看
        
        Channels channels = channelsService.findById(id);
        
        if(StringUtils.isNotBlank(channels.getIdcardLicense())){
            channels.setIdcardLicense(resourceIP + channels.getIdcardLicense());
        }
        if(StringUtils.isNotBlank(channels.getBusinessLicense())){
            channels.setBusinessLicense(resourceIP + channels.getBusinessLicense());
        }
        if(StringUtils.isNotBlank(channels.getOrgcodeLicense())){
            channels.setOrgcodeLicense(resourceIP + channels.getOrgcodeLicense());
        }
        if(StringUtils.isNotBlank(channels.getOtherLicense())){
            channels.setOtherLicense(resourceIP + channels.getOtherLicense());
        }
        
        request.setAttribute("channels", channels);
        if(channel == null || channel.getChannelType() == 1){
            request.setAttribute("view", "view");
        }
        request.setAttribute("type", type);
        
        return "/views/channel/channel/update.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/modifyChannel"}, method = RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    public String modifyChannel(HttpServletRequest request ,Channels channels, HttpSession session){
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer str = new StringBuffer();
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            
            if (StringUtils.isNotBlank(channels.getIdcardLicense())) {
                channels.setIdcardLicense(channels.getIdcardLicense().substring(resourceIP.length(), channels.getIdcardLicense().length()));
            }
            if (StringUtils.isNotBlank(channels.getBusinessLicense())) {
                channels.setBusinessLicense(channels.getBusinessLicense().substring(resourceIP.length(), channels.getBusinessLicense().length()));
            }
            if (StringUtils.isNotBlank(channels.getOrgcodeLicense())) {
                channels.setOrgcodeLicense(channels.getOrgcodeLicense().substring(resourceIP.length(), channels.getOrgcodeLicense().length()));
            }
            if (StringUtils.isNotBlank(channels.getOtherLicense())) {
                channels.setOtherLicense(channels.getOtherLicense().substring(resourceIP.length(), channels.getOtherLicense().length()));
            }
            
            if (!IDCardUtil.isIDCard(channels.getContactIdcard())) {
                map.put("status", false);
                map.put("result", "请使用正确的身份证号码");
                str.append("FILE@UPLOAD");
                str.append(map.get("status")).append(":");
                str.append(map.get("result"));
                str.append("FILE@UPLOAD");
                return str.toString();
            }
            // 截取日期字符串
            String timexf = null;
            if(StringUtils.isNoneEmpty(channels.getBusinessLicense()) && !StringUtils.equals(channels.getBusinessLicense(), "null")){
                if(channels.getBusinessLicense().indexOf("ditchMessage") < 0){
                    timexf = channels.getBusinessLicense().substring(resourceIP.length() + 10, resourceIP.length() + 18);
                }
            }
            
            if (channels.getIdcardFile() != null && channels.getIdcardFile().getSize() > 0) {
                // 保存门店信息image，并获取门店信息图片地址
                channels.setIdcardLicense(saveImageFile(channels.getIdcardFile(), timexf, channels.getChannelCode()));
            }
            if (channels.getBusinessFile() != null && channels.getBusinessFile().getSize() > 0) {
                // 保存营业执照image，并获取营业执照图片地址
                channels.setBusinessLicense(saveImageFile(channels.getBusinessFile(), timexf, channels.getChannelCode()));
            }
            if (channels.getOrgcodeFile() != null && channels.getOrgcodeFile().getSize() > 0) {
                // 保存门店信息image，并火气门店信息图片地址
                channels.setOrgcodeLicense(saveImageFile(channels.getOrgcodeFile(), timexf, channels.getChannelCode()));
            }
            if (channels.getOtherFile() != null && channels.getOtherFile().getSize() > 0) {
                // 保存门店信息image，并火气门店信息图片地址
                channels.setOtherLicense(saveImageFile(channels.getOtherFile(), timexf, channels.getChannelCode()));
            }
            
            Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
            channels.setUpdateId(user.getId());
            channels.setUpdateTime(newDate);
            // 二级渠道对审核不通过的网点资料重新提交，一级渠道对审核不通过的直属网点资料重新提交
            if (channels.getStatus() == 5) {
                channels.setStatus(2);
                channels.setAuthComment("重新提交资料");
            }
            
            channelsService.modifyChannel(channels, user);
            map.put("status", true);
        } catch (Exception e) {
            map.put("status", false);
            map.put("result", "操作失败！");
            logger.error(e.getMessage(), e);
        }
        str.append("FILE@UPLOAD");
        str.append(map.get("status")).append(":");
        str.append(map.get("result"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
    
    @RequestMapping(value = "/freeze")
    public String freeze(HttpServletRequest request ){
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        request.setAttribute("channels", channels);
        
        return "/views/channel/channel/frozen.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/frozen"}, method = RequestMethod.POST)
    public boolean frozen(HttpServletRequest request ,Channels channels, HttpSession session){
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        channels.setStatus(4);
        try {
            channelsService.frozenChannel(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        
        return true;
    }
    
    @ResponseBody
    @RequestMapping("/resetPwd")
    public Map<String, Object> resetPwd(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);

        try {
            channelsService.resetPwd(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        return map;
    }
    
    @ResponseBody
    @RequestMapping("/unfreeze")
    public Map<String, Object> unfreeze(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        
        Channels channels = channelsService.findById(id);
        
        Channels channel = channelsService.findById(channels.getParentChannelId());
        if(channel != null){
            if(channel.getStatus() == 4){
                map.put("status", false);
                map.put("msg", "解冻失败！原因：上级渠道已被冻结");
                return map;
            }else if(channel.getStatus() == 3) {
                //如果上级渠道已被冻结开户，则解冻后的渠道状态也将是解冻开户
                channels.setStatus(3);
                channels.setComment(channel.getComment());
            }else {
                channels.setStatus(1);
            }
        }else {
            channels.setStatus(1);
        }
        
        try {
            channelsService.frozenChannel(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        map.put("status", true);
        return map;
    }
    
    @RequestMapping(value = "/freezeAccount")
    public String freezeAccount(HttpServletRequest request ){
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        request.setAttribute("channels", channels);
        
        return "/views/channel/channel/frozenOpenAccount.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/frozenAccount"}, method = RequestMethod.POST)
    public boolean frozenAccount(HttpServletRequest request ,Channels channels, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        channels.setStatus(3);
        try {
            channelsService.frozenAccount(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        
        return true;
    }
    
    @ResponseBody
    @RequestMapping("/unfreezeAccount")
    public Map<String, Object> unfreezeAccount(HttpServletRequest request, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        
        Channels channels = channelsService.findById(id);
        
        Channels channel = channelsService.findById(channels.getParentChannelId());
        if(channel != null){
            if(channel.getStatus() == 4){
                map.put("status", false);
                map.put("msg", "解冻开户失败！原因：上级渠道已被冻结");
                return map;
            }else if(channel.getStatus() == 3) {
                map.put("status", false);
                map.put("msg", "解冻开户失败！原因：上级渠道已被冻结开户");
                return map;
            }
        }
        channels.setStatus(1);
        try {
            channelsService.frozenAccount(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        map.put("status", true);
        return map;
    }
    
    @RequestMapping(value = "/batchFreeze")
    public String batchFreeze(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String ids = request.getParameter("ids");
        Integer id = Integer.parseInt(ids.split(",")[0]);
        Channels channels = channelsService.findById(id);
        //以下是渠道主页获取渠道信息(父级渠道)
        Channels channel = null;
        if(channels.getParentChannelId() != null){
            channel = channelsService.findById(channels.getParentChannelId());
        }
        if(channel == null){
            request.setAttribute("level", 0);
            request.setAttribute("pStatus", 1);
        }else{
            request.setAttribute("level", channel.getChannelLevel());
            request.setAttribute("pStatus", channel.getStatus());
        }
        
        request.setAttribute("ids", ids);
        request.setAttribute("channels", channels);
        
        return "/views/channel/channel/batchFrozen.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/batchFrozen"}, method = RequestMethod.POST)
    public Map<String, Object> batchFrozen(HttpServletRequest request ,Channels channels, HttpSession session){
        Map<String, Object> map = new HashMap<String, Object>();
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        if(StringUtils.isNoneBlank(channels.getIds())){
            Integer id = Integer.parseInt(channels.getIds().split(",")[0]);
            Channels c = channelsService.findById(id);
            //以下是渠道主页获取渠道信息(父级渠道)
            if(c.getParentChannelId() != null){
                Channels channel = channelsService.findById(c.getParentChannelId());
                if(channel != null && channel.getStatus() == 4 && channels.getStatus() == 3){
                    map.put("status", false);
                    map.put("msg", "批量冻结失败！原因：上级渠道已被冻结");
                    return map;
                }
            }
        }
        
        try {
            RestStatus rs = channelsService.BatchFrozenChannel(channels, user);
            if(!rs.getStatus()){
                map.put("status", false);
                map.put("msg", rs.getErrorMessage());
                return map;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            
            map.put("status", false);
            map.put("msg", "批量设置异常，请联系客服");
            return map;
        }
        
        map.put("status", true);
        map.put("msg", "批量冻结设置成功！");
        return map;
    }
    
    @ResponseBody
    @RequestMapping("/batchUnfrozen")
    public Map<String, Object> batchUnfrozen(HttpServletRequest request, HttpSession session){
        Map<String,Object> map = new HashMap<String,Object>();
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String ids = request.getParameter("ids");
        
        Channels channels = new Channels();
        channels.setIds(ids);
        channels.setStatus(1);
        if(StringUtils.isNoneBlank(ids)) {
            Integer id = Integer.parseInt(ids.split(",")[0]);
            Channels c = channelsService.findById(id);
            //以下是渠道主页获取渠道信息(父级渠道)
            Channels channel = null;
            if(c.getParentChannelId() != null){
                channel = channelsService.findById(c.getParentChannelId());
                
                if(channel != null){
                    if(channel.getStatus() == 4){
                        map.put("status", false);
                        map.put("msg", "批量解冻失败！原因：上级渠道已被冻结");
                        return map;
                    }else if(channel.getStatus() == 3) {
                        //如果上级渠道已被冻结开户，则解冻后的渠道状态也将是解冻开户
                        channels.setComment(channel.getComment());
                        channels.setStatus(3);
                    }
                }
            }
        }
        
        try {
            channelsService.frozenChannel(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map.put("status", true);
            map.put("msg", "批量解冻失败！请联系客服");
            return map;
        }
        map.put("status", true);
        map.put("msg", "批量解冻成功！");
        return map;
    }
    
    @ResponseBody
    @RequestMapping("/batchUnfreezeAccount")
    public Map<String, Object> batchUnfreezeAccount(HttpServletRequest request, HttpSession session){
        Map<String,Object> map = new HashMap<String,Object>();
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String ids = request.getParameter("ids");
        if(StringUtils.isNoneBlank(ids)) {
            Integer id = Integer.parseInt(ids.split(",")[0]);
            Channels c = channelsService.findById(id);
            //以下是渠道主页获取渠道信息(父级渠道)
            Channels channel = null;
            if(c.getParentChannelId() != null){
                channel = channelsService.findById(c.getParentChannelId());
                
                if(channel != null){
                    if(channel.getStatus() == 4){
                        map.put("status", false);
                        map.put("msg", "批量解冻开户失败！原因：上级渠道已被冻结");
                        return map;
                    }else if(channel.getStatus() == 3) {
                        map.put("status", false);
                        map.put("msg", "批量解冻开户失败！原因：上级渠道已被冻结开户");
                        return map;
                    }
                }
            }
        }
        
        Channels channels = new Channels();
        channels.setIds(ids);
        channels.setStatus(1);
        try {
            channelsService.frozenAccount(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map.put("status", true);
            map.put("msg", "批量解冻开户失败！请联系客服");
            return map;
        }
        map.put("status", true);
        map.put("msg", "批量解冻开户成功！");
        return map;
    }
    
    @RequestMapping(value = "/brokerageset")
    public String brokerageset(HttpServletRequest request , HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        int userType = channelsService.findUserTypeByUser(user);
        
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        //查询佣金设置的渠道级别
        Channels channels = channelsService.findById(id);
        if(channels.getChannelLevel() == 1){
            request.setAttribute("channelLevel", 1);
        }else if(channels.getChannelLevel() == 2 && channels.getChannelType() == 1) {
            request.setAttribute("channelLevel", 2);
        }else {
            request.setAttribute("channelLevel", 3);
        }
        
        //170佣金设置
        List<Packages> packages = null;
        if(channels.getChannelLevel() == 1) {
            packages = packagesService.findAllByPropertyAndChannelId("2", "0", id);//查询已发布的套餐
        }else {
            //非一级渠道，发布的套餐跟一级渠道相同
            packages = packagesService.findAllByPropertyAndChannelId("2", "0", channels.getChannelIdLevel1());//查询已发布的套餐
        }
        //套餐业务
        List<ProductDefBro> bros = new ArrayList<ProductDefBro>();
        Integer productId = 0;
        //获取第一个已发布的产品Id
        if(packages != null && packages.size() > 0){
            productId = packages.get(0).getId();
            try {
                bros = packagesService.listPackagesDefBor(productId, id);
            } catch (Exception e) {
                logger.error("查看套餐失败，原因："+e.getMessage(),e);
                e.printStackTrace();
            }
        }
        //cool170产品
        List<Product> products = null;
        if(channels.getChannelLevel() == 1) {
            products = productService.findByChannelIdAndCategory(id, 0);//查询已发布的套餐
        }else {
            //非一级渠道，发布的产品跟一级渠道相同
            products = productService.findByChannelIdAndCategory(channels.getChannelIdLevel1(), 0);  //查询已发布的产品
        }
        
        //流量充值
        ProductDefBro productDefBor = productDefBorService.findCZByChannelIdAndProductId(id, 0, "3");
        //170话费
        ProductDefBro productDefBor170 = productDefBorService.findCZByChannelIdAndProductId(id, 0, "4");
        //联通流量充值
        ProductDefBro lt_productDefBor = productDefBorService.findCZByChannelIdAndProductId(id, 0, "5");
        //联通170话费
        ProductDefBro lt_productDefBor170 = productDefBorService.findCZByChannelIdAndProductId(id, 0, "6");
        if(productDefBor == null){
            productDefBor = new ProductDefBro();
        }
        if(productDefBor170 != null) {
            productDefBor.setChannelBro4(productDefBor170.getChannelBro1());
            productDefBor.setChannelBro5(productDefBor170.getChannelBro2());
            productDefBor.setChannelBro6(productDefBor170.getChannelBro3());
        }
        if(lt_productDefBor != null) {
            productDefBor.setChannelBro7(lt_productDefBor.getChannelBro1());
            productDefBor.setChannelBro8(lt_productDefBor.getChannelBro2());
            productDefBor.setChannelBro9(lt_productDefBor.getChannelBro3());
        }
        if(lt_productDefBor170 != null) {
            productDefBor.setChannelBro10(lt_productDefBor170.getChannelBro1());
            productDefBor.setChannelBro11(lt_productDefBor170.getChannelBro2());
            productDefBor.setChannelBro12(lt_productDefBor170.getChannelBro3());
        }
        
        request.setAttribute("channelId", id);
        request.setAttribute("products", products);
//        request.setAttribute("czProducts", czProducts);
        request.setAttribute("productDefBor", productDefBor);
        request.setAttribute("userType", userType);    //按钮隐藏
        request.setAttribute("packages", packages);
        request.setAttribute("bros", bros);
        request.setAttribute("productId", productId);
        
        return "/views/channel/channel/brokeragesetting.jsp";
    }
    
    //170、  COOL170佣金设置
    @ResponseBody
    @RequestMapping(value = {"/brokeragesetting"}, method = RequestMethod.POST)
    public boolean brokeragesetting(HttpServletRequest request ,ProductDefBro productDefBor, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        try {
            channelsService.brokeragesetting(productDefBor, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        
        return true;
    }
    
    //充值佣金设置
    @ResponseBody
    @RequestMapping(value = {"/czbrokeragesetting"}, method = RequestMethod.POST)
    public boolean czbrokeragesetting(HttpServletRequest request ,ProductDefBro productDefBor, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Date newDate = DateUtil.getInstance().parseDate(DateUtil.getNowDateTimeString("yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss");
        productDefBor.setCreateId(user.getId());
        productDefBor.setCreateTime(newDate);
        productDefBor.setUpdateId(user.getId());
        productDefBor.setUpdateTime(newDate);
        try {
            channelsService.czbrokeragesetting(productDefBor, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        
        return true;
    }
    
    @RequestMapping(value = "/brokerageview")
    public String brokerageview(HttpServletRequest request ){
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        
        //cool170产品
//        List<Brokerage> brokerages = brokerageService.findByChannelIdAndCategory(id, 0);
        List<Product> products = productService.findByChannelIdAndCategory(id, 0);
        //充值产品
        //流量充值
        ProductDefBro productDefBor = productDefBorService.findCZByChannelIdAndProductId(id, 0, "3");
        //170话费
        ProductDefBro productDefBor170 = productDefBorService.findCZByChannelIdAndProductId(id, 0, "4");
        //联通流量充值
        ProductDefBro lt_productDefBor = productDefBorService.findCZByChannelIdAndProductId(id, 0, "5");
        //联通170话费
        ProductDefBro lt_productDefBor170 = productDefBorService.findCZByChannelIdAndProductId(id, 0, "6");
        if(productDefBor == null){
            productDefBor = new ProductDefBro();
        }
        if(productDefBor170 != null) {
            productDefBor.setChannelBro4(productDefBor170.getChannelBro1());
            productDefBor.setChannelBro5(productDefBor170.getChannelBro2());
            productDefBor.setChannelBro6(productDefBor170.getChannelBro3());
        }
        if(lt_productDefBor != null) {
            productDefBor.setChannelBro7(lt_productDefBor.getChannelBro1());
            productDefBor.setChannelBro8(lt_productDefBor.getChannelBro2());
            productDefBor.setChannelBro9(lt_productDefBor.getChannelBro3());
        }
        if(lt_productDefBor170 != null) {
            productDefBor.setChannelBro10(lt_productDefBor170.getChannelBro1());
            productDefBor.setChannelBro11(lt_productDefBor170.getChannelBro2());
            productDefBor.setChannelBro12(lt_productDefBor170.getChannelBro3());
        }
        
        request.setAttribute("channelId", id);
        request.setAttribute("products", products);
        request.setAttribute("productDefBor", productDefBor);
        
        return "/views/channel/channel/brokerageview.jsp";
    }
    
    @RequestMapping(value = "/realname")
    public String realname(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        //以下是渠道主页获取渠道信息
        Channels channel = null;
        if(channels.getParentChannelId() != null){
            channel = channelsService.findById(channels.getParentChannelId());
        }
        if (channel == null) {
            request.setAttribute("channelLevel", 0);
        } else {
            request.setAttribute("channelLevel", channel.getChannelLevel());
            
            ChannelAuth auth = channelAuthService.findByChannelId(channel.getId());
            if(auth != null){
                request.setAttribute("openCardAnth", auth.getIsAuth());
                request.setAttribute("openAccountMode", auth.getIsImg());
                request.setAttribute("appImg", auth.getIsAppImg());
                request.setAttribute("appFace", auth.getIsAppFace());
            }
        }
        
        
        ChannelAuth channelAuth = channelAuthService.findByChannelId(id);
        if (channelAuth != null) {
            channels.setOpenCardAnth(channelAuth.getIsAuth());
            channels.setOpenAccountMode(channelAuth.getIsImg());
            if (null == channelAuth.getIsAppImg()) {
                channels.setAppImg(0);
                channels.setAppFace(1);
            } else {
                channels.setAppImg(channelAuth.getIsAppImg());
                channels.setAppFace(channelAuth.getIsAppFace());
            }
        } else {
            channels.setOpenCardAnth(1);
            channels.setOpenAccountMode(1);
            channels.setAppImg(0);
            channels.setAppFace(1);
        }
        
        request.setAttribute("channels", channels);
        
        return "/views/channel/channel/realname.jsp";
    }
    
    @RequestMapping(value = "/batchRealname")
    public String batchRealname(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String ids = request.getParameter("ids");
        Integer id = Integer.parseInt(ids.split(",")[0]);
        Channels channels = channelsService.findById(id);
        //以下是渠道主页获取渠道信息
        Channels channel = null;
        if(channels.getParentChannelId() != null){
            channel = channelsService.findById(channels.getParentChannelId());
        }
        if(channel == null){
            request.setAttribute("channelLevel", 0);
            request.setAttribute("openCardAnth", 1);
            request.setAttribute("openAccountMode", 1);
            request.setAttribute("appImg", 0);
            request.setAttribute("appFace", 1);
        }else{
            request.setAttribute("channelLevel", channel.getChannelLevel());
            
            ChannelAuth auth = channelAuthService.findByChannelId(channel.getId());
            if(auth != null){
                request.setAttribute("openCardAnth", auth.getIsAuth());
                request.setAttribute("openAccountMode", auth.getIsImg());
                request.setAttribute("appImg", auth.getIsAppImg());
                request.setAttribute("appFace", auth.getIsAppFace());
            }
        }
        
        request.setAttribute("ids", ids);
        request.setAttribute("channels", channels);
        
        return "/views/channel/channel/batchRealname.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/realnameSetting"}, method = RequestMethod.POST)
    public boolean realnameSetting(HttpServletRequest request ,Channels channels, HttpSession session){
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        try {
            channelsService.realnameSetting(channels, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        
        return true;
    }
    
    @RequestMapping(value = "/accountHb")
    public String accountHb(HttpServletRequest request ){
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        
        String ransactionId = "";
        
        if(channels.getParentChannelId() != null){
            ChannelAccount channelAccountHb = channelAccountService.findByChannelIdAndType(channels.getParentChannelId(), 2);
            ChannelAccount channelAccountZc = channelAccountService.findByChannelIdAndType(channels.getParentChannelId(), 3);
            request.setAttribute("accountBalance", channelAccountHb.getAccountBalanceYuan().add(channelAccountZc.getAccountBalanceYuan()));
        }else{
            request.setAttribute("accountBalance", 0);
            
            ransactionId = ransactionId();
        }
        request.setAttribute("level", channels.getChannelLevel() - 1);
        request.setAttribute("channels", channels);
        request.setAttribute("ransactionId", ransactionId);
        
        return "/views/channel/channel/accountHb.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountHb"}, method = RequestMethod.POST)
    public RestStatus saveAccountHb(HttpServletRequest request ,Channels channels, HttpSession session){
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount  ="";
            
        Channels channel = channelsService.findChannelByUserId(user.getId());
            
        if(channel != null){
            transactionAccount = "[" + channel.getChannelCode() + "] " + channel.getChannelName();
        }else{
            transactionAccount = "总部：" + user.getNickName();
        }
        
        if(channels.getAccountBalanceHb() == null || channels.getAccountBalanceHb().compareTo(BigDecimal.ZERO) <= 0){
            return new RestStatus(Boolean.FALSE, "500", "您输入的划拨金额("+channels.getAccountBalanceHb()+")错误！");
        }
        
        try {
            restStatus = channelsService.saveAccountHb(channels, user.getId(), transactionAccount, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new RestStatus(Boolean.FALSE, "500", "划拨操作失败！");
        }
        
        return restStatus;
    }
    
    @RequestMapping(value = "/accountCorrect")
    public String accountCorrect(HttpServletRequest request ){
        
        String ransactionId = "";
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        request.setAttribute("channels", channels);
        ChannelAccount channelAccount = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
        request.setAttribute("accountBalance", channelAccount.getAccountBalanceYuan());
        if(channels.getParentChannelId() == null){
            ransactionId = ransactionId();
        }
        request.setAttribute("ransactionId", ransactionId);
        request.setAttribute("level", channels.getChannelLevel() - 1);
        
        return "/views/channel/channel/accountCorrect.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountCorrect"}, method = RequestMethod.POST)
    public RestStatus saveAccountCorrect(HttpServletRequest request ,Channels channels, HttpSession session){
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount  ="";
            
        Channels channel = channelsService.findChannelByUserId(user.getId());
            
        if(channel != null){
            transactionAccount = "[" + channel.getChannelCode() + "] " + channel.getChannelName();
        }else{
            transactionAccount = "总部：" + user.getNickName();
        }
        
        if(channels.getAccountBalanceHb() == null || channels.getAccountBalanceHb().compareTo(BigDecimal.ZERO) <= 0){
            return new RestStatus(Boolean.FALSE, "500", "您输入的纠正金额("+channels.getAccountBalanceHb()+")错误！");
        }
        
        try {
            restStatus = channelsService.saveAccountCorrect(channels, user.getId(), transactionAccount, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new RestStatus(Boolean.FALSE, "500", "划拨操作失败！");
        }
        
        return restStatus;
    }
    
    /**
     * 三级渠道待审核详情
     * @param request
     * @param channels
     * @return
     */
    @RequestMapping(value = "/findThreeByChannelId")
    public String findThreeByChannelId(HttpServletRequest request, Channels channels, String search, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
     
        
        PageEntity pageEntity = new PageEntity(channels.getPageSize(), channels.getPageIndex());
        
        Map<String, Object> params = new HashMap<String, Object>();
        
        //以下是渠道主页获取渠道信息
        Channels channel = channelsService.findChannelByUserId(user.getId());
        if(channel != null ) {
            params.put("level", channel.getChannelLevel());
            request.setAttribute("level", channel.getChannelLevel());
            params.put("channelId", channel.getId());
        }
        
        if((channel == null || channel.getChannelLevel() == 1) && !StringUtils.equals(search, "search")){
            channels.setStatus(2);
        }

        // 设置分页初始化数据
        if (StringUtils.isNotBlank(channels.getParentChannelName())) {
            params.put("parentChannelName", channels.getParentChannelName());
        }
        if (StringUtils.isNotBlank(channels.getChannelName())) {
            params.put("channelName", channels.getChannelName());
        }
        if (StringUtils.isNotBlank(channels.getProvinceName())) {
            params.put("provinceName", channels.getProvinceName());
        }
        if (channels.getStatus() != null) {
            params.put("status", channels.getStatus());
        }
        if (StringUtils.isNotBlank(channels.getsDate())) {
            params.put("sDate", channels.getsDate());
        }
        if (StringUtils.isNotBlank(channels.geteDate())) {
            params.put("eDate", channels.geteDate());
        }
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<Channels> authlist = channelsService.findThreeByProperty(params);
        int total = channelsService.authThreeCountTotal(params);
        pageEntity.setTotal(total);

        request.setAttribute("authlist", authlist);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("channels", channels);
        request.setAttribute("channel", channel);
        
        return "/views/channel/channel/authlist.jsp";
    }
    
    
    @RequestMapping(value = "/channelAuth")
    public String channelAuth(HttpServletRequest request ){
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        if(StringUtils.isNotBlank(channels.getIdcardLicense())){
            channels.setIdcardLicense(resourceIP + channels.getIdcardLicense());
        }
        if(StringUtils.isNotBlank(channels.getBusinessLicense())){
            channels.setBusinessLicense(resourceIP + channels.getBusinessLicense());
        }
        if(StringUtils.isNotBlank(channels.getOrgcodeLicense())){
            channels.setOrgcodeLicense(resourceIP + channels.getOrgcodeLicense());
        }
        if(StringUtils.isNotBlank(channels.getOtherLicense())){
            channels.setOtherLicense(resourceIP + channels.getOtherLicense());
        }
        request.setAttribute("channels", channels);
        
        return "/views/channel/channel/pointauth.jsp";
    }
    
    //审核不通过
    @RequestMapping("/pointAuthDetail" )
    public String pointAuthDetail(HttpServletRequest request, String status, String channelId, HttpSession session) {
        
        request.setAttribute("status", status);
        request.setAttribute("channelId", channelId);
        
        return "/views/channel/channel/pointAuthDetail.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveChannelAuth"}, method = RequestMethod.POST)
    public Map<String, Object> saveChannelAuth(HttpServletRequest request ,Channels channels, HttpSession session){
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        Map<String,Object> map = new HashMap<String,Object>();
        try {
            channelsService.channelAuth(channels, user);
            map.put("status", true);
        } catch (Exception e) {
            map.put("status", false);
            map.put("result", e.getMessage());
            logger.error(e.getMessage(), e);
        }
        
        return map;
    }
    
    //稽查资料
    @RequestMapping("/checkDetail" )
    public String checkDetail(HttpServletRequest request, Integer id, HttpSession session) {
        
        request.setAttribute("channelId", id);
        
        return "/views/channel/channel/checkDetail.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveChannelCheck"}, method = RequestMethod.POST)
    public Map<String, Object> saveChannelCheck(HttpServletRequest request ,Channels channels, HttpSession session){
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        Map<String,Object> map = new HashMap<String,Object>();
        try {
            if(channels.getCheckStatus() == 4){
                channels.setCheckStatus(3);
                channels.setCheckComment("不合规："+ channels.getCheckComment());
            }
            channelsService.channelCheck(channels, user);
            map.put("status", true);
        } catch (Exception e) {
            map.put("status", false);
            map.put("result", e.getMessage());
            logger.error(e.getMessage(), e);
        }
        
        return map;
    }
    
    @RequestMapping("/picShow" )
    public String picShow(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        Integer id = Integer.parseInt(request.getParameter("id"));
        Integer num = Integer.parseInt(request.getParameter("num"));
        Channels channels = channelsService.findById(id);
        
        if(StringUtils.isNotBlank(channels.getIdcardLicense())){
            channels.setIdcardLicense(resourceIP + channels.getIdcardLicense());
        }
        if(StringUtils.isNotBlank(channels.getBusinessLicense())){
            channels.setBusinessLicense(resourceIP + channels.getBusinessLicense());
        }
        if(StringUtils.isNotBlank(channels.getOrgcodeLicense())){
            channels.setOrgcodeLicense(resourceIP + channels.getOrgcodeLicense());
        }
        if(StringUtils.isNotBlank(channels.getOtherLicense())){
            channels.setOtherLicense(resourceIP + channels.getOtherLicense());
        }
        request.setAttribute("channels", channels);
        request.setAttribute("num", num);
        
        return "/views/channel/channel/picShow.jsp";
    }
    
    
    /**
     * 根据渠道编码、渠道父ID查找渠道信息
     * @param channelCode
     * @param channelId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/findChannelByCodeAndPid")
    public Channels findChannelByCodeAndPid(String channelCode,String channelId){
        Channels channels = channelsService.findChannelByCodeAndPid(channelCode, channelId);
        if(channels == null) {
            return null;
        }
        ChannelAccount channelAccount = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("channelId", channels.getId());
        param.put("accountType", 2);
        // 未处理的划拨账户订单金额
        BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param);
        channels.setAccountBalanceHb(channelAccount.getAccountBalanceYuan().subtract(freezeAllotMoney));
        return channels;
    }
    
    /**
     * 根据渠道编码、渠道父ID查找渠道信息
     * @param channelCode
     * @param channelId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/ransactionId")
    public String maxTansactionId(){
        return ransactionId();
    }
    
    /**
     * 省市县三级联动
     * @param level 城市等级
     * @param id 父Id
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/findAreaCode") 
    public List<?> findAreaCode(Integer level, Integer id){
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("level", level);
        params.put("parentCode", id);
        return cityService.findByLevelAndParentCode(params);
    }
    
    public String saveImageFile(MultipartFile file, String timexf, String channelCode ){
        
        if(file == null){
            logger.info("上传文件不能够为空");
        }
        
        String sourceName = file.getOriginalFilename(); // 原始文件名
        
        if(sourceName==null||"".equals(sourceName)){
            logger.info("上传文件不能够为空");
        }
        
        if(StringUtils.isBlank(timexf)){
            timexf = DateUtil.getInstance().formatDate(new Date(), "yyyyMMdd");
        }
        
        String docLocation = "channels/" + timexf + "/" + channelCode ;
        
        UUID uuid = UUID.randomUUID();
        sourceName = uuid + sourceName.substring(sourceName.lastIndexOf("."), sourceName.length());
        
        if(file.getSize() > 10000000){
            logger.info("上传失败：文件大小不能超过10M");
        }
        
        if(file.getSize()>0){
            try {
                SaveFileFromInputStream(file.getInputStream(),imageURL + "/" + docLocation,sourceName);
            } catch (IOException e) {
                logger.info("系统找不到指定的路径："+e.getMessage());
            }
        } else {
            logger.info("上传文件不能够为空");
        }
        
        return  "/" + docLocation + "/" + sourceName;
    }
    
    public void SaveFileFromInputStream(InputStream stream,String path,String filename) throws IOException    
    {          
        File dir = new File(path);
        if (!dir.exists()){   //如果目录不存在就创建目录
            dir.mkdirs();
        }
        FileOutputStream fs=new FileOutputStream( path + "/"+ filename);    
        byte[] buffer =new byte[1024*1024];    
        int byteread = 0;     
        while ((byteread=stream.read(buffer))!=-1)    
        {    
           fs.write(buffer,0,byteread);    
           fs.flush();    
        }     
        fs.close();    
        stream.close();          
    }
    
    //工单号
    public String ransactionId() {
        String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
        String timeStr = DateUtil.getNowDateTimeString("HHmmss");
        String ransactionId = transactionService.maxTransactionId(dateStr);
        if(StringUtils.isBlank(ransactionId)){
            ransactionId = dateStr + timeStr + "001";
        }else {
            String maxStr = ransactionId.substring(ransactionId.length()-3, ransactionId.length());
            String str = String.valueOf(Long.parseLong(maxStr) + 1);
            if(str.length() == 1){
                str = "00" + str;
            }else if(maxStr.length() == 2){
                str = "0" + str;
            }
            ransactionId = dateStr + timeStr + str;
        }
        
        return ransactionId;
    }
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/channelDetailExport",method=RequestMethod.GET)
    public void channelDetailExport(HttpServletRequest request, HttpServletResponse response, Channels channels, Integer sortByAmount, Integer pageSize, HttpSession session){
        
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);

            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            
            //以下是渠道主页获取渠道信息
            Channels channel = channelsService.findChannelByUserId(user.getId());
            
            Map<String, Object> params = new HashMap<String, Object>();
             
            if(channel == null) {
                params.put("channelLevel", 0);  //当前登录渠道级别，总部员工默认为0
                request.setAttribute("channelLevel", 0);
                if(channels.getLevel() == null) {
                    params.put("level", 1);
                    channels.setLevel(1);
                }
                request.setAttribute("curChannellevel", 0);  //当前渠道级别，界面判断使用
            }else {
                params.put("channelId", channel.getId());
                params.put("channelLevel", channel.getChannelLevel());
                request.setAttribute("curChannellevel", channel.getChannelLevel());
                if(channels.getLevel() == null) {
                    params.put("level", channel.getChannelLevel() + 1);
                    channels.setLevel(channel.getChannelLevel() + 1);
                }
            }
            
            //界面跳转时用到（查询下级渠道列表信息）
            if(channels.getId() != null && channels.getChannelLevel() != null){
                params.put("channelId", channels.getId());
                params.put("channelLevel", channels.getChannelLevel());
            }
            
            // 设置分页初始化数据
            if (StringUtils.isNotBlank(channels.getChannelName())) {
                channels.setChannelName(URLDecoder.decode(channels.getChannelName(),"utf-8"));
                params.put("channelName", channels.getChannelName());
            }
            if(channels.getLevel() != null ) {
                params.put("level", channels.getLevel());
                if(channels.getLevel() == 0){
                    params.remove("level");
                }
            }
            if (StringUtils.isNotBlank(channels.getChannelNameLevel1())) {
                channels.setChannelNameLevel1(URLDecoder.decode(channels.getChannelNameLevel1(),"utf-8"));
                List<Integer> channelIds = channelsService.findByCodeOrName(channels.getChannelNameLevel1().trim());
                if(channelIds != null && channelIds.size() > 0){
                    params.put("channelIds", channelIds);
                }else {
                    channelIds.add(1);
                    params.put("channelIds", channelIds);
                }
            }
            if (StringUtils.isNotBlank(channels.getLoginName())) {
                params.put("loginName", channels.getLoginName());
            }
            if (StringUtils.isNotBlank(channels.getProvinceName())) {
                channels.setProvinceName(URLDecoder.decode(channels.getProvinceName(),"utf-8"));
                params.put("provinceName", channels.getProvinceName());
            }
            if (channels.getStatus() != null) {
                params.put("status", channels.getStatus());
            }
            if (channels.getIsAuth() != null) {
                params.put("isAuth", channels.getIsAuth());
            }
            if (channels.getIsImg() != null) {
                params.put("isImg", channels.getIsImg());
            }
            if (channels.getCheckStatus() != null) {
                params.put("checkStatus", channels.getCheckStatus());
            }
            if (StringUtils.isNotBlank(channels.getsDate())) {
                params.put("sDate", channels.getsDate());
            }
            if (StringUtils.isNotBlank(channels.geteDate())) {
                params.put("eDate", channels.geteDate());
            }
            
            params.put("sortByAmount", sortByAmount);

            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;

            params.put("limit", limit);
            params.put("offset", offset);
            List<Channels> channelList = channelsService.newListChannels(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "渠道列表" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"创建时间","上级" ,"渠道编码" ,"渠道名称" ,"登录账号" ,"渠道属性" ,"所在地" ,"渠道状态" ,"开卡审核权限" ,"手动输入身份证" ,"渠道资质"};
            properties = new String[]{"createTimeExp","channelNameLevel" ,"channelCode" ,"channelName" ,"loginName" ,"channelProperty" ,"provinceNameStr" ,"statusExp" ,"isAuthStr" ,"isImgStr" ,"checkStatusExp" };
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(),headers,channelList,properties);
            
        } catch (IOException e) {
            logger.info("渠道信息导出失败");
            e.printStackTrace();
        } 
    }

}
