package com.agent.channel.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.ChannelProduct;
import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelProductMapper;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.common.DataTable;
import com.agent.product.dto.ChannelProductDto;
import com.agent.product.entity.Packages;
import com.agent.product.entity.Product;
import com.agent.product.mapper.PackagesMapper;
import com.agent.product.mapper.ProductMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;

@Transactional(rollbackFor=Exception.class)
@Service("channelProductService")
public class ChannelProductService {
    private static Logger logger = LoggerFactory.getLogger(ChannelProductService.class);
    @Autowired
    private ChannelProductMapper cpMapper;
    @Autowired
    private ChannelsMapper channelsMapper;
    @Autowired
    private BusinessLogService logService;
    @Resource
    private ProductMapper proMapper;
    @Resource
    private PackagesMapper pacMapper;

    public DataTable<ChannelProductDto> listChannelPros(DataTable<ChannelProductDto> dt,Map<String, Object> params) throws Exception{
        List<ChannelProductDto> list =  cpMapper.listProCPD(params);
        int count = cpMapper.listProCPDCount(params);
        dt.setAaData(list);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }

    //新增修改渠道商品可见性
    public void proSave(ChannelProductDto cpDo,User us) throws Exception{
        //设置是否可见商品
        Product product = proMapper.findById(cpDo.getProId());
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("eqProId",cpDo.getProId());
        searchMap.put("proId", cpDo.getProId());
        searchMap.put("proType","1");//商品类型：商品类型：1-产品，2-套餐
        searchMap.put("channelId",cpDo.getChannelId());
        List<ChannelProductDto> dtos = cpMapper.listProCPD(searchMap);
        //设置是否可见渠道
        Channels chan = channelsMapper.findById(cpDo.getChannelId());
        //增加类型
        cpDo.setProType("1");
        if(null != dtos && dtos.size() >0){
            cpDo.setId(dtos.get(0).getId());
            cpMapper.updateByDto(cpDo);
        }else{
            cpMapper.insertByDto(cpDo);
        }
        channelProisShow(product.getProductName(), chan.getChannelName(), cpDo.getIsShowStr(), String.valueOf(cpDo.getId()), us,Business.cool_product_channel);
    }


    //新增修改渠道商品可见性
    public void bacthProSave(ChannelProductDto cpDo,User us) throws Exception{
        //设置是否可见商品
        Product product = proMapper.findById(cpDo.getProId());
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("eqProId",cpDo.getProId());
        searchMap.put("proId", cpDo.getProId());
        searchMap.put("proType","1");//商品类型：商品类型：1-产品，2-套餐
        searchMap.put("channelIds",cpDo.getChannelIds());
        List<ChannelProductDto> dtos = cpMapper.listProCPD(searchMap);
        List<ChannelProductDto> saveDtos = new ArrayList<ChannelProductDto>();
        if(null != dtos && dtos.size() >0){
            List<Integer> cids = new ArrayList<Integer>();
            for(ChannelProductDto d:dtos){
                cids.add(d.getChannelId());
                d.setIsShow(cpDo.getIsShow());
            }
            
            for(Integer i:cpDo.getChannelIds()){
                if(!cids.contains(i)){
                    ChannelProductDto saveDto = new ChannelProductDto();
                    saveDto.setProId(cpDo.getProId());
                    saveDto.setChannelId(i);
                    saveDto.setProType("1");
                    saveDto.setIsShow(cpDo.getIsShow());
                    saveDtos.add(saveDto);
                }
            }
            
            if(saveDtos.size() >0 ){
                cpMapper.batchInsertByDto(saveDtos);
            }
            cpMapper.batchUpdateByDto(dtos);
        }else{
            for(Integer i:cpDo.getChannelIds()){
                ChannelProductDto saveDto = new ChannelProductDto();
                saveDto.setProId(cpDo.getProId());
                saveDto.setChannelId(i);
                saveDto.setProType("1");
                saveDto.setIsShow(cpDo.getIsShow());
                saveDtos.add(saveDto);
            }
            cpMapper.batchInsertByDto(saveDtos);
        }

        searchMap = new HashMap<String,Object>();
        searchMap.put("chIds",cpDo.getChannelIds());
        List<Channels> chs = channelsMapper.listChannels(searchMap);
        StringBuffer channelCodes = new StringBuffer();
        for(int i=0;i<chs.size();i++){
            channelCodes.append(chs.get(i).getChannelCode());
            if(i != chs.size() -1){
                channelCodes.append("，");
            }
        }
        
        channelProisShow(product.getProductName(), channelCodes.toString(), cpDo.getIsShowStr(), String.valueOf(cpDo.getId()), us,Business.cool_product_channel_batch);
    }
    
    /** 
     * 设置渠道商品可见
     * @param proName
     */
    public void channelProisShow(String proName,String chName,String isShow,String souId,User us,String logType){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("proName",proName);
            logmap.put("chName",chName);
            logmap.put("isShow",isShow);
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            logService.businessSaveLog(logType,String.valueOf(us.getId()),us.getLoginName(),souId,"设置渠道商品可见",logmap);
        }catch (Exception  e){
            logger.error("设置渠道商品可见日志记录错误：原因："+e.getMessage(),e);
        }
    }

    /**
     * 新增修改渠道套餐可见性
     * */
    public void pacSave(ChannelProductDto cpDo,User us) throws Exception{
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("eqProId",cpDo.getProId());
        searchMap.put("proId", cpDo.getProId());
        searchMap.put("proType","2");//商品类型：商品类型：1-产品，2-套餐
        searchMap.put("channelId",cpDo.getChannelId());
        List<ChannelProductDto> dtos = cpMapper.listProCPD(searchMap);
        //设置是否可见渠道
        Channels chan = channelsMapper.findById(cpDo.getChannelId());
        //设置是否可见套餐
        Packages packages = pacMapper.findById(cpDo.getProId());
        cpDo.setProType("2");
        if(null != dtos && dtos.size() >0){
            cpDo.setId(dtos.get(0).getId());
            cpMapper.updateByDto(cpDo);
        }else{
            cpMapper.insertByDto(cpDo);
        }
        channelPacLog(packages.getName(), chan.getChannelCode(), cpDo.getIsShowStr(), String.valueOf(cpDo.getId()), us,Business.packages_allot);
    }

    /**
     * 批量新增修改渠道套餐可见性
     * */
    public void batchPacSave(ChannelProductDto cpDo,User us) throws Exception{
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("eqProId",cpDo.getProId());
        searchMap.put("proId", cpDo.getProId());
        searchMap.put("proType","2");//商品类型：商品类型：1-产品，2-套餐
        searchMap.put("channelIds",cpDo.getChannelIds());
        List<ChannelProductDto> dtos = cpMapper.listProCPD(searchMap);
        //设置是否可见套餐
        Packages packages = pacMapper.findById(cpDo.getProId());
        cpDo.setProType("2");
        
        List<ChannelProductDto> saveDtos = new ArrayList<ChannelProductDto>();
        if(null != dtos && dtos.size() >0){
            List<Integer> cids = new ArrayList<Integer>();
            for(ChannelProductDto d:dtos){
                cids.add(d.getChannelId());
                d.setIsShow(cpDo.getIsShow());
            }
            
            for(Integer i:cpDo.getChannelIds()){
                if(!cids.contains(i)){
                    ChannelProductDto saveDto = new ChannelProductDto();
                    saveDto.setProId(cpDo.getProId());
                    saveDto.setChannelId(i);
                    saveDto.setProType("2");
                    saveDto.setIsShow(cpDo.getIsShow());
                    saveDtos.add(saveDto);
                }
            }
            
            if(saveDtos.size() >0 ){
                cpMapper.batchInsertByDto(saveDtos);
            }
            cpMapper.batchUpdateByDto(dtos);
        }else{
            for(Integer i:cpDo.getChannelIds()){
                ChannelProductDto saveDto = new ChannelProductDto();
                saveDto.setProId(cpDo.getProId());
                saveDto.setChannelId(i);
                saveDto.setProType("2");
                saveDto.setIsShow(cpDo.getIsShow());
                saveDtos.add(saveDto);
            }
            cpMapper.batchInsertByDto(saveDtos);
        }

        searchMap = new HashMap<String,Object>();
        searchMap.put("chIds",cpDo.getChannelIds());
        List<Channels> chs = channelsMapper.listChannels(searchMap);
        StringBuffer channelCodes = new StringBuffer();
        for(int i=0;i<chs.size();i++){
            channelCodes.append(chs.get(i).getChannelCode());
            if(i != chs.size() -1){
                channelCodes.append("，");
            }
        }
        
        channelPacLog(packages.getName(), channelCodes.toString(), cpDo.getIsShowStr(), String.valueOf(cpDo.getId()), us,Business.packages_allot_batch);
    }

    /**
     * 设置渠道商品可见日志
     * @param pacName
     */
    public void channelPacLog(String pacName,String channelCode,String isShow,String souId,User us,String logType){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("pacName",pacName);
            logmap.put("channelCode",channelCode);
            logmap.put("isShow",isShow);
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            logService.businessSaveLog(logType,String.valueOf(us.getId()),us.getLoginName(),souId,"设置渠道套餐可见",logmap);
        }catch (Exception  e){
            logger.error("设置渠道套餐可见日志记录错误：原因："+e.getMessage(),e);
        }
    }
    
    public ChannelProduct channelProductShow(Integer channelId, Integer packageId) {
        return cpMapper.channelProductShow(channelId, packageId);
    }
}