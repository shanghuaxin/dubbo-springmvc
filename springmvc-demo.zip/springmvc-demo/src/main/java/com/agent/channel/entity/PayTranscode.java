package com.agent.channel.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 渠道交易码表
 * @author weijialiang
 *
 */
public class PayTranscode implements Serializable {

    private static final long serialVersionUID = 1366467204334260114L;
    
    private Integer id;         //id
    private Integer uid;        //渠道用户id
    private Integer channelId;  //渠道ID
    private String transcode;   //银行交易码
    private Integer status;     //状态：1-有效，0-无效
    private Integer createId;   //创建人ID
    private Date createTime;    //创建时间
    private Integer updateId;   //更新人ID
    
    private Date updateTime;    //更新时间

    public PayTranscode() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getTranscode() {
        return transcode;
    }

    public void setTranscode(String transcode) {
        this.transcode = transcode;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "PayTranscode [id=" + id + ", uid=" + uid + ", channelId=" + channelId + ", transcode=" + transcode
                + ", status=" + status + ", createId=" + createId + ", createTime=" + createTime + ", updateId="
                + updateId + ", updateTime=" + updateTime + "]";
    }
}
