package com.agent.channel.entity;

import java.io.Serializable;

/**
 * 渠道与外部系统对接  关系映射表
 * @author weijialiang
 *
 */
public class ChannelMapping implements Serializable{

    private static final long serialVersionUID = 7998267952549114085L;
    
    private Integer id;             //id
    private Integer channelId;      //渠道id
    private String channelCode;     //渠道编号
    private Integer extSys;         //外部系统标识：1: BOSS，2: COOL 170，3: FLOW PLATFORM，4: COOL FLOW PLATFORM
    private String extCode;     //外部系统编码

    public ChannelMapping() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public Integer getExtSys() {
        return extSys;
    }

    public void setExtSys(Integer extSys) {
        this.extSys = extSys;
    }

    public String getExtCode() {
        return extCode;
    }

    public void setExtCode(String extCode) {
        this.extCode = extCode;
    }

    @Override
    public String toString() {
        return "ChannelMapping [id=" + id + ", channelId=" + channelId + ", channelCode=" + channelCode + ", extSys="
                + extSys + ", extCode=" + extCode + "]";
    }
}
