package com.agent.channel.entity;

/**
 * 渠道编号记录表
 * @author weijialiang
 *
 */
public class ChannelCodeSequence {
    
    private String name;           //sequence名称
    private Integer currentValue;  //初始值
    private Integer increment;     //增量值
    
    //补充变量
    private String sql;
    
    public ChannelCodeSequence() {
        super();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(Integer currentValue) {
        this.currentValue = currentValue;
    }

    public Integer getIncrement() {
        return increment;
    }

    public void setIncrement(Integer increment) {
        this.increment = increment;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    @Override
    public String toString() {
        return "ChannelCodeSequence [name=" + name + ", currentValue=" + currentValue + ", increment=" + increment
                + "]";
    }
    
    

}
