package com.agent.businesslog.entity;

import javax.persistence.Entity;

import java.io.Serializable;
import java.util.Date;

@Entity
public class BusinessLog implements Serializable {
    private static final long serialVersionUID = -3886223768031900106L;
    private Integer id;
    private String logType;//日志类型
    private String operatorId;//操作员ID
    private String operatorName;//操作员名称
    private String businessId;//被操作实体ID，别操作拿条记录的ID
    private String businessName;//被操作实体名称，可为空，比如代理商开户，就写入开户的号码
    private String description;//操作说明 就是BUSINESS_LOG_TYPE这个表中PATTERN经过转换后的内容
    private String operationResult;//操作结果 成功 失败
    private Date operationDate;//操作时间
    private Integer belongChannelIdLevel1;
    private Integer createId;
    private Date createTime;
    private Integer updateId;
    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLogType() {
        return logType;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public String getBusinessId() {
        return businessId;
    }

    public String getBusinessName() {
        return businessName;
    }

    public String getDescription() {
        return description;
    }

    public String getOperationResult() {
        return operationResult;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setOperationResult(String operationResult) {
        this.operationResult = operationResult;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Integer getBelongChannelIdLevel1() {
        return belongChannelIdLevel1;
    }

    public void setBelongChannelIdLevel1(Integer belongChannelIdLevel1) {
        this.belongChannelIdLevel1 = belongChannelIdLevel1;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
