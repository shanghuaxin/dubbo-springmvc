package com.agent.businesslog.dto;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by MrC on 2015/10/10.
 */
public class BusinessLogSaveListDTO extends LogDTO{
    private String pattern;
    private Map<String,String> relMap = new HashMap<String,String>();

    public Map<String, String> getRelMap() {
        return relMap;
    }

    public void setRelMap(Map<String, String> relMap) {
        this.relMap = relMap;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }
}
