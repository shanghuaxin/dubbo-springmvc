package com.agent.businesslog.entity;

import java.io.Serializable;
/**
 * 异常日志记录表，记录接口异常日志
 * @author weijialiang
 *
 */
import java.util.Date;
public class ErrorLog implements Serializable{

    private static final long serialVersionUID = -8389069651352580566L;
    
    private Integer id;           //id
    private Integer channelId;    //渠道id
    private String channelName;   //渠道名称
    private String optionType;    //操作类型:recharge-充值，opensim-开户，complete-报峻，modCustomer -过户
    private String msisdn;        //号码
    private String msg;           //异常信息
    private Date createTime;      //创建时间
    
    //扩展字段
    private Integer pageIndex;    // 当前页
    private Integer pageSize;     // 页面大小

    public ErrorLog() {
        super();
    }

    public ErrorLog(Integer channelId, String channelName, String optionType, String msisdn, String msg) {
        super();
        this.channelId = channelId;
        this.channelName = channelName;
        this.optionType = optionType;
        this.msisdn = msisdn;
        this.msg = msg;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "ErrorLog [id=" + id + ", channelId=" + channelId + ", channelName=" + channelName + ", optionType="
                + optionType + ", msisdn=" + msisdn + ", msg=" + msg + ", createTime=" + createTime + "]";
    }

}
