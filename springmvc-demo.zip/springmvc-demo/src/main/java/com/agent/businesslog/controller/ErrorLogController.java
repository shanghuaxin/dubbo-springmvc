package com.agent.businesslog.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.agent.businesslog.entity.InterfaceData;
import com.agent.businesslog.service.InterfaceDataService;
import com.agent.common.PageEntity;

@Controller
@RequestMapping(value="errorlog")
public class ErrorLogController {
    
    private static Logger logger = LoggerFactory.getLogger(ErrorLogController.class);
    
    @Autowired
    private InterfaceDataService integerfaceDataService;
    /**
     * 进入列表页面
     */
    @RequestMapping("list")
    public String list(HttpServletRequest request, InterfaceData interfaceData) {
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(interfaceData.getPageSize(), interfaceData.getPageIndex());
        Map<String, Object> params = new HashMap<String, Object>();
        String msisdn = interfaceData.getMsisdn();
        msisdn = null==msisdn?"":msisdn.trim();
        interfaceData.setMsisdn(msisdn);
        if (StringUtils.isNotBlank(interfaceData.getMsisdn())) {
            params.put("msisdn", msisdn);
        }
        if (StringUtils.isNotBlank(interfaceData.getInterfaceName())) {
            params.put("interfaceName", interfaceData.getInterfaceName());
        }
        String channelName = interfaceData.getChannelName();
        channelName = null==channelName?"":channelName.trim();
        interfaceData.setChannelName(channelName);
        if (StringUtils.isNotBlank(interfaceData.getChannelName())) {
            params.put("channelName", interfaceData.getChannelName());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);

        List<InterfaceData> logList = integerfaceDataService.list(params);
        int total = integerfaceDataService.count(params);
        pageEntity.setTotal(total);
        request.setAttribute("logList", logList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("interfaceData", interfaceData);
        logger.info("=====查询错误日志信息=====");
        return "/views/businesslog/errorLogList.jsp";
    }

}
