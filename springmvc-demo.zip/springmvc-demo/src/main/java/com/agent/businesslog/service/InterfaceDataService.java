package com.agent.businesslog.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.entity.InterfaceData;
import com.agent.businesslog.mapper.InterfaceDataMapper;

@Service
public class InterfaceDataService {
    
    private static Logger logger = LoggerFactory.getLogger(InterfaceDataService.class);
    
    @Autowired
    private InterfaceDataMapper interfaceDataMapper;
    
    public List<InterfaceData> list(Map<String, Object> map) {
        return interfaceDataMapper.list(map);
    }
    
    /**
     * 查询总数
     * @param map
     * @return
     */
    public int count(Map<String, Object> map) {
        return interfaceDataMapper.count(map);
    }
    
    public InterfaceData findById(Integer id) {
        return interfaceDataMapper.select(id);
    }
    
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public int insert(InterfaceData interfaceData) {
        try {
            // 记录日志不能影响正常的业务逻辑，所以这里需要对异常进行处理
            return interfaceDataMapper.insert(interfaceData);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return 0;
    }
}
