package com.agent.businesslog.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.businesslog.entity.ErrorLog;
import com.agent.businesslog.mapper.ErrorLogMapper;

@Service
public class ErrorLogService {
    
    @Autowired
    private ErrorLogMapper errorLogMapper;
    
    public List<ErrorLog> list(Map<String, Object> params) {
        return errorLogMapper.list(params);
    }
    
    public int countTotal(Map<String, Object> params) {
        return errorLogMapper.count(params);
    }

}
