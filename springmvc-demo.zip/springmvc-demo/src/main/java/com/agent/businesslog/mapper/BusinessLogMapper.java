package com.agent.businesslog.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.businesslog.entity.BusinessLog;
import com.agent.businesslog.entity.BusinessLogCategory;
import com.agent.businesslog.entity.BusinessLogType;
import com.agent.common.BaseMapper;

@Repository
public interface BusinessLogMapper extends BaseMapper<BusinessLog, Integer> {
    BusinessLogType findLogTypeByPrimaryKey(String logType);
    
    List<BusinessLog> selectByCondition(Map<String, Object> map);
    
    // 查询一级菜单
    List<BusinessLogCategory> qryFirstMenu(Integer categoryLevel);
    
    // 查询二级菜单
    List<BusinessLogCategory> qrySecondMenu(String parentName);
    
    // 查询三级菜单
    List<BusinessLogType> qryThirdMenu(String categoryName);
    
}
