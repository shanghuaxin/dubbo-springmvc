package com.agent.businesslog.util;

public class Business {
    /** 登录日志 */
    public static String login = "700000101";
    /** 注销登录 */
    public static String logout = "700000102";
    /** 修改密码*/
    public static String update_pwd = "700000103";
    /** 发送验证码*/
    public static String login_autch_code = "700000104";
    /** 添加用户 */
    public static String add_user = "700000201";
    /** 修改用户 */
    public static String edit_user = "700000202";
    /** 激活用户 */
    public static String active_user = "700000203";
    /** 冻结用户 */
    public static String frozen_user = "700000204";


    /** COOL170商品新增 */
    public static String cool_product_add = "300000201";
    /** COOL170商品变更 */
    public static String cool_product_mod = "300000202";
    /** COOL170商品发布*/
    public static String cool_product_release = "300000203";
    /** COOL170商品关闭 */
    public static String cool_product_close = "300000204";
    /** COOL170商品佣金设置 */
    public static String cool_product_bro = "300000205";
    /** COOL170商品渠道可见 */
    public static String cool_product_channel = "300000206";
    /** 批量设置COOL170商品渠道可见 */
    public static String cool_product_channel_batch = "300000207";

    /** 卡密库存导入 */
    public static String stock_card_import = "800000101";
    /** 卡密库存分配 */
    public static String stock_card_allot = "800000201";
    /** 卡密库存回收 */
    public static String stock_card_back = "800000301";
    /** 卡密库存下架 */
    public static String stock_card_del = "800000401";

    /** 号码库存导入 */
    public static String stock_phone_import = "800000102";
    /** 预开户号码导入 */
    public static String stock_phone_pre_import = "800000103";
    /** 号码库存分配 */
    public static String stock_phone_allot = "800000202";
    /** 号码库存回收 */
    public static String stock_phone_back = "800000302";
    /** 号码库存下架 */
    public static String stock_phone_del = "800000402";
    
    
    /** 号码批量分配*/
    public static String stock_phone_allot_batch = "800000501";
    /** 号码批量回收*/
    public static String stock_phone_back_batch = "800000502";
    /** 号码批量备注*/
    public static String stock_phone_remark_batch = "800000503";
    /** 号码延期 */
    public static String stock_phone_delay = "800000504";

    /** 新增预开户号码 */
    public static String stock_phone_pre_save = "800000601";
    /** 删除预开户号码 */
    public static String stock_phone_pre_del = "800000602";
    
    /** 号码库存销户 */
    public static String stock_phone_cancle = "800000701";
    /** ICCID出库 */
    public static String iccid_out_stock = "800000801";
    
    /** 渠道新增 */
    public static String channel_add = "100000101";
    /** 渠道修改*/
    public static String channel_update = "100000102";
    /** 渠道冻结 */
    public static String channel_frozen = "100000103";
    /** 渠道解冻 */
    public static String channel_unfrozen = "100000104";
    /** 渠道冻结开户 */
    public static String channel_frozen_account = "100000105";
    /** 渠道解冻开户 */
    public static String channel_unfrozen_account = "100000106";
    /** 渠道网点审核 */
    public static String channel_auth = "100000107";
    /** 渠道划拨 */
    public static String channel_account_hb = "100000108";
    /** 渠道纠正 */
    public static String channel_account_correct = "100000109";
    /** 渠道加值 */
    public static String channel_account_add = "100000110";
    /** 账户流水 */
    public static String channel_flow = "100000111";
    /** 实名设置 */
    public static String channel_realname_setting = "100000112";
    /** 佣金设置 */
    public static String channel_brokerage_setting = "100000113";

    /** 新增套餐 */
    public static String packages_add = "300000101";
    /** 编辑套餐 */
    public static String packages_edit = "300000102";
    /** 发布套餐 */
    public static String packages_release = "300000103";
    /** 关闭套餐 */
    public static String packages_close = "300000104";
    /** 分发套餐 */
    public static String packages_allot = "300000105";
    /** 套餐佣金设置 */
    public static String packages_brokerage = "300000106";
    /** 新增套餐增值业务 */
    public static String packages_add_low = "300000107";
    /** 编辑套餐增值业务 */
    public static String packages_edit_low = "300000108";
    /** 删除套餐增值业务 */
    public static String packages_del_low = "300000109";
    /** 批量分发套餐 */
    public static String packages_allot_batch = "300000110";
    /** 批量套餐佣金设置 */
    public static String packages_brokerage_batch = "300000111";
    

    /**调取卡密***/
    public static String retrieve_card = "900000101";
    /**申请补货***/
    public static String replenish = "900000102";
    /**号码充流量***/
    public static String phone_recharge_flow = "900000201";
    /**号码充值***/
    public static String phone_recharge = "900000202";
    
    
    
    /** 170过户 */
    public static String phone_mod_customser = "900000301";
    /** 过户审核 */
    public static String phone_mod_check = "900000302";
    /** 170业务办理 */
    public static String phone_buy_Sub = "900000303";
    /** 170业务办理重新提交 */
    public static String phone_buy_again_sub = "900000304";
    /**号码报峻***/
    public static String phone_complete = "900000305";
    /**号码开户申请***/
    public static String phone_open_apply = "900000306";
    /**号码开户***/
    public static String phone_open = "900000307";
    /**预开户号码开卡**/
    public static String phone_pre_open = "900000308";
    /**号码审核***/
    public static String phone_check = "900000309";
    /**号码稽核***/
    public static String phone_aduit = "900000310";
    /**号码稽核***/
    public static String phone_cancle = "900000311";
    /** 170用户资料修改 */
    public static String phone_mod_user_info = "900000312";
    /** 号码修改iccid */
    public static String phone_mod_iccid = "900000314";
    /** 联通号码状态同步 */
    public static String phone_status_sync = "900000315";

    /** 新增公告 ***/
    public static String technology_announcement_add = "400000101";
    /** 修改公告 ***/
    public static String technology_announcement_edit = "400000102";
    /** 发布公告 ***/
    public static String technology_announcement_release = "400000103";
    /** 关闭公告 ***/
    public static String technology_announcement_close = "400000104";
    /** 上传培训资料  ***/
    public static String technology_train_info_upload = "400000201";
    /** 删除培训资料  ***/
    public static String technology_train_info_delete = "400000202";
    /** 下载培训资料  ***/
    public static String technology_train_info_download = "400000203";

    /** 新增活动 ***/
    public static String technology_activity_add = "400000301";
    /** 修改活动 ***/
    public static String technology_activity_edit = "400000302";
    /** 发布活动 ***/
    public static String technology_activity_release = "400000303";
    /** 关闭活动 ***/
    public static String technology_activity_close = "400000304";
    

    /** 新增品牌动态 ***/
    public static String online_brand_insert = "1000000101";
    /** 变更品牌动态 ***/
    public static String online_brand_update = "1000000102";
    public static String online_brand_close = "1000000103";
    public static String online_brand_release = "1000000104";
}
