package com.agent.businesslog.entity;


import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class BusinessLogType implements Serializable {
    private static final long serialVersionUID = 8359257401904648836L;
    private String logType;
    private String logTypeName;
    private String categoryName;
    private String pattern;

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getLogTypeName() {
        return logTypeName;
    }

    public void setLogTypeName(String logTypeName) {
        this.logTypeName = logTypeName;
    }
}
