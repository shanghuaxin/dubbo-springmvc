package com.agent.businesslog.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.agent.businesslog.dto.BusinessLogSaveListDTO;
import com.agent.businesslog.entity.BusinessLog;
import com.agent.businesslog.entity.BusinessLogCategory;
import com.agent.businesslog.entity.BusinessLogType;
import com.agent.businesslog.mapper.BusinessLogMapper;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelsService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class BusinessLogService {
    
    private static Logger logger = (Logger) LoggerFactory.getLogger(BusinessLogService.class);
    
    @Autowired
    private BusinessLogMapper businessLogMapper;
    
    @Autowired
    private ChannelsService channelsService;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 记录日志
     * @param logType  日志子类型
     * @param opeId  操作人id
     * @param opeName 操作人姓名
     * @param busId 业务id
     * @param busName 业务名称
     * @param relMap desc
     * @throws Exception
     */
    @Transactional(readOnly=false)
    public void businessSaveLog(String logType,String opeId,String opeName,String busId,
                                String busName,Map<String,String> logMap){
        try{
            BusinessLogType blt = findLogTypeByPrimaryKey(logType);
            if (null!=blt && !Utils.isEmptyString(blt.getPattern())) {
                Integer channelIdLevel1 = null;
                if (!StringUtils.isEmpty(opeId)) {
                    Channels channels = channelsService.findChannelByUserId(Integer.parseInt(opeId));
                    channelIdLevel1 = null!=channels ? channels.getId() : 0;
                    if (null != channels) {
                        channelIdLevel1 = channels.getChannelIdLevel1()==null?channels.getId():channels.getChannelIdLevel1();
                    }
                }
                String descStr = getPattenStr(blt.getPattern(), logMap);
                BusinessLog log = new BusinessLog();
                log.setLogType(logType);
                log.setOperatorId(opeId);
                log.setOperatorName(opeName);
                log.setBusinessId(busId);
                log.setBusinessName(busName);
                log.setDescription(descStr);
                log.setOperationResult("SUCCESS");
                log.setOperationDate(new Date());
                log.setBelongChannelIdLevel1(channelIdLevel1);
                try {
                    log.setCreateId(Integer.parseInt(opeId));
                } catch (Exception e) {
                    log.setCreateId(null);
                }
                log.setCreateTime(new Date());
                businessLogMapper.insert(log);
            }
        } catch (Exception e) {
            logger.error("记录日志出错：原因："+e.getMessage(),e);
        }
    }

    /**
     * 按模式替换字符串
     *
     * @param pattern
     * @param otherInfoMap
     * @return
     */
    public static String getPattenStr(String pattern, Map<String, String> otherInfoMap) {
        //
        if (otherInfoMap != null) {
            for (Iterator<Map.Entry<String, String>> iter = otherInfoMap.entrySet().iterator(); iter.hasNext();) {
                Map.Entry<String, String> entry = iter.next();
                String key = entry.getKey();
                String value = entry.getValue();
                if (!key.startsWith("{")) {
                    key = "{" + key;
                }
                if (!key.endsWith("}")) {
                    key = key + "}";
                }
                pattern = StringUtils.replace(pattern, key, value);
            }
        }
        return pattern;
    }

    /**
     * 拼装入库sql语句
     * @param log
     * @return
     */
    @Transactional(readOnly=false)
    public StringBuffer sqlAppend(BusinessLog log){
        StringBuffer sql = new StringBuffer();
        sql.append("insert into `t_business_log` (`LOG_TYPE`, `OPERATOR_ID`, `OPERATOR_NAME`, `BUSINESS_ID`, `BUSINESS_NAME`, `DESCRIPTION`, `OPERATION_RESULT`, `OPERATION_DATE`, `CREATE_ID`, `CREATE_TIME`) values ");
        sql.append("(");
        sql.append("'").append(log.getLogType()).append("'").append(",");
        sql.append("'").append(log.getOperatorId()).append("'").append(",");
        sql.append("'").append(log.getOperatorName()).append("'").append(",");
        sql.append("'").append(log.getBusinessId()).append("'").append(",");
        sql.append("'").append(log.getBusinessName()).append("'").append(",");
        sql.append("'").append(log.getDescription()).append("'").append(",");
        sql.append("'").append(log.getOperationResult()).append("'").append(",");
        sql.append("NOW()").append(",");
        sql.append("'").append(log.getOperatorId()).append("'").append(",");
        sql.append("NOW()");
        sql.append(")");
        sql.append(";");
        return sql;
    }
     
    /**
      * 根据条件查询业务日志信息
      * @param params
      * @return
      */
    public List<BusinessLog> list(Map<String, Object> params) {
        List<BusinessLog> businessLogList = businessLogMapper.list(params);
        return businessLogList;
    }
     
     /**
      * 获取总数
      * @param params
      * @return
      */
     public int countTotal(Map<String, Object> params) {
         return businessLogMapper.count(params);
     }
     
     /**
      * 查询一级菜单
      * @param categoryLevel 一级菜单的级别，默认为1
      * @return
      */
     public List<BusinessLogCategory> qryFirstMenu(Integer categoryLevel) {
         return businessLogMapper.qryFirstMenu(categoryLevel);
     }
     public List<BusinessLogCategory> qrySecondMenu(String parentName) {
         return businessLogMapper.qrySecondMenu(parentName);
     }
     public List<BusinessLogType> qryThirdMenu(String categoryName) {
         return businessLogMapper.qryThirdMenu(categoryName);
     }
     
     /**
     *
     * @param logs 日志集合
     * @throws Exception
     */
    @Transactional(readOnly=false)
    public void businessSaveLogs(List<BusinessLogSaveListDTO> logs){
       try{
           if(null != logs && logs.size()>0){
               List<BusinessLog> saves = new ArrayList<>();
               for (BusinessLogSaveListDTO s:logs){
                   String descStr = getPattenStr(s.getPattern(),s.getRelMap());
                   BusinessLog log = new BusinessLog();
                   BeanUtils.copyProperties(s, log);
                   log.setDescription(descStr);
                   saves.add(log);
               }
               StringBuffer sqlbf = sqlAppends(saves);
               jdbcTemplate.update(sqlbf.toString());
           }
       }catch (Exception e){
           logger.error("记录日志出错：原因："+e.getMessage(),e);
       }
   }
   
   /**
    * 拼装入库sql语句
    * @param logs
    * @return
    */
   @Transactional(readOnly=false)
   public StringBuffer sqlAppends(List<BusinessLog> logs){
       StringBuffer sql = new StringBuffer();
       sql.append("insert into `t_business_log` (`create_time`, `LOG_TYPE`, `OPERATOR_ID`, `OPERATOR_NAME`, `BUSINESS_ID`, `BUSINESS_NAME`, `DESCRIPTION`, `OPERATION_RESULT`, `OPERATION_DATE`) values ");
       for(int i=0;i<logs.size();i++){
           sql.append("(");
           sql.append("'").append(System.currentTimeMillis()).append("'").append(",");
           sql.append("'").append(logs.get(i).getLogType()).append("'").append(",");
           sql.append("'").append(logs.get(i).getOperatorId()).append("'").append(",");
           sql.append("'").append(logs.get(i).getOperatorName()).append("'").append(",");
           sql.append("'").append(logs.get(i).getBusinessId()).append("'").append(",");
           sql.append("'").append(logs.get(i).getBusinessName()).append("'").append(",");
           sql.append("'").append(logs.get(i).getDescription()).append("'").append(",");
           sql.append("'").append(logs.get(i).getOperationResult()).append("'").append(",");
           sql.append("NOW()");
           sql.append(")");
           if(i != logs.size()-1){
               sql.append(",");
           }
       }
       sql.append(";");
       return sql;
    }
    
   /**
    * 获取日志小类
    * @param logType
    * @return
    */
    BusinessLogType findLogTypeByPrimaryKey(String logType) {
        return businessLogMapper.findLogTypeByPrimaryKey(logType);
    }

    /**
     * 号码库存回收
     * @param us
     */
    public void takeBackImportLog(User us,Integer dataNum,String logType){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("dataNum", dataNum.toString());
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessSaveLog(logType,String.valueOf(us.getId()),us.getLoginName(),"0","号码库存回收",logmap);
        }catch (Exception  e){
            logger.error("库存回收记录日志记录错误：原因："+e.getMessage(),e);
        }
    }

    /**
     * 库存分配
     * @param us
     */
    public void importAllotLog(User us,Integer dataNum,String logType){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("dataNum", dataNum.toString());
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessSaveLog(logType,String.valueOf(us.getId()),us.getLoginName(),"0","库存分配",logmap);
        }catch (Exception  e){
            logger.error("库存分配记录日志记录错误：原因："+e.getMessage(),e);
        }
    }
    


    /**
     * 号码库存备注
     * @param us
     */
    public void batchRemark(User us,Integer dataNum,String remark){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("dataNum", dataNum.toString());
            logmap.put("remark", remark);
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessSaveLog(Business.stock_phone_remark_batch,String.valueOf(us.getId()),us.getLoginName(),"0","号码库存回收",logmap);
        }catch (Exception  e){
            logger.error("号码批量备注记录日志记录错误：原因："+e.getMessage(),e);
        }
    }
}
