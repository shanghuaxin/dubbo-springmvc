package com.agent.businesslog.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.businesslog.entity.InterfaceData;
import com.agent.common.BaseMapper;

@Repository
public interface InterfaceDataMapper extends BaseMapper<InterfaceData, Integer>{
    int count(Map<String, Object> map);
    
    //获取接口信息
    public List<InterfaceData> listAsciiTxt(Map<String, Object> map);
}
