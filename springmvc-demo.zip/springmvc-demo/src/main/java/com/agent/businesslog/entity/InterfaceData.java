package com.agent.businesslog.entity;

import java.io.Serializable;
/**
 * 异常日志记录表，记录接口异常日志
 * @author weijialiang
 *
 */
import java.util.Date;
public class InterfaceData implements Serializable{

    private static final long serialVersionUID = -8389069651352580566L;
    
    private Integer id;               // id
    private String msisdn;            // 号码
    private Integer operatorId;        // 当前登录的操作员id
    // 接口名称:recharge-充值，opensim-开户，complete-报峻，modCustomer -过户，详见接口协议
    private String interfaceName;    // 接口名称:recharge-充值，opensim-开户，complete-报峻，modCustomer -过户
    private String requestContent;    // 请求报文
    private Date requestTime;        // 请求时间
    private Integer status;           // status 0：失败 1：成功
    private String responseContent;  // 响应报文
    private Date responseTime;       // 响应时间
    
    //扩展字段
    private String channelName;   //渠道名称
    private Integer pageIndex;    // 当前页
    private Integer pageSize;     // 页面大小
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getMsisdn() {
        return msisdn;
    }
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
    public Integer getOperatorId() {
        return operatorId;
    }
    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }
    public String getInterfaceName() {
        return interfaceName;
    }
    public String getInterfaceNameStr() {
        String interfaceNameStr = "";
        if (null!=interfaceName) {
            if (interfaceName.equals("QueryUserProfile4Basic")) {
                interfaceNameStr = "信息查询";
            } else if (interfaceName.equals("SetIncomingCallService")) {
                interfaceNameStr = "来电显示";
            } else if (interfaceName.equals("DataPlanService")) {
                interfaceNameStr = "流量包订购";
            } else if (interfaceName.equals("UnificationDataPlanService")) {
                interfaceNameStr = "融合流量包订购";
            } else if (interfaceName.equals("CoerciveReact")) {
                interfaceNameStr = "强制复机";
            } else if (interfaceName.equals("CoerciveBlock")) {
                interfaceNameStr = "强制停机";
            } else if (interfaceName.equals("NewConnection")) {
                interfaceNameStr = "开户";
            } else if (interfaceName.equals("ModCustomer")) {
                interfaceNameStr = "过户";
            } else if (interfaceName.equals("DealerRecharge")) {
                interfaceNameStr = "充值";
            }
        }
        return interfaceNameStr;
    }
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }
    public String getRequestContent() {
        return requestContent;
    }
    public void setRequestContent(String requestContent) {
        this.requestContent = requestContent;
    }
    public Date getRequestTime() {
        return requestTime;
    }
    public void setRequestTime(Date requestTime) {
        this.requestTime = requestTime;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getResponseContent() {
        return responseContent;
    }
    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }
    public Date getResponseTime() {
        return responseTime;
    }
    public void setResponseTime(Date responseTime) {
        this.responseTime = responseTime;
    }
    public String getChannelName() {
        return channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    @Override
    public String toString() {
        return "InterfaceData [id=" + id + ", msisdn=" + msisdn + ", operatorId=" + operatorId + ", interfaceName="
                + interfaceName + ", requestContent=" + requestContent + ", requestTime=" + requestTime + ", status="
                + status + ", responseContent=" + responseContent + ", responseTime=" + responseTime + "]";
    }
}
