package com.agent.businesslog.entity;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class BusinessLogCategory implements Serializable {
    private static final long serialVersionUID = -7714154231624423252L;
    private String categoryName;
    private String description;
    private String parentName;
    private Integer categoryLevel;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public Integer getCategoryLevel() {
        return categoryLevel;
    }

    public void setCategoryLevel(Integer categoryLevel) {
        this.categoryLevel = categoryLevel;
    }
}
