package com.agent.businesslog.mapper;

import org.springframework.stereotype.Repository;

import com.agent.businesslog.entity.ErrorLog;
import com.agent.common.BaseMapper;

@Repository
public interface ErrorLogMapper extends BaseMapper<ErrorLog, Integer>{

}
