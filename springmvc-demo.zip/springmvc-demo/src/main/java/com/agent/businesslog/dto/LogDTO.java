package com.agent.businesslog.dto;

import com.agent.util.DateUtil;

import java.util.Date;

/**
 * Created by zw on 2015/8/25.
 */
public class LogDTO {
    private String logType;//日志类型
    private String operatorId;//操作员ID
    private String operatorName;//操作员名称
    private String businessId;//被操作实体ID，别操作拿条记录的ID
    private String businessName;//被操作实体名称，可为空，比如代理商开户，就写入开户的号码
    private String description;//操作说明 就是BUSINESS_LOG_TYPE这个表中PATTERN经过转换后的内容
    private String operationResult;//操作结果 成功 失败
    private Date operationDate;//操作时间
    
    /* 扩展属性 begin */
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    // 一级菜单
    private String firstMenu;
    // 二级菜单
    private String secondMenu;
    // 三级菜单
    private String thirdMenu;
    // 查询开始时间
    private String startDate;
    // 查询结束时间
    private String endDate;
    /* 扩展属性 end */

    public String getLogType() {
        return logType;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public String getBusinessId() {
        return businessId;
    }

    public String getBusinessName() {
        return businessName;
    }

    public String getDescription() {
        return description;
    }

    public String getOperationResult() {
        return operationResult;
    }

    public Date getOperationDate() {
        return operationDate;
    }


    public String getOperationDateStr(){
        return this.operationDate!=null? DateUtil.getInstance().getDateStr(operationDate,"yyyy-MM-dd HH:mm:ss"):null;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public void setOperatord(String operatorId) {
        this.operatorId = operatorId;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setOperationResult(String operationResult) {
        this.operationResult = operationResult;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getFirstMenu() {
        return firstMenu;
    }

    public void setFirstMenu(String firstMenu) {
        this.firstMenu = firstMenu;
    }

    public String getSecondMenu() {
        return secondMenu;
    }

    public void setSecondMenu(String secondMenu) {
        this.secondMenu = secondMenu;
    }

    public String getThirdMenu() {
        return thirdMenu;
    }

    public void setThirdMenu(String thirdMenu) {
        this.thirdMenu = thirdMenu;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
