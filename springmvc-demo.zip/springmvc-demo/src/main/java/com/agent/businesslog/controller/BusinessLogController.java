package com.agent.businesslog.controller;

import com.agent.businesslog.dto.LogDTO;
import com.agent.businesslog.entity.BusinessLog;
import com.agent.businesslog.entity.BusinessLogCategory;
import com.agent.businesslog.entity.BusinessLogType;
import com.agent.businesslog.service.BusinessLogService;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelsService;
import com.agent.common.PageEntity;
import com.agent.constant.Constant;
import com.agent.system.entity.User;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 数据字典控制器
 *
 * @author auto
 */
@Controller
@RequestMapping(value="businesslog")
public class BusinessLogController {
    
    private static Logger logger = LoggerFactory.getLogger(BusinessLogController.class);
    
    @Autowired
    private BusinessLogService businessLogService;
    
    @Autowired
    private ChannelsService channelsService;
    
    /**
     * 进入列表页面
     */
    @RequestMapping("list")
    public String list(HttpServletRequest request, HttpServletResponse response, Model model, LogDTO logDTO) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if (null != channels) {
                params.put("channelId", channels.getId());
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(logDTO.getPageSize(), logDTO.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(logDTO.getFirstMenu()) 
                    && StringUtils.isNotEmpty(logDTO.getSecondMenu()) 
                    && StringUtils.isNotEmpty(logDTO.getThirdMenu())) {
                params.put("logType", logDTO.getThirdMenu());
            } else if (StringUtils.isNotEmpty(logDTO.getFirstMenu()) && StringUtils.isNotEmpty(logDTO.getSecondMenu()) ) {
                params.put("logType", logDTO.getSecondMenu());
            } else if (StringUtils.isNotEmpty(logDTO.getFirstMenu())) {
                params.put("logType", logDTO.getFirstMenu());
            }
            String description = logDTO.getDescription();
            description = null==description?"":description.trim();
            logDTO.setDescription(description);
            if (StringUtils.isNoneEmpty(description)) {
                params.put("description", description);
            }
            String operatorName = logDTO.getOperatorName();
            operatorName = null==operatorName?"":operatorName.trim();
            logDTO.setOperatorName(operatorName);
            if (StringUtils.isNoneEmpty(operatorName)) {
                params.put("operatorName", operatorName);
            }
            String startDate = "";
            String endDate = "";
            if (StringUtils.isNotEmpty(logDTO.getStartDate())) {
                startDate = logDTO.getStartDate() + " 00:00:00";
                params.put("startDate", startDate);
            }
            if (StringUtils.isNotEmpty(logDTO.getEndDate())) {
                endDate = logDTO.getEndDate() + " 23:59:59";
                params.put("endDate", endDate);
            }

            List<BusinessLog> logList = businessLogService.list(params);
            int total = businessLogService.countTotal(params);
            List<BusinessLogCategory> firstMenuList = businessLogService.qryFirstMenu(new Integer(1));
            pageEntity.setTotal(total);
            request.setAttribute("logList", logList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("firstMenuList", firstMenuList);
            request.setAttribute("logDTO", logDTO);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "/views/businesslog/businessLogList.jsp";
    }
    
    /**
     * 二级菜单
     *
     * @param
     * @return
     */
    @RequestMapping(value = "secondMenu", method = RequestMethod.POST)
    @ResponseBody
    public List<BusinessLogCategory> secondMenu(@RequestParam("parentName")String parentName, HttpServletRequest request) throws Exception {
        List<BusinessLogCategory> list = businessLogService.qrySecondMenu(parentName);
        return list;
    }
    
    /**
     * 三级菜单
     *
     * @param
     * @return
     */
    @RequestMapping(value = "thirdMenu", method = RequestMethod.POST)
    @ResponseBody
    public List<BusinessLogType> thirdMenu(@RequestParam("categoryName")String categoryName, HttpServletRequest request) throws Exception {
        List<BusinessLogType> list = businessLogService.qryThirdMenu(categoryName);
        return list;
    }
}
