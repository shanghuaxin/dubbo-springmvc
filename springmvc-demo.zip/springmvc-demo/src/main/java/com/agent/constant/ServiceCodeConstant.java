package com.agent.constant;

/**
 * 联通接口业务编码常量
 * @author FengLu
 *
 */
public class ServiceCodeConstant {
    public static final String PASSWORD_UPDATE = "NEU6099060003";
    /**业务号码检测(ServiceIdCheck)*/
    public static final String SERVICE_ID_CHECK = "NEU6099060102";
    /**获取可选包接口(GetOptionalPackageServiceHandle)*/
    public static final String OPTIONAL_PACKAGE = "NEU6099060194";
    /**保存订单、预算费用(OrderAcceptHandle. doSaveBudgetOrder)*/
    public static final String SAVE_BUDGET_ORDER = "NEU6099060115";
    /**提交订单(OrderAcceptHandle. doCompleteOrder)*/
    public static final String COMPLETE_ORDER = "NEU6099060116";
    /**有效和预约销售品信息查询(QueryOfferWithStatusService）*/
    public static final String OFFER_WITH_STATUS = "NEU6099060043";
    /**可变更套餐信息查询(QueryModProdOfferService）*/
    public static final String MOD_PROD_OFFER = "NEU6099060198";
    /**销售品变更(ModOfferService）*/
    public static final String MOD_PROD = "NEU6099060004";
    /**验证用户有效性 (UserValidationService）*/
    public static final String USER_VALIDATION = "NEU6099060023";
    /**解挂(Reportmissingreport）*/
    public static final String REPORT_MISSING_REPORT = "NEU6099060222";
    /**挂失(Reportmissingreport）*/
    public static final String MISSING_REPORT = "NEU6099060223";
    /**客户资料修改AgentCustInfoService)*/
    public static final String AGENT_CUSTINFO = "NEU6099060107";
    /**补换卡接口、预算费用（ChangeCardOrder、doSaveBudgetOrder）*/
    public static final String CHANGE_CARD_ORDER = "NEU6099060196";
    /**可订购的可选包查询(QueryCanOrderProdOfferService）*/
    public static final String CAN_ORDER_PROD_OFFER = "NEU6099060189";
    /**订购退订可选包 (ModOptionalOfferService）*/
    public static final String MOD_OPTIONAL_OFFER = "NEU6099060002";
    /**密码修改 (ModPasswdService）*/
    public static final String MOD_PASSWD = "NEU6099060003";
    /**用户综合信息查询(QueryUserService）*/
    public static final String QUERY_USER = "NEU6099060079";
    /**删除订单(OrderAcceptHandle.doDeleteOrder))*/
    public static final String DELETE_ORDER = "NEU6099060117";
    /**呼转号码设置(SetCallForwardingNumberService)*/
    public static final String CALL_FORWARDING_NUMBER = "NEU6099060227";
    /**过户接口、预算费用（ChangeCustOrder、doSaveBudgetOrder）*/
    public static final String CHANGE_CUST_ORDER = "NEU6099060197";
    /**销户(AccountCancellationService）*/
    public static final String ACCOUNT_CANCELLACTION = "NEU6099060224";
    /**3G转4G(3GTurn4GService)*/
    public static final String THREEG_TO_4G = "NEU6099060231";
    /**开通关闭短信，上网功能 NEU6099060226(doProductChange)*/
    public static final String DO_PRODUCT_CHANGE = "NEU6099060226";
    /**资源池转模组校验 NEU6099060232(CheckProductIdIfEqualService)*/
    public static final String CHECK_PRODUCT_ID_IF_EQUAL = "NEU6099060232";
}
