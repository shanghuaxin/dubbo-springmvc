package com.agent.constant;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class Constant {

    public static final String SESSION_USER = "user";
    public static final String SESSION_DPRIVI = "dataprivi";
    public static final String SESSION_PRIVI = "privilege";
    public static final String SESSION_EXPIRE = "expire";
    public static final String SESSION_DENY = "deny";

    public static final String ANDROID_TYPE = "android修改列表";
    public static final String IOS_TYPE = "ios修改列表";
    public static final String WAP_TYPE = "wap修改列表";

    public static final String ANDROID_FILE = "and_img";
    public static final String ANDROID_IMG = "and_file";

    public static final String IOS_FILE = "ios_file";
    public static final String IOS_IMG = "ios_img";

    public static final String WAP_FILE = "wap_file";
    public static final String WAP_IMG = "wap_img";

    public static final Integer ADMIN_ROLE_ID = 1;// 管理员角色ID
    public static final Integer NORMAL_ADMIN_ROLE_ID = 18;// 普通管理员角色ID
    public static final Integer MANAGER_ROLE_ID = 2;// 项目经理角色ID
    public static final Integer DEPLOY_ROLE_ID = 3;// 部署人员角色ID
    public static final Integer CUSTOMER_ROLE_ID = 4;// 客户角色ID
    public static final Integer SALER_ROLE_ID = 5;// 商务角色ID
    public static final Integer TEST_ROLE_ID = 6;// 测试角色ID
    
    //导出文件暂存目录
    public static final String TEMP_EXCEL = "/temp/excel";

    //库存导入文件
    public static final String STOCK_IMPORT = "/stock/import";
    //库存分配文件
    public static final String STOCK_ALLOT = "/stock/allot";
    //库存回收文件
    public static final String STOCK_TAKE_BACK = "/stock/takeback";
    //库存下架文件
    public static final String STOCK_DEL = "/stock/del";
    //库存下架文件
    public static final String STOCK_CANCEL = "/stock/cancle";
    //ICCID出库文件
    public static final String STOCK_ICCID = "/stock/iccid";
    //模版存储相对路径
    public static final String TEMPLATE = "/template";

    //模版解析类型  预开户号码导入
    public static final String PHONE_PRE_IMPORT = "PREIMPT";
    //模版解析类型  号码导入
    public static final String PHONE_IMPORT = "PHONEIMPT";
    //模版解析类型  总部号码分配
    public static final String PHONE_ALLOT_COMP = "PHONEALLOTCOMP";
    //模版解析类型  一级号码分配
    public static final String PHONE_ALLOT_1 = "PHONEALLOT1";
    //模版解析类型  二级号码分配
    public static final String PHONE_ALLOT_2 = "PHONEALLOT2";
    //模版解析类型  号码回收
    public static final String PHONE_TAKE_BACK = "PHONETAKEBACK";
    //模版解析类型  号码下架
    public static final String PHONE_DEL = "PHONEDEL";
    //模版解析类型  号码销户
    public static final String PHONE_CANCEL = "PHONECANCEL";

    //模版解析类型  卡密导入
    public static final String CARD_IMPORT = "CARDIMPT";
    //模版解析类型  总部卡密分配
    public static final String CARD_ALLOT_COMP = "CARDALLOTCOMP";
    //模版解析类型  一级卡密分配
    public static final String CARD_ALLOT_1 = "CARDALLOT1";
    //模版解析类型  二级卡密分配
    public static final String CARD_ALLOT_2 = "CARDALLOT2";
    //模版解析类型  回收
    public static final String CARD_TAKE_BACK = "CARDTAKEBACK";
    //模版解析类型  下架
    public static final String CARD_DEL = "CARDDEL";
    //模版解析类型 ICCID回收
    public static final String ICCID_OUT = "ICCIDOUT";

    //计算公共对象
    public static BigDecimal cnt100 = new BigDecimal(100);
    //分转元 100
    public static DecimalFormat df = new DecimalFormat();
    // 不带小数点
    public static DecimalFormat df1 = new DecimalFormat("#0");
    //无小数时，只保留整数
    public static DecimalFormat df0 = new DecimalFormat("#0.00");
    //始终保留两位小数，并四舍五入
    public static DecimalFormat df00 = new DecimalFormat("#,##0.00");


    // 联通CRM接口专用 begin
    // 城市编码
    public static final String CITY_CODE = "360";
    // 联通CRM接口专用 begin
    
    // 联通billing接口专用 begin
    // 系统标识
    public static final String SYSTEM_ID = "0001";
    // 网络
    public static final String UNICOM = "LT";
    public static final String CHAINMOBILE = "YD";

    /**
     * 定时任务业务订购中
     */
    public static String is_buy = "0"; //  0-可以执行，1-执行中
    /**
     * 定时任务业务订购中
     */
    public static String is_sus = "0"; //  0-可以执行，1-执行中
    /**
     * 定时任务业务订购中
     */
    public static String is_push = "0"; //  0-可以执行，1-执行中
    
    /**
     * 联通工单
     */
    public static String MVNOKEY = "Z2XnSTq";
    public static String SERVICE_TYPE = "basic_service";
    public static String SERVICE_NAME_SUBMIT = "submit_support";
    public static String SERVICE_NAME_REVOKE = "revoke_support";
    public static String SERVICE_NAME_SUPPORT = "query_support";
    public static String API_NAME_SUBMIT = "cu.vop.basic_service.submit_support";
    public static String API_NAME_REVOKE = "cu.vop.basic_service.revoke_support";
    public static String API_NAME_SUPPORT = "cu.vop.basic_service.query_support";

}
