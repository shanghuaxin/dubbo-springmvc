package com.agent.aircharge.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.aircharge.entity.AirchargeAddRecord;
import com.agent.aircharge.entity.AirchargeAgentCode;
import com.agent.aircharge.entity.AirchargeAgentInfo;
import com.agent.aircharge.entity.AirchargeRateConfig;
import com.agent.aircharge.entity.AirchargeWarningConfig;
import com.agent.aircharge.entity.AirchargeRecordDetail;
import com.agent.aircharge.mapper.AirchargeManageMapper;

@Transactional(rollbackFor=Exception.class)
@Service("airchargeManageService")
public class AirchargeManageService {
    @Autowired
    private AirchargeManageMapper rechargeManagerMapper;
    
    /**
     * 查找所有的充值代理商信息
     * @return
     */
    public List<AirchargeAgentInfo> queryAgent(Map<String, Object> params) {
        return rechargeManagerMapper.queryAgent(params);
    }
    
    /**
     * 获取总数
     * @return
     */
    public int countAgent(Map<String, Object> params) {
        return rechargeManagerMapper.countAgent(params);
    }
    
    /**
     * 汇总充值代理商信息
     * @return
     */
    public List<AirchargeAgentInfo> statisticsAgentInfo(Map<String, Object> params) {
        return rechargeManagerMapper.statisticsAgentInfo(params);
    }
    
    /**
     * 更新充值代理商余额
     * @param airchargeAgentInfo
     * @return
     */
    public int updateAgentBalance(AirchargeAgentInfo airchargeAgentInfo) {
        return rechargeManagerMapper.updateAgentBalance(airchargeAgentInfo);
    }
    
    /**
     * 更新充值代理商状态
     * @param airchargeAgentInfo
     * @return
     */
    public int updateAgentStatus(AirchargeAgentInfo airchargeAgentInfo) {
        return rechargeManagerMapper.updateAgentStatus(airchargeAgentInfo);
    }
    
    /**
     * 查找所有的充值代理商预警信息
     * @return
     */
    public List<AirchargeWarningConfig> queryWarningConfig(Map<String, Object> params) {
        return rechargeManagerMapper.queryWarningConfig(params);
    }
    
    /**
     * 获取总数
     * @return
     */
    public int countWarning(Map<String, Object> params) {
        return rechargeManagerMapper.countWarning(params);
    }
    
    /**
     * 根据主键获取预警信息
     * @param id
     * @return
     */
    public AirchargeWarningConfig findWarningConfig(Integer id) {
        return rechargeManagerMapper.findWarningConfig(id);
    }
    
    /**
     * 新增预警信息
     * @param rechargeWarningConfig
     * @return
     */
    public int insertWarningConfig(AirchargeWarningConfig rechargeWarningConfig) {
        return rechargeManagerMapper.insertWarningConfig(rechargeWarningConfig);
    }
    
    /**
     * 更新预警余额
     * @param rechargeWarningConfig
     * @return
     */
    public int updateWarningConfig(AirchargeWarningConfig rechargeWarningConfig) {
        return rechargeManagerMapper.updateWarningConfig(rechargeWarningConfig);
    }
    
    /**
     * 查找所有的充值代理商费率信息
     * @return
     */
    public List<AirchargeRateConfig> queryRateConfig(Map<String, Object> params) {
        return rechargeManagerMapper.queryRateConfig(params);
    }
    
    /**
     * 获取总数
     * @return
     */
    public int countRate(Map<String, Object> params) {
        return rechargeManagerMapper.countRate(params);
    }
    
    /**
     * 根据主键获取费率信息
     * @param id
     * @return
     */
    public AirchargeRateConfig findRateConfig(Integer id) {
        return rechargeManagerMapper.findRateConfig(id);
    }
    
    /**
     * 新增预警信息
     * @param AirchargeRateConfig
     * @return
     */
    public int insertRateConfig(AirchargeRateConfig airchargeRateConfig) {
        return rechargeManagerMapper.insertRateConfig(airchargeRateConfig);
    }
    
    /**
     * 更新费率信息
     * @param rechargeAgentInfo
     * @return
     */
    public int updateRateConfig(AirchargeRateConfig airchargeRateConfig) {
        return rechargeManagerMapper.updateRateConfig(airchargeRateConfig);
    }
    
    
    /**
     * 查询加值信息
     * @param params
     * @return
     */
    public List<AirchargeAddRecord> queryAddRecord(Map<String, Object> params) {
        return rechargeManagerMapper.queryAddRecord(params);
    }
    
    /**
     * 获取总数
     * @return
     */
    public int countAddRecord(Map<String, Object> params) {
        return rechargeManagerMapper.countAddRecord(params);
    }
    
    /**
     * 新增加值信息
     * @param airchargeAddRecord
     * @return
     */
    public int insertAddRecord(AirchargeAddRecord airchargeAddRecord) {
        return rechargeManagerMapper.insertAddRecord(airchargeAddRecord);
    }
    
    /**
     * 获取代理商编码信息
     * @param id
     * @return
     */
    public AirchargeAgentCode findAgentCode(Integer id) {
        return rechargeManagerMapper.findAgentCode(id);
    }
    
    /**
     * 查询充值明细
     * @param params
     * @return
     */
    public List<AirchargeRecordDetail> queryAirchargeRecordDetail(Map<String, Object> params) {
        return rechargeManagerMapper.queryAirchargeRecordDetail(params);
    }
    
    /**
     * 获取总数
     * @return
     */
    public int countRecordDetail(Map<String, Object> params) {
        return rechargeManagerMapper.countRecordDetail(params);
    }
}
