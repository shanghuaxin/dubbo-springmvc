package com.agent.aircharge.entity;

import java.io.Serializable;

public class AirchargeAgentCode implements Serializable {
    
    private static final long serialVersionUID = 2431053300104452668L;
    private Integer agentId;
    private String agentCode;
    private String agentName;
    public Integer getAgentId() {
        return agentId;
    }
    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
    public String getAgentCode() {
        return agentCode;
    }
    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }
    public String getAgentName() {
        return agentName;
    }
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
}
