package com.agent.aircharge.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.util.DateUtil;

public class AirchargeRateConfig extends BaseDomain {
    
    private static final long serialVersionUID = -6269987509021738197L;
    // 充值代理商ID
    private Integer agentId;
    // 中国移动费率
    private BigDecimal chinaMobileRate;
    // 中国联通费率
    private BigDecimal chinaUnicomRate;
    // 生效时间
    private Date effectDate;
    // 失效时间
    private Date expiryDate;
    /* 扩展属性 begin */
    // 充值代理商名称
    private String agentName;
    // 生效时间
    private String effectDatePage;
    // 失效时间
    private String expiryDatePage;
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    /* 扩展属性 begin */
    
    public Integer getAgentId() {
        return agentId;
    }
    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
    public BigDecimal getChinaMobileRate() {
        return chinaMobileRate;
    }
    public void setChinaMobileRate(BigDecimal chinaMobileRate) {
        this.chinaMobileRate = chinaMobileRate;
    }
    public BigDecimal getChinaUnicomRate() {
        return chinaUnicomRate;
    }
    public void setChinaUnicomRate(BigDecimal chinaUnicomRate) {
        this.chinaUnicomRate = chinaUnicomRate;
    }
    public Date getEffectDate() {
        return effectDate;
    }
    public String getEffectDateStr() {
        return effectDate !=null ? DateUtil.getInstance().getDateStr(effectDate, DateUtil.yyyy_MM_dd) : "";
    }
    public void setEffectDate(Date effectDate) {
        this.effectDate = effectDate;
    }
    public Date getExpiryDate() {
        return expiryDate;
    }
    public String getExpiryDateStr() {
        return expiryDate !=null ? DateUtil.getInstance().getDateStr(expiryDate, DateUtil.yyyy_MM_dd) : "";
    }
    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
    public String getAgentName() {
        return agentName;
    }
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    public String getEffectDatePage() {
        return effectDatePage;
    }
    public void setEffectDatePage(String effectDatePage) {
        this.effectDatePage = effectDatePage;
    }
    public String getExpiryDatePage() {
        return expiryDatePage;
    }
    public void setExpiryDatePage(String expiryDatePage) {
        this.expiryDatePage = expiryDatePage;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public String getValidDateStr() {
        try {
            String beginDateStr =  effectDate !=null ? DateUtil.getInstance().getDateStr(effectDate, "yyyy/MM/dd") : "";
            String endDateStr =  expiryDate !=null ? DateUtil.getInstance().getDateStr(expiryDate, "yyyy/MM/dd") : "";
            return beginDateStr + " - " + endDateStr;
        } catch (Exception e) {
            
        }
        return "";
    }
}
