package com.agent.aircharge.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.aircharge.entity.AirchargeAddRecord;
import com.agent.aircharge.entity.AirchargeAgentCode;
import com.agent.aircharge.entity.AirchargeAgentInfo;
import com.agent.aircharge.entity.AirchargeRateConfig;
import com.agent.aircharge.entity.AirchargeWarningConfig;
import com.agent.aircharge.entity.AirchargeRecordDetail;
import com.agent.common.BaseMapper;

@Repository
public interface AirchargeManageMapper extends BaseMapper<AirchargeAgentInfo, Integer> {
    
    /**
     * 查找所有的充值代理商信息
     * @return
     */
    public List<AirchargeAgentInfo> queryAgent(Map<String, Object> params);
    
    /**
     * 获取总数
     * @return
     */
    public int countAgent(Map<String, Object> params);
    
    /**
     * 汇总充值代理商信息
     * @return
     */
    public List<AirchargeAgentInfo> statisticsAgentInfo(Map<String, Object> params);
    
    /**
     * 更新充值代理商余额
     * @param airchargeAgentInfo
     * @return
     */
    public int updateAgentBalance(AirchargeAgentInfo airchargeAgentInfo);
    
    /**
     * 更新充值代理商状态
     * @param airchargeAgentInfo
     * @return
     */
    public int updateAgentStatus(AirchargeAgentInfo airchargeAgentInfo);
    
    /**
     * 更新费率信息
     * @param airchargeRateConfig
     * @return
     */
    public int updateRateConfig(AirchargeRateConfig airchargeRateConfig);
    
    /**
     * 查找所有的充值代理商预警信息
     * @param params
     * @return
     */
    public List<AirchargeWarningConfig> queryWarningConfig(Map<String, Object> params);
    
    /**
     * 获取总数
     * @return
     */
    public int countWarning(Map<String, Object> params);
    
    /**
     * 根据主键获取预警信息
     * @param id
     * @return
     */
    public AirchargeWarningConfig findWarningConfig(Integer id);
    
    /**
     * 新增预警信息
     * @param rechargeWarningConfig
     * @return
     */
    public int insertWarningConfig(AirchargeWarningConfig rechargeWarningConfig);
    
    /**
     * 更新预警余额
     * @param rechargeWarningConfig
     * @return
     */
    public int updateWarningConfig(AirchargeWarningConfig rechargeWarningConfig);
    
    /**
     * 查找所有的充值代理商费率信息
     * @return
     */
    public List<AirchargeRateConfig> queryRateConfig(Map<String, Object> params);
    
    /**
     * 获取总数
     * @return
     */
    public int countRate(Map<String, Object> params);
    
    /**
     * 根据主键获取费率信息
     * @param id
     * @return
     */
    public AirchargeRateConfig findRateConfig(Integer id);
    
    /**
     * 新增预警信息
     * @param airchargeRateConfig
     * @return
     */
    public int insertRateConfig(AirchargeRateConfig airchargeRateConfig);
    
    /**
     * 查询加值信息
     * @param params
     * @return
     */
    public List<AirchargeAddRecord> queryAddRecord(Map<String, Object> params);
    
    /**
     * 获取总数
     * @return
     */
    public int countAddRecord(Map<String, Object> params);
    
    /**
     * 新增加值信息
     * @param airchargeAddRecord
     * @return
     */
    public int insertAddRecord(AirchargeAddRecord airchargeAddRecord);
    
    /**
     * 获取代理商编码信息
     * @param id
     * @return
     */
    public AirchargeAgentCode findAgentCode(Integer id);
    
    /**
     * 查询充值明细
     * @param params
     * @return
     */
    public List<AirchargeRecordDetail> queryAirchargeRecordDetail(Map<String, Object> params);
    
    /**
     * 获取总数
     * @return
     */
    public int countRecordDetail(Map<String, Object> params);
}
