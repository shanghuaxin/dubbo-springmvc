package com.agent.aircharge.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;

public class AirchargeAddRecord extends BaseDomain {
    
    private static final long serialVersionUID = 7264468562094863707L;
    // 充值代理商ID
    private Integer agentId;
    // 操作金额
    private BigDecimal operationMoney;
    // 备注
    private String remark;
    
    /* 扩展属性 begin */
    // 充值代理商名称
    private String agentName;
    // 操作人
    private String operationName;
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    // 开始时间
    private String startDate;
    // 结束时间
    private String endDate;
    /* 扩展属性 begin */
    
    public Integer getAgentId() {
        return agentId;
    }
    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
    public BigDecimal getOperationMoney() {
        return operationMoney;
    }
    public String getOperationMoneyYuan() {
        if(null != operationMoney){
            return Constant.df00.format(operationMoney.divide(Constant.cnt100));
        }
        return "0.00";
    }
    public void setOperationMoney(BigDecimal operationMoney) {
        this.operationMoney = operationMoney;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getOperationName() {
        return operationName;
    }
    public void setOperationName(String operationName) {
        this.operationName = operationName;
    }
    public String getAgentName() {
        return agentName;
    }
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
