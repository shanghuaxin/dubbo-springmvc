package com.agent.aircharge.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;

public class AirchargeWarningConfig extends BaseDomain {
    
    private static final long serialVersionUID = -4512058488112199427L;
    // 充值代理商ID
    private Integer agentId;
    // 预警余额，小于次金额时，根据warningType进行不同的操作
    private BigDecimal warningBalance;
    // 预警配置类型 1:预警金额配置 2:关闭金额配置
    private Integer warningType;
    /* 扩展属性 begin */
    // 充值代理商名称
    private String agentName;
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    /* 扩展属性 begin */
    
    public Integer getAgentId() {
        return agentId;
    }
    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
    public BigDecimal getWarningBalance() {
        return warningBalance;
    }
    public BigDecimal getWarningBalanceYuan() {
        if(null != warningBalance){
            return warningBalance.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return warningBalance;
    }
    public void setWarningBalance(BigDecimal warningBalance) {
        this.warningBalance = warningBalance;
    }
    public Integer getWarningType() {
        return warningType;
    }
    public void setWarningType(Integer warningType) {
        this.warningType = warningType;
    }
    public String getAgentName() {
        return agentName;
    }
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
