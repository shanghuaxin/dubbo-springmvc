package com.agent.aircharge.entity;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.agent.common.BaseDomain;
import com.agent.common.enumeration.NetworkType;
import com.agent.constant.Constant;
import com.agent.util.DateUtil;

public class AirchargeRecordDetail extends BaseDomain {
    
    private static final long serialVersionUID = -1854485492417772152L;
    // 手机号码
    private String phone;
    // 运营商
    private String network;
    // 充值代理商ID
    private Integer agentId;
    // 充值代理商名称
    private String agentName;
    // 充值流水号
    private String orderNo;
    // 充值金额
    private BigDecimal money;
    // 佣金
    private BigDecimal broMoney;
    // 调用方操作流水号
    private String callOrderNo;
    // 调用方操作时间
    private Date callOperationTime;
    /* 扩展属性 begin */
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    // 开始时间
    private String startDate;
    // 结束时间
    private String endDate;
    /* 扩展属性 end */
    
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getNetwork() {
        return network;
    }
    public String getNetworkStr() {
        if (StringUtils.isNotEmpty(network)) {
            return NetworkType.getName(network);
        }
        return "";
    }
    public void setNetwork(String network) {
        this.network = network;
    }
    public Integer getAgentId() {
        return agentId;
    }
    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
    public String getAgentName() {
        return agentName;
    }
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public BigDecimal getMoneyYuan() {
        if(null != money){
            return money.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public BigDecimal getBroMoney() {
        return broMoney;
    }
    public BigDecimal getBroMoneyYuan() {
        if(null != broMoney){
            return broMoney.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return broMoney;
    }
    public void setBroMoney(BigDecimal broMoney) {
        this.broMoney = broMoney;
    }
    public String getCallOrderNo() {
        return callOrderNo;
    }
    public void setCallOrderNo(String callOrderNo) {
        this.callOrderNo = callOrderNo;
    }
    public Date getCallOperationTime() {
        return callOperationTime;
    }
    public String getCallOperationTimeStr() {
        return callOperationTime !=null ? DateUtil.getInstance().getDateStr(callOperationTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setCallOperationTime(Date callOperationTime) {
        this.callOperationTime = callOperationTime;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
