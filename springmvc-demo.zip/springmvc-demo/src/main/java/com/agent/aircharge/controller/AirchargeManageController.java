package com.agent.aircharge.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.aircharge.entity.AirchargeAddRecord;
import com.agent.aircharge.entity.AirchargeAgentCode;
import com.agent.aircharge.entity.AirchargeAgentInfo;
import com.agent.aircharge.entity.AirchargeRateConfig;
import com.agent.aircharge.entity.AirchargeWarningConfig;
import com.agent.aircharge.entity.AirchargeRecordDetail;
import com.agent.aircharge.service.AirchargeManageService;
import com.agent.api.InterfaceUtil;
import com.agent.common.PageEntity;
import com.agent.constant.Constant;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;
import com.agent.util.SysConfig;

@Controller
@RequestMapping(value="aircharge")
public class AirchargeManageController {
    private static Logger logger = LoggerFactory.getLogger(AirchargeManageController.class);
    
    @Autowired
    private AirchargeManageService airchargeManageService;
    
    /**
     * 初始化预警配置页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="warningInit", method=RequestMethod.GET)
    public String warningInit(HttpServletRequest request, HttpServletResponse response, 
            Integer pageIndex, Integer pageSize, Integer warningType) {
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // warningType 配置类型 1：预警阈值配置 2：关闭阈值配置
            if (null == warningType) {
                warningType = 1;
            }
            params.put("warningType", warningType);
            List<AirchargeWarningConfig> warningList = airchargeManageService.queryWarningConfig(params);
            int totalCount = airchargeManageService.countWarning(params);
            pageEntity.setTotal(totalCount);
            request.setAttribute("warningList", warningList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("warningType", warningType);
        } catch (Exception e) {
            logger.error("初始化预警配置页面出错："+e.getMessage(), e);
        }
        String result = "/views/aircharge/aircharge_warning.jsp";
        if (null!=warningType && warningType==2) {
            result = "/views/aircharge/aircharge_close.jsp";
        }
        return result;
    }
    
    /**
     * 初始化新增预警页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="warningEditInit")
    public String warningEditInit(HttpServletRequest request, HttpServletResponse response, 
            Integer id, Integer warningType) {
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            List<AirchargeAgentInfo> agentList = airchargeManageService.queryAgent(params);
            AirchargeWarningConfig airchargeWarningConfig = null;
            if (null != id) {
                // id不为空，表示是编辑
                airchargeWarningConfig = airchargeManageService.findWarningConfig(id);
            } else {
                airchargeWarningConfig = new AirchargeWarningConfig();
                airchargeWarningConfig.setWarningType(warningType);
            }
            request.setAttribute("airchargeWarningConfig", airchargeWarningConfig);
            request.setAttribute("agentList", agentList);
        } catch (Exception e) {
            logger.error("初始化新增预警页面出错："+e.getMessage(), e);
        }
        String result = null;
        if (null!=warningType && warningType==1) {
            result = "/views/aircharge/aircharge_warning_edit.jsp";
        } else {
            result = "/views/aircharge/aircharge_close_edit.jsp";
        }
        return result;
    }
    
    /**
     * 维护预警信息
     * @param request
     * @param response
     * @param agentId
     * @param warningBalance
     * @return
     */
    @RequestMapping(value="warningEdit")
    @ResponseBody
    public Map<String, Object> warningEdit(HttpServletRequest request, HttpServletResponse response, 
            AirchargeWarningConfig airchargeWarningConfig) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            // 新增
            if (null == airchargeWarningConfig.getId()) {
                Map<String,Object> param = new HashMap<String,Object>();
                param.put("agentId", airchargeWarningConfig.getAgentId());
                param.put("warningType", airchargeWarningConfig.getWarningType());
                // 查找记录是否存在，存在就提示不能添加
                int count = airchargeManageService.countWarning(param);
                if (count > 0) {
                    map.put("status", false);
                    map.put("msg", "该渠道已设置预警配置，不能添加！");
                    return map;
                }
                // 元转换为分
                airchargeWarningConfig.setWarningBalance(airchargeWarningConfig.getWarningBalance().multiply(new BigDecimal(100)));
                airchargeWarningConfig.setWarningType(airchargeWarningConfig.getWarningType());
                airchargeWarningConfig.setCreateId(user.getId());
                airchargeWarningConfig.setUpdateId(user.getId());
                airchargeManageService.insertWarningConfig(airchargeWarningConfig);
            } else {
                // 修改
                AirchargeWarningConfig oldAirchargeWarningConfig = airchargeManageService.findWarningConfig(airchargeWarningConfig.getId());
                oldAirchargeWarningConfig.setWarningBalance(airchargeWarningConfig.getWarningBalance().multiply(new BigDecimal(100)));
                airchargeManageService.updateWarningConfig(oldAirchargeWarningConfig);
            }
        } catch (Exception e) {
            logger.error("新增预警配置出错："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "新增预警配置出错");
        }
        return map;
    }
    
    /**
     * 初始化费率配置页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="rateInit", method=RequestMethod.GET)
    public String rateInit(HttpServletRequest request, HttpServletResponse response, 
            Integer pageIndex, Integer pageSize) {
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            List<AirchargeRateConfig> rateList = airchargeManageService.queryRateConfig(params);
            int totalCount = airchargeManageService.countRate(params);
            pageEntity.setTotal(totalCount);
            request.setAttribute("rateList", rateList);
            request.setAttribute("pageEntity", pageEntity);
        } catch (Exception e) {
            logger.error("初始化费率配置页面出错："+e.getMessage(), e);
        }
        return "/views/aircharge/aircharge_rate.jsp";
    }
    
    /**
     * 初始化新增/修改费率页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="rateEditInit")
    public String rateEditInit(HttpServletRequest request, HttpServletResponse response, 
            Integer id, Integer warningType) {
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            List<AirchargeAgentInfo> agentList = airchargeManageService.queryAgent(params);
            AirchargeRateConfig airchargeRateConfig = null;
            if (null != id) {
                // id不为空，表示是编辑
                airchargeRateConfig = airchargeManageService.findRateConfig(id);
            } else {
                airchargeRateConfig = new AirchargeRateConfig();
            }
            request.setAttribute("airchargeRateConfig", airchargeRateConfig);
            request.setAttribute("agentList", agentList);
        } catch (Exception e) {
            logger.error("初始化新增/修改费率页面出错："+e.getMessage(), e);
        }
        return "/views/aircharge/aircharge_rate_edit.jsp";
    }
    
    /**
     * 维护费率信息
     * @param request
     * @param response
     * @param warningBalance
     * @return
     */
    @RequestMapping(value="rateEdit")
    @ResponseBody
    public Map<String, Object> rateEdit(HttpServletRequest request, HttpServletResponse response, 
            AirchargeRateConfig airchargeRateConfig) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            // 新增
            if (null == airchargeRateConfig.getId()) {
                airchargeRateConfig.setEffectDate(DateUtil.getInstance().parseDate(airchargeRateConfig.getEffectDatePage()+" 00:00:00",DateUtil.yyyy_MM_dd_HH_mm_ss));
                if (StringUtils.isNotEmpty(airchargeRateConfig.getExpiryDatePage())) {
                    airchargeRateConfig.setExpiryDate(DateUtil.getInstance().parseDate(airchargeRateConfig.getExpiryDatePage()+" 23:59:59",DateUtil.yyyy_MM_dd_HH_mm_ss));
                } else {
                    airchargeRateConfig.setExpiryDate(DateUtil.getInstance().parseDate("2037-12-31 23:59:59", DateUtil.yyyy_MM_dd_HH_mm_ss));
                }
                airchargeRateConfig.setCreateId(user.getId());
                airchargeRateConfig.setUpdateId(user.getId());
                airchargeManageService.insertRateConfig(airchargeRateConfig);
            } else {
                // 修改
                AirchargeRateConfig oldAirchargeRateConfig = airchargeManageService.findRateConfig(airchargeRateConfig.getId());
                oldAirchargeRateConfig.setChinaMobileRate(airchargeRateConfig.getChinaMobileRate());
                oldAirchargeRateConfig.setChinaUnicomRate(airchargeRateConfig.getChinaUnicomRate());
                oldAirchargeRateConfig.setEffectDate(DateUtil.getInstance().parseDate(airchargeRateConfig.getEffectDatePage()+" 00:00:00",DateUtil.yyyy_MM_dd_HH_mm_ss));
                if (StringUtils.isNotEmpty(airchargeRateConfig.getExpiryDatePage())) {
                    oldAirchargeRateConfig.setExpiryDate(DateUtil.getInstance().parseDate(airchargeRateConfig.getExpiryDatePage()+" 23:59:59",DateUtil.yyyy_MM_dd_HH_mm_ss));
                } else {
                    oldAirchargeRateConfig.setExpiryDate(DateUtil.getInstance().parseDate("2037-12-31 23:59:59", DateUtil.yyyy_MM_dd_HH_mm_ss));
                }
                airchargeManageService.updateRateConfig(oldAirchargeRateConfig);
            }
        } catch (Exception e) {
            logger.error("维护费率配置出错："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "维护费率配置出错");
        }
        return map;
    }
    
    /**
     * 初始化预警信息页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="warningDetail")
    public String warningDetailInit(HttpServletRequest request, HttpServletResponse response, 
            AirchargeAddRecord airchargeAddRecord) {
        try {
            Map<String, Object> param = new HashMap<String, Object>();
            // 充值代理商列表
            List<AirchargeAgentInfo> agentList = airchargeManageService.queryAgent(param);
            Map<String, Object> params = new HashMap<String, Object>();
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(airchargeAddRecord.getPageSize(), airchargeAddRecord.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(airchargeAddRecord.getStartDate())) {
                params.put("startDate", airchargeAddRecord.getStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(airchargeAddRecord.getEndDate())) {
                params.put("endDate", airchargeAddRecord.getEndDate() + " 23:59:59");
            }
            if (null != airchargeAddRecord.getAgentId()) {
                params.put("agentId", airchargeAddRecord.getAgentId());
            }
            List<AirchargeAddRecord> addMoneyList = airchargeManageService.queryAddRecord(params);
            int totalCount = airchargeManageService.countAddRecord(params);
            List<AirchargeAgentInfo> agentInfoList = airchargeManageService.statisticsAgentInfo(new HashMap<String, Object>());
            pageEntity.setTotal(totalCount);
            request.setAttribute("agentList", agentList);
            request.setAttribute("addMoneyList", addMoneyList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("airchargeAddRecord", airchargeAddRecord);
            request.setAttribute("agentInfoList", agentInfoList);
        } catch (Exception e) {
            logger.error("初始化预警信息页面出错："+e.getMessage(), e);
        }
        return "/views/aircharge/aircharge_warning_detail.jsp";
    }
    
    /**
     * 初始化新增加值信息页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="addMoneyInit", method=RequestMethod.GET)
    public String addMoneyInit(HttpServletRequest request, HttpServletResponse response) {
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            List<AirchargeAgentInfo> agentList = airchargeManageService.queryAgent(params);
            request.setAttribute("agentList", agentList);
        } catch (Exception e) {
            logger.error("初始化新增加值信息页面出错："+e.getMessage(), e);
        }
        return "/views/aircharge/aircharge_add_money.jsp";
    }
    
    /**
     * 加值
     * @param request
     * @param response
     * @param airchargeAddRecord
     * @return
     */
    @RequestMapping(value="addMoneyEdit")
    @ResponseBody
    public Map<String, Object> addMoneyEdit(HttpServletRequest request, HttpServletResponse response, 
            AirchargeAddRecord airchargeAddRecord) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            /*// 元转换为分
            airchargeAddRecord.setOperationMoney(airchargeAddRecord.getOperationMoney().multiply(new BigDecimal(100)));
            airchargeAddRecord.setCreateId(user.getId());
            airchargeAddRecord.setUpdateId(user.getId());
            // 记录加值信息
            airchargeManageService.insertAddRecord(airchargeAddRecord);
            // 修改充值代理商余额
            AirchargeAgentInfo airchargeAgentInfo = new AirchargeAgentInfo();
            airchargeAgentInfo.setAgentId(airchargeAddRecord.getAgentId());
            airchargeAgentInfo.setBalance(airchargeAddRecord.getOperationMoney());
            // 加值时，认为用户已经收到告警信息或本来就没有告警，把标识置为0，以便下次预警
            airchargeAgentInfo.setWarningStatus(0);
            airchargeAgentInfo.setUpdateId(user.getId());
            airchargeManageService.updateAgentBalance(airchargeAgentInfo);*/
            
            String url = SysConfig.getValue("CoolAirChargeUrl");
            InterfaceUtil.getInstance().callInvoke(url + "add-charge?agentId="+airchargeAddRecord.getAgentId()+"&money="+airchargeAddRecord.getOperationMoney().multiply(new BigDecimal(100))+"&userId="+user.getId(), "");//url + "add-charge?code=card_dx&money=10000&writeLog=true"
        } catch (Exception e) {
            logger.error("加值出错："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "加值出错");
        }
        return map;
    }
    
    /**
     * 空充明细
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="recordDetail")
    public String recordDetail(HttpServletRequest request, HttpServletResponse response, 
            AirchargeRecordDetail arichargeRecordDetail) {
        try {
            Map<String, Object> param = new HashMap<String, Object>();
            // 充值代理商列表
            List<AirchargeAgentInfo> agentList = airchargeManageService.queryAgent(param);
            Map<String, Object> params = new HashMap<String, Object>();
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(arichargeRecordDetail.getPageSize(), arichargeRecordDetail.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // net为null，表示首次进入页面，需要设置startDate和endDate默认值为当天
            String startDate = null;
            String endDate = null;
            if (null == arichargeRecordDetail.getNetwork()) {
                startDate = DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd);
                endDate = DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd);
                arichargeRecordDetail.setStartDate(startDate);
                arichargeRecordDetail.setEndDate(endDate);
            }
            if (StringUtils.isNotEmpty(arichargeRecordDetail.getStartDate())) {
                params.put("startDate", arichargeRecordDetail.getStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(arichargeRecordDetail.getEndDate())) {
                params.put("endDate", arichargeRecordDetail.getEndDate() + " 23:59:59");
            }
            if (null != arichargeRecordDetail.getAgentId()) {
                params.put("agentId", arichargeRecordDetail.getAgentId());
                // 把代理商ID根据表t_aircharge_agent_code中的关系转换成code
                AirchargeAgentCode airchargeAgentCode = airchargeManageService.findAgentCode(arichargeRecordDetail.getAgentId());
                params.put("payType", airchargeAgentCode.getAgentCode());
            } else {
                // TODO 代理商为空时，目前只查询鼎信充值卡的详情，等酷商接入了空充业务后，再修改此处逻辑
                params.put("agentId", "207");
                // 把代理商ID根据表t_aircharge_agent_code中的关系转换成code
                AirchargeAgentCode airchargeAgentCode = airchargeManageService.findAgentCode(207);
                if (null == airchargeAgentCode) {
                    params.put("payType", "card_dx");
                } else {
                    params.put("payType", airchargeAgentCode.getAgentCode());
                }
            }
            if (StringUtils.isNotEmpty(arichargeRecordDetail.getNetwork())) {
                params.put("network", arichargeRecordDetail.getNetwork());
            }
            List<AirchargeRecordDetail> recordDetailList = airchargeManageService.queryAirchargeRecordDetail(params);
            int totalCount = airchargeManageService.countRecordDetail(params);
            pageEntity.setTotal(totalCount);
            request.setAttribute("agentList", agentList);
            request.setAttribute("recordDetailList", recordDetailList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("arichargeRecordDetail", arichargeRecordDetail);
        } catch (Exception e) {
            logger.error("查询空充明细信息出错："+e.getMessage(), e);
        }
        return "/views/aircharge/aircharge_record_detail.jsp";
    }
    
    /**
     * 导出空充明细
     * @param request
     * @param response
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, AirchargeRecordDetail arichargeRecordDetail) {
        logger.info("-------------空充明细记录导出开始-------------");
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            // 最大导出5000条记录
            params.put("limit", 0);
            params.put("offset", 5000);
            if (StringUtils.isNotEmpty(arichargeRecordDetail.getStartDate())) {
                params.put("startDate", arichargeRecordDetail.getStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(arichargeRecordDetail.getEndDate())) {
                params.put("endDate", arichargeRecordDetail.getEndDate() + " 23:59:59");
            }
            if (null != arichargeRecordDetail.getAgentId()) {
                params.put("agentId", arichargeRecordDetail.getAgentId());
                // 把代理商ID根据表t_aircharge_agent_code中的关系转换成code
                AirchargeAgentCode airchargeAgentCode = airchargeManageService.findAgentCode(arichargeRecordDetail.getAgentId());
                params.put("payType", airchargeAgentCode.getAgentCode());
            } else {
                // TODO 代理商为空时，目前只查询鼎信充值卡的详情，等酷商接入了空充业务后，再修改此处逻辑
                params.put("agentId", "700");
                // 把代理商ID根据表t_aircharge_agent_code中的关系转换成code
                AirchargeAgentCode airchargeAgentCode = airchargeManageService.findAgentCode(700);
                params.put("payType", airchargeAgentCode.getAgentCode());
            }
            if (null != arichargeRecordDetail.getNetwork()) {
                params.put("network", arichargeRecordDetail.getNetwork());
            }
            List<AirchargeRecordDetail> recordDetailList = airchargeManageService.queryAirchargeRecordDetail(params);
            
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "空充明细记录" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"手机号码","运营商" ,"空充代理商" ,"充值流水号" ,"充值金额/元" ,"佣金/元" , "充值时间" ,"调用方操作流水号", "调用方操作时间", "充值渠道ID" };
            properties = new String[]{"phone", "networkStr" ,"agentName" ,"orderNo" ,"moneyYuan" ,"broMoneyYuan", "createTimeStr", "callOrderNo", "callOperationTimeStr", "agentId"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, recordDetailList, properties);
        } catch (Exception e) {
            logger.error("导出空充明细记录异常："+e.getMessage(), e);
        }
        logger.info("-------------空充明细记录导出结束-------------");
    }
    
    /**
     * 编辑空充代理商
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "editStatus/{id}/{status}", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> closeAgent(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id, @PathVariable Integer status) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            /*AirchargeAgentInfo agentInfo = new AirchargeAgentInfo();
            agentInfo.setId(id);
            agentInfo.setStatus(status);
            agentInfo.setUpdateId(user.getId());
            airchargeManageService.updateAgentStatus(agentInfo);*/
            
            String url = SysConfig.getValue("CoolAirChargeUrl");
            InterfaceUtil.getInstance().callInvoke(url + "update-status-charge?agentId="+id+"&status="+status+"&userId="+user.getId(), "");//url + "add-charge?agentId=700&status=1&userId=123"
        } catch (Exception e) {
            logger.error("编辑空充代理商异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "编辑空充代理商异常");
        }
        return map;
    }
}