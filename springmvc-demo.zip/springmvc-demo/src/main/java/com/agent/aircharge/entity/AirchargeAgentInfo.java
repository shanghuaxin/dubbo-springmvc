package com.agent.aircharge.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;

public class AirchargeAgentInfo extends BaseDomain {
    
    private static final long serialVersionUID = 6479383703635544973L;
    // 充值代理商ID
    private Integer agentId;
    // 充值代理商名称
    private String agentName;
    // 账户余额
    private BigDecimal balance;
    // 是否已经余额阈值告警 0:未告警 1:告警 默认0
    private Integer warningStatus;
    // 状态 0:关闭 1:正常
    private Integer status;
    
    /* 扩展属性 begin */
    // 加值总额
    private BigDecimal addTotalMoney;
    // 消耗总额
    private BigDecimal useMoney;
    // 预警金额
    private BigDecimal warningBalance;
    // 关闭金额
    private BigDecimal closeBalance;
    /* 扩展属性 end */
    
    public Integer getAgentId() {
        return agentId;
    }
    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
    public String getAgentName() {
        return agentName;
    }
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    public BigDecimal getBalance() {
        return balance;
    }
    public BigDecimal getBalanceYuan() {
        if(null != balance){
            return balance.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return balance;
    }
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    public Integer getWarningStatus() {
        return warningStatus;
    }
    public void setWarningStatus(Integer warningStatus) {
        this.warningStatus = warningStatus;
    }
    public Integer getStatus() {
        return status;
    }
    public String getStatusStr() {
        String statusStr = "";
        if (null != status) {
            if (0 == status) {
                statusStr = "关闭";
            } else {
                statusStr = "正常";
            }
        }
        return statusStr;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public BigDecimal getAddTotalMoney() {
        return addTotalMoney;
    }
    public BigDecimal getAddTotalMoneyYuan() {
        if(null != addTotalMoney){
            return addTotalMoney.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return addTotalMoney;
    }
    public void setAddTotalMoney(BigDecimal addTotalMoney) {
        this.addTotalMoney = addTotalMoney;
    }
    public BigDecimal getUseMoney() {
        return useMoney;
    }
    public BigDecimal getUseMoneyYuan() {
        if(null != useMoney){
            return useMoney.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return useMoney;
    }
    public void setUseMoney(BigDecimal useMoney) {
        this.useMoney = useMoney;
    }
    public BigDecimal getWarningBalance() {
        return warningBalance;
    }
    public BigDecimal getWarningBalanceYuan() {
        if(null != warningBalance){
            return warningBalance.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return warningBalance;
    }
    public void setWarningBalance(BigDecimal warningBalance) {
        this.warningBalance = warningBalance;
    }
    public BigDecimal getCloseBalance() {
        return closeBalance;
    }
    public BigDecimal getCloseBalanceYuan() {
        if(null != closeBalance){
            return closeBalance.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return closeBalance;
    }
    public void setCloseBalance(BigDecimal closeBalance) {
        this.closeBalance = closeBalance;
    }
}
