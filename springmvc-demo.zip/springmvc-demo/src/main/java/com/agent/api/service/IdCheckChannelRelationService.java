package com.agent.api.service;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.agent.api.ApiResultCode;
import com.agent.api.InterfaceUtil;
import com.agent.api.entity.IDCheck;
import com.agent.api.entity.IdCheckChannelRelation;
import com.agent.api.mapper.IDCheckMapper;
import com.agent.api.mapper.IdCheckChannelRelationMapper;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.enumeration.OperationType;
import com.agent.constant.Constant;
import com.agent.number.entity.TNumber;
import com.agent.number.service.NumberService;
import com.agent.order.service.OrderDetailService;
import com.agent.system.entity.User;
import com.agent.util.DicUtil;
import com.agent.util.SysConfig;
import com.agent.util.Utils;

@Transactional(rollbackFor=Exception.class)
@Service("idCheckChannelRelationService")
public class IdCheckChannelRelationService {
    private static Logger logger = LoggerFactory.getLogger(IdCheckChannelRelationService.class);
    @Autowired
    private IdCheckChannelRelationMapper idCheckChannelRelationMapper;
    
    @Autowired
    private IDCheckMapper idCheckMapper;
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private ChannelAccountService channelAccountService;
    @Autowired
    private NumberService numberService;
    @Autowired
    private OrderDetailService orderDetailService;
    
    private IDCheck findByIDCode(Map<String, Object> param){
        return idCheckMapper.findByIDCode(param);
    }
    
    // 添加
    private int insert(IDCheck idCheck) {
        return idCheckMapper.insert(idCheck);
    }
    
    /**
     * OCR识别
     * @param requestJson 必须包含frontImg，backImg（身份证正反面base64图片或绝对地址,两个参数不能同时为空）
     *                    非必须 imgType默认0表示图片base64,  1表示图片绝对路径
     * @return  json字符串
     * @throws Exception
     */
    public String ocrAnalyse(String requestJson, HttpServletRequest request) {
        String result = "";
        String ocrPrice = "0";
        
        try {
            JSONObject jsonObject = new JSONObject(requestJson);
            
            if(!jsonObject.has("frontImg") && !jsonObject.has("backImg")){
                result = "{\"result\":\""+ApiResultCode.FAIL_102.getId()+"\", \"message\": \"参数异常,frontImg与backImg参数不能同时为空\"}";
                return result;
            }
            
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            
            Integer channelId = 0;
            Channels channel = null;
            if(jsonObject.has("partner_account") && jsonObject.has("partner_pwd") && jsonObject.has("partner_secret_key")){
                String partner_account = jsonObject.getString("partner_account");
                String partner_pwd = jsonObject.getString("partner_pwd");
                String partner_secret_key = jsonObject.getString("partner_secret_key");
                IdCheckChannelRelation iccr = this.findIdCheckChannelRelation(partner_account, partner_pwd, partner_secret_key);
                if(iccr!=null){
                    channelId = iccr.getChannelId();
                    // OCR识别身份证反面是否需要计费，如果传递idnosBackNoChargingByOCR参数,表示不计费
                    //if(!jsonObject.has("idnosBackNoChargingByOCR")){
                    if(jsonObject.has("frontImg")){// 如果识别反面图片，直接不计费
                        ocrPrice = iccr.getOcrPrice();
                        if(ocrPrice==null || "".equals(ocrPrice)){
                            ocrPrice = "0";
                        }
                    }
                } else {
                    result = "{\"result\":\""+ApiResultCode.FAIL_101.getId()+"\", \"message\": \"非法接入\"}";
                    return result;
                }
                channel = channelsService.findById(channelId);
                if (null==channel) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_201.getId()+"\", \"message\": \"非法接入,渠道信息未录入系统\"}";
                    return result;
                }
            } else {
                if (null==user || user.getId()==null || user.getId()<=0) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_202.getId()+"\", \"message\": \"非网点登录，请重新登录\"}";
                    return result;
                }
                //以下是获取渠道信息
                channel = channelsService.findChannelByUserId(user.getId());
                if (null==channel || channel.getChannelType()!=2) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_202.getId()+"\", \"message\": \"非网点登录，请重新登录\"}";
                    return result;
                }
                channelId = channel.getId();
                
                // OCR识别身份证反面是否需要计费，如果传递idnosBackNoChargingByOCR参数,表示不计费
                //if(!jsonObject.has("idnosBackNoChargingByOCR")){
                if(jsonObject.has("frontImg")){// 如果识别反面图片，直接不计费
                    // 根据OCR的价格，扣除代理商的费用(单位：元)
                    ocrPrice = DicUtil.getMapDictionary("SYS_CONFIG").get("OCR_PRICE");
                    if(ocrPrice==null || "".equals(ocrPrice)){
                        ocrPrice = "0";
                    }
                }
            }
            
            IDCheck idCheck = new IDCheck();
            idCheck.setChannelId(channelId);
            // 获取直充账户余额
            ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channelId, 3);
            // 获取划拨账户余额
            ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channelId, 2);
            // 未处理的划拨账户订单金额
            Map<String, Object> para = new HashMap<String, Object>();
            para.put("channelId", channelId);
            para.put("accountType", 2);
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
            // 未处理的充值账户订单金额
            para.put("accountType", 3);
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
            
            BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
            allotBalance = allotBalance.subtract(freezeAllotMoney);
            BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
            directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
            
            // 判断充值账户和划拨账户的总额是否大于0，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
            if (directRechargeBalance.add(allotBalance).compareTo(new BigDecimal(ocrPrice)) == -1) {
                result = "{\"result\":\""+ApiResultCode.FAIL_203.getId()+"\", \"message\": \"账户余额不足，无法进行OCR识别！\"}";
                return result;
            }
            
            // 服务端地址
            String url = SysConfig.getValue("CoolUrl");
            String ocrAnalyse = SysConfig.getValue("OCRAnalyse");
            
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("url", url+ocrAnalyse);
            if(jsonObject.has("frontImg")){
                param.put("frontImg", jsonObject.get("frontImg").toString());
                // 设置上传头像信息地址，酷商系统终止返回头像功能
                /*if(jsonObject.has("headimgPath")){
                    param.put("headimgPath", jsonObject.get("headimgPath").toString());
                }*/
            }
            if(jsonObject.has("backImg")){
                param.put("backImg", jsonObject.get("backImg").toString());
            }
            //默认0表示图片base64,  1表示图片绝对路径
            if(jsonObject.has("imgType")){
                param.put("imgType", jsonObject.get("imgType").toString());
            }
            
            result = InterfaceUtil.getInstance().httpPost(param);
            JSONObject json = new JSONObject(result);
            String resultOcr = json.getString("result");
            String message = URLDecoder.decode(json.getString("message"), "UTF-8");
            idCheck.setResultCode(resultOcr);
            idCheck.setMessage(message);
            if ("0".equals(resultOcr)) {
                if(json.has("id_code")){
                    idCheck.setIdCode(json.getString("id_code"));
                }
                idCheck.setTransactionId(json.getString("transaction_id"));
                
                // 身份证反面不计费，并不写数据库
                //if(!jsonObject.has("idnosBackNoChargingByOCR")){
                if(jsonObject.has("frontImg")){// 如果识别反面图片，直接不计费
                    BigDecimal money = new BigDecimal(ocrPrice);
                    TNumber number = new TNumber();
                    //number.setPhone(requestDTO.getPhone());
                    User curUser = new User();
                    curUser.setId(user.getId());
                    curUser.setLoginName(user.getLoginName());
                    String orderNo = Utils.getOrderNo("J");
                    Map<String, Object> mapTM = new HashMap<String, Object>();
                    mapTM.put("us", curUser);
                    mapTM.put("channel", channel);
                    mapTM.put("number", number);
                    mapTM.put("operationType", OperationType.OCR_ANALYSE.getId());
                    mapTM.put("orderMoney", money);
                    mapTM.put("money", money);
                    mapTM.put("orderNo", orderNo);
                    mapTM.put("remark", "OCR识别");
                    numberService.takeMoney(mapTM);
                }
            }
            // 操作类型 1:OCR识别  2:身份核验  3:活体+人像比对
            idCheck.setOperationType("1");
            // OCR识别返回的结果
            idCheck.setReturnContent(result.replace("\n", ""));
            
            // 把OCR识别结果记录到表中
            this.insert(idCheck);
            
        } catch (Exception e) {
            //logger.error(e.getMessage(), e);
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \"系统异常，请联系客服\"}";
        }
        return result;
    }

    /**
     * 身份证查证
     * @param map 必须包含userId，userName（身份证号、身份证真实姓名）,needCharging内部调用字段，是否需要计费，值等于0时计费
     * @return  json字符串
     * @throws Exception
     */
    public String idCheck(String requestJson, HttpServletRequest request) {
        String result = "";
        
        try {
            JSONObject jsonObject = new JSONObject(requestJson);
            
            if(!jsonObject.has("userId") || !jsonObject.has("userName")){
                result = "{\"result\":\""+ApiResultCode.FAIL_102.getId()+"\", \"message\": \"参数异常,userId与userName参数不能为空\"}";
                return result;
            }
            
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            
            // needCharging不等于1时，计费
            String needCharging = "";
            if(jsonObject.has("needCharging")){
                needCharging = jsonObject.getString("needCharging");
            }
            
            // 根据OCR的价格，扣除代理商的费用(单位：元)
            String idCheckPrice = DicUtil.getMapDictionary("SYS_CONFIG").get("IDCHECK_PRICE");
            if(idCheckPrice==null || "".equals(idCheckPrice)){
                idCheckPrice = "0";
            }
            
            Integer channelId = 0;
            Channels channel = null;
            String deductFeeFlag = null;
            if(jsonObject.has("partner_account") && jsonObject.has("partner_pwd") && jsonObject.has("partner_secret_key")){
                String partner_account = jsonObject.getString("partner_account");
                String partner_pwd = jsonObject.getString("partner_pwd");
                String partner_secret_key = jsonObject.getString("partner_secret_key");
                IdCheckChannelRelation iccr = this.findIdCheckChannelRelation(partner_account, partner_pwd, partner_secret_key);
                if(iccr!=null){
                    channelId = iccr.getChannelId();
                    deductFeeFlag = iccr.getDeductFeeFlag();
                    // 只有值等于1的时候重复扣费
                    if(!"1".equals(deductFeeFlag)){
                        idCheckPrice = iccr.getIdcheckPrice();
                        if(idCheckPrice==null || "".equals(idCheckPrice)){
                            idCheckPrice = "0";
                        }
                    } else {
                        idCheckPrice = "0";
                    }
                } else {
                    result = "{\"result\":\""+ApiResultCode.FAIL_101.getId()+"\", \"message\": \"非法接入\"}";
                    return result;
                }
                channel = channelsService.findById(channelId);
                if (null==channel || channel.getChannelType()!=2) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_201.getId()+"\", \"message\": \"非法接入,渠道信息未录入系统\"}";
                    return result;
                }
            } else {
                if (null==user || user.getId()==null || user.getId()<=0) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_202.getId()+"\", \"message\": \"非网点登录，请重新登录\"}";
                    return result;
                }
                //以下是获取渠道信息
                channel = channelsService.findChannelByUserId(user.getId());
                if (null==channel || channel.getChannelType()!=2) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_202.getId()+"\", \"message\": \"非网点登录，请重新登录\"}";
                    return result;
                }
            }
            
            
            IDCheck idCheck = new IDCheck();
            if(!"1".equals(needCharging)){
                idCheck.setChannelId(channel.getId());
                // 获取直充账户余额
                ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 3);
                // 获取划拨账户余额
                ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 2);
                // 未处理的划拨账户订单金额
                Map<String, Object> para = new HashMap<String, Object>();
                para.put("channelId", channel.getId());
                para.put("accountType", 2);
                BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
                // 未处理的充值账户订单金额
                para.put("accountType", 3);
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
                BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
                allotBalance = allotBalance.subtract(freezeAllotMoney);
                BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
                directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
                
                // 判断充值账户和划拨账户的总额是否大于0，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
                if (directRechargeBalance.add(allotBalance).compareTo(new BigDecimal(idCheckPrice)) == -1) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_203.getId()+"\", \"message\": \"账户余额不足，无法进行身份核验\"}";
                    return result;
                }
            }
            
            // 服务端地址
            String url = SysConfig.getValue("CoolUrl");
            // 查证功能提供商  1.图睿 2.国政通，默认取图睿
            String provider = DicUtil.getMapDictionary("SYS_CONFIG").get("ID_CHECK_PROVIDER");
            // 判断调用图睿或者国政通的接口
            String idCheckS = null;
            // 操作类型 1:OCR识别  2:图睿身份核验  3:活体+人像比对 4:国政通身份核验
            String operationType = null;
            if ("2".equals(provider)) {
                idCheckS = SysConfig.getValue("IDCheckGZT");
                operationType = "4";
            } else {
                idCheckS = SysConfig.getValue("IDCheck");
                operationType = "2";
            }
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("url", url+idCheckS);
            param.put("userId", jsonObject.get("userId").toString());
            param.put("userName", jsonObject.get("userName").toString());
            
            // 是否调用了查证的服务 0:未调用 1:调用
            String callServiceFlag = "";
            // 根据身份证号查询数据库，如果存在就不在调用接口
            Map<String, Object> param1 = new HashMap<String, Object>();
            param1.put("idCode", jsonObject.get("userId").toString());
            param1.put("idName", jsonObject.get("userName").toString());
            param1.put("operationType", operationType);
            IDCheck hasIDcheck = this.findByIDCode(param1);
            if (hasIDcheck == null) {
                callServiceFlag = "1";
                result = InterfaceUtil.getInstance().httpPost(param);
            } else {
                callServiceFlag = "0";
                result = hasIDcheck.getReturnContent();
                
                idCheck.setDeductFeeFlag(deductFeeFlag);
            }
            logger.info(result);
            JSONObject json = new JSONObject(result);
            String resultMK = json.getString("result");
            String message = URLDecoder.decode(json.getString("message"), "UTF-8");
            idCheck.setResultCode(resultMK);
            idCheck.setMessage(message);
            if (/*"0".equals(resultMK) && */json.has("transaction_id")) {
                idCheck.setTransactionId(json.getString("transaction_id"));
            }
            idCheck.setIdCode(jsonObject.get("userId").toString());
            idCheck.setIdName(jsonObject.get("userName").toString());
            idCheck.setOperationType(operationType);
            idCheck.setCallServiceFlag(callServiceFlag);
            // 身份核验返回的结果
            idCheck.setReturnContent(result.replace("\n", ""));
            
            // 把OCR后身份核验请求结果记录到表中
            this.insert(idCheck);
            
            if(!"1".equals(needCharging)){
                BigDecimal money = new BigDecimal(idCheckPrice);
                TNumber number = new TNumber();
                //number.setPhone(requestDTO.getPhone());
                User curUser = new User();
                curUser.setId(user.getId());
                curUser.setLoginName(user.getLoginName());
                String orderNo = Utils.getOrderNo("K");
                Map<String, Object> mapTK = new HashMap<String, Object>();
                mapTK.put("us", curUser);
                mapTK.put("channel", channel);
                mapTK.put("number", number);
                mapTK.put("operationType", OperationType.OCR_ID_CHECK.getId());
                mapTK.put("orderMoney", money);
                mapTK.put("money", money);
                mapTK.put("orderNo", orderNo);
                mapTK.put("remark", "身份核验");
                numberService.takeMoney(mapTK);
            }
            
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \"系统异常，请联系客服\"}";
            return result;
        }
        return result;
    }
    
    /**
     * 活体+人像比对
     * @param requestDTO
     * @return
     * @throws Exception
     */
    @RequestMapping(value="faceCheck", method = RequestMethod.POST)
    public String faceCheck(String requestJson, HttpServletRequest request) {
        String result = "";
        
        try {
            JSONObject jsonObject = new JSONObject(requestJson);
            
            if(!jsonObject.has("baseImg") || !jsonObject.has("dataPackage")){
                result = "{\"result\":\""+ApiResultCode.FAIL_102.getId()+"\", \"message\": \"参数异常,baseImg与dataPackage参数不能为空\"}";
                return result;
            }
            
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute(Constant.SESSION_USER);
        
            // 根据酷商配制的数据字典的价格，扣除代理商的费用(单位：元)
            String faceCheckPrice = DicUtil.getMapDictionary("SYS_CONFIG").get("FACECHECK_PRICE");
            if(faceCheckPrice==null || "".equals(faceCheckPrice)){
                faceCheckPrice = "0";
            }
            
            Integer channelId=0;
            Channels channel = null;
            if(jsonObject.has("partner_account") && jsonObject.has("partner_pwd") && jsonObject.has("partner_secret_key")){
                String partner_account = jsonObject.getString("partner_account");
                String partner_pwd = jsonObject.getString("partner_pwd");
                String partner_secret_key = jsonObject.getString("partner_secret_key");
                IdCheckChannelRelation iccr = this.findIdCheckChannelRelation(partner_account, partner_pwd, partner_secret_key);
                if(iccr!=null){
                    channelId = iccr.getChannelId();
                    faceCheckPrice = iccr.getFaceCheckPrice();
                    if(faceCheckPrice==null || "".equals(faceCheckPrice)){
                        faceCheckPrice = "0";
                    }
                } else {
                    result = "{\"result\":\""+ApiResultCode.FAIL_101.getId()+"\", \"message\": \"非法接入\"}";
                    return result;
                }
                channel = channelsService.findById(channelId);
                if (null==channel || channel.getChannelType()!=2) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_201.getId()+"\", \"message\": \"非法接入,渠道信息未录入系统\"}";
                    return result;
                }
            } else {
                //以下是获取渠道信息
                channel = channelsService.findChannelByUserId(user.getId());
                if (null==channel || channel.getChannelType()!=2) {
                    result = "{\"result\":\""+ApiResultCode.FAIL_202.getId()+"\", \"message\": \"非网点登录，请重新登录\"}";
                    return result;
                }
            }
            
            IDCheck idCheck = new IDCheck();
            idCheck.setChannelId(channel.getId());
        
            // 获取直充账户余额
            ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 3);
            // 获取划拨账户余额
            ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 2);
            // 未处理的划拨账户订单金额
            Map<String, Object> para = new HashMap<String, Object>();
            para.put("channelId", channel.getId());
            para.put("accountType", 2);
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
            // 未处理的充值账户订单金额
            para.put("accountType", 3);
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
            
            BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
            allotBalance = allotBalance.subtract(freezeAllotMoney);
            BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
            directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
            
            // 判断充值账户和划拨账户的总额是否大于0，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
            if (directRechargeBalance.add(allotBalance).compareTo(new BigDecimal(faceCheckPrice)) == -1) {
                result = "{\"result\":\""+ApiResultCode.FAIL_203.getId()+"\", \"message\": \"账户余额不足，无法进行人像比对\"}";
                return result;
            }
            
            // 服务端地址
            String url = SysConfig.getValue("CoolUrl");
            String decryptCheck = SysConfig.getValue("faceCheck");
            String baseImg = jsonObject.getString("baseImg");//Base64Util.getBase64(imageURL+requestDTO.getBaseImg());
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("url", url+decryptCheck);
            param.put("baseImg", baseImg);
            // 证件照类型，1:证件照  2:证件照翻拍  3:类证件照  9:铁丝网水印的证件照   OCR返回的头像属于证件照翻拍2
            param.put("baseImgType", "2");
            // 活体检测收集的加密包
            param.put("dataPackage", jsonObject.getString("dataPackage"));
            
            result = InterfaceUtil.getInstance().httpPost(param);
            logger.info(result);
            JSONObject json = new JSONObject(result);
            String resultCode = json.getString("result");
            String message = URLDecoder.decode(json.getString("message"), "UTF-8");
            idCheck.setResultCode(resultCode);
            idCheck.setMessage(message);
            if ("0".equals(resultCode)) {
                // 对比结果, 0同一个人  1不是同一个人
                String verifyResult = json.getString("verify_result");
                // 对比相似值,取值0到100，值越大越相似
                String verifySimilarity = json.getString("verify_similarity");
                String transactionId = json.getString("transaction_id");
                if ("0".equals(verifyResult)) {
                    // 人像比对参考值，小于这个值，认为不是同一个人
                    String photoCheckValue = json.getString("photo_check_value");
                    if (Double.valueOf(verifySimilarity) < Double.valueOf(photoCheckValue)) {
                        message = "图像疑似不是同一个人，请核对后重新检测！";
                    }
                } else {
                    message = "图像疑似不是同一个人，请核对后重新检测！";
                }
                idCheck.setTransactionId(transactionId);
            }
            // 操作类型 1:OCR识别  2:身份核验  3:活体+人像比对
            idCheck.setOperationType("3");
            // OCR识别返回的结果
            idCheck.setReturnContent(result.replace("\n", ""));
            
            // 把活体+人像比对请求结果记录到表中
            this.insert(idCheck);
            
            BigDecimal money = new BigDecimal(faceCheckPrice);
            TNumber number = new TNumber();
            //number.setPhone(requestDTO.getPhone());
            User curUser = new User();
            curUser.setId(user.getId());
            curUser.setLoginName(user.getLoginName());
            String orderNo = Utils.getOrderNo("L");
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("us", curUser);
            map.put("channel", channel);
            map.put("number", number);
            map.put("operationType", OperationType.FACE_DECRYPT.getId());
            map.put("orderMoney", money);
            map.put("money", money);
            map.put("orderNo", orderNo);
            map.put("remark", "人像比对");
            numberService.takeMoney(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \"系统异常，请联系客服\"}";
        }
        return result;
    }
    
    public IdCheckChannelRelation findIdCheckChannelRelation(String partner_account, String partner_pwd, String partner_secret_key){
        return idCheckChannelRelationMapper.findIdCheckChannelRelation(partner_account, partner_pwd, partner_secret_key);
    }
    
}
