package com.agent.api.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 身份核验
 *
 */
public class IDCheck implements Serializable {

    private static final long serialVersionUID = 1466664487590619775L;
    private Integer id;
    // 渠道ID
    private Integer channelId;
    // 身份证号码
    private String idCode;
    // 身份证-姓名
    private String idName;
    // 业务交易流水号
    private String transactionId;
    // 业务类型 1:OCR 2:OCR后的身份核验 3:活体+人像比对
    private String operationType;
    // 是否调用了服务 0:未调用 1:调用，默认为1，仅查证接口使用
    private String callServiceFlag;
    //是否重复扣费(酷商扣取合作商费用标识)
    private String deductFeeFlag;
    // 返回标识 0表示成功，其余值表示失败
    private String resultCode;
    // 返回结果
    private String message;
    // 接口返回的值
    private String returnContent;
    // 操作时间
    private Date operationTime;
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getChannelId() {
        return channelId;
    }
    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }
    public String getIdCode() {
        return idCode;
    }
    public void setIdCode(String idCode) {
        this.idCode = idCode;
    }
    public String getIdName() {
        return idName;
    }
    public void setIdName(String idName) {
        this.idName = idName;
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public String getOperationType() {
        return operationType;
    }
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }
    public String getCallServiceFlag() {
        return callServiceFlag;
    }
    public void setCallServiceFlag(String callServiceFlag) {
        this.callServiceFlag = callServiceFlag;
    }
    public String getDeductFeeFlag() {
        return deductFeeFlag;
    }
    public void setDeductFeeFlag(String deductFeeFlag) {
        this.deductFeeFlag = deductFeeFlag;
    }
    public String getResultCode() {
        return resultCode;
    }
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getReturnContent() {
        return returnContent;
    }
    public void setReturnContent(String returnContent) {
        this.returnContent = returnContent;
    }
    public Date getOperationTime() {
        return operationTime;
    }
    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }
}
