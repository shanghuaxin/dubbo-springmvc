package com.agent.api;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InterfaceWorkOrderUtil {
    
    private static Logger logger = LoggerFactory.getLogger(InterfaceWorkOrderUtil.class);
    
    private static InterfaceWorkOrderUtil interfaceUtil = null;
    
    public static InterfaceWorkOrderUtil getInstance() {
        if (null == interfaceUtil) {
            interfaceUtil = new InterfaceWorkOrderUtil();
        }
        return interfaceUtil;
    }
    
    /**
     * 得到请求参数
     * 
     * @param request
     *            ：HttpServletRequest
     * @return ：请求的参数 json格式
     */
    public String getPostData(HttpServletRequest request) throws IOException {
        int nlen = request.getContentLength();

        StringBuffer buffer = new StringBuffer(4096);
        int count = 0;
        char[] bt = new char[4096];
        if (nlen > 0) {
            BufferedReader in = new BufferedReader(new InputStreamReader(request.getInputStream()));
            int rd = 0;
            while ((rd = in.read(bt)) > 0) {
                count += rd;
                buffer.append(new String(bt).substring(0, rd));
                if (count >= nlen) {
                    break;
                }
            }
            in.close();
        }
        return buffer.toString();
    }
    
    /**
     * RespToClient,调用此方法将结果返回给客户端 @ in response @ in szSpResContens @ return
     */
    public void respToClient(HttpServletRequest req, HttpServletResponse response, String returnContent, int resultCode) throws IOException {
        DataOutputStream output = null;
        try {
            /* 设置HTTP返回状态，正常为200 */
            response.setStatus(resultCode);
            /* 设置HTTP Content-type和Content-Length */
            response.setContentType(req.getContentType());
            response.setContentLength(returnContent.getBytes().length);

            /* 获取输出流和输出Http回应 */
            output = new DataOutputStream(new BufferedOutputStream(response.getOutputStream()));
            output.write(returnContent.getBytes());
        } catch (IOException ex) {
            throw ex;
        } finally {
            if (output != null) {
                close(output);
            }
            if (!response.isCommitted()) {
                try {
                    response.flushBuffer();
                } catch (IOException ex1) {
                    throw ex1;
                }
            }
        }
    }

    /**
     * 关闭流
     */
    boolean close(final OutputStream stream) {
        boolean success = true;
        if (stream != null) {
            try {
                stream.flush();
                stream.close();
            } catch (IOException e) {
                success = false;
            }
        }
        return success;
    }

    
    /**
     * 调用服务端，返回服务端的请求结果
     * @param postUrl 服务端地址
     * @param postData 入参
     * @param reqPro 请求属性
     * @return 出参
     */
    public String callInvoke(String postUrl, String postData, Map<String, String> reqPro) {
        String result = "";
        try {
            //发送POST请求
            URL url = new URL(postUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            for(String key : reqPro.keySet()){
                //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                //conn.setRequestProperty("Connection", "Keep-Alive");
                //...
                conn.setRequestProperty(key, reqPro.get(key));
            }
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Length", String.valueOf(postData.getBytes().length));
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
            out.write(postData);
            out.flush();
            out.close();

            //获取响应状态
//            if (conn.getResponseCode() != 0) {
//                logger.info("fail");
//                System.out.println("失败");
//                return "";
//            }
            //获取响应内容体
            String line;
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            while ((line = in.readLine()) != null) {
                result += line + "\n";
            }
            if (StringUtils.isNotEmpty(result) && result.contains("\n")) {
                result = result.replace("\n", "");
            }
            in.close();
        } catch (Exception e) {
            logger.error("=====调用接口失败(执行方法:callInvoke)====="+e.getMessage(), e);
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        return result;
    }
    
    /**
     * 调用服务端，返回服务端的请求结果
     * @param requestUrl 服务端地址
     * @return 出参
     */
    public String callInvokeGET(String requestUrl) {
        BufferedReader in = null;        
        StringBuilder result = new StringBuilder(); 
        try {
            //发送POST请求
            URL url = new URL(requestUrl);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            //Get请求不需要DoOutPut
            conn.setDoOutput(false);
            conn.setDoInput(true);
            //设置连接超时时间和读取超时时间
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            //连接服务器  
            conn.connect();  
            // 取得输入流，并使用Reader读取  
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            logger.error("=====调用接口失败(执行方法:callInvoke)====="+e.getMessage(), e);
            result = new StringBuilder("{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}");
        }
      //关闭输入流
        finally{
            try{
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        return result.toString();
    }
    
    public static void main(String[] args) {
        String backUrl = "http://192.168.12.62:9998/basic_service/revoke_support/v1?BJN2GP17D121WKnY5pvU3ZXSTuFIEwRvk5iiRVOYXTUySHI2";
        String json = "{\"mvnokey\":\"Z2XnSTq\",\"serial_number\":\"cOKD31n20140101101937816x93z92\",\"timestamp\":\"2018-02-07 10:19:37\""
                + ",\"service_type\":\"basic_service\",\"service_name\":\"revoke_support\""
                + ",\"api_name\":\"cu.vop.basic_service.revoke_support\",\"data\":{\"support_id\":\"cOKD31n20140101101937816x93z921111\",\"reason\":\"aaaa\"}}";
        Map<String, String> reqRes = new HashMap<String, String>();
        reqRes.put("Content-Type", "application/x-www-form-urlencoded");
        reqRes.put("Connection", "Keep-Alive");
        String result = InterfaceWorkOrderUtil.getInstance().callInvoke(backUrl, json, reqRes);
        System.out.println("result--->"+result);
    }
}
