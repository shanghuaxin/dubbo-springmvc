package com.agent.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.agent.common.enumeration.WorkOrderStatusType;
import com.agent.cs.dto.UnicomOrderFeedbackDTO;
import com.agent.cs.entity.WorkOrder;
import com.agent.cs.service.WorkOrderService;
import com.agent.order.common.util.JSONUtil;
import com.agent.util.DateUtil;

/**
 * 订购结果回执（酷商作为服务端）
 */
public class WorkOrderFeecbackServlet extends HttpServlet {

    private static final long serialVersionUID = -8391097026995586045L;
    
    private static Logger logger = LoggerFactory.getLogger(WorkOrderFeecbackServlet.class);
    
    public void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        logger.info("=====调用工单反馈接口 begin=====");
        String method = req.getMethod().trim();
        String returnContent = null;
        int resultCode = 200;
        try {
            if (method.compareTo("GET") == 0) {
                returnContent = handleGet(req, resp);
            } else if (method.compareTo("POST") == 0) {
                returnContent = handlePost(req, resp);
            } else {
                resultCode = 500;
                returnContent = "Unexpect HTTP method:" + method;
            }
        } catch (Exception e) {
            resultCode = 999;
            returnContent = e.getMessage();
        }

        // 返回结果给客户端
        InterfaceUtil.getInstance().respToClient(req, resp, returnContent, resultCode);
        logger.info("=====调用工单反馈接口 end=====");
    }
    
    /**
     * get请求
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    private String handleGet(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        return doBussiness(req, resp);
    }

    /**
     * post请求
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    private String handlePost(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        return doBussiness(req, resp);
    }

    /**
     * 业务处理
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    private String doBussiness(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String result = null;
        try {
            resp.setContentType("text/html;charset=UTF-8");
            req.setCharacterEncoding("UTF-8");
            // json格式的字符串
            String reqContent = InterfaceUtil.getInstance().getPostData(req);
            logger.info("=====调用工单反馈接口入参====="+reqContent);
            if (StringUtils.isEmpty(reqContent)) {
                result = "{\"data\":{\"status\": false, \"message\": \"参数为空\" }}";
                return result;
            }
            UnicomOrderFeedbackDTO unicomOrderFeedback = JSONUtil.jsonToObject(reqContent, UnicomOrderFeedbackDTO.class);
            // 查找工单信息
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("supportId", unicomOrderFeedback.getData().getSupport_id());
            ServletContext servletContext = this.getServletContext();
            WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(servletContext);
            WorkOrderService workOrderService1 = (WorkOrderService) context.getBean("workOrderService");
            List<WorkOrder> workOrderList = workOrderService1.list(map);
            if (null==workOrderList || workOrderList.size()==0) {
                result = "{\"data\":{\"status\": false, \"message\": \"工单不存在\" }}";
                return result;
            }
            WorkOrder workOrder = workOrderList.get(0);
            // 更新工单表状态为已回复
            WorkOrder wo = new WorkOrder();
            wo.setId(workOrder.getId());
            wo.setStatus(WorkOrderStatusType.REPLY.getId());
            wo.setFeedbackStatus(unicomOrderFeedback.getData().getStatus());
            wo.setFeedbackContent(unicomOrderFeedback.getData().getContent());
            wo.setFeedbackTime(DateUtil.getInstance().parseDate(unicomOrderFeedback.getData().getFeedback_time(), DateUtil.yyyyMMddHHmmss));
            wo.setFeedbackContactPhone(unicomOrderFeedback.getData().getPhone_number());
            wo.setFeedbackContactName(unicomOrderFeedback.getData().getContact());
            wo.setFeedbackRemark(unicomOrderFeedback.getData().getRemark());
            
            workOrderService1.update(wo);
            result = "{\"data\":{\"status\": true, \"message\": \"接收成功\" }}";
            
            logger.info("=====调用工单反馈接口出参====="+result);
        } catch (Exception e) {
            logger.error("=====调用工单反馈接口 失败(执行方法:doBussiness)====="+e.getMessage(), e);
            result = "{\"data\":{\"status\": false, \"message\": \"系统内部错误\" }}";
        }
        return result;
    }
}
