package com.agent.api;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.net.www.protocol.http.HttpURLConnection;

@SuppressWarnings("restriction")
public class OperatorFlowService {
    
    private static Logger logger = LoggerFactory.getLogger(OperatorFlowService.class);
    
    private static OperatorFlowService operatorFlowService = null;
    
    public static OperatorFlowService getInstance() {
        synchronized(OperatorFlowService.class){
            if (null == operatorFlowService) {
                operatorFlowService = new OperatorFlowService();
            }
        }
        return operatorFlowService;
    }
    
    /**
     * 订购流量(酷商--->运营商流量)
     * @param map 
     * @return
     */
    public String buyFlow(Map<String, Object> map) {
        logger.info("===调用接口：订购流量buy_flow begin");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = (String) map.get("coolUrl");
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口：订购流量buy_flow 失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口：订购流量buy_flow end===");
        return result;
    }
    
    /**
     * 订购结果回执（运营商流量--->酷商）
     * @param param
     * @return
     */
    public String flowOrderReceipt(Map<String, Object> map) {
        logger.info("===调用接口：订单结果回执flowOrderReceipt begin===");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            logger.info("===调用接口：订单结果回执flowOrderReceipt 入参--->" + json.toString());
            String url = (String) map.get("coolUrl");
            result = callInvoke(url, json.toString());
            logger.info("===调用接口：订单结果回执flowOrderReceipt 出参--->" + result);
        } catch (Exception e) {
            logger.info("===调用接口：订单结果回执flowOrderReceipt 失败===");
            logger.error(e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"msg\": \""+e.getMessage()+"\", \"code\":\"999\"}";
        }
        logger.info("===调用接口：订单结果回执flowOrderReceipt end===");
        return result;
    }
    
    /**
     * 交易订单查询(酷商--->运营商流量)
     * @param map 
     * @return
     */
    public String orderInfoQuery(Map<String, Object> map) {
        logger.info("===调用接口：交易订单查询order_info begin");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = (String) map.get("coolUrl");
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口：交易订单查询order_info 失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口：交易订单查询order_info end===");
        return result;
    }
    
    /**
     * 客户余额查询(酷商--->运营商流量)
     * @param map 
     * @return
     */
    public String userWalletQuery(Map<String, Object> map) {
        logger.info("===调用接口：客户余额查询user_wallet begin");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = (String) map.get("coolUrl");
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口：客户余额查询user_wallet 失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口：客户余额查询user_wallet end===");
        return result;
    }
    
    /**
     * 流量套餐查询(酷商--->运营商流量)
     * @param map 
     * @return
     */
    public String flowListQuery(Map<String, Object> map) {
        logger.info("===调用接口：流量套餐查询flow_list begin");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = (String) map.get("coolUrl");
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口：流量套餐查询flow_list 失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口：流量套餐查询flow_list end===");
        return result;
    }
    
    private String callInvoke(String postUrl, String postData) {
        String result = "";
        try {
            //发送POST请求
            URL url = new URL(postUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Length", String.valueOf(postData.getBytes().length));
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
            out.write(postData);
            out.flush();
            out.close();

            //获取响应状态
//            if (conn.getResponseCode() != 0) {
//                logger.info("fail");
//                System.out.println("失败");
//                return "";
//            }
            //获取响应内容体
            String line;
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            while ((line = in.readLine()) != null) {
                result += line + "\n";
            }
            in.close();
        } catch (Exception e) {
            logger.error("错误信息:"+e.getMessage(), e);
            System.out.println("错误信息:"+e.getMessage());
            result = "{\"msg\": \""+e.getMessage()+"\", \"code\":\"999\"}";
        }
        return result;
    }
}
