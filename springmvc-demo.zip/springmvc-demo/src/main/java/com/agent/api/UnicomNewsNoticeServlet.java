package com.agent.api;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.agent.cs.dto.UnicomNewsNoticeDTO;
import com.agent.cs.dto.UnicomNewsNoticeDataDTO;
import com.agent.cs.entity.UnicomNewsNotice;
import com.agent.cs.service.UnicomNewsNoticeService;
import com.agent.order.common.util.JSONUtil;
import com.agent.util.DateUtil;

/**
 * 联通消息通知（酷商作为服务端）
 */
public class UnicomNewsNoticeServlet extends HttpServlet {
    private static final long serialVersionUID = -1593326173314927977L;
    private static Logger logger = LoggerFactory.getLogger(UnicomNewsNoticeServlet.class);
    
    public void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        logger.info("=====调用联通消息通知接口 begin=====");
        String method = req.getMethod().trim();
        String returnContent = null;
        int resultCode = 200;
        try {
            if (method.compareTo("GET") == 0) {
                returnContent = handleGet(req, resp);
            } else if (method.compareTo("POST") == 0) {
                returnContent = handlePost(req, resp);
            } else {
                resultCode = 500;
                returnContent = "Unexpect HTTP method:" + method;
            }
        } catch (Exception e) {
            resultCode = 999;
            returnContent = e.getMessage();
        }

        // 返回结果给客户端
        InterfaceUtil.getInstance().respToClient(req, resp, returnContent, resultCode);
        logger.info("=====调用联通消息通知接口 end=====");
    }
    
    /**
     * get请求
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    private String handleGet(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        return doBussiness(req, resp);
    }

    /**
     * post请求
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    private String handlePost(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        return doBussiness(req, resp);
    }

    /**
     * 业务处理
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    private String doBussiness(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String result = null;
        try {
            resp.setContentType("text/html;charset=UTF-8");
            req.setCharacterEncoding("UTF-8");
            // json格式的字符串
            String reqContent = InterfaceUtil.getInstance().getPostData(req);
            logger.info("=====调用联通消息通知接口入参====="+reqContent);
            if (StringUtils.isEmpty(reqContent)) {
                result = "{\"data\":{\"status\": false, \"message\": \"参数为空\" }}";
                logger.error("调用联通消息通知接口错误：参数为空");
                return result;
            }
            UnicomNewsNoticeDTO unicomNewsNoticeDTO = JSONUtil.jsonToObject(reqContent, UnicomNewsNoticeDTO.class);
            ServletContext servletContext = this.getServletContext();
            WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(servletContext);
            UnicomNewsNoticeService unicomNewsNoticeService = (UnicomNewsNoticeService) context.getBean("unicomNewsNoticeService");
            
            UnicomNewsNoticeDataDTO dto = unicomNewsNoticeDTO.getData();
            UnicomNewsNotice u = new UnicomNewsNotice();
            u.setApiName(unicomNewsNoticeDTO.getApi_name());
            u.setTimestamp(DateUtil.getInstance().parseDate(unicomNewsNoticeDTO.getTimestamp(), DateUtil.yyyy_MM_dd_HH_mm_ss));
            u.setPushId(dto.getPush_id());
            u.setPushType(dto.getPush_type());
            u.setPushContent(dto.getPush_content());
            u.setPushTime(DateUtil.getInstance().parseDate(dto.getPush_time(), DateUtil.yyyy_MM_dd_HH_mm_ss));
            u.setPhoneNumber(dto.getPhone_number());
            u.setContact(dto.getContact());
            u.setRemark(dto.getRemark());
            unicomNewsNoticeService.saveNotice(u);
            result = "{\"data\":{\"status\": true }}";
            logger.info("=====调用联通消息通知接口出参====="+result);
        } catch (Exception e) {
            logger.error("=====调用联通消息通知接口 失败(执行方法:doBussiness)====="+e.getMessage(), e);
            result = "{\"data\":{\"status\": false }}";
        }
        return result;
    }
}
