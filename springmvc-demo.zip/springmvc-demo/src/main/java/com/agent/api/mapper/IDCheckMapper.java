package com.agent.api.mapper;

import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.api.entity.IDCheck;
import com.agent.common.BaseMapper;

@Repository
public interface IDCheckMapper extends BaseMapper<IDCheck, Integer> {
    // 根据id查找
    public IDCheck findById(Integer id);
    
    // 根据身份证号查找
    public IDCheck findByIDCode(Map<String, Object> param);
    
    // 添加
    public int insert(IDCheck idCheck);
}
