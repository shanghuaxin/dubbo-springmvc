package com.agent.api;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.net.www.protocol.http.HttpURLConnection;

@SuppressWarnings("restriction")
public class InterfaceUtil {
    
    private static Logger logger = LoggerFactory.getLogger(InterfaceUtil.class);
    
    private static InterfaceUtil interfaceUtil = null;
    
    public static InterfaceUtil getInstance() {
        synchronized(InterfaceUtil.class){
            if (null == interfaceUtil) {
                interfaceUtil = new InterfaceUtil();
            }
        }
        return interfaceUtil;
    }
    
    /**
     * 刷新数据字典
     * @param map
     * @return
     */
    public String dictionaryRefresh(Map<String, Object> map) {
        logger.info("===调用接口：刷新数据字典dictionaryRefresh begin===");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = (String) json.get("url");
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口：刷新数据字典dictionaryRefresh 失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口：刷新数据字典dictionaryRefresh end===");
        return result;
    }
    
    /**
     * 字典数据查询
     * @param map
     * @return
     */
    public String codeDictionaryQuery(Map<String, Object> map) {
        logger.info("===调用接口：字典数据查询codeDictionaryQuery begin");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = "http://127.0.0.1:8088/coolagent-api/services/codeDictionaryQuery";
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口：字典数据查询codeDictionaryQuery 失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"code\":\"999\", \"msg\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口：字典数据查询codeDictionaryQuery end===");
        return result;
    }
    
    /**
     * @param map
     * @return
     */
    public String httpPost(Map<String, Object> map) {
        logger.info("===调用接口： begin");
        String result = null;
        try {
            JSONObject json = new JSONObject(map);
            String url = (String) map.get("url");
            result = callInvoke(url, json.toString());
        } catch (Exception e) {
            logger.error("===调用接口失败==="+e.getMessage(), e);
            // 异常返回时，错误码定义为999
            result = "{\"result\":\"999\", \"message\": \""+e.getMessage()+"\"}";
        }
        logger.info("===调用接口end===");
        return result;
    }
    
    /**
     * RespToClient,调用此方法将结果返回给客户端 @ in response @ in szSpResContens @ return
     */
    public void respToClient(HttpServletRequest req, HttpServletResponse response, String returnContent, int resultCode) throws IOException {
        DataOutputStream output = null;
        try {
            /* 设置HTTP返回状态，正常为200 */
            response.setStatus(resultCode);
            /* 设置HTTP Content-type和Content-Length */
            response.setContentType(req.getContentType());
            response.setContentLength(returnContent.getBytes().length);

            /* 获取输出流和输出Http回应 */
            output = new DataOutputStream(new BufferedOutputStream(response.getOutputStream()));
            output.write(returnContent.getBytes());
        } catch (IOException ex) {
            throw ex;
        } finally {
            if (output != null) {
                close(output);
            }
            if (!response.isCommitted()) {
                try {
                    response.flushBuffer();
                } catch (IOException ex1) {
                    throw ex1;
                }
            }
        }
    }
    
    /**
     * 关闭流
     */
    boolean close(final OutputStream stream) {
        boolean success = true;
        if (stream != null) {
            try {
                stream.flush();
                stream.close();
            } catch (IOException e) {
                success = false;
            }
        }
        return success;
    }

    public String callInvoke(String postUrl, String postData) {
        String result = "";
        try {
            //发送POST请求
            URL url = new URL(postUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Length", String.valueOf(postData.getBytes().length));
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
            out.write(postData);
            out.flush();
            out.close();

            //获取响应状态
//            if (conn.getResponseCode() != 0) {
//                logger.info("fail");
//                System.out.println("失败");
//                return "";
//            }
            //获取响应内容体
            String line;
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            while ((line = in.readLine()) != null) {
                result += line + "\n";
            }
            in.close();
        } catch (Exception e) {
            logger.error("错误信息:"+e.getMessage(), e);
            System.out.println("错误信息:"+e.getMessage());
            result = "{\"message\": \""+e.getMessage()+"\", \"result\":\"999\"}";
        }
        return result;
    }


    public String callInvokeOnlie(String postUrl, String postData) {
        String result = "";
        try {
            //发送POST请求
            URL url = new URL(postUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Length", String.valueOf(postData.getBytes().length));
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
            out.write(postData);
            out.flush();
            out.close();

            //获取响应状态
//            if (conn.getResponseCode() != 0) {
//                logger.info("fail");
//                System.out.println("失败");
//                return "";
//            }
            //获取响应内容体
            String line;
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            while ((line = in.readLine()) != null) {
                result += line + "\n";
            }
            in.close();
        } catch (Exception e) {
            logger.error("错误信息:"+e.getMessage(), e);
            System.out.println("错误信息:"+e.getMessage());
            result = "{\"errorMessage\": \""+e.getMessage()+"\", \"errorCode\":\"999\", \"status\":\"false\"}";
        }
        return result;
    }
    /**
     * 得到请求参数
     * 
     * @param request
     *            ：HttpServletRequest
     * @return ：请求的参数 json格式
     */
    public String getPostData(HttpServletRequest request) throws IOException {
        int nlen = request.getContentLength();

        StringBuffer buffer = new StringBuffer(4096);
        int count = 0;
        char[] bt = new char[4096];
        if (nlen > 0) {
            BufferedReader in = new BufferedReader(new InputStreamReader(request.getInputStream()));
            int rd = 0;
            while ((rd = in.read(bt)) > 0) {
                count += rd;
                buffer.append(new String(bt).substring(0, rd));
                if (count >= nlen) {
                    break;
                }
            }
            in.close();
        }
        return buffer.toString();
    }
}
