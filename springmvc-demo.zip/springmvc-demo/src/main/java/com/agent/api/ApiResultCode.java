package com.agent.api;

/**
 */
public enum ApiResultCode {
    SUCCESS_000(0,"成功"),
    FAIL_101(101,"非法接入"),
    FAIL_102(102,"参数异常"),
    FAIL_201(201,"系统无相关渠道信息"),
    FAIL_202(202,"非网点渠道信息"),
    FAIL_203(203,"账户余额不足"),
    
    FAIL_999(999,"系统异常"),
    ;
    
    // 成员变量 
    private Integer id;
    private String name;
    // 构造方法 
    private ApiResultCode(Integer id,String name) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (ApiResultCode ot : ApiResultCode.values()) {
            if (ot.getId() == id) {
                return ot.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public static void main(String[] args) {
        System.out.println(ApiResultCode.FAIL_201.getId());
    }
}
