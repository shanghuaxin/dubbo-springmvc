package com.agent.api.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.api.ApiResultCode;
import com.agent.api.InterfaceUtil;
import com.agent.api.service.IDCheckService;
import com.agent.api.service.IdCheckChannelRelationService;

@Controller
@RequestMapping(value="api")
public class IDCheckController {
    private static Logger logger = LoggerFactory.getLogger(IDCheckController.class);
    
    @Autowired
    private IdCheckChannelRelationService idCheckService;
    @Autowired
    private IDCheckService service;
    private String result = null;
    
    /**
     * ocr识别
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="ocr", method=RequestMethod.POST)
    public String ocr(HttpServletRequest request, HttpServletResponse response) {
        try {
            String requestJson = InterfaceUtil.getInstance().getPostData(request);
            if(checkSecretKey(requestJson)){
                result = idCheckService.ocrAnalyse(requestJson, request);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \""+e.getMessage()+"\"}";
        }
        return result;
    }
    
    /**
     * 身份证查证
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="idcheck", method=RequestMethod.POST)
    public String idcheck(HttpServletRequest request, HttpServletResponse response) {
        try {
            String requestJson = InterfaceUtil.getInstance().getPostData(request);
            if(checkSecretKey(requestJson)){
                result = idCheckService.idCheck(requestJson, request);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \""+e.getMessage()+"\"}";
        }
        return result;
    }
    
    
    private static ExecutorService threadPool = Executors.newFixedThreadPool(5);
    /**
     * 身份证查证---上传到别处
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="idcheck-upload", method=RequestMethod.POST)
    @ResponseBody
    public String idcheckUpload() {
        try {
            for(int i=1;i<=5;i++) {
                if(!new File("F:/"+i+".txt").exists()) {
                    continue;
                }
                
                final int fileIndex=i;
                threadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("F:/"+fileIndex+".txt")));
                            String data = null;
                            while((data = br.readLine())!=null) {
                                System.out.println(data);
                                String []idinfos = data.split(",");
                                if(data!=null && !"".equals(data.trim())){
                                    File file = new File("F:/idcheckinfo"+fileIndex+".txt");
                                    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                                            new FileOutputStream(file, true)));
                                    
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("needCharging", "1");//表示不计费
                                    jsonObject.put("userId", idinfos[3]);
                                    jsonObject.put("userName", idinfos[2]);
                                    
                                    String requestJson = jsonObject.toString();
                                    
                                    result = service.idCheck(requestJson, null);
                                    JSONObject jsonResult = new JSONObject(result);
                                    String code = jsonResult.getString("result");//0表示一致，1表示不一致
                                    code = "0".equals(code)?"一致":"不一致";
                                    String str = data+","+code + "\r\n";
                                    out.write(str);
                                    try {
                                        out.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                            br.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                
            }
            
            
        } catch (Exception e) {
            logger.error(e.getMessage());
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \""+e.getMessage()+"\"}";
        }
        return result;
    }
    
    /**
     * 活体+人脸
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value="facecheck", method=RequestMethod.POST)
    public String face(HttpServletRequest request, HttpServletResponse response) {
        try {
            String requestJson = InterfaceUtil.getInstance().getPostData(request);
            if(checkSecretKey(requestJson)){
                result = idCheckService.faceCheck(requestJson, request);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \""+e.getMessage()+"\"}";
        }
        return result;
    }
    
    /**
     * 验证密钥参数是否传递
     * @param requestJson
     * @return
     * @throws Exception
     */
    private boolean checkSecretKey(String requestJson) throws Exception{
        JSONObject jsonObject = new JSONObject(requestJson);
        if(jsonObject.has("partner_account") && jsonObject.has("partner_pwd") && jsonObject.has("partner_secret_key")){
            return true;
        } else {
            result = "{\"result\":\""+ApiResultCode.FAIL_999.getId()+"\", \"message\": \"非法接入\"}";
            return false;
        }
    }
}