package com.agent.api.entity;

import java.io.Serializable;

/**
 * OCR身份核验第三方接口提供表
 */
public class IdCheckChannelRelation implements Serializable {

    private static final long serialVersionUID = 1466664487590619775L;
    private Integer id;
    // 渠道ID
    private Integer channelId;
    private String channelName;
    private String partnerAcccount;
    private String partnerPwd;
    private String partnerSecretKey;
    private String ocrPrice;
    private String idcheckPrice;
    private String faceCheckPrice;
    private String deductFeeFlag;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getChannelId() {
        return channelId;
    }
    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }
    public String getChannelName() {
        return channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getPartnerAcccount() {
        return partnerAcccount;
    }
    public void setPartnerAcccount(String partnerAcccount) {
        this.partnerAcccount = partnerAcccount;
    }
    public String getPartnerPwd() {
        return partnerPwd;
    }
    public void setPartnerPwd(String partnerPwd) {
        this.partnerPwd = partnerPwd;
    }
    public String getPartnerSecretKey() {
        return partnerSecretKey;
    }
    public void setPartnerSecretKey(String partnerSecretKey) {
        this.partnerSecretKey = partnerSecretKey;
    }
    public String getOcrPrice() {
        return ocrPrice;
    }
    public void setOcrPrice(String ocrPrice) {
        this.ocrPrice = ocrPrice;
    }
    public String getIdcheckPrice() {
        return idcheckPrice;
    }
    public void setIdcheckPrice(String idcheckPrice) {
        this.idcheckPrice = idcheckPrice;
    }
    public String getFaceCheckPrice() {
        return faceCheckPrice;
    }
    public void setFaceCheckPrice(String faceCheckPrice) {
        this.faceCheckPrice = faceCheckPrice;
    }
    public String getDeductFeeFlag() {
        return deductFeeFlag;
    }
    public void setDeductFeeFlag(String deductFeeFlag) {
        this.deductFeeFlag = deductFeeFlag;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    
}
