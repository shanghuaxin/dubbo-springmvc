package com.agent.api.mapper;

import org.springframework.stereotype.Repository;

import com.agent.api.entity.IdCheckChannelRelation;
import com.agent.common.BaseMapper;

@Repository
public interface IdCheckChannelRelationMapper extends BaseMapper<IdCheckChannelRelation, Integer> {
    
    /**
     * @param partner_account, 
     * partner_pwd, 
     * partner_secret_key
     * @return
     */
    public IdCheckChannelRelation findIdCheckChannelRelation(String partner_account, String partner_pwd, String partner_secret_key);
    
}
