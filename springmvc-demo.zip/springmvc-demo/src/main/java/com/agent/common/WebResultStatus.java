package com.agent.common;

public class WebResultStatus {
    public static final int SUCCESS = 1;
    public static final int BUSINESS_ERROR = 0;
    public static final int EXCEPTION = -1;
}
