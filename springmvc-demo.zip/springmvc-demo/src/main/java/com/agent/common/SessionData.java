package com.agent.common;

import com.agent.system.entity.User;

import javax.servlet.http.HttpServletRequest;

/**
 * 获取session 信息
 */
public class SessionData {
    private static SessionData sessionData;
    public static SessionData getInstance(){
        //if(dateUtil==null){
        synchronized(SessionData.class){
            if(sessionData==null){
                sessionData=new SessionData();
            }
        }
        //}
        return sessionData;
    }

    /**
     * 获取用户信息
     * @param request
     * @return
     * @throws Exception
     */
    public User getUser(HttpServletRequest request) throws Exception{
        User us = (User)request.getSession().getAttribute("user");
        if(us != null && 0!=us.getId()){
            return us;
        }else{
            throw new Exception("您的登录已超时，请重新登录！");
        }
    }
}
