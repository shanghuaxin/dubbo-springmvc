package com.agent.common;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.agent.business.dto.SubsDTO;
import com.agent.common.enumeration.BossPhoneStatus;
import com.agent.common.enumeration.NumberStatus;
import com.agent.order.common.util.Utils;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;

/**
 * 通用工具类
 * @author FengLu
 *
 */
public class CommonUtil {
    
    private static Logger logger = LoggerFactory.getLogger(CommonUtil.class);
    private static CommonUtil commonUtil;
    /**
     * 获取工具类实例
     * @return
     */
    public static CommonUtil getInstance() {
        if (null == commonUtil) {
            commonUtil = new CommonUtil();
        }
        return commonUtil;
    }
    
    /**
     * 获取url绝对路径
     * @param request
     * @param path 目标相对路径
     * @return
     */
    public String getAbsoluteUrl(HttpServletRequest request, String path) {
        // 请求协议 http 或 https
        String url;
        try {
            url = request.getScheme()+"://";
            // 请求服务器 (地址+端口)
            url += request.getHeader("host");
            // 工程名
            url += request.getContextPath();
            url += path;
        } catch (Exception e) {
            logger.error("获取url绝对路径异常："+e.getMessage(), e);
            return path;
        }
        return url;
    }

    
    /**
     * 当前用户是否可以办理业务，判断是否测试中
     * @return
     */
    public Boolean isBusiness(String phone) {
        String onlineTest = DicUtil.getMapDictionary("ONLINE_CONFIG").get("ONLINE_TEST");
        if("true".equals(onlineTest)){
            Map<String, String> testNameMap =DicUtil.getMapDictionary("PHONE_LIST");
            if(null != testNameMap.get(phone)){
                return true;
            }else{
                return false;
            }
        }else{
            return true;
        }
    }
    
    /**
     * 获取测试中测试金额
     * @return
     */
    public BigDecimal getMoney(BigDecimal orderMoney) {
        String onlineTest = DicUtil.getMapDictionary("ONLINE_CONFIG").get("ONLINE_TEST");
        if("true".equals(onlineTest)){
            String checkMoney = DicUtil.getMapDictionary("ONLINE_CONFIG").get("CHECK_MONEY");
            if(!Utils.isEmptyString(checkMoney) && "0".equals(checkMoney)){
                return new BigDecimal(DicUtil.getMapDictionary("ONLINE_CONFIG").get("TEST_MONEY"));
            }else{
                return orderMoney;
            }
        }else{
            return orderMoney;
        }
    }
    
    //获取订购业务操作名称
    public Map<String, Map<String, String>> optionType(){
        /* FLOW_ORDER("流量订购", "1"),
        INCONING_CALL("来电提醒", "2"),
        INCONING_SHOW("来电显示", "3"),
        CALL_FORWARDING("无条件呼叫转移", "4"),
        RINGING("炫铃服务", "5"),
        VOICE_CALL("语音呼入", "6"),
        INTERNET_FUNCTION("上网功能", "7"),
        SMS_FUNCTION("短信功能", "8"),
        REALNAME("实名补录", "9"),
        DUPLICATE_SIM("补换卡", "10"),
        LOST_OR_RESTORE("挂失解挂", "11"),
        BLOCK_OR_REACT("停机保号停复机", "12"),
        NUMBER_CANCEL_APPLY("销户申请", "13")
        /操作类型：0-订购，1-取消，2-变更
        */
        
        Map<String, Map<String, String>> optionType = new HashMap<>();
        optionType.put("0", stApplyMap());//开户
        optionType.put("1", stMap());
        optionType.put("2", stMap());
        optionType.put("3", stMap());
        optionType.put("4", stMap());
        optionType.put("5", stMap());
        optionType.put("6", stMap());
        optionType.put("7", stMap());
        optionType.put("8", stMap());
        optionType.put("9", stApplyMap());
        optionType.put("10", stApplyMap());
        optionType.put("11", stApplyMap());
        optionType.put("12", stApplyMap());
        optionType.put("13", stApplyMap());
        optionType.put("14", stMap());
        optionType.put("15", stMap());
        optionType.put("16", stMap());
        optionType.put("17", stMap());
        optionType.put("18", stMap());
        return optionType;
    }
    
    public Map<String, String> stMap(){
        Map<String, String> stMap = new HashMap<>();
        stMap.put("0", "订购");
        stMap.put("1", "退订");
        stMap.put("2", "变更");
        return stMap;
    }
    
    public Map<String, String> stApplyMap(){
        Map<String, String> stMap = new HashMap<>();
        stMap.put("0", "申请");
        stMap.put("1", "申请");
        return stMap;
    }
    
    /**
     * 金额按天折算
     * @param m
     * @return
     * @throws Exception
     */
    public BigDecimal qryServMoney(BigDecimal m) throws Exception{
        int lastDay = DateUtil.getInstance().lastDay();
        int nday = DateUtil.getInstance().day();
        BigDecimal servMoney = new BigDecimal(0);
        //每天价格
        BigDecimal c = m.divide(new BigDecimal(lastDay), 2, BigDecimal.ROUND_HALF_UP);
        if(lastDay == nday){
            servMoney = c;
        }else{
            BigDecimal dayNum = new BigDecimal(lastDay-nday+1);//剩余天数
            BigDecimal lc = c.multiply(dayNum);//剩余天数*每天金额
            servMoney = lc;
        }
        return servMoney;
    }
    
    /**
     * 
     * @param servType  业务类型 0 套餐  ,1 来电提醒，2 来电显示 ,3 app语音业务 ,4流量业务 ,5组合业务,6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包
     * @param optType   操作：0-订购，1-退订，2-变更
     * @param network   网络：1-移动，2-联通，3-电信
     * @return 1-实时生效， 2-次月生效，3-次日生效
     */
    public String valildTypeCode(String servType,String optType,String network){
        if("1".equals(network)){
            if("0".equals(servType)){
                return commonValild(optType);
            }else if("1".equals(servType)){
                return commonValild(optType);
            }else if("2".equals(servType)){
                return commonValild(optType);
            }else if("4".equals(servType)){
                return commonValild(optType);
            }
        }else{
            if("0".equals(servType)){
                return commonValild(optType);
            }else if("1".equals(servType)){
                return "1";//联通来显，漏电提醒 的订购和退订都是实时生效
            }else if("2".equals(servType)){
                return "1";//联通来显，漏电提醒 的订购和退订都是实时生效
            }else if("4".equals(servType)){
                if(optType.equals("0")){
                    return "2";
                }else if(optType.equals("1")){
                    return "2";
                }else{
                    return "2";
                }
            }else if("6".equals(servType)){
                //叠加包只能订购
                return "1";
            }else if("7".equals(servType)){
                if(optType.equals("0")){
                    return "2";
                }else if(optType.equals("1")){
                    return "2";
                }else{
                    return "2";
                }
            }else if("8".equals(servType)){
                //普通流量日包只能订购
                return "1";
            }else if("9".equals(servType)){
                if(optType.equals("0")){
                    return "1";
                }else if(optType.equals("1")){
                    return "3";
                }else{
                    return "3";
                }
            }
        }
        return "";
    }
    //通用生效类型，订购-实时生效，退订/变更次月生效
    private String commonValild(String optType){
        if(optType.equals("0")){
            return "1";
        }else if(optType.equals("1")){
            return "2";
        }else{
            return "2";
        }
    }
    
    /**
     * 
     * @param servType  业务类型 0 套餐  ,1 来电提醒，2 来电显示 ,3 app语音业务 ,4流量业务 ,5组合业务,6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包
     * @return 收费模式：1-一次性收费，2，按月收费，3-实时收费,4-按天收费
     */
    public String feeStyleCode(String servType){
        if("0".equals(servType)){
           return "2";
        }else if("1".equals(servType)){
            return "2";
        }else if("2".equals(servType)){
            return "2";
        }else if("4".equals(servType)){
            return "2";
        }else if("6".equals(servType)){
            return "3";
        }else if("7".equals(servType)){
            return "2";
        }else if("8".equals(servType)){
            return "4";
        }else if("9".equals(servType)){
            return "4";
        }
        return "";
    }
    
    //业务类型套餐表 0-,套餐   1 来电提醒，2 来电显示 ,3 语音业务 ,4流量业务 ,5组合业务，6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包，14-套餐变更
    //业务订购记录表类型 
    //移动   业务类型：1-强制停机，2-强制复机，3-来电提醒/来电显示，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理，8-开户，14-套餐变更
    //联通   业务类型：1-强制停机，2-强制复机，3-来电提醒，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理，8-开户，9-来电显示，
    //10-叠加月包，11-语音包，12-普通日包，13-自动续订日包，14-套餐变更
    public final static Map<String, String> servTypeMapMobile = new HashMap<>();//移动：业务类型  对应 订购业务表 类型
    static {
        servTypeMapMobile.put("1", "3");
        servTypeMapMobile.put("2", "3");
        servTypeMapMobile.put("4", "6");
        servTypeMapMobile.put("6", "10");
        servTypeMapMobile.put("7", "11");
        servTypeMapMobile.put("8", "12");
        servTypeMapMobile.put("9", "13");
        servTypeMapMobile.put("0", "14");
    }
    public final static Map<String, String> servTypeMapUnicom = new HashMap<>();//联通：业务类型  对应 订购业务表 类型
    static {
        servTypeMapUnicom.put("1", "3");
        servTypeMapUnicom.put("2", "9");
        servTypeMapUnicom.put("4", "6");
        servTypeMapUnicom.put("6", "10");
        servTypeMapUnicom.put("7", "11");
        servTypeMapUnicom.put("8", "12");
        servTypeMapUnicom.put("9", "13");
        servTypeMapUnicom.put("0", "14");
    }
    //1-流量订购 ，2-来电提醒 ，3-来电显示，14-套餐变更，15-叠加包，16-语音包，17-普通日包，18-自动续订日包
    public final static Map<String, String> servTypeMapBiz = new HashMap<>();//业务类型  对应 biz 表业务类型
    static {
        servTypeMapBiz.put("1", "2");
        servTypeMapBiz.put("2", "3");
        servTypeMapBiz.put("4", "1");
        servTypeMapBiz.put("6", "15");
        servTypeMapBiz.put("7", "16");
        servTypeMapBiz.put("8", "17");
        servTypeMapBiz.put("9", "18");
        servTypeMapBiz.put("0", "14");
    }
    //1-复机，2-流量包，3，融合流量包，4-来电显示，5-来电提醒，6-开户，7-叠加流量包，8-语音包，9-普通日包，10-自动续订日包
    public final static Map<String, String> servTypeMapOrder = new HashMap<>();//业务类型  对应 订购业务表排序
    static {
        servTypeMapOrder.put("1", "5");
        servTypeMapOrder.put("2", "4");
        servTypeMapOrder.put("4", "2");
        servTypeMapOrder.put("6", "7");
        servTypeMapOrder.put("7", "8");
        servTypeMapOrder.put("8", "9");
        servTypeMapOrder.put("9", "10");
        servTypeMapOrder.put("0", "11");
    }
    /*
     * 开户状态Map
    US01("US01", "待分配"),
    US02("US02", "待开户"),
    US03("US03", "开户待确认"),
    US10("US10", "已开户"),
    US20("US20", "已销户"),
    US21("US21", "强制单停"),
    US30("US30", "挂失停机"),
    US31("US31", "停机保号"),
    US33("US33", "强制双停"),
    US34("US34", "欠费停机"),
    US35("US35", "单停"),*/
    public final static Map<String, String> numberStatusOpen = new HashMap<>();//业务类型  对应 订购业务表排序
    static {
        numberStatusOpen.put(NumberStatus.US03.getCode(), NumberStatus.US03.getName());
        numberStatusOpen.put(NumberStatus.US10.getCode(), NumberStatus.US10.getName());
        numberStatusOpen.put(NumberStatus.US20.getCode(), NumberStatus.US20.getName());
        numberStatusOpen.put(NumberStatus.US21.getCode(), NumberStatus.US21.getName());
        numberStatusOpen.put(NumberStatus.US30.getCode(), NumberStatus.US30.getName());
        numberStatusOpen.put(NumberStatus.US31.getCode(), NumberStatus.US31.getName());
        numberStatusOpen.put(NumberStatus.US33.getCode(), NumberStatus.US33.getName());
        numberStatusOpen.put(NumberStatus.US34.getCode(), NumberStatus.US34.getName());
        numberStatusOpen.put(NumberStatus.US35.getCode(), NumberStatus.US35.getName());
    }
    /**
     * 获取用户状态
     */
    public String getProdStateStr(String prodState,String blockReason) {
        String statusStr = null;
        if (SubsDTO.SUBS_STATE_A.equals(prodState)) {
            statusStr = "正常使用";
        } else if (SubsDTO.SUBS_STATE_B.equals(prodState)) {
            statusStr = "销户";
        } else if (SubsDTO.SUBS_STATE_E.equals(prodState)) {
            /*if (BossPhoneStatus.ARREARS_STOP_ALONE.getValue().equals(blockReason)) {
                statusStr = "欠费单停";
            } else if (BossPhoneStatus.ARREARS_STOP_ALL.getValue().equals(blockReason)) {
                statusStr = "欠费双停";
            } else if (BossPhoneStatus.PRE_CANCELLATION.getValue().equals(blockReason)) {
                statusStr = "预销户";
            } else if (BossPhoneStatus.FORCED_STOP.getValue().equals(blockReason)) {
                statusStr = "违规停机";
            } else if (BossPhoneStatus.STOP_PAUL.getValue().equals(blockReason)) {
                statusStr = "停机保号";
            } else if (BossPhoneStatus.STOP_PAUL_ALONE.getValue().equals(blockReason)) {
                statusStr = "停机保号欠费单停";
            } else if (BossPhoneStatus.STOP_PAUL_ALL.getValue().equals(blockReason)) {
                statusStr = "停机保号欠费双停";
            } else if (BossPhoneStatus.REPORT_LOSS.getValue().equals(blockReason)) {
                statusStr = "挂失";
            } else if (BossPhoneStatus.REPORT_LOSS_ALONE.getValue().equals(blockReason)) {
                statusStr = "挂失欠费单停";
            } else if (BossPhoneStatus.REPORT_LOSS_ALL.getValue().equals(blockReason)) {
                statusStr = "挂失欠费双停";
            }else if (BossPhoneStatus.STOP_LOSS_ALL.getValue().equals(blockReason)) {
                statusStr = "停机保号违规双停";
            }else if (BossPhoneStatus.RECHARGE_STOP_ALL.getValue().equals(blockReason)) {
                statusStr = "欠费双停";
            }*/
            statusStr = BossPhoneStatus.getName(blockReason);
        } else if (SubsDTO.SUBS_STATE_G.equals(prodState)) {
            statusStr = "未激活";
        } else {
            statusStr = BossPhoneStatus.getName(prodState);
        }
        return statusStr;
    }
    
    //业务类型:0 套餐  ,1 来电提醒，2 来电显示 ,3 app语音业务 ,4流量业务 ,5组合业务,6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包
    public final static Map<String, String> servTypeNameMap = new HashMap<>();//套餐产品  业务类型 名称对应map
    static {
        servTypeNameMap.put("0", "套餐");
        servTypeNameMap.put("1", "来电提醒");
        servTypeNameMap.put("2","来电显示");
        servTypeNameMap.put("3", "app语音");
        servTypeNameMap.put("4", "基础流量包");
        servTypeNameMap.put("5", "融合包");
        servTypeNameMap.put("6", "叠加包");
        servTypeNameMap.put("7", "基础语音包");
        servTypeNameMap.put("8", "普通流量日包");
        servTypeNameMap.put("9", "自动续订流量日包");
    }
}
