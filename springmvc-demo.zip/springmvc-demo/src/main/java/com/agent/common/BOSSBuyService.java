package com.agent.common;

import java.util.Date;

import com.agent.util.DicUtil;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.businesslog.entity.InterfaceData;
import com.agent.businesslog.service.InterfaceDataService;
import com.agent.system.entity.User;
import com.agent.util.SysConfig;
import com.agent.util.XMLUtil;

import zsmart.ztesoft.com.xsd.*;

@Service
public class BOSSBuyService {
    private static Logger logger = (Logger) LoggerFactory.getLogger(BOSSBuyService.class);

    private static final String SUCCESS = "0";
    
    @Autowired
    private InterfaceDataService interfaceDataService;

    public RestStatus queryUserProfile4Basic(TQueryUserProfileRequestBO bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "信息查询BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("QueryUserProfile4Basic");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TQueryUserProfile4BaseBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("QueryUserProfile4Basic", bo);
                resp = (TQueryUserProfile4BaseBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TQueryUserProfile4BaseBOResponse();
                resp.setMSISDN(bo.getMSISDN());
                resp.setState("A");
                resp.setCertNbr("429005199201033060");
                resp.setCustName("张三");
                //resp.setResultCode("0000");
                resp.setBal("150000");
                resp.setSubsPlanCode("xcool201");
                resp.setSubsPlanName("酷2");
                interfaceData.setResponseContent("没有调用接口");
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            String errorCode = e.getMessage().trim();
            boolean iscode = false;
            for(String code:DicUtil.getKeyNameMap("BOSS_ERROR_CODE").keySet()){
                if(errorCode.indexOf(code) > -1 && !iscode){
                    res.setErrorMessage(DicUtil.getKeyNameMap("BOSS_ERROR_CODE").get(code));
                    iscode = true;
                }
            }
           if(!iscode){
                res.setErrorMessage("查询号码信息失败！");
            }
            res.setStatus(Boolean.FALSE);
            logger.error("号码信息查询接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("号码信息查询接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "信息查询BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }

    /**
     * 号码来电显示，提醒开关BOSS接口调用
     * 
     * @param callbo
     * @return
     */
    public RestStatus setIncomingCallService(TSetIncomingCallServiceBO callbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + callbo.getMSISDN() + "来电显示，提醒开关BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(callbo);
            interfaceData.setMsisdn(callbo.getMSISDN());
            interfaceData.setInterfaceName("SetIncomingCallService");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TSetIncomingCallServiceBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("SetIncomingCallService", callbo);
                resp = (TSetIncomingCallServiceBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TSetIncomingCallServiceBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getOpraDesc());
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("号码来电显示，提醒开关BOSS接口调用接口错误：phone=" + callbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("号码来电显示，提醒开关BOSS接口调用接口错误：phone=" + callbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + callbo.getMSISDN() + "来电显示，提醒开关BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }

    /**
     * 流量包
     * 
     * @param planbo
     * @return
     */
    public RestStatus dataPlanService(TDataPlanServiceBO planbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + planbo.getMSISDN() + "流量包订购BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(planbo);
            interfaceData.setMsisdn(planbo.getMSISDN());
            interfaceData.setInterfaceName("DataPlanService");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TDataPlanServiceBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("DataPlanService", planbo);
                resp = (TDataPlanServiceBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TDataPlanServiceBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getOpraDesc());
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("流量包订购接口调用接口错误：phone=" + planbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("流量包订购接口调用接口错误：phone=" + planbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + planbo.getMSISDN() + "流量包订购BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }

    /**
     * 融合流量包
     * 
     * @param uplanbo
     * @return
     */
    public RestStatus unificationDataPlanService(TUnificationDataPlanServiceBO uplanbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + uplanbo.getMSISDN() + "融合流量包订购BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(uplanbo);
            interfaceData.setMsisdn(uplanbo.getMSISDN());
            interfaceData.setInterfaceName("UnificationDataPlanService");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TUnificationDataPlanServiceBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("UnificationDataPlanService", uplanbo);
                resp = (TUnificationDataPlanServiceBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TUnificationDataPlanServiceBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getOpraDesc());
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("融合流量包订购接口调用接口错误：phone=" + uplanbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("融合流量包订购接口调用接口错误：phone=" + uplanbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + uplanbo.getMSISDN() + "融合流量包订购BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }

    /**
     * 强制复机
     * 
     * @param recatbo
     * @return
     */
    public RestStatus CoerciveReact(TCoerciveReactBO recatbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + recatbo.getMSISDN() + "强制复机BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(recatbo);
            interfaceData.setMsisdn(recatbo.getMSISDN());
            interfaceData.setInterfaceName("CoerciveReact");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TCoerciveReactBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("CoerciveReact", recatbo);
                resp = (TCoerciveReactBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TCoerciveReactBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getOpraDesc());
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("复机接口调用接口错误：phone=" + recatbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("复机接口调用接口错误：phone=" + recatbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + recatbo.getMSISDN() + "强制复机BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }

    /**
     * 强制停机
     * 
     * @param blockbo
     * @return
     */
    public RestStatus coerciveBlock(TCoerciveBlockBO blockbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + blockbo.getMSISDN() + "强制停机BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(blockbo);
            interfaceData.setMsisdn(blockbo.getMSISDN());
            interfaceData.setInterfaceName("CoerciveBlock");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TCoerciveBlockBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("CoerciveBlock", blockbo);
                resp = (TCoerciveBlockBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TCoerciveBlockBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getOpraDesc());
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("强制停机接口调用接口错误：phone=" + blockbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("强制停机接口调用接口错误：phone=" + blockbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("强制停机接口调用接口错误：phone=" + blockbo.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + blockbo.getMSISDN() + "强制停机BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }

    /**
     * 号码开户
     * 
     * @param bo
     * @return
     */
    public RestStatus newConnection(TNewConnectionRequest bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "号码开户BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("NewConnection");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TNewConnectionResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("NewConnection", bo);
                resp = (TNewConnectionResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TNewConnectionResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
            
            logger.error("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "号码开户BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }

    /**
     * 号码过户
     * 
     * @param bo
     * @return
     */
    public RestStatus modCustomer(TModCustomerBO bo, String type, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        if("1".equals(type)){
            logger.error("----------------------------- 号码：" + bo.getMSISDN() + "预开卡号码开户开始调用接口 ,时间：" + System.nanoTime()
            + "-----------------------------");
        }else {
            logger.error("----------------------------- 号码：" + bo.getMSISDN() + "预开卡号码过户开始调用接口 ,时间：" + System.nanoTime()
            + "-----------------------------");
        }
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            if("1".equals(type)){
                interfaceData.setInterfaceName("NewConnection");
            }else {
                interfaceData.setInterfaceName("ModCustomer");
            }
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TModCustomerBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceURL");
                Client client = getClient(url);
                Object[] response = client.invoke("ModCustomer", bo);
                resp = (TModCustomerBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TModCustomerBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            if("1".equals(type)){
                interfaceData.setResponseContent("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
                logger.error("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            }else {
                interfaceData.setResponseContent("号码过户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
                logger.error("号码过户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            }
//            throw new Exception("号码过户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        if("1".equals(type)){
            logger.error("-----------------------------号码：" + bo.getMSISDN() + "预开卡号码开户接口调用完成,时间：" + System.nanoTime()
            + "-----------------------------");
        }else {
            logger.error("-----------------------------号码：" + bo.getMSISDN() + "预开卡号码过户接口调用完成,时间：" + System.nanoTime()
            + "-----------------------------");
        }
        return res;
    }

    /**
     * 号码充话费
     * 
     * @param rechargeBO
     * @return
     */
    public RestStatus dealerRecharge(TDealerRechargeBO rechargeBO, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + rechargeBO.getMSISDN() + "号码充话费BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            Date requestTime = new Date();
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(rechargeBO);
            interfaceData.setMsisdn(rechargeBO.getMSISDN());
            interfaceData.setInterfaceName("DealerRecharge");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 把出参对象转换成xml格式的字符串
            interfaceData.setResponseTime(new Date());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceURL");
            Client client = getClient(url);
            client.invoke("DealerRecharge", rechargeBO);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("号码充话费BOSS接口调用接口错误：phone=" + rechargeBO.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + rechargeBO.getMSISDN() + "号码充话费BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }

    private Client getClient(String url) {
        JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
        Client client = factory.createClient(url);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());
        return client;
    }
}
