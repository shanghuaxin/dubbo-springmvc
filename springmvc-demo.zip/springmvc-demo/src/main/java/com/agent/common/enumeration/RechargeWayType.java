package com.agent.common.enumeration;

/**
 * 充值方式类型：
 */
public enum RechargeWayType {
    AGENT("酷商", "agent"),
    ONLINE("网厅", "online"),
    WAP("掌厅", "wap"),
    APP("APP", "app"),
    ;
    
    // 成员变量 
    private String name;
    private String code;
    // 构造方法 
    private RechargeWayType(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (RechargeWayType ot : RechargeWayType.values()) {
            if (ot.getCode().equals(code)) {
                return ot.name;
            }
        }
        return code;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setId(String code) {
        this.code = code;
    }
}
