package com.agent.common.enumeration;

/**
 * 联通和移动号码的转换关系
 * 109999 正常服务    US10
 * 119999 已销户        US22
 * 129988 挂失停机    US30
 * 129993 停机保号    US31
 * 129994 强制单停    US32
 * 129995 预销户        US21
 * 129996 强制双停    US33
 * 129997 欠费停机    US34
 * 129998 单停            US35
 */
public enum UnicomAndAgentStatus {
    US10("US10", "109999"),
    US22("US22", "119999"),
    US30("US30", "129988"),
    US31("US31", "129993"),
    US21("US21", "129995"),
    US33("US33", "129996"),
    US34("US34", "129997"),
    US35("US35", "129998"),
    ;
    
    // 成员变量 
    private String unicomStatus;
    private String agentStatus;
    // 构造方法 
    private UnicomAndAgentStatus(String agentStatus, String unicomStatus) {
        this.agentStatus = agentStatus;
        this.unicomStatus = unicomStatus;
    }
    
    public static String getAgentStatus(String unicomStatus) {
        for (UnicomAndAgentStatus us : UnicomAndAgentStatus.values()) {
            if (us.getUnicomStatus().equals(unicomStatus)) {
                return us.agentStatus;
            }
        }
        return unicomStatus;
    }
    
    public String getUnicomStatus() {
        return unicomStatus;
    }
    
    public void setUnicomStatus(String unicomStatus) {
        this.unicomStatus = unicomStatus;
    }
    
    public String getAgentStatus() {
        return agentStatus;
    }
    
    public void setAgentStatus(String agentStatus) {
        this.agentStatus = agentStatus;
    }
}
