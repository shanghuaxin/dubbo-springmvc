package com.agent.common.enumeration;

/**
 * 号码状态
 * @author fenglu
 *
 */
public enum BossPhoneStatus {
    NORMAL("正常", "A"),
    ARREARS_STOP_ALONE("欠费单停", "00100000000000"),
    ARREARS_STOP_ALL("欠费双停", "00200000000000"),
    PRE_CANCELLATION("预销户", "00002000000000"),
    FORCED_STOP("强制停机", "02000000000000"),
    STOP_PAUL("停机保号", "20000000000000"),
    STOP_PAUL_ALONE("停机保号欠费单停", "20100000000000"),
    STOP_PAUL_ALL("停机保号欠费双停", "20200000000000"),
    REPORT_LOSS("挂失", "00000002000000"),
    REPORT_LOSS_ALONE("挂失欠费单停", "00100002000000"),
    REPORT_LOSS_ALL("挂失欠费双停", "00200002000000"),
    STOP_LOSS_ALL("停机保号强制双停", "22000000000000"),
    RECHARGE_STOP_ALL("欠费双停", "02200000000000"),
    NOT_ACTIVITE("未激活", "G"),
    // 联通号码状态
    UNICOM_NORMAL("正常", "109999"),
    UNICOM_CANCEL("销户", "119999"),
    UNICOM_LOSS("挂失停机", "129988"),
    UNICOM_STOP_PAUL("停机保号", "129993"),
    UNICOM_FORCED_STOP_ALONE("强制单停", "129994"),
    UNICOM_PRE_CANCEL("预销户", "129995"),
    UNICOM_FORCED_STOP("强制双停", "129996"),
    UNICOM_ARREARS_STOP_ALL("欠费停机", "129997"),
    UNICOM_STOP_ALONE("单停", "129998"),
    UNICOM_109996("强制开机","109996"),
    UNICOM_109997("强拆返销","109997"),
    UNICOM_109998("销号返销","109998"),
    //UNICOM_109999("正常服务","109999"),
    UNICOM_110000("无效","110000"),
    UNICOM_119990("预登录取消","119990"),
    UNICOM_119991("单机与中继互转","119991"),
    UNICOM_119992("删除中继线号","119992"),
    UNICOM_119993("跨业务换装","119993"),
    UNICOM_119994("客户帐户合并拆分","119994"),
    UNICOM_119995("过户","119995"),
    UNICOM_119996("改号","119996"),
    UNICOM_119997("装机回退","119997"),
    UNICOM_119998("强拆销号","119998"),
    //UNICOM_119999("用户退网","119999"),
    UNICOM_129983("PPC用户加锁","129983"),
    UNICOM_129984("PPC用户挂失","129984"),
    UNICOM_129985("预销户","129985"),
    UNICOM_129986("预登录呼限","129986"),
    UNICOM_129987("预登录停机","129987"),
    //UNICOM_129988("挂失停机","129988"),
    UNICOM_129989("携出停机","129989"),
    UNICOM_129990("强制停机","129990"),
    UNICOM_129991("预登录强制停机","129991"),
    UNICOM_129992("申请呼叫限制","129992"),
    //UNICOM_129993("停机保号","129993"),
    //UNICOM_129995("退网停机","129995"),
    //UNICOM_129996("局方强制服务暂停","129996"),
    //UNICOM_129997("欠费服务暂停","129997"),
    //UNICOM_129998("呼叫限制","129998"),
    UNICOM_129999("申请服务暂停","129999"),
    UNICOM_145000("预约","145000"),
    UNICOM_149998("准开通","149998"),
    UNICOM_149999("预登录","149999"),
    ;
    
    // 成员变量 
    private String name;
    private String value;
    // 构造方法 
    private BossPhoneStatus(String name, String value) {
        this.name = name;
        this.value = value;
    }
    
    public static String getName(String value) {
        for (BossPhoneStatus ot : BossPhoneStatus.values()) {
            if (ot.getValue().equals(value)) {
                return ot.name;
            }
        }
        return value + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getValue() {
        return value;
    }
    
    public void setValue(String value) {
        this.value = value;
    }
}
