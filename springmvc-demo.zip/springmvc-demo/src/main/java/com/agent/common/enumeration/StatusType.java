package com.agent.common.enumeration;

public enum StatusType {
    
    SUCCESS("成功", "1"), FAILURE("失败", "2"), PROCESS("处理中", "3");
    
    // 成员变量 
    private String name;
    private String code;
    // 构造方法 
    private StatusType(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (StatusType ot : StatusType.values()) {
            if (ot.getCode() == code) {
                return ot.name;
            }
        }
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
