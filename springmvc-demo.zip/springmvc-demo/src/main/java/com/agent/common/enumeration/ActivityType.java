package com.agent.common.enumeration;

/**
 * 活动类型枚举
 * @author fenglu
 *
 */
public enum ActivityType {
    ONLINE_BANNER("网厅轮播图", 1),
    ONLINE_ACTIVITY("网厅活动", 2),
    ONLINE_PHONE("网厅号码专区", 3),
    ONLINE_OUTSIDE("网厅境外出行", 4),
    ONLINE_MORE("网厅更多产品", 5),
    WAP_BANNER("掌厅轮播图", 6),
    WAP_CHINAMOBILE("掌厅移动专区", 7),
    WAP_UNICOM("掌厅联通专区", 8),
    WAP_MORE("掌厅更多产品", 9),
    WAP_MAIN_MENU("掌厅首页菜单", 10),
    WAP_SERVICE_MENU1("掌厅服务1类菜单", 11),
    WAP_SERVICE_MENU2("掌厅服务2类菜单", 12),
    WAP_SERVICE_MENU3("掌厅服务3类菜单", 13),
    APP_BANNER("APP首页轮播图", 14)
    ;
    
    // 成员变量 
    private String name;
    private Integer id;
    // 构造方法 
    private ActivityType(String name, Integer id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (ActivityType ot : ActivityType.values()) {
            if (ot.getId() == id) {
                return ot.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
}
