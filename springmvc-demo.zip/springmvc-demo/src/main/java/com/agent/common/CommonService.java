package com.agent.common;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.api.InterfaceUtil;
import com.agent.api.service.IDCheckService;
import com.agent.cs.dto.ReqCommonDTO;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.SysConfig;

@Service("commonService")
public class CommonService {
    private static Logger logger = LoggerFactory.getLogger(CommonService.class);
    @Autowired
    private IDCheckService idCheckService;

    /**
     * 调用网厅接口相关公共方法
     * @param dto
     * @param url
     * @param desc
     * @param request
     * @return
     * @author Shanghuaxin
     */
    public static RestStatus common(ReqCommonDTO dto, String url, String desc, User user){
        RestStatus rs = new RestStatus(true);
        try {
            dto.setUserId(user.getId());//当前操作员ID
            // 服务端地址
            String olbiz_url = SysConfig.getValue("CoolOlbizUrl");
            String postUrl = olbiz_url + url;
            String postData = JSONUtil.objectToJson(dto);
            logger.info(desc + "，请求参数：" + postData);
            //String result = "{\"status\":true,\"errorCode\":\"200\",\"errorMessage\":\"获取用户信息成功\",\"responseData\":[{\"certName\":\"唐袅\",\"certCode\":\"360121199206210522\",\"phone\":"
            //+ "\"17057094093\",\"phoneLevel\":\"5\",\"openDate\":\"2018-01-30 11:08:02.0\",\"activationDate\":\"2018-01-30\",\"userStatus\":\"正常\",\"pacName\":\"酷2\",\"minMoney\":\"10.00\",\"pacMoney\":\"2.00\",\"pacCode\":\"1351201\",\"bal\":\"60.00\",\"balFlow\":\"303.00\",\"area\":\"中兴视通\",\"channelName\":null,\"mobileModel\":null,\"isPre\":\"0\"}]}";
            String result = InterfaceUtil.getInstance().callInvokeOnlie(postUrl, postData);
            logger.info(desc + "，返回结果为：" + result);
            rs = JSONUtil.jsonToObject(result, RestStatus.class);
        } catch (Exception e) {
            logger.error("调用查询接口失败:"+e.getMessage(),e);
            rs = new RestStatus(Boolean.FALSE,"500","调用查询接口失败:"+e.getMessage());
        }
        return rs;
    }
    

    /**
     * 获取身份证信息
     * @param atts
     * @param realname
     * @param idcardInfo
     * @param request
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public IdcardInfo imgIdcardInfo(List<AttachedDocuments> atts,String phone, HttpServletRequest request,String imageURL) throws Exception{
        IdcardInfo idcardInfo = new IdcardInfo();
        if(null != atts && atts.size() >0){
            for(AttachedDocuments s:atts){
              //cardFront 正面
                //cardRear 背面
                try {
                    if("cardFront".equals(s.getSourceType()) || "cardRear".equals(s.getSourceType())){
                        String idnoPath = imageURL+s.getAttachmentUrl();
                        JSONObject jo = new JSONObject();
                        // 默认0表示图片base64,  1表示图片绝对路径
                        jo.put("imgType", 1);
                        if("cardFront".equals(s.getSourceType())){
                            jo.put("frontImg", idnoPath);
                        } else if("cardRear".equals(s.getSourceType())){
                            jo.put("backImg", idnoPath);
                            // 是否需要计费，如果传递idnosBackNoChargingByOCR参数,表示不计费
                            jo.put("idnosBackNoChargingByOCR", true);
                        }
                        
                        logger.info("---------------客服识别OCR-------------号码：" + phone + "OCR识别开始 ,时间：" + DateUtil.getInstance().formatDate(new Date(), null) + "---");
                        String resultStr = idCheckService.ocrAnalyseKF(jo.toString());
                        logger.info("---------------客服识别OCR-------------号码：" + phone + "OCR识别完成 ,时间：" + DateUtil.getInstance().formatDate(new Date(), null) + "---");
                        if("cardFront".equals(s.getSourceType())){
                            resultStr = resultStr.replace("ethnic", "nation").replace("id_code", "idNumber").replace("real_name", "name")
                                    .replace("gender", "sexual").replace("addr", "address");
                            Map<String,String> m = JSONUtil.jsonToObject(resultStr, Map.class);
                            if("0".equals(m.get("result"))){
                                if(null != m.get("name")){
                                    idcardInfo.setName(m.get("name"));
                                }
                                if(null != m.get("nation")){
                                    idcardInfo.setNation(m.get("nation"));
                                }
                                if(null != m.get("idNumber")){
                                    idcardInfo.setIdNumber(m.get("idNumber"));
                                }
                                if(null != m.get("address")){
                                    idcardInfo.setAddress(m.get("address"));
                                }
                                if(null != m.get("sexual")){
                                    idcardInfo.setSexual(m.get("sexual"));
                                }
                            }
                        } else if("cardRear".equals(s.getSourceType())){
                            resultStr = resultStr.replace("issue_authority", "organs").replace("valid_period", "expirydate");
                            Map<String,String> m = JSONUtil.jsonToObject(resultStr, Map.class);
                            if("0".equals(m.get("result"))){
                                if(null != m.get("organs")){
                                    idcardInfo.setOrgans(m.get("organs"));
                                }
                                if(null != m.get("expirydate")){
                                    idcardInfo.setExpiryDate(m.get("expirydate"));
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    logger.error("识别图片失败", e.getMessage(),e);
                }
            }
        }
        return idcardInfo;
    }
}
