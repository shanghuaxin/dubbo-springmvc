package com.agent.common.enumeration;

/**
 * 酷商号码名称转换
 * 
 */
public enum NumberStatus {
    US01("US01", "待分配"),
    US02("US02", "待开户"),
    US03("US03", "开户待确认"),
    US10("US10", "已开户"),
    US20("US20", "已销户"),
    US21("US21", "预销户"),
    US22("US22", "强制单停"),
    US30("US30", "挂失停机"),
    US31("US31", "停机保号"),
    US33("US33", "强制双停"),
    US34("US34", "欠费停机"),
    US35("US35", "单停"),
    ;
    
    // 成员变量 
    private String code;
    private String name;
    // 构造方法 
    private NumberStatus(String code, String name) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (NumberStatus us : NumberStatus.values()) {
            if (us.getCode().equals(code)) {
                return us.name;
            }
        }
        return code;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
}
