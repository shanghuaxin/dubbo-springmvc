package com.agent.common.enumeration;

/**
 * 工单类型 01：网络使用类 02：计费类  03：充值类 04：增值业务类 05：服务开通变更类 06：漏电提醒类
 */
public enum WorkOrderSupportType {
    NETWORK("网络使用类", "01"),
    ACCOUNT("服务开通变更类", "02"),
    BILLING("计费类", "03"),
    RECHARGE("充值类", "04"),
    VAS("增值业务类", "05"),
    MISHU("漏电提醒类", "06"),
    ;
    
    private String name;
    private String id;
    // 构造方法 
    private WorkOrderSupportType(String name, String id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(String id) {
        for (WorkOrderSupportType ps : WorkOrderSupportType.values()) {
            if (ps.getId().equals(id)) {
                return ps.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
}
