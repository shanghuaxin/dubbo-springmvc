package com.agent.common;

import static com.agent.util.ServletUtil.contains;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.agent.constant.Constant;
import com.agent.system.entity.User;

/**
 * 权限过滤
 * 
 * @author zhyan
 */
public class AuthenticatFilter implements Filter {

    /** 不需要登录即可访问的地址 **/
    private static List<String> DEFAULTPATH = new ArrayList<String>();
    /** 会话过期或未登录 **/
    private static RequestDispatcher expire, deny;
    static {
        DEFAULTPATH.add("pro/getPriviOption.action");
        DEFAULTPATH.add("pro/getRoleOption.action");
        DEFAULTPATH.add("pro/getAllPrivi.action");
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        ServletContext ctx = filterConfig.getServletContext();
        expire = ctx.getRequestDispatcher("/expire.html");
        deny = ctx.getRequestDispatcher("/deny.jsp");
    }

    /**
     * 登录验证
     */
    @SuppressWarnings("unchecked")
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletResponse rsp = (HttpServletResponse) response;
        rsp.setHeader("Pragma", "No-cache");
        rsp.setHeader("Cache-Control", "no-cache");
        rsp.setHeader("Cache-Control", "no-store");
        rsp.setDateHeader("Expires", 0);

        HttpServletRequest req = (HttpServletRequest) request;
        int lastIndex = req.getRequestURI().lastIndexOf("pro/");
        if (lastIndex == -1) {
            lastIndex = req.getRequestURI().lastIndexOf("config/");
        }
        String url = req.getRequestURI().substring(lastIndex);

        List<String> priviList = new ArrayList<String>();
        priviList = (List<String>) req.getSession().getAttribute(Constant.SESSION_PRIVI);
        if (contains(priviList, url) || contains(DEFAULTPATH, url)) {
            chain.doFilter(request, response);
            return;
        }
        User user = (User) req.getSession().getAttribute(Constant.SESSION_USER);
        if (user == null) {
            expire.forward(request, response);
        } else {
            deny.forward(request, response);
            return;
        }

    }

    @Override
    public void destroy() {
        expire = null;
    }
}
