package com.agent.common;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;

public class CacheRedisOperator {

    private static final Logger log = LoggerFactory.getLogger(CacheRedisOperator.class);

    public static Jedis getJedis() {
        return CacheRedisFactory.getResource();
    }

    public static String get(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.get(key);
        } catch (Exception e) {
            log.error("redis:获取用户信息失败,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return null;
    }

    public static long expire(String key, int seconds) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.expire(key, seconds);
        } catch (Exception e) {
            log.error("key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static void set(String key, String value) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            jedis.set(key, value);
        } catch (Exception e) {
            log.error("redis:设置用户属性失败,key=" + key + ",value=" + value, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
    }

    public static void del(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            jedis.del(key);
        } catch (Exception e) {
            log.error("redis:删除key失败,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
    }

    public static boolean exists(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.exists(key);
        } catch (Exception e) {
            log.error("redis:检测key是否存在失败,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return false;
    }

    public static String spop(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.spop(key);
        } catch (Exception e) {
            log.error("redis:获取缓存号码出错,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return null;
    }

    public static long sadd(String key, String value) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            long size = jedis.sadd(key, value);
            return size;
        } catch (Exception e) {
            log.error("redis:缓存添加号码失败(sadd),key=" + key + ",vlaue=" + value, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static long scard(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.scard(key);
        } catch (Exception e) {
            log.error("redis:获取缓存号码长度出错,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public long srem(String key, String member) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.srem(key, member);
        } catch (Exception e) {
            log.error("redis:移除缓存号码出错,key=" + key + ",value=" + member, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static long hset(String key, String field, String value) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            long size = jedis.hset(key, field, value);
            return size;
        } catch (Exception e) {
            log.error("redis:设置用户属性失败,key=" + key + ",field=" + field + ",value=" + value, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static String hmset(String key, Map<String, String> map) {

        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            String result = jedis.hmset(key, map);
            return result;
        } catch (Exception e) {
            log.error("redis:设置用户属性失败,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return null;

    }

    public static String hget(String key, String field) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.hget(key, field);
        } catch (Exception e) {
            log.error("redis:获取用户属性失败,key=" + key + ",field=" + field, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return null;
    }

    public static boolean hexists(String key, String field) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.hexists(key, field);
        } catch (Exception e) {
            log.error("redis:检测用户属性是否存在失败,key=" + key + ",field=" + field, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return false;
    }

    public static long hdel(String key, String field) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            jedis.hdel(key, field);
        } catch (Exception e) {
            log.error("redis:删除用户属性失败,key=" + key + ",field=" + field, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static Map<String, String> hgetAll(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.hgetAll(key);
        } catch (Exception e) {
            log.error("redis:获取用户所有属性失败,key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return null;
    }

    public static long incr(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.incr(key);
        } catch (Exception e) {
            log.error("key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static long decr(String key) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.decr(key);
        } catch (Exception e) {
            log.error("key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return 0;
    }

    public static void setex(String key, int seconds, String value) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            jedis.setex(key, seconds, value);
        } catch (Exception e) {
            log.error("key=" + key, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
    }

    public static Set<String> keys(String pattern) {
        Jedis jedis = null;
        // 从池中获取一个jedis实例
        try {
            jedis = getJedis();
            return jedis.keys(pattern);
        } catch (Exception e) {
            log.error("pattern=" + pattern, e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            // 还会到连接池
            CacheRedisFactory.returnResource(jedis);
        }
        return null;
    }

    public static String ping() {
        Jedis jedis = null;
        try {
            jedis = getJedis();
            return jedis.ping();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            // 销毁对象
            CacheRedisFactory.returnBrokenResource(jedis);
        } finally {
            CacheRedisFactory.returnResource(jedis);
        }
        return null;
    }

    /**
     * 删除给定的一个或多个key
     * 
     * @param keys
     * @return
     */
    public static final Long del(String... keys) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.del(keys);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    public static final List<String> hmget(String key, String... fields) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.hmget(key, fields);
        } catch (Exception e) {
            log.error("hmget error", e);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
        return null;
    }

    public static final Long hmdel(String key, String... fields) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.hdel(key, fields);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    // 添加客户端 set
    public static final Long sadd(String key, String... members) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.sadd(key, members);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    // list
    public static final Long lpush(String key, String... members) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.lpush(key, members);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    public static final Long srem(String key, String... members) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.srem(key, members);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    public static final Set<String> smembers(String key) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.smembers(key);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    // list 取出所有
    public static final List<String> lrange(String key) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.lrange(key, 0, llen(key));
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    // 获取list 长度
    public static final Long llen(String key) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.llen(key);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    public static final String srandmember(String key) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.srandmember(key);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    public static final void rename(String key, String newKey) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            res.rename(key, newKey);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

    public static final Set<String> hkeys(String key) {
        Jedis res = CacheRedisFactory.getResource();
        try {
            return res.hkeys(key);
        } finally {
            CacheRedisFactory.returnResource(res);
        }
    }

}
