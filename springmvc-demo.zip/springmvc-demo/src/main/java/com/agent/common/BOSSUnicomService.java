package com.agent.common;

import java.io.StringWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.example.forcestopdeal.ForceStopDealRequest;
import org.example.forcestopdeal.ForceStopDealResponse;
import org.example.paymentbank.PaymentBankRequest;
import org.example.paymentbank.PaymentBankResponse;
import org.example.payoutfeedeal.PayOutFeeDealRequest;
import org.example.payoutfeedeal.PayOutFeeDealResponse;
import org.example.productusedquery.ProductUsedQueryRequest;
import org.example.productusedquery.ProductUsedQueryResponse;
import org.example.usermonthfeelist.UserMonthFeeListRequest;
import org.example.usermonthfeelist.UserMonthFeeListResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.api.InterfaceUtil;
import com.agent.businesslog.entity.InterfaceData;
import com.agent.businesslog.service.InterfaceDataService;
import com.agent.constant.Constant;
import com.agent.constant.ServiceCodeConstant;
import com.agent.number.dto.NumberTopUpRestDTO;
import com.agent.openaccount.dto.ModCustomerDTO;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.SysConfig;
import com.agent.util.Utils;
import com.agent.util.XMLUtil;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.CompactWriter;

import namespace.webservice.crmsps.AccessProdItemVO;
import namespace.webservice.crmsps.AccountCancellation;
import namespace.webservice.crmsps.AgentCustInfo;
import namespace.webservice.crmsps.CallForwarding;
import namespace.webservice.crmsps.ChangeCardOrder;
import namespace.webservice.crmsps.CheckProductIdIfEqual;
import namespace.webservice.crmsps.Com_Bus_Info;
import namespace.webservice.crmsps.CompleteOrder;
import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.CrmSpsService;
import namespace.webservice.crmsps.CrmSpsServicePortType;
import namespace.webservice.crmsps.CustInfoVO;
import namespace.webservice.crmsps.CustOrderBasicVO;
import namespace.webservice.crmsps.Missingreport;
import namespace.webservice.crmsps.ModOffer;
import namespace.webservice.crmsps.ModOptionalOffer;
import namespace.webservice.crmsps.ModPasswd;
import namespace.webservice.crmsps.ModProdOffer;
import namespace.webservice.crmsps.OfferItemVO;
import namespace.webservice.crmsps.OfferWithStatus;
import namespace.webservice.crmsps.OptPackage;
import namespace.webservice.crmsps.OptionalPackage;
import namespace.webservice.crmsps.PackageInfo;
import namespace.webservice.crmsps.PrestoreVo;
import namespace.webservice.crmsps.ProdOfferListVO;
import namespace.webservice.crmsps.ProductChangeVO;
import namespace.webservice.crmsps.QueryUser;
import namespace.webservice.crmsps.Reportmissingreport;
import namespace.webservice.crmsps.SaveBudgetOrder;
import namespace.webservice.crmsps.SvcCont;
import namespace.webservice.crmsps.TcpCont;
import namespace.webservice.crmsps.ThreeGTurnFourGVO;
import namespace.webservice.crmsps.TransUser;
import namespace.webservice.crmsps.UserValidation;

@Service
public class BOSSUnicomService {
    public Logger logger = (Logger) LoggerFactory.getLogger(BOSSBuyService.class);
    
    @Autowired
    private InterfaceDataService interfaceDataService;
    
    //public final QName SERVICE_NAME_CRM1 = new QName("http://crmsps.webservice.namespace", "crmSpsService");
    //public final QName SERVICE_NAME_CRM2 = new QName("http://WebhallService.server.webService.resource.crm.neusoft.com", "crmSpsService");
    
    public static void main(String args[]) {
        try {
            //new BOSSUnicomService().AccountCancellationService();
            //new BOSSUnicomService().optionalPackage();
            /*PayOutFeeDealRequest number = new PayOutFeeDealRequest();
            number.setServiceId("17091504325");
            number.setFee(new BigDecimal(10).multiply(Constant.cnt100).longValue());
            new BOSSUnicomService().payOutFeeDeal(number,new User());*/
            //new BOSSUnicomService().doCompleteOrder("1222222");
            //new BOSSUnicomService().optionalPackage(new User());
            //new BOSSUnicomService().saveBudgetOrder();
            //new BOSSUnicomService().offerWithStatus();
            //new BOSSUnicomService().modProdOffer();
            //new BOSSUnicomService().modOffer();
            //new BOSSUnicomService().userValidation();
            //new BOSSUnicomService().reportmissingreport();
            //new BOSSUnicomService().missingreport();
            //new BOSSUnicomService().agentCustInfo();
            //new BOSSUnicomService().changeCardOrder();
            //new BOSSUnicomService().canOrderProdOffer();
            //new BOSSUnicomService().modOptionalOffer();
            //new BOSSUnicomService().modPasswd();
            //new BOSSUnicomService().queryUser();
            new BOSSUnicomService().CheckProductIdIfEqualService(new User(), "17170051412", "1351201");
            
            /*String backUrl = "http://192.168.12.61:9998/basic_service/revoke_support/v1?BJN2GP17D121WKnY5pvU3ZXSTuFIEwRvk5iiRVOYXTUySHI2";
            String json = "{\"mvnokey\":\"JE0ijPd\",\"serial_number\":\"JE0ijPd20140428966137833x00x23\",\"timestamp\":\"2014-05-10 14:19:37\""
                    + ",\"service_type\":\"extended_service\",\"service_name\":\"query_internet_history\",\"api_name\":\"cu.vop.extended_service.query_internet_history\""
                    +",\"phone_number\":\"170928172261\",\"start_time\":\"2014-01-01\",\"end_time\":\"2014-01-02\"}";
            String result = InterfaceUtil.getInstance().callInvoke(backUrl, json);
            System.out.println("result--->"+result);*/
            
            /*ForceStopDealRequest request = new ForceStopDealRequest();
            request.setServiceId("17057000125");
            request.setOperFlag("4");
            new BOSSUnicomService().forceStopDeal(request, new User());*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 保存订单、预算费用 NEU6099060115
     */
    public RestStatus saveBudgetOrder(NumberTopUpRestDTO number,User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(number);
            interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName(ServiceCodeConstant.SAVE_BUDGET_ORDER);
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            }
            
            // NEU6099060115 保存订单、预算费用 begin
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.SAVE_BUDGET_ORDER);
            contractRoot.setTcpCont(tcpCont);
            SaveBudgetOrder svcCont = new SaveBudgetOrder();
            AccessProdItemVO apivo = new AccessProdItemVO();
            apivo.setOperKind(1);
            apivo.setCityCode("360");
            apivo.setServiceId(number.getPhone());
            apivo.setResInstId(number.getResInstId());
            apivo.setUimId(number.getIccid());
            apivo.setUimResInstId(number.getUimResInstId());
            apivo.setProductId(ContractRoot.PRODUCTID);
            apivo.setCustomerId("0");
            apivo.setDealerInnetMethod("-1");
            //可选
            apivo.setBelongCode("360");
            apivo.setTownCode("1");
            
            apivo.setDealerId(number.getChannelId());
            apivo.setSourceDealerId(number.getChannelId());
            
            CustOrderBasicVO cobvo = new CustOrderBasicVO();
            cobvo.setCustId("0");
            //可选
            cobvo.setHandlePeopleName("");
            cobvo.setViaIdKind("1");
            cobvo.setViaId("12");
            cobvo.setViaAddress("12");
            cobvo.setNote("");
            cobvo.setAcceptCity("360");
            cobvo.setWorkNo("ADMIN");
            
            List<OfferItemVO> offerItemList = new ArrayList<OfferItemVO>();
            OfferItemVO oivo = new OfferItemVO();
            // 增值业务（可选）
            String meals = number.getMealCodes();
            if(!"".equals(meals)){
                String mealCodes[] = meals.split(",");
                for(String m : mealCodes){
                    oivo = new OfferItemVO();
                    oivo.setOperKind("1");
                    oivo.setProdOfferId(m);//1351062
                    oivo.setEffDate(DateUtil.getNowDateTimeString("yyyy-MM-dd"));
                    oivo.setExpDate("2037-01-01");
                    offerItemList.add(oivo);
                }
            }
            
            CustInfoVO civo = new CustInfoVO();
            civo.setWorkNo("ADMIN");
            civo.setCustName(number.getName());
            civo.setIdentityCode(number.getCode());
            civo.setIdentityKind("3");
            civo.setCityCode("360");
            civo.setIdentityAddress(number.getAddress());
            civo.setDutyMan(number.getName());
            civo.setDutyKind("1");
            civo.setDutyAddress(number.getAddress());
            civo.setDutyId(number.getCode());
            
            PrestoreVo pvo = new PrestoreVo();
            String money = Constant.df1.format(new BigDecimal(number.getMoney()).multiply(new BigDecimal(100)));//乘以100(单位：分)  
            pvo.setPrestoreId(money);
            pvo.setAdjustFee(number.getNumberLowerMoney());
            
            svcCont.setAccessProdItemVO(apivo);
            svcCont.setCustOrderBasicVO(cobvo);
            svcCont.setOfferItemList(offerItemList);
            svcCont.setCustInfoVO(civo);
            svcCont.setPrestoreVo(pvo);
            
            contractRoot.setSvcCont(svcCont);
            // NEU6099060115 保存订单、预算费用 end
            
            ContractRoot root = exec(contractRoot, SaveBudgetOrder.class.getSimpleName());
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                res.setStatus(Boolean.TRUE);
                interfaceData.setStatus(1);
            }else{
                res.setStatus(Boolean.FALSE);
                interfaceData.setStatus(0);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("保存订单、预算费用接口失败！原因：" + e.getMessage());
            res.setStatus(Boolean.FALSE);
            logger.error("保存订单、预算费用接口错误：phone=" + number.getPhone() + "，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("保存订单、预算费用接口错误：phone=" + number.getPhone() + "，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 获取可选包接口NEU6099060194
     * 根据工号销售品id及主套餐的付费方式查询能订购的可选包信息
     */
    public RestStatus optionalPackage(User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
//            String reqeustContent = JSONUtil.objectToJson(number);
//            interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060194");
//            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            // NEU6099060194 获取可选包接口 begin
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.OPTIONAL_PACKAGE);
            contractRoot.setTcpCont(tcpCont);
            
            OptPackage svcCont = new OptPackage();
            // 工号
            svcCont.setWorkNo("ADMIN");
            // 主套餐Id
            svcCont.setProdOfferId("1300822");
            // 计费方式，取主套餐的计费方式
            svcCont.setFeeType("1200");
            contractRoot.setSvcCont(svcCont);
            // NEU6099060194 获取可选包接口 end
            ContractRoot root = exec(contractRoot, OptPackage.class.getSimpleName());
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("获取可选包接口接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("获取可选包接口接口错误：原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("获取可选包接口接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 用户综合信息查询     NEU6099060079
     */
    public RestStatus queryUserService(QueryUser svcCont,User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getQueryValue());
            interfaceData.setInterfaceName("NEU6099060079");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.QUERY_USER);
            contractRoot.setTcpCont(tcpCont);
            /*QueryUser svcCont = new QueryUser();
            svcCont.setQueryValue("1");
            svcCont.setQueryType("1");
            svcCont.setProductId("1");
            svcCont.setCityCode("360");*/
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, QueryUser.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("用户综合信息查询接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("用户综合信息查询接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("用户综合信息查询接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 密码修改     NEU6099060003
     */
    public RestStatus modPasswd(User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060003");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.MOD_PASSWD);
            contractRoot.setTcpCont(tcpCont);
            
            ModPasswd svcCont = new ModPasswd();
            svcCont.setAccNbr("-1");
            svcCont.setProductId("1");
            svcCont.setCityCode("360");
            svcCont.setPasstype("1");
            svcCont.setOldPassword("1111111");
            svcCont.setNewPassword("111111");
            svcCont.setAcceptPerson("1");
            svcCont.setAcceptWay("1");
            svcCont.setIfCkeckFlag("1");
            svcCont.setIdentityCode("1");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ModPasswd.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("密码修改接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("密码修改接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("密码修改接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 订购退订可选包接口   NEU6099060002
     */
    public RestStatus modOptionalOffer(ModOptionalOffer svcCont,User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getAccNbr());
            interfaceData.setInterfaceName("NEU6099060002");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.MOD_OPTIONAL_OFFER);
            contractRoot.setTcpCont(tcpCont);
           /* ModOptionalOffer svcCont = new ModOptionalOffer();
            svcCont.setAccNbr("-1");
            svcCont.setProductId("1");
            svcCont.setCityCode("360");
            svcCont.setProdOfferId("1300822");
            svcCont.setServiceOfferId("1");
            svcCont.setEffectType("1");*/
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ModOptionalOffer.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("订购退订可选包接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("订购退订可选包接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("订购退订可选包接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 可订购的可选包查询   NEU6099060189
     */
    public RestStatus canOrderProdOffer(User user) {
        
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060189");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.CAN_ORDER_PROD_OFFER);
            contractRoot.setTcpCont(tcpCont);
            ModProdOffer svcCont = new ModProdOffer();
            svcCont.setProdOfferId("1300822");
            svcCont.setServiceId("1");
            svcCont.setChannelId("1");
            svcCont.setCityCode("360");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ModProdOffer.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("可订购的可选包查询接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("可订购的可选包查询接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("可订购的可选包查询接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 补换卡接口、预算费用   NEU6099060196
     */
    public RestStatus changeCardOrder(User user,ChangeCardOrder changeCardOrder) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        logger.error("----------------------------- 号码：" + changeCardOrder.getServiceId() + "补换卡BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(changeCardOrder);
            interfaceData.setMsisdn(changeCardOrder.getServiceId());
            interfaceData.setInterfaceName("NEU6099060196");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.CHANGE_CARD_ORDER);
            contractRoot.setTcpCont(tcpCont);
            ChangeCardOrder svcCont = new ChangeCardOrder();
            svcCont.setOperKind(changeCardOrder.getOperKind());
            svcCont.setServiceId(changeCardOrder.getServiceId());
            svcCont.setOldCard(changeCardOrder.getOldCard());
            svcCont.setNewCard(changeCardOrder.getNewCard());
            svcCont.setChangeReason(changeCardOrder.getChangeReason());
            svcCont.setChangeKind(changeCardOrder.getChangeKind());
            svcCont.setExtOrderId(changeCardOrder.getExtOrderId());
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ChangeCardOrder.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            logger.info("request_content="+responseContent);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("补换卡接口、预算费用接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("补换卡接口、预算费用接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("补换卡接口、预算费用接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("----------------------------- 号码：" + changeCardOrder.getServiceId() + "补换卡BOSS接口调用完成 ,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 客户资料修改   NEU6099060107
     */
    public RestStatus agentCustInfo(User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060107");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.AGENT_CUSTINFO);
            contractRoot.setTcpCont(tcpCont);
            AgentCustInfo svcCont = new AgentCustInfo();
            svcCont.setWorkNo("M517");
            svcCont.setCustName("11");
            svcCont.setIdentityCode("150202198403230912");
            svcCont.setIdentityKind("11");
            svcCont.setCityCode("11");
            svcCont.setIdentityAddress("11");
            svcCont.setLinkMan("11");
            svcCont.setLinkPhone("17091502448");
            svcCont.setServiceId("17091502448");
            svcCont.setCommuAddress("11");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, AgentCustInfo.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("客户资料修改接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("客户资料修改接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("客户资料修改接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 挂失   NEU6099060223   0 挂失停机 1 停机保号
     */
    public RestStatus missingreport(Missingreport svcCont, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getAccNbr());
            interfaceData.setInterfaceName(ServiceCodeConstant.MISSING_REPORT);
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.MISSING_REPORT);
            contractRoot.setTcpCont(tcpCont);
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, Missingreport.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("挂失接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("挂失接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("挂失接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 解挂   NEU6099060222   0 解挂 1 停机保号复机
     */
    public RestStatus reportmissingreport(Reportmissingreport svcCont, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getAccNbr());
            interfaceData.setInterfaceName(ServiceCodeConstant.REPORT_MISSING_REPORT);
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.REPORT_MISSING_REPORT);
            contractRoot.setTcpCont(tcpCont);
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, Reportmissingreport.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if ("0000".equals(root.getTcpCont().getResponse().getRspCode())) {
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            } else {
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        } catch(Exception e) {
            res.setErrorMessage("解挂接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("解挂错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("解挂接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 验证用户有效性    NEU6099060023
     */
    public RestStatus userValidation(String phone, String pwdMd5, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            UserValidation svcCont = new UserValidation();
            svcCont.setProductId("-1");
            svcCont.setProdInstAccNbr(phone);
            svcCont.setPassword(pwdMd5);
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getProdInstAccNbr());
            interfaceData.setInterfaceName("NEU6099060023");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.USER_VALIDATION);
            contractRoot.setTcpCont(tcpCont);
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, UserValidation.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("验证用户有效性接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("验证用户有效性接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("验证用户有效性接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 销售品变更    NEU6099060004
     */
    public RestStatus modOffer(ModOffer svcCont,User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getAccNbr());
            interfaceData.setInterfaceName("NEU6099060004");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.MOD_PROD);
            contractRoot.setTcpCont(tcpCont);
            /*ModOffer svcCont = new ModOffer();
            svcCont.setAccNbr("1300822");
            svcCont.setProductId("1300822");
            // 可选
            svcCont.setCityCode("1200");
            svcCont.setOldProdOfferId("1300822");
            svcCont.setNewProdOfferId("1300820");
            svcCont.setEffectType("0");*/
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ModOffer.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("销售品变更接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("销售品变更用接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("销售品变更接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 可变更套餐信息查询    NEU6099060198
     */
    public RestStatus modProdOffer(User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060198");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.MOD_PROD_OFFER);
            contractRoot.setTcpCont(tcpCont);
            ModProdOffer svcCont = new ModProdOffer();
            svcCont.setProdOfferId("1300822");
            svcCont.setServiceId("1");
            svcCont.setChannelId("1");
            svcCont.setCityCode("360");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ModProdOffer.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("可变更套餐信息查询接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("可变更套餐信息查询 接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("可变更套餐信息查询 接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 有效和预约销售品信息查询 NEU6099060043
     */
    public RestStatus offerWithStatus(OfferWithStatus svcCont,User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getAccNbr());
            interfaceData.setInterfaceName("NEU6099060043");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.OFFER_WITH_STATUS);
            contractRoot.setTcpCont(tcpCont);
            /*OfferWithStatus svcCont = new OfferWithStatus();
            svcCont.setAccNbr("1300822");
            svcCont.setProductId("1300822");
            svcCont.setCityCode("1200");
            svcCont.setReserveStatus("1");*/
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, OfferWithStatus.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("有效和预约销售品信息查询接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("有效和预约销售品信息查询接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("有效和预约销售品信息查询接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    // 获取可选包接口 NEU6099060194
    public RestStatus GetOptionalPackageServiceHandle(User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060194");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.OPTIONAL_PACKAGE);
            contractRoot.setTcpCont(tcpCont);
            OptionalPackage svcCont = new OptionalPackage();
            svcCont.setWorkNo("ADMIN");
            svcCont.setProdOfferId("1300822");
            svcCont.setFeeType("1200");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, OptionalPackage.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("获取可选包接口接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("获取可选包接口接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("获取可选包接口接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    // 呼转号码设置 NEU6099060227
    public RestStatus setCallForwardingNumberService(CallForwarding svcCont,User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = JSONUtil.objectToJson(svcCont);
            interfaceData.setMsisdn(svcCont.getAccNbr());
            interfaceData.setInterfaceName("NEU6099060227");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.CALL_FORWARDING_NUMBER);
            contractRoot.setTcpCont(tcpCont);
            /*CallForwarding svcCont = new CallForwarding();
            svcCont.setAccNbr("17090041960");
            svcCont.setProductId("-1");
            svcCont.setCityCode("360");
            svcCont.setCallForwardingNumber("17090041961");
            svcCont.setCallForwardingType("01");
            svcCont.setDealflag("00");*/
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, CallForwarding.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("呼转号码设置接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("呼转号码设置接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("呼转号码设置接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    // 过户接口、预算费用 NEU6099060197
    public RestStatus changeCust(ModCustomerDTO obj, String transferId, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060197");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.CHANGE_CUST_ORDER);
            contractRoot.setTcpCont(tcpCont);
            TransUser svcCont = new TransUser();
            svcCont.setServiceId(obj.getPhone());
            svcCont.setCustId("0");
            svcCont.setExtOrderId("1000000004201405280000009852");
            svcCont.setTransferId(transferId);//1.过户 2.实名补录
            CustInfoVO custInfoVO = new CustInfoVO();
            custInfoVO.setWorkNo("ADMIN");
            custInfoVO.setCustName(obj.getName());
            custInfoVO.setIdentityCode(obj.getCode());
            custInfoVO.setIdentityKind("1");
            custInfoVO.setIdentityAddress(obj.getAddress());
            custInfoVO.setCityCode("360");
            custInfoVO.setLinkMan(obj.getName());
            custInfoVO.setLinkPhone(obj.getPhone());
            custInfoVO.setCommuAddress(obj.getAddress());
            custInfoVO.setFontImage(" ");
            custInfoVO.setBackImage(" ");
            custInfoVO.setGroupImage(" ");
            svcCont.setCustInfoVO(custInfoVO);
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, TransUser.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("过户接口、预算费用接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("过户接口、预算费用接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("过户接口、预算费用接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    // 提交订单 NEU6099060116
    public RestStatus doCompleteOrder(String custOrderId, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName(ServiceCodeConstant.COMPLETE_ORDER);
            interfaceData.setRequestContent(custOrderId);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.COMPLETE_ORDER);
            contractRoot.setTcpCont(tcpCont);
            CompleteOrder svcCont = new CompleteOrder();
            svcCont.setCustOrderId(custOrderId);
            svcCont.setWorkNo("admin");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, CompleteOrder.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("提交订单接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("提交订单接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("提交订单接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    // 删除订单 NEU6099060117
    public RestStatus doDeleteOrder(String custOrderId, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060117");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.DELETE_ORDER);
            contractRoot.setTcpCont(tcpCont);
            CompleteOrder svcCont = new CompleteOrder();
            svcCont.setCustOrderId(custOrderId);
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, CompleteOrder.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("删除订单接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("删除订单接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("删除订单接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    // 销户 NEU6099060224
    public RestStatus AccountCancellationService(User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060224");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.ACCOUNT_CANCELLACTION);
            contractRoot.setTcpCont(tcpCont);
            AccountCancellation svcCont = new AccountCancellation();
            svcCont.setProductId("100110");
            svcCont.setServiceId("17091504441");
            svcCont.setCityCode("360");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, AccountCancellation.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("销户接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("销户接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("销户接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    //3G转4G NEU6099060231
    public RestStatus ThreeGTurn4GService(User user){
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("NEU6099060231");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.THREEG_TO_4G);
            contractRoot.setTcpCont(tcpCont);
            ThreeGTurnFourGVO svcCont = new ThreeGTurnFourGVO();
            svcCont.setThreegProdOfferId("");
            svcCont.setThreegServiceOfferId("");
            svcCont.setFourgProdOfferId("");
            svcCont.setFourgServiceOfferId("");
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ThreeGTurnFourGVO.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("3G转4G(3GTurn4GService)接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("3G转4G(3GTurn4GService)接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("3G转4G(3GTurn4GService)接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    //2.2.33    资源池转模组校验NEU6099060232
    public RestStatus CheckProductIdIfEqualService(User user,String phone, String newMainProdOfferId){
        RestStatus res = new RestStatus();
        res.setStatus(true);
        
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            interfaceData.setMsisdn(phone);
            interfaceData.setInterfaceName("NEU6099060232");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.CHECK_PRODUCT_ID_IF_EQUAL);
            contractRoot.setTcpCont(tcpCont);
            CheckProductIdIfEqual svcCont = new CheckProductIdIfEqual();
            svcCont.setServiceId(phone);
            svcCont.setNewMainProdOfferId(newMainProdOfferId);
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, CheckProductIdIfEqual.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("资源池转模组CheckProductIdIfEqualService校验接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("资源池转模组CheckProductIdIfEqualService校验接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("资源池转模组CheckProductIdIfEqualService校验接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    /**
     * 流量使用查询
     * @param user
     * @return
     */
    public RestStatus flowUseQuery(User user) {
        RestStatus res = new RestStatus(true);
        // TODO 流量查询
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            //interfaceData.setMsisdn(number.getPhone());
            interfaceData.setInterfaceName("流量去向查询");
            //interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            String backUrl = "http://192.168.12.61:9998/basic_service/revoke_support/v1?BJN2GP17D121WKnY5pvU3ZXSTuFIEwRvk5iiRVOYXTUySHI2";
            String json = "{\"mvnokey\":\"Z2XnSTq\",\"serial_number\":\"cOKD31n20140101101937816x93z92\",\"timestamp\":\"2014-01-01 10:19:37\""
                    + ",\"service_type\":\"basic_service\",\"service_name\":\"revoke_support\""
                    + ",\"api_name\":\"cu.vop.basic_service.revoke_support\",\"data\":{\"support_id\":\"cOKD31n20140101101937816x93z921111\",\"reason\":\"aaaa\"}}";
            String result = InterfaceUtil.getInstance().callInvoke(backUrl, json);
            System.out.println("result--->"+result);
            
            interfaceData.setResponseContent(result);
            res.setResponseData(result);
        }catch(Exception e){
            res.setErrorMessage("流量去向查询,接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("流量去向查询,接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("流量去向查询,接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        
        return res;
    }

    /**
     * 强停、强开接口
     * 4 强制停机
        5 强制开机
     * @param request
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus forceStopDeal(ForceStopDealRequest request, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        // TODO 强停强开
        logger.error("----------------------------- 号码：" + request.getServiceId() + "强停、强开接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            Date requestTime = new Date();
            request.setRequestId(Utils.getRandomString(10));
            request.setSystemId("0001");
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(request);
            interfaceData.setMsisdn(request.getServiceId());
            interfaceData.setInterfaceName("ForceStopDeal");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
            url = String.format(url, "ForceStopDealSOAP");
            Client client = getClient(url);
            Object[] r = client.invoke("NewOperation", request);
            ForceStopDealResponse resp = (ForceStopDealResponse)r[0];
            if (!"0".equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getResultInfo());
                logger.error("强停、强开接口调用错误:phone=" + request.getServiceId() + ",原因：" + resp.getResultInfo());
            }
            res.setResponseData(resp);
            
            // 把出参对象转换成xml格式的字符串
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("强停、强开接口调用接口错误：phone=" + request.getServiceId() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + request.getServiceId() + "强停、强开接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    // 2.2.22   开通关闭短信，上网功能 NEU6099060226
    public RestStatus doProductChange(String phone, List<ProductChangeVO> list, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        // TODO 开通、关闭---->短信、上网
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try{
            // 把入参对象转换成xml格式的字符串
            //String reqeustContent = JSONUtil.objectToJson(number);
            interfaceData.setMsisdn(phone);
            interfaceData.setInterfaceName("NEU6099060226");
            interfaceData.setRequestContent(list.get(0).toString());
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            } 
            
            ContractRoot contractRoot = new ContractRoot();
            TcpCont tcpCont = initTcpCont(ServiceCodeConstant.DO_PRODUCT_CHANGE);
            contractRoot.setTcpCont(tcpCont);
            
            ProductChangeVO svcCont = new ProductChangeVO();
            svcCont.setServiceId(phone);
            svcCont.setCityCode("360");
            svcCont.setProductChangeList(list);
            
            contractRoot.setSvcCont(svcCont);
            ContractRoot root = exec(contractRoot, ProductChangeVO.class.getSimpleName());
            
            String responseContent = JSONUtil.objectToJson(root);
            interfaceData.setResponseContent(responseContent);
            if("0000".equals(root.getTcpCont().getResponse().getRspCode())){
                interfaceData.setStatus(1);
                res.setStatus(Boolean.TRUE);
            }else{
                interfaceData.setStatus(0);
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(root.getTcpCont().getResponse().getRspDesc());
            }
            res.setResponseData(root);
        }catch(Exception e){
            res.setErrorMessage("开通关闭短信，上网功能接口失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("开通关闭短信，上网功能接口错误，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("开通关闭短信，上网功能接口错误，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        logger.error(interfaceData.toString());
        interfaceDataService.insert(interfaceData);
        return res;
    }
    
    private TcpCont initTcpCont(String busCode) {
        TcpCont tcpCont = new TcpCont();
        tcpCont.setBusCode(busCode);
        tcpCont.setServiceCode(busCode);
        tcpCont.setServiceContractVer(busCode+DateUtil.getInstance().formatDate(new Date(), "yyyyMMdd"));
        tcpCont.setActionCode("0");
        tcpCont.setTransactionID(Utils.getRandomString(28));
        tcpCont.setServiceLevel("1");
        tcpCont.setSrcOrgID("100001");
        tcpCont.setSrcSysID("1000000001");//1000000088
        tcpCont.setDstOrgID("100000");
        tcpCont.setDstSysID("1000000000");
        tcpCont.setReqTime(DateUtil.getInstance().formatDate(new Date(), "yyyyMMddHHmmss"));
        Com_Bus_Info comBusInfo = new Com_Bus_Info();
        comBusInfo.setOper_Id("ADMIN");
        tcpCont.setCom_Bus_Info(comBusInfo);
        return tcpCont;
    }
    
    private ContractRoot exec(ContractRoot contractRoot, String replaceSvcStr) throws Exception{
        logger.error("----------------------------- 调用接口：" + contractRoot.getTcpCont().getBusCode() + "，号码："+contractRoot.getSvcCont().getServiceId()+"，开始时间：" + System.nanoTime() + "-----------------------------");
        
        URL wsdlURL = CrmSpsService.WSDL_LOCATION;
        CrmSpsService ss = new CrmSpsService(wsdlURL, CrmSpsService.SERVICE);
        CrmSpsServicePortType port = ss.getCrmSpsServiceHttpPort();  
        
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);
        xstream.addDefaultImplementation(contractRoot.getClass(), ContractRoot.class);
        Writer writer = new StringWriter();
        xstream.marshal(contractRoot, new CompactWriter(writer));
        String reqeustContent = writer.toString();
        reqeustContent = reqeustContent.replaceAll("namespace.webservice.crmsps.", "");//
        reqeustContent = reqeustContent.replaceAll("__", "_");
        if(replaceSvcStr!=null && !"".equals(replaceSvcStr)){
            reqeustContent = reqeustContent.replaceAll(" class=\""+replaceSvcStr+"\"", "");
        }
        // 3G转4G特殊字段转换,原因：JAVA变量不能以数字开头
        String busCode = contractRoot.getTcpCont().getBusCode();
        if(ServiceCodeConstant.THREEG_TO_4G.equals(busCode)){
            reqeustContent = reqeustContent.replace("threegProdOfferId", "3gProdOfferId")
                    .replace("threegServiceOfferId", "3gServiceOfferId")
                    .replace("fourgProdOfferId", "4gProdOfferId")
                    .replace("fourgServiceOfferId", "4gServiceOfferId")
                    .replace("ProdOfferVOList", "ProdOfferList");
        }
        if(ServiceCodeConstant.MOD_OPTIONAL_OFFER.equals(busCode)){
            reqeustContent = reqeustContent.replace("ProdOfferVOList", "ProdOfferList");
        }
        
        logger.info("入参2：--->\n"+reqeustContent);
        
        java.lang.String _exchange__return = port.exchange(reqeustContent);
        //_exchange__return = _exchange__return.replaceAll("com.neusoft.crm.ordermgr.business.orderservice.bo.query.data.", "");
        logger.info("出参：--->\n" + _exchange__return);
        if(ServiceCodeConstant.OFFER_WITH_STATUS.equals(contractRoot.getTcpCont().getBusCode())){
            _exchange__return = _exchange__return.replace("ProdOfferVO", "ProdOfferListVO");
            logger.info("替换后出参：--->\n" + _exchange__return);
        }
        XStream xstream1 = new XStream();
        xstream1.alias("ContractRoot", ContractRoot.class); 
        xstream1.alias("TcpCont", TcpCont.class); 
        xstream1.alias("SvcCont", SvcCont.class); 
        xstream1.alias("com.neusoft.crm.ordermgr.business.orderservice.bo.query.data.PackageInfo", PackageInfo.class); 
        xstream1.alias("com.neusoft.crm.ordermgr.business.orderservice.bo.query.data.SubOfferProdList", PackageInfo.class); 
        xstream1.alias("ProdOfferListVO", ProdOfferListVO.class); 
        ContractRoot root = (ContractRoot) xstream1.fromXML(_exchange__return);
        logger.info("result:"+root.getTcpCont().getActionCode()+"--->"+root.getTcpCont().getResponse().getRspCode());
        
        logger.error("----------------------------- 调用接口：" + contractRoot.getTcpCont().getBusCode() + "，号码："+contractRoot.getSvcCont().getServiceId()+"，结束时间：" + System.nanoTime() + "-----------------------------");
        return root;
    }
    
    private Client getClient(String url) {
        JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
        Client client = factory.createClient(url);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());
        return client;
    }
    
    /**
     * 账务充值接口
     * @param request
     * @return
     */
    public RestStatus paymentBank(PaymentBankRequest request, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        logger.error("----------------------------- 号码：" + request.getServiceId() + "账务充值接口调用开始, 时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        try{
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(request);
            interfaceData.setMsisdn(request.getServiceId());
            interfaceData.setInterfaceName("PaymentBankSOAP");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if (null == user) {
                interfaceData.setOperatorId(0);
            } else {
                interfaceData.setOperatorId(user.getId());
            }
            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
            // 这里的url里有变量，需要根据不同的业务进行格式化
            url = String.format(url, "PaymentBankSOAP");
            Client client = getClient(url);
            Object[] obj = client.invoke("execute", request);
            PaymentBankResponse resp = (PaymentBankResponse) obj[0];
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if ("0".equals(resp.getResultCode())) {
                interfaceData.setStatus(1);
                res.setResponseData(resp);
            } else {
                interfaceData.setStatus(0);
                res.setStatus(false);
                res.setErrorMessage("["+resp.getResultCode()+"]"+resp.getResultInfo().getValue());
                interfaceData.setResponseContent("账务充值接口错误：phone=" + request.getServiceId() 
                        + "，原因：["+resp.getResultCode()+"]"+resp.getResultInfo().getValue());
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("账务充值接口错误：phone=" + request.getServiceId() + "，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("----------------------------- 号码：" + request.getServiceId() + "账务充值接口调用完成, 时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        return res;
    }
    
    /**
     * 实时话费查询接口
     * @param request
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus userMonthFeeList(UserMonthFeeListRequest request, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + request.getServiceId() + "实时话费查询接口调用 ,时间："
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            request.setRequestId(Utils.getRandomString(10));
            request.setSystemId("0001");
            request.setServiceKind(8);
            
            Date requestTime = new Date();
            
            // 组装接口日志对象
            interfaceData.setMsisdn(request.getServiceId());
            interfaceData.setInterfaceName("UserMonthFeeList");
            interfaceData.setRequestContent(JSONUtil.objectToJson(request));
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
            url = String.format(url, "UserMonthFeeListSOAP");
            Client client = getClient(url);
            Object[] r = client.invoke("execute", request);
            UserMonthFeeListResponse resp = (UserMonthFeeListResponse)r[0];
            if (!"0".equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getResultInfo());
                logger.error("套餐使用查询接口调用错误:phone=" + request.getServiceId() + ",原因：" + resp.getResultInfo());
            }
            res.setResponseData(resp);
            
            // 把出参对象转换成xml格式的字符串
            interfaceData.setResponseContent(JSONUtil.objectToJson(resp));
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("实时话费查询接口调用接口错误：phone=" + request.getServiceId() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + request.getServiceId() + "实时话费查询接口调用完成,时间："
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        return res;
    }
    
    public RestStatus payOutFeeDeal(PayOutFeeDealRequest request, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        try {
            request.setRequestId(Utils.getRandomString(10));
            request.setSystemId("0005");
            request.setFeeKind("9001");
            request.setOperatorNo("ADMIN");
            
            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
            // 这里的url里有变量，需要根据不同的业务进行格式化
            url = String.format(url, "PayOutFeeDealSOAP");
            Client client = getClient(url);
            Object[] obj = client.invoke("NewOperation", request);
            PayOutFeeDealResponse resp = (PayOutFeeDealResponse) obj[0];
            if ("0".equals(resp.getResultCode())) {
                res.setResponseData(resp);
            } else {
                res.setStatus(false);
                if (Utils.isEmptyString(resp.getResultCode())) {
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                } else {
                    res.setErrorMessage(resp.getResultInfo());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
        }
        return res;
    }
    
    /**
     * 套餐使用查询接口
     * @param request
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus productUsedQuery(ProductUsedQueryRequest request, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + request.getServiceId() + "套餐使用查询接口调用 ,时间："
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            request.setRequestId(Utils.getRandomString(10));
            request.setSystemId("0003");
            request.setUserId(0);
            request.setServiceKind(8);
            
            Date requestTime = new Date();
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(request);
            interfaceData.setMsisdn(request.getServiceId());
            interfaceData.setInterfaceName("ProductUsedQuery");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
            url = String.format(url, "ProductUsedQuerySOAP");
            Client client = getClient(url);
            Object[] r = client.invoke("execute", request);
            ProductUsedQueryResponse resp = (ProductUsedQueryResponse)r[0];
            if (!"0".equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                res.setErrorMessage(resp.getResultInfo().getValue());
                logger.error("套餐使用查询接口调用错误:phone=" + request.getServiceId() + ",原因：" + resp.getResultInfo().getValue());
            }
            res.setResponseData(resp);
            
            // 把出参对象转换成xml格式的字符串
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("套餐使用查询接口调用接口错误：phone=" + request.getServiceId() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + request.getServiceId() + "套餐使用查询BOSS接口调用完成,时间："
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        return res;
    }
}
