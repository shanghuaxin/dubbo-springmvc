package com.agent.common;

import java.util.Date;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.businesslog.entity.InterfaceData;
import com.agent.businesslog.service.InterfaceDataService;
import com.agent.order.common.util.Utils;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.SysConfig;
import com.agent.util.XMLUtil;

import zsmart.ztesoft.com.xsd.TCoerciveBlockBOSSBO;
import zsmart.ztesoft.com.xsd.TCoerciveBlockBOSSResponse;
import zsmart.ztesoft.com.xsd.TCoerciveReactBOSSBO;
import zsmart.ztesoft.com.xsd.TCoerciveReactBOSSResponse;
import zsmart.ztesoft.com.xsd.TDataPlanServiceRequest;
import zsmart.ztesoft.com.xsd.TDataPlanServiceResponse;
import zsmart.ztesoft.com.xsd.TDeductFeeBOSSBO;
import zsmart.ztesoft.com.xsd.TDeductFeeBOSSBOResponse;
import zsmart.ztesoft.com.xsd.TDuplicateSIMCardBOSSBO;
import zsmart.ztesoft.com.xsd.TDuplicateSIMCardBOSSBOResponse;
import zsmart.ztesoft.com.xsd.TGPRSSwitchRequest;
import zsmart.ztesoft.com.xsd.TGPRSSwitchResponse;
import zsmart.ztesoft.com.xsd.TLostOrRestoreBO;
import zsmart.ztesoft.com.xsd.TLostOrRestoreBOResponse;
import zsmart.ztesoft.com.xsd.TMMSSwitchRequest;
import zsmart.ztesoft.com.xsd.TMMSSwitchResponse;
import zsmart.ztesoft.com.xsd.TModCustomerBOSSBO;
import zsmart.ztesoft.com.xsd.TModCustomerBOSSBOResponse;
import zsmart.ztesoft.com.xsd.TNewConnectionBOSSRequest;
import zsmart.ztesoft.com.xsd.TNewConnectionBOSSResponse;
import zsmart.ztesoft.com.xsd.TPackageChangeRequestOrCancellRequest;
import zsmart.ztesoft.com.xsd.TPackageChangeRequestOrCancellResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBO;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBOResponse;
import zsmart.ztesoft.com.xsd.TSMSSwitchRequest;
import zsmart.ztesoft.com.xsd.TSMSSwitchResponse;
import zsmart.ztesoft.com.xsd.TSetForwardNumberBO;
import zsmart.ztesoft.com.xsd.TSetForwardNumberBOResponse;
import zsmart.ztesoft.com.xsd.TSetIncomingCallServiceBOSSBO;
import zsmart.ztesoft.com.xsd.TSetIncomingCallServiceBOSSResponse;
import zsmart.ztesoft.com.xsd.TUnificationDataPlanServiceRequest;
import zsmart.ztesoft.com.xsd.TUnificationDataPlanServiceResponse;
import zsmart.ztesoft.com.xsd.TUserServiceQryRequest;
import zsmart.ztesoft.com.xsd.TUserServiceQryResponse;

@Service

public class BOSSNewBuyService {
    private static Logger logger = (Logger) LoggerFactory.getLogger(BOSSNewBuyService.class);

    private static final String SUCCESS = "0000";
    
    @Autowired
    private InterfaceDataService interfaceDataService;


    private Client getClient(String url) {
        JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
        Client client = factory.createClient(url);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());
        return client;
    }
    
    /**
     * boss新接口查询用户信息
     * @param bo
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus QueryUserProfileBOSS(TQueryUserProfileRequestBO bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("号码：" + bo.getMSISDN() + "信息查询BOSS接口调用 ,时间：" + DateUtil.getInstance().getDateStr(new Date(),"yyyy-MM-dd HH:mm:ss"));
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("QueryUserProfileBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            if(null == user){
                interfaceData.setOperatorId(0);
            }else{
                interfaceData.setOperatorId(user.getId());
            }

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TQueryUserProfile4BaseBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("QueryUserProfileBOSS", bo);
                resp = (TQueryUserProfile4BaseBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TQueryUserProfile4BaseBOResponse();
                resp.setMSISDN(bo.getMSISDN());
                resp.setState("A");
                resp.setCertNbr("412724199109031838");
                resp.setCustName("付五杰");
                resp.setResultCode("0000");
                resp.setBal("0");
                resp.setSubsPlanCode("xcool2");
                resp.setSubsPlanName("酷2");
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
                
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setErrorMessage("查询号码信息失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("号码信息查询接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("号码信息查询接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("号码：" + bo.getMSISDN() + "信息查询BOSS接口调用完成,时间：" + DateUtil.getInstance().getDateStr(new Date(),"yyyy-MM-dd HH:mm:ss"));
        return res;
    }
    
    /**
     * 号码来电显示，提醒开关BOSS接口调用
     * 
     * @param callbo
     * @return
     */
    public RestStatus SetIncomingCallServiceBOSS(TSetIncomingCallServiceBOSSBO callbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + callbo.getMSISDN() + "来电显示，提醒开关BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(callbo);
            interfaceData.setMsisdn(callbo.getMSISDN());
            interfaceData.setInterfaceName("SetIncomingCallServiceBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TSetIncomingCallServiceBOSSResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("SetIncomingCallServiceBOSS", callbo);
                resp = (TSetIncomingCallServiceBOSSResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TSetIncomingCallServiceBOSSResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("号码来电显示，提醒开关BOSS接口调用接口错误：phone=" + callbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("号码来电显示，提醒开关BOSS接口调用接口错误：phone=" + callbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + callbo.getMSISDN() + "来电显示，提醒开关BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 流量包
     * 
     * @param planbo
     * @return
     */
    public RestStatus DataPlanService(TDataPlanServiceRequest planbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + planbo.getMSISDN() + "流量包订购BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(planbo);
            interfaceData.setMsisdn(planbo.getMSISDN());
            interfaceData.setInterfaceName("DataPlanService");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TDataPlanServiceResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("DataPlanService", planbo);
                resp = (TDataPlanServiceResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TDataPlanServiceResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("流量包订购接口调用接口错误：phone=" + planbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("流量包订购接口调用接口错误：phone=" + planbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + planbo.getMSISDN() + "流量包订购BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }
    
    /**
     * 融合流量包
     * 
     * @param uplanbo
     * @return
     */
    public RestStatus UnificationDataPlanService(TUnificationDataPlanServiceRequest uplanbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + uplanbo.getMSISDN() + "融合流量包订购BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(uplanbo);
            interfaceData.setMsisdn(uplanbo.getMSISDN());
            interfaceData.setInterfaceName("UnificationDataPlanService");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TUnificationDataPlanServiceResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("UnificationDataPlanService", uplanbo);
                resp = (TUnificationDataPlanServiceResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TUnificationDataPlanServiceResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("融合流量包订购接口调用接口错误：phone=" + uplanbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("融合流量包订购接口调用接口错误：phone=" + uplanbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + uplanbo.getMSISDN() + "融合流量包订购BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 强制复机
     * 
     * @param recatbo
     * @return
     */
    public RestStatus CoerciveReactBOSS(TCoerciveReactBOSSBO recatbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + recatbo.getMSISDN() + "强制复机BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(recatbo);
            interfaceData.setMsisdn(recatbo.getMSISDN());
            interfaceData.setInterfaceName("CoerciveReactBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TCoerciveReactBOSSResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("CoerciveReactBOSS", recatbo);
                resp = (TCoerciveReactBOSSResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TCoerciveReactBOSSResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("复机接口调用接口错误：phone=" + recatbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("复机接口调用接口错误：phone=" + recatbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + recatbo.getMSISDN() + "强制复机BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }

    /**
     * 强制停机
     * 
     * @param blockbo
     * @return
     */
    public RestStatus CoerciveBlockBOSS(TCoerciveBlockBOSSBO blockbo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + blockbo.getMSISDN() + "强制停机BOSS接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(blockbo);
            interfaceData.setMsisdn(blockbo.getMSISDN());
            interfaceData.setInterfaceName("CoerciveBlockBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TCoerciveBlockBOSSResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("CoerciveBlockBOSS", blockbo);
                resp = (TCoerciveBlockBOSSResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TCoerciveBlockBOSSResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("强制停机接口调用接口错误：phone=" + blockbo.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("强制停机接口调用接口错误：phone=" + blockbo.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("强制停机接口调用接口错误：phone=" + blockbo.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + blockbo.getMSISDN() + "强制停机BOSS接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }

    /***
     * 查询用户订购业务信息
     * @param bo
     * @param user
     * @return
     */
    public RestStatus UserServiceQry(TUserServiceQryRequest bo, User user) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "查询用户订购业务信息BOSS接口调用 ,时间：" + System.nanoTime()
                + "------------"+DateUtil.getInstance().getDateStr(new Date(),DateUtil.yyyyMMddHHmmss)+"-----------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("UserServiceQry");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TUserServiceQryResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("UserServiceQry", bo);
                resp = (TUserServiceQryResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TUserServiceQryResponse();
                resp.setResultCode("0000");
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage("查询用户订购业务信息BOSS查询号码失败："+e.getMessage());
            logger.error("查询用户订购业务信息接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "查询用户订购业务信息BOSS接口调用完成,时间：" + System.nanoTime()
                + "-------------"+DateUtil.getInstance().getDateStr(new Date(),DateUtil.yyyyMMddHHmmss)+"----------------");
        return res;
    }

    
    /**
     * 号码开户
     *  
     * @param bo
     * @return
     */
    public RestStatus NewConnectionBOSS(TNewConnectionBOSSRequest bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "号码开户BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("NewConnectionBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TNewConnectionBOSSResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("NewConnectionBOSS", bo);
                resp = (TNewConnectionBOSSResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TNewConnectionBOSSResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
            
            logger.error("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "号码开户BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 号码过户
     * 
     * @param bo
     * @return
     */
    public RestStatus ModCustomerBOSS(TModCustomerBOSSBO bo, String type, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        if("1".equals(type)){
            logger.error("----------------------------- 号码：" + bo.getMSISDN() + "预开卡号码开户开始调用接口 ,时间：" + System.nanoTime()
            + "-----------------------------");
        }else {
            logger.error("----------------------------- 号码：" + bo.getMSISDN() + "预开卡号码过户开始调用接口 ,时间：" + System.nanoTime()
            + "-----------------------------");
        }
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            if("1".equals(type)){
                interfaceData.setInterfaceName("NewConnectionBOSS");
            }else {
                interfaceData.setInterfaceName("ModCustomerBOSS");
            }
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TModCustomerBOSSBOResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("ModCustomerBOSS", bo);
                resp = (TModCustomerBOSSBOResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TModCustomerBOSSBOResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            if("1".equals(type)){
                interfaceData.setResponseContent("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
                logger.error("号码开户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            }else {
                interfaceData.setResponseContent("号码过户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage());
                logger.error("号码过户接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            }
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        if("1".equals(type)){
            logger.error("-----------------------------号码：" + bo.getMSISDN() + "预开卡号码开户接口调用完成,时间：" + System.nanoTime()
            + "-----------------------------");
        }else {
            logger.error("-----------------------------号码：" + bo.getMSISDN() + "预开卡号码过户接口调用完成,时间：" + System.nanoTime()
            + "-----------------------------");
        }
        return res;
    }
    
    /**
     * 号码充话费
     * 
     * @param rechargeBO
     * @return
     */
    public RestStatus RechargeBOSS(TRechargeBOSSBO rechargeBO, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + rechargeBO.getMSISDN() + "号码充话费BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            Date requestTime = new Date();
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(rechargeBO);
            interfaceData.setMsisdn(rechargeBO.getMSISDN());
            interfaceData.setInterfaceName("RechargeBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 把出参对象转换成xml格式的字符串
            interfaceData.setResponseTime(new Date());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNewURL");
            Client client = getClient(url);
            Object[] r = client.invoke("RechargeBOSS", rechargeBO);
            TRechargeBOSSBOResponse resp = (TRechargeBOSSBOResponse)r[0];
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("号码充话费BOSS接口调用接口错误：phone=" + rechargeBO.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + rechargeBO.getMSISDN() + "号码充话费BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 6.1.1.23    扣费接口（第一批）
     * 
     * @param bo
     * @return
     */
    public RestStatus DeductFeeBOSS(TDeductFeeBOSSBO bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "扣费BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            Date requestTime = new Date();
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("DeductFeeBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 把出参对象转换成xml格式的字符串
            interfaceData.setResponseTime(new Date());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNewURL");
            Client client = getClient(url);
            Object[] r = client.invoke("DeductFeeBOSS", bo);
            TDeductFeeBOSSBOResponse resp = (TDeductFeeBOSSBOResponse)r[0];
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("扣费BOSS接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "扣费BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 6.1.1.19 换卡（第一批）
     * 
     * @param bo
     * @return
     */
    public RestStatus DuplicateSIMCardBOSS(TDuplicateSIMCardBOSSBO bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "补换卡BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            Date requestTime = new Date();
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("DuplicateSIMCardBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 把出参对象转换成xml格式的字符串
            interfaceData.setResponseTime(new Date());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNewURL");
            Client client = getClient(url);
            Object[] r = client.invoke("DuplicateSIMCardBOSS", bo);
            TDuplicateSIMCardBOSSBOResponse resp = (TDuplicateSIMCardBOSSBOResponse)r[0];
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("号码补换卡BOSS接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "补换卡BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    /**
     * 无条件呼转
     * @param bo
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus SetForwardNumber(TSetForwardNumberBO bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "无条件呼转接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("SetForwardNumber");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            TSetForwardNumberBOResponse resp;
            String url = SysConfig.getValue("WebServiceURL");
            Client client = getClient(url);
            Object[] response = client.invoke("SetForwardNumber", bo);
            resp = (TSetForwardNumberBOResponse) response[0];
            // 把出参对象转换成xml格式的字符串
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if (!"0".equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setErrorMessage("无条件呼转失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("无条件呼转接口错误：phone=" + bo.getMSISDN() + "，error=" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("无条件呼转接口错误：phone=" + bo.getMSISDN() + "，error=" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "无条件呼转接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }
    /**
     * 6.1.2.7  挂失解挂接口
     * 
     * @param bo
     * @return
     */
    public RestStatus LostOrRestore(TLostOrRestoreBO bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "挂失解挂BOSS接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            Date requestTime = new Date();
            
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("LostOrRestore");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());
            // 把出参对象转换成xml格式的字符串
            interfaceData.setResponseTime(new Date());
            // 成功
            interfaceData.setStatus(1);
            
            String url = SysConfig.getValue("WebServiceNewURL");
            Client client = getClient(url);
            Object[] r = client.invoke("LostOrRestore", bo);
            TLostOrRestoreBOResponse resp = (TLostOrRestoreBOResponse)r[0];
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("号码挂失解挂BOSS接口调用接口错误：phone=" + bo.getMSISDN() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "挂失解挂BOSS接口调用完成,时间："
                + System.nanoTime() + "-----------------------------");
        return res;
    }
    /**
     * 套餐变更
     * @param bo
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus PackageChangeRequestOrCancell(TPackageChangeRequestOrCancellRequest bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + bo.getMSISDN() + "套餐变更接口调用 ,时间：" + System.nanoTime()
                + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(bo);
            interfaceData.setMsisdn(bo.getMSISDN());
            interfaceData.setInterfaceName("PackageChangeRequestOrCancell");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            TPackageChangeRequestOrCancellResponse resp;
            String url = SysConfig.getValue("WebServiceNewURL");
            Client client = getClient(url);
            Object[] response = client.invoke("PackageChangeRequestOrCancell", bo);
            resp = (TPackageChangeRequestOrCancellResponse) response[0];
            // 把出参对象转换成xml格式的字符串
            String responseContent = xMLUtil.tranObjToXML(resp);
            interfaceData.setResponseContent(responseContent);
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setErrorMessage("套餐变更失败！");
            res.setStatus(Boolean.FALSE);
            logger.error("套餐变更接口错误：phone=" + bo.getMSISDN() + "，error=" + e.getMessage(), e);
            e.printStackTrace();
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("套餐变更接口错误：phone=" + bo.getMSISDN() + "，error=" + e.getMessage());
        }
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(new Date());
        interfaceDataService.insert(interfaceData);
        logger.error("-----------------------------号码：" + bo.getMSISDN() + "套餐变更接口调用完成,时间：" + System.nanoTime()
                + "-----------------------------");
        return res;
    }
    
    /**
     * 短信功能0关1开
     * @param smsRequest
     * @param user
     * @return
     */
    public RestStatus smsSwitch(TSMSSwitchRequest smsRequest, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + smsRequest.getMSISDN() + "短信功能BOSS接口调用 ,时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(smsRequest);
            interfaceData.setMsisdn(smsRequest.getMSISDN());
            interfaceData.setInterfaceName("SMSSwitch");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TSMSSwitchResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("SMSSwitch", smsRequest);
                resp = (TSMSSwitchResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TSMSSwitchResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("短信功能接口调用接口错误：phone=" + smsRequest.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("短信功能接口调用接口错误：phone=" + smsRequest.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("短信功能接口调用接口错误：phone=" + smsRequest.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + smsRequest.getMSISDN() + "短信功能BOSS接口调用完成,时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        return res;
    }
    
    /**
     * 彩信功能0关1开
     * @param smsRequest
     * @param user
     * @return
     */
    public RestStatus mmsSwitch(TMMSSwitchRequest mmsRequest, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + mmsRequest.getMSISDN() + "彩信功能BOSS接口调用 ,时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(mmsRequest);
            interfaceData.setMsisdn(mmsRequest.getMSISDN());
            interfaceData.setInterfaceName("SMSSwitch");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TMMSSwitchResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("MMSSwitch", mmsRequest);
                resp = (TMMSSwitchResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TMMSSwitchResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("彩信功能接口调用接口错误：phone=" + mmsRequest.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("彩信功能接口调用接口错误：phone=" + mmsRequest.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("彩信功能接口调用接口错误：phone=" + mmsRequest.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + mmsRequest.getMSISDN() + "彩信功能BOSS接口调用完成,时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        return res;
    }
    
    /**
     * 上网功能0关1开
     * @param smsRequest
     * @param user
     * @return
     */
    public RestStatus gprsSwitch(TGPRSSwitchRequest gprsSwitchRequest, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        logger.error("----------------------------- 号码：" + gprsSwitchRequest.getMSISDN() + "上网功能BOSS接口调用 ,时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        Date requestTime = new Date();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(gprsSwitchRequest);
            interfaceData.setMsisdn(gprsSwitchRequest.getMSISDN());
            interfaceData.setInterfaceName("GPRSSwitch");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(requestTime);
            interfaceData.setOperatorId(user.getId());

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            TGPRSSwitchResponse resp;
            if (flag != null && flag.equals("true")) {
                String url = SysConfig.getValue("WebServiceNewURL");
                Client client = getClient(url);
                Object[] response = client.invoke("GPRSSwitch", gprsSwitchRequest);
                resp = (TGPRSSwitchResponse) response[0];
                // 把出参对象转换成xml格式的字符串
                String responseContent = xMLUtil.tranObjToXML(resp);
                interfaceData.setResponseContent(responseContent);
            }else{
                resp = new TGPRSSwitchResponse();
                interfaceData.setResponseContent("没有调用接口");
            }
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(Utils.isEmptyString(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
            // 成功
            interfaceData.setStatus(1);
            res.setResponseData(resp);
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent("上网功能接口调用接口错误：phone=" + gprsSwitchRequest.getMSISDN() + "，原因：" + e.getMessage());
            logger.error("上网功能接口调用接口错误：phone=" + gprsSwitchRequest.getMSISDN() + "，原因：" + e.getMessage(), e);
            throw new Exception("上网功能接口调用接口错误：phone=" + gprsSwitchRequest.getMSISDN() + "，原因：" + e.getMessage());
        } finally {
            // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
            interfaceData.setResponseTime(new Date());
            interfaceDataService.insert(interfaceData);
        }
        logger.error("-----------------------------号码：" + gprsSwitchRequest.getMSISDN() + "上网功能BOSS接口调用完成,时间：" 
                + DateUtil.getInstance().formatDate(new Date(), null) + "-----------------------------");
        return res;
    }
    
    public static void main(String[] args) {
        /*TMMSSwitchRequest mmsRequest = new TMMSSwitchRequest();
        mmsRequest.setMSISDN("8617057000068");
        mmsRequest.setOperType("1");
        try {
            new BOSSNewBuyService().mmsSwitch(mmsRequest, new User());
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        
        /*TSMSSwitchRequest smsRequest = new TSMSSwitchRequest();
        smsRequest.setMSISDN("8617057000068");
        smsRequest.setOperType("1");
        try {
            new BOSSNewBuyService().smsSwitch(smsRequest, new User());
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        
        TGPRSSwitchRequest gprs = new TGPRSSwitchRequest();
        gprs.setMSISDN("8617057000068");
        gprs.setOperType("1");
        try {
            new BOSSNewBuyService().gprsSwitch(gprs, new User());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
