package com.agent.common.enumeration;

/**
 * 1：划拨进，2：加值(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，
 * 6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
 * 16:开卡冻结，17：开卡扣款，18:开卡冻结解冻扣款，19:开卡冻结解冻回退，20:开卡充值佣金，21:充值佣金转划拨
 * 22:销售佣金转划拨 23:OCR识别，24:身份核验，25:人像比对
 */
public enum OperationType {
    ALLOT_IN("划拨进", 1),
    DIRECT_RECHARGE("加值", 2),
    CORRECT_IN("纠正进", 3),
    OPEN_ACCOUNT("开卡", 4),
    ALLOT_OUT("划拨出", 9),
    CORRECT_OUT("纠正出", 10),
    RECHARGE_FLOW("充流量", 11),
    RECHARGE_FLOW_BACK("充流量回退", 12),
    RECHARGE_COST("充话费", 13),
    RECHARGE_COST_BACK("充话费回退", 14),
    REPLENISH("补货", 15),
    OPEN_ACCOUNT_FREEZE("开卡扣款", 16),
    OPEN_ACCOUNT_DEDUCT("开卡扣款", 17),
    OPEN_ACCOUNT_UNFREEZE("开卡冻结解冻扣款", 18),
    OPEN_ACCOUNT_UNFREEZE_BACK("开卡回退", 19),
    OPEN_ACCOUNT_RECHARGE_BROKERAGE("开卡充值佣金", 20),
    BROKERAGE_RECHARGE_TO_ALLOT("充值佣金转划拨", 21),
    BROKERAGE_SALE_TO_ALLOT("销售佣金转划拨", 22),
    OCR_ANALYSE("OCR识别", 23),
    OCR_ID_CHECK("身份核验", 24),
    FACE_DECRYPT("人像比对", 25),
    ;
    
    // 成员变量 
    private String name;
    private Integer id;
    // 构造方法 
    private OperationType(String name, Integer id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (OperationType ot : OperationType.values()) {
            if (ot.getId() == id) {
                return ot.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
}
