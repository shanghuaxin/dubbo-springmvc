package com.agent.common;

/**
 * 枚举统一文字资源获取
 * @author fenglu
 */
public interface BaseTextEnum {

    public String description();
}
