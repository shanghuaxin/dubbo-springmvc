package com.agent.common;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.agent.util.ConfigUtil;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class CacheRedisFactory {

    private static final Logger log = LoggerFactory.getLogger(CacheRedisFactory.class);
    private static final JedisPool pool;
    static {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxActive(ConfigUtil.getConfig("redis.maxActive", 20));
        config.setMaxIdle(ConfigUtil.getConfig("redis.maxIdle", 20));
        pool = new JedisPool(config, ConfigUtil.getConfig("redis.host"), ConfigUtil.getConfig("redis.port", 6379), 3000,
                ConfigUtil.getConfig("redis.pass"), Integer.parseInt(ConfigUtil.getConfig("redis.db")));
        CacheRedisFactory.init();
    }

    public static final void init() {
        String message = ConfigUtil.getConfig("redis.host") + ":" + ConfigUtil.getConfig("redis.port", 6379);
        try {
            if ("PONG".equalsIgnoreCase(CacheRedisOperator.ping())) {
                log.info("redis 连接成功！" + message);
            } else {
                throw new RuntimeException("redis 连接错误" + message);
            }
        } catch (Exception e) {
            log.error("redis 连接错误" + message);
            throw new RuntimeException("redis 连接错误" + message);
        }
    }

    public static final Jedis getResource() {
        return pool.getResource();
    }

    public static final void returnResource(Jedis jedis) {
        pool.returnResource(jedis);
    }

    public static final void returnBrokenResource(Jedis jedis) {
        pool.returnBrokenResource(jedis);
    }
}
