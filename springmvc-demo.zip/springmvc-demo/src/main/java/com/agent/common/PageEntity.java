package com.agent.common;

import java.io.Serializable;

public class PageEntity implements Serializable {

    private static final long serialVersionUID = -8913668325182611364L;
    // 每页显示几条记录
    private int pageSize = 10;
    // 当前页
    private int pageIndex = 1;
    // 上一页
    private int preIndex;
    // 下一页
    private int nextTndex;
    // 总记录数
    private int total;
    // 总页数(计算得到)
    private int pageCount;
    
    public PageEntity() {
        
    }
    
    public PageEntity(int pageIndex) {
        this.pageIndex = pageIndex;
    }
    
    public PageEntity(Integer pageSize, Integer pageIndex) {
        if (null == pageIndex) {
            pageIndex = 1;
        }
        if (null == pageSize) {
            pageSize = 10;
        }
        this.pageSize = pageSize;
        this.pageIndex = pageIndex;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPreIndex() {
        return preIndex;
    }

    public void setPreIndex(int preIndex) {
        this.preIndex = preIndex;
    }

    public int getNextTndex() {
        return nextTndex;
    }

    public void setNextTndex(int nextTndex) {
        this.nextTndex = nextTndex;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
        setPageCount(this.total%this.pageSize==0 ? this.total/this.pageSize : this.total/this.pageSize+1);
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
}
