package com.agent.common.enumeration;

/**
 * 状态 0：待提交 1：待回复 2：已回复  3：已归档  4：已撤回 5:待重发
 */
public enum WorkOrderStatusType {
    WAIT_SUBMIT("待提交", 0),
    WAIT_REPLY("待回复", 1),
    REPLY("已回复", 2),
    REVOKE("已撤回", 3),
    DELETE("已删除", 4),
    WAIT_RESUBMIT("待重发", 5),
    ;
    
    private String name;
    private Integer id;
    // 构造方法 
    private WorkOrderStatusType(String name, Integer id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (WorkOrderStatusType ps : WorkOrderStatusType.values()) {
            if (ps.getId().intValue() == id.intValue()) {
                return ps.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
}
