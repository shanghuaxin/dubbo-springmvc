package com.agent.common;

public enum WebResultCode {
    SUCCESS, BUSINESS_ERROR, EXCEPTION
}
