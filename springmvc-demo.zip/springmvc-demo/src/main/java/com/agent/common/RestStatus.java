package com.agent.common;

/**
 * @author auto
 */
public class RestStatus {
    private Boolean status;
    private String errorCode;
    private String errorMessage;
    private Object responseData;
    public RestStatus(){
        this.errorCode="";
        this.errorMessage="";
    }
    public RestStatus(Boolean status){
        this.status=status;
        this.errorCode="";
        this.errorMessage="";
    }
    public RestStatus(Boolean status, String errorCode, String errorMessage){
        this.status=status;
        this.errorCode=errorCode;
        this.errorMessage=errorMessage;
    }
    public RestStatus(Boolean status, String errorCode, String errorMessage, Object responseData){
        this.status=status;
        this.errorCode=errorCode;
        this.errorMessage = errorMessage;
        this.responseData =responseData;
    }
    public Boolean getStatus(){
        return status;
    }
    public void setStatus(Boolean status){
        this.status=status;
    }
    public String getErrorCode(){
        return errorCode;
    }
    public void setErrorCode(String errorCode){
        this.errorCode=errorCode;
    }
    public String getErrorMessage(){
        return errorMessage;
    }
    public void setErrorMessage(String errorMessage){
        this.errorMessage=errorMessage;
    }
    public Object getResponseData(){
        return responseData;
    }
    public void setResponseData(Object responseData){
        this.responseData = responseData;
    }
}
