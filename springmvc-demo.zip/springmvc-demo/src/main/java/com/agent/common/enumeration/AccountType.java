package com.agent.common.enumeration;

/**
 * 账户类型：1：开卡账户，2：划拨账户，3：充值账户，4：消费佣金账户，5：销售佣金账户，6：充值佣金账户
 * @author fenglu
 *
 */
public enum AccountType {
    OPEN_ACCOUNT(1), // 开卡账户
    ALLOT_ACCOUNT(2), // 划拨账户
    RECHARGE_ACCOUNT(3), // 充值账户
    CONSUME_BROKERAGE_ACCOUNT(4), // 消费佣金账户
    SALE_BROKERAGE_ACCOUNT(5), // 移动销售佣金账户
    RECHARGE_BROKERAGE_ACCOUNT(6), // 移动充值佣金账户
    SALE_BROKERAGE_UNICOM_ACCOUNT(205), // 联通销售佣金账户
    RECHARGE_BROKERAGE_UNICOM_ACCOUNT(206), // 联通充值佣金账户
    ;
    private Integer type;
    AccountType(Integer type){
        this.type = type;
    }
    /**
     * @return Returns the type.
     */
    public Integer getValue(){
        return type;
    }
}
