package com.agent.common.enumeration;

/**
 * 号码状态枚举  待分配：US01，待开户：US02，开户待确认：US03，已开户：US10,销户：US20
 */
public enum PhoneStatus {
    US01("待分配", "US01"),
    US02("待开户", "US02"),
    US03("开户待确认", "US03"),
    US10("已开户", "US10"),
    US20("销户", "US20"),
    ;
    
    private String name;
    private String id;
    // 构造方法 
    private PhoneStatus(String name, String id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(String id) {
        for (PhoneStatus ps : PhoneStatus.values()) {
            if (ps.getId().equals(id)) {
                return ps.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
}
