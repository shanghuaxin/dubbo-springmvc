package com.agent.common.enumeration;

/**
 * 联通号码等级
 */
public enum UnicomNumberLevel {
    BEST("至尊", 1),
    DIAMOND("钻石", 2),
    PLATINUM("白金", 3),
    GOLD("黄金", 4),
    SELECTED("精选", 5),
    BIRTHDAY("生日", 6),
    LOVE("爱情", 7),
    MATH_FORMULA("数学公式", 8),
    NORMAL("普通号", 11),
    POOR("差号", 12),
    ;
    
    // 成员变量 
    private String name;
    private Integer id;
    // 构造方法 
    private UnicomNumberLevel(String name, Integer id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (UnicomNumberLevel ot : UnicomNumberLevel.values()) {
            if (ot.getId() == id.intValue()) {
                return ot.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
}
