package com.agent.common;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.example.usermonthfeelist.UserMonthFeeListRequest;
import org.example.usermonthfeelist.UserMonthFeeListResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.agent.order.common.util.Utils;
import com.agent.system.entity.User;

import zsmart.ztesoft.com.xsd.TMMSSwitchRequest;
import zsmart.ztesoft.com.xsd.TMMSSwitchResponse;

@Service
public class TestService {
    private static Logger logger = (Logger) LoggerFactory.getLogger(TestService.class);
    
    private static final String SUCCESS = "0";
    
    private static Client getClient(String url) {
        JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
        Client client = factory.createClient(url);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());
        return client;
    }
    
    public RestStatus test(UserMonthFeeListRequest bo, User user) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        try {
            String url = "http://192.168.13.12:9083/billingWS/services/UserMonthFeeListSOAP?wsdl";
            Client client = getClient(url);
            Object[] r = client.invoke("UserMonthFeeList", bo);
            UserMonthFeeListResponse resp = (UserMonthFeeListResponse)r[0];
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if (Utils.isEmptyString(resp.getResultInfo())) {
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                } else {
                    res.setErrorMessage(resp.getResultInfo());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            logger.error("实时话费查询接口调用接口错误：phone=" + bo.getServiceId() + "，原因：" + e.getMessage(), e);
            e.printStackTrace();
        } 
        return res;
    }
    
    public static void main1(String[] args) {
        UserMonthFeeListRequest bo = new UserMonthFeeListRequest();
        bo.setServiceId("17057000056");
        bo.setServiceKind(1);
        bo.setFeeDate("201710");
        try {
            RestStatus res = new TestService().test(bo, new User());
            System.out.println("res.getStatus()--->"+res.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public static void main(String[] args) {
        
        /*UserMonthFeeListRequest request = new UserMonthFeeListRequest();
        request.setRequestId("123123123");
        request.setSystemId("0001");
        request.setServiceId("17001171946");
        request.setServiceKind(9);
        request.setFeeDate("201710");
        try {
            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
            url = String.format(url, "UserMonthFeeListSOAP");
            System.out.println("url--->"+url);
            //String url = "http://192.168.13.12:9083/billingWS/services/UserMonthFeeListSOAP?wsdl";
            Client client = getClient(url);
            Object[] r = client.invoke("execute", request);
            UserMonthFeeListResponse resp = (UserMonthFeeListResponse)r[0];
            if (!SUCCESS.equals(resp.getResultCode())) {
               System.out.println("error");
            }else{
                System.out.println(resp.getAcctBalanceFee());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        
        /*PaymentBankRequest request = new PaymentBankRequest();
        request.setRequestId("123123");
        request.setSystemId("0001");
        request.setServiceId("17090041961");
        request.setServiceKind(8);
        request.setPayFee(100);
        ObjectFactory objFac=new ObjectFactory();  
        JAXBElement<String> flowNumber = objFac.createPaymentBankRequestFlowNumber("");
        JAXBElement<String> notifyDate = objFac.createPaymentBankRequestNotifyDate("");
        request.setFlowNumber(flowNumber);
        request.setNotifyDate(notifyDate);
        request.setPayWay(4);
        request.setPayKind(1);
        request.setIfContinue(false);
        request.setDealerId("test");
        request.setWorkNo("test");
        request.setPresentFee(0);
        try {
//            String url = SysConfig.getValue("WebServiceNeusoftBillingURL");
//            url = String.format(url, "PaymentBankSOAP");
            String url = "http://192.168.13.12:9083/billingWS/services/PaymentBankSOAP?wsdl";
            Client client = getClient(url);
            Object[] r = client.invoke("execute", request);
            PaymentBankResponse resp = (PaymentBankResponse)r[0];
            if (!SUCCESS.equals(resp.getResultCode())) {
               System.out.println(resp.getResultCode());
               System.out.println(resp.getResultInfo().getValue());
               System.out.println(resp.getResultInfo());
            }else{
                System.out.println("WriteoffDate--->"+resp.getWriteoffDate().getValue());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        
        TMMSSwitchRequest request = new TMMSSwitchRequest();
        request.setMSISDN("8617057000023");
        request.setOperType("1");
        try {
            String url = "http://192.168.10.14:17380/SeecomBoss?wsdl";
            Client client = getClient(url);
            Object[] r = client.invoke("MMSSwitch", request);
            TMMSSwitchResponse resp = (TMMSSwitchResponse)r[0];
            
            System.out.println(resp.getResultCode());
            System.out.println(resp.getOpraDesc());
            if (!SUCCESS.equals(resp.getResultCode())) {
            } else {
            }
        } catch (Exception e) {
          e.printStackTrace();
        }
    }
}
