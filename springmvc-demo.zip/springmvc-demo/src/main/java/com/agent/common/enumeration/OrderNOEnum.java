package com.agent.common.enumeration;

public enum OrderNOEnum {
    
    //订单编码：A-**，B-业务办理
    BUSINESS_NO("业务办理编号", "B");
    
    // 成员变量 
    private String name;
    private String code;
    // 构造方法 
    private OrderNOEnum(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (OrderNOEnum ot : OrderNOEnum.values()) {
            if (ot.getCode() == code) {
                return ot.name;
            }
        }
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
