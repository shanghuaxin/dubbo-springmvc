package com.agent.common.mapper;

import com.agent.common.BaseMapper;
import com.agent.common.entity.LoginCode;

import java.util.List;
import java.util.Map;

public interface LoginCodeMapper extends BaseMapper<LoginCode, Integer> {
    public List<LoginCode> list(Map<String,Object> map);
    public int insert(LoginCode loginCode);
}
