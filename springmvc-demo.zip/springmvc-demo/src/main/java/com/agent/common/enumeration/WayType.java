package com.agent.common.enumeration;

public enum WayType {
    
    // 渠道类型：AGENT-酷商，ONLINE-网厅，AGENTAPP-酷商APP，WAP-掌厅，KF-客服
    AGENT("酷商", "AGENT"),
    AGENTAPP("酷商APP", "AGENTAPP"),
    ONLINE("网厅", "ONLINE"),
    WAP("掌厅", "WAP"),
    KF("客服", "KF"),
    ;
    
    // 成员变量 
    private String name;
    private String code;
    // 构造方法 
    private WayType(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (WayType ot : WayType.values()) {
            if (ot.getCode().equals(code)) {
                return ot.name;
            }
        }
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
