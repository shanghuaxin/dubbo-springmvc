package com.agent.common.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.api.InterfaceUtil;
import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.common.entity.LoginCode;
import com.agent.common.mapper.LoginCodeMapper;
import com.agent.system.dto.SmsResponseDTO;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.JsonUtil;
import com.agent.util.SysConfig;
import com.agent.util.Utils;

/**
 * Created by Administrator on 2016/11/9.
 */
@Transactional(rollbackFor=Exception.class)
@Service("loginCodeService")
public class LoginCodeService {
    private static Logger logger = LoggerFactory.getLogger(LoginCodeService.class);
    @Autowired
    private LoginCodeMapper smsCodeMapper;
    @Autowired
    private BusinessLogService logService;

    /**
     * 根据号码获取短信验证码
     * @param phone
     * @param source
     * @return
     * @throws Exception
     */
    public Map<String, Object> smsCode(User us,String phone, String source) throws Exception{
        Map<String, Object> map = new HashMap<String, Object>();
        // 判断获取验证码是否频繁
        String time = DicUtil.getMapDictionary("CODE_GAP_TIME").get("GAP_TIME");
        Date d = DateUtil.getInstance().minusDateSecond(Integer.parseInt(time));
        boolean isLogin = isCheck(phone,d);
        if (isLogin) {
            map.put("status", false);
            map.put("msg", "对不起，您获取验证码过于频繁，请稍后在试！");
            return map;
        }

        String code = getRandomString(6);
        String maxTimeStr = DicUtil.getMapDictionary("CODE_VALID_TIME").get("VALID_TIME");
        Integer maxTime = Integer.parseInt(maxTimeStr)/60;
        String text = code + "(动态验证码)，请在" + maxTime.intValue() + "分钟内填写";
        /*String smsUrl = SysConfig.getValue("smsUrl");
        String smsSendUser = SysConfig.getValue("smsSendUser");
        String smsSendPwd = SysConfig.getValue("smsSendPwd");
        String dtime = String.valueOf(System.currentTimeMillis());
        String pwdString = "key=" + MD5.GetMD5Code(smsSendPwd).toLowerCase() + "&timestamp=" + dtime;
        smsUrl = smsUrl + "?user_name=" + smsSendUser + "&sub_user=&password=" + MD5.GetMD5Code(pwdString)
                + "&timestamp=" + dtime + "&mobile=" + phone + "&content=" + text;
        // 数据返回的格式：
        // {\"msg\":\"发送成功\",\"code\":0,\"data\":{\"task_id\":\"12\"}}
        String respon = servletReqService.GetResponseData(smsUrl, "");*/
        String urlStr = SysConfig.getValue("CoolUrl")+"services/smsCodeServlet";
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("url", urlStr);
        param.put("mobile", phone);
        param.put("content", text);
        String respon = InterfaceUtil.getInstance().httpPost(param);
        if (Utils.isEmptyStr(respon)) {
            logger.error("调用发送短信接口错误：phone=" + phone + "，接口返回" + respon);
            map.put("status", false);
            map.put("msg", "获取验证码失败！");
            return map;
        }
        SmsResponseDTO resDTO = (SmsResponseDTO) JsonUtil.deserialize(respon, SmsResponseDTO.class);
        if (!"0".equals(resDTO.getCode())) {
            logger.error("调用发送短信接口错误：phone=" + phone + "，接口返回" + respon);
            map.put("status", false);
            map.put("msg", "获取验证码失败！");
            return map;
        }
        logger.info("获取验证码成功：phone=" + phone + "，验证码:" + code);
        // 登录验证码入库
        save(us.getLoginName(), phone, text,code);
        //记录日志
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff",us.getLoginName());
        logmap.put("phone",phone);
        logmap.put("code",code);
        logmap.put("source",source);
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logService.businessSaveLog(Business.login_autch_code,"0",us.getLoginName(),"","获取验证码",logmap);
        map.put("status", true);
        return map;
    }

    /**
     * 验证码信息入库
     * @param loginName
     * @param phone
     * @param sms
     * @param code
     * @throws Exception
     */
    public void save(String loginName,String phone,String sms,String code) throws Exception{
        LoginCode smsCode = new LoginCode();
        smsCode.setLoginName(loginName);
        smsCode.setPhone(phone);
        smsCode.setSms(sms);
        smsCode.setCode(code);
        smsCode.setCreateTime(new Date());
        smsCodeMapper.insert(smsCode);
    }
    /**
     * 验证码信息入库
     * @param smsCode
     * @throws Exception
     */
    public void save(LoginCode smsCode) throws Exception{
        smsCodeMapper.insert(smsCode);
    }

    /**
     * 在data时间后号码phone是否有登录
     * @param phone
     * @param date
     * @return
     * @throws Exception
     */
    public Boolean isCheck(String phone,Date date) throws Exception{
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("phone",phone);
        searchMap.put("startTime",date);
        List<LoginCode> list = smsCodeMapper.list(searchMap);
        if(null != list & list.size() >0){
            return true;
        }
        return false;
    }

    /**
     * 在data时间后号码phone是否有登录
     * @param phone
     * @param date
     * @return
     * @throws Exception
     */
    public String getMmsCode(String phone,Date date) throws Exception{
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("phone",phone);
        searchMap.put("startTime",DateUtil.getInstance().formatDate(date,DateUtil.yyyy_MM_dd_HH_mm_ss));
        List<LoginCode> list = smsCodeMapper.list(searchMap);
        if(null != list & list.size() >0){
            return list.get(0).getCode();
        }
        return "";
    }

    /**
     * 获取随机数
     *
     * @param length
     *            长度
     * @return
     */
    public String getRandomString(int length) {
        String base = "0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
}
