package com.agent.common.enumeration;

/**
 * 1：划拨进，2：加值(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，
 * 6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
 * 16:开卡冻结，17：开卡扣款，18:开卡冻结解冻扣款，19:开卡冻结解冻回退，20:开卡充值佣金，21:充值佣金转划拨
 * 22:销售佣金转划拨 23:OCR识别，24:身份核验，25:人像比对
 */
public enum BizSourceType {
    ONLINE("网厅", "online"),
    WAP("掌厅", "wap"),
    BIZ1("流量订购","1"),
    BIZ2("来电提醒","2"),
    BIZ3("来电显示","3"),
    BIZ4("无条件呼叫转移","4"),
    BIZ5("炫铃服务","5"),
    BIZ6("语音呼入","6"),
    BIZ7("上网功能","7"),
    BIZ8("短信功能","8"),
    BIZ9("实名补录","9"),
    BIZ10("补换卡","10"),
    BIZ11("挂失解挂","11"),
    BIZ12("停机保号停复机","12"),
    BIZ13("销户申请","13"),
    ;
    
    // 成员变量 
    private String name;
    private String type;
    // 构造方法 
    private BizSourceType(String name, String type) {
        this.name = name;
        this.type = type;
    }
    
    public static String getName(String type) {
        for (BizSourceType ot : BizSourceType.values()) {
            if (ot.getType().equals(type)) {
                return ot.name;
            }
        }
        return type;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
}
