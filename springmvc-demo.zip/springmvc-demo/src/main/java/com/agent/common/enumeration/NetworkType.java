package com.agent.common.enumeration;

/**
 * 网络（运营商）状态枚举  移动：1，联通：2，电信：3
 */
public enum NetworkType {
    YD("移动", "1"),
    LT("联通", "2"),
    DX("电信", "3"),
    ;
    
    private String name;
    private String id;
    // 构造方法 
    private NetworkType(String name, String id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(String id) {
        for (NetworkType ps : NetworkType.values()) {
            if (ps.getId().equals(id)) {
                return ps.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
}
