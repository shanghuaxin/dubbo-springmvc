package com.agent.common;

import com.agent.util.DateUtil;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zw on 2016/7/15.
 */
public class BaseDomain implements Serializable {
    private static final long serialVersionUID = 5284923098731360037L;
    private Integer id;
    private Integer createId;
    private Date createTime;
    private Integer updateId;
    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public String getCreateTimeStr() {
        return createTime !=null ? DateUtil.getInstance().getDateStr(createTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public String getCreateTimeYMD() {
        return createTime !=null ? DateUtil.getInstance().getDateStr(createTime,DateUtil.yyyy_MM_dd) : "";
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime !=null ? DateUtil.getInstance().getDateDate(createTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : null;;

    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }
    public String getUpdateTimeStr() {
        return updateTime !=null ? DateUtil.getInstance().getDateStr(updateTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime !=null ? DateUtil.getInstance().getDateDate(updateTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : null;

    }
}
