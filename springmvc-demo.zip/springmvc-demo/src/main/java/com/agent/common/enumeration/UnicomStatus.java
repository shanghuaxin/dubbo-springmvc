package com.agent.common.enumeration;

/**
 * 1：划拨进，2：加值(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，
 * 6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
 * 16:开卡冻结，17：开卡扣款，18:开卡冻结解冻扣款，19:开卡冻结解冻回退，20:开卡充值佣金，21:充值佣金转划拨
 * 22:销售佣金转划拨 23:OCR识别，24:身份核验，25:人像比对
 */
public enum UnicomStatus {
    UNICOM_109996(109996,"强制开机"),
    UNICOM_109997(109997,"强拆返销"),
    UNICOM_109998(109998,"销号返销"),
    UNICOM_109999(109999,"正常服务"),
    UNICOM_110000(110000,"无效"),
    UNICOM_119990(119990,"预登录取消"),
    UNICOM_119991(119991,"单机与中继互转"),
    UNICOM_119992(119992,"删除中继线号"),
    UNICOM_119993(119993,"跨业务换装"),
    UNICOM_119994(119994,"客户帐户合并拆分"),
    UNICOM_119995(119995,"过户"),
    UNICOM_119996(119996,"改号"),
    UNICOM_119997(119997,"装机回退"),
    UNICOM_119998(119998,"强拆销号"),
    UNICOM_119999(119999,"用户退网"),
    UNICOM_129983(129983,"PPC用户加锁"),
    UNICOM_129984(129984,"PPC用户挂失"),
    UNICOM_129985(129985,"预销户"),
    UNICOM_129986(129986,"预登录呼限"),
    UNICOM_129987(129987,"预登录停机"),
    UNICOM_129988(129988,"挂失停机"),
    UNICOM_129989(129989,"携出停机"),
    UNICOM_129990(129990,"强制停机"),
    UNICOM_129991(129991,"预登录强制停机"),
    UNICOM_129992(129992,"申请呼叫限制"),
    UNICOM_129993(129993,"停机保号"),
    UNICOM_129995(129995,"退网停机"),
    UNICOM_129996(129996,"局方强制服务暂停"),
    UNICOM_129997(129997,"欠费服务暂停"),
    UNICOM_129998(129998,"呼叫限制"),
    UNICOM_129999(129999,"申请服务暂停"),
    UNICOM_145000(145000,"预约"),
    UNICOM_149998(149998,"准开通"),
    UNICOM_149999(149999,"预登录"),
    ;
    
 // 成员变量 
    private Integer id;
    private String name;
    // 构造方法 
    private UnicomStatus(Integer id,String name) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (UnicomStatus ot : UnicomStatus.values()) {
            if (ot.getId() == id) {
                return ot.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
}
