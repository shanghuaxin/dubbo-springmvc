package com.agent.common.enumeration;

/**
 * 增值业务类型
 */
public enum ServiceType {
    CALL_REMAIND("来电提醒", "1"),
    CALL_DISPLAY("来电显示", "2"),
    VOICE("语音包", "3"),
    NORMALFLOW("普通流量包", "4"),
    COMBINATION_PACKAGE("组合包", "5"),
    MONTH_PACKAGE("叠加包", "6"),
    BASIC_VOICE("语音包", "7"),
    DAY_FLOW("普通日包", "8"),
    DAY_FLOW_KEEP_ON("自动续订日包", "9"),
    SMS_FUNCTION("短信功能", "10"),
    HZ_FUNCTION("呼转功能", "11"),
    FLOW_FUNCTION("上网功能", "12"),
    VOICE_FUNCTION("语音功能", "13"),
    ;
    
    private String name;
    private String id;
    // 构造方法 
    private ServiceType(String name, String id) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(String id) {
        for (ServiceType ps : ServiceType.values()) {
            if (ps.getId().equals(id)) {
                return ps.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
}
