package com.agent.common.enumeration;

/**
 * 操作类型：101-上架，102-分配，103-修改iccid，104-修改面额，105-延期，106-回收，107-下架，201-锁定，202-解锁，203-开户，204-激活，205-过户,206-销户',
 * @author fenglu
 *
 */
public enum NmbRecordOptType {
    IMP_STOCK(100,"号码接入系统"), // 上架
    UPPER_SHELF(101,"上架"), // 上架
    ALLOT(102,"分配"), //分配
    UP_ICCID(103,"修改iccid"), // -修改iccid
    UP_MONEY(104,"修改面额"), // 修改面额
    DELAY(105,"延期"), // 延期
    CALLBACK(106,"回收"), // 回收
    LOWER_SHELF(107,"下架"), // 下架
    LOCKING(201,"锁定"), // 锁定
    UNLOCK(202,"解锁"), // 解锁
    OPEN(203,"开户"), // 开户
    ACTIVATION(204,"激活"), // 激活
    MOD_CUSTOMER(205,"过户"), // 过户
    CANCLE_BLACK(206,"销户"), // 销户
    ;
    // 成员变量 
    private Integer id;
    private String name;
    // 构造方法 
    private NmbRecordOptType(Integer id,String name) {
        this.name = name;
        this.id = id;
    }
    
    public static String getName(Integer id) {
        for (NmbRecordOptType ot : NmbRecordOptType.values()) {
            if (ot.getId() == id) {
                return ot.name;
            }
        }
        return id + "";
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
}
