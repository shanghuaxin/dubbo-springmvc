package com.agent.openaccount.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;

/**
 * 开户扣款记录表
 */
public class Account extends BaseDomain {

    private static final long serialVersionUID = -8042663030938965090L;
    //操作类型
    public final  static String   ACCOUNT_TYPE_ADD="ACCOUNT_TYPE_ADD";//预备金充值
    public final  static String   ACCOUNT_TYPE_CORRECT="ACCOUNT_TYPE_CORRECT";//预备金纠正
    public final static String    WITHDRAWALS_BROKERAGE="WITHDRAWALS_BROKERAGE";//佣金提现
    public final static String   ADD_IMPREEST="ADD_IMPREEST";//预备金补充
    public  final static String    FINE="FINE";//违规罚款
    public  final static String    OPEN_SIM="OPEN_SIM";//开卡
    public  final static String    RECHARGE="RECHARGE";//充值
    public final static String OPEN_ACC_ADD="OPEN_ACC_ADD";//开卡账户-->充值
    public final static String OPEN_ACC_UPDATE="OPEN_ACC_UPDATE";//开卡账户-->充值纠正
    public final static String RECHARGE_ACC_ADD="RECHARGE_ACC_ADD";//充值账户-->充值
    public final static String RECHARGE_ACC_UPDATE="RECHARGE_ACC_UPDATE";//充值账户-->充值纠正
    public final static String RECHARGE_ACC_ADD_BUS="RECHARGE_ACC_ADD_BUS";//充值账户-->充值-->业务人员
    public final static String RECHARGE_ACC_UPDATE_BUS="RECHARGE_ACC_UPDATE_BUS";//充值账户-->充值纠正-->业务人员   
    public final static String RECHARGE_ACC_ADD_SELF="RECHARGE_ACC_ADD_SELF";//充值账户-->充值-->网点本人
    public final static String OPEN_ACC_MOVE="OPEN_ACC_MOVE";//预备金-->开卡账户补充
    public final static String RECHARGE_ACC_MOVE="RECHARGE_ACC_MOVE";//预备金-->充值账户补充
    public final static String BROKERAGE_MOVE="BROKERAGE_MOVE";//佣金-->充值账户补充
    public final static String PRIV_BRO_ADD="PRIV_BRO_ADD";//充值-->直充账户佣金--> 增加佣金
    public final static String PRIV_OPEN_BRO_ADD="PRIV_OPEN_BRO_ADD";//开卡-->直充账户佣金--> 增加佣金
    public final static String REC_BRO_ADD="REC_BRO_ADD";//充值-->充值账户佣金--> 增加佣金
    public final static String REC_OPEN_BRO_ADD="REC_OPEN_BRO_ADD";//开卡-->充值账户佣金--> 增加佣金

    //账户类型
    public final  static String IMPREEST="IMPREEST"; //预付款
    public final  static String OPEN_ACC="OPEN_ACC"; //开卡账户
    public final  static String RECHARGE_ACC="RECHARGE_ACC"; //充值账户
    public final  static String RECHARGE_PRIV="RECHARGE_PRIV"; //直充账户    
    public final static String BROKERAGE="BROKERAGE";//佣金
    public final static String PRIV_BRO="PRIV_BRO";//直充佣金账户
    public final static String REC_BRO="REC_BRO";//充值佣金账户
    private Integer channelId;    //
    private String accountType;   //
    private BigDecimal money;     //
    private String optionType;    //
    private String phone;         //
    private BigDecimal balance;   //
    private String orderNo;       //

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    @Override
    public String toString() {
        return "Account [channelId=" + channelId + ", accountType=" + accountType + ", money=" + money + ", optionType="
                + optionType + ", phone=" + phone + ", balance=" + balance + ", orderNo=" + orderNo + "]";
    }

}
