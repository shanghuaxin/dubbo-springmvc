package com.agent.openaccount.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.mapper.AttachedDocumentsMapper;

@Transactional(rollbackFor=Exception.class)
@Service("documentsService")
public class AttachedDocumentsService {
    
    @Autowired
    private AttachedDocumentsMapper attachedDocumentsMapper;
    
    //查询照片信息
    public List<AttachedDocuments> findBySourceIdAndSourceName(Integer sourceId, String sourceName) {
        return attachedDocumentsMapper.findBySourceIdAndSourceName(sourceId, sourceName);
    }
    

}
