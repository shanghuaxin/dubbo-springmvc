package com.agent.openaccount.dto;

import java.util.Date;

import com.agent.order.common.util.Utils;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;

/**
 * 号码过户列表DTO
 */
public class ModCustomerListDTO {
    private Integer modId;//过户记录id
    private Integer phoneId;//号码id
    private Date createTime;//过户 时间
    private String level;//号码等级
    private String phone;//号码
    private String oldName;//历史姓名
    private String oldCode;//历史身份证号
    private String newName;//当前姓名
    private String newCode;//当前身份证号
    private String contactPhone; //联系电话
    private Integer operatorCode; //运营商:1-移动，2-联通，3-电信
    private String modSources;    //过户来源：PC（电脑），APP（手机）
    private String checkStatus;// 状态：1-待审核，2-审核不通过，0-审核通过,3-过户取消
    private String remark;//审核信息
    private String channelCode;//过户网点编号
    private String channelName;//过户网点名称
    private String channelPhone;//过户网点联系电话
    private String readType;//识别方式：1-阅读识别器,2-照片识别,3-NFC,4-亿数,5-华视,6-神思,7-信通，8-精伦,9-OCR
    private String tnStatus;//号码状态

    public Integer getModId() {
        return modId;
    }

    public void setModId(Integer modId) {
        this.modId = modId;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getCreateTimeStr() {
        return DateUtil.getInstance().getDateStr(createTime,DateUtil.yyyy_MM_dd_HH_mm_ss);
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getLevelStr() {
        return DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(level);
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOldUserInfo() {
        return oldName+"<br/>"+oldCode;
    }

    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    public String getOldCode() {
        return oldCode;
    }

    public void setOldCode(String oldCode) {
        this.oldCode = oldCode;
    }

    public String getUserInfo() {
        return newName+"<br/>"+newCode;
    }

    public String getNewName() {
        return newName;
    }

    public void setNewName(String newName) {
        this.newName = newName;
    }

    public String getNewCode() {
        return newCode;
    }

    public void setNewCode(String newCode) {
        this.newCode = newCode;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }
    
    public Integer getOperatorCode() {
        return operatorCode;
    }
    
    public String getOperatorCodeStr() {
        if(null != operatorCode){
            if(1 == operatorCode.intValue()){
                return "移动";
            }else if(2 == operatorCode.intValue()){
                return "联通";
            }else {
                return "电信";
            }
        }
        return "";
    }

    public void setOperatorCode(Integer operatorCode) {
        this.operatorCode = operatorCode;
    }

    public String getModSources() {
        return modSources;
    }

    public void setModSources(String modSources) {
        this.modSources = modSources;
    }

    public String getCheckStatusStr() {
        if(!Utils.isEmptyString(checkStatus)){
            if("1".equals(checkStatus)){
                return "待审核";
            }else if("2".equals(checkStatus)){
                return "审核不通过";
            }else if("3".equals(checkStatus)){
                return "已取消";
            }else{
                return "审核通过";
            }
        }
        return "";
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelPhone() {
        return channelPhone;
    }

    public void setChannelPhone(String channelPhone) {
        this.channelPhone = channelPhone;
    }
    

    public String getReadType() {
        return readType;
    }
    public String getReadTypeStr() {
        if(!Utils.isEmptyString(readType)){
            if("1".equals(readType)){
                return "阅读识别器";
            }else if("2".equals(readType)){
                return "照片识别";
            }else if("3".equals(readType)){
                return "NFC";
            }else if("4".equals(readType)){
                return "亿数";
            }else if("5".equals(readType)){
                return "华视";
            }else if("6".equals(readType)){
                return "神思";
            }else if("7".equals(readType)){
                return "信通";
            }else if("8".equals(readType)){
                return "精伦电子";
            }else if("9".equals(readType)){
                return "OCR";
            }
        }
        return readType;
    }

    public void setReadType(String readType) {
        this.readType = readType;
    }
    
    public String getTnStatus() {
        return tnStatus;
    }

    public void setTnStatus(String tnStatus) {
        this.tnStatus = tnStatus;
    }

    public String getChannelInfo() {
       return "编码："+channelCode+
               "<br/>名称："+channelName+
               "<br/>联系电话："+channelPhone;
    }
}
