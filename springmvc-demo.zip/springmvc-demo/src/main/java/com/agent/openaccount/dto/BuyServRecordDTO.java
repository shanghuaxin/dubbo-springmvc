package com.agent.openaccount.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 业务办理DTO
 * @author zw
 *
 */
public class BuyServRecordDTO {
	private Long id;
	private String phone;//号码
	private Integer phoneId;           //号码id
	private String parChannelName;//归属渠道
	private String channelName;//业务办理渠道
	private Integer channelId;//业务办理渠道
	private String certName;//订购业务号码用户
	private String certNbr;//订购业务号码身份证
	private String servName;//业务名称
	private String servCode;//业务编号
	private String status;//状态：0-发送成功，1-待发送，2-发送失败 默认待发送
	private String ctime;//办理时间
	private String memo;//备注
    private String network; //网络：移动-1,2-联通，3-电信
	private String nowsType;//消息类型：1-预开户，2-业务订购，3-开户
	private Integer orderNum;//消息类型的排序顺序，1-复机，2-流量包，3，融合流量包，4-来电显示，5-来电提醒，6-开户,7-语音包，8-联通叠加包
	private Integer portNum;//推送次数
	private String sourceType;//app,pc
	private String buyType;//业务类型：1-强制停机，2-强制复机，3-来电提醒/来电显示，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理,8-开户，9-语音业务，10-联通叠加包
	private String parmStr;//参数内容
	private BigDecimal servMoney=new BigDecimal(0); //价格   分为单位
    private Date pushTime;//订购开始时间
	private Integer createId;
	private Integer updateId;
	

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getParChannelName() {
        return parChannelName;
    }

    public void setParChannelName(String parChannelName) {
        this.parChannelName = parChannelName;
    }

    public String getCertName() {
		return certName;
	}

	public void setCertName(String certName) {
		this.certName = certName;
	}

	public String getCertNbr() {
		return certNbr;
	}

	public void setCertNbr(String certNbr) {
		this.certNbr = certNbr;
	}

	public String getServName() {
		return servName;
	}

	public void setServName(String servName) {
		this.servName = servName;
	}

	public String getCtime() {
		return ctime;
	}

	public void setCtime(String ctime) {
		this.ctime = ctime;
	}

	public String getServCode() {
		return servCode;
	}

	public void setServCode(String servCode) {
		this.servCode = servCode;
	}

	public String getStatus() {
		return status;
	}

	public String getStatusStr() {
		if("0".equals(status)){
			return "成功";
		}else if("1".equals(status)){
			return "订购中";
		}else if("2".equals(status)){
			return "失败";
		}
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getNowsType() {
		return nowsType;
	}

	public String getNowsTypeStr() {
		if("1".equals(nowsType)){
			return "预开户";
		}else if("2".equals(nowsType)){
			return "业务订购";
		}
		return nowsType;
	}

	public void setNowsType(String nowsType) {
		this.nowsType = nowsType;
	}

	public Integer getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}

	public Integer getPortNum() {
		return portNum;
	}

	public void setPortNum(Integer portNum) {
		this.portNum = portNum;
	}

	public String getBuyType() {
		return buyType;
	}

	public void setBuyType(String buyType) {
		this.buyType = buyType;
	}

	public String getParmStr() {
		return parmStr;
	}

	public void setParmStr(String parmStr) {
		this.parmStr = parmStr;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public BigDecimal getServMoney() {
		return servMoney;
	}

	public void setServMoney(BigDecimal servMoney) {
		this.servMoney = servMoney;
	}

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public Date getPushTime() {
        return pushTime;
    }

    public void setPushTime(Date pushTime) {
        this.pushTime = pushTime;
    }
}
