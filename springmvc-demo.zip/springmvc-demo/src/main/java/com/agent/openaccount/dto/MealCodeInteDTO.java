package com.agent.openaccount.dto;

public class MealCodeInteDTO {
	/** 来电显示接口  */
	public static final String SetIncomingCall_3 = "3";
	/** 流量包接口  */
	public static final String DataPlan_6 = "6";
	/** 融合流量包  */
	public static final String UnificationDataPlan_7 = "7";
	/** 来电显示  */
	public static final String ldshow_420 = "420";
	/** 来电提醒  */
	public static final String ldshow_152 = "152";
	
	private String servCode;//'业务编号',
	private String servName ;//'业务名称',
	private String servInte ;//'调用接口',
	private String inteType ;//'调用接口类型：1-强制停机，2-强制复机，3-来电提醒/来电显示，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理',
	private String memo;//'备注',
	public String getServCode() {
		return servCode;
	}
	public void setServCode(String servCode) {
		this.servCode = servCode;
	}
	public String getServName() {
		return servName;
	}
	public void setServName(String servName) {
		this.servName = servName;
	}
	public String getServInte() {
		return servInte;
	}
	public void setServInte(String servInte) {
		this.servInte = servInte;
	}
	public String getInteType() {
		return inteType;
	}
	public void setInteType(String inteType) {
		this.inteType = inteType;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	
}
