package com.agent.openaccount.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.mapper.IdcardInfoMapper;

@Transactional(rollbackFor=Exception.class)
@Service("idcardInfoService")
public class IdcardInfoService {
    
    @Autowired
    private IdcardInfoMapper idcardInfoMapper;
    
    public IdcardInfo findByIdNumber(String idNumber) {
        return idcardInfoMapper.findByIdNumber(idNumber);
    }

}
