package com.agent.openaccount.entity;

import java.io.Serializable;

import com.agent.order.common.util.Utils;

/**
 * 身份信息表
 */
public class IdcardInfo implements Serializable {

    private static final long serialVersionUID = -4307706033397152402L;

    private Integer id;         //
    private String name;        //姓名
    private String sexual;      //性别
    private String nation;      //名族
    private String address;     //地址
    private String idNumber;    //公民身份号码
    private String organs;      //签发机关
    private String expiryDate;  //有效期限

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSexualStr() {
       if("1".equals(sexual)){
           return "男";
       }else{
           return "女";
       }
    }

    public String getSexual() {
        return sexual;
    }

    public void setSexual(String sexual) {
        this.sexual = sexual;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getOrgans() {
        return organs;
    }

    public void setOrgans(String organs) {
        this.organs = organs;
    }

    public String getExpiryDate() {
        return expiryDate;
    }
    public String getStartExpiryDate() {
        if(!Utils.isEmptyString(expiryDate) && expiryDate.indexOf("-") > -1 && expiryDate.indexOf("长期") < 0){
            if(expiryDate.length() == 19){
                expiryDate = expiryDate.substring(0,5)+"0"+expiryDate.substring(5,15)+"0"+expiryDate.substring(15,19);
            }else if(expiryDate.length() ==20 && !expiryDate.substring(5,6).equals("0")){
                expiryDate = expiryDate.substring(0,5)+"0"+expiryDate.substring(5,20);
            }else if(expiryDate.length() ==20 && !expiryDate.substring(16,17).equals("0")){
                expiryDate = expiryDate.substring(0,16)+"0"+expiryDate.substring(16,20);
            }
            if(expiryDate.indexOf("-") == 4){
                return expiryDate.substring(0, 10).replaceAll("-",".");
            }else{
                return expiryDate.substring(0, expiryDate.indexOf("-")).replaceAll("-", ".");
            }
        }
        return "";
    }
    public String getEndExpiryDate() {
        if(!Utils.isEmptyString(expiryDate) && expiryDate.indexOf("-") > -1 && expiryDate.indexOf("长期") < 0){
            if(expiryDate.length() == 19){
                expiryDate = expiryDate.substring(0,5)+"0"+expiryDate.substring(5,15)+"0"+expiryDate.substring(15,19);
            }else if(expiryDate.length() ==20 && !expiryDate.substring(5,6).equals("0")){
                expiryDate = expiryDate.substring(0,5)+"0"+expiryDate.substring(5,20);
            }else if(expiryDate.length() ==20 && !expiryDate.substring(16,17).equals("0")){
                expiryDate = expiryDate.substring(0,16)+"0"+expiryDate.substring(16,20);
            }
            if(expiryDate.indexOf("-") == 4){
                return expiryDate.substring(11, 21).replaceAll("-",".");
            }else{
                return expiryDate.substring(expiryDate.indexOf("-")+1,expiryDate.length()).replaceAll("-",".");
            }
        }
        return "";
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }


    @Override
    public String toString() {
        return "IdcardInfo [id=" + id + ", name=" + name + ", sexual=" + sexual + ", nation=" + nation + ", address="
                + address + ", idNumber=" + idNumber + ", organs=" + organs + ", expiryDate=" + expiryDate + "]";
    }

}
