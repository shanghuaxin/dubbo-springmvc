package com.agent.openaccount.dto;

import org.springframework.jdbc.core.RowMapper;

import com.agent.util.DateUtil;
import com.agent.util.Utils;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * Created by Administrator on 2015/8/28.
 */
public class OpenAccountVo implements RowMapper<OpenAccountVo>,Serializable{
    
    private static final long serialVersionUID = 8077591184173920530L;
    private Long phone_id;//号码表ID
    private String phone;//号码
    private String name;//姓名
    private String identityCard;//身份证号
    private Date openDate;//开户时间
    private int status;  //状态 1激活中2未激活3已激活
    private String channel;
    private String setMeal;
    private String iccId;
    private String amount;
    private Long id;
    public String openDateDesc;

    public Long getPhone_id() {
        return phone_id;
    }

    public void setPhone_id(Long phone_id) {
        this.phone_id = phone_id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdentityCard() {
        return identityCard;
    }

    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getSetMeal() {
        return setMeal;
    }

    public void setSetMeal(String setMeal) {
        this.setMeal = setMeal;
    }

    public String getIccId() {
        return iccId;
    }

    public void setIccId(String iccId) {
        this.iccId = iccId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OpenAccountVo mapRow(ResultSet rs, int row) throws SQLException{
        OpenAccountVo vo = new OpenAccountVo();
        vo.setId(rs.getLong("id"));
        vo.setAmount(Utils.foratNumber(rs.getDouble("money")));
        vo.setChannel(rs.getString("ditch_name"));
        vo.setIccId(rs.getString("imsi"));
        vo.setIdentityCard(rs.getString("identity_card"));
        vo.setSetMeal(rs.getString("mealName"));
        vo.setOpenDate(rs.getDate("open_date"));
        vo.setPhone(rs.getString("phone"));
        vo.setName(rs.getString("name"));
        return vo;
    }

    public String getOpenDateDesc() {
        return DateUtil.getInstance().formatDate(getOpenDate(),null);
    }

}
