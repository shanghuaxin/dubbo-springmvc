package com.agent.openaccount.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.PreSubs;

public interface PreSubsMapper extends BaseMapper<PreSubs, Integer> {
    public int batchInsert(List<PreSubs> list);
    //查询改号码是否为boss预开户号码 是预开户号码
    public PreSubs findSubsByPhone(@Param(value="phone") String phone);
    //已完成的预开户记录,删除预开户记录
    public void deleteSubsByPhone(@Param(value="phone") String phone);
    //充值失败修改信息
    public void upPreSubs(@Param(value="phone")String phone, @Param(value="code")String code);

    public int deleteSubsByPhoneList(List<String> list);
}
