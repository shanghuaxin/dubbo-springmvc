package com.agent.openaccount.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.mapper.IdentityMapper;

@Transactional(rollbackFor=Exception.class)
@Service("identityService")
public class IdentityService {
    
    @Autowired
    private IdentityMapper identityMapper;
    
    public Identity findById(Integer id) {
        return identityMapper.select(id);
    }
    
    public List<Identity> findIdentityByPhoneId(Integer phoneId) {
        return identityMapper.findIdentityByPhoneId(phoneId);
    }
    
    public Identity findByPhone(String phone) {
        return identityMapper.findByPhone(phone);
    }
    
    public int findIdentityNumByCode(String code) {
        return identityMapper.findIdentityNumByCode(code);
    }
    
    //是否已被审核
    public boolean hasIdentityCheck(Integer phoneId){
        boolean boo=false;
        List<Identity> list = identityMapper.hasCheck(phoneId);
        if(null !=list && list.size()>0){
            boo=true;
        }
        return boo;
    }

    // 统计渠道下的开户量
    public int statisticsOpenCount(Map<String, Object> params) {
        return identityMapper.statisticsOpenCount(params);
    }
}
