package com.agent.openaccount.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.order.common.util.Utils;

/**
 * 业务订购表
 */
public class BuyServiceRecord extends BaseDomain {
    /***  订购     **/
    public static final String opt_type_0 = "0";
    /***  取消     **/
    public static final String opt_type_1 = "1";
    /***  变更     **/
    public static final String opt_type_2 = "2";
    /***  实时生效     **/
    public static final String valid_type_1 = "1";
    /***  次月生效     **/
    public static final String valid_type_2 = "2";
    /***  次日生效     **/
    public static final String valid_type_3 = "3";

    private static final long serialVersionUID = -2997818758014209343L;
    private Integer channelId;      //渠道id
    private String channelName;     //渠道名称
    private String phone;           //号码
    private Integer phoneId;           //号码id
    private String servCode;        //业务编号
    private String servName;        //业务名称
    private String nowsType;        //业务类型：1-预开户，2-业务订购,3-开户
    //排序顺序，1-复机，2-流量包，3，融合流量包，4-来电显示，5-来电提醒，6-开户，7-叠加流量包，8-语音包，9-普通日包，10-自动续订日包,11-套餐，12-无条件呼转
    private String orderNum;        
    //移动   业务类型：1-强制停机，2-强制复机，3-来电提醒/来电显示，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理，8-开户，14-套餐变更
    //联通   业务类型：1-强制停机，2-强制复机，3-来电提醒，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理，8-开户，9-来电显示，
    //10-叠加月包，11-语音包，12-普通日包，13-自动续订日包，14-套餐变更
    private String buyType;         
    private String status;          //状态：0-发送成功，1-待发送，2-发送失败,3-取消,4-待校验，5-待校验回执   默认待发送
    private String parmStr;         //参数内容
    private String memo;            //备注
    private String network;            //网络：移动-1,2-联通，3-电信
    private String sourceType;      //来源类型：app,pc,online,wap
    private int portNum;            //推送次数
    private BigDecimal servMoney;   //价格，单位分
    private String certName;//订购业务号码用户
    private String certNbr;//订购业务号码身份证
    private Date successTime;//订购完成时间
    private Date pushTime;//订购开始时间
    private String orderNo;    //订单编号
    private String optType;   //操作类型：0-订购，1-取消，2-变更
    private String validType;       //生效方式：1-实时生效， 2-次月生效，3-次日生效
    private String newServCode;   //新业务编码
    private String newServName;   //新业务名称
    private String oldServCode;   //旧业务编码
    private String oldServName;   //旧业务名称

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getServCode() {
        return servCode;
    }

    public void setServCode(String servCode) {
        this.servCode = servCode;
    }

    public String getServName() {
        return servName;
    }

    public void setServName(String servName) {
        this.servName = servName;
    }

    public String getNowsType() {
        return nowsType;
    }

    public void setNowsType(String nowsType) {
        this.nowsType = nowsType;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getBuyType() {
        return buyType;
    }

    public void setBuyType(String buyType) {
        this.buyType = buyType;
    }

    public String getStatusStr() {
        if("0".equals(status)){
            return "成功";
        }else if("1".equals(status)){
            return "订购中";
        }else if("2".equals(status)){
            return "失败";
        }else if("3".equals(status)){
            return "已取消";
        }else if("4".equals(status)){
            return "待校验";
        }else if("5".equals(status)){
            return "待校验回执";
        }
        return status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getParmStr() {
        return parmStr;
    }

    public void setParmStr(String parmStr) {
        this.parmStr = parmStr;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public int getPortNum() {
        return portNum;
    }

    public void setPortNum(int portNum) {
        this.portNum = portNum;
    }

    public BigDecimal getServMoney() {
        return servMoney;
    }

    public void setServMoney(BigDecimal servMoney) {
        this.servMoney = servMoney;
    }

    public String getCertName() {
        return certName;
    }

    public void setCertName(String certName) {
        this.certName = certName;
    }

    public String getCertNbr() {
        return certNbr;
    }

    public void setCertNbr(String certNbr) {
        this.certNbr = certNbr;
    }
    

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }
    

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public Date getSuccessTime() {
        return successTime;
    }

    public void setSuccessTime(Date successTime) {
        this.successTime = successTime;
    }

    public Date getPushTime() {
        return pushTime;
    }

    public void setPushTime(Date pushTime) {
        this.pushTime = pushTime;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOptTypeStr() {
        if(!Utils.isEmptyString(optType)){
            if(opt_type_0.equals(optType)){
                return "订购";
            }else if(opt_type_1.equals(optType)){
                return "退订";
            }else if(opt_type_2.equals(optType)){
                return "变更";
            }
        }
        return "";
    }

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType;
    }

    public String getValidType() {
        return validType;
    }

    public void setValidType(String validType) {
        this.validType = validType;
    }

    public String getNewServCode() {
        return newServCode;
    }

    public void setNewServCode(String newServCode) {
        this.newServCode = newServCode;
    }

    public String getNewServName() {
        return newServName;
    }

    public void setNewServName(String newServName) {
        this.newServName = newServName;
    }

    public String getOldServCode() {
        return oldServCode;
    }

    public void setOldServCode(String oldServCode) {
        this.oldServCode = oldServCode;
    }

    public String getOldServName() {
        return oldServName;
    }

    public void setOldServName(String oldServName) {
        this.oldServName = oldServName;
    }

    @Override
    public String toString() {
        return "BuyServiceRecord [channelId=" + channelId + ", channelName=" + channelName + ", phone=" + phone
                + ", phoneId=" + phoneId + ", servCode=" + servCode + ", servName=" + servName + ", nowsType="
                + nowsType + ", orderNum=" + orderNum + ", buyType=" + buyType + ", status=" + status + ", parmStr="
                + parmStr + ", memo=" + memo + ", network=" + network + ", sourceType=" + sourceType + ", portNum="
                + portNum + ", servMoney=" + servMoney + ", certName=" + certName + ", certNbr=" + certNbr
                + ", successTime=" + successTime + ", pushTime=" + pushTime + ", orderNo=" + orderNo + ", optType="
                + optType + ", validType=" + validType + ", newServCode=" + newServCode + ", newServName=" + newServName
                + ", oldServCode=" + oldServCode + ", oldServName=" + oldServName + "]";
    }
    
}
