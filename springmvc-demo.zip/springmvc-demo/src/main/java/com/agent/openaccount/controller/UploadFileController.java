package com.agent.openaccount.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.agent.api.service.IDCheckService;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelsService;
import com.agent.constant.Constant;
import com.agent.exception.BusException;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.service.IdentityService;
import com.agent.order.common.util.Utils;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.images.FileUtil;

@Controller
@RequestMapping("upload-file")
public class UploadFileController {
    private static Logger logger = (Logger) LoggerFactory.getLogger(UploadFileController.class);
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private IdentityService identityService;
    @Autowired
    private IDCheckService idCheckService;
    
    
    /**
     * 上传文件
     * @param file
     * @param response
     * @param request
     * @param imgType
     * @return
     * @throws java.io.IOException
     */
    @RequestMapping(value={"/card-file"}, method={RequestMethod.POST},produces={"text/html;charset=UTF-8"})
    public @ResponseBody String upload(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("imgType")String imgType,@RequestParam("imgPhone")String imgPhone, @RequestParam("readerWay")String readerWay, HttpSession session) throws IOException {
        logger.info("---号码：" + imgPhone + "上传图片开始 ,时间：" + DateUtil.getInstance().formatDate(new Date(), null) + "---");
        JSONObject jsonObject = new JSONObject();
        response.setContentType("application/json; charset=UTF-8");
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        } else {
            try {
                if(Utils.isEmptyString(imgPhone)){
                    throw new BusException("请先输入手机号码再上传！"); 
                }
                // 以下是获取当前渠道信息
                Channels channels = channelsService.findChannelByUserId(user.getId());
                if(null == channels){
                    //客服操作修改资料, 渠道取号码开户渠道
                    Identity ide = identityService.findByPhone(imgPhone);
                    channels = channelsService.findById(ide.getChannelId());
                }
                
                //将图片先暂时上传临时目录下
                String imageURLTmp = imageURL + File.separator + FileUtil.imgPathTmp;
                
                String certificatePath="";
                String saveName = "";
                String fileName = file.getOriginalFilename();
                String type = "";
                String fileType;
                if(!Utils.isEmptyString(fileName)){
                    // 开关打开时，才允许生成缩略图，目前手持照不需要压缩
                    boolean needCompress = true;
                    if(imgType.equals("cardHand")){
                        type = "3";
                        needCompress = false;
                    }else if(imgType.equals("cardFront")){
                        type = "1";
                    }else if(imgType.equals("cardRear")){
                        type = "2";
                    }
                    saveName = imgPhone+"_" + type + "_"+getRandomString(6)+"_PC"+fileName.substring(fileName.lastIndexOf("."),fileName.length());
                    fileType = fileName.substring(fileName.lastIndexOf(".")+1,fileName.length());
                    if(!"jpg".equalsIgnoreCase(fileType.toLowerCase()) && !"jpeg".equalsIgnoreCase(fileType.toLowerCase())
                            && !"png".equalsIgnoreCase(fileType.toLowerCase())&& !"gif".equalsIgnoreCase(fileType.toLowerCase())
                            && !"bmp".equalsIgnoreCase(fileType.toLowerCase())){
                        //return  "身份证手持照格式不正确，请重新上传！@开户失败";
                        throw new BusException("图片格式不正确，请重新上传！"); 
                    }
                    // 1.MultipartFil对象转换为File
                    File fromFile = com.agent.util.FileUtil.multipartToFile(file);
                    // 2.复制照片为txt格式
                    File toFile = new File(fromFile.getPath().substring(0, fromFile.getPath().lastIndexOf("."))+".txt");
                    com.agent.util.FileUtil.copyFile(fromFile, toFile);
                    // 3.读取文件内容，判断是否有PS的标记
                    boolean result = com.agent.util.FileUtil.readTxtFile(toFile);
                    // 4.删除临时生成的txt文件
                    com.agent.util.FileUtil.delete(toFile);
                    if (!result) {
                        logger.error("网点【"+channels.getChannelCode()+"】"+channels.getChannelName()+"上传疑似PS照片！");
                        throw new BusException("此图片疑似经过PS处理，请上传原图！");
                    }
                    certificatePath=FileUtil.getInstance().uploadFile(imageURLTmp,file, saveName, channels.getChannelCode(), needCompress);
                    
                    // ocr方式读取
                    if(readerWay!=null && "2".equals(readerWay.trim()) && (Integer.valueOf(type)==1 || Integer.valueOf(type)==2)){
                        String idnoPath = imageURLTmp+certificatePath;
                        
                        JSONObject jo = new JSONObject();
                        // 默认0表示图片base64,  1表示图片绝对路径
                        jo.put("imgType", 1);
                        if(Integer.valueOf(type)==1){
                            jo.put("frontImg", idnoPath);
                            
                            String headPath = certificatePath.replace("_1_", "_4_");
                            // 头像输出路径
                            headPath = imageURLTmp+headPath;
                            // 上传头像信息，值为上传地址，如果不需要上传头像地址，则可以不传此参数，或传空
                            //jo.put("headimgPath", headPath);//，酷商系统终止返回头像功能
                        } else if(Integer.valueOf(type)==2){
                            jo.put("backImg", idnoPath);
                            // 是否需要计费，如果传递idnosBackNoChargingByOCR参数,表示不计费
                            jo.put("idnosBackNoChargingByOCR", true);
                        }
                        
                        logger.info("---号码：" + imgPhone + "OCR识别开始 ,时间：" + DateUtil.getInstance().formatDate(new Date(), null) + "---");
                        String resultStr = idCheckService.ocrAnalyse(jo.toString(), request);
                        logger.info("---号码：" + imgPhone + "OCR识别完成 ,时间：" + DateUtil.getInstance().formatDate(new Date(), null) + "---");
                        if(Integer.valueOf(type)==1){
                            resultStr = resultStr.replace("ethnic", "nation").replace("id_code", "code").replace("real_name", "name")
                                    .replace("gender", "sex").replace("addr", "address");
                            
                        } else if(Integer.valueOf(type)==2){
                            resultStr = resultStr.replace("issue_authority", "organs").replace("valid_period", "expirydate");
                        }
                        
                        jsonObject = new JSONObject(resultStr);
                    }
                }else{
                    throw new BusException("请选择要上传的图片，重新上传！"); 
                }
                
                jsonObject.put("fileNameOrig",fileName);
                jsonObject.put("fileName",saveName);
                jsonObject.put("attachmentUrl",certificatePath);
            }catch(BusException e){
                try {
                    jsonObject.put("fileNameOrig","error");
                    jsonObject.put("fileName","error");
                    jsonObject.put("attachmentUrl",e.getMessage());
                } catch (JSONException e1) {
                    logger.error("上传图片失败", e.getMessage());
                }
                logger.error("上传图片失败", e.getMessage());
            } catch (Exception e) {
                try {
                    jsonObject.put("fileNameOrig","error");
                    jsonObject.put("fileName","error");
                    jsonObject.put("attachmentUrl","系统异常");
                } catch (JSONException e1) {
                    logger.error("上传图片失败", e.getMessage());
                }
                logger.error("上传图片失败", e.getMessage());
            }
        }
        logger.info("---号码：" + imgPhone + "上传图片完成 ,时间：" + DateUtil.getInstance().formatDate(new Date(), null) + "---");
        return jsonObject.toString();
    } 
    
    /**
     * 生成随机数
     * @param length
     * @return
     */
    public static String getRandomString(int length) { //length表示生成字符串的长度
        return RandomStringUtils.randomNumeric(length);
    }
    

    /**
     * 普通上传文件
     * @param file
     * @param response
     * @param request
     * @param operType 1:实名补录，2：补换卡,3-品牌动态
     * @param imgType 图片类型（品牌动态：10-网厅图，20-掌厅轮播，21-掌厅详情）
     * @return
     * @throws java.io.IOException
     */
    @RequestMapping(value={"/common-file"}, method={RequestMethod.POST},produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String uploadFile(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("operType")String operType,@RequestParam("imgType")String imgType, HttpSession session) throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        JSONObject jsonObject = new JSONObject();
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return "login.jsp";
            } 
            // 以下是获取当前渠道信息
//            Channels channels = channelsService.findChannelByUserId(user.getId());
//            String ditchCode = "";
//            if(null != channels){
//                //客服操作修改资料, 渠道取号码开户渠道
//                ditchCode = channels.getChannelCode();
//            }
            String catalog = "coolagent";
            String certificatePath="";
            String saveName = "";
            String fileName = file.getOriginalFilename();
            if(!Utils.isEmptyString(fileName)){
                // 1.MultipartFil对象转换为File
                File fromFile =  com.agent.util.FileUtil.multipartToFile(file);
                // 2.复制照片为txt格式
                File toFile = new File(fromFile.getPath().substring(0, fromFile.getPath().lastIndexOf("."))+".txt");
                com.agent.util.FileUtil.copyFile(fromFile, toFile);
                // 3.读取文件内容，判断是否有PS的标记
                //boolean result = FileUtil.readTxtFile(toFile);
                // 4.删除临时生成的txt文件
                com.agent.util.FileUtil.delete(toFile);
                if("3".equals(operType)){
                    catalog="";//品牌动态不需要定义最小目录
                    saveName = "BRAND" + "_" + imgType +"_"+getRandomString(6)+"_PC"+fileName.substring(fileName.lastIndexOf("."),fileName.length());
                }
                // operType定义大目录，catalog 定义年月日下的小目录
                certificatePath= FileUtil.getInstance().uploadFile(imageURL,file, saveName, catalog, operType); //
            }else{
                throw new BusException("请选择要上传的图片，重新上传！"); 
            }
            jsonObject.put("fileNameOrig",fileName);
            jsonObject.put("fileName",saveName);
            jsonObject.put("attachmentUrl",certificatePath);
            jsonObject.put("resourceIP",resourceIP);
        }catch(BusException e){
            logger.error("上传图片失败", e);
            try {
                jsonObject.put("fileNameOrig","error");
                jsonObject.put("fileName","error");
                jsonObject.put("attachmentUrl",e.getMessage());
            } catch (JSONException e1) {
                logger.error("上传图片失败jsonObject", e.getMessage());
            }
        } catch (Exception e) {
            logger.error("上传图片失败", e);
            try {
                jsonObject.put("fileNameOrig","error");
                jsonObject.put("fileName","error");
                jsonObject.put("attachmentUrl","系统异常");
            } catch (JSONException e1) {
                logger.error("上传图片失败jsonObject", e.getMessage());
            }
        }
        return jsonObject.toString();
    } 

}
