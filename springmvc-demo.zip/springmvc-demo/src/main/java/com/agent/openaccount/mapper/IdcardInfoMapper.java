package com.agent.openaccount.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.IdcardInfo;

public interface IdcardInfoMapper extends BaseMapper<IdcardInfo, Integer> {
    
    public IdcardInfo findByIdNumber(@Param(value="idNumber") String idNumber);
    
    public int findCountByIdNumber(@Param(value="idNumber") String idNumber);

}
