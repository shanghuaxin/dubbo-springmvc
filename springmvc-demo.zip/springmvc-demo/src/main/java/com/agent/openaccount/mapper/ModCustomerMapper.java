package com.agent.openaccount.mapper;

import com.agent.common.BaseMapper;
import com.agent.openaccount.dto.ModCustomerListDTO;
import com.agent.openaccount.entity.ModCustomer;

import java.util.List;
import java.util.Map;

public interface ModCustomerMapper extends BaseMapper<ModCustomer, Integer> {
    public List<ModCustomerListDTO> modList(Map<String,Object> searchMap);
    public int modListCount(Map<String,Object> searchMap);
    public ModCustomer findById(Integer id);
    public int update(ModCustomer mod);
}
