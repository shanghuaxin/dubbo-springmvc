package com.agent.openaccount.entity;

import com.agent.common.BaseDomain;

/**
 * 系统附件表
 */
public class AttachedDocuments extends BaseDomain {

    private static final long serialVersionUID = -8636156601880872408L;
    private String attachmentName;    //附件名称(只存名称，不存其类型如123456.jpg，只存123456)
    private String attachmentUrl;     //附件存储路径
    private String attachmentType;    //不要加点，如直接word，pdf等，附件类型(是图片还是其他附件(pdf,word,excel)，图片1,pdf 2,word 3,excel 4)
    private Integer defaulOk;         //是否默认
    private String notice;            //说明
    private Integer size;             //尺寸
    private Integer sort;             //排序
    private Integer sourceId;         //来源表Id
    private String sourceName;        //来源表名称
    private String sourceType;        //来源类型

    public String getAttachmentName() {
        return attachmentName;
    }

    public void setAttachmentName(String attachmentName) {
        this.attachmentName = attachmentName;
    }

    public String getAttachmentUrl() {
        return attachmentUrl;
    }

    public void setAttachmentUrl(String attachmentUrl) {
        this.attachmentUrl = attachmentUrl;
    }

    public String getAttachmentType() {
        return attachmentType;
    }

    public void setAttachmentType(String attachmentType) {
        this.attachmentType = attachmentType;
    }

    public Integer getDefaulOk() {
        return defaulOk;
    }

    public void setDefaulOk(Integer defaulOk) {
        this.defaulOk = defaulOk;
    }

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    @Override
    public String toString() {
        return "AttachedDocuments [attachmentName=" + attachmentName + ", attachmentUrl=" + attachmentUrl
                + ", attachmentType=" + attachmentType + ", defaulOk=" + defaulOk + ", notice=" + notice + ", size="
                + size + ", sort=" + sort + ", sourceId=" + sourceId + ", sourceName=" + sourceName + ", sourceType="
                + sourceType + "]";
    }

}
