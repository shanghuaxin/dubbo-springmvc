package com.agent.openaccount.controller;

import java.io.File;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.channel.entity.ChannelAuth;
import com.agent.channel.entity.ChannelProduct;
import com.agent.channel.entity.ChannelWhite;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAuthService;
import com.agent.channel.service.ChannelProductService;
import com.agent.channel.service.ChannelWhiteService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.common.Result;
import com.agent.common.ResultEnum;
import com.agent.constant.Constant;
import com.agent.number.dto.NumberTopUpRestDTO;
import com.agent.number.entity.TNumber;
import com.agent.number.service.NumberService;
import com.agent.openaccount.dto.CheckListDTO;
import com.agent.openaccount.dto.OpenAccount;
import com.agent.openaccount.entity.ApplyIdentity;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.Check;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.service.ApplyIdentityService;
import com.agent.openaccount.service.AttachedDocumentsService;
import com.agent.openaccount.service.CheckService;
import com.agent.openaccount.service.IdcardInfoService;
import com.agent.openaccount.service.IdentityService;
import com.agent.openaccount.service.OpenAccountService;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.Utils;
import com.agent.product.entity.PackLevel;
import com.agent.product.entity.Packages;
import com.agent.product.service.PackagesService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.ExcelUtils;
import com.agent.util.IDCardUtil;
import com.agent.util.PhoneOpenUtil;
import com.agent.util.images.FileUtil;

@Controller
@RequestMapping("openAccount")
public class OpenAccountController {
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    
    /**说明：身份证识别功能 begin*/
    @Value("#{configProperties['timeKey']}")
    private String timeKey;//外部可自行设置TIMEKEY值， 也可使用引擎默认的KEY取
    /**说明：身份证识别功能 end*/
    
    
    private static Logger logger = (Logger) LoggerFactory.getLogger(OpenAccountController.class);
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private ChannelAuthService channelAuthService;
    @Autowired
    private NumberService numberService;
    @Autowired
    private PackagesService packagesService;
    @Autowired
    private OpenAccountService openAccountService;
    @Autowired
    private AttachedDocumentsService documentsService;
    @Autowired
    private ApplyIdentityService applyIdentityService;
    @Autowired
    private IdentityService identityService;
    @Autowired
    private IdcardInfoService idcardInfoService;
    @Autowired
    private CheckService checkService;
    @Autowired
    private ChannelProductService channelProductService;
    @Autowired
    private ChannelWhiteService channelWhiteService;
    
    @RequestMapping(value = "/open")
    public String accountOperation(HttpServletRequest request,HttpServletResponse response, String phone, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        //以下是获取当前渠道信息
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if(channels == null) {
            return "/deny.jsp";
        }
        ChannelAuth channelAuth = channelAuthService.findByChannelId(channels.getId());
        
        request.setAttribute("channels", channels);
        request.setAttribute("channelAuth", channelAuth);
        request.setAttribute("phone", phone);
        request.setAttribute("curDate", DateUtil.getInstance().formatDate(new Date(), "yyyy.MM.dd"));
        request.setAttribute("resourceIP", resourceIP);
        
        String type = request.getParameter("type");
        // 根据类型，返回不同的页面，默认返回开卡页面
        try {
            if ("buy".equals(type)) {
                response.sendRedirect("../buy-service/buy-page");
                return null;
            } else if ("mod".equals(type)) {
                response.sendRedirect("../mod-customer/mod");
                return null;
            }
        } catch (Exception e) {
            logger.error("系统异常", e);
        }
        
        return "/views/openaccount/open.jsp";
    }
    
    @RequestMapping(value = "openAccount", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> openAccount(OpenAccount oa,HttpServletRequest request,HttpServletResponse response , HttpSession session){
        Map<String, Object> map = new HashMap<String, Object>();
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            map.put("status", false);
            map.put("msg", "登录超时，请重新登录");
            return map;
        }
        
        //以下是渠道主页获取渠道信息
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if(channels == null) {
            map.put("status", false);
            map.put("msg", "当前用户非渠道用户，不能开户");
            return map;
        }
        
        if(channels.getStatus().intValue() == 3) {
            map.put("status", false);
            map.put("msg", "当前渠道已冻结开户，不能开户！");
            return map;
        }
        
        if(channels.getStatus().intValue() == 4) {
            map.put("status", false);
            map.put("msg", "当前渠道已冻结，不能开户！");
            return map;
        }
        
        if(channels.getChannelType().intValue() != 2){  //非网点将不能进行开户
            map.put("status", false);
            map.put("msg", "对不起，您的权限不足！");
            return map;
        }
        
        TNumber n = numberService.findByChannelIdAndPhone(oa.getPhone(), channels.getId());
        if(n == null) {
            map.put("status", false);
            map.put("msg", "对不起，您不能对号码开户。原因：号码不在库存！");
            return map;
        }
        
        Packages packages;
        try {
            packages = packagesService.findByPackageId(n.getPackagesId());
            if(packages == null){
                if(n.getOperatorCode()==1){
                    map.put("status", false);
                    map.put("msg", "对不起，您不能对该套餐的号码开户。原因：该号码绑定的套餐不存在！请联系客服！");
                    return map;
                }
            }else if(!StringUtils.equals(packages.getStatus(), "2")) {
                map.put("status", false);
                map.put("msg", "对不起，您不能对该套餐的号码开户。原因：该套餐的开户权限已关闭，暂不支持开户！请联系客服！");
                return map;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            map.put("status", false);
            map.put("msg", "对不起，绑定套餐数据查询异常！请联系客服！");
            return map;
        }
        
        if(n.getOperatorCode()==1){
            ChannelProduct channelProduct = channelProductService.channelProductShow(channels.getId(), n.getPackagesId());
            if(channelProduct == null || channelProduct.getIsShow() == 0){
                map.put("status", false);
                map.put("msg", "对不起，您不能对该套餐的号码开户。原因：您没有该套餐的开户权限！请联系客服！");
                return map;
            }
        }
        
        RestStatus isCheck = checkMoney(oa, channels.getId());
        if(!isCheck.getStatus()){
            map.put("status", false);
            map.put("msg", isCheck.getErrorMessage());
            return map;
        }
        
        if(Utils.isEmptyString(oa.getName()) || Utils.isEmptyString(oa.getCode())){
            map.put("status", false);
            map.put("msg", "请完整输入用户信息！");
            return map;
        }
        
        if(!IDCardUtil.isIDCard(oa.getCode())){
            map.put("status", false);
            map.put("msg", "请使用正确的身份证号码！");
            return map;
        }
    
        int minAge = 0;
        try {
            minAge = Integer.parseInt(DicUtil.getMapDictionary("MIN_OPEN_AGE").get("MIN_OPEN_AGE_VAL"));
        } catch (Exception e1) {
            minAge = 10;
            logger.error("最小开卡年龄没有配置，默认为10岁！");
        }
        if(!IDCardUtil.compareDate(oa.getCode(),minAge)){

            map.put("status", false);
            map.put("msg", "您的身份证年龄小于"+ minAge +"，开户失败");
            return map;
        }
        
        if(Utils.isEmptyString(oa.getAddress())){
            map.put("status", false);
            map.put("msg", "您的身份证地址信息未填写！");
            return map;
        }
        Pattern pattern = Pattern.compile("[\u4E00-\u9FA5]{1,10}([\u00B7]{0,1}[\u4E00-\u9FA5]{1,10})+");
        Matcher matcher = pattern.matcher(oa.getName());
        if (!matcher.matches()) {
            map.put("status", false);
            map.put("msg", "身份证姓名格式不正确");
            return map;
        }
        
        response.setContentType("text/html;charset=UTF-8");
        
        NumberTopUpRestDTO obj = new NumberTopUpRestDTO();
        try{
            String cardHandUploadFile = request.getParameter("cardHandUploadFile");
            String cardHandUploadFilePath = request.getParameter("cardHandUploadFilePath");
            String cardFrontUploadFile = request.getParameter("cardFrontUploadFile");
            String cardFrontUploadFilePath = request.getParameter("cardFrontUploadFilePath");
            String cardRearUploadFile = request.getParameter("cardRearUploadFile");
            String cardRearUploadFilePath = request.getParameter("cardRearUploadFilePath");
            //String imgStr = request.getParameter("imgStr");

            //图片规则：号码_类型_6位随机数_来源，  类型：1-正面照，2-反面照，3-手持照
            //是否需要上传附件或者是否身份证开卡
            if(channelAuthService.isUploadFile(channels.getId())){
                Boolean isres = false;
                if(null!=cardHandUploadFile){
                    if(Utils.isEmptyString(cardHandUploadFile)){
                        isres = true;
                    }
                }else{
                    isres = true;
                }
                if(null!=cardFrontUploadFile){
                    if(Utils.isEmptyString(cardFrontUploadFile)){
                        isres = true;
                    }
                }else{
                    isres = true;
                }
                if(null!=cardRearUploadFile){
                    if(Utils.isEmptyString(cardRearUploadFile)){
                        isres = true;
                    }
                }else{
                    isres = true;
                }
                if(isres){
                    map.put("status", false);
                    map.put("msg", "请上传照片！");
                    return map;
                }

                if(cardHandUploadFile.equals(cardFrontUploadFile)){
                    map.put("status", false);
                    map.put("msg", "身份证手持照和正面照不能相同！");
                    return map;
                }else if(cardHandUploadFile.equals(cardRearUploadFile)){
                    map.put("status", false);
                    map.put("msg", "身份证手持照和背面照不能相同！");
                    return map;
                }else if(cardFrontUploadFile.equals(cardRearUploadFile)){
                    map.put("status", false);
                    map.put("msg", "身份证正面照和背面照不能相同！");
                    return map;
                }
            }
            File localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + cardHandUploadFilePath);
            if(!localFileA.exists()){
                map.put("status", false);
                map.put("msg", "您的身份证手持照没有上传成功，请重新上传！");
                return map;
            } else {
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + cardHandUploadFilePath, imageURL + File.separator + cardHandUploadFilePath);
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "临时文件上传到正式目录异常！");
                    return map;
                }
            }
            localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + cardFrontUploadFilePath);
            if(!localFileA.exists()){
                map.put("status", false);
                map.put("msg", "您的身份证正面照没有上传成功，请重新上传！");
                return map;
            } else {
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + cardFrontUploadFilePath, imageURL + File.separator + cardFrontUploadFilePath);
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "临时文件上传到正式目录异常！");
                    return map;
                }
            }
            localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + cardRearUploadFilePath);
            if(!localFileA.exists()){
                map.put("status", false);
                map.put("msg", "您的身份证背面照没有上传成功，请重新上传！");
                return map;
            } else {
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + cardRearUploadFilePath, imageURL + File.separator + cardRearUploadFilePath);
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "临时文件上传到正式目录异常！");
                    return map;
                }
            }
            //该网点开的号码需要审核
            Boolean bool= channelAuthService.isCheck(channels.getId());
            
            //开卡后审核，如果遇到当前时间为系统维护时间，则这段时间的开卡操作都做开卡前审核处理
            RestStatus isPool = PhoneOpenUtil.isPool();//当前时间是否为出账时间，是否可以办理业务，不能办理业务走审核流程
            RestStatus isExce = PhoneOpenUtil.isExcpetion();//当前时间是否为系统维护时间，是否可以办理业务，不能办理业务走审核流程
            if(!isPool.getStatus() || !isExce.getStatus()){
                //开户信息录入开户申请表
                bool = true;
            }

            List<AttachedDocuments> atts = new ArrayList<>();
            String certificatePath="";
            AttachedDocuments att = new AttachedDocuments();
            //手持身份证照片
            if(null != cardHandUploadFile && !Utils.isEmptyString(cardHandUploadFile)){
                String imgType = "cardHand";
                String fileName = cardHandUploadFile;
                if(!Utils.isEmptyString(fileName)){
                    certificatePath=cardHandUploadFilePath;
                    att.setAttachmentName(fileName);
                    att.setAttachmentUrl(certificatePath);
                    if(bool){
                        att.setSourceName("t_apply_identity");
                    }else{
                        att.setSourceName("t_identity");
                    }
                    att.setSourceType(imgType);
                    atts.add(att);
                }
            }
            //身份证正面照
            if(null != cardFrontUploadFile && !Utils.isEmptyString(cardFrontUploadFile)){
                String imgType = "cardFront";
                String fileName = cardFrontUploadFile;
                
                if(!Utils.isEmptyString(fileName)){
                    certificatePath=cardFrontUploadFilePath;
                    att = new AttachedDocuments();
                    att.setAttachmentName(fileName);
                    att.setAttachmentUrl(certificatePath);
                    if(bool){
                        att.setSourceName("t_apply_identity");
                    }else{
                        att.setSourceName("t_identity");
                    }
                    att.setSourceType(imgType);
                    atts.add(att);
                }
            }
            //身份证背面照
            if(null != cardRearUploadFile && !Utils.isEmptyString(cardRearUploadFile)){
                String imgType = "cardRear";
                String fileName = cardRearUploadFile;
                
                if(!Utils.isEmptyString(fileName)){
                    certificatePath=cardRearUploadFilePath;
                    att = new AttachedDocuments();
                    att.setAttachmentName(fileName);
                    att.setAttachmentUrl(certificatePath);
                    if(bool){
                        att.setSourceName("t_apply_identity");
                    }else{
                        att.setSourceName("t_identity");
                    }
                    att.setSourceType(imgType);
                    atts.add(att);
                }
            }
            
            /*//头像，酷商取消上传头像功能
            if(null != imgStr && !Utils.isEmptyString(imgStr)){
                Map<String,Object> imgMap = new HashMap<String, Object>();
                // imgStr=uploadHeadImgTrueByOcr  表示OCR识别头像信息并已经上传到图片服务器成功
                if(imgStr.equals("uploadHeadImgTrueByOcr")){
                    imgMap.put("status", true);
                    imgMap.put("attachmentName", cardFrontUploadFile.replace("_1_", "_4_"));
                    imgMap.put("attachmentUrl", cardFrontUploadFilePath.replace("_1_", "_4_"));
                } 
                // 阅读器头像
                if(oa.getOpenWay().equals("1")) {
                    imgMap =  FileUtil.getInstance().imgStr(oa.getPhone(), imgStr ,"4",channels.getChannelCode(),imageURL,"PC");
                    if(!"true".equals(imgMap.get("status").toString())){
                        return imgMap;
                    }
                }
                att = new AttachedDocuments();
                att.setAttachmentName(imgMap.get("attachmentName").toString());
                att.setAttachmentUrl(imgMap.get("attachmentUrl").toString());
                if(bool){
                    att.setSourceName("t_apply_identity");
                }else{
                    att.setSourceName("t_identity");
                }
                att.setSourceType("cardHeadImg");
                atts.add(att);
            }*/

            obj.setName(oa.getName().trim());
            obj.setSexual(oa.getSexual());
            obj.setNation(oa.getNation());
            obj.setPhone(oa.getPhone());
            obj.setOrgans(oa.getOrgans());
            obj.setExpiryDate(oa.getExpiryDate());
            obj.setCode(oa.getCode());
            obj.setContactPhone(oa.getContactPhone());
            obj.setAddress(oa.getAddress());
            obj.setMoney(oa.getMoney());
            obj.setMealCodes(oa.getMealCodes());
            obj.setOpenWay(oa.getOpenWay());
            obj.setAtts(atts);
            obj.setResInstId(n.getResInstId());
            obj.setUimResInstId(n.getUimResInstId());
            obj.setIccid(n.getIccid());
            obj.setNumberLowerMoney(n.getMinFloat().toString());
            
            //开卡前审核：1、渠道实名设置2、当前时间为系统维护时间，则这段时间的开卡操作都做开卡前审核处理
            if(bool || (!isPool.getStatus() || !isExce.getStatus())){
                //开户信息录入开户申请表
                RestStatus restStatus= numberService.phoneTestExamine(obj, "PC", channels);
                if(restStatus.getStatus()){
                    map.put("status", true);
                    map.put("msg", restStatus.getErrorMessage());
                    map.put("flag", "0");
                    return map;
                }else{
                    map.put("status", false);
                    map.put("msg", restStatus.getErrorMessage());
                    return map;
                }
            }
            
            Boolean isPreSub  = numberService.findSubsByPhone(obj.getPhone());
            RestStatus rest = null;
            if(isPreSub){
                //boss已经预开户
                rest = numberService.prePhoneActivite(obj, "PC", channels);
            }else{
                //开卡后审核（修改开户状态默认开户成功，打开接口状态为待开户确认）
                rest = numberService.phoneActivite(obj,"PC",channels);
            }
            
            if(rest.getStatus()){
                map.put("status", true);
                map.put("msg", rest.getErrorMessage());
                return map;
            }else{
                map.put("status", false);
                map.put("msg", rest.getErrorMessage());
                return map;
            }
        }catch(Exception e){
            logger.error("调用接口号码开户失败，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", e.getMessage());
            return map;
        }
    }
    
    @RequestMapping("/openAccountList" )
    public String openAccountList(HttpServletRequest request, TNumber number, Integer sortBy, Integer pageSize, Integer pageIndex, String flag, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        if(sortBy == null){
            sortBy = 0;
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        
        Map<String, Object> params = new HashMap<String, Object>();
        
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if(channels == null && user.getBelongChannelId() == null) {
            request.setAttribute("channelLevel", 0);
        }else if(channels == null && user.getBelongChannelId() != null) {
            request.setAttribute("channelLevel", 1);
            params.put("curChannelId", user.getBelongChannelId());   //渠道客服默认是所属渠道Id
            params.put("channelLevel", 1);   //渠道客服默认是所属渠道级别
            if(number.getCheckStatus() == null){
                number.setCheckStatus("1");
            }
        }else {
            if(channels.getChannelType() == 1 && channels.getChannelLevel() == 1) {
                request.setAttribute("channelLevel", 1);
                params.put("curChannelId", channels.getId());   
                params.put("channelLevel", 1);   
                if(number.getCheckStatus() == null){
                    number.setCheckStatus("1");
                }
            }else if(channels.getChannelType() == 1 && channels.getChannelLevel() == 2) {  //二级渠道
                request.setAttribute("channelLevel", 2);
                params.put("curChannelId", channels.getId());   
                params.put("channelLevel", 2); 
                if(number.getCheckStatus() == null){
                    number.setCheckStatus("1");
                }
            }else {
                request.setAttribute("channelLevel", 3);
                params.put("curChannelId", channels.getId());   
                params.put("channelLevel", 3);
            }
        }
        
        if (StringUtils.isNotBlank(number.getOpenChannelName())) {
            List<Integer> channelIds = channelsService.findByCodeOrName(number.getOpenChannelName().trim());
            if(channelIds != null && channelIds.size() > 0){
                params.put("channelIds", channelIds);
            }else {
                channelIds.add(0);
                params.put("channelIds", channelIds);
            }
        }

        if (StringUtils.isNotBlank(number.getOpenWay())) {
            params.put("openWay", number.getOpenWay());
        }
        
        if (StringUtils.isNotBlank(number.getPhone())) {
            params.put("phone", number.getPhone().trim());
        }
        
        if (StringUtils.isNotBlank(number.getAscription())) {
            params.put("ascription", number.getAscription().trim());
        }
        
        if (number.getOperatorCode()!=null) {
            params.put("operatorCode", number.getOperatorCode());
        }
        
        if (StringUtils.isNotBlank(number.getLevel())) {
            params.put("level", number.getLevel());
        }
        
        if (StringUtils.isNotBlank(number.getStatus())) {
            params.put("status", number.getStatus());
        }
        
        if (number.getPackagesId() != null) {
            params.put("packagesId", number.getPackagesId());
        }
        
        if (StringUtils.isNotBlank(number.getCheckStatus())) {
            params.put("checkStatus", number.getCheckStatus());
        }
        
        if (StringUtils.isNotBlank(number.getAscription())) {
            String[] arr = number.getAscription().split("-");
            if(arr != null && arr.length == 2){
                params.put("ascription", arr[1]);
            }else if(arr != null && arr.length == 1){
                params.put("ascription", arr[0]);
            }
        }
        
        if (StringUtils.isNotBlank(number.getsDate())) {
            params.put("sDate", number.getsDate());
        }
        
        if (StringUtils.isNotBlank(number.geteDate())) {
            params.put("eDate", number.geteDate());
        }
        
        params.put("sortBy", sortBy);
        
        // 查询数据字典，获取要特殊处理的账号，如果跟登录账号一致，则只能查询指定开户时间的数据
        String loginName = DicUtil.getMapDictionary("HJHC_CONFIG").get("HJHC_LOGIN_NAME");
        String beginDate = DicUtil.getMapDictionary("HJHC_CONFIG").get("HJHC_OPEN_BEGINDATE");
        String endDate = DicUtil.getMapDictionary("HJHC_CONFIG").get("HJHC_OPEN_ENDDATE");
        if (null!=loginName && null!=beginDate && null!=endDate 
                && loginName.indexOf(user.getLoginName())>-1) {
            params.put("sDate", beginDate);
            params.put("eDate", endDate);
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<TNumber> numberList = openAccountService.listOpenAccount(params);
        int total = openAccountService.countOpenAccount(params);
        pageEntity.setTotal(total);
        
        List<Packages> packages = packagesService.findAllByProperty("2", "0");

        request.setAttribute("phoneLevel", DicUtil.getDictionarysByKey("PHONE_LEVEL_CODE"));
        request.setAttribute("numberList", numberList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("number", number);
        request.setAttribute("sortBy", sortBy);
        request.setAttribute("flag", flag);
        request.setAttribute("packages", packages);
        
        return "/views/openaccount/openaccountlist.jsp";
    }
    
    @RequestMapping("/operationList" )
    public String operationList(HttpServletRequest request, Integer phoneId , Integer pageSize, Integer pageIndex, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        
        Map<String, Object> params = new HashMap<String, Object>();
        
        TNumber number = numberService.findByPhoneId(phoneId);
        
        params.put("phoneId", number.getId());
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<CheckListDTO> dtos = checkService.operationNumberList(params);
        int total = checkService.operationNumberListTotal(params);
        pageEntity.setTotal(total);

        request.setAttribute("dtos", dtos);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("number", number);
        
        return "/views/openaccount/operationlist.jsp";
    }
    
    @RequestMapping("/batchViewPic" )
    public String batchViewPic(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        Map<String, Object> params = new HashMap<String, Object>();
        
        String phones = request.getParameter("phones");
        String sortBy = request.getParameter("sortBy");
        List<String> phoneList = new ArrayList<String>();
        String[] phoneArr = phones.split(",");
        if(phoneArr != null && phoneArr.length > 0){
            phoneList = Arrays.asList(phoneArr);
        }else {
            phoneList.add("");
        }
        
        params.put("phoneList", phoneList);
        params.put("sortBy", sortBy);
        
        List<TNumber> numberList = openAccountService.batchViewPic(params);

        request.setAttribute("resourceIP", resourceIP);
        request.setAttribute("numberList", numberList);
        
        return "/views/openaccount/batchViewPic.jsp";
    }
    
    @RequestMapping("/view" )
    public String view(HttpServletRequest request, HttpSession session) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }

        String idStr = request.getParameter("id");
        Integer id = null;
        if (StringUtils.isEmpty(idStr)) {
            id = 0;
        } else {
            id = Integer.parseInt(request.getParameter("id"));
        }
        String sourceName = request.getParameter("type");

        IdcardInfo idcardInfo = null;
        String phone = "";
        String contactPhone = "";
        if(StringUtils.equals(sourceName, "t_identity")) {
            //根据开户记录查看用户资料信息
            Identity identity = identityService.findById(id);
            if (null == identity) {
                identity = new Identity();
            }
            idcardInfo = idcardInfoService.findByIdNumber(identity.getCode());
            phone = identity.getPhone();
            contactPhone = identity.getContactPhone();
            if(idcardInfo == null) {
                idcardInfo = new IdcardInfo();
                idcardInfo.setIdNumber(identity.getCode());
            }
            idcardInfo.setName(identity.getName());
        }else {
            //根据开户申请记录查看用户资料信息
            ApplyIdentity applyIdentity = applyIdentityService.findById(id);
            if (null == applyIdentity) {
                applyIdentity = new ApplyIdentity();
            }
            idcardInfo = JSONUtil.jsonToObject(applyIdentity.getIdcardinfo(), IdcardInfo.class);
            //idcardInfo = idcardInfoService.findByIdNumber(applyIdentity.getCode());
            phone = applyIdentity.getPhone();
            contactPhone = applyIdentity.getContactPhone();
            if(idcardInfo == null) {
                idcardInfo = new IdcardInfo();
                idcardInfo.setIdNumber(applyIdentity.getCode());
            }
        }
        List<AttachedDocuments> attr = documentsService.findBySourceIdAndSourceName(id, sourceName);
        AttachedDocuments cardHeadImg = null;
        List<AttachedDocuments> attachedDocuments = null;
        if(null != attr && attr.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : attr){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                if(s.getSourceType().equals("cardHeadImg")){
                    try{
                        cardHeadImg = new AttachedDocuments();
                        BeanUtils.copyProperties(cardHeadImg, s);
                    }catch (Exception e){
                        logger.error("头像图片获取失败");
                    }
                }else{
                    attachedDocuments.add(s);
                }
            }
        }

        request.setAttribute("id", id);
        request.setAttribute("type", sourceName);
        request.setAttribute("phone", phone);
        request.setAttribute("cardHeadImg", cardHeadImg);
        request.setAttribute("contactPhone", contactPhone);
        request.setAttribute("idcardInfo", idcardInfo);
        request.setAttribute("attachedDocuments", attachedDocuments);

        return "/views/openaccount/view.jsp";
    }
    
    //审核
    @RequestMapping("/audit" )
    public String audit(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");
        if(StringUtils.isBlank(idStr)){
            request.setAttribute("flag", "2");
            return "/views/openaccount/audit.jsp";
        }
        Integer id = Integer.parseInt(idStr);
        String sourceName = request.getParameter("type");
        
        IdcardInfo idcardInfo = null;
        String phone = "";
        String contactPhone = "";
        int num = 0;
        int noCheckNum = 0;
        if(StringUtils.equals(sourceName, "t_identity")) {
            //根据开户记录查看用户资料信息
            Identity identity = identityService.findById(id);
            if(identity == null){
                request.setAttribute("flag", "2");
                return "/views/openaccount/audit.jsp";
            }
            num = identityService.findIdentityNumByCode(identity.getCode());
            noCheckNum = checkService.noCheckCount(identity.getChannelId());
            idcardInfo = idcardInfoService.findByIdNumber(identity.getCode());
            phone = identity.getPhone();
            contactPhone = identity.getContactPhone();
            if(idcardInfo == null) {
                idcardInfo = new IdcardInfo();
                idcardInfo.setIdNumber(identity.getCode());
            }
            idcardInfo.setName(identity.getName());
        }else {
            //根据开户申请记录查看用户资料信息
            ApplyIdentity applyIdentity = applyIdentityService.findById(id);
            if(applyIdentity == null){
                request.setAttribute("flag", "2");
                return "/views/openaccount/audit.jsp";
            }
            num = identityService.findIdentityNumByCode(applyIdentity.getCode());
            noCheckNum = checkService.noCheckCount(applyIdentity.getChannelId());
            if(applyIdentity != null){
                String idcardInfoJson = applyIdentity.getIdcardinfo();
                idcardInfo = JSONUtil.jsonToObject(idcardInfoJson, IdcardInfo.class);
                //idcardInfo = idcardInfoService.findByIdNumber(applyIdentity.getCode());
                if(idcardInfo == null) {
                    idcardInfo = new IdcardInfo();
                    idcardInfo.setIdNumber(applyIdentity.getCode());
                }
                phone = applyIdentity.getPhone();
                contactPhone = applyIdentity.getContactPhone();
            }
        }
        List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
        AttachedDocuments cardHeadImg = null;
        List<AttachedDocuments> attachedDocuments = null;
        if(null != atts && atts.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : atts){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                if(s.getSourceType().equals("cardHeadImg")){
                    try{
                        cardHeadImg = new AttachedDocuments();
                        BeanUtils.copyProperties(cardHeadImg, s);
                    }catch (Exception e){
                        logger.error("头像图片获取失败");
                    }
                }else{
                    attachedDocuments.add(s);
                }
            }
        }
        
        request.setAttribute("id", id);
        request.setAttribute("type", sourceName);
        request.setAttribute("phone", phone);
        request.setAttribute("num", num);
        request.setAttribute("noCheckNum", noCheckNum);
        request.setAttribute("contactPhone", contactPhone);
        request.setAttribute("idcardInfo", idcardInfo);
        request.setAttribute("cardHeadImg", cardHeadImg);
        request.setAttribute("attachedDocuments", attachedDocuments);
        
        return "/views/openaccount/audit.jsp";
    }
    
    //审核
    @RequestMapping("/auditDetail" )
    public String auditDetail(HttpServletRequest request, String phone, String pass, HttpSession session) {
        
        request.setAttribute("phone", phone);
        request.setAttribute("pass", pass);
        
        return "/views/openaccount/auditDetail.jsp";
    }
    
  //审核
    @RequestMapping("/picShow" )
    public String picShow(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");
        Integer id = null;
        if (StringUtils.isEmpty(idStr)) {
            id = 0;
        } else {
            id = Integer.parseInt(request.getParameter("id"));
        }
        String sourceName = request.getParameter("type");
        
        List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
        AttachedDocuments cardHeadImg = null;
        List<AttachedDocuments> attachedDocuments = null;
        if(null != atts && atts.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : atts){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                if(s.getSourceType().equals("cardHeadImg")){
                    try{
                        cardHeadImg = new AttachedDocuments();
                        BeanUtils.copyProperties(cardHeadImg, s);
                    }catch (Exception e){
                        logger.error("头像图片获取失败");
                    }
                }else{
                    attachedDocuments.add(s);
                }
            }
        }

        request.setAttribute("attachedDocuments", attachedDocuments);
        
        return "/views/openaccount/picShow.jsp";
    }
    
    //稽核
    @RequestMapping("/check" )
    public String check(HttpServletRequest request, HttpSession session) {
        String phone = "";
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return "login.jsp";
            }

            Integer id = Integer.parseInt(request.getParameter("id"));
            String sourceName = request.getParameter("type");

            IdcardInfo idcardInfo = null;
            String contactPhone = "";
            if(StringUtils.equals(sourceName, "t_identity")) {
                //根据开户记录查看用户资料信息
                Identity identity = identityService.findById(id);
                idcardInfo = idcardInfoService.findByIdNumber(identity.getCode());
                phone = identity.getPhone();
                contactPhone = identity.getContactPhone();
                if(idcardInfo == null) {
                    idcardInfo = new IdcardInfo();
                    idcardInfo.setIdNumber(identity.getCode());
                }
                idcardInfo.setName(identity.getName());
            }else {
                //根据开户申请记录查看用户资料信息
                ApplyIdentity applyIdentity = applyIdentityService.findById(id);
                idcardInfo = JSONUtil.jsonToObject(applyIdentity.getIdcardinfo(), IdcardInfo.class);
                if(idcardInfo == null) {
                    idcardInfo = idcardInfoService.findByIdNumber(applyIdentity.getCode());
                }
                phone = applyIdentity.getPhone();
                contactPhone = applyIdentity.getContactPhone();
                if(idcardInfo == null) {
                    idcardInfo = new IdcardInfo();
                    idcardInfo.setIdNumber(applyIdentity.getCode());
                }
                idcardInfo.setName(applyIdentity.getName());
            }
            List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
            TNumber n = numberService.findByPhone(phone);

            AttachedDocuments cardHeadImg = null;
            List<AttachedDocuments> attachedDocuments = null;
            if(null != atts && atts.size() >0){
                attachedDocuments = new ArrayList<AttachedDocuments>();
                for(AttachedDocuments s : atts){
                    s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                    if(s.getSourceType().equals("cardHeadImg")){
                        try{
                            cardHeadImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHeadImg, s);
                        }catch (Exception e){
                            logger.error("头像图片获取失败");
                        }
                    }else{
                        attachedDocuments.add(s);
                    }
                }
            }

            request.setAttribute("id", id);
            request.setAttribute("type", sourceName);
            request.setAttribute("phone", phone);
            request.setAttribute("sourceId", id);
            request.setAttribute("phoneId", n.getId());
            request.setAttribute("contactPhone", contactPhone);
            request.setAttribute("idcardInfo", idcardInfo);
            request.setAttribute("cardHeadImg", cardHeadImg);
            request.setAttribute("attachedDocuments", attachedDocuments);
        }catch (Exception e){
            logger.error("号码("+phone+")稽核失败");
        }
        return "/views/openaccount/check.jsp";
    }
    
    //稽核
    @RequestMapping("/checkDetail" )
    public String checkDetail(HttpServletRequest request, String phoneId, String pass, String sourceId, HttpSession session) {
        
        request.setAttribute("phoneId", phoneId);
        request.setAttribute("pass", pass);
        request.setAttribute("sourceId", sourceId);
        
        return "/views/openaccount/checkDetail.jsp";
    }
    
    public RestStatus checkMoney(OpenAccount oa, Integer channelId) {
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        BigDecimal minFloat = BigDecimal.ZERO;   //比较卡面额、号码低消、套餐金额、套餐低消的大小，返回最大值
        try {
            TNumber n = numberService.findByChannelIdAndPhone(oa.getPhone(), channelId);
            if(n == null) {
                return new RestStatus(Boolean.FALSE, "500", "号码("+oa.getPhone()+")不在库存");
            }
            Packages p = packagesService.findByPackageId(n.getPackagesId());
            if(n.getOperatorCode()==1){// 移动号码入库时候会绑定套餐
                if(p == null){
                    return new RestStatus(Boolean.FALSE, "500", "号码("+oa.getPhone()+")绑定的套餐不在库存");
                }else if(!StringUtils.equals(p.getStatus(), "2")) {
                    return new RestStatus(Boolean.FALSE, "500", "对不起，您不能对该套餐的号码开户。原因：该套餐的开户权限已关闭，暂不支持开户！请联系客服！");
                }
            } else {
                p = new Packages();
            }
            
            ChannelWhite channelWhite = channelWhiteService.findByChannelId(channelId);
            //0元开卡，设置套餐低消为0
            if(channelWhite != null && channelWhite.getStatus() == 1){
                if(n.getMoney().compareTo(BigDecimal.ZERO) == 0){
                    p.setLowConsume(BigDecimal.ZERO);
                }
            }
            BigDecimal packagesMoney = (p.getMoney() == null ? BigDecimal.ZERO : p.getMoney());  //套餐金额
            minFloat = (n.getMinFloat() == null ? BigDecimal.ZERO : n.getMinFloat());
            if(n.getMinFloat().compareTo(n.getChannelMoney()) < 0){  //号码面额为渠道更新后的面额
                minFloat = n.getChannelMoney();
            }
            if(minFloat.compareTo(packagesMoney) < 0){
                minFloat = p.getMoney();
            }
            if(minFloat.compareTo((p.getLowConsume()==null?BigDecimal.ZERO:p.getLowConsume())) < 0){
                minFloat = p.getLowConsume();
            }
            
            //号码绑定套餐、选中套餐金额总和
            if(StringUtils.isNotBlank(oa.getMealCodes())) {
                String mealsArr[] = oa.getMealCodes().split(",");
                
                if(mealsArr != null && mealsArr.length > 0) {
                    for (int i = 0; i < mealsArr.length; i++) {
                        Packages pac = packagesService.findByCode(mealsArr[i]);
                        if(pac == null){
                            return new RestStatus(Boolean.FALSE, "500", "您选择的套餐("+mealsArr[i]+")不存在");
                        }
                        packagesMoney = packagesMoney.add(pac.getMoney());
                    }
                }
            }
            
            //判断开户最低金额
            if(minFloat.compareTo(packagesMoney) < 0) {
                minFloat = packagesMoney;
            }
            
            //开户金额和开户最低金额比较
            BigDecimal money = new BigDecimal(oa.getMoney()).multiply(new BigDecimal(100));  //开户金额，单位：分
            if(money.compareTo(minFloat) < 0) {
                return new RestStatus(Boolean.FALSE, "500", "您输入的开卡金额错误，请重新输入");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE, "500", "开户失败，请联系客服！");
        }
        
        return restStatus;
    }
    
    /**
     * 检查电话号码是否当前开户渠道存在
     * @param phone
     * @param channelId
     * @return
     */
    @ResponseBody
    @RequestMapping(value="checkPhone") 
    public Result checkPhone(@RequestParam("phone") String phone, @RequestParam("channelId") Integer channelId){
        /*if(!StringUtils.equals(phone.substring(0, 3), "170")) {
            return new Result(405, "号码不在库存");
        }*/
        TNumber number = numberService.findByChannelIdAndPhone(phone, channelId);
        if(number == null) {
            return new Result(405, "号码不在库存");
        }
        try {
            Packages packages = packagesService.findByPackageId(number.getPackagesId());
            if(packages == null){
                if(number.getOperatorCode()==1){
                    return new Result(405, "对不起，您不能对该套餐的号码开户。原因：该号码绑定的套餐不存在！请联系客服！");
                } else {
                    packages = new Packages();
                }
            }else if(!StringUtils.equals(packages.getStatus(), "2")) {
                return new Result(405, "对不起，您不能对该套餐的号码开户。原因：该套餐的开户权限已关闭，暂不支持开户！请联系客服！");
            }
            number.setPackagesName(packages.getName());
            number.setPackageNotes(packages.getPackageNotes());
            number.setPackageMoney(packages.getMoneyStr());
            //number.setMinFloat(packages.getLowConsume());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        if(number.getOperatorCode()==1){
            ChannelProduct channelProduct = channelProductService.channelProductShow(channelId, number.getPackagesId());
            if(channelProduct == null || channelProduct.getIsShow() == 0){
                return new Result(405, "对不起，您不能对该套餐的号码开户。原因：您没有该套餐的开户权限！请联系客服！");
            }
        }
        if(number != null){
            if(StringUtils.equals(number.getStatus(), TNumber.STATUS_WAIT_ACTIVATE) && (StringUtils.isBlank(number.getCheckStatus()) 
                    || StringUtils.equals(number.getCheckStatus(), Check.audit_no))) { //待开户/审核不通过
                return new Result(0, "操作成功！", number);
            }else if(StringUtils.isNotBlank(number.getCheckStatus())){
                return new Result(405, "号码已开户");
            }
        }
        return new Result(405, "号码不在库存");
    }
    
    /**
     * 检查电话号码的ICCID号是否正确
     * @param phone
     * @param iccid
     * @return
     */
    @ResponseBody
    @RequestMapping(value="checkIccid") 
    public Result checkIccid(@RequestParam("phone") String phone, @RequestParam("channelId") Integer channelId, @RequestParam("iccidBack") String iccidBack, @RequestParam("packageMainId") Integer packageMainId){
        
        TNumber number = numberService.findByChannelIdAndPhone(phone, channelId);
        
        if(number != null){
            
            if(number.getOperatorCode()==1) {
                if(!StringUtils.equals(number.getIccid().substring(number.getIccid().length() - 6, number.getIccid().length()), iccidBack)) { //ICCID号码验证成功
                    return new Result(405, "ICCID号码错误");
                }
            } else {
                //后6位-到倒数第2位
                String IccidLastFive = number.getIccid().substring(number.getIccid().length() - 6, number.getIccid().length()-1);
                String iccIdBackLastFive = iccidBack.substring(0, iccidBack.length()-1);
                if(!StringUtils.equals(IccidLastFive, iccIdBackLastFive)) {
                    return new Result(405, "ICCID号码错误");
                }
            }
        
            //查找套餐
            Packages packages = null;
            try {
                //查找号码绑定套餐的所有叠加流量包
                if(number.getOperatorCode()==2) {
                    
                    if(number.getPackagesId()!=null && number.getPackagesId().intValue()>0) {
                        //已经绑定套餐
                        packages = packagesService.findById(number.getPackagesId());
                    } else {
                        // 联通号需要加载套餐列表
                        List<Packages> childPackages = new ArrayList<Packages>();
                        Map<String, Object> searchMap = new HashMap<String, Object>();
                        searchMap.put("phoneLevel", number.getLevel());
                        searchMap.put("channelId", channelId);
                        List<PackLevel> packLevels = packagesService.packLevelList(searchMap);
                        for(PackLevel pl : packLevels){
                            Packages p = new Packages();
                            p.setId(pl.getPacId());
                            p.setCode(pl.getPacCode());
                            p.setName(pl.getPacName());
                            p.setPackageNotes(pl.getPacNotes());
                            p.setMoney(new BigDecimal(pl.getPacMoney()));
                            childPackages.add(p);
                        }
                        number.setPackagesId((packageMainId!=null && packageMainId.intValue()>0)?packageMainId:packLevels.get(0).getPacId());
                        packages = packagesService.findById(number.getPackagesId());//联通默认第一个套餐
                        packages.setChildPackages(childPackages);
                    }
                    
                    List<Packages> djFlowPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "6");
                    List<Packages> yuyinPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "7");
                    List<Packages> dayPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "8");
                    List<Packages> reNewDayPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "9");
                    Map<String, List<Packages>> flowMap = new HashMap<String, List<Packages>>();
                    flowMap.put("djflowpackages",djFlowPackages);
                    flowMap.put("yuyinpackages", yuyinPackages);
                    flowMap.put("daypackages", dayPackages);
                    flowMap.put("renewdaypackages", reNewDayPackages);
                    packages.setDjFlowPackages(flowMap);
                } else {
                    packages = packagesService.findById(number.getPackagesId());
                }
                
                ChannelWhite channelWhite = channelWhiteService.findByChannelId(channelId);
                //0元开卡，设置套餐低消为0
                if(channelWhite != null && channelWhite.getStatus() == 1){
                    if(number.getMoney().compareTo(BigDecimal.ZERO) == 0){
                        packages.setLowConsume(BigDecimal.ZERO);
                    }
                }
                
                //查找号码绑定套餐的所有融合套餐
                List<Packages> fusionPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "5");
                //APP语音包
                // List<Packages> yuyinPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "3");
                //普通流量包
                List<Packages> flowPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "4");
                //来电显示
                List<Packages> showPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "2");
                //来电提醒
                List<Packages> alertPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "1");
                packages.setFusionPackages(fusionPackages);
                // packages.setYuyinPackages(yuyinPackages);
                packages.setFlowPackages(flowPackages);
                packages.setShowPackages(showPackages);
                if(number.getOperatorCode()!=2) {
                    packages.setAlertPackages(alertPackages);
                }
            } catch (Exception e) {
                return new Result(ResultEnum.SYSTEM_ERROR);
            }
            return new Result(0, "操作成功！", packages);
        }
        return new Result(405, "ICCID号码错误");
    }
    
    /**
     * 联通选择套餐
     * @param phone
     * @param iccid
     * @return
     */
    @ResponseBody
    @RequestMapping(value="choosePackage") 
    public Result choosePackage(@RequestParam("phone") String phone, @RequestParam("channelId") Integer channelId, @RequestParam("packageMainId") Integer packageMainId){
        
        TNumber number = numberService.findByChannelIdAndPhone(phone, channelId);
        
        if(number != null){
          //查找套餐
            Packages packages = null;
            try {
                number.setPackagesId(packageMainId);
                
                packages = packagesService.findById(number.getPackagesId());
                ChannelWhite channelWhite = channelWhiteService.findByChannelId(channelId);
                //0元开卡，设置套餐低消为0
                if(channelWhite != null && channelWhite.getStatus() == 1){
                    if(number.getMoney().compareTo(BigDecimal.ZERO) == 0){
                        packages.setLowConsume(BigDecimal.ZERO);
                    }
                }
                
                //查找号码绑定套餐的所有叠加流量包
                if(number.getOperatorCode()==2) {
                    List<Packages> djFlowPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "6");
                    List<Packages> yuyinPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "7");
                    List<Packages> dayPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "8");
                    List<Packages> reNewDayPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "9");
                    Map<String, List<Packages>> flowMap = new HashMap<String, List<Packages>>();
                    flowMap.put("djflowpackages",djFlowPackages);
                    flowMap.put("yuyinpackages", yuyinPackages);
                    flowMap.put("daypackages", dayPackages);
                    flowMap.put("renewdaypackages", reNewDayPackages);
                    packages.setDjFlowPackages(flowMap);
                }
                
                //查找号码绑定套餐的所有融合套餐
                List<Packages> fusionPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "5");
                //APP语音包
                // List<Packages> yuyinPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "3");
                //普通流量包
                List<Packages> flowPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "4");
                //来电显示
                List<Packages> showPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "2");
                //来电提醒
                List<Packages> alertPackages = packagesService.packgesByServTypeAndPId(number.getPackagesId(), "1");
                packages.setFusionPackages(fusionPackages);
                // packages.setYuyinPackages(yuyinPackages);
                packages.setFlowPackages(flowPackages);
                packages.setShowPackages(showPackages);
                packages.setAlertPackages(alertPackages);
            } catch (Exception e) {
                return new Result(ResultEnum.SYSTEM_ERROR);
            }
            return new Result(0, "操作成功！", packages);
        }
        return new Result(405, "ICCID号码错误");
    }
    
    /**
     * 生成随机数
     * @param length
     * @return
     */
    public static String getRandomString(int length) { //length表示生成字符串的长度
        return RandomStringUtils.randomNumeric(length);
    }
    
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/numberDetailExport",method=RequestMethod.GET)
    public void numberDetailExport(HttpServletRequest request, HttpServletResponse response, TNumber number , Integer pageSize, HttpSession session){
        logger.info("-------------开户列表导出开始-------------");
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);

            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            
            Map<String, Object> params = new HashMap<String, Object>();
            
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(channels == null && user.getBelongChannelId() == null) {
                request.setAttribute("channelLevel", 0);
            }else if(channels == null && user.getBelongChannelId() != null) {
                request.setAttribute("channelLevel", 1);
                params.put("curChannelId", user.getBelongChannelId());   //渠道客服默认是所属渠道Id
                params.put("channelLevel", 1);   //渠道客服默认是所属渠道级别
            }else {
                if(channels.getChannelType() == 1 && channels.getChannelLevel() == 1) {
                    request.setAttribute("channelLevel", 1);
                    params.put("curChannelId", channels.getId());   
                    params.put("channelLevel", 1);   
                }else if(channels.getChannelType() == 1 && channels.getChannelLevel() == 2) {  //二级渠道
                    request.setAttribute("channelLevel", 2);
                    params.put("curChannelId", channels.getId());   
                    params.put("channelLevel", 2); 
                }else {
                    request.setAttribute("channelLevel", 3);
                    params.put("curChannelId", channels.getId());   
                    params.put("channelLevel", 3);
                }
            }
            
            if (StringUtils.isNotBlank(number.getOpenChannelName())) {
                number.setOpenChannelName(URLDecoder.decode(number.getOpenChannelName(),"utf-8"));
                List<Integer> channelIds = channelsService.findByCodeOrName(number.getOpenChannelName().trim());
                if(channelIds != null && channelIds.size() > 0){
                    params.put("channelIds", channelIds);
                }else {
                    channelIds.add(0);
                    params.put("channelIds", channelIds);
                }
            }

            if (StringUtils.isNotBlank(number.getOpenWay())) {
                params.put("openWay", number.getOpenWay());
            }
            
            if (StringUtils.isNotBlank(number.getPhone())) {
                params.put("phone", number.getPhone().trim());
            }
            
            if (StringUtils.isNotBlank(number.getLevel())) {
                params.put("level", number.getLevel());
            }
            
            if (StringUtils.isNotBlank(number.getStatus())) {
                params.put("status", number.getStatus());
            }
            
            if (StringUtils.isNotBlank(number.getCheckStatus())) {
                params.put("checkStatus", number.getCheckStatus());
            }
            
            if (number.getPackagesId() != null) {
                params.put("packagesId", number.getPackagesId());
            }
            
            if (StringUtils.isNotBlank(number.getAscription())) {
                String[] arr = number.getAscription().split("-");
                if(arr != null && arr.length == 2){
                    params.put("ascription", arr[1]);
                }else if(arr != null && arr.length == 1){
                    params.put("ascription", arr[0]);
                }
            }
            
            if (StringUtils.isNotBlank(number.getsDate())) {
                params.put("sDate", number.getsDate());
            }
            
            if (StringUtils.isNotBlank(number.geteDate())) {
                params.put("eDate", number.geteDate());
            }
            
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            
            params.put("limit", limit);
            params.put("offset", offset);
            
            // 从页面获取每页展示的条数
            List<TNumber> numberList = openAccountService.listOpenAccount(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "openAccount" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"开户时间","开户渠道编码" ,"开户渠道名称" ,"号码" ,"号码级别" ,"号码归属地" ,"套餐" ,"号码低消（元）" ,"号码面额（元）" ,"开卡金额（元）" ,"网点扣款（元）" ,"手动输入" ,"开卡来源" ,"号码状态" ,"实名状态"};
            properties = new String[]{"openTimeStr","channelCode" ,"channelName" ,"phone" ,"level" ,"ascription" ,"packagesName" ,"minFloatYuan" ,"moneyYuan" ,"khMoneyYuan" ,"wdMoneyYuan" ,"openWayStr" ,"openSources" ,"statusStr" ,"checkStatusStr"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(),headers,numberList,properties);
            
        } catch (Exception e) {
            logger.error("开户列表记录导出失败"+e.getMessage(), e);
        }
        logger.info("-------------开户列表导出结束-------------");
    }

}
