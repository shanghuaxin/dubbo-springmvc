package com.agent.openaccount.entity;

import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * 过户信息表
 */
public class ModCustomer extends BaseDomain {

    private static final long serialVersionUID = 5678069971202843443L;
    private String phone;       //号码
    private Integer phoneId;       //号码id
    private Integer channelId;  //渠道id
    private String HisName;     //原用户名
    private String HisCode;     //原身份证
    private String name;        //用户名
    private String code;        //身份证号
    private String status;        //状态：1-待审核，2-审核不通过，0-审核通过
    private String contactPhone;//联系电话
    private String modSources;   //过户来源：PC（电脑），APP（手机）
    private Date customerDate;  //过户时间
    private String readType;//识别方式：1-阅读识别器,2-照片识别,3-NFC,4-亿数,5-华视,6-神思,7-信通，8-精伦,9-OCR
    private String custOrderId;  //联通过户回执单
    private String idcardinfo;  //身份证信息
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getHisName() {
        return HisName;
    }

    public void setHisName(String hisName) {
        HisName = hisName;
    }

    public String getHisCode() {
        return HisCode;
    }

    public void setHisCode(String hisCode) {
        HisCode = hisCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getCustomerDate() {
        return customerDate;
    }

    public void setCustomerDate(Date customerDate) {
        this.customerDate = customerDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getModSources() {
        return modSources;
    }

    public void setModSources(String modSources) {
        this.modSources = modSources;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }
    

    public String getReadType() {
        return readType;
    }

    public void setReadType(String readType) {
        this.readType = readType;
    }

    public String getCustOrderId() {
        return custOrderId;
    }

    public void setCustOrderId(String custOrderId) {
        this.custOrderId = custOrderId;
    }

    public String getIdcardinfo() {
        return idcardinfo;
    }

    public void setIdcardinfo(String idcardinfo) {
        this.idcardinfo = idcardinfo;
    }

    @Override
    public String toString() {
        return "ModCustomer{" +
                "phone='" + phone + '\'' +
                ", channelId=" + channelId +
                ", HisName='" + HisName + '\'' +
                ", HisCode='" + HisCode + '\'' +
                ", name='" + name + '\'' +
                ", code='" + code + '\'' +
                ", status='" + status + '\'' +
                ", contactPhone='" + contactPhone + '\'' +
                ", customerDate=" + customerDate +
                '}';
    }
}
