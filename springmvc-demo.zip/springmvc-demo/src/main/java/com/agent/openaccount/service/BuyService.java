package com.agent.openaccount.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.business.dto.PhoneStatusDTO;
import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.CommonUtil;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.BossPhoneStatus;
import com.agent.common.enumeration.OrderNOEnum;
import com.agent.common.enumeration.StatusType;
import com.agent.common.enumeration.UnicomStatus;
import com.agent.constant.Constant;
import com.agent.exception.SeeComException;
import com.agent.number.dto.BuyServDTO;
import com.agent.number.dto.BuyServSaveDTO;
import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberMapper;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.entity.Biz;
import com.agent.online.mapper.BizMapper;
import com.agent.openaccount.dto.BuyServRecordDTO;
import com.agent.openaccount.dto.BuyServRecordListDTO;
import com.agent.openaccount.entity.BuyServiceRecord;
import com.agent.openaccount.mapper.BuyServiceRecordMapper;
import com.agent.order.common.util.Utils;
import com.agent.product.entity.Packages;
import com.agent.product.mapper.PackagesMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.PhoneOpenUtil;

import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.ModOptionalOffer;
import namespace.webservice.crmsps.OfferWithStatus;
import namespace.webservice.crmsps.ProdOfferVO;
import namespace.webservice.crmsps.ProductChangeVO;
import namespace.webservice.crmsps.QueryUser;
import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;

@Service("buyService")
@Transactional(readOnly = true)
public class BuyService {
	private static Logger logger = (Logger) LoggerFactory .getLogger(BuyService.class);
	@Autowired
	private BusinessLogService logService;
	@Autowired
	private ChannelsMapper channelsMapper;
	@Resource
	private PackagesMapper pacMapper;
    @Resource
    private NumberMapper numberMapper;
	@Autowired
	private BuyServiceRecordMapper buyServiceRecordMapper;
    @Autowired
    private BizMapper bizMapper;
    @Autowired
    private BOSSNewBuyService bossNewBuyService;
    @Autowired
    private BOSSUnicomService bOSSUnicomService;
    

	@Transactional(readOnly=false,rollbackFor = Exception.class)
	public void busServRecordSave(List<BuyServRecordDTO> listDto) throws Exception{
		if(null != listDto && listDto.size() >0){
		    Map<String, Object> map = new HashMap<String, Object>();
		    map.put("list", listDto);
		    buyServiceRecordMapper.busServRecordSave(map);
		}else{
			throw new Exception("业务订购记录表入库失败，listDto 对象不能为空");
		}
	}
	
	/**
     * 获取待订购业务，入消息推送表
     * @return
     */
    @Transactional(readOnly=false)
    public void busServPush() throws Exception{
        if(!PhoneOpenUtil.isExcpetion().getStatus()){//系统故障或维护时间内不能推送订购
            return;
        }
		Map<String, Object> map = new HashMap<String, Object>();
		//移动业务
		List<String> buys = new ArrayList<String>();
		if(!PhoneOpenUtil.isPool().getStatus()){//收租时间不能推送业务
			buys.add(BuyServSaveDTO.NewConnection);
			buys.add(BuyServSaveDTO.SetIncomingCallService);
			buys.add(BuyServSaveDTO.DataPlanService);
			buys.add(BuyServSaveDTO.UnificationDataPlanService);
		}
        List<String> servBuys = new ArrayList<String>();//套餐可办理时，不能推送流量包，语音包变更业务
		if(PhoneOpenUtil.isModMeal().getStatus()){//套餐可办理时，不能推送套餐变更业务
		    buys.add(BuyServSaveDTO.MEAL_EDIT);
		    servBuys.add(BizType.FLOW_ORDER.getCode()+"2");
		    servBuys.add(BizType.VOICE.getCode()+"2");
            /* 客服要求流量包语音包退订取消押后推送
             * servBuys.add(BizType.FLOW_ORDER.getCode()+"1");
            servBuys.add(BizType.VOICE.getCode()+"1");*/
		}
		if(buys.size() >0){
		    map.put("notBuyType",buys);
		}
		if(servBuys.size() >0){
            map.put("notServBuys",servBuys);
        }
		
		map.put("network","1");
        map.put("status","1");
		List<BuyServiceRecord> records = buyServiceRecordMapper.listBuyPush(map);
        if(null != records && records.size() >0){
			Date d = new Date();
			for(BuyServiceRecord s:records){
				s.setStatus("1");
				s.setCreateTime(d);
			}
			buyServiceRecordMapper.batchInsertPush(records);
        }
        
        map = new HashMap<String, Object>();
        //联通业务
        if(PhoneOpenUtil.isPool().getStatus()){
            buys = new ArrayList<String>();
            if(PhoneOpenUtil.isModMeal().getStatus()){//套餐可办理时，不能推送套餐变更业务
                buys.add(BuyServSaveDTO.MEAL_EDIT);
                servBuys.add(BizType.FLOW_ORDER.getCode()+"0");
                servBuys.add(BizType.VOICE.getCode()+"0");
            }
            if(buys.size() >0){
                map.put("notBuyType",buys);
            }
            if(servBuys.size() >0){
                map.put("notServBuys",servBuys);
            }
            map.put("network","2");
            map.put("status","1");
            records = buyServiceRecordMapper.listBuyPush(map);
            if(null != records && records.size() >0){
                Date d = new Date();
                for(BuyServiceRecord s:records){
                    s.setStatus("1");
                    s.setCreateTime(d);
                }
                buyServiceRecordMapper.batchInsertPush(records);
            }
            
            //联通套餐变更校验入推送表
            map = new HashMap<String, Object>();
            map.put("network","2");
            map.put("status","4");
            records = buyServiceRecordMapper.listBuyPush(map);
            if(null != records && records.size() >0){
                Date d = new Date();
                for(BuyServiceRecord s:records){
                    s.setStatus("1");
                    s.setCreateTime(d);
                }
                buyServiceRecordMapper.batchInsertPush(records);
            }
        }
    }
    
	/**
	 * 移动号码业务订购
	 * @param dto
	 * @param us
	 * @throws Exception
	 */
	@Transactional(readOnly=false,rollbackFor = Exception.class)
	public void buySubMobile(BuyServDTO dto, User us) throws Exception{
		String[] oldServ = dto.getOldServ().split(",",-1);//顺序：融合包，流量包，语音包，来显，来电
		String[] newServ = dto.getNewServ().split(",",-1);
		logger.info("oldServ="+dto.getOldServ()+"，newServ="+dto.getNewServ());
		List<Integer> ids = new ArrayList<Integer>();
		for(int i=0;i<oldServ.length;i++){
			if(!Utils.isEmptyString(oldServ[i]) && !ids.contains(Integer.valueOf(oldServ[i]))){
				ids.add(Integer.valueOf(oldServ[i]));
			}
		}
		for(int i=0;i<newServ.length;i++){
			if(!Utils.isEmptyString(newServ[i]) && !ids.contains(Integer.valueOf(newServ[i]))){
				ids.add(Integer.valueOf(newServ[i]));
			}
		}
		
		Map<Integer,Packages> pacMap = new HashMap<Integer,Packages>();
		List<Packages> pacs = pacMapper.findByIds(ids);
		if(null != pacs && pacs.size() >0){
			for(Packages p:pacs){
				pacMap.put(p.getId(),p);
			}
		}
		TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
		bo.setMSISDN("86"+dto.getPhone());
		RestStatus rs = bossNewBuyService.QueryUserProfileBOSS(bo, new User());
		BigDecimal userBal; //用户余额
		if(rs.getStatus()){
			TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
			if(!"A".equals(res.getState())){
				throw new SeeComException("号码："+dto.getPhone()+"当前状态为："+DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()) + "，不可订购业务");
			}
			userBal = new BigDecimal(res.getBal());
		}else{
			throw new SeeComException(rs.getErrorMessage());
		}
		int lastDay = DateUtil.getInstance().lastDay();
        int nday = DateUtil.getInstance().day();
		BigDecimal servBal = new BigDecimal(0);
		if(!Utils.isEmptyString(newServ[0]) && Utils.isEmptyString(oldServ[0])){
			servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[0])).getMoney());
		}
		if(!Utils.isEmptyString(newServ[1]) && Utils.isEmptyString(oldServ[1])){
            //每天价格
		    BigDecimal c = pacMap.get(Integer.valueOf(newServ[1])).getMoney().divide(new BigDecimal(lastDay), 2, BigDecimal.ROUND_HALF_UP);
		    if(lastDay == nday){
		        servBal = servBal.add(c);
		    }else{
		        BigDecimal dayNum = new BigDecimal(lastDay-nday+1);//剩余天数
		        BigDecimal lc = c.multiply(dayNum);//剩余天数*每天金额
		        servBal = servBal.add(lc);
		    }
		}
		if(!Utils.isEmptyString(newServ[2]) && Utils.isEmptyString(oldServ[2])){
            //每天价格
            BigDecimal c = pacMap.get(Integer.valueOf(newServ[2])).getMoney().divide(new BigDecimal(lastDay), 2, BigDecimal.ROUND_HALF_UP);
            if(lastDay == nday){
                servBal = servBal.add(c);
            }else{
                BigDecimal dayNum = new BigDecimal(lastDay-nday+1);//剩余天数
                BigDecimal lc = c.multiply(dayNum);//剩余天数*每天金额
                servBal = servBal.add(lc);
            }
		}
		if(!Utils.isEmptyString(newServ[3]) && Utils.isEmptyString(oldServ[3])){
			//每天价格
            BigDecimal c = pacMap.get(Integer.valueOf(newServ[3])).getMoney().divide(new BigDecimal(lastDay), 2, BigDecimal.ROUND_HALF_UP);
            if(lastDay == nday){
                servBal = servBal.add(c);
            }else{
                BigDecimal dayNum = new BigDecimal(lastDay-nday+1);//剩余天数
                BigDecimal lc = c.multiply(dayNum);//剩余天数*每天金额
                servBal = servBal.add(lc);
            }
		}
		//servBal = servBal.add(new BigDecimal(500000));
		if(servBal.floatValue() > userBal.floatValue()){
			throw new SeeComException("对不起，用户余额不足，不能订购当前业务！");
		}
				
		//查询订购融合包包含业务
		/*Set<String> lowType = new HashSet<String>();
		if(Utils.isEmptyString(oldServ[0]) && !Utils.isEmptyString(newServ[0])){  //订购融合包
		    Map<String,Object> searchMap = new HashMap<String,Object>();
			searchMap.put("pacGroupId",newServ[0]);
			List<Packages> lowPacs = pacMapper.listPacLew(searchMap);
			if(null != lowPacs && lowPacs.size() >0){
				for(Packages s:lowPacs){
					if(!lowType.contains(s.getServType())){
						lowType.add(s.getServType());
					}
				}
			}
		}else if(!Utils.isEmptyString(oldServ[0]) && Utils.isEmptyString(newServ[0])){  //退订融合包
			searchMap = new HashMap<String,Object>();
			searchMap.put("pacGroupId",oldServ[0]);
			List<Packages> lowPacs = pacMapper.listPacLew(searchMap);
			if(null != lowPacs && lowPacs.size() >0){
				for(Packages s:lowPacs){
					if(!lowType.contains(s.getServType())){
						lowType.add(s.getServType());
					}
				}
			}
		}else if(!Utils.isEmptyString(oldServ[0]) && !Utils.isEmptyString(newServ[0]) && !oldServ[0].equals(newServ[0])){  //变更融合包
			searchMap = new HashMap<String,Object>();
			searchMap.put("pacGroupId",newServ[0]);
			List<Packages> lowPacs = pacMapper.listPacLew(searchMap);
			if(null != lowPacs && lowPacs.size() >0){
				for(Packages s:lowPacs){
					if(!lowType.contains(s.getServType())){
						lowType.add(s.getServType());
					}
				}
			}
			searchMap = new HashMap<String,Object>();
			searchMap.put("pacGroupId",oldServ[0]);
			lowPacs = pacMapper.listPacLew(searchMap);
			if(null != lowPacs && lowPacs.size() >0){
				for(Packages s:lowPacs){
					if(!lowType.contains(s.getServType())){
						lowType.add(s.getServType());
					}
				}
			}
		}*/
		
		TNumber n = numberMapper.findByPhone(dto.getPhone());
        //保存销户业务办理信息
        List<Biz> saveList = new ArrayList<Biz>();
		//获取当前时间
        Date d = new Date();
		Channels ch = channelsMapper.findByUserId(us.getId());
		StringBuffer servInfo = new StringBuffer();
		List<BuyServiceRecord> buys = new ArrayList<BuyServiceRecord>();
		BuyServiceRecord recordDTO = new BuyServiceRecord();
		StringBuffer parmStr = new StringBuffer();
		/*recordDTO.setPhone(dto.getPhone());
		if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
		recordDTO.setNowsType("2");
        recordDTO.setNetwork("1");
		recordDTO.setStatus("1");
		recordDTO.setPortNum(0);
		recordDTO.setCertName(dto.getCertName());
		recordDTO.setCertNbr(dto.getCertNbr());
		recordDTO.setBuyType("7");
		recordDTO.setMemo("组合业务");
		if(Utils.isEmptyString(oldServ[0]) && !Utils.isEmptyString(newServ[0])){
			//订购融合包
		    recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
			parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
			parmStr.append("OperType:").append("0").append(",");
			parmStr.append("NewOfferId:").append(pacMap.get(Integer.valueOf(newServ[0])).getCode());
			servInfo.append("号码：" + dto.getPhone() + "订购组合业务：" + pacMap.get(Integer.valueOf(newServ[0])).getName());
			recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[0])).getCode());
			recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[0])).getMoney());
			recordDTO.setServName("订购组合业务：" + pacMap.get(Integer.valueOf(newServ[0])).getName());
			recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[0])).getCode());
			recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[0])).getName());
		}else if(!Utils.isEmptyString(oldServ[0]) && Utils.isEmptyString(newServ[0])){
			//取消融合包
            recordDTO.setOptType(BuyServiceRecord.opt_type_1);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
			parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
			parmStr.append("OperType:").append("1").append(",");
			parmStr.append("OldOfferId:").append(pacMap.get(Integer.valueOf(oldServ[0])).getCode());
			servInfo.append("号码：" + dto.getPhone() + "取消组合业务：" + pacMap.get(Integer.valueOf(oldServ[0])).getName());
			recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[0])).getCode());
			recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[0])).getMoney());
			recordDTO.setServName("退订组合业务：" + pacMap.get(Integer.valueOf(oldServ[0])).getName());
			recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[0])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[0])).getName());
		}else if(!Utils.isEmptyString(oldServ[0]) && !Utils.isEmptyString(newServ[0]) && !oldServ[0].equals(newServ[0])){
			//变更融合包
            recordDTO.setOptType(BuyServiceRecord.opt_type_2);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
			parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
			parmStr.append("OperType:").append("2").append(",");
			parmStr.append("OldOfferId:").append(pacMap.get(Integer.valueOf(oldServ[0])).getCode()).append(",");
			parmStr.append("NewOfferId:").append(pacMap.get(Integer.valueOf(newServ[0])).getCode());
			servInfo.append("号码：" + dto.getPhone() + "变更组合业务：" + pacMap.get(Integer.valueOf(oldServ[0])).getName() + "为：" + pacMap.get(Integer.valueOf(newServ[0])).getName());
			recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[0])).getCode());
			recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[0])).getMoney());
			recordDTO.setServName("组合业务：" + pacMap.get(Integer.valueOf(oldServ[0])).getName()+" 变更为："+pacMap.get(Integer.valueOf(newServ[0])).getName());
			recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[0])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[0])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[0])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[0])).getName());
		}
		recordDTO.setOrderNum("3");
		recordDTO.setParmStr(parmStr.toString());
		recordDTO.setChannelId(ch.getId());
		recordDTO.setChannelName(ch.getChannelName());
		recordDTO.setSourceType(dto.getSourceType());
		recordDTO.setCreateId(us.getId());
		recordDTO.setCreateTime(d);
		recordDTO.setUpdateId(us.getId());
		recordDTO.setUpdateTime(d);
		recordDTO.setPushTime(d);
		if(!Utils.isEmptyString(parmStr.toString())){
		    Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[0]) ? 0: Integer.valueOf(newServ[0]),Utils.isEmptyString(oldServ[0]) ? 0: Integer.valueOf(oldServ[0]),d,StatusType.PROCESS.getCode(),"流量业务");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
		}*/

		recordDTO = new BuyServiceRecord();
		parmStr = new StringBuffer();
		recordDTO.setPhone(dto.getPhone());
		if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
		recordDTO.setNowsType("2");
        recordDTO.setNetwork("1");
		recordDTO.setStatus("1");
		recordDTO.setPortNum(0);
		recordDTO.setCertName(dto.getCertName());
		recordDTO.setCertNbr(dto.getCertNbr());
		recordDTO.setBuyType("6");
		recordDTO.setMemo("流量业务");
		//if(!lowType.contains("4") ){//如果订购或变更融合包，包含流量业务流量业务不变更，不退订，不订购，boss内部自动处理
			if(Utils.isEmptyString(oldServ[1]) && !Utils.isEmptyString(newServ[1])){
				//订购流量包
	            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
	            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("0").append(",");
				parmStr.append("NewOfferId:").append(pacMap.get(Integer.valueOf(newServ[1])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "订购流量业务：" + pacMap.get(Integer.valueOf(newServ[1])).getName());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[1])).getMoney());
				recordDTO.setServName("订购流量业务：" + pacMap.get(Integer.valueOf(newServ[1])).getName());
				recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
	            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[1])).getName());
	            recordDTO.setPushTime(d);
			}else if(!Utils.isEmptyString(oldServ[1]) && Utils.isEmptyString(newServ[1])){
				//取消流量包
                recordDTO.setOptType(BuyServiceRecord.opt_type_1);
                recordDTO.setValidType(BuyServiceRecord.valid_type_2);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("1").append(",");
				parmStr.append("OldOfferId:").append(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "取消流量业务：" + pacMap.get(Integer.valueOf(oldServ[1])).getName());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[1])).getMoney());
				recordDTO.setServName("退订流量业务：" + pacMap.get(Integer.valueOf(oldServ[1])).getName());
                recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
                recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[1])).getName());
                recordDTO.setPushTime(d);
			}else if(!Utils.isEmptyString(oldServ[1]) && !Utils.isEmptyString(newServ[1]) && !oldServ[1].equals(newServ[1])){
				//变更流量包
                recordDTO.setOptType(BuyServiceRecord.opt_type_2);
                recordDTO.setValidType(BuyServiceRecord.valid_type_2);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("2").append(",");
				parmStr.append("OldOfferId:").append(pacMap.get(Integer.valueOf(oldServ[1])).getCode()).append(",");
				parmStr.append("NewOfferId:").append(pacMap.get(Integer.valueOf(newServ[1])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "流量业务：" + pacMap.get(Integer.valueOf(oldServ[1])).getName() + "变更为：" + pacMap.get(Integer.valueOf(newServ[1])).getName());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[1])).getMoney());
				recordDTO.setServName("流量业务：" + pacMap.get(Integer.valueOf(oldServ[1])).getName() + " 变更为：" + pacMap.get(Integer.valueOf(newServ[1])).getName());
				recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
                recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[1])).getName());
                recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
                recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[1])).getName());
                recordDTO.setPushTime(d);
			}
		//}
		recordDTO.setOrderNum("2");
		recordDTO.setParmStr(parmStr.toString());
		recordDTO.setChannelId(ch.getId());
		recordDTO.setChannelName(ch.getChannelName());
		recordDTO.setSourceType(dto.getSourceType());
		recordDTO.setCreateId(us.getId());
		recordDTO.setCreateTime(d);
		recordDTO.setUpdateId(us.getId());
		recordDTO.setUpdateTime(d);
		if(!Utils.isEmptyString(parmStr.toString())){
			Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[1]) ? 0: Integer.valueOf(newServ[1]),Utils.isEmptyString(oldServ[1]) ? 0: Integer.valueOf(oldServ[1]),d,StatusType.PROCESS.getCode(),"流量业务");
            saveList.add(b);
			recordDTO.setOrderNo(b.getOrderNo());
			buys.add(recordDTO);
		}


		recordDTO = new BuyServiceRecord();
		parmStr = new StringBuffer();
		recordDTO.setPhone(dto.getPhone());
		if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
		recordDTO.setNowsType("2");
        recordDTO.setNetwork("1");
		recordDTO.setStatus("1");
		recordDTO.setPortNum(0);
		recordDTO.setCertName(dto.getCertName());
		recordDTO.setCertNbr(dto.getCertNbr());
		recordDTO.setBuyType("3");
		recordDTO.setMemo("来电显示");
		//if(!lowType.contains("2")) {//如果订购或变更融合包，包含来电显示 来电显示不变更，不退订，不订购，boss内部自动处理
			if(Utils.isEmptyString(oldServ[2]) && !Utils.isEmptyString(newServ[2])){
				//订购来显
                recordDTO.setOptType(BuyServiceRecord.opt_type_0);
                recordDTO.setValidType(BuyServiceRecord.valid_type_1);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("0").append(",");
				parmStr.append("ServiceCode:").append(pacMap.get(Integer.valueOf(newServ[2])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "订购来电显示：" + pacMap.get(Integer.valueOf(newServ[2])).getName());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[2])).getCode());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[2])).getMoney());
				recordDTO.setServName("订购来电显示");
				recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[2])).getCode());
                recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[2])).getName());
			}else if(!Utils.isEmptyString(oldServ[2]) && Utils.isEmptyString(newServ[2])){
				//取消来显
                recordDTO.setOptType(BuyServiceRecord.opt_type_1);
                recordDTO.setValidType(BuyServiceRecord.valid_type_2);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("1").append(",");
				parmStr.append("ServiceCode:").append(pacMap.get(Integer.valueOf(oldServ[2])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "取消来电显示：" + pacMap.get(Integer.valueOf(oldServ[2])).getName());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[2])).getCode());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[2])).getMoney());
				recordDTO.setServName("退订来电显示");
                recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[2])).getCode());
                recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[2])).getName());
			}
		//}
		recordDTO.setOrderNum("4");
		recordDTO.setParmStr(parmStr.toString());
		recordDTO.setChannelId(ch.getId());
		recordDTO.setChannelName(ch.getChannelName());
		recordDTO.setSourceType(dto.getSourceType());
		recordDTO.setCreateId(us.getId());
		recordDTO.setCreateTime(d);
		recordDTO.setUpdateId(us.getId());
		recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
		if(!Utils.isEmptyString(parmStr.toString())){
		    Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[2]) ? 0: Integer.valueOf(newServ[2]),Utils.isEmptyString(oldServ[2]) ? 0: Integer.valueOf(oldServ[2]),d,StatusType.PROCESS.getCode(),"来电显示");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
		}

		recordDTO = new BuyServiceRecord();
		parmStr = new StringBuffer();
		recordDTO.setPhone(dto.getPhone());
		if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
		recordDTO.setNowsType("2");
        recordDTO.setNetwork("1");
		recordDTO.setStatus("1");
		recordDTO.setPortNum(0);
		recordDTO.setCertName(dto.getCertName());
		recordDTO.setCertNbr(dto.getCertNbr());
		recordDTO.setBuyType("3");
		//if(!lowType.contains("1")) {//如果订购或变更融合包，包含来电提醒 来电提醒不变更，不退订，不订购，boss内部自动处理
			if(Utils.isEmptyString(oldServ[3]) && !Utils.isEmptyString(newServ[3])){
				//订购来电
                recordDTO.setOptType(BuyServiceRecord.opt_type_0);
                recordDTO.setValidType(BuyServiceRecord.valid_type_1);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("0").append(",");
				parmStr.append("ServiceCode:").append(pacMap.get(Integer.valueOf(newServ[3])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "订购来电显示：" + pacMap.get(Integer.valueOf(newServ[3])).getName());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[3])).getCode());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[3])).getMoney());
				recordDTO.setServName("订购来电提醒");
				recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[3])).getCode());
                recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[3])).getName());
			}else if(!Utils.isEmptyString(oldServ[3]) && Utils.isEmptyString(newServ[3])){
				//取消来电
                recordDTO.setOptType(BuyServiceRecord.opt_type_1);
                recordDTO.setValidType(BuyServiceRecord.valid_type_2);
				parmStr.append("MSISDN:").append("86" + dto.getPhone()).append(",");
				parmStr.append("OperType:").append("1").append(",");
				parmStr.append("ServiceCode:").append(pacMap.get(Integer.valueOf(oldServ[3])).getCode());
				servInfo.append("，号码：" + dto.getPhone() + "取消来电显示：" + pacMap.get(Integer.valueOf(oldServ[3])).getName());
				recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[3])).getMoney());
				recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[3])).getCode());
				recordDTO.setServName("退订来电提醒");
                recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[3])).getCode());
                recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[3])).getName());
			}
		//}
		recordDTO.setOrderNum("5");
		recordDTO.setParmStr(parmStr.toString());
		recordDTO.setChannelId(ch.getId());
		recordDTO.setChannelName(ch.getChannelName());
		recordDTO.setSourceType(dto.getSourceType());
		recordDTO.setCreateId(us.getId());
		recordDTO.setCreateTime(d);
		recordDTO.setUpdateId(us.getId());
		recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
		if(!Utils.isEmptyString(parmStr.toString())){
			Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[3]) ? 0: Integer.valueOf(newServ[3]),Utils.isEmptyString(oldServ[3]) ? 0: Integer.valueOf(oldServ[3]),d,StatusType.PROCESS.getCode(),"来电提醒");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
		}
		if(buys.size() <1){
			throw new SeeComException("您没有订购任何业务");
		}
        

	      
		RestStatus orderServRS = orderServiceVerify(buys);
		if(!orderServRS.getStatus()){
		    throw new SeeComException(orderServRS.getErrorMessage());
		}
		/*if(!Utils.isEmptyString(dto.getOldServ()) || !Utils.isEmptyString(dto.getNewServ())){
            throw new Exception("测试错误");
        }*/
        bizMapper.batchInsert(saveList);
		buyServiceRecordMapper.batchInsert(buys);

		//日志记录
		Map<String,String> logmap = new HashMap<String,String>();
		logmap.put("staff", us.getLoginName());
		logmap.put("phone",dto.getPhone());
		logmap.put("servInfo",servInfo.toString().substring(1,servInfo.toString().length()));
		logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
		logmap.put("result","成功！");
		logService.businessSaveLog(Business.phone_buy_Sub,String.valueOf(us.getId()),us.getLoginName(),
				"0","业务订购",logmap);
	}
	


    /**
     * 联通号码订购业务
     * @param dto
     * @param us
     * @throws Exception
     */
    @Transactional(readOnly=false,rollbackFor = Exception.class)
    public void buySubUnicom(BuyServDTO dto, User us) throws Exception{
        String[] oldServ = dto.getOldServ().split(",",-1);//顺序：融合包，流量包，来显，来电，叠加包，基础语音包，普通日包，续订日包
        String[] newServ = dto.getNewServ().split(",",-1);//流量包，来显，来电，叠加包，基础语音包，普通日包，续订日包
        logger.info("业务办理：oldServ="+dto.getOldServ()+"，newServ="+dto.getNewServ());
        List<Integer> appendFlows = new ArrayList<>();//叠加包
        List<Integer> ids = new ArrayList<Integer>();
        for(int i=0;i<oldServ.length;i++){
            if(!Utils.isEmptyString(oldServ[i]) && !ids.contains(Integer.valueOf(oldServ[i]))){
                ids.add(Integer.valueOf(oldServ[i]));
            }
        }
        for(int i=0;i<newServ.length;i++){
            if(i == 4){
                if(!Utils.isEmptyString(newServ[i])){
                    //叠加流量包特殊处理
                    String[] appendFlow = newServ[i].split("_");
                    for(int j=0;j<appendFlow.length;j++){
                        if(!Utils.isEmptyString(appendFlow[j]) && !ids.contains(Integer.valueOf(appendFlow[j]))){
                            appendFlows.add(Integer.valueOf(appendFlow[j]));
                            ids.add(Integer.valueOf(appendFlow[j]));
                        }
                    }
                }
            }else{
                if(!Utils.isEmptyString(newServ[i]) && !ids.contains(Integer.valueOf(newServ[i]))){
                    ids.add(Integer.valueOf(newServ[i]));
                }
            }
        }
        Map<Integer,Packages> pacMap = new HashMap<Integer,Packages>();
        List<Packages> pacs = pacMapper.findByIds(ids);
        if(null != pacs && pacs.size() >0){
            for(Packages p:pacs){
                pacMap.put(p.getId(),p);
            }
        }
        QueryUser cd = new QueryUser();
        cd.setQueryValue(dto.getPhone());
        cd.setQueryType("0");
        cd.setProductId("-1");
        cd.setCityCode("360");
        RestStatus  rs = bOSSUnicomService.queryUserService(cd,us);
        BigDecimal userBal = new BigDecimal(0);
        ContractRoot cr = null;
        if(rs.getStatus()){
            cr = (ContractRoot)rs.getResponseData();
            if(!"109999".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                throw new SeeComException("号码："+dto.getPhone()+"当前状态为："+UnicomStatus.getName(Integer.valueOf(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())) + "，不可订购业务");
            }
            userBal = new BigDecimal(cr.getSvcCont().getUserInfoView().getUserInfo().getAvailableBalance());
        }else{
            throw new SeeComException(rs.getErrorMessage());
        }
        //userBal = new BigDecimal(9999999);
        //查询当月订购的业务
        BigDecimal servBal = new BigDecimal(0);
        if(!Utils.isEmptyString(newServ[1]) && Utils.isEmptyString(oldServ[1])){
            servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[1])).getMoney());
        }
        Map<String, Object> searchMap;
        if(!Utils.isEmptyString(newServ[2]) && Utils.isEmptyString(oldServ[2])){
            searchMap = new HashMap<>();
            searchMap.put("buyType", "209");//来显
            searchMap.put("phone", dto.getPhone());
            searchMap.put("status", "0");
            searchMap.put("parmStrLike", "ServiceOfferId:1");
            int c = buyServiceRecordMapper.listDtoCount(searchMap);
            if(c == 0){//没有进行过来显，来电订购
                servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[2])).getMoney());
            }
        }
        if(!Utils.isEmptyString(newServ[3]) && Utils.isEmptyString(oldServ[3])){
            searchMap = new HashMap<>();
            searchMap.put("buyType", "203");//来提
            searchMap.put("phone", dto.getPhone());
            searchMap.put("status", "0");
            searchMap.put("parmStrLike", "ServiceOfferId:1");
            int c = buyServiceRecordMapper.listDtoCount(searchMap);
            if(c == 0){//没有进行过来显，来电订购
                servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[3])).getMoney());
            }
        }
        if(appendFlows.size() > 0){
            for(Integer s:appendFlows){
                servBal = servBal.add(pacMap.get(s).getMoney());
            }
        }
        if(!Utils.isEmptyString(newServ[5]) && Utils.isEmptyString(oldServ[5])){
            servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[5])).getMoney());
        }
        if(!Utils.isEmptyString(newServ[6]) && Utils.isEmptyString(oldServ[6])){
            servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[6])).getMoney());
        }
        if(!Utils.isEmptyString(newServ[7]) && Utils.isEmptyString(oldServ[7])){
            servBal = servBal.add(pacMap.get(Integer.valueOf(newServ[7])).getMoney());
        }
        if(servBal.floatValue() > userBal.multiply(Constant.cnt100).floatValue()){
            throw new SeeComException("对不起，用户余额不足，不能订购当前业务！");
        }
        searchMap = new HashMap<String,Object>();
        searchMap.put("servType", "0");
        searchMap.put("network", "LT");
        searchMap.put("code", cr.getSvcCont().getUserInfoView().getUserInfo().getProdOfferId());
        List<Packages> pack = pacMapper.listPac(searchMap);
        //订购省内普通日包，不能订购国内普通日包
        searchMap = new HashMap<String,Object>();
        searchMap.put("parentId",pack.get(0).getId());
        searchMap.put("network", "LT");
        List<Packages> lwPacsAll = pacMapper.listPac(searchMap);//当前套餐下全部业务
        Map<String, Packages> pacServMap = new HashMap<>();//当前套餐下全部业务
        Map<String,Packages> dayFlows = new HashMap<>();//普通流量日包对象
        String hzCode = "";//呼叫转移编号
        if(null != lwPacsAll && lwPacsAll.size() >0){
            for(Packages p:lwPacsAll){
                pacServMap.put(p.getCode(), p);
                if("8".equals(p.getServType())){
                    dayFlows.put(p.getCode(),p);
                }
                if("11".equals(p.getServType())){
                    hzCode = p.getCode();
                }
            }
        }
        //查询预约和已订购业务
        OfferWithStatus svcCont = new OfferWithStatus();
        svcCont.setAccNbr(us.getPhone());
        svcCont.setProductId("-1");
        svcCont.setCityCode("360");
        svcCont.setReserveStatus("1");
        RestStatus ows = bOSSUnicomService.offerWithStatus(svcCont,us);
        if(!ows.getStatus()){
            logger.error("查询订购业务接口失败");
            throw new SeeComException(ows.getErrorMessage());
        }
        ContractRoot crt = (ContractRoot)ows.getResponseData();
        Boolean smsService = false;//短信功能
        Boolean hzService = false;//呼转功能
        Boolean flowService = false;//上网功能
        if(null != crt.getSvcCont().getProdOfferList() && crt.getSvcCont().getProdOfferList().size() >0){
            for(int i=0;i< crt.getSvcCont().getProdOfferList().size();i++){
                if("1000".equals(crt.getSvcCont().getProdOfferList().get(i).getStatusCd())){
                    String prodOfferId = crt.getSvcCont().getProdOfferList().get(i).getProdOfferId();
                    if(dayFlows.containsKey(prodOfferId)
                       && !newServ[6].equals(prodOfferId)){
                        // 订购了普通日包，并且当前订购的和已订购不一样   订购了省内日包就只能继续订省内日包不能定国内日包
                        logger.error("订购普通日包省内和国内不可同时订购");
                        throw new SeeComException("普通流量包，省内和国内日包不可同时订购");
                    }
                    if("10".equals(pacServMap.get(prodOfferId).getServType())){
                        smsService = true;
                    }
                    if("11".equals(pacServMap.get(prodOfferId).getServType())){
                        hzService = true;
                    }
                    if("12".equals(pacServMap.get(prodOfferId).getServType())){
                        flowService = true;
                    }
                }
                
            }
        }
        
        Boolean isFlow = false;//是否开通上网功能

        //保存销户业务办理信息
        List<Biz> saveList = new ArrayList<Biz>();
        TNumber n = numberMapper.findByPhone(dto.getPhone());
        Date d = new Date();
        Channels ch = channelsMapper.findByUserId(us.getId());
        StringBuffer servInfo = new StringBuffer();
        List<BuyServiceRecord> buys = new ArrayList<BuyServiceRecord>();
        BuyServiceRecord recordDTO = new BuyServiceRecord();
        StringBuffer parmStr = new StringBuffer();
        //基础流量包
        recordDTO = new BuyServiceRecord();
        parmStr = new StringBuffer();
        recordDTO.setPhone(dto.getPhone());
        if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
        recordDTO.setNowsType("2");
        recordDTO.setNetwork("2");
        recordDTO.setStatus("1");
        recordDTO.setPortNum(0);
        recordDTO.setCertName(dto.getCertName());
        recordDTO.setCertNbr(dto.getCertNbr());
        recordDTO.setBuyType("6");
        recordDTO.setMemo("流量业务");
        parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
        parmStr.append("ProductId:").append("-1").append(",");
        if(Utils.isEmptyString(oldServ[1]) && !Utils.isEmptyString(newServ[1])){
            if(!flowService){
                isFlow = true;
            }
            //订购流量包
            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[1])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            parmStr.append("EffectType:").append("1");
            servInfo.append("，号码：" + dto.getPhone() + "订购流量业务：" + pacMap.get(Integer.valueOf(newServ[1])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[1])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[1])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[1])).getName());
        }else if(!Utils.isEmptyString(oldServ[1]) && Utils.isEmptyString(newServ[1])){
            //取消流量包
            recordDTO.setOptType(BuyServiceRecord.opt_type_1);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
            parmStr.append("ServiceOfferId:").append("0").append(",");
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[1])).getCode()).append(",");
            parmStr.append("EffectType:").append("1");
            servInfo.append("，号码：" + dto.getPhone() + "取消流量业务：" + pacMap.get(Integer.valueOf(oldServ[1])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[1])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(oldServ[1])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[1])).getName());
        }else if(!Utils.isEmptyString(oldServ[1]) && !Utils.isEmptyString(newServ[1]) && !oldServ[1].equals(newServ[1])){
            //变更流量包 
            recordDTO.setOptType(BuyServiceRecord.opt_type_2);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[1])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("0").append(",");
            parmStr.append("EffectType:").append("1");
            parmStr.append("&&&");
            parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
            parmStr.append("ProductId:").append("-1").append(",");
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[1])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            parmStr.append("EffectType:").append("1");
            servInfo.append("，号码：" + dto.getPhone() + "流量业务：" + pacMap.get(Integer.valueOf(oldServ[1])).getName() + "变更为：" + pacMap.get(Integer.valueOf(newServ[1])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[1])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[1])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[1])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[1])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[1])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[1])).getName());
        }
        recordDTO.setOrderNum("2");
        recordDTO.setParmStr(parmStr.toString());
        recordDTO.setChannelId(ch.getId());
        recordDTO.setChannelName(ch.getChannelName());
        recordDTO.setSourceType(dto.getSourceType());
        recordDTO.setCreateId(us.getId());
        recordDTO.setCreateTime(d);
        recordDTO.setUpdateId(us.getId());
        recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
        if(parmStr.toString().indexOf("ServiceOfferId") >=0){
            Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[1]) ? 0: Integer.valueOf(newServ[1]),Utils.isEmptyString(oldServ[1]) ? 0: Integer.valueOf(oldServ[1]),d,StatusType.PROCESS.getCode(),"基础流量包");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
        }

        //来显
        recordDTO = new BuyServiceRecord();
        parmStr = new StringBuffer();
        recordDTO.setPhone(dto.getPhone());
        if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
        recordDTO.setNowsType("2");
        recordDTO.setNetwork("2");
        recordDTO.setStatus("1");
        recordDTO.setPortNum(0);
        recordDTO.setCertName(dto.getCertName());
        recordDTO.setCertNbr(dto.getCertNbr());
        recordDTO.setBuyType("9");
        recordDTO.setMemo("来电显示");
        parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
        parmStr.append("ProductId:").append("-1").append(",");
        if(Utils.isEmptyString(oldServ[2]) && !Utils.isEmptyString(newServ[2])){
            //订购来显
            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[2])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "订购来电显示：" + pacMap.get(Integer.valueOf(newServ[2])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[2])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[2])).getMoney());
            recordDTO.setServName("来电显示");
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[2])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[2])).getName());
        }else if(!Utils.isEmptyString(oldServ[2]) && Utils.isEmptyString(newServ[2])){
            //取消来显
            recordDTO.setOptType(BuyServiceRecord.opt_type_1);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[2])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("0").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "取消来电显示：" + pacMap.get(Integer.valueOf(oldServ[2])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[2])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[2])).getMoney());
            recordDTO.setServName("来电显示");
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[2])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[2])).getName());
        }
        parmStr.append("EffectType:").append("0");
        recordDTO.setOrderNum("4");
        recordDTO.setParmStr(parmStr.toString());
        recordDTO.setChannelId(ch.getId());
        recordDTO.setChannelName(ch.getChannelName());
        recordDTO.setSourceType(dto.getSourceType());
        recordDTO.setCreateId(us.getId());
        recordDTO.setCreateTime(d);
        recordDTO.setUpdateId(us.getId());
        recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
        if(parmStr.toString().indexOf("ServiceOfferId") >=0){
            Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[2]) ? 0: Integer.valueOf(newServ[2]),Utils.isEmptyString(oldServ[2]) ? 0: Integer.valueOf(oldServ[2]),d,StatusType.PROCESS.getCode(),"来电显示");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
        }
        //来提
        recordDTO = new BuyServiceRecord();
        parmStr = new StringBuffer();
        recordDTO.setPhone(dto.getPhone());
        if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
        recordDTO.setNowsType("2");
        recordDTO.setNetwork("2");
        recordDTO.setStatus("1");
        recordDTO.setPortNum(0);
        recordDTO.setCertName(dto.getCertName());
        recordDTO.setCertNbr(dto.getCertNbr());
        recordDTO.setBuyType("3");
        parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
        parmStr.append("ProductId:").append("-1").append(",");
        if(Utils.isEmptyString(oldServ[3]) && !Utils.isEmptyString(newServ[3])){
            if(!smsService){
                //没有短信功能
                throw new SeeComException("您的尚未开通短信功能，无法开通来电提醒功能。请联系客服");
            }
            if(hzService){
                //有呼转功能，并且要订购来电提醒，先关闭呼转功能
                ModOptionalOffer hzSvcCont = new ModOptionalOffer();
                hzSvcCont.setAccNbr(dto.getPhone());
                hzSvcCont.setProductId("-1");
                hzSvcCont.setCityCode("360");
                
                List<ProdOfferVO> vos = new ArrayList<>();
                ProdOfferVO vo = new ProdOfferVO();
                vo.setProdOfferId(hzCode);
                vo.setServiceOfferId("0");
                vo.setEffectType("0");
                vos.add(vo);
               
                hzSvcCont.setProdOfferVOList(vos);
                RestStatus hzRS = bOSSUnicomService.modOptionalOffer(hzSvcCont,new User());
                if(!hzRS.getStatus()){
                    throw new SeeComException("来电提醒功能开通失败，无法关闭呼叫转移功能，请联系客服");
                }
            }
            
            //订购来电提醒
            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[3])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "订购来电提醒：" + pacMap.get(Integer.valueOf(newServ[3])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[3])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[3])).getMoney());
            recordDTO.setServName("来电提醒");
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[3])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[3])).getName());
        }else if(!Utils.isEmptyString(oldServ[3]) && Utils.isEmptyString(newServ[3])){
            //取消来电
            recordDTO.setOptType(BuyServiceRecord.opt_type_1);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[3])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("0").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "取消来电提醒：" + pacMap.get(Integer.valueOf(oldServ[3])).getName());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[3])).getMoney());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[3])).getCode());
            recordDTO.setServName("来电提醒");
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[3])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[3])).getName());
        }
        parmStr.append("EffectType:").append("0");
        recordDTO.setOrderNum("5");
        recordDTO.setParmStr(parmStr.toString());
        recordDTO.setChannelId(ch.getId());
        recordDTO.setChannelName(ch.getChannelName());
        recordDTO.setSourceType(dto.getSourceType());
        recordDTO.setCreateId(us.getId());
        recordDTO.setCreateTime(d);
        recordDTO.setUpdateId(us.getId());
        recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
        if(parmStr.toString().indexOf("ServiceOfferId") >=0){
            Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[3]) ? 0: Integer.valueOf(newServ[3]),Utils.isEmptyString(oldServ[3]) ? 0: Integer.valueOf(oldServ[3]),d,StatusType.PROCESS.getCode(),"来电提醒");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
        }
        //叠加包
        if(appendFlows.size() > 0){
            if(!flowService){
                isFlow = true;
            }
            for(Integer s:appendFlows){
                recordDTO = new BuyServiceRecord();
                parmStr = new StringBuffer();
                recordDTO.setPhone(dto.getPhone());
                if(null != n){
                    recordDTO.setPhoneId(n.getId());
                }
                recordDTO.setNowsType("2");
                recordDTO.setNetwork("2");
                recordDTO.setStatus("1");
                recordDTO.setPortNum(0);
                recordDTO.setCertName(dto.getCertName());
                recordDTO.setCertNbr(dto.getCertNbr());
                recordDTO.setBuyType("10");
                parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
                parmStr.append("ProductId:").append("-1").append(",");
                parmStr.append("ProdOfferId:").append(pacMap.get(s).getCode()).append(",");
                //订购 月包
                recordDTO.setOptType(BuyServiceRecord.opt_type_0);
                recordDTO.setValidType(BuyServiceRecord.valid_type_1);
                parmStr.append("ServiceOfferId:").append("1").append(",");
                servInfo.append("，号码：" + dto.getPhone() + "订购叠加包：" + pacMap.get(s).getName());
                recordDTO.setServCode(pacMap.get(s).getCode());
                recordDTO.setServMoney(pacMap.get(s).getMoney());
                recordDTO.setServName(pacMap.get(s).getName());
                recordDTO.setNewServCode(pacMap.get(s).getCode());
                recordDTO.setNewServName(pacMap.get(s).getName());
                parmStr.append("EffectType:").append("0");
                recordDTO.setOrderNum("7");
                recordDTO.setParmStr(parmStr.toString());
                recordDTO.setChannelId(ch.getId());
                recordDTO.setChannelName(ch.getChannelName());
                recordDTO.setSourceType(dto.getSourceType());
                recordDTO.setCreateId(us.getId());
                recordDTO.setCreateTime(d);
                recordDTO.setUpdateId(us.getId());
                recordDTO.setUpdateTime(d);
                recordDTO.setPushTime(d);
                if(parmStr.toString().indexOf("ServiceOfferId") >=0){
                    Biz b = servBiz(dto,recordDTO,pacMap,s,0,d,StatusType.PROCESS.getCode(),"叠加包");
                    saveList.add(b);
                    recordDTO.setOrderNo(b.getOrderNo());
                    buys.add(recordDTO);
                }
            }
        }
        
        //基础语音包
        recordDTO = new BuyServiceRecord();
        parmStr = new StringBuffer();
        recordDTO.setPhone(dto.getPhone());
        if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
        recordDTO.setNowsType("2");
        recordDTO.setNetwork("2");
        recordDTO.setStatus("1");
        recordDTO.setPortNum(0);
        recordDTO.setCertName(dto.getCertName());
        recordDTO.setCertNbr(dto.getCertNbr());
        recordDTO.setBuyType("11");
        recordDTO.setMemo("语音业务");
        parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
        parmStr.append("ProductId:").append("-1").append(",");
        if(Utils.isEmptyString(oldServ[5]) && !Utils.isEmptyString(newServ[5])){
            //订购语音包
            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[5])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            parmStr.append("EffectType:").append("1");
            servInfo.append("，号码：" + dto.getPhone() + "订购语音业务：" + pacMap.get(Integer.valueOf(newServ[5])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[5])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[5])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[5])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[5])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[5])).getName());
        }else if(!Utils.isEmptyString(oldServ[5]) && Utils.isEmptyString(newServ[5])){
            //取消语音包
            recordDTO.setOptType(BuyServiceRecord.opt_type_1);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
            parmStr.append("ServiceOfferId:").append("0").append(",");
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[5])).getCode()).append(",");
            parmStr.append("EffectType:").append("1");
            servInfo.append("，号码：" + dto.getPhone() + "取消语音业务：" + pacMap.get(Integer.valueOf(oldServ[5])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[5])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[5])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(oldServ[5])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[5])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[5])).getName());
        }else if(!Utils.isEmptyString(oldServ[5]) && !Utils.isEmptyString(newServ[5]) && !oldServ[5].equals(newServ[5])){
            //变更语音包
            recordDTO.setOptType(BuyServiceRecord.opt_type_2);
            recordDTO.setValidType(BuyServiceRecord.valid_type_2);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[5])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("0").append(",");
            parmStr.append("EffectType:").append("1");
            parmStr.append("&&&");
            parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
            parmStr.append("ProductId:").append("-1").append(",");
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[5])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            parmStr.append("EffectType:").append("1");
            servInfo.append("，号码：" + dto.getPhone() + "语音业务：" + pacMap.get(Integer.valueOf(oldServ[5])).getName() + "变更为：" + pacMap.get(Integer.valueOf(newServ[5])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[5])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[5])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[5])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[5])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[5])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[5])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[5])).getName());
        }
        recordDTO.setOrderNum("8");
        recordDTO.setParmStr(parmStr.toString());
        recordDTO.setChannelId(ch.getId());
        recordDTO.setChannelName(ch.getChannelName());
        recordDTO.setSourceType(dto.getSourceType());
        recordDTO.setCreateId(us.getId());
        recordDTO.setCreateTime(d);
        recordDTO.setUpdateId(us.getId());
        recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
        if(parmStr.toString().indexOf("ServiceOfferId") >=0){
            Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[5]) ? 0: Integer.valueOf(newServ[5]),Utils.isEmptyString(oldServ[5]) ? 0: Integer.valueOf(oldServ[5]),d,StatusType.PROCESS.getCode(),"基础语音包");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
        }
        
        //普通日包
        recordDTO = new BuyServiceRecord();
        parmStr = new StringBuffer();
        recordDTO.setPhone(dto.getPhone());
        if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
        recordDTO.setNowsType("2");
        recordDTO.setNetwork("2");
        recordDTO.setStatus("1");
        recordDTO.setPortNum(0);
        recordDTO.setCertName(dto.getCertName());
        recordDTO.setCertNbr(dto.getCertNbr());
        recordDTO.setBuyType("12");
        recordDTO.setMemo("流量日包业务");
        parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
        parmStr.append("ProductId:").append("-1").append(",");
        //普通日包
        if(!Utils.isEmptyString(newServ[6])){
            if(!flowService){
                isFlow = true;
            }
            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[6])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "订购流量日包业务：" + pacMap.get(Integer.valueOf(newServ[6])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[6])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[6])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[6])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[6])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[6])).getName());
            parmStr.append("EffectType:").append("0");
        }
        recordDTO.setOrderNum("9");
        recordDTO.setParmStr(parmStr.toString());
        recordDTO.setChannelId(ch.getId());
        recordDTO.setChannelName(ch.getChannelName());
        recordDTO.setSourceType(dto.getSourceType());
        recordDTO.setCreateId(us.getId());
        recordDTO.setCreateTime(d);
        recordDTO.setUpdateId(us.getId());
        recordDTO.setUpdateTime(d);
        recordDTO.setPushTime(d);
        if(parmStr.toString().indexOf("ServiceOfferId") >=0){
            Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[6]) ? 0: Integer.valueOf(newServ[6]),Utils.isEmptyString(oldServ[6]) ? 0: Integer.valueOf(oldServ[6]),d,StatusType.PROCESS.getCode(),"普通流量日包");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            buys.add(recordDTO);
        }
        
        //续订日包
        recordDTO = new BuyServiceRecord();
        parmStr = new StringBuffer();
        recordDTO.setPhone(dto.getPhone());
        if(null != n){
            recordDTO.setPhoneId(n.getId());
        }
        recordDTO.setNowsType("2");
        recordDTO.setNetwork("2");
        recordDTO.setStatus("1");
        recordDTO.setPortNum(0);
        recordDTO.setCertName(dto.getCertName());
        recordDTO.setCertNbr(dto.getCertNbr());
        recordDTO.setBuyType("13");
        recordDTO.setMemo("续订流量业务");
        parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
        parmStr.append("ProductId:").append("-1").append(",");
        if(Utils.isEmptyString(oldServ[7]) && !Utils.isEmptyString(newServ[7])){
            if(!flowService){
                isFlow = true;
            }
            //订购续订流量包
            recordDTO.setOptType(BuyServiceRecord.opt_type_0);
            recordDTO.setValidType(BuyServiceRecord.valid_type_1);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[7])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("1").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "订购续订流量业务：" + pacMap.get(Integer.valueOf(newServ[7])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[7])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[7])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[7])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[7])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[7])).getName());
            recordDTO.setPushTime(d);
        }else if(!Utils.isEmptyString(oldServ[7]) && Utils.isEmptyString(newServ[7])){
            //取消续订流量包
            recordDTO.setOptType(BuyServiceRecord.opt_type_1);
            recordDTO.setValidType(BuyServiceRecord.valid_type_3);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[7])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("0").append(",");
            servInfo.append("，号码：" + dto.getPhone() + "取消续订流量业务：" + pacMap.get(Integer.valueOf(oldServ[7])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(oldServ[7])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(oldServ[7])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(oldServ[7])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[7])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[7])).getName());
            recordDTO.setPushTime(DateUtil.getInstance().parseDate(DateUtil.getInstance().formatDate(d, DateUtil.yyyy_MM_dd)+" "+DicUtil.getMapDictionary("ONLINE_CONFIG").get("CLOSE_FLOW_DAY")+":00",DateUtil.yyyy_MM_dd_HH_mm_ss));
        }else if(!Utils.isEmptyString(oldServ[7]) && !Utils.isEmptyString(newServ[7]) && !oldServ[7].equals(newServ[7])){
            //变更续订流量包      走退订订购流程
            recordDTO.setOptType(BuyServiceRecord.opt_type_2);
            recordDTO.setValidType(BuyServiceRecord.valid_type_3);
            parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(oldServ[7])).getCode()).append(",");
            parmStr.append("ServiceOfferId:").append("0").append(",");//先入退订
            servInfo.append("，号码：" + dto.getPhone() + "续订流量业务：" + pacMap.get(Integer.valueOf(oldServ[7])).getName() + "变更为：" + pacMap.get(Integer.valueOf(newServ[7])).getName());
            recordDTO.setServCode(pacMap.get(Integer.valueOf(newServ[7])).getCode());
            recordDTO.setServMoney(pacMap.get(Integer.valueOf(newServ[7])).getMoney());
            recordDTO.setServName(pacMap.get(Integer.valueOf(newServ[7])).getName());
            recordDTO.setNewServCode(pacMap.get(Integer.valueOf(newServ[7])).getCode());
            recordDTO.setNewServName(pacMap.get(Integer.valueOf(newServ[7])).getName());
            recordDTO.setOldServCode(pacMap.get(Integer.valueOf(oldServ[7])).getCode());
            recordDTO.setOldServName(pacMap.get(Integer.valueOf(oldServ[7])).getName());
            recordDTO.setPushTime(DateUtil.getInstance().parseDate(DateUtil.getInstance().formatDate(d, DateUtil.yyyy_MM_dd)+" "+DicUtil.getMapDictionary("ONLINE_CONFIG").get("CLOSE_FLOW_DAY")+":00",DateUtil.yyyy_MM_dd_HH_mm_ss));
        }
        parmStr.append("EffectType:").append("0");
        recordDTO.setOrderNum("8");
        recordDTO.setParmStr(parmStr.toString());
        recordDTO.setChannelId(ch.getId());
        recordDTO.setChannelName(ch.getChannelName());
        recordDTO.setSourceType(dto.getSourceType());
        recordDTO.setCreateId(us.getId());
        recordDTO.setCreateTime(d);
        recordDTO.setUpdateId(us.getId());
        recordDTO.setUpdateTime(d);
        if(parmStr.toString().indexOf("ServiceOfferId") >=0){
            Biz b = servBiz(dto,recordDTO,pacMap,Utils.isEmptyString(newServ[7]) ? 0: Integer.valueOf(newServ[7]),Utils.isEmptyString(oldServ[7]) ? 0: Integer.valueOf(oldServ[7]),d,StatusType.PROCESS.getCode(),"续订流量日包");
            saveList.add(b);
            recordDTO.setOrderNo(b.getOrderNo());
            if(BuyServiceRecord.opt_type_2.equals(recordDTO.getOptType())){
                //续订日包变更   修改记录表未退订  再新增一条订购记录
                recordDTO.setOptType(BuyServiceRecord.opt_type_1);
                BuyServiceRecord recordDTOOrder = new BuyServiceRecord();
                BeanUtils.copyProperties(recordDTO, recordDTOOrder);
                recordDTOOrder.setOptType(BuyServiceRecord.opt_type_0);
                parmStr = new StringBuffer();
                parmStr.append("AccNbr:").append(dto.getPhone()).append(",");
                parmStr.append("ProductId:").append("-1").append(",");
                parmStr.append("ProdOfferId:").append(pacMap.get(Integer.valueOf(newServ[7])).getCode()).append(",");
                parmStr.append("ServiceOfferId:").append("1").append(",");//再入订购
                parmStr.append("EffectType:").append("0");
                recordDTOOrder.setParmStr(parmStr.toString());
                recordDTOOrder.setPushTime(DateUtil.getInstance().parseDate(DateUtil.getInstance().addDateStr(d, 1,DateUtil.yyyy_MM_dd)+" 00:00:00",DateUtil.yyyy_MM_dd_HH_mm_ss));
                buys.add(recordDTOOrder);
            }
            buys.add(recordDTO);
        }
        if(buys.size() <1){
            throw new SeeComException("您没有订购任何业务");
        }
        //开通上网功能
        if(isFlow){
            //订购流量包，并且没有上网功能
            List<ProductChangeVO> list = new ArrayList<ProductChangeVO>();
            ProductChangeVO vo = new ProductChangeVO();
            vo.setProductId("102");
            vo.setOperKind("1");
            list.add(vo);
            //调用接口
            RestStatus flowRS = bOSSUnicomService.doProductChange(dto.getPhone(), list, us);
            if(!flowRS.getStatus()){
                logger.error("订购流量包，开通上网功能失败");
                throw new SeeComException("您的 上网功能开通失败，请联系客服");
            }
        }
        
        RestStatus orderServRS = orderServiceVerify(buys);
        if(!orderServRS.getStatus()){
            throw new SeeComException(orderServRS.getErrorMessage());
        }

        bizMapper.batchInsert(saveList);
        buyServiceRecordMapper.batchInsert(buys);
        //日志记录
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("phone",dto.getPhone());
        logmap.put("servInfo",servInfo.toString().substring(1,servInfo.toString().length()));
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logService.businessSaveLog(Business.phone_buy_Sub,String.valueOf(us.getId()),us.getLoginName(),
                "0","业务订购",logmap);
    }
    
    
    /**
     * 业务重新订购
     * @param ids
     * @throws Exception
     */
    @Transactional(readOnly=false,rollbackFor = Exception.class)
    public void buyAgainSubUnicom(List<Integer> ids, User us,BuyServiceRecord buys) throws Exception {
        QueryUser cd = new QueryUser();
        cd.setQueryValue(buys.getPhone());
        cd.setQueryValue("17090041961");
        cd.setQueryType("0");
        cd.setProductId("-1");
        cd.setCityCode("360");
        RestStatus  rs = bOSSUnicomService.queryUserService(cd,us);
        ContractRoot cr;
        if(rs.getStatus()){
            cr = (ContractRoot)rs.getResponseData();
            if(!"109999".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                throw new SeeComException("号码："+buys.getPhone()+"当前状态为："+UnicomStatus.getName(Integer.valueOf(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())) + "，不可订购业务");
            }
        }else{
            throw new SeeComException(rs.getErrorMessage());
        }
        
        String[] parStrings = buys.getParmStr().split(",");
        Map<String, String> parMap = new HashMap<String, String>();
        for (int k = 0; k < parStrings.length; k++) {
            String key = parStrings[k].substring(0, parStrings[k].indexOf(":"));
            String value = parStrings[k].substring(parStrings[k].indexOf(":")+1, parStrings[k].length());
            parMap.put(key, value);
        }
        Map<String, Object> searchMap = new HashMap<>();
        BigDecimal userBal = new BigDecimal(cr.getSvcCont().getUserInfoView().getUserInfo().getAvailableBalance());
        
        if(buys.getBuyType().equals("203") || buys.getBuyType().equals("209")){
            searchMap = new HashMap<>();
            searchMap.put("buyType", buys.getBuyType());
            searchMap.put("phone", buys.getPhone());
            searchMap.put("status", "0");
            searchMap.put("parmStrLike", "ServiceOfferId:1");
            int c = buyServiceRecordMapper.listDtoCount(searchMap);
            if(c == 0 && buys.getServMoney().floatValue() > userBal.floatValue() && parMap.containsKey("OperType") &&  "0".equals(parMap.get("OperType"))){//没有进行过来显，来电订购
                throw new SeeComException("对不起，用户的余额不足，不能订购该业务！");
            }
        }else if(buys.getBuyType().equals("210") 
                || buys.getBuyType().equals("211") || buys.getBuyType().equals("212")){
            if(buys.getServMoney().floatValue() > userBal.floatValue()){//没有进行过来显，来电订购
                throw new SeeComException("对不起，用户的余额不足，不能订购该业务！");
            }
        }
        //业务重新订购
        buyServiceRecordMapper.buyAgainSub(us.getId(), ids);

        //记录日志
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("phone", buys.getPhone());
        logmap.put("servInfo", buys.getServName());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
        logmap.put("result", "成功！");
        logService.businessSaveLog(Business.phone_buy_again_sub,String.valueOf(us.getId()),us.getLoginName(),
                null != buys.getId() ? String.valueOf(buys.getId()) : "0","业务重新订购",logmap);
    }

	/**
	 * 移动 业务重新订购
	 * @param ids
	 * @throws Exception
	 */
	@Transactional(readOnly=false,rollbackFor = Exception.class)
	public void buyAgainSubMobile(List<Integer> ids, User us,BuyServiceRecord buys) throws Exception {
		TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
		bo.setMSISDN("86"+buys.getPhone());
		RestStatus rs = bossNewBuyService.QueryUserProfileBOSS(bo, new User());
		BigDecimal userBal; //用户余额
		if(rs.getStatus()){
			TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
			if(!"A".equals(res.getState())){
				throw new SeeComException("号码："+buys.getPhone()+"当前状态为："+DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()) + "，不可订购业务");
			}
			userBal = new BigDecimal(res.getBal());
		}else{
			throw new SeeComException(rs.getErrorMessage());
		}
		String[] parStrings = buys.getParmStr().split(",");
		Map<String, String> parMap = new HashMap<String, String>();
		for (int k = 0; k < parStrings.length; k++) {
			String key = parStrings[k].substring(0, parStrings[k].indexOf(":"));
			String value = parStrings[k].substring(parStrings[k].indexOf(":")+1, parStrings[k].length());
			parMap.put(key, value);
		}
		if(buys.getServMoney().floatValue() > userBal.multiply(Constant.cnt100).floatValue() && parMap.containsKey("OperType") &&  "0".equals(parMap.get("OperType"))){
			throw new SeeComException("对不起，用户的余额不足，不能订购该业务！");
		}
        //业务重新订购
        buyServiceRecordMapper.buyAgainSub(us.getId(), ids);

		//记录日志
		Map<String,String> logmap = new HashMap<String,String>();
		logmap.put("staff", us.getLoginName());
		logmap.put("phone", buys.getPhone());
		logmap.put("servInfo", buys.getServName());
		logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
		logmap.put("result", "成功！");
		logService.businessSaveLog(Business.phone_buy_again_sub,String.valueOf(us.getId()),us.getLoginName(),
				null != buys.getId() ? String.valueOf(buys.getId()) : "0","业务重新订购",logmap);
	}

	/**
	 * 查看业务办理列表
	 * @param dt
	 * @param searchMap
	 * @return
	 * @throws Exception
	 */
	public DataTable<BuyServRecordListDTO> listBuy(DataTable<BuyServRecordListDTO> dt,Map<String,Object> searchMap) throws Exception{
		List<BuyServRecordListDTO> listDto = buyServiceRecordMapper.listDto(searchMap);
		if(null != listDto && listDto.size() >0){
		    for(BuyServRecordListDTO s:listDto){
		        if(BuyServiceRecord.opt_type_0.equals(s.getOptType())){
		            if(Utils.isEmptyString(s.getNewServName()) || s.getServName().indexOf("订购") >0){
		                s.setServName(s.getServName());
		            }else{
		                s.setServName("订购"+s.getNewServName());
		            }
		            
		        }else if(BuyServiceRecord.opt_type_1.equals(s.getOptType())){
		            if(Utils.isEmptyString(s.getOldServName()) || s.getServName().indexOf("退订") >0){
		                s.setServName(s.getServName());
		            }else{
		                s.setServName("退订"+s.getOldServName());
		            }
		        }else if(BuyServiceRecord.opt_type_2.equals(s.getOptType())){
		            if(Utils.isEmptyString(s.getOldServName())){
		                s.setServName(s.getServName());
		            }else{
		                s.setServName(s.getOldServName() +"变更为 "+ s.getNewServName());
		            }
		           
		        }
		       
		    }
		}
		int count = buyServiceRecordMapper.listDtoCount(searchMap);
		dt.setAaData(listDto);
		dt.setiTotalDisplayRecords(count);
		return dt;
	}


	/**
	 * 校验号码和服务密码是否正确
	 * @param dto
	 * @return
	 */
	public RestStatus checkData(BuyServDTO dto){
		RestStatus res = new RestStatus();
		res.setStatus(Boolean.FALSE);
		if (Utils.isEmptyString(dto.getPhone())) {
			return new RestStatus(Boolean.FALSE, "500", "请正确填写11位手机号!");
		}
		if (dto.getPhone().length() != 11) {
			return new RestStatus(Boolean.FALSE, "500", "请正确填写11位手机号!");
		}
		if(!dto.getPhone().matches("[0-9]+")){
			return new RestStatus(Boolean.FALSE, "500", "请输入11位正确号码");
		}
		if (Utils.isEmptyString(dto.getUserpwd())) {
			return new RestStatus(Boolean.FALSE, "500", "请正确填写6位服务密码!");
		}
		if (dto.getUserpwd().length() != 6) {
			return new RestStatus(Boolean.FALSE, "500", "请正确填写6位服务密码");
		}
		if(!dto.getUserpwd().matches("[0-9]+")){
			return new RestStatus(Boolean.FALSE, "500", "请正确填写6位服务密码");
		}
		res.setStatus(Boolean.TRUE);
		return res;
	}
	
	/**
     * 校验是否可以办理业务
     * @param phone
     * @param network
     * @param optDtos
     * @return
     * @throws Exception
     */
    public RestStatus orderServiceVerify(List<BuyServiceRecord> optDtos) throws Exception{
        RestStatus res = new RestStatus();
        res.setStatus(Boolean.TRUE);
        //当月办理次月生效业务
        Map<String, Object> searchMap = new HashMap<>();
        List<String> statusIn = new ArrayList<>();
        statusIn.add("0");
        statusIn.add("1");
        statusIn.add("4");
        statusIn.add("5");
        searchMap.put("statusList", statusIn);
        searchMap.put("startdate", DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM)+"-01");
        searchMap.put("phone", optDtos.get(0).getPhone());
        searchMap.put("nowsType","2");
        List<BuyServRecordListDTO> dtolist = buyServiceRecordMapper.listDto(searchMap);
        int packsCnt = 0;//当月办理了套餐变更
        int dayCnt = 0;
        int nextMonthServ = 0;//次月生效业务
        String flowbool = "000";//是否已办理基础流量业务  0-订购，1-退订，2-变更
        String voicebool = "000";//是否已办理基础语音业务 0-订购，1-退订，2-变更
        Map<String, String> stMap = new HashMap<>();
        BuyServRecordListDTO flowDay = null;
        List<String> orlist = new ArrayList<>();//未订购成功不能再订购业务类型
        orlist.add("3");//移动来显漏电
        orlist.add("6");//流量包
        orlist.add("9");//联通 来电
        orlist.add("11");//基础语音包
        orlist.add("13");//续订日包
        Map<String, Set<String>> oldMonth = new HashMap<String, Set<String>>();// 业务类型<生效类型>  立即生效不算
        if(null != dtolist && dtolist.size() >0){
            Map<String, BuyServiceRecord> codeMap = new HashMap<>();
            Map<String, BuyServiceRecord> oldCodeMap = new HashMap<>();
            for(BuyServRecordListDTO servDto:dtolist){
                if(StringUtils.isNotEmpty(servDto.getNewServCode())){
                    codeMap.put(servDto.getNewServCode(),servDto);
                }
                if(StringUtils.isNotEmpty(servDto.getOldServCode())){
                    codeMap.put(servDto.getOldServCode(),servDto);
                }
                if(!"0".equals(servDto.getOptType()) && StringUtils.isNotEmpty(servDto.getOldServCode())){
                    oldCodeMap.put(servDto.getOldServCode(),servDto);
                }
            }
            if(codeMap.keySet().size() >0){
                searchMap = new HashMap<>();
                searchMap.put("codes", codeMap.keySet().toArray());
                List<Packages> ps = pacMapper.listPac(searchMap);
                if(null != ps && ps.size()>0){
                    for(Packages p:ps){
                        if(!"1".equals(codeMap.get(p.getCode()).getValidType())){
                            if(oldMonth.containsKey(p.getServType())){
                                Set<String> validType = oldMonth.get(p.getServType());
                                validType.add(codeMap.get(p.getCode()).getValidType());
                                oldMonth.put(p.getServType(), validType);
                            }else{
                                Set<String> validType = new HashSet<>();
                                validType.add(codeMap.get(p.getCode()).getValidType());
                                oldMonth.put(p.getServType(), validType);
                            }
                        }
                        if(null != oldCodeMap.get(p.getCode()) && !"1".equals(oldCodeMap.get(p.getCode()).getValidType())){
                            if(oldCodeMap.containsKey(p.getServType())){
                                Set<String> validType = oldMonth.get(p.getServType());
                                validType.add(oldCodeMap.get(p.getCode()).getValidType());
                                oldMonth.put(p.getServType(), validType);
                            }else{
                                Set<String> validType = new HashSet<>();
                                validType.add(oldCodeMap.get(p.getCode()).getValidType());
                                oldMonth.put(p.getServType(), validType);
                            }
                        }
                    }
                }
            }
            
            for(BuyServRecordListDTO servDto:dtolist){
                if(servDto.getValidType().equals(BuyServiceRecord.valid_type_2)){
                    nextMonthServ++;
                }
                if("14".equals(servDto.getBuyType())){
                    packsCnt++;//当月办理了套餐变更
                }
                if(servDto.getValidType().equals(BuyServiceRecord.valid_type_3) && 
                        DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd).equals(DateUtil.getInstance().formatDate(servDto.getCreateTime(), DateUtil.yyyy_MM_dd))){
                    dayCnt++;//今天办理了，次日生效
                }
                if("12".equals(servDto.getBuyType()) && 
                        DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd).equals(DateUtil.getInstance().formatDate(servDto.getCreateTime(), DateUtil.yyyy_MM_dd))){
                    //当天办理了普通日包订购
                    flowDay = servDto;
                }
                if("6".equals(servDto.getBuyType())){
                    //已办理流量包订购
                    flowbool = servDto.getOptType();
                }
                if("11".equals(servDto.getBuyType())){
                    //已办理语音包订购
                    voicebool = servDto.getOptType();
                }
                if("3".equals(servDto.getBuyType()) && "1".equals(servDto.getNetwork())){
                    //移动已办理来显，来电
                    stMap.put(servDto.getServCode(), servDto.getOptType());
                }
            }
        }

        List<String> newCode = new ArrayList<>();
        for(BuyServiceRecord r:optDtos){
            if(StringUtils.isNotEmpty(r.getNewServCode())){
                newCode.add(r.getNewServCode());
            }
            if(StringUtils.isNotEmpty(r.getOldServCode())){
                newCode.add(r.getOldServCode());
            }
        }
        Map<String, String> codeValidType = new HashMap<>();
        if(newCode.size() >0){
            searchMap = new HashMap<>();
            searchMap.put("codes", newCode);
            List<Packages> ps = pacMapper.listPac(searchMap);
            if(null != ps && ps.size()>0){
                for(Packages p:ps){
                    codeValidType.put(p.getCode(), p.getServType());
                }
            }
        }
        for(BuyServiceRecord r:optDtos){
            if(r.getBuyType().equals("14") && nextMonthServ >0){
                return new RestStatus(Boolean.FALSE, "1004", "您已办理下月生效业务，不能再办理套餐变更。您可联系客服取消下月生效业务后再办理！");
            }
            String servCode = r.getNewServCode();
            if(StringUtils.isEmpty(servCode)){
                servCode = r.getOldServCode();
            }
            if(oldMonth.get(codeValidType.get(servCode)) != null){//有相同业务操作
                for(String s:oldMonth.get(codeValidType.get(servCode))){
                    if("2".equals(s)){
                        return new RestStatus(Boolean.FALSE, "1004", "您已办理下月生效业务，不能再办理"+CommonUtil.servTypeNameMap.get(codeValidType.get(servCode)));
                    }
                }
            }
            
            if(packsCnt > 0){
                //当月办理套餐变更，并且套餐变更已经推送boss，不能再办理任何业务
                return new RestStatus(Boolean.FALSE, "1004", "您的套餐变更正在变更生效中，不能再办理业务！");
            }
            
            if(r.getValidType().equals(BuyServiceRecord.valid_type_3) && dayCnt > 0){
                //当月办理次日生效只能有一个业务
                return new RestStatus(Boolean.FALSE, "1004", "您还有次日待生效业务，不能再办理："+r.getServName()+"次日生效业务");
            }
            if("12".equals(r.getBuyType()) && null != flowDay && !r.getServCode().equals(flowDay.getServCode())){
                //当日订购了普通日包，并且现在订购和已经订购不一样
                return new RestStatus(Boolean.FALSE, "1004", "您今日已提交："+flowDay.getServName()+" 就只能订购该普通包，明日可订购其他普通包");
            }
            if("6".equals(r.getBuyType()) && flowbool.equals(r.getOptType())){
                //当月已办理流量包订购  再办理
                return new RestStatus(Boolean.FALSE, "1004", "您本月办理基础流量包"+CommonUtil.getInstance().stMap().get(r.getOptType())+"，不能再办理"+CommonUtil.getInstance().stMap().get(r.getOptType()));
            }
            if("11".equals(r.getBuyType()) && voicebool.equals(r.getOptType())){
                //当月已办理语音包订购  再办理
                return new RestStatus(Boolean.FALSE, "1004", "您本月办理基础语音包"+CommonUtil.getInstance().stMap().get(r.getOptType())+"，不能再办理"+CommonUtil.getInstance().stMap().get(r.getOptType()));
            }
            if("3".equals(r.getBuyType()) && "1".equals(r.getNetwork()) && stMap.get(r.getServCode()) != null && stMap.get(r.getServCode()).equals(r.getOptType())){
                //移动已办理来显，来电
                String s = "来电提醒";
                if("420".equals(r.getServCode())){
                    s = "来电显示";
                }
                return new RestStatus(Boolean.FALSE, "1004", "您本月办理"+s+CommonUtil.getInstance().stMap().get(r.getOptType())+"，不能再办理"+CommonUtil.getInstance().stMap().get(r.getOptType()));
            }
        }
        return res;
    }
	
	/**
	 * 获取biz对象
	 * @param dto
	 * @param phone
	 * @param recordDTO
	 * @param pacMap
	 * @param newServId
	 * @param oldServId
	 * @param d
	 * @param remark
	 * @return
	 * @throws Exception
	 */
	private Biz servBiz(BuyServDTO dto,BuyServiceRecord recordDTO,Map<Integer,Packages> pacMap,
	        Integer newServId,Integer oldServId,Date d,String status
            ,String remark) throws Exception{
        Biz b = new Biz();
        b.setPhone(dto.getPhone());
        b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
        b.setOperationType(recordDTO.getOptType());
        b.setValidType(recordDTO.getValidType());
        b.setOperationTime(d);
        b.setStatus(status);
        b.setServCode(recordDTO.getServCode());
        if(BuyServiceRecord.opt_type_0.equals(recordDTO.getOptType())){
            if(Utils.isEmptyString(recordDTO.getNewServName()) || recordDTO.getServName().indexOf("订购") >0){
                b.setServName(recordDTO.getServName());
            }else{
                b.setServName("订购"+recordDTO.getNewServName());
            }
        }else if(BuyServiceRecord.opt_type_1.equals(recordDTO.getOptType())){
            if(Utils.isEmptyString(recordDTO.getOldServName()) || recordDTO.getServName().indexOf("退订") >0){
                b.setServName(recordDTO.getServName());
            }else{
                b.setServName("退订"+recordDTO.getOldServName());
            }
        }else if(BuyServiceRecord.opt_type_2.equals(recordDTO.getOptType())){
            if(Utils.isEmptyString(recordDTO.getOldServName())){
                b.setServName(recordDTO.getServName());
            }else{
                b.setServName(recordDTO.getOldServName() +"变更为 "+ recordDTO.getNewServName());
            }
        }
       
        b.setNewServCode(recordDTO.getNewServCode());
        b.setNewServName(recordDTO.getNewServName());
        b.setOldServCode(recordDTO.getOldServCode());
        b.setOldServName(recordDTO.getOldServName());
        b.setMoney(recordDTO.getServMoney());
        if(StringUtils.equals(recordDTO.getOptType(), "0")){
            b.setBizType(CommonUtil.servTypeMapBiz.get(pacMap.get(newServId).getServType()));
            b.setBizName(pacMap.get(newServId).getServTypeStr());
            b.setFeeStyle(CommonUtil.getInstance().feeStyleCode(CommonUtil.servTypeMapBiz.get(pacMap.get(newServId).getServType())));
            
        }else if(StringUtils.equals(recordDTO.getOptType(), "2")){
            b.setBizType(CommonUtil.servTypeMapBiz.get(pacMap.get(newServId).getServType()));
            b.setBizName(pacMap.get(newServId).getServTypeStr());
            b.setFeeStyle(CommonUtil.getInstance().feeStyleCode(CommonUtil.servTypeMapBiz.get(pacMap.get(newServId).getServType())));
            b.setValidType(CommonUtil.getInstance().valildTypeCode(pacMap.get(newServId).getServType(),recordDTO.getOptType(),recordDTO.getNetwork()));
        }else {
            b.setBizType(CommonUtil.servTypeMapBiz.get(pacMap.get(oldServId).getServType()));
            b.setBizName(pacMap.get(oldServId).getServTypeStr());
            b.setFeeStyle(CommonUtil.getInstance().feeStyleCode(CommonUtil.servTypeMapBiz.get(pacMap.get(oldServId).getServType())));
            b.setValidType(CommonUtil.getInstance().valildTypeCode(pacMap.get(oldServId).getServType(),recordDTO.getOptType(),recordDTO.getNetwork()));
        }
        b.setWayType("AGENT");
        b.setIp(dto.getIp());
        b.setReason(remark);
        b.setRemark(null);
        b.setCreateTime(d);
        b.setUpdateTime(d);
        return b;
    }
	


    /**
     * 查询用户套餐编号
     * @param user
     * @param pwd
     * @return
     * @throws Exception
     */
    public RestStatus queryPacCodeMobile(User user,String pwd) throws Exception{
        //查询用户信息
        TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
        bo.setMSISDN("86" + user.getPhone());
        if(!Utils.isEmptyString(pwd)){
            bo.setUserPwd(pwd);
        }
        
        // TODO 给测试人员临时使用，后期要删除
        Map<String, String> testNameMap =DicUtil.getMapDictionary("TEST_NAME");
        if(null!=testNameMap && null!=testNameMap.get(user.getLoginName())){
            bo.setUserPwd(null);
        }
        
        RestStatus rs;
        String packagesCode = "";
        PhoneStatusDTO statusDto;
        //boss新接口查询用户信息
        rs = bossNewBuyService.QueryUserProfileBOSS(bo, new User());
        if(rs.getStatus()){
            TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
            statusDto = new PhoneStatusDTO(res.getState(), res.getStateSet());
            if(!"A".equals(res.getState())){
                return new RestStatus(Boolean.FALSE, "1004", "号码："+user.getPhone()+"当前状态为："+ statusDto.getProdStateStr() + "，不可订购业务");
            }
            packagesCode = res.getSubsPlanCode();
            if("cool2".equals(res.getSubsPlanCode())){
                packagesCode = "xcool2";
            }
            res.setSubsPlanCode(packagesCode);
            return new RestStatus(Boolean.TRUE, "200", "查询 成功",res);
        }else{
            return new RestStatus(Boolean.FALSE, "1001", rs.getErrorMessage());
        }
    }
    
    /**
     * 查询用户套餐编号
     * @param user
     * @return
     * @throws Exception
     */
    public RestStatus queryPacCodeUnicom(User user) throws Exception{
        QueryUser cd = new QueryUser();
        cd.setQueryValue(user.getPhone());
        cd.setQueryType("0");
        cd.setProductId("-1");
        cd.setCityCode("360");
        RestStatus  rs = bOSSUnicomService.queryUserService(cd,user);
        if(rs.getStatus()){
            ContractRoot cr = (ContractRoot)rs.getResponseData();
            if(!"109999".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                return new RestStatus(Boolean.FALSE, "1004", "号码："+user.getPhone()+"当前状态为："+BossPhoneStatus.getName(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus()) + "，不可订购业务");
            }
            return new RestStatus(Boolean.TRUE, "200", "查询 成功",cr.getSvcCont().getUserInfoView());
        }else{
            return new RestStatus(Boolean.FALSE, "1001", rs.getErrorMessage());
        }
    }
    
    /**
     * 联通号码套餐变更报竣
     * @param phone
     * @return
     * @throws Exception
     */
    public RestStatus modProUpdate(String phone) throws Exception{
        logger.error("号码："+phone+"套餐变更校验报竣，时间"+DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss));
        Map<String, Object> searchMap = new HashMap<>();
        searchMap.put("phone", phone);
        searchMap.put("status", "5");
        searchMap.put("limit", 0);
        searchMap.put("pageSize", 1);
        List<BuyServRecordListDTO> listDto = buyServiceRecordMapper.listDto(searchMap);
        if(null != listDto && listDto.size() >0){
            BuyServiceRecord b = new BuyServiceRecord();
            b.setId(listDto.get(0).getId());
            b.setStatus("4");
            b.setUpdateId(listDto.get(0).getUpdateId());
            b.setUpdateTime(new Date());
            buyServiceRecordMapper.updateStatus(b);
        }else{
            logger.error("号码："+phone+"套餐变更校验报竣,没有找到需要报竣数据，时间"+DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss));
        }
        return new RestStatus(Boolean.TRUE,"200","报竣成功");
    }
}