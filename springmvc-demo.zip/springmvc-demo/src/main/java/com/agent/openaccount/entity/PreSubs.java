package com.agent.openaccount.entity;

import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * BOSS预开户记录表
 */
public class PreSubs extends BaseDomain {

    private static final long serialVersionUID = -2345168666727642917L;
    private String phone;       //号码
    private String passwd;      //服务密码
    private String iccid;       //iccid
    private String imsi;        //imsi
    private String servCode;    //套餐编号
    private String servName;    //套餐名称
    private Date advanceTime;   //预开户时间
    private String status;      //充值是否失败：0-成功，1-失败
    private String code;        //身份证号码
    private Integer source;        //来源：1-导入，2-新增
    
    private String userName;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getServCode() {
        return servCode;
    }

    public void setServCode(String servCode) {
        this.servCode = servCode;
    }

    public String getServName() {
        return servName;
    }

    public void setServName(String servName) {
        this.servName = servName;
    }

    public Date getAdvanceTime() {
        return advanceTime;
    }

    public void setAdvanceTime(Date advanceTime) {
        this.advanceTime = advanceTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
    

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }
    
    

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return "PreSubs [phone=" + phone + ", passwd=" + passwd + ", iccid=" + iccid + ", imsi=" + imsi + ", servCode="
                + servCode + ", servName=" + servName + ", advanceTime=" + advanceTime + ", status=" + status
                + ", code=" + code + "]";
    }

}
