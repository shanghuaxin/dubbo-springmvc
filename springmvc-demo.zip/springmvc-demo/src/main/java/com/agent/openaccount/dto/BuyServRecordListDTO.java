package com.agent.openaccount.dto;

import com.agent.openaccount.entity.BuyServiceRecord;

/**
 * 业务办理DTO
 * @author zw
 *
 */
public class BuyServRecordListDTO extends BuyServiceRecord {
    
    private static final long serialVersionUID = -1423098262798615640L;
    private String channelCode;
    private String channelParName;
    private String bizStatus;
    private String bizOptType;////操作类型：0-订购，1-取消，2-变更  biz表操作类型
    private String servType;
    private String pacType;//套餐类型：YD-移动，LTZYC-联通资源池，LTMZ-联通模组，LTMINIMZ-联通迷你模组     业务分类：PR-省内，CN-国内

    public String getChannelParName() {
        return channelParName;
    }

    public void setChannelParName(String channelParName) {
        this.channelParName = channelParName;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getBizStatus() {
        return bizStatus;
    }

    public void setBizStatus(String bizStatus) {
        this.bizStatus = bizStatus;
    }

    public String getServType() {
        return servType;
    }

    public void setServType(String servType) {
        this.servType = servType;
    }

    public String getBizOptType() {
        return bizOptType;
    }

    public void setBizOptType(String bizOptType) {
        this.bizOptType = bizOptType;
    }

    public String getPacType() {
        return pacType;
    }

    public void setPacType(String pacType) {
        this.pacType = pacType;
    }
}
