package com.agent.openaccount.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.NmbRecordOptType;
import com.agent.common.enumeration.OrderNOEnum;
import com.agent.common.enumeration.PhoneStatus;
import com.agent.cs.dto.CsUserListDTO;
import com.agent.cs.dto.ReqCommonDTO;
import com.agent.cs.service.CsUserService;
import com.agent.number.entity.NumberRecord;
import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberRecordMapper;
import com.agent.number.service.NumberService;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.entity.Biz;
import com.agent.online.mapper.BizMapper;
import com.agent.openaccount.dto.ModCustomerDTO;
import com.agent.openaccount.dto.ModCustomerListDTO;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.Check;
import com.agent.openaccount.entity.HisIdentity;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.entity.ModCustomer;
import com.agent.openaccount.mapper.AttachedDocumentsMapper;
import com.agent.openaccount.mapper.CheckMapper;
import com.agent.openaccount.mapper.HisIdentityMapper;
import com.agent.openaccount.mapper.IdcardInfoMapper;
import com.agent.openaccount.mapper.IdentityMapper;
import com.agent.openaccount.mapper.ModCustomerMapper;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.technology.entity.MsgPush;
import com.agent.technology.entity.NewsInfo;
import com.agent.technology.mapper.MsgPushMapper;
import com.agent.technology.mapper.NewsInfoMapper;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.IDCardUtil;
import com.agent.util.SysConfig;
import com.agent.util.Utils;
import com.agent.util.images.FileUtil;

import namespace.webservice.crmsps.ContractRoot;
import zsmart.ztesoft.com.xsd.TModCustomerBOSSBO;
import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;

@Service("modCustomerService")
@Transactional(rollbackFor=Exception.class)
public class ModCustomerService {
	@Value("#{configProperties['imageURL']}")
	private String imageURL;
	@Resource
	private ModCustomerMapper modMapper;
	@Resource
	private IdentityMapper identityMapper;
	@Resource
	private HisIdentityMapper hisIdentityMapper;
	@Autowired
	private ChannelsMapper channelsMapper;
	@Autowired
	private BusinessLogService logService;
	@Autowired
	private AttachedDocumentsMapper documentsMapper;
	@Autowired
	private IdcardInfoMapper idcardInfoMapper;
	@Autowired
	private BOSSNewBuyService buyNewService;
	@Autowired
	private CheckMapper checkMapper;
	@Autowired
	private AttachedDocumentsMapper attachedDocumentsMapper;
    @Autowired
    private MsgPushMapper msgPushMapper;
    @Autowired
    private NewsInfoMapper newsInfoMapper;
    @Autowired
    private NumberService numberService;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    @Autowired
    private NumberRecordMapper numberRecordMapper;
    @Autowired
    private BizMapper bizMapper;
    @Autowired
    private CsUserService csUserService;

	private static Logger logger = (Logger) LoggerFactory.getLogger(ModCustomerService.class);

	/**
	 * 号码过户申请提交
	 * @param dto
	 * @throws Exception
	 */
	public void modCustomer(ModCustomerDTO dto,User us) throws Exception{
		Channels ch = channelsMapper.findByUserId(us.getId());
		Map<String,Object> searchMap = new HashMap<String,Object>();
		searchMap.put("phone",dto.getPhone());
        searchMap.put("pStatusNot",TNumber.STATUS_CANCEL);
		Identity identity = identityMapper.list(searchMap).get(0);
		
		String custOrderId=null;
		try {
		    int operatorCode = numberService.findByPhone(dto.getPhone()).getOperatorCode();
		    // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            if (flag != null && flag.equals("true") && operatorCode==2){// 联通接口
                RestStatus rsStatus = bossUnicomService.changeCust(dto, "1", us);//1.过户 2.实名补录
                if(rsStatus.getStatus()){
                    ContractRoot root = (ContractRoot)rsStatus.getResponseData();
                    custOrderId = root.getSvcCont().getCustOrderId();
                } else {
                    throw new Exception(rsStatus.getErrorMessage());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("过户调用接口错误！" + e.getMessage());
        }
		
		//过户信息入库
		ModCustomer mod = new ModCustomer();
		mod.setPhone(dto.getPhone());
		mod.setPhoneId(identity.getPhoneId());
		mod.setHisCode(identity.getCode());
		mod.setHisName(identity.getName());
		mod.setCode(dto.getCode());
		mod.setName(dto.getName());
		mod.setReadType(dto.getReadType());
		mod.setChannelId(ch.getId());
		mod.setStatus("1");
		mod.setCustomerDate(new Date());
		mod.setContactPhone(dto.getContactPhone());
		mod.setModSources("PC");
		mod.setCreateId(us.getId());
		mod.setCreateTime(new Date());
		mod.setUpdateId(us.getId());
		mod.setUpdateTime(new Date());
		mod.setCustOrderId(custOrderId);
		//身份证信息入库
        IdcardInfo g = new IdcardInfo();
        g.setName(dto.getName());
        g.setSexual(dto.getSexual());
        g.setNation(dto.getNation());
        g.setAddress(dto.getAddress());
        g.setIdNumber(dto.getCode());
        g.setOrgans(dto.getOrgans());
        g.setExpiryDate(dto.getExpiryDate());
		mod.setIdcardinfo(JSONUtil.objectToJson(g));
		modMapper.insert(mod);

		//新增最新图片
		for (AttachedDocuments att : dto.getAtts()) {
			att.setSourceId(mod.getId());
		}
		documentsMapper.batchInsert(dto.getAtts());

		//记录待审核信息
		Check check = new Check();
		check.setStatusType("1");
		check.setCheckOpinion("提交资料待审核");
		check.setSourceId(mod.getId());
		check.setWayType("3");
		check.setSubmitDate(new Date());
		check.setCreateId(us.getId());
		check.setCreateTime(new Date());
		check.setUpdateId(us.getId());
		check.setUpdateTime(new Date());
		checkMapper.insert(check);

		//记录日志
		Map<String,String> logmap = new HashMap<String,String>();
		logmap.put("staff", us.getLoginName());
		logmap.put("phone",dto.getPhone());
		logmap.put("oldUserInfo",mod.getHisName()+"/"+mod.getHisCode());
		logmap.put("userInfo",mod.getName()+"/"+mod.getCode());
		logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
		logmap.put("result","成功！");
		logService.businessSaveLog(Business.phone_mod_customser,String.valueOf(us.getId()),us.getLoginName(),
				null != mod.getId() ? String.valueOf(mod.getId()) : "0","号码过户",logmap);

	}

	/**
	 * 查询过户列表
	 * @param dt
	 * @param searchMap
	 * @return
	 */
	public DataTable<ModCustomerListDTO> modList(DataTable<ModCustomerListDTO> dt,Map<String,Object> searchMap) throws Exception{
		List<ModCustomerListDTO> listDto = modMapper.modList(searchMap);
		int count = modMapper.modListCount(searchMap);
		dt.setAaData(listDto);
		dt.setiTotalDisplayRecords(count);
		return dt;
	}

	/**
	 * 查询过户信息数量
	 * @param searchMap
	 * @return
	 * @throws Exception
	 */
	public int modListCount(Map<String,Object> searchMap) throws Exception{
		return modMapper.modListCount(searchMap);
	}

	/**
	 * 查询过户信息
	 * @return
	 * @throws Exception
	 */
	public ModCustomer findById(Integer id) throws Exception{
		return modMapper.findById(id);
	}

	/**
	 * 查询过户信息
	 * @return
	 * @throws Exception
	 */
	public int uploadMod(ModCustomer modCustomer) throws Exception{
		return modMapper.update(modCustomer);
	}

	/**
	 * 号码过户审核
	 * @param check
	 * @return
	 * @throws Exception
	 */
	public RestStatus modCheck(Check check,User us) throws Exception{
		synchronized (ModCustomerService.class){
			String checkStr = "审核通过";//审核结果
            String newStr="审核通过";//审核消息
			ModCustomer modCustomer = modMapper.findById(check.getSourceId());
			if(!"1".equals(modCustomer.getStatus())){
				return new RestStatus(Boolean.FALSE,"500","该号码已经审核，不能重复审核");
			}
			String phone = modCustomer.getPhone();
            TNumber number = numberService.findByPhone(phone);
			if("2".equals(check.getStatusType())){
				//判断开户数量
				int nu = identityMapper.findIdentityNumByCode(modCustomer.getCode());
				int phoneCountMax = 0;
				try {
					phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
				} catch (Exception e1) {
					phoneCountMax = 5;
				}
				if (nu >= phoneCountMax) {
					return new RestStatus(Boolean.FALSE,"500","您已开户"+phoneCountMax+"个号码，不能再进行过户！");
				}
				modCustomer.setStatus("0");
				//身份证信息入库
		        IdcardInfo g = JSONUtil.jsonToObject(modCustomer.getIdcardinfo(), IdcardInfo.class);
		        int totalCount = idcardInfoMapper.findCountByIdNumber(g.getIdNumber());
		        if(totalCount == 0){
		            // 向身份证信息表添加数据
		            idcardInfoMapper.insert(g);
		        }else{
		            // 向身份证信息表更新数据
		            idcardInfoMapper.update(g);
		        }
		        
		        //号码信息变动表
		        Channels channels = channelsMapper.findById(modCustomer.getChannelId());
		        NumberRecord r = new NumberRecord();
		        r.setPhoneId(number.getId());
		        r.setPhone(number.getPhone());
		        r.setOptType(NmbRecordOptType.MOD_CUSTOMER.getId());
		        r.setOptStr("代理商："+channels.getChannelName()+"["+channels.getChannelCode()+"]过户成功");
                r.setCreateId(us.getId());
                r.setUpdateId(us.getId());
                numberRecordMapper.insert(r);

				Map<String,Object> searchMap = new HashMap<String,Object>();
				searchMap.put("phone",modCustomer.getPhone());
                searchMap.put("pStatusNot",TNumber.STATUS_CANCEL);
				Identity identity = identityMapper.list(searchMap).get(0);
				//开户历史记录备份
				HisIdentity his = new HisIdentity();
				BeanUtils.copyProperties(his, identity);
				hisIdentityMapper.insert(his);
				//修改开户信息附件归属
				documentsMapper.upAttachment(identity.getId(), "t_identity", his.getId(), "t_his_identity");//修改图片归属

				//修改开户记录姓名，身份证。联系电话
				identity.setCode(modCustomer.getCode());
				identity.setName(modCustomer.getName());
				identity.setContactPhone(modCustomer.getContactPhone());
				identityMapper.updateNameCode(identity);
				//复制过户附件信息给开户信息
				List<AttachedDocuments> attr = attachedDocumentsMapper.findBySourceIdAndSourceName(modCustomer.getId(), "t_mod_customer");
				for (AttachedDocuments att : attr) {
					att.setSourceId(identity.getId());
					att.setSourceName("t_identity");
				}
				documentsMapper.batchInsert(attr);
				
				//录入biz表
				Date d = new Date();
		        List<Biz> saveList = new ArrayList<Biz>();
				Biz b = new Biz();
		        b.setPhone(number.getPhone());
		        b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
		        b.setOperationType(Biz.opt_type_2);
		        b.setValidType("1");
		        b.setOperationTime(d);
		        b.setStatus("1");
		        b.setServCode(null);
		        b.setServName("过户");
		        b.setNewServCode(null);
                b.setNewServName(modCustomer.getName());
                b.setOldServCode(null);
                b.setOldServName(modCustomer.getHisName());
		        b.setMoney(new BigDecimal(0));
		        b.setBizType(BizType.MOD_CUSTOMER.getCode());
                b.setBizName("过户");
                b.setFeeStyle("3");
                b.setValidType("1");
		        b.setWayType("AGENT");
		        b.setIp("");
		        b.setReason("");
		        b.setRemark(null);
		        b.setCreateTime(d);
		        b.setUpdateTime(d);
		        saveList.add(b);				
		        bizMapper.batchInsert(saveList);
				
				// 查询调用调用BOSS接口是否打开
	            String flag = SysConfig.getValue("SendToBoss");
	            if (flag != null && flag.equals("true")) {
	                if (number.getOperatorCode()==1) {
	                    /** ---------------------------------------------调用接口-----------------------------------------** ***/
	                    TModCustomerBOSSBO bo = new TModCustomerBOSSBO();
	                    bo.setMSISDN("86"+modCustomer.getPhone());
	                    bo.setCustName(modCustomer.getName());
	                    bo.setCertType("1");//身份证
	                    bo.setCertNbr(modCustomer.getCode());
	                    RestStatus rs = buyNewService.ModCustomerBOSS(bo,  "2", us);
	                    if(rs.getStatus()){
	                        logger.info("号码："+modCustomer.getPhone()+"过户成功");
	                    }else{
	                        throw new Exception("号码="+modCustomer.getPhone()+"调用过户接口失败，原因："+rs.getErrorMessage());
	                    }
                    } else if (number.getOperatorCode()==2) {
                        RestStatus rsStatus = bossUnicomService.doCompleteOrder(modCustomer.getCustOrderId(), us);
                        if(!rsStatus.getStatus()){
                            logger.error("过户调用接口错误：phone=" + phone + "，原因："+rsStatus.getErrorMessage());
                            throw new Exception(rsStatus.getErrorMessage());
                        }
                    }
	            }
			}else{
				modCustomer.setStatus("2");
				checkStr = "审核不通过";
				newStr="审核不通过，原因："+check.getCheckOpinion();
				
				// 查询调用调用BOSS接口是否打开
                String flag = SysConfig.getValue("SendToBoss");
                logger.error("接口配置：" + flag + "调用接口开始");
                if (flag != null && flag.equals("true") && number.getOperatorCode()==2){// 联通号接口调用
                    try {
                        RestStatus rsStatus = bossUnicomService.doDeleteOrder(modCustomer.getCustOrderId(), us);
                        if(!rsStatus.getStatus()){
                            logger.error("号码审核调用取消接口错误：phone=" + number.getPhone() + "，原因："+rsStatus.getErrorMessage());
                            throw new Exception(rsStatus.getErrorMessage());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new Exception("号码审核调用取消接口错误！" + e.getMessage());
                    }
                }
			}
            
            try {
                NewsInfo n = new NewsInfo();
                n.setNewsType("1");
                n.setTitle("过户审核");
                n.setContent("号码："+modCustomer.getPhone()+" 过户"+newStr);
                n.setCreateTime(new Date());
                n.setIsRead("0");
                n.setTargetId(modCustomer.getCreateId());
                newsInfoMapper.insert(n);
                
                MsgPush m = new MsgPush();
                m.setNoticeId(n.getId());
                m.setNoticeType("t_news_info");
                m.setTitle(n.getTitle());
                m.setContent(n.getContent());
                m.setUserId(modCustomer.getCreateId());
                m.setStatus("0");
                msgPushMapper.insert(m);
            } catch (Exception e) {
                logger.error(modCustomer.getPhone()+"过户，记录消息出错，原因："+e.getMessage(),e);
                e.printStackTrace();
            }
			
			modCustomer.setUpdateId(us.getId());
			modCustomer.setUpdateTime(new Date());
			modMapper.update(modCustomer);

			check.setWayType("3");
			check.setSubmitDate(new Date());
			check.setCreateId(us.getId());
			check.setCreateTime(new Date());
			check.setUpdateId(us.getId());
			check.setUpdateTime(new Date());
			checkMapper.insert(check);

			//记录日志
			Map<String,String> logmap = new HashMap<String,String>();
			logmap.put("staff", us.getLoginName());
			logmap.put("phone",modCustomer.getPhone());
			logmap.put("checkStr",checkStr);
			logmap.put("remark",check.getCheckOpinion());
			logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
			logmap.put("result","成功！");
			logService.businessSaveLog(Business.phone_mod_check,String.valueOf(us.getId()),us.getLoginName(),
					null != check.getId() ? String.valueOf(check.getId()) : "0","号码过户审核",logmap);

			return new RestStatus(Boolean.TRUE);
		}
	}


	/**
	 * 号码过户数据后台校验
	 * @param dto
     * @param type mod-过户，update-修改资料
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    public Map<String,Object> modSumitCheck(ModCustomerDTO dto,User user,String type,DataTable<CsUserListDTO> dt) throws Exception{
		Map<String, Object> map = new HashMap<String, Object>();
		if(Utils.isEmptyString(dto.getPhone())){
			map.put("status", false);
			map.put("msg", "手机号码不能为空");
			return map;
		}
		if(Utils.isEmptyString(dto.getName())){
			map.put("status", false);
			map.put("msg", "姓名不能为空");
			return map;
		}
		if(Utils.isEmptyString(dto.getCode())){
			map.put("status", false);
			map.put("msg", "身份证不能为空");
			return map;
		}
		if(Utils.isEmptyString(dto.getSexual())){
			map.put("status", false);
			map.put("msg", "性别不能为空");
			return map;
		}
		if(Utils.isEmptyString(dto.getOrgans())){
			map.put("status", false);
			map.put("msg", "签发机关不能为空");
			return map;
		}
		if(Utils.isEmptyString(dto.getExpiryDate())){
			map.put("status", false);
			map.put("msg", "有效期不能为空");
			return map;
		}
		if(Utils.isEmptyString(dto.getAddress())){
			map.put("status", false);
			map.put("msg", "身份证住址不能为空");
			return map;
		}
        if(Utils.isEmptyString(dto.getReadType())){
            map.put("status", false);
            map.put("msg", "请选择读取方式");
            return map;
        }
		Pattern pattern = Pattern.compile("[\u4E00-\u9FA5]{1,10}([\u00B7]{0,1}[\u4E00-\u9FA5]{1,10})+");
		Matcher matcher = pattern.matcher(dto.getName());
		if (!matcher.matches()) {
			map.put("status", false);
			map.put("msg", "身份证姓名格式不正确");
			return map;
		}
		if(!"updaet".equals(type)){ //修改资料照片非必填
		    File localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + dto.getCardHandUploadFilePath());
		    if(!localFileA.exists()){
		        localFileA=new File(imageURL + File.separator + dto.getCardHandUploadFilePath());
		        if(!localFileA.exists()){
    		        map.put("status", false);
    		        map.put("msg", "您的身份证手持照没有上传成功，请重新上传");
    		        return map;
		        }
		    }
            localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + dto.getCardFrontUploadFilePath());
		    if(!localFileA.exists()){
		        localFileA=new File(imageURL + File.separator + dto.getCardFrontUploadFilePath());
		        if(!localFileA.exists()){
    		        map.put("status", false);
    		        map.put("msg", "您的身份证正面照没有上传成功，请重新上传");
    		        return map;
		        }
		    }
            localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + dto.getCardRearUploadFilePath());
		    if(!localFileA.exists()){
		        localFileA=new File(imageURL + File.separator + dto.getCardRearUploadFilePath());
		        if(!localFileA.exists()){
    		        map.put("status", false);
    		        map.put("msg", "您的身份证背面照没有上传成功，请重新上传！");
    		        return map;
		        }
		    }
		}
		
		TNumber number = numberService.findByPhone(dto.getPhone());
		int operatorCode = number.getOperatorCode();
		if(operatorCode == 1){
		    TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
		    bo.setMSISDN("86" + dto.getPhone());
		    RestStatus rs = buyNewService.QueryUserProfileBOSS(bo,user);
		    if(rs.getStatus()){
		        TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
		        if("mod".equals(type)){
		            if(!"A".equals(res.getState())){
		                if(!("E".equals(res.getState()) && Integer.valueOf(res.getBal()) >=0)){
		                    map.put("status", false);
		                    map.put("msg", "对不起，用户当前状态不正常不能进行过户");
		                    return map;
		                }
		            }
		            if(dto.getCode().equals(res.getCertNbr())){
		                map.put("status", false);
		                map.put("msg", "号码："+dto.getPhone() +"已经归属过户目标用户！");
		                return map;
		            }
		        }else if("update".equals(type)){
		            if(!dto.getCode().equals(res.getCertNbr()) || !dto.getName().equals(res.getCustName())){
		                dto.setHisName(res.getCustName());
		                dto.setHisCode(res.getCertNbr());
		                if(Integer.valueOf(res.getBal()) < 0){
		                    map.put("status", false);
		                    map.put("msg", "对不起，当前号码已欠费不能进行修改资料，请先充值！");
		                    return map;
		                }
		            }
		            
		        }
		    }else{
		        map.put("status", false);
		        map.put("msg", rs.getErrorMessage());
		        return map;
		    }
		} else if(operatorCode == 2){
		    String status = number.getStatus();
		    if(!status.equals(PhoneStatus.US10.getId())){
                map.put("status", false);
                map.put("msg", "对不起，用户当前状态不正常不能进行过户！");
                return map;
            } 
		    ReqCommonDTO reqCommonDTO = new ReqCommonDTO();
		    reqCommonDTO.setPhone(dto.getPhone());
            csUserService.userList(dt,user,reqCommonDTO);
            if(null != dt && dt.getAaData() != null && dt.getAaData().size() >0){
                Map<String,Object> entry = (Map<String,Object>)dt.getAaData().get(0);
                String certName = String.valueOf(entry.get("certName"));
                String certCode = String.valueOf(entry.get("certCode"));
                String bal = String.valueOf(entry.get("bal"));
                if(!dto.getCode().equals(certCode) || !dto.getName().equals(certName)){
                    dto.setHisName(certName);
                    dto.setHisCode(certCode);
                    if(Float.valueOf(bal).intValue() < 0){
                        map.put("status", false);
                        map.put("msg", "对不起，当前号码已欠费不能进行修改资料，请先充值！");
                        return map;
                    }
                }
            }
		    if(dto.getCode().equals(number.getCode())){
                map.put("status", false);
                map.put("msg", "号码："+dto.getPhone() +"已经归属过户目标用户！");
                return map;
            }
		}
		//判断开户身份证年龄
		int minAge = 0;
		try {
			minAge = Integer.parseInt(DicUtil.getMapDictionary("MIN_OPEN_AGE").get("MIN_OPEN_AGE_VAL"));
		} catch (Exception e1) {
			minAge = 10;
			logger.error("最小开卡年龄没有配置，默认为10岁！");
		}
		if(!IDCardUtil.isIDCard(dto.getCode())){
			map.put("status", false);
			map.put("msg", "请填写正确身份证号码");
			return map;
		}
		if(!IDCardUtil.compareDate(dto.getCode(), minAge)){
			map.put("status", false);
			map.put("msg", "过户身份证年龄小于"+ minAge+"不能过户");
			return map;
		}
		if(!dto.getCode().equals(dto.getHisCode()) || !dto.getName().equals(dto.getHisName())){
		    //判断开户数量
		    int nu = identityMapper.findIdentityNumByCode(dto.getCode());
		    if("update".equals(type) && dto.getCode().equals(dto.getHisCode())){
		        nu = nu-1;
		    }
		    int phoneCountMax = 0;
		    try {
		        phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
		    } catch (Exception e1) {
		        phoneCountMax = 5;
		    }
		    if (nu >= phoneCountMax) {
		        map.put("status", false);
		        map.put("msg", "您已开户"+phoneCountMax+"个号码，不能再进行过户！");
		        return map;
		    }
		}

		map.put("status", true);
		return map;
	}
	
	/**
     * 号码资料修改
     * @param dto
     * @throws Exception
     */
    public RestStatus modUserInfo(ModCustomerDTO dto,User us) throws Exception{
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("phone",dto.getPhone());
        searchMap.put("pStatusNot",TNumber.STATUS_CANCEL);
        Identity identity = identityMapper.list(searchMap).get(0);
        Channels ch = channelsMapper.findById(identity.getChannelId());
        //身份证或姓名和boss不一致需要过户
        if(!dto.getCode().equals(dto.getHisCode()) || !dto.getName().equals(dto.getHisName())){
            //判断开户数量
            int nu = identityMapper.findIdentityNumByCode(dto.getCode());
            if(dto.getCode().equals(dto.getHisCode())){
                nu = nu-1;
            }
            int phoneCountMax = 0;
            try {
                phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
            } catch (Exception e1) {
                phoneCountMax = 5;
            }
            if (nu >= phoneCountMax) {
                return new RestStatus(Boolean.FALSE,"500","您已开户"+phoneCountMax+"个号码，不能再进行过户！");
            }
        }
        
        //身份证头像
        if(!Utils.isEmptyString(dto.getImgStr())){
            Map<String,Object> imgMap =  FileUtil.getInstance().imgStr(dto.getPhone(),dto.getImgStr(),"4",ch.getChannelCode(),imageURL,"PC");
            if(!"true".equals(imgMap.get("status").toString())){
                return new RestStatus(Boolean.FALSE,"500",imgMap.get("msg").toString());
            }
        }

        //过户信息入库
        ModCustomer mod = new ModCustomer();
        mod.setPhone(dto.getPhone());
        mod.setHisCode(identity.getCode());
        mod.setHisName(identity.getName());
        mod.setCode(dto.getCode());
        mod.setName(dto.getName());
        mod.setChannelId(ch.getId());
        mod.setStatus("0");
        mod.setCustomerDate(new Date());
        mod.setContactPhone(dto.getContactPhone());
        mod.setModSources("PC");
        mod.setCreateId(us.getId());
        mod.setCreateTime(new Date());
        mod.setUpdateId(us.getId());
        mod.setUpdateTime(new Date());

        //身份证信息入库
        IdcardInfo g = new IdcardInfo();
        g.setName(dto.getName());
        g.setSexual(dto.getSexual());
        g.setNation(dto.getNation());
        g.setAddress(dto.getAddress());
        g.setIdNumber(dto.getCode().trim());
        g.setOrgans(dto.getOrgans());
        g.setExpiryDate(dto.getExpiryDate());
        int totalCount = idcardInfoMapper.findCountByIdNumber(dto.getCode());
        if(totalCount == 0){
            // 向身份证信息表添加数据
            idcardInfoMapper.insert(g);
        }else{
            // 向身份证信息表更新数据
            idcardInfoMapper.update(g);
        }

        //记录待审核信息
        Check check = new Check();
        check.setStatusType("1");
        check.setCheckOpinion("提交资料待审核");
        check.setSourceId(mod.getId());
        check.setWayType("3");
        check.setSubmitDate(new Date());
        check.setCreateId(us.getId());
        check.setCreateTime(new Date());
        check.setUpdateId(us.getId());
        check.setUpdateTime(new Date());
        checkMapper.insert(check);
        
        //默认审核通过
        Check check2 = new Check();
        check2.setStatusType("2");
        check2.setCheckOpinion("审核通过");
        check2.setSourceId(mod.getId());
        check2.setWayType("3");
        check2.setSubmitDate(new Date());
        check2.setCreateId(us.getId());
        check2.setCreateTime(new Date());
        check2.setUpdateId(us.getId());
        check2.setUpdateTime(new Date());
        checkMapper.insert(check2);
        
        //开户图片
        List<AttachedDocuments> attr = attachedDocumentsMapper.findBySourceIdAndSourceName(identity.getId(), "t_identity");
        AttachedDocuments cardHand = null;//手持身份证照片
        AttachedDocuments cardFront = null;//身份证正面照
        AttachedDocuments cardRear = null;//身份证背面照
        AttachedDocuments cardHeadImg = null;//身份证头像
        if(null != attr && attr.size() >0){
            for(AttachedDocuments s:attr){
                if(s.getSourceType().equals("cardHand")){
                    cardHand = new AttachedDocuments();
                    BeanUtils.copyProperties(cardHand, s);
                }else if(s.getSourceType().equals("cardFront")){
                    cardFront = new AttachedDocuments();
                    BeanUtils.copyProperties(cardFront, s);
                }else if(s.getSourceType().equals("cardRear")){
                    cardRear = new AttachedDocuments();
                    BeanUtils.copyProperties(cardRear, s);
                }else if(s.getSourceType().equals("cardHeadImg")){
                    cardHeadImg = new AttachedDocuments();
                    BeanUtils.copyProperties(cardHeadImg, s);
                }
            }
        }
        
        //开户历史记录备份
        HisIdentity his = new HisIdentity();
        BeanUtils.copyProperties(his, identity);
        hisIdentityMapper.insert(his);
        //修改开户信息附件归属
        documentsMapper.upAttachment(identity.getId(), "t_identity", his.getId(), "t_his_identity");//修改图片归属

        //修改开户记录姓名，身份证。联系电话
        identity.setCode(dto.getCode());
        identity.setName(dto.getName());
        identity.setContactPhone(dto.getContactPhone());
        identityMapper.updateNameCode(identity);
        
        //获取图片修改
        List<AttachedDocuments> attrs = modUserInfoPic(dto,cardHand,cardFront,cardRear,cardHeadImg,identity.getId(),mod.getId());
        if(null != attrs){
            documentsMapper.batchInsert(attrs);
        }
        
        TNumber tn = numberService.findById(identity.getPhoneId());
        
        //身份证或姓名和boss不一致需要过户
        if(!dto.getCode().equals(dto.getHisCode()) || !dto.getName().equals(dto.getHisName())){
            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            if (flag != null && flag.equals("true")) {
                /** ---------------------------------------------调用接口-----------------------------------------** ***/
                if(1 == tn.getOperatorCode().intValue()){//移动
                   TModCustomerBOSSBO bo = new TModCustomerBOSSBO();
                    bo.setMSISDN("86"+dto.getPhone());
                    bo.setCustName(dto.getName());
                    bo.setCertType("1");//身份证
                    bo.setCertNbr(dto.getCode());
                    RestStatus rs = buyNewService.ModCustomerBOSS(bo,  "2", us);
                    if(rs.getStatus()){
                        logger.info("号码："+dto.getPhone()+"过户成功");
                    }else{
                        throw new Exception("号码="+dto.getPhone()+"调用过户接口失败，原因："+rs.getErrorMessage());
                    }
                }else if(2 == tn.getOperatorCode().intValue()){//联通
                    String custOrderId = "";
                    RestStatus rsStatus = bossUnicomService.changeCust(dto, "1", us);//1.过户 2.实名补录
                    if(rsStatus.getStatus()){
                        ContractRoot root = (ContractRoot)rsStatus.getResponseData();
                        custOrderId = root.getSvcCont().getCustOrderId();
                    } else {
                        logger.error("号码="+dto.getPhone()+"调用过户预提交接口失败，原因："+rsStatus.getErrorMessage());
                        throw new Exception(rsStatus.getErrorMessage());
                    }
                    mod.setCustOrderId(custOrderId);
                    //过户申请提交
                    RestStatus rsStatusRp = bossUnicomService.doCompleteOrder(custOrderId, us);
                    if(!rsStatusRp.getStatus()){
                        //过户提交失败，删除预提交订单
                        RestStatus rsStatusDel = bossUnicomService.doDeleteOrder(custOrderId, us);
                        if(!rsStatusDel.getStatus()){
                            logger.error("号码修改资料过户失败，删除订单：phone=" + dto.getPhone() + "，原因："+rsStatusDel.getErrorMessage());
                            throw new Exception(rsStatusDel.getErrorMessage());
                        }
                        logger.error("号码="+dto.getPhone()+"调用过户接口失败，原因："+rsStatusRp.getErrorMessage());
                        throw new Exception(rsStatusRp.getErrorMessage());
                    }
                } 
            }
        }
        modMapper.insert(mod);
        
        //记录日志
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("phone",dto.getPhone());
        logmap.put("oldUserInfo",mod.getHisName()+"/"+mod.getHisCode());
        logmap.put("userInfo",mod.getName()+"/"+mod.getCode());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logService.businessSaveLog(Business.phone_mod_user_info,String.valueOf(us.getId()),us.getLoginName(),
                null != mod.getId() ? String.valueOf(mod.getId()) : "0","号码用户资料修改",logmap);
        return new RestStatus(Boolean.TRUE);

    }
    
    /**
     * 获取修改资料图片
     * @param dto
     * @return
     * @throws Exception
     */
    public List<AttachedDocuments> modUserInfoPic(ModCustomerDTO dto,AttachedDocuments cardHand,
            AttachedDocuments cardFront,AttachedDocuments cardRear,AttachedDocuments cardHeadImg,
            Integer identityId,Integer modId) throws Exception{
        List<AttachedDocuments> attrs = new ArrayList<AttachedDocuments>();
        
        //手持身份证照片
        if(!Utils.isEmptyString(dto.getCardHandUploadFilePath())){
            //开户图片
            AttachedDocuments att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardHandUploadFile());
            att.setAttachmentUrl(dto.getCardHandUploadFilePath());
            att.setSourceType("cardHand");
            att.setSourceId(identityId);
            att.setSourceName("t_identity");
            attrs.add(att);
            //过户图片
            att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardHandUploadFile());
            att.setAttachmentUrl(dto.getCardHandUploadFilePath());
            att.setSourceType("cardHand");
            att.setSourceId(modId);
            att.setSourceName("t_mod_customer");
            attrs.add(att);
        }else if(null != cardHand){
            //开户图片
            AttachedDocuments att = new AttachedDocuments();
            BeanUtils.copyProperties(att, cardHand);
            att.setSourceId(identityId);
            att.setSourceName("t_identity");
            attrs.add(att);
            //过户图片
            att = new AttachedDocuments();
            BeanUtils.copyProperties(att, cardHand);
            att.setSourceId(modId);
            att.setSourceName("t_mod_customer");
            attrs.add(att);
        }
     
        //身份证正面照
        if(!Utils.isEmptyString(dto.getCardFrontUploadFilePath())){
            //开户图片
            AttachedDocuments att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardFrontUploadFile());
            att.setAttachmentUrl(dto.getCardFrontUploadFilePath());
            att.setSourceType("cardFront");
            att.setSourceId(identityId);
            att.setSourceName("t_identity");
            attrs.add(att);
            //过户图片
            att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardFrontUploadFile());
            att.setAttachmentUrl(dto.getCardFrontUploadFilePath());
            att.setSourceType("cardFront");
            att.setSourceId(modId);
            att.setSourceName("t_mod_customer");
            attrs.add(att);
        }else if(null != cardFront){
            //开户图片
            AttachedDocuments att = new AttachedDocuments();
            BeanUtils.copyProperties(att, cardFront);
            att.setSourceId(identityId);
            att.setSourceName("t_identity");
            attrs.add(att);
            //过户图片
            att = new AttachedDocuments();
            BeanUtils.copyProperties(att, cardFront);
            att.setSourceId(modId);
            att.setSourceName("t_mod_customer");
            attrs.add(att);
        }
        
        //身份证背面照
        if(!Utils.isEmptyString(dto.getCardRearUploadFilePath())){
            //开户图片
            AttachedDocuments att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardRearUploadFile());
            att.setAttachmentUrl(dto.getCardRearUploadFilePath());
            att.setSourceType("cardRear");
            att.setSourceId(identityId);
            att.setSourceName("t_identity");
            attrs.add(att);
            //过户图片
            att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardRearUploadFile());
            att.setAttachmentUrl(dto.getCardRearUploadFilePath());
            att.setSourceType("cardRear");
            att.setSourceId(modId);
            att.setSourceName("t_mod_customer");
            attrs.add(att);
        }else if(null != cardRear){
            //开户图片
            AttachedDocuments att = new AttachedDocuments();
            BeanUtils.copyProperties(att, cardRear);
            att.setSourceId(identityId);
            att.setSourceName("t_identity");
            attrs.add(att);
            //过户图片
            att = new AttachedDocuments();
            BeanUtils.copyProperties(att, cardRear);
            att.setSourceId(modId);
            att.setSourceName("t_mod_customer");
            attrs.add(att);
        }
        
        return attrs;
    }
    
}
