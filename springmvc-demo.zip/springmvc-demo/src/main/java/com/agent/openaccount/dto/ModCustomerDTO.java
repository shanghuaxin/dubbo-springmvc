package com.agent.openaccount.dto;

import java.util.List;

import com.agent.openaccount.entity.AttachedDocuments;

/**
 * 号码过户
 */
public class ModCustomerDTO{
    private Integer phoneId;//号码表ID
    private String phone;//号码
    private String contactPhone; //联系电话
    private String name;//姓名
    private String code;//身份证号
    private String sexual;//性别1：男，0：女
    private String nation;//民族
    private String address;//身份证地址
    private String organs; //签发机关
    private String expiryDate; //有效期
    private String imgStr;//头像字节字符串
    private String cardHandUploadFile;//手持照名称
    private String cardHandUploadFilePath;//手持照路径
    private String cardFrontUploadFile;//正面照名称
    private String cardFrontUploadFilePath;//正面照路径
    private String cardRearUploadFile;//反面照名称
    private String cardRearUploadFilePath;//反面照路径
    private List<AttachedDocuments> atts;//过户附件
    private String hisName;//历史姓名
    private String hisCode;//历史身份证号
    private String readType;//识别方式：1-阅读识别器,2-照片识别,3-NFC,4-亿数,5-华视,6-神思,7-信通，8-精伦,9-OCR

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSexual() {
        return sexual;
    }

    public void setSexual(String sexual) {
        this.sexual = sexual;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getOrgans() {
        return organs;
    }

    public void setOrgans(String organs) {
        this.organs = organs;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone= phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getCardHandUploadFile() {
        return cardHandUploadFile;
    }

    public void setCardHandUploadFile(String cardHandUploadFile) {
        this.cardHandUploadFile = cardHandUploadFile;
    }

    public String getCardHandUploadFilePath() {
        return cardHandUploadFilePath;
    }

    public void setCardHandUploadFilePath(String cardHandUploadFilePath) {
        this.cardHandUploadFilePath = cardHandUploadFilePath;
    }

    public String getCardFrontUploadFile() {
        return cardFrontUploadFile;
    }

    public void setCardFrontUploadFile(String cardFrontUploadFile) {
        this.cardFrontUploadFile = cardFrontUploadFile;
    }

    public String getCardFrontUploadFilePath() {
        return cardFrontUploadFilePath;
    }

    public void setCardFrontUploadFilePath(String cardFrontUploadFilePath) {
        this.cardFrontUploadFilePath = cardFrontUploadFilePath;
    }

    public String getCardRearUploadFile() {
        return cardRearUploadFile;
    }

    public void setCardRearUploadFile(String cardRearUploadFile) {
        this.cardRearUploadFile = cardRearUploadFile;
    }

    public String getCardRearUploadFilePath() {
        return cardRearUploadFilePath;
    }

    public void setCardRearUploadFilePath(String cardRearUploadFilePath) {
        this.cardRearUploadFilePath = cardRearUploadFilePath;
    }

    public List<AttachedDocuments> getAtts() {
        return atts;
    }

    public void setAtts(List<AttachedDocuments> atts) {
        this.atts = atts;
    }

    public String getImgStr() {
        return imgStr;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public String getHisName() {
        return hisName;
    }

    public void setHisName(String hisName) {
        this.hisName = hisName;
    }

    public String getHisCode() {
        return hisCode;
    }

    public void setHisCode(String hisCode) {
        this.hisCode = hisCode;
    }

    public String getReadType() {
        return readType;
    }

    public void setReadType(String readType) {
        this.readType = readType;
    }
}
