package com.agent.openaccount.entity;

import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.order.common.util.Utils;

/**
 * 开卡审核表
 */
public class Check extends BaseDomain {

    private static final long serialVersionUID = -4180875970913985763L;
    /**待审批*/
    public final static String audit_apply = "1";
    /**审批通过*/
    public final static String audit_yes = "2";
    /**审批不通过*/
    public final static String audit_no = "3";
    /**稽核不通过*/
    public final static String check_no = "4";
    
    private Integer sourceId;      //来源id
    private Integer phoneId;       //号码id
    private String wayType;        //来源类型：0.网点   2.开卡  3.号码过户
    private Date submitDate;       //提交时间
    private String statusType;     //状态（0取消，1待审核，2审核通过，3审核不通过，4稽查不通过）
    private Date passDate;         //通过时间
    private String checkOpinion;   //审批意见
    private Integer channelId;     //渠道ID

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getWayType() {
        return wayType;
    }

    public void setWayType(String wayType) {
        this.wayType = wayType;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public String getStatusTypeStr() {
        if(!Utils.isEmptyString(statusType)){
            if("1".equals(statusType)){
                return "提交审核申请";
            }else if("2".equals(statusType)){
                return "审核通过";
            }else if("3".equals(statusType)){
                return "审核不通过";
            }else if("0".equals(statusType)){
                return "开户取消";
            }
        }
        return "";
    }

    public String getStatusType() {
        return statusType;
    }

    public void setStatusType(String statusType) {
        this.statusType = statusType;
    }

    public Date getPassDate() {
        return passDate;
    }

    public void setPassDate(Date passDate) {
        this.passDate = passDate;
    }

    public String getCheckOpinion() {
        return checkOpinion;
    }

    public void setCheckOpinion(String checkOpinion) {
        this.checkOpinion = checkOpinion;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    @Override
    public String toString() {
        return "Check [sourceId=" + sourceId + ", phoneId=" + phoneId + ", wayType=" + wayType + ", submitDate="
                + submitDate + ", statusType=" + statusType + ", passDate=" + passDate + ", checkOpinion="
                + checkOpinion + "]";
    }

}
