package com.agent.openaccount.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.AttachedDocuments;

public interface AttachedDocumentsMapper extends BaseMapper<AttachedDocuments, Integer> {
    
    //查询照片信息
    public List<AttachedDocuments> findBySourceIdAndSourceName(@Param(value="sourceId") Integer sourceId, @Param(value="sourceName") String sourceName);
    //如果重新开卡，删除以前的照片信息
    public void deleteBySourceIdAndSourceName(@Param(value="sourceId") Integer sourceId, @Param(value="sourceName") String sourceName);
    //批量添加附件
    public void batchInsert(List<AttachedDocuments> list);
    //添加附件(app端是照片先上传，然后进行修改)
    public void appUpFeAttachment(@Param(value="sId") Integer sId, @Param(value="sName") String sName, @Param(value="sourceName") String sourceName);
    //修改附件归属
    public void upAttachment(@Param(value="sOldId") Integer sOldId, @Param(value="sOldName") String sOldName,@Param(value="sId") Integer sId, @Param(value="sName") String sourceName);

    //根据id删除
    public int batchDelByIds(List<Integer> ids);
}
