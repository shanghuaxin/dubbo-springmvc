package com.agent.openaccount.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberMapper;
import com.agent.number.service.NumberService;
import com.agent.openaccount.dto.CheckImgResubmitDTO;
import com.agent.openaccount.dto.CheckListDTO;
import com.agent.openaccount.entity.ApplyIdentity;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.Check;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.entity.ModCustomer;
import com.agent.openaccount.mapper.ApplyIdentityMapper;
import com.agent.openaccount.mapper.AttachedDocumentsMapper;
import com.agent.openaccount.mapper.CheckMapper;
import com.agent.openaccount.mapper.IdcardInfoMapper;
import com.agent.openaccount.mapper.IdentityMapper;
import com.agent.openaccount.mapper.ModCustomerMapper;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.util.DicUtil;

@Transactional(rollbackFor=Exception.class)
@Service("checkService")
public class CheckService {
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Autowired
    private CheckMapper checkMapper;
    @Autowired
    private AttachedDocumentsMapper documentsMapper;
    @Resource
    private ModCustomerMapper modMapper;
    @Autowired
    private ApplyIdentityMapper applyIdentityMapper;
    @Autowired
    private IdentityMapper identityMapper;
    @Autowired
    private NumberMapper numberMapper;
    @Autowired
    private ChannelsMapper channelsMapper;
    @Autowired
    private NumberService numberService;
    @Autowired
    private IdcardInfoMapper idcardInfoMapper;

    private static Logger logger = LoggerFactory.getLogger(CheckService.class);
    
    /**
     * 提交审核信息
     * @param check
     * @throws Exception
     */
    public void insert(Check check) throws Exception{
        checkMapper.insert(check);
    }

    /**
     * 查询审核信息列表
     * @param dt
     * @param searchMap
     * @return
     */
    public DataTable<CheckListDTO> checkList(DataTable<CheckListDTO> dt,Map<String,Object> searchMap) throws Exception{
        List<CheckListDTO> listDto = checkMapper.checkList(searchMap);
        int count = checkMapper.checkListCount(searchMap);
        dt.setAaData(listDto);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    public List<CheckListDTO> operationNumberList(Map<String, Object> map) {
        return checkMapper.operationNumberList(map);
    }
    
    public int operationNumberListTotal(Map<String, Object> map) {
        return checkMapper.operationNumberListCount(map);
    }

    /**
     * 审核不通过重新提交照片
     * @param dto
     * @param us
     * @return
     * @throws Exception
     */
    public RestStatus resubmit(CheckImgResubmitDTO dto,User us) throws Exception{
        Date d = new Date();
        //根据当前用户查找当前渠道
        Channels fd = channelsMapper.findByUserId(us.getId());
        //查询照片
        String sourceName = "";
        if("3".equals(dto.getWayType())){ //过户
            sourceName = "t_mod_customer";
            //修改过户记录为待审核
            ModCustomer mod = modMapper.findById(dto.getSourceId());
            mod.setStatus("1");
            mod.setUpdateId(us.getId());
            mod.setUpdateTime(d);
            
            //修改身份证信息
            IdcardInfo info = new IdcardInfo();
            info.setAddress(dto.getAddress());
            info.setExpiryDate(dto.getExpiryDate());
            info.setOrgans(dto.getOrgans());
            info.setName(dto.getName());
            info.setSexual(dto.getSexual());
            info.setNation(dto.getNation());
            info.setIdNumber(dto.getIdNumber());
            mod.setName(dto.getName());
            mod.setCode(dto.getIdNumber());
            String jsonStr = JSONUtil.objectToJson(info);
            String resubmit = DicUtil.getMapDictionary("BUG").get("RESUBMITFAIL");
            if("true".equals(resubmit) && jsonStr==null){
                logger.error("重新提交失败，身份信息不完整！"+info.toString());
                throw new Exception("重新提交失败，身份信息不完整！");
            }
            mod.setIdcardinfo(jsonStr);
            
            modMapper.update(mod);
            //增加提交审核记录
            Check check = new Check();
            check.setStatusType(Check.audit_apply);
            check.setCheckOpinion("重新提交资料待审核");
            check.setSourceId(mod.getId());
            check.setWayType("3");
            check.setSubmitDate(d);
            check.setCreateId(us.getId());
            check.setCreateTime(d);
            check.setUpdateId(us.getId());
            check.setUpdateTime(d);
            checkMapper.insert(check);
        }else if("2".equals(dto.getWayType())){ //开户
            sourceName = dto.getSourceName();
            String phone = "";
            if(StringUtils.equals(dto.getSourceName(), "t_apply_identity")) {
                ApplyIdentity applyIdentity = applyIdentityMapper.select(dto.getSourceId());
                phone = applyIdentity.getPhone();
                
                TNumber n = numberMapper.findByPhone(phone);
                
                int nu = identityMapper.findIdentityNumByCode(applyIdentity.getCode());
                int phoneCountMax = 0;
                try {
                    phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
                } catch (Exception e1) {
                    phoneCountMax = 5;
                }
                if (nu >= phoneCountMax) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，您已开户"+phoneCountMax+"个号码，不能再进行开户！");
                }
                
                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", n);
                param.put("channelId", fd.getId());
                param.put("accountType", null);
                param.put("operationType", 16);
                param.put("money", applyIdentity.getMoney());
                param.put("busMoney", n.getMoney());
                param.put("remark", null);
                param.put("transactionAccount", null);
                param.put("transId", null);
                param.put("transactionType", null);
                param.put("calcType", null);
                param.put("transactionFlow", null);
                param.put("payType", null);
                param.put("us", us);
                //开卡前审核，重新提交资料资料扣款
                RestStatus rs = numberService.takeMoney(param);
                
                if (!rs.getStatus()) {
                    return rs; // 账户金额不足
                }
                
                //修改身份证信息
                //String idcardInfoJson = applyIdentity.getIdcardinfo();
                IdcardInfo info = new IdcardInfo();//JSONUtil.jsonToObject(idcardInfoJson, IdcardInfo.class);
                info.setAddress(dto.getAddress());
                info.setExpiryDate(dto.getExpiryDate());
                info.setOrgans(dto.getOrgans());
                info.setName(dto.getName());
                info.setSexual(dto.getSexual());
                info.setNation(dto.getNation());
                info.setIdNumber(dto.getIdNumber());
                
                applyIdentity.setName(dto.getName());
                applyIdentity.setCode(dto.getIdNumber());
                String jsonStr = JSONUtil.objectToJson(info);
                String resubmit = DicUtil.getMapDictionary("BUG").get("RESUBMITFAIL");
                if("true".equals(resubmit) && jsonStr==null){
                    logger.error("重新提交失败，身份信息不完整！"+info.toString());
                    throw new Exception("重新提交失败，身份信息不完整！");
                }
                applyIdentity.setIdcardinfo(jsonStr);
                applyIdentity.setCheckStatus(Check.audit_apply);
                applyIdentity.setUpdateId(us.getId());
                applyIdentity.setUpdateTime(new Date());
                applyIdentityMapper.update(applyIdentity);
                //applyIdentityMapper.updateCheckStatus(applyIdentity.getId(), Check.audit_apply, us.getId());
                
                //增加提交审核记录
                Check check = new Check();
                check.setStatusType(Check.audit_apply);
                check.setCheckOpinion("重新提交资料待审核");
                check.setSourceId(applyIdentity.getId());
                check.setPhoneId(applyIdentity.getPhoneId());
                check.setWayType("2");
                check.setSubmitDate(d);
                check.setCreateId(us.getId());
                check.setCreateTime(d);
                check.setUpdateId(us.getId());
                check.setUpdateTime(d);
                checkMapper.insert(check);
            }else {
                Identity identity = identityMapper.select(dto.getSourceId());
                identity.setAduitStatus(Check.audit_apply);
                identity.setUpdateId(us.getId());
                identity.setUpdateTime(d);
                identity.setCode(dto.getIdNumber());
                identity.setName(dto.getName());
                identityMapper.update(identity);
                
                phone = identity.getPhone();
                //增加提交审核记录
                Check check = new Check();
                check.setStatusType(Check.audit_apply);
                check.setCheckOpinion("重新提交资料待审核");
                check.setSourceId(identity.getId());
                check.setPhoneId(identity.getPhoneId());
                check.setWayType("2");
                check.setSubmitDate(d);
                check.setCreateId(us.getId());
                check.setCreateTime(d);
                check.setUpdateId(us.getId());
                check.setUpdateTime(d);
                checkMapper.insert(check);
                
                //修改身份证信息
                //if(StringUtils.isNotBlank(dto.getOrgans())) {
                    IdcardInfo info = idcardInfoMapper.findByIdNumber(dto.getIdNumber());
                    info.setAddress(dto.getAddress());
                    info.setExpiryDate(dto.getExpiryDate());
                    info.setOrgans(dto.getOrgans());
                    info.setName(dto.getName());
                    info.setSexual(dto.getSexual());
                    info.setNation(dto.getNation());
                    info.setIdNumber(dto.getIdNumber());
                    
                    idcardInfoMapper.update(info);
                //}
            }
            
            TNumber number = numberMapper.findByPhone(phone);
            number.setCheckStatus(Check.audit_apply);
            numberMapper.update(number);
            
        }

        //查询历史图片
        List<AttachedDocuments> attr = documentsMapper.findBySourceIdAndSourceName(dto.getSourceId(), sourceName);

        //获取图片
        List<AttachedDocuments> atts = new ArrayList<AttachedDocuments>();
        AttachedDocuments att = new AttachedDocuments();
        //手持身份证照片
        att.setAttachmentName(dto.getCardHandUploadFile());
        att.setAttachmentUrl(dto.getCardHandUploadFilePath());
        att.setSourceName(sourceName);
        att.setSourceId(dto.getSourceId());
        att.setSourceType("cardHand");
        atts.add(att);
        //身份证正面照
        att = new AttachedDocuments();
        att.setAttachmentName(dto.getCardFrontUploadFile());
        att.setAttachmentUrl(dto.getCardFrontUploadFilePath());
        att.setSourceName(sourceName);
        att.setSourceId(dto.getSourceId());
        att.setSourceType("cardFront");
        atts.add(att);
        //身份证背面照
        att = new AttachedDocuments();
        att.setAttachmentName(dto.getCardRearUploadFile());
        att.setAttachmentUrl(dto.getCardRearUploadFilePath());
        att.setSourceName(sourceName);
        att.setSourceId(dto.getSourceId());
        att.setSourceType("cardRear");
        atts.add(att);
        //添加新图片
        documentsMapper.batchInsert(atts);

        if(null != attr && attr.size() >0){
            //删除非头像历史图片(开户修改资料界面修改，不在删除原有图片)
            List<Integer> ids = new ArrayList<Integer>();
            for(AttachedDocuments s : attr){
                if(!"cardHeadImg".equals(s.getSourceType())){
                    ids.add(s.getId());
//                    File f = new File(imageURL+s.getAttachmentUrl());
//                    if(f.exists()){
//                        f.delete();
//                    }
                }
            }
            documentsMapper.batchDelByIds(ids);
        }
        return new RestStatus(Boolean.TRUE);
    }
    
    public int noCheckCount(Integer channelId){
        return checkMapper.noCheckCount(channelId);
    }
}
