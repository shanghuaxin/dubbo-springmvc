package com.agent.openaccount.mapper;

import com.agent.openaccount.dto.CheckListDTO;
import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.Check;

import java.util.List;
import java.util.Map;

public interface CheckMapper extends BaseMapper<Check, Integer> {
    //开户号码是否已经申请审核
    public Check isExitCheck(@Param(value="phone") String phone);

    public List<CheckListDTO> checkList(Map<String,Object> searchMap);
    public int checkListCount(Map<String,Object> searchMap);
    //号码操作纪律
    public List<CheckListDTO> operationNumberList(Map<String,Object> searchMap);
    public int operationNumberListCount(Map<String,Object> searchMap);
    //渠道号码开户审核、稽核不通过次数
    public int noCheckCount(@Param(value="channelId") Integer channelId);
    
}
