package com.agent.openaccount.dto;

import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * 
 */
public class OpenAccount extends BaseDomain{

    private static final long serialVersionUID = 8556783328858528100L;
    private Integer phoneId;//号码表ID
    private String phone;//号码
    private String contactPhone; //联系电话
    private String name;//姓名
    private String code;//身份证号
    private String sexual;//性别1：男，0：女
    private String nation;//民族
    private String address;//身份证地址
    private String organs; //签发机关
    private String expiryDate; //有效期
    private String ocxName;//控件读取姓名
    private String ocxCode;//控件读取身份证号
    private String money;//开户金额
    private String mealCodes;//套餐编码
    private Date openDate;//开户时间
    private String openWay;  //识别方式：1-阅读识别器,2-照片识别
    private int status;  //状态 1激活中2未激活3已激活

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSexual() {
        return sexual;
    }

    public void setSexual(String sexual) {
        this.sexual = sexual;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getOrgans() {
        return organs;
    }

    public void setOrgans(String organs) {
        this.organs = organs;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone= phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public String getOpenWay() {
        return openWay;
    }

    public void setOpenWay(String openWay) {
        this.openWay = openWay;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getMealCodes() {
        return mealCodes;
    }

    public void setMealCodes(String mealCodes) {
        this.mealCodes = mealCodes;
    }

    public String getOcxName() {
        return ocxName;
    }

    public void setOcxName(String ocxName) {
        this.ocxName = ocxName;
    }

    public String getOcxCode() {
        return ocxCode;
    }

    public void setOcxCode(String ocxCode) {
        this.ocxCode = ocxCode;
    }
}
