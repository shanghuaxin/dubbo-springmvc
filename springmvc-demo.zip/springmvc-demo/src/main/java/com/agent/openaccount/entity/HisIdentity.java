package com.agent.openaccount.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 开户信息历史记录表
 */
public class HisIdentity implements Serializable {

    private static final long serialVersionUID = 3865070435936705959L;
    private Integer id;         //
    private String code;        //身份证号
    private String contactPhone;  //联系电话
    private String name;        //姓名
    private String phone;       //号码
    private Integer phoneId;    //号码ID
    private String status;      //状态:0-未报峻，1-已报峻
    private Date openDate;      //开户金额
    private String meals;       //开户时间
    private Integer channelId;  //开户渠道id
    private String openSources; //开户来源：PC（电脑），APP（手机）

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public String getMeals() {
        return meals;
    }

    public void setMeals(String meals) {
        this.meals = meals;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getOpenSources() {
        return openSources;
    }

    public void setOpenSources(String openSources) {
        this.openSources = openSources;
    }

    @Override
    public String toString() {
        return "HisIdentity [id=" + id + ", code=" + code + ", contactPhone=" + contactPhone + ", name=" + name
                + ", phone=" + phone + ", phoneId=" + phoneId + ", status=" + status + ", openDate=" + openDate
                + ", meals=" + meals + ", channelId=" + channelId + ", openSources=" + openSources + "]";
    }

}
