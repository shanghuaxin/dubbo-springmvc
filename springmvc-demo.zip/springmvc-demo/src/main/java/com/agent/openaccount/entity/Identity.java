package com.agent.openaccount.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * 开户信息记录表
 */
public class Identity extends BaseDomain {

    private static final long serialVersionUID = 2676522280237030698L;
    private String code;          //身份证号
    private String contactPhone;  //联系电话
    private String name;          //姓名
    private String phone;         //号码
    private Integer phoneId;      //号码ID
    private String status;        //状态:0-未报峻，1-已报峻
    private BigDecimal money;     //开户金额
    private Date openDate;        //开户时间
    private String meals;         //增值业务id ，逗号隔开
    private Integer channelId;    //渠道id
    private String custOrderId;         //联通保存订单、预算费用返回的订单ID
    private Integer channelIdLevel1;      //一级代理商id
    private Integer channelIdLevel2;      //二级代理商id
    private Integer channelIdLevel3;      //网点id
    private String openSources;    //开户来源：PC（电脑），APP（手机）
    private BigDecimal orderMoney;  //实际订单金额（套餐+增值业务）
    private Date handleDate;      //报峻处理时间
    private Date completeDate;    //移动报峻时间
    private Integer openMealId;   //开户套餐id
    private String openMealCode;  //开户套餐编号
    private String aduitStatus;   //审核状态（1待审核，2审核通过，3审核不通过）

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public String getMeals() {
        return meals;
    }

    public void setMeals(String meals) {
        this.meals = meals;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getCustOrderId() {
        return custOrderId;
    }

    public void setCustOrderId(String custOrderId) {
        this.custOrderId = custOrderId;
    }

    public Integer getChannelIdLevel1() {
        return channelIdLevel1;
    }

    public void setChannelIdLevel1(Integer channelIdLevel1) {
        this.channelIdLevel1 = channelIdLevel1;
    }

    public Integer getChannelIdLevel2() {
        return channelIdLevel2;
    }

    public void setChannelIdLevel2(Integer channelIdLevel2) {
        this.channelIdLevel2 = channelIdLevel2;
    }

    public Integer getChannelIdLevel3() {
        return channelIdLevel3;
    }

    public void setChannelIdLevel3(Integer channelIdLevel3) {
        this.channelIdLevel3 = channelIdLevel3;
    }

    public String getOpenSources() {
        return openSources;
    }

    public void setOpenSources(String openSources) {
        this.openSources = openSources;
    }

    public BigDecimal getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(BigDecimal orderMoney) {
        this.orderMoney = orderMoney;
    }

    public Date getHandleDate() {
        return handleDate;
    }

    public void setHandleDate(Date handleDate) {
        this.handleDate = handleDate;
    }

    public Date getCompleteDate() {
        return completeDate;
    }

    public void setCompleteDate(Date completeDate) {
        this.completeDate = completeDate;
    }

    public Integer getOpenMealId() {
        return openMealId;
    }

    public void setOpenMealId(Integer openMealId) {
        this.openMealId = openMealId;
    }

    public String getOpenMealCode() {
        return openMealCode;
    }

    public void setOpenMealCode(String openMealCode) {
        this.openMealCode = openMealCode;
    }

    public String getAduitStatus() {
        return aduitStatus;
    }

    public void setAduitStatus(String aduitStatus) {
        this.aduitStatus = aduitStatus;
    }

    @Override
    public String toString() {
        return "Identity [code=" + code + ", contactPhone=" + contactPhone + ", name=" + name + ", phone=" + phone
                + ", phoneId=" + phoneId + ", status=" + status + ", money=" + money + ", openDate=" + openDate
                + ", meals=" + meals + ", channelId=" + channelId + ", openSources=" + openSources + ", orderMoney="
                + orderMoney + ", handleDate=" + handleDate + ", completeDate=" + completeDate + ", openMealId="
                + openMealId + ", openMealCode=" + openMealCode + ", aduitStatus=" + aduitStatus + "]";
    }


}
