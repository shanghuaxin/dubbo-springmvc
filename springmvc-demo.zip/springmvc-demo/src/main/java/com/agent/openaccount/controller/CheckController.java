package com.agent.openaccount.controller;

import com.agent.common.*;
import com.agent.constant.Constant;
import com.agent.openaccount.dto.CheckImgResubmitDTO;
import com.agent.openaccount.dto.CheckListDTO;
import com.agent.openaccount.entity.ApplyIdentity;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.entity.ModCustomer;
import com.agent.openaccount.service.ApplyIdentityService;
import com.agent.openaccount.service.AttachedDocumentsService;
import com.agent.openaccount.service.CheckService;
import com.agent.openaccount.service.IdcardInfoService;
import com.agent.openaccount.service.IdentityService;
import com.agent.openaccount.service.ModCustomerService;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.Utils;
import com.agent.util.images.FileUtil;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2016/11/9.
 * 审核记录
 */
@Controller
@RequestMapping(value="/check")
public class CheckController {
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    @Autowired
    private CheckService checkService;
    @Autowired
    private ModCustomerService modService;
    @Autowired
    private ApplyIdentityService applyIdentityService;
    @Autowired
    private IdentityService identityService;
    @Autowired
    private IdcardInfoService idcardInfoService;
    @Autowired
    private AttachedDocumentsService documentsService;

    private static Logger logger = LoggerFactory.getLogger(CheckController.class);

    /**
     * 审核信息列表
     * @return
     */
    @RequestMapping(value="check-list-table",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<CheckListDTO> checkListTable(DataTable<CheckListDTO> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("sourceId", request.getParameter("sourceId"));
            searchMap.put("wayType",request.getParameter("wayType"));
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return checkService.checkList(dt,searchMap);
        }catch(Exception e){
            logger.error("查看审核记录信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 进入审核不通过重新提交照片页面
     * @return
     */
    @RequiresPermissions("resubmit")
    @RequestMapping(value = "resubmit", method = RequestMethod.GET)
    public String resubmit(Model model, HttpSession session,Integer sourceId, String sourceName, String wayType) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        IdcardInfo cardInfo = null;//身份证信息
        AttachedDocuments cardHeadImg = null;//头像图片
        AttachedDocuments cardHandImg = null;//手持照
        AttachedDocuments cardFrontImg = null;//正面照
        AttachedDocuments cardRearImg = null;//反面照
        String contactPhone = "";//联系电话
        String phone = "";//联系电话
        try{
            if(StringUtils.isBlank(sourceName)){
                sourceName = "t_mod_customer";
            }
            //过户重新提交
            if("3".equals(wayType)){
                ModCustomer mod = modService.findById(sourceId);
                contactPhone = mod.getContactPhone();
                phone = mod.getPhone();
                cardInfo = idcardInfoService.findByIdNumber(mod.getCode());
            }else if("2".equals(wayType)) {  //开户重新提交资料
                if(StringUtils.equals(sourceName, "t_apply_identity")) {
                    ApplyIdentity applyIdentity = applyIdentityService.findById(sourceId);
                    contactPhone = applyIdentity.getContactPhone();
                    phone = applyIdentity.getPhone();
                    cardInfo = JSONUtil.jsonToObject(applyIdentity.getIdcardinfo(), IdcardInfo.class);
                    //cardInfo = idcardInfoService.findByIdNumber(applyIdentity.getCode());
                    if(cardInfo == null) {
                        cardInfo = new IdcardInfo();
                        cardInfo.setIdNumber(applyIdentity.getCode());
                        cardInfo.setName(applyIdentity.getName());
                    }
                }else {
                    Identity identity = identityService.findById(sourceId);
                    contactPhone = identity.getContactPhone();
                    phone = identity.getPhone();
                    cardInfo = idcardInfoService.findByIdNumber(identity.getCode());
                    if(cardInfo == null) {
                        cardInfo = new IdcardInfo();
                        cardInfo.setIdNumber(identity.getCode());
                        cardInfo.setName(identity.getName());
                    }
                }
                int period = 0;
                if(StringUtils.isNotBlank(cardInfo.getExpiryDate())) {
                    String []ds = cardInfo.getExpiryDate().split("-");
                    model.addAttribute("Startdate1", ds[0].replaceAll("-", "."));
                    if (ds.length > 1) {
                        model.addAttribute("Enddate1", ds[1]);
                        if("长期".equals(ds[1])) {
                            period = 1;
                        }
                    }
                    model.addAttribute("period", period);
                }
            }

            List<AttachedDocuments> attr = documentsService.findBySourceIdAndSourceName(sourceId, sourceName);
            if(null != attr && attr.size() >0){
                try{
                    for(AttachedDocuments s : attr){
//                        s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                        if(s.getSourceType().equals("cardHeadImg")){
                            cardHeadImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHeadImg, s);
                            model.addAttribute("openWay", 1);
                        }else if(s.getSourceType().equals("cardHand")){
                            cardHandImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHandImg, s);
                        }else if(s.getSourceType().equals("cardFront")){
                            cardFrontImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardFrontImg, s);
                        }else if(s.getSourceType().equals("cardRear")){
                            cardRearImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardRearImg, s);
                        }
                    }
                }catch (Exception e){
                    logger.error("头像图片获取失败");
                }
            }
        }catch(Exception e){
            e.printStackTrace();
            logger.error("查询审核信息失败，原因：" + e.getMessage(), e);
        }
        model.addAttribute("phone", phone);
        model.addAttribute("contactPhone", contactPhone);
        model.addAttribute("idcardInfo", cardInfo);
        model.addAttribute("cardHeadImg", cardHeadImg);
        model.addAttribute("cardHandImg", cardHandImg);
        model.addAttribute("cardFrontImg", cardFrontImg);
        model.addAttribute("cardRearImg", cardRearImg);
        model.addAttribute("sourceId",sourceId);
        model.addAttribute("sourceName",sourceName);
        model.addAttribute("wayType",wayType);
        model.addAttribute("resourceIP", resourceIP);
        model.addAttribute("curDate", DateUtil.getInstance().formatDate(new Date(), "yyyy.MM.dd"));
        
        return "/views/check/resubmit.jsp";
    }

    /**
     * 审核不通过重新提交照片
     * @return
     */
    @RequestMapping(value="resubmit",method=RequestMethod.POST)
    @ResponseBody
    public RestStatus resubmit(CheckImgResubmitDTO dto,HttpServletRequest request){
        try{
            if(Utils.isEmptyString(dto.getSourceId()) || Utils.isEmptyString(dto.getWayType()) || Utils.isEmptyString(dto.getCardFrontUploadFile()) || Utils.isEmptyString(dto.getCardFrontUploadFilePath())
                    || Utils.isEmptyString(dto.getCardRearUploadFile()) || Utils.isEmptyString(dto.getCardRearUploadFilePath()) || Utils.isEmptyString(dto.getCardHandUploadFile()) || Utils.isEmptyString(dto.getCardHandUploadFilePath())){
                return new RestStatus(Boolean.FALSE,"500","重新提交失败，信息不完整！");
            }
            
            String resubmit = DicUtil.getMapDictionary("BUG").get("RESUBMITFAIL");
            if("true".equals(resubmit)){
                if(Utils.isEmptyString(dto.getName()) || Utils.isEmptyString(dto.getIdNumber()) || Utils.isEmptyString(dto.getOrgans()) ||
                        Utils.isEmptyString(dto.getNation()) || Utils.isEmptyString(dto.getExpiryDate()) || Utils.isEmptyString(dto.getAddress())){
                    
                    return new RestStatus(Boolean.FALSE,"500","重新提交失败，身份信息不完整！");
                }
            }
            
            File localFileA=new File(imageURL + File.separator + dto.getCardHandUploadFilePath());
            if(!localFileA.exists()){//表示重新上传
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardHandUploadFilePath(), imageURL + dto.getCardHandUploadFilePath());
                } catch (Exception e) {
                    new RestStatus(Boolean.FALSE,"500","您的身份证手持照没有上传成功，请重新上传");
                }
            }
            localFileA=new File(imageURL + File.separator + dto.getCardFrontUploadFilePath());
            if(!localFileA.exists()){//表示重新上传
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardFrontUploadFilePath(), imageURL + dto.getCardFrontUploadFilePath());
                } catch (Exception e) {
                    new RestStatus(Boolean.FALSE,"500","您的身份证正面照没有上传成功，请重新上传");
                }
            }
            localFileA=new File(imageURL + File.separator + dto.getCardRearUploadFilePath());
            if(!localFileA.exists()){//表示重新上传
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardRearUploadFilePath(), imageURL + dto.getCardRearUploadFilePath());
                } catch (Exception e) {
                    new RestStatus(Boolean.FALSE,"500","您的身份证背面照没有上传成功，请重新上传");
                }
            }
            
            return checkService.resubmit(dto, SessionData.getInstance().getUser(request));
        }catch(Exception e){
            logger.error("重新提交失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE,"500","重新提交失败，请重新提交！");
        }
    }
}
