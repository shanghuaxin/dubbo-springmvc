package com.agent.openaccount.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * 开户申请表
 */
public class ApplyIdentity extends BaseDomain {

    private static final long serialVersionUID = 7455824579941074455L;
    private String code;           //身份证号码
    private String contactPhone;   //联系电话
    private String name;           //姓名
    private String phone;          //号码
    private Integer phoneId;       //号码表ID
    private String status;         //状态:0-未导出，1-已导出
    private BigDecimal money;      //开户金额
    private Date openDate;         //开户时间
    private String meals;          //开户增值业务
    private Integer channelId;     //渠道表ID
    private String custOrderId;         //联通保存订单、预算费用返回的订单ID
    private String openSources;    //开户来源：PC（电脑），APP（手机）
    private BigDecimal orderMoney; //实际订单金额（套餐+增值业务）单位：分
    private Date handleDate;       //报峻处理时间
    private String mealNames;      //增值业务名称
    private Date completeDate;     //移动报峻时间
    private Integer openMealId;    //开户套餐id
    private String openMealCode;   //开户套餐编号
    private String openMeals;      //增值业务编号集合逗号隔开
    private String checkStatus;    //审核状态（1待审核，2审核通过，3审核不通过）
    private String idcardinfo;    //申请身份证信息

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public String getMeals() {
        return meals;
    }

    public void setMeals(String meals) {
        this.meals = meals;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getCustOrderId() {
        return custOrderId;
    }

    public void setCustOrderId(String custOrderId) {
        this.custOrderId = custOrderId;
    }

    public String getOpenSources() {
        return openSources;
    }

    public void setOpenSources(String openSources) {
        this.openSources = openSources;
    }

    public BigDecimal getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(BigDecimal orderMoney) {
        this.orderMoney = orderMoney;
    }

    public Date getHandleDate() {
        return handleDate;
    }

    public void setHandleDate(Date handleDate) {
        this.handleDate = handleDate;
    }

    public String getMealNames() {
        return mealNames;
    }

    public void setMealNames(String mealNames) {
        this.mealNames = mealNames;
    }

    public Date getCompleteDate() {
        return completeDate;
    }

    public void setCompleteDate(Date completeDate) {
        this.completeDate = completeDate;
    }

    public Integer getOpenMealId() {
        return openMealId;
    }

    public void setOpenMealId(Integer openMealId) {
        this.openMealId = openMealId;
    }

    public String getOpenMealCode() {
        return openMealCode;
    }

    public void setOpenMealCode(String openMealCode) {
        this.openMealCode = openMealCode;
    }

    public String getOpenMeals() {
        return openMeals;
    }

    public void setOpenMeals(String openMeals) {
        this.openMeals = openMeals;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public String getIdcardinfo() {
        return idcardinfo;
    }

    public void setIdcardinfo(String idcardinfo) {
        this.idcardinfo = idcardinfo;
    }

    @Override
    public String toString() {
        return "ApplyIdentity [code=" + code + ", contactPhone=" + contactPhone + ", name=" + name + ", phone=" + phone
                + ", phoneId=" + phoneId + ", status=" + status + ", money=" + money + ", openDate=" + openDate
                + ", meals=" + meals + ", channelId=" + channelId + ", openSources=" + openSources + ", orderMoney="
                + orderMoney + ", handleDate=" + handleDate + ", mealNames=" + mealNames + ", completeDate="
                + completeDate + ", openMealId=" + openMealId + ", openMealCode=" + openMealCode + ", openMeals="
                + openMeals + ", checkStatus=" + checkStatus + "]";
    }
    

}
