package com.agent.openaccount.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.Account;

public interface AccountMapper extends BaseMapper<Account, Integer> {
    
    public List<Account> findphoneIsOpen(@Param(value="phone") String phone);

}
