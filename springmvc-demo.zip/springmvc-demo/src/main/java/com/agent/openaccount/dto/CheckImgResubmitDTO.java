package com.agent.openaccount.dto;

import com.agent.openaccount.entity.AttachedDocuments;

import java.util.List;

/**
 * 审核不通过重新提交照片
 */
public class CheckImgResubmitDTO {
    private Integer sourceId;      //来源id
    private String sourceName;     //来源表名称
    private String wayType;        //来源类型：0.网点   2.开卡  3.号码过户
    private String name;       //身份证名
    private String idNumber;       //身份证号码
    private String organs;         //签发机关
    private String nation;         //民族
    private String expiryDate;     //身份证有效期
    private String address;        //身份证地址
    private String sexual;        //身份证地址
    private String cardHandUploadFile;//手持照名称
    private String cardHandUploadFilePath;//手持照路径
    private String cardFrontUploadFile;//正面照名称
    private String cardFrontUploadFilePath;//正面照路径
    private String cardRearUploadFile;//反面照名称
    private String cardRearUploadFilePath;//反面照路径
    private List<AttachedDocuments> atts;//过户附件

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getWayType() {
        return wayType;
    }

    public void setWayType(String wayType) {
        this.wayType = wayType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getOrgans() {
        return organs;
    }

    public void setOrgans(String organs) {
        this.organs = organs;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCardHandUploadFile() {
        return cardHandUploadFile;
    }

    public void setCardHandUploadFile(String cardHandUploadFile) {
        this.cardHandUploadFile = cardHandUploadFile;
    }

    public String getCardHandUploadFilePath() {
        return cardHandUploadFilePath;
    }

    public void setCardHandUploadFilePath(String cardHandUploadFilePath) {
        this.cardHandUploadFilePath = cardHandUploadFilePath;
    }

    public String getCardFrontUploadFile() {
        return cardFrontUploadFile;
    }

    public void setCardFrontUploadFile(String cardFrontUploadFile) {
        this.cardFrontUploadFile = cardFrontUploadFile;
    }

    public String getCardFrontUploadFilePath() {
        return cardFrontUploadFilePath;
    }

    public void setCardFrontUploadFilePath(String cardFrontUploadFilePath) {
        this.cardFrontUploadFilePath = cardFrontUploadFilePath;
    }

    public String getCardRearUploadFile() {
        return cardRearUploadFile;
    }

    public void setCardRearUploadFile(String cardRearUploadFile) {
        this.cardRearUploadFile = cardRearUploadFile;
    }

    public String getCardRearUploadFilePath() {
        return cardRearUploadFilePath;
    }

    public void setCardRearUploadFilePath(String cardRearUploadFilePath) {
        this.cardRearUploadFilePath = cardRearUploadFilePath;
    }

    public List<AttachedDocuments> getAtts() {
        return atts;
    }

    public void setAtts(List<AttachedDocuments> atts) {
        this.atts = atts;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getSexual() {
        return sexual;
    }

    public void setSexual(String sexual) {
        this.sexual = sexual;
    }

    @Override
    public String toString() {
        return "CheckImgResubmitDTO [sourceId=" + sourceId + ", sourceName=" + sourceName + ", wayType=" + wayType
                + ", cardHandUploadFile=" + cardHandUploadFile + ", cardHandUploadFilePath=" + cardHandUploadFilePath
                + ", cardFrontUploadFile=" + cardFrontUploadFile + ", cardFrontUploadFilePath="
                + cardFrontUploadFilePath + ", cardRearUploadFile=" + cardRearUploadFile + ", cardRearUploadFilePath="
                + cardRearUploadFilePath + ", atts=" + atts + "]";
    }
}
