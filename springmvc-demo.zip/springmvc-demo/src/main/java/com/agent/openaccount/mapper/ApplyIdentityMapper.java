package com.agent.openaccount.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.ApplyIdentity;

public interface ApplyIdentityMapper extends BaseMapper<ApplyIdentity, Integer> {
    
    public ApplyIdentity findByPhone(@Param(value="phone") String phone);
    
    public ApplyIdentity findByPhoneId(@Param(value="phoneId") Integer phoneId);
    
    public List<ApplyIdentity> applyIdentityByPhoneId(@Param("phoneId")Integer phoneId);
    
//    public ApplyIdentity applyIdentityByPhone(@Param("phone")String phone);
    //是否已被审核
    public List<ApplyIdentity> hasCheck(@Param("phoneId")Integer phoneId);
    //修改审核状态
    public int updateCheckStatus(@Param("id")Integer id, @Param("checkStatus")String checkStatus, @Param("userId")Integer userId);
    //号码取消时，删除开户申请记录
    public int deleteByPhone(@Param(value="phone") String phone);
    public int deleteByPhoneId(@Param(value="phoneId") Integer phoneId);
    //删除记录申请表
    public int batchDelByPhoneId(List<Integer> numIds);

}
