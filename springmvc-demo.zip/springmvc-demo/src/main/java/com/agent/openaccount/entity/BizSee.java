package com.agent.openaccount.entity;

import java.io.Serializable;
import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * 代理商查看号码关系表
 * @author Administrator
 *
 */
public class BizSee extends BaseDomain implements Serializable {

    private static final long serialVersionUID = -7036544427402447386L;
    private Integer channelIdLevel1;      //一级代理商id
    private Integer channelIdLevel2;      //二级代理商id
    private Integer channelIdLevel3;      //网点id
    private String phone;                 //号码
    private Integer phoneId;              //号码id
    private Date proCreateTime;              //号码创建时间

    public Integer getChannelIdLevel1() {
        return channelIdLevel1;
    }

    public void setChannelIdLevel1(Integer channelIdLevel1) {
        this.channelIdLevel1 = channelIdLevel1;
    }

    public Integer getChannelIdLevel2() {
        return channelIdLevel2;
    }

    public void setChannelIdLevel2(Integer channelIdLevel2) {
        this.channelIdLevel2 = channelIdLevel2;
    }

    public Integer getChannelIdLevel3() {
        return channelIdLevel3;
    }

    public void setChannelIdLevel3(Integer channelIdLevel3) {
        this.channelIdLevel3 = channelIdLevel3;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }
    

    public Date getProCreateTime() {
        return proCreateTime;
    }

    public void setProCreateTime(Date proCreateTime) {
        this.proCreateTime = proCreateTime;
    }

    @Override
    public String toString() {
        return "BizSee [channelIdLevel1=" + channelIdLevel1 + ", channelIdLevel2=" + channelIdLevel2
                + ", channelIdLevel3=" + channelIdLevel3 + ", phone=" + phone + ", phoneId=" + phoneId + "]";
    }

}
