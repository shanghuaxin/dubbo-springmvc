package com.agent.openaccount.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.Identity;

public interface IdentityMapper extends BaseMapper<Identity, Integer> {
    public int findIdentityNumByCode(@Param(value="code") String code);
    public int updateNameCode(Identity identity);
    public List<Identity> findIdentityByPhoneId(@Param("phoneId")Integer phoneId);
    //是否已被审核
    public List<Identity> hasCheck(@Param("phoneId")Integer phoneId);
    //号码报峻
    public int updateIdentityComplete(Identity identity);
    
    // 统计渠道下的开户量
    public int statisticsOpenCount(Map<String, Object> params);
    
    public Identity findByPhone(@Param("phone")String phone);

}
