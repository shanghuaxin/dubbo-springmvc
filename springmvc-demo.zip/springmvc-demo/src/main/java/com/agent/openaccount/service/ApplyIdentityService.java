package com.agent.openaccount.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.openaccount.entity.ApplyIdentity;
import com.agent.openaccount.mapper.ApplyIdentityMapper;

@Transactional(rollbackFor=Exception.class)
@Service("applyIdentityService")
public class ApplyIdentityService {
    
    @Autowired
    private ApplyIdentityMapper applyIdentityMapper;
    
    public ApplyIdentity findById(Integer id) {
        return applyIdentityMapper.select(id);
    }
    
    public List<ApplyIdentity> applyIdentityByPhoneId(Integer phoneId) {
        return applyIdentityMapper.applyIdentityByPhoneId(phoneId);
    }
    
    //是否已被审核
    public boolean hasCheck(Integer phoneId){
        boolean boo=false;
        List<ApplyIdentity> list = applyIdentityMapper.hasCheck(phoneId);
        if(null !=list && list.size()>0){
            boo=true;
        }
        return boo;
    }

}
