package com.agent.openaccount.dto;

import org.apache.commons.lang3.StringUtils;

import com.agent.openaccount.entity.Check;

/**
 * 审核信息列表
 */
public class CheckListDTO extends Check {
    private static final long serialVersionUID = 1991724480073289657L;
    private String userName;
    private Integer userId;      //用户ID
    private String loginName;    //用户登录名
    private String nickName;     //用户昵称
    private String channelCode;  //渠道编码
    private Integer channelType; //渠道属性，1：代理，2：网点
    private String channelName;  //渠道名称
    private String empName;      //渠道员工名称
    private Integer channelId;   //渠道员工归属渠道ID
    private String checkOpinion;   //审批意见

    public String getUserName() {
        return userName;
    }
    
    public String getOperationUserName() {
        if(channelId != null) {
            return "渠道员工：" + empName;
        }else if(channelCode != null && channelType == 1) {
            return "代理商：["+channelCode+"]" + channelName;
        }else if(channelCode != null && channelType == 2) {
            return "网点：["+channelCode+"]" + channelName;
        }
        return "总部：" + loginName;
    }
    
    public String getOperation() {
        if(StringUtils.equals(getStatusType(), "1") && StringUtils.isBlank(checkOpinion)) {
            return "开户"; 
        }else if(StringUtils.equals(getStatusType(), "1") && StringUtils.isNotBlank(checkOpinion)) {
            return "重新提交资料   " + checkOpinion;
        }else if(StringUtils.equals(getStatusType(), "3")) {
            return "审核不通过   " + checkOpinion;
        }else if(StringUtils.equals(getStatusType(), "2")) {
            return "审核通过";
        }else if(StringUtils.equals(getStatusType(), "4")) {
            return "稽核不通过   " + checkOpinion;
        }
        else if(StringUtils.equals(getStatusType(), "0")) {
            return "开户取消 ";
        }
        return getStatusType();
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getCheckOpinion() {
        return checkOpinion;
    }

    public void setCheckOpinion(String checkOpinion) {
        this.checkOpinion = checkOpinion;
    }
    
    
}
