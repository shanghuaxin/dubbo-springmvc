package com.agent.openaccount.mapper;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.PreSubsHis;

public interface PreSubsHisMapper extends BaseMapper<PreSubsHis, Integer> {

}
