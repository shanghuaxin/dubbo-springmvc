package com.agent.openaccount.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.number.dto.BuyServSaveDTO;
import com.agent.openaccount.dto.BuyServRecordListDTO;
import com.agent.openaccount.entity.BuyServiceRecord;

public interface BuyServiceRecordMapper extends BaseMapper<BuyServiceRecord, Integer> {
    public void busServRecordSave(Map<String, Object> map);
    /** 修改订购业务状态 */
    public int updateStatus(BuyServiceRecord buyServiceRecord);
    /** 查询业务订购类型 */
    public BuyServiceRecord findById(Integer id);
    //重新提交资料
    public int buyAgainSub(@Param(value="userId")Integer userId, @Param(value="list")List<Integer> list);

    public List<BuyServRecordListDTO> listDto(Map<String,Object> searchMap);
    public int listDtoCount(Map<String,Object> searchMap);

    //业务订购批量新增
    public int batchInsert(List<BuyServiceRecord> list);
    //批量新增订购推送表
    public int batchInsertPush(List<BuyServiceRecord> list);
    public List<BuyServiceRecord> listBuyPush(Map<String,Object> searchMap);
    //号码复机成功待订购业务
    public List<BuyServSaveDTO> listBuyServPush();
    //修改消息推送表状态
    public int updateBusServ(List<BuyServSaveDTO> list);
    //修改业务订购表状态
    public int updateBusRecordServ(List<BuyServSaveDTO> list);
    //修改网掌厅业务办理记录状态
    public int updateBizStatus(List<String> list);

    public int listPushCount(@Param(value="recordId")Integer recordId);
    
}
