package com.agent.openaccount.mapper;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.HisIdentity;

public interface HisIdentityMapper extends BaseMapper<HisIdentity, Integer> {

}
