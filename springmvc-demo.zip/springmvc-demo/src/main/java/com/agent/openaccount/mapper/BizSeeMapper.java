package com.agent.openaccount.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.openaccount.entity.BizSee;

public interface BizSeeMapper extends BaseMapper<BizSee, Integer> {
    
    public int deleteByPhoneId(@Param(value="phoneId") Integer phoneId);

}
