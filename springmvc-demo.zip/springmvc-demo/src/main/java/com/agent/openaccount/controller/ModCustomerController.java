package com.agent.openaccount.controller;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.QueryUser;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;

import com.agent.business.entity.MobileArea;
import com.agent.business.service.MobileAreaService;
import com.agent.channel.entity.ChannelAuth;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAuthService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.DataTable;
import com.agent.common.DetailDTO;
import com.agent.common.RestStatus;
import com.agent.common.SessionData;
import com.agent.common.enumeration.PhoneStatus;
import com.agent.common.service.LoginCodeService;
import com.agent.constant.Constant;
import com.agent.cs.dto.CsUserListDTO;
import com.agent.cs.dto.ReqCommonDTO;
import com.agent.cs.service.CsUserService;
import com.agent.exception.SeeComException;
import com.agent.number.entity.TNumber;
import com.agent.number.service.NumberService;
import com.agent.openaccount.dto.ModCustomerDTO;
import com.agent.openaccount.dto.ModCustomerListDTO;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.Check;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.entity.ModCustomer;
import com.agent.openaccount.service.AttachedDocumentsService;
import com.agent.openaccount.service.IdcardInfoService;
import com.agent.openaccount.service.IdentityService;
import com.agent.openaccount.service.ModCustomerService;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.MD5;
import com.agent.util.SysConfig;
import com.agent.util.Utils;
import com.agent.util.images.FileUtil;

/**
 * Created by Administrator on 2016/11/9.
 * 号码过户
 */
@Controller
@RequestMapping(value="/mod-customer")
public class ModCustomerController {
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    @Autowired
    private LoginCodeService smsCodeService;
    @Resource
    private NumberService numService;
    @Autowired
    private ChannelAuthService channelAuthService;
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private IdentityService identityService;
    @Autowired
    private ModCustomerService modService;
    @Autowired
    private BOSSNewBuyService buyNewService;
    @Autowired
    private IdcardInfoService idcardInfoService;
    @Autowired
    private AttachedDocumentsService documentsService;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    @Autowired
    private MobileAreaService mobileAreaService;
    @Autowired
    private CsUserService csUserService;

    private static Logger logger = LoggerFactory.getLogger(ModCustomerController.class);


    /**
     * 进入号码过户也
     * @return
     */
    @RequiresPermissions("mod")
    @RequestMapping(value = "mod", method = RequestMethod.GET)
    public String customer(Model model, HttpSession session) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        //以下是获取当前渠道信息
        Channels channels = channelsService.findChannelByUserId(user.getId());
        ChannelAuth channelAuth = channelAuthService.findByChannelId(channels.getId());
        model.addAttribute("channels", channels);
        model.addAttribute("channelAuth", channelAuth);
        model.addAttribute("curDate", DateUtil.getInstance().formatDate(new Date(), "yyyy.MM.dd"));
        model.addAttribute("resourceIP", resourceIP);
        return "/views/modCustomer/modCustomer.jsp";
    }


    /**
     * 是否靓号
     * @param phone
     * @return
     */
    @RequestMapping(value = "phone-is-good", method = RequestMethod.POST)
    @ResponseBody
    public DetailDTO<Boolean> phoneDetail(String phone){
        DetailDTO<Boolean> detailDTO = null;
        try{
            TNumber ndto = numService.findByPhone(phone);
            if(null == ndto){
                return new DetailDTO<Boolean>(Boolean.FALSE, "500", "号码不存在，请重新输入！");
            }else if(!TNumber.STATUS_FINISH_ACTIVATE.equals(ndto.getStatus())){
                return new DetailDTO<Boolean>(Boolean.FALSE, "500", "号码未开户不能进行过户！");
            }
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("phone",phone);
            searchMap.put("status","1");//带审核过户
            int count = modService.modListCount(searchMap);
            if(count > 0){
                return new DetailDTO<Boolean>(Boolean.FALSE, "500", "该号码已经存在过户待审核信息，不能重复提交！");
            }
            //测试中
            if(!"8".equals(ndto.getLevel()) && !"10".equals(ndto.getLevel())){ //非普通和差号 是靓号
                return new DetailDTO<Boolean>(Boolean.TRUE, true);
            }else{
                return new DetailDTO<Boolean>(Boolean.TRUE, false);
            }
        }catch (Exception e){
            e.printStackTrace();
            logger.error("过户查询号码信息失败，原因："+e.getMessage(),e);
            detailDTO = new DetailDTO<Boolean>(Boolean.FALSE, "500", "后台异常，稍后重试！");
        }
        return detailDTO;
    }

    /***
     * 获取短信验证码
     * @param request
     * @param phone
     * @param source
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "sms-code", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> smsCode(HttpServletRequest request, String phone, String source) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        if (Utils.isEmptyString(phone)) {
            map.put("status", false);
            map.put("msg", "请输入过户手机号码！");
            return map;
        }
        try{
            User us = SessionData.getInstance().getUser(request);
            map = smsCodeService.smsCode(us,phone,source);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("过户获取验证码失败，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "获取验证码失败！");
            return map;
        }
        map.put("status", true);
        return map;
    }


    /***
     * 验证短信码，获取用户信息
     * @param request
     * @param phone
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "user-info", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> userInfo(HttpServletRequest request, String phone, String servPwd,String securityCode,String certNbr, HttpSession session) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        if (Utils.isEmptyString(phone)) {
            map.put("status", false);
            map.put("msg", "请输入号码！");
            return map;
        }
        if (Utils.isEmptyString(servPwd)) {
            map.put("status", false);
            map.put("msg", "请输入服务密码！");
            return map;
        }
        if (Utils.isEmptyString(certNbr)) {
            map.put("status", false);
            map.put("msg", "请输入用户身份证号码！");
            return map;
        }
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(1 != channels.getStatus().intValue() && 3 != channels.getStatus().intValue()){
                map.put("status", false);
                map.put("msg", "对不起，您的渠道状态不正常，不能进行过户！");
                return map;
            }
            TNumber ndto = numService.findByPhone(phone);
            if(null == ndto){
                map.put("status", false);
                map.put("msg", "号码在系统不存在！");
                return map;
            }
            map.put("operatorCode", ndto.getOperatorCodeStr());
            if(!"8".equals(ndto.getLevel()) && !"10".equals(ndto.getLevel())){ //非普通和差号 是靓号
                if (Utils.isEmptyString(securityCode)) {
                    map.put("status", false);
                    map.put("msg", "请输入短信验证码！");
                    return map;
                }
                String isSmsCode = SysConfig.getValue("isSmsCode");
                if("true".equals(isSmsCode)){
                    String time = DicUtil.getMapDictionary("CODE_VALID_TIME").get("VALID_TIME");
                    Date d = DateUtil.getInstance().minusDateSecond(Integer.parseInt(time));
                    String code = smsCodeService.getMmsCode(phone,d);
                    if(Utils.isEmptyString(code)){
                        map.put("status", false);
                        map.put("msg", "您的验证码已过期，请重新获取！");
                        return map;
                    }
                    logger.info("正确的验证码--->" + code);
                    if (!securityCode.equals(code)) {
                        map.put("status", false);
                        map.put("msg", "验证码不正确");
                        return map;
                    }
                }
            }
            if(ndto.getOperatorCode().intValue() == 1) {   //移动
                TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
                bo.setMSISDN("86"+phone);
                bo.setUserPwd(MD5.GetMD5Code(servPwd));  //测试中
                RestStatus rs = buyNewService.QueryUserProfileBOSS(bo,user);
                if(rs.getStatus()){
                    TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
                    if(Integer.valueOf(res.getBal()) < 0){
                        map.put("status", false);
                        map.put("msg", "号码："+phone+"，已欠费，不能进行过户");
                        return map;
                    }else if(!"A".equals(res.getState()) && !"E".equals(res.getState())){
                        map.put("status", false);
                        map.put("msg", "号码："+phone+" 状态为："+DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()) + "，不能进行过户");
                        return map;
                    }
                    if(!certNbr.equals(res.getCertNbr())){
                        map.put("status", false);
                        map.put("msg", "用户身份证号输入错误！");
                        return map;
                    }
                    
                    map.put("qPhone",phone);
                    map.put("qStatus",DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()));
                    map.put("qName",res.getCustName().substring(0, 0) + "*" + res.getCustName().substring(1, res.getCustName().length()));
                    map.put("certNbr",res.getCertNbr().substring(0, 8)+"*****"+res.getCertNbr().substring(12, 18));
                    BigDecimal userBal = new BigDecimal(res.getBal());
                    map.put("bal",Constant.df0.format(userBal.divide(Constant.cnt100)));
                }else{
                    map.put("status", false);
                    map.put("msg", rs.getErrorMessage());
                    return map;
                }
            }else if(ndto.getOperatorCode().intValue() == 2) { //联通
                try {
                    RestStatus rsStatus = bossUnicomService.userValidation(ndto.getPhone(), MD5.GetMD5Code(servPwd), user);
                    if(!rsStatus.getStatus()){
                        logger.error("过户调用接口错误：phone=" + ndto.getPhone() + "，原因："+rsStatus.getErrorMessage());
                        throw new Exception(rsStatus.getErrorMessage());
                    } else {
                        QueryUser svcCont = new QueryUser();
                        svcCont.setQueryType("0");//0用户号码，1客户编号
                        svcCont.setQueryValue(phone);
                        svcCont.setCityCode("360");
                        svcCont.setProductId("-1");
                        rsStatus = bossUnicomService.queryUserService(svcCont, user);
                        String bal = "0", name = "";
                        if(!rsStatus.getStatus()){
                            logger.error("过户调用接口错误：phone=" + ndto.getPhone() + "，原因："+rsStatus.getErrorMessage());
                            throw new Exception(rsStatus.getErrorMessage());
                        } else {
                            ContractRoot root = (ContractRoot)rsStatus.getResponseData();
                            bal = root.getSvcCont().getUserInfoView().getUserInfo().getAvailableBalance();
                            name = root.getSvcCont().getUserInfoView().getCustInfo().getCustName();
                        }
                        TNumber number = numService.findByPhone(ndto.getPhone());
                        map.put("qPhone",phone);
                        map.put("qStatus", PhoneStatus.getName(number.getStatus()));
                        map.put("qName", name);
                        map.put("certNbr", "");
                        BigDecimal userBal = new BigDecimal(bal);
                        map.put("bal",Constant.df0.format(userBal.divide(Constant.cnt100)));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    map.put("status", false);
                    map.put("msg", e.getMessage());
                    return map;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            logger.error("校验号码信息失败，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "校验号码信息失败，请重新提交！");
            return map;
        }
        map.put("status", true);
        return map;
    }

    /***
     * 提交号码过户申请
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "mod", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> modSumit(ModCustomerDTO dto,HttpServletRequest request, HttpSession session) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(null == user){
                map.put("status", false);
                map.put("msg", "您的登录已超时，请重新登录！");
                return map;
            }
            Channels channels = channelsService.findChannelByUserId(user.getId());

            Map<String, Object> checkMap = modService.modSumitCheck(dto,user,"mod",null); //校验传入数据
            if("false" == checkMap.get("status").toString()){
                return checkMap;
            }
            List<AttachedDocuments> atts = new ArrayList<AttachedDocuments>();
            AttachedDocuments att = new AttachedDocuments();
            //手持身份证照片
            att.setAttachmentName(dto.getCardHandUploadFile());
            att.setAttachmentUrl(dto.getCardHandUploadFilePath());
            att.setSourceName("t_mod_customer");
            att.setSourceType("cardHand");
            atts.add(att);
            //身份证正面照
            att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardFrontUploadFile());
            att.setAttachmentUrl(dto.getCardFrontUploadFilePath());
            att.setSourceName("t_mod_customer");
            att.setSourceType("cardFront");
            atts.add(att);
            //身份证背面照
            att = new AttachedDocuments();
            att.setAttachmentName(dto.getCardRearUploadFile());
            att.setAttachmentUrl(dto.getCardRearUploadFilePath());
            att.setSourceName("t_mod_customer");
            att.setSourceType("cardRear");
            atts.add(att);

            //头像
            if(!Utils.isEmptyString(dto.getImgStr())){
                Map<String,Object> imgMap =  FileUtil.getInstance().imgStr(dto.getPhone(),dto.getImgStr(),"4",channels.getChannelCode(),imageURL,"PC");
                if(!"true".equals(imgMap.get("status").toString())){
                    return imgMap;
                }
                att = new AttachedDocuments();
                att.setAttachmentName(imgMap.get("attachmentName").toString());
                att.setAttachmentUrl(imgMap.get("attachmentUrl").toString());
                att.setSourceName("t_mod_customer");
                att.setSourceType("cardHeadImg");
                atts.add(att);
            }
            
            File localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + dto.getCardHandUploadFilePath());
            if(!localFileA.exists()){
                map.put("status", false);
                map.put("msg", "您的身份证手持照没有上传成功，请重新上传");
                return map;
            } else {
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardHandUploadFilePath(), imageURL + dto.getCardHandUploadFilePath());
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "您的身份证手持照没有上传成功，请重新上传！");
                    return map;
                }
            }
            localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + dto.getCardFrontUploadFilePath());
            if(!localFileA.exists()){
                map.put("status", false);
                map.put("msg", "您的身份证正面照没有上传成功，请重新上传");
                return map;
            } else {
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardFrontUploadFilePath(), imageURL + dto.getCardFrontUploadFilePath());
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "您的身份证正面照没有上传成功，请重新上传！");
                    return map;
                }
            }
            localFileA=new File(imageURL + File.separator + FileUtil.imgPathTmp + dto.getCardRearUploadFilePath());
            if(!localFileA.exists()){
                map.put("status", false);
                map.put("msg", "您的身份证背面照没有上传成功，请重新上传！");
                return map;
            } else {
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardRearUploadFilePath(), imageURL + dto.getCardRearUploadFilePath());
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "您的身份证背面照没有上传成功，请重新上传！");
                    return map;
                }
            }

            dto.setAtts(atts);
            modService.modCustomer(dto,SessionData.getInstance().getUser(request));
        } catch (SeeComException e) {
            e.printStackTrace();
            logger.error("号码过户申请失败号码="+dto.getPhone()+"，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", e.getMessage());
            return map;
        }catch (Exception e) {
            e.printStackTrace();
            logger.error("号码过户申请失败号码="+dto.getPhone()+"，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "号码"+dto.getPhone()+"过户失败！");
            return map;
        }
        map.put("status", true);
        return map;
    }

    /**
     * 进入号码过户列表页面
     * @return
     */
    @RequiresPermissions("mod-list")
    @RequestMapping(value = "mod-list", method = RequestMethod.GET)
    public String modList(Model model, HttpSession session, HttpServletRequest request) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        //以下是获取当前渠道信息
        Channels channels = channelsService.findChannelByUserId(user.getId());
        String type = Utils.isEmptyString(request.getParameter("type")) ? "" : request.getParameter("type");
        if("buy".equals(type)){
            model.addAttribute("channelType", 1);
        }else{
            model.addAttribute("channelType", 0);
        }

        if(null != channels && Channels.CHANNEL_TYPE_2.intValue() == channels.getChannelType().intValue()){
            model.addAttribute("isWD", 1);
        }else{
            model.addAttribute("isWD", 0);
        }
        if(null != channels && channels.getChannelLevel().intValue() == Channels.CHANNEL_LEVEL_1.intValue()){
            model.addAttribute("channelLevel", 1);
        }else{
            model.addAttribute("channelLevel", 0);
        }
        model.addAttribute("channels", channels);
        model.addAttribute("phoneLevel", DicUtil.getDictionary("PHONE_LEVEL_CODE"));
        return "/views/modCustomer/modCustomerList.jsp";
    }

    /**
     * 查询号码过户列表
     * @return
     */
    @RequestMapping(value="mod-list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<ModCustomerListDTO> modList(DataTable<ModCustomerListDTO> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = new HashMap<>();
            searchMap.put("phoneLike", request.getParameter("phoneLike"));
            searchMap.put("level",request.getParameter("level"));
            searchMap.put("status",request.getParameter("status"));
            searchMap.put("channelName",request.getParameter("channelName"));
            searchMap.put("startdate",request.getParameter("startdate"));
            searchMap.put("enddate",request.getParameter("enddate"));
            searchMap.put("operatorCode",request.getParameter("operatorCode"));
            searchMap.put("modSources",request.getParameter("modSources"));
            searchMap.put("operatorCode",request.getParameter("operatorCode"));
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            searchMap.put("order","ASC");
            if(null != channels && Channels.CHANNEL_TYPE_2.intValue() == channels.getChannelType().intValue()){
                searchMap.put("channelId",channels.getId());
                searchMap.put("order","DESC");
                searchMap.put("createId",user.getId());
            }else if(null != channels && Channels.CHANNEL_LEVEL_1.intValue() == channels.getChannelLevel().intValue()){
                searchMap.put("channelId1",channels.getId());
            }
            
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return modService.modList(dt,searchMap);
        }catch(Exception e){
            logger.error("查看号码过户信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 过户审核页面和查看详情页面
     * @return
     */
    @RequiresPermissions("mod_check")
    @RequestMapping(value = "mod_check", method = RequestMethod.GET)
    public String modCheck(Model model, HttpSession session,HttpServletRequest request) {
        try{
            Integer modId = Integer.valueOf(request.getParameter("modId"));
            String viewType = String.valueOf(request.getParameter("viewType"));
            ModCustomer mod = modService.findById(modId);
            IdcardInfo cardInfo = null;
            String idcardinfo = mod.getIdcardinfo();
            if(idcardinfo!=null && !"".equals(idcardinfo)){
                cardInfo = JSONUtil.jsonToObject(idcardinfo, IdcardInfo.class);
            } else {
                cardInfo = idcardInfoService.findByIdNumber(mod.getCode());
            }
            List<AttachedDocuments> attr = documentsService.findBySourceIdAndSourceName(mod.getId(), "t_mod_customer");
            AttachedDocuments cardHeadImg = null;
            List<AttachedDocuments> attachedDocuments = null;
            if(null != attr && attr.size() >0){
                attachedDocuments = new ArrayList<AttachedDocuments>();
                for(AttachedDocuments s : attr){
                    s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                    if(s.getSourceType().equals("cardHeadImg")){
                        try{
                            cardHeadImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHeadImg, s);
                        }catch (Exception e){
                            logger.error("头像图片获取失败");
                        }
                    }else{
                        attachedDocuments.add(s);
                    }
                }
            }

            model.addAttribute("viewType", viewType);
            model.addAttribute("modCustomer", mod);
            model.addAttribute("idcardInfo", cardInfo);
            model.addAttribute("cardHeadImg", cardHeadImg);
            model.addAttribute("attachedDocuments", attachedDocuments);
        }catch (Exception e){
            logger.error("过户审核页面失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return "/views/modCustomer/modCheck.jsp";
    }

    /**
     * 过户审核
     * @return
     */
    @RequestMapping(value="mod-check",method=RequestMethod.POST)
    @ResponseBody
    public RestStatus modCheck(Check c,HttpServletRequest request){
        try{
            if(Utils.isEmptyString(c.getSourceId()) || Utils.isEmptyString(c.getStatusType())){
                return new RestStatus(Boolean.FALSE,"500","审核失败，信息不完整！");
            }
            return modService.modCheck(c,SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            logger.error("号码过户审核，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE,"500",e.getMessage());
        }catch(Exception e){
            logger.error("号码过户审核，原因："+e.getMessage(),e);
            e.printStackTrace();
            if(e.getMessage().indexOf("接口") > -1){
                return new RestStatus(Boolean.FALSE,"500",e.getMessage());
            }else{
                return new RestStatus(Boolean.FALSE,"500","审核失败，请重新提交！");
            }
        }
    }
    
    /**
     * 进入号码资料修改页面
     * @return
     */
    @RequestMapping(value = "mod-user-info", method = RequestMethod.GET)
    public String modUserInfo(Model model, HttpSession session, HttpServletRequest request) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        String reqPhone = Utils.isEmptyString(request.getParameter("reqPhone")) ? "" : request.getParameter("reqPhone");
        model.addAttribute("reqPhone", reqPhone);
        
        //以下是获取当前渠道信息
        Channels channels = channelsService.findChannelByUserId(user.getId());
        model.addAttribute("channels", channels);
        model.addAttribute("curDate", DateUtil.getInstance().formatDate(new Date(), "yyyy.MM.dd"));
        model.addAttribute("resourceIP", resourceIP);
        return "/views/modCustomer/modUserInfo.jsp";
    }
    
    /***
     * 提交号码资料修改
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "mod-user-info", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> modUserInfo(ModCustomerDTO dto,HttpServletRequest request, HttpSession session,DataTable<CsUserListDTO> dt) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            dto.setHisCode(dto.getCode());
            dto.setHisName(dto.getName());
            Map<String, Object> checkMap = modService.modSumitCheck(dto,user,"update",dt); //校验传入数据
            if("false" == checkMap.get("status").toString()){
                return checkMap;
            }
            
            File localFileA=new File(imageURL + File.separator + dto.getCardHandUploadFilePath());
            if(!localFileA.exists()){//表示重新上传
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardHandUploadFilePath(), imageURL + dto.getCardHandUploadFilePath());
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "您的身份证手持照没有上传成功，请重新上传");
                    return map;
                }
            }
            localFileA=new File(imageURL + File.separator + dto.getCardFrontUploadFilePath());
            if(!localFileA.exists()){//表示重新上传
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardFrontUploadFilePath(), imageURL + dto.getCardFrontUploadFilePath());
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "您的身份证正面照没有上传成功，请重新上传");
                    return map;
                }
            }
            localFileA=new File(imageURL + File.separator + dto.getCardRearUploadFilePath());
            if(!localFileA.exists()){//表示重新上传
                try {
                    // 将临时文件上传到正式目录下
                    FileUtil.copyFile(imageURL + File.separator + FileUtil.imgPathTmp + File.separator + dto.getCardRearUploadFilePath(), imageURL + dto.getCardRearUploadFilePath());
                } catch (Exception e) {
                    map.put("status", false);
                    map.put("msg", "您的身份证背面照没有上传成功，请重新上传");
                    return map;
                }
            }
            
            RestStatus rs = modService.modUserInfo(dto,SessionData.getInstance().getUser(request));
            if(!rs.getStatus()){
                map.put("status", false);
                map.put("msg", rs.getErrorMessage());
                return map;
            }
        } catch (SeeComException e) {
            e.printStackTrace();
            logger.error("号码资料修改失败,号码="+dto.getPhone()+"：原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", e.getMessage());
            return map;
        }catch (Exception e) {
            e.printStackTrace();
            logger.error("号码资料修改失败,号码="+dto.getPhone()+"：原因："+e.getMessage(),e);
            map.put("status", false);
            if(e.getMessage().indexOf("接口") > -1){
                map.put("msg", e.getMessage());
            }else{
                map.put("msg", "号码"+dto.getPhone()+"资料修改失败！");
            }
            return map;
        }
        map.put("status", true);
        return map;
    }
    
    /***
     * 查询用户信息
     * @param request
     * @param modPhone
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "phone-info", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> phoneInfo(HttpServletRequest request, String modPhone,  HttpSession session,DataTable<CsUserListDTO> dt) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        if (Utils.isEmptyString(modPhone)) {
            map.put("status", false);
            map.put("msg", "请输入号码！");
            return map;
        }
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            TNumber ndto = numService.findByPhone(modPhone);
            if(null == ndto){
                map.put("status", false);
                map.put("msg", "号码在系统不存在！");
                return map;
            }
            if(!TNumber.STATUS_FINISH_ACTIVATE.equals(ndto.getStatus()) && 
                    !TNumber.STATUS_WAIT_FINISH.equals(ndto.getStatus())){
                map.put("status", false);
                map.put("msg", "号码在系统未开户！");
                return map;
            }
            
            
            Identity identity = identityService.findByPhone(modPhone);
            if(null != identity){
                map.put("contactPhone",identity.getContactPhone());
            }
            

            Map<String, Object> parment = new HashMap<>();
            parment.put("prefix", Integer.valueOf(modPhone.substring(0, 7)));
            parment.put("virtualCode", "ZXST");
            MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
            if(mobileArea == null){
                map.put("status", false);
                map.put("msg", "对不起，该号码为非中兴视通号码不能进行业务办理！");
                return map;
            }
            if(MobileArea.carrier_YD.equals(mobileArea.getCarrier())){

                TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
                bo.setMSISDN("86"+modPhone);
                RestStatus rs = buyNewService.QueryUserProfileBOSS(bo,user);
                if(rs.getStatus()){
                    TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
                    /*
                     * 客服修改资料不校验状态
                     * if(Integer.valueOf(res.getBal()) < 0){
                        map.put("status", false);
                        map.put("msg", "号码："+modPhone+"，已欠费，不能进行过户");
                        return map;
                    }else if(!"A".equals(res.getState()) && !"E".equals(res.getState())){
                        map.put("status", false);
                        map.put("msg", "号码："+modPhone+" 状态为："+DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()) + "，不能进行过户");
                        return map;
                    }*/

                    map.put("qName",res.getCustName());
                    map.put("qCode",res.getCertNbr());

                }else{
                    map.put("status", false);
                    map.put("msg", rs.getErrorMessage());
                    return map;
                }
            }else{
                ReqCommonDTO dto = new ReqCommonDTO();
                dto.setPhone(modPhone);
                 csUserService.userList(dt,user,dto);
                if(null != dt && dt.getAaData() != null && dt.getAaData().size() >0){
                    Map<String,Object> entry = (Map<String,Object>)dt.getAaData().get(0);
                    map.put("qName",String.valueOf(entry.get("certName")));
                    map.put("qCode",String.valueOf(entry.get("certCode")));
                }
            }

            IdcardInfo cardInfo = idcardInfoService.findByIdNumber(map.get("qCode").toString());
            if(null !=cardInfo){
                map.put("sexual",cardInfo.getSexual());
                map.put("sexualStr",cardInfo.getSexualStr());
                map.put("organs",cardInfo.getOrgans());
                map.put("address",cardInfo.getAddress());
                map.put("expiryDate",cardInfo.getExpiryDate());
                map.put("startExpiryDate",cardInfo.getStartExpiryDate());
                map.put("endExpiryDate",cardInfo.getEndExpiryDate());
                List<AttachedDocuments> attr = documentsService.findBySourceIdAndSourceName(identity.getId(), "t_identity");
                AttachedDocuments cardHandImg = null;
                AttachedDocuments cardFrontImg = null;
                AttachedDocuments cardRearImg = null;
                if(null != attr && attr.size() >0){
                    for(AttachedDocuments s : attr){
                        s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                        if(s.getSourceType().equals("cardHand")){
                            cardHandImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHandImg, s);
                        }else if(s.getSourceType().equals("cardFront")){
                            cardFrontImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardFrontImg, s);
                        }else if(s.getSourceType().equals("cardRear")){
                            cardRearImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardRearImg, s);
                        }
                    }
                }

                map.put("cardHandImg", cardHandImg);
                map.put("cardFrontImg", cardFrontImg);
                map.put("cardRearImg", cardRearImg);
            }
            

        }catch (Exception e){
            e.printStackTrace();
            logger.error("查询用户"+modPhone+"信息失败，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "查询用户信息失败，请重新提交！");
        }
        map.put("status", true);
        return map;
    }

}
