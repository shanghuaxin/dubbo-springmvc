package com.agent.openaccount.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberMapper;
import com.agent.util.DicUtil;

@Transactional(rollbackFor=Exception.class)
@Service("openAccountService")
public class OpenAccountService {
    
    @Autowired
    private NumberMapper numberMapper;
    
    public List<TNumber> listOpenAccount(Map<String, Object> params) {
        List<TNumber> list = new ArrayList<TNumber>();
        List<TNumber> numbers = numberMapper.listOpenAccount(params);
        for (TNumber tNumber : numbers) {
            tNumber.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(tNumber.getLevel()));
            list.add(tNumber);
        }
        return list;
    }
    
    public int countOpenAccount(Map<String, Object> params) {
        return numberMapper.countOpenAccount(params);
    }
    
    public List<TNumber> batchViewPic(Map<String, Object> params) {
        return numberMapper.batchViewPic(params);
    }

}
