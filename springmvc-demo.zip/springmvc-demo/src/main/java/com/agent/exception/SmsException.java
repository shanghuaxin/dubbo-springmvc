package com.agent.exception;

/**
 * Created by cm.linjinxiao on 2016/6/16.
 * 自定义异常
 * 调用短信接口异常
 */
public class SmsException extends Exception {
    
    private static final long serialVersionUID = -4359992276449896544L;

    public SmsException(String msg) {
        super(msg);
    }
}
