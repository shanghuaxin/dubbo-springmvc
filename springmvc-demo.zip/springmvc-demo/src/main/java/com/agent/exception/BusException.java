package com.agent.exception;

/**
 * Created by zw on 2015/11/22.
 * 自定义异常
 */
public class BusException extends Exception {
    private static final long serialVersionUID = 7878623210812143520L;

    public BusException(String msg) {
        super(msg);
    }
}
