package com.agent.exception;

/**
 * Created by zw on 2015/11/22.
 * 自定义异常
 */
public class RechargeException extends Exception {
    
    private static final long serialVersionUID = -4980725335157406072L;

    public RechargeException(String msg) {
        super(msg);
    }
}
