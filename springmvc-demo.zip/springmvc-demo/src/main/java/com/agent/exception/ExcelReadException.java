package com.agent.exception;

import org.xml.sax.SAXException;

/**
 * Created by Administrator on 2016/7/22.
 */
@SuppressWarnings("serial")
public class ExcelReadException extends SAXException {
    public ExcelReadException(String msg) {
        super(msg);
    }
}
