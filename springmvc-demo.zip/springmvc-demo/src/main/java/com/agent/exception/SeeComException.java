package com.agent.exception;

/**
 * Created by Administrator on 2016/7/22.
 */
@SuppressWarnings("serial")
public class SeeComException extends Exception {
    public SeeComException(String msg) {
        super(msg);
    }
}
