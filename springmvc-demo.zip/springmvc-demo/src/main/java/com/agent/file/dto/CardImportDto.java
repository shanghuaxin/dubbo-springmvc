package com.agent.file.dto;

/**
 * Created by Administrator on 2016/7/22.
 * 卡密导入对象
 */
public class CardImportDto {
    private String cardNo;
    private String cardPwd;
    private String isCard;
    private String proType;
    private String ranges;
    private String variety;//规格
    private String proAttr;
    private String validity;//有效期
    private String channelCode1;
    private String channelCode2;
    private String channelCode3;

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardPwd() {
        return cardPwd;
    }

    public void setCardPwd(String cardPwd) {
        this.cardPwd = cardPwd;
    }

    public String getIsCard() {
        return isCard;
    }

    public void setIsCard(String isCard) {
        this.isCard = isCard;
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType;
    }

    public String getRanges() {
        return ranges;
    }

    public void setRanges(String ranges) {
        this.ranges = ranges;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getProAttr() {
        return proAttr;
    }

    public void setProAttr(String proAttr) {
        this.proAttr = proAttr;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public String getChannelCode1() {
        return channelCode1;
    }

    public void setChannelCode1(String channelCode1) {
        this.channelCode1 = channelCode1;
    }

    public String getChannelCode2() {
        return channelCode2;
    }

    public void setChannelCode2(String channelCode2) {
        this.channelCode2 = channelCode2;
    }

    public String getChannelCode3() {
        return channelCode3;
    }

    public void setChannelCode3(String channelCode3) {
        this.channelCode3 = channelCode3;
    }
}
