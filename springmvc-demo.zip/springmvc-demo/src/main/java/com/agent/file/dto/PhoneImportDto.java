package com.agent.file.dto;

import java.util.Date;

/**
 * Created by Administrator on 2016/7/22.
 * 号码导入对象
 */
public class PhoneImportDto {
    public static String allot_type_1 = "1";//分配给一级
    public static String allot_type_2 = "2";//分配给二级
    public static String allot_type_3 = "3";//分配给三级
    public static String allot_type_4 = "4";//分配给直属网点

    private String phone;
    private Integer phoneId;
    private String iccid;
    private String imsi;
    private String ascription;//号码归属地
    private String level;//号码级别
    private String minFloat;//低消
    private String prestore;//预存
    private String money;//面额
    private String validity;//有效期
    private String packages;//套餐
    private String isPre;//是否预开户
    private String preDate;//预开户时间
    private String allotType;//分配类型：1：一级，2：二级，3：三级，4：直属网点
    private Integer channelId1;
    private String channelCode1;
    private String channelName1;
    private Date channelDate1;
    private String money1;
    private Integer channelId2;
    private String channelCode2;
    private String channelName2;
    private Date channelDate2;
    private String money2;
    private Integer channelId3;
    private String channelCode3;
    private String channelName3;
    private Date channelDate3;
    private String money3;
    private Integer channelId;//当前渠道
    private String channelName;//当前渠道
    private String operatorCode; //运营商:1-移动，2-联通，3-电信

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getAscription() {
        return ascription;
    }

    public void setAscription(String ascription) {
        this.ascription = ascription;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getMinFloat() {
        return minFloat;
    }

    public void setMinFloat(String minFloat) {
        this.minFloat = minFloat;
    }

    public String getPrestore() {
        return prestore;
    }

    public void setPrestore(String prestore) {
        this.prestore = prestore;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public String getPackages() {
        return packages;
    }

    public void setPackages(String packages) {
        this.packages = packages;
    }

    public String getIsPre() {
        return isPre;
    }

    public void setIsPre(String isPre) {
        this.isPre = isPre;
    }

    public String getPreDate() {
        return preDate;
    }

    public void setPreDate(String preDate) {
        this.preDate = preDate;
    }

    public Integer getChannelId1() {
        return channelId1;
    }

    public void setChannelId1(Integer channelId1) {
        this.channelId1 = channelId1;
    }

    public String getChannelCode1() {
        return channelCode1;
    }

    public void setChannelCode1(String channelCode1) {
        this.channelCode1 = channelCode1;
    }

    public String getChannelName1() {
        return channelName1;
    }

    public void setChannelName1(String channelName1) {
        this.channelName1 = channelName1;
    }

    public String getMoney1() {
        return money1;
    }

    public void setMoney1(String money1) {
        this.money1 = money1;
    }

    public Integer getChannelId2() {
        return channelId2;
    }

    public void setChannelId2(Integer channelId2) {
        this.channelId2 = channelId2;
    }

    public String getChannelCode2() {
        return channelCode2;
    }

    public void setChannelCode2(String channelCode2) {
        this.channelCode2 = channelCode2;
    }

    public String getChannelName2() {
        return channelName2;
    }

    public void setChannelName2(String channelName2) {
        this.channelName2 = channelName2;
    }

    public String getMoney2() {
        return money2;
    }

    public void setMoney2(String money2) {
        this.money2 = money2;
    }

    public Integer getChannelId3() {
        return channelId3;
    }

    public void setChannelId3(Integer channelId3) {
        this.channelId3 = channelId3;
    }

    public String getChannelCode3() {
        return channelCode3;
    }

    public void setChannelCode3(String channelCode3) {
        this.channelCode3 = channelCode3;
    }

    public String getChannelName3() {
        return channelName3;
    }

    public void setChannelName3(String channelName3) {
        this.channelName3 = channelName3;
    }

    public String getMoney3() {
        return money3;
    }

    public void setMoney3(String money3) {
        this.money3 = money3;
    }

    public String getAllotType() {
        return allotType;
    }

    public void setAllotType(String allotType) {
        this.allotType = allotType;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

    public Date getChannelDate1() {
        return channelDate1;
    }

    public void setChannelDate1(Date channelDate1) {
        this.channelDate1 = channelDate1;
    }

    public Date getChannelDate2() {
        return channelDate2;
    }

    public void setChannelDate2(Date channelDate2) {
        this.channelDate2 = channelDate2;
    }

    public Date getChannelDate3() {
        return channelDate3;
    }

    public void setChannelDate3(Date channelDate3) {
        this.channelDate3 = channelDate3;
    }
    
    
}
