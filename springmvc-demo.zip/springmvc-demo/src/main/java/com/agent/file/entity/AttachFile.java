package com.agent.file.entity;

import com.agent.common.BaseDomain;

/**
 * Created by Administrator on 2016/7/25.
 */
public class AttachFile extends BaseDomain{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String attachName;
    private String attachUrl;
    private Integer attrachType;
    private String attachDesc;
    private Long size;
    private Integer sort;
    private Integer sourceId;
    private String sourceType;

    public String getAttachName() {
        return attachName;
    }

    public void setAttachName(String attachName) {
        this.attachName = attachName;
    }

    public String getAttachUrl() {
        return attachUrl;
    }

    public void setAttachUrl(String attachUrl) {
        this.attachUrl = attachUrl;
    }

    public Integer getAttrachType() {
        return attrachType;
    }

    public void setAttrachType(Integer attrachType) {
        this.attrachType = attrachType;
    }

    public String getAttachDesc() {
        return attachDesc;
    }

    public void setAttachDesc(String attachDesc) {
        this.attachDesc = attachDesc;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    @Override
    public String toString() {
        return "AttachFile{" +
                "attachName='" + attachName + '\'' +
                ", attachUrl='" + attachUrl + '\'' +
                ", attrachType=" + attrachType +
                ", attachDesc='" + attachDesc + '\'' +
                ", size=" + size +
                ", sort=" + sort +
                ", sourceId=" + sourceId +
                ", sourceType='" + sourceType + '\'' +
                '}';
    }
}
