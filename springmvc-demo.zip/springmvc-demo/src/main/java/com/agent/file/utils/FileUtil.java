package com.agent.file.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.agent.exception.SeeComException;

/**
 * Created by Administrator on 2016/7/22.
 * 文件上传
 */
public class FileUtil {
    private static Logger logger = LoggerFactory.getLogger(FileUtil.class);

    /**
     * 生成文件
     * @param stream
     * @param path
     * @param filename
     * @throws Exception
     */
    public static void saveFileFromInputStream(InputStream stream,String path,
            String filename) throws Exception {
        FileOutputStream fs = null;
        try {
            File dir = new File(path);
            if (!dir.exists()){   //如果目录不存在就创建目录
                dir.mkdirs();
            }
            fs = new FileOutputStream(path + File.separator + filename);
            byte[] buffer = new byte[1024*1024];
            int byteread = 0;
            while ((byteread=stream.read(buffer))!=-1)
            {
                fs.write(buffer,0,byteread);
                fs.flush();
            }
            fs.close();
            stream.close();
        } catch (Exception e) {
            logger.error("保存文件出错："+e.getMessage(), e);
        } finally {
            try {
                if (null != fs) {
                    fs.close();
                    fs = null;
                }
                if (null != stream) {
                    stream.close();
                    stream = null;
                }
            } catch (Exception e) {
                logger.error("关闭文件流异常："+e.getMessage(), e);
            }
        }
    }
    /**
     * 保存图片
     * @param file
     * @param filPatch
     * @param fileName
     * @return
     * @throws Exception
     */
    public static String saveImageFile(MultipartFile file,String fileHp, String filPatch,String fileName) throws Exception{

        logger.info("---------- 保存文件【"+filPatch + File.separator + fileName+"】 begin ----------");
        if(file == null){
            logger.error("上传文件不能够为空");
            throw new SeeComException("上传文件不能够为空");
        }
        String sourceName = file.getOriginalFilename(); // 原始文件名

        if(sourceName==null||"".equals(sourceName)){
            logger.error("上传文件不能够为空");
            throw new SeeComException("上传文件不能够为空");
        }
        if(file.getSize() > 10000000){
            logger.error("上传失败：文件大小不能超过10M");
            throw new SeeComException("上传失败：文件大小不能超过10M");
        }
        if(file.getSize()>0){
            saveFileFromInputStream(file.getInputStream(), fileHp + File.separator + filPatch, fileName);
        }else{
            logger.error("上传文件不能够为空");
            throw new SeeComException("上传文件不能够为空");
        }
        logger.info("---------- 保存文件【"+filPatch + File.separator + fileName+"】 end ----------");
        return filPatch + File.separator + fileName;
    }
    
    public static String saveImageFile(MultipartFile file, String imageURL) throws Exception {
        if(file == null){
            logger.error("上传文件不能够为空");
            throw new SeeComException("上传文件不能够为空");
        }
        
        String sourceName = file.getOriginalFilename(); // 原始文件名
        
        if(sourceName==null||"".equals(sourceName)){
            logger.error("上传文件不能够为空");
            throw new SeeComException("上传文件不能够为空");
        }
        
        String docLocation = "homePage";
        
        /*UUID uuid = UUID.randomUUID();
        sourceName = uuid + sourceName.substring(sourceName.lastIndexOf("."), sourceName.length());*/
        
        if(file.getSize() > 20000000){
            logger.error("上传失败：文件大小不能超过20M");
            throw new SeeComException("上传失败：文件大小不能超过20M");
        }
        
        if (file.getSize()>0) {
            try {
                saveFileFromInputStream(file.getInputStream(), imageURL + File.separator + docLocation, sourceName);
            } catch (Exception e) {
                logger.error("系统找不到指定的路径");
                throw new SeeComException("系统找不到指定的路径");
            }
        } else {
            logger.error("上传文件不能够为空");
            throw new SeeComException("上传文件不能够为空");
        }
        return  File.separator + docLocation + File.separator + sourceName;
    }
}
