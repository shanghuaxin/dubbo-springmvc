package com.agent.file.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.agent.constant.Constant;
import com.agent.number.service.IccidPoolService;
import com.agent.number.service.NumberImportService;
import com.agent.stock.service.CardInfoService;
import com.agent.stock.service.StockAllotService;
import com.agent.util.DateUtil;

/**
 * Created by Administrator on 2016/7/22.
 */
@Controller
@RequestMapping(value="file")
public class FileController {
    private static Logger logger = LoggerFactory.getLogger(FileController.class);
    @Resource
    private CardInfoService cardInfoService;
    @Resource
    private NumberImportService numberImportService;
    @Resource
    private StockAllotService stockAllotService;
    @Resource
    private IccidPoolService iccidPoolService;

    /**
     * 卡密导入
     * @param file
     * @param response
     * @param request
     * @param importType
     * @return
     * @throws IOException
     */
    @RequestMapping(value="info-import-excel", method=RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String cardImport(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("importType") String importType,@RequestParam("remark") String remark) {
        Map<String,Object> rtnMap=new HashMap<String,Object>();
        try{
            logger.error("进入号码卡密信息导入 cardImport");
            response.setContentType("text/html; charset=UTF-8");
            if(Constant.CARD_IMPORT.equals(importType)){
                rtnMap = cardInfoService.importFile(file, importType, request);
            }else if(Constant.PHONE_IMPORT.equals(importType)){
                rtnMap = numberImportService.importPhoneInfoFile(file, importType,remark, request);
            }else if(Constant.PHONE_PRE_IMPORT.equals(importType)){
                rtnMap = numberImportService.importPreFile(file,importType,request);
            }
        }catch(Exception ex){
            logger.error("号码卡密信息导入失败:{}",ex);
            rtnMap.put("stat",false);
            rtnMap.put("msg","导入失败！");
            ex.printStackTrace();
        }
        StringBuffer str = new StringBuffer();
        str.append("FILE@UPLOAD");
        str.append(rtnMap.get("stat")).append(":");
        str.append(rtnMap.get("msg"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }


    /**
     * 库存分配导入
     * @param file
     * @param response
     * @param request
     * @param importType
     * @return
     * @throws IOException
     */
    @RequestMapping(value="allot-import-excel", method=RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String cardAllotImport(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("importType") String importType,@RequestParam("remark") String remark) {
        Map<String,Object> rtnMap=new HashMap<String,Object>();
        try{
            logger.error(" 库存分配导入 cardAllotImport");
            response.setContentType("text/html; charset=UTF-8");
            if(Constant.PHONE_ALLOT_COMP.equals(importType) || Constant.PHONE_ALLOT_1.equals(importType) || Constant.PHONE_ALLOT_2.equals(importType)){
                rtnMap = numberImportService.importPhoneAllotFile(file,importType,remark,request);
            }else if(Constant.CARD_ALLOT_COMP.equals(importType) || Constant.CARD_ALLOT_1.equals(importType) || Constant.CARD_ALLOT_2.equals(importType)){
                rtnMap = stockAllotService.importFile(file, importType, request);
            }
        }catch(Exception ex){
            logger.error("分配导入失败:{}",ex);
            rtnMap.put("stat",false);
            rtnMap.put("msg","分配导入失败！");
            ex.printStackTrace();
        }
        StringBuffer str = new StringBuffer();
        str.append("FILE@UPLOAD");
        str.append(rtnMap.get("stat")).append(":");
        str.append(rtnMap.get("msg"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }

    /**
     * 库存回收导入
     * @param file
     * @param response
     * @param request
     * @param importType
     * @return
     * @throws IOException
     */
    @RequestMapping(value="take-bake-excel", method=RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String stockTakeBack(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("importType") String importType,@RequestParam("remark") String remark){
        Map<String,Object> rtnMap=new HashMap<String,Object>();
        try{
            logger.error("进入库存回收导入 stockTakeBack");
            response.setContentType("text/html; charset=UTF-8");
            if(Constant.PHONE_TAKE_BACK.equals(importType)){
                rtnMap =numberImportService.takeBackImport(file, importType,remark, request);
            }else if(Constant.CARD_TAKE_BACK.equals(importType)){
                rtnMap = stockAllotService.takeBackImport(file, importType, request);
            }
        }catch(Exception ex){
            logger.error("回收导入失败:{}",ex);
            rtnMap.put("stat",false);
            rtnMap.put("msg","回收导入失败！");
            ex.printStackTrace();
        }
        StringBuffer str = new StringBuffer();
        str.append("FILE@UPLOAD");
        str.append(rtnMap.get("stat")).append(":");
        str.append(rtnMap.get("msg"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }

    /**
     * 库存下架导入
     * @param file
     * @param response
     * @param request
     * @param importType
     * @return
     * @throws IOException
     */
    @RequestMapping(value="stock-del-excel", method=RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String takeBackExcel(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("importType") String importType,@RequestParam("remark") String remark) {
        Map<String,Object> rtnMap=new HashMap<String,Object>();
        try{
            logger.error("================= 库存下架导入 takeBackExcel开始时间："
                    +DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyyMMddHHmmssSSS)+"=================");
            response.setContentType("text/html; charset=UTF-8");
            if (Constant.PHONE_DEL.equals(importType)) {
                rtnMap = numberImportService.stockDelImport(file, importType,remark, request);
            } else if(Constant.CARD_DEL.equals(importType)) {
                rtnMap = stockAllotService.stockDelImport(file,importType,request);
            }
            logger.error("================= 库存下架导入 takeBackExcel结束时间："
                    +DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyyMMddHHmmssSSS)+"=================");
        } catch(Exception ex) {
            logger.error("库存下架导入失败:"+ex.getMessage(), ex);
            rtnMap.put("stat",false);
            rtnMap.put("msg","导入失败！");
        }
        StringBuffer str = new StringBuffer();
        str.append("FILE@UPLOAD");
        str.append(rtnMap.get("stat")).append(":");
        str.append(rtnMap.get("msg"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
    
    
    /**
     * 号码销户回收导入
     * @param file
     * @param response
     * @param request
     * @param importType
     * @return
     * @throws IOException
     */
    @RequestMapping(value="stock-cancle-black", method=RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String stockCancleBlack(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("importType") String importType,@RequestParam("remark") String remark) {
        Map<String,Object> rtnMap=new HashMap<String,Object>();
        try{
            logger.error("进入号码销户回收导入 stockCancleBlack");
            response.setContentType("text/html; charset=UTF-8");
            rtnMap =numberImportService.stockCancleBlack(file, importType,remark, request);
        }catch(Exception ex){
            logger.error("号码销户回收导入失败:{}",ex);
            rtnMap.put("stat",false);
            rtnMap.put("msg","导入失败！");
            ex.printStackTrace();
        }
        StringBuffer str = new StringBuffer();
        str.append("FILE@UPLOAD");
        str.append(rtnMap.get("stat")).append(":");
        str.append(rtnMap.get("msg"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
    
    /**
     * ICCID 出库
     * @param file
     * @param response
     * @param request
     * @param importType
     * @return
     * @throws IOException
     */
    @RequestMapping(value="stock-iccid-out", method=RequestMethod.POST,produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String iccidOutStock(@RequestParam("uploadFile") MultipartFile file,HttpServletResponse response,HttpServletRequest request,
            @RequestParam("importType") String importType,@RequestParam("remark") String remark) {
        Map<String,Object> rtnMap=new HashMap<String,Object>();
        try{
            logger.error("进入ICCID 出库导入 iccidOutStock");
            response.setContentType("text/html; charset=UTF-8");
            rtnMap =iccidPoolService.iccidOutStock(file, importType,remark, request);
        }catch(Exception ex){
            logger.error("ICCID 出库导入失败:{}",ex);
            rtnMap.put("stat",false);
            rtnMap.put("msg","ICCID 出库导入失败！");
            ex.printStackTrace();
        }
        StringBuffer str = new StringBuffer();
        str.append("FILE@UPLOAD");
        str.append(rtnMap.get("stat")).append(":");
        str.append(rtnMap.get("msg"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
}
