package com.agent.file.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.file.entity.AttachFile;

@Repository
public interface AttachFileMapper extends BaseMapper<AttachFile,Integer> {
    public List<AttachFile> listAttachFile(Map<String, Object> params);
    public int insert(AttachFile attachFile);
    public void batchInsert(List<AttachFile> list);
}
