package com.agent.file.service;
import java.io.File;
import java.util.LinkedList;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.file.utils.DownExcel;

/**
 * 导入设置管理
 * @author auto
 */
@Transactional(rollbackFor=Exception.class)
@Service
public class ImportExcelService {
    private static Logger logger= LoggerFactory.getLogger(ImportExcelService.class);
    public static final int HASH_INTERATIONS=1024;
    //private static final int SALT_SIZE=8;
    /**
     * 动态生成excel 文件
     *
     * @param tip      生成用户,职责,OA用户信息
     * @param response
     */
    public void DownLoadExcel(String tip,HttpServletResponse response){
        try{
            LinkedList<String> titleList=new LinkedList<>();
            /*if("1".equals(tip)){//生成下载用户的模块信息 带有角色下拉框信息
                List<FeRole> roleList=(List<FeRole>)feRoleDao.findAll();
                if(null!=roleList&&roleList.size()>0){
                    for(FeRole feObj : roleList){
                        if(null!=feObj.getName()){
                            titleList.add(feObj.getName());
                        }
                    }
                }
            }*/
            DownExcel.getInstall().downloadExcel(tip,response,titleList); //动态生成excel 下载模板文件
        }catch(Exception e){
            logger.error("动态生成excel文件,出错{}",e);
        }
    }
    /**
     * <分析Excel，组装显示在页面中>
     *
     * @param file               文件信息
     * @param uploadFileFileName 文件后缀名
     * @param tip                生成用户,职责,OA用户信息
     */
    public Map<String,Object> GetObjInfOfExcel(File file,String uploadFileFileName,String tip){
        return DownExcel.getInstall().getObjInfOfExcel(file,uploadFileFileName,tip);
    }
}