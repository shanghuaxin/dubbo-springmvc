package com.agent.file.utils;

import com.agent.constant.Constant;
import com.agent.file.dto.CardImportDto;
import com.agent.file.dto.PhoneImportDto;
import com.agent.file.dto.PreImportDto;
import com.agent.util.PathUtil;
import com.agent.util.Utils;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
*
 * 生成应用的下载文件
 *
*/
public class DownExcel{
    private static DownExcel downExcel=null;
    private final Logger log= LoggerFactory.getLogger(DownExcel.class);
    private DownExcel(){
    }
    public static DownExcel getInstall(){
        synchronized(DownExcel.class){
            if(downExcel==null){
                downExcel=new DownExcel();
            }
        }
        //}
        return downExcel;
    }
    /**
     * @Description: (下载excel 模板文件)
     */
    public void downloadExcel(String tip,HttpServletResponse response,LinkedList<String> titleList){
        try{
            String targetDirectory= PathUtil.getRootPath(), path="";
            if(!Utils.isEmptyString(tip)){
                if(tip.equals("1")){//卡密导入
                    path=targetDirectory+ Constant.TEMPLATE+"/"+"cardInfoImport.xlsx";
                }
            }
            File file=new File(path);// path是指欲下载的文件的路径。
            InputStream fis=new BufferedInputStream(new FileInputStream(path));// 以流的形式下载文件。
            byte[] buffer=new byte[fis.available()];
            fis.read(buffer);
            fis.close();
            response.reset();
            response.setContentType("application/octet-stream;charset=utf-8");
            response.addHeader("Content-Disposition","attachment;filename="+new String(file.getName().getBytes(),"ISO-8859-1"));
            response.addHeader("Content-Length",""+file.length());
            OutputStream toClient=new BufferedOutputStream(response.getOutputStream());
            toClient.write(buffer);
            toClient.flush();
            toClient.close();
            //downLoadFile(response,path);
        }catch(Exception e){
            e.printStackTrace();
            log.error("下载excel模板文件，错误信息 {}",e);
        }
    }


    /**
     * <分析Excel，组装显示在页面中>
     *
     * @param: @param uploadFileFileName
     * @param: @param directory
     * @param: @param tip 1标示上传用户    2标示上传职责
     * @Date 2014-1-17 下午04:08:06
     */
    public Map<String,Object> getObjInfOfExcel(File target,String uploadFileFileName,String tip){
        Map<String,Object> map=new HashMap<String,Object>();
        try{
            Workbook wb=null;
            if(uploadFileFileName.endsWith("xlsx")){
                try{
                    wb=new XSSFWorkbook(new FileInputStream(target));// 操作Excel2007的版本，扩展名是.xlsx
                }catch(Exception e){
                    map.put("errorBack","errorFileError");
                    log.error("分析Excel，出错 {}",e);
                    e.printStackTrace();
                }
            }else if(uploadFileFileName.endsWith("xls")){
                try{
                    wb=new HSSFWorkbook(new FileInputStream(target));// 操作Excel2003以前（包括2003）的版本，扩展名是.xls
                }catch(Exception e){
                    map.put("errorBack","errorFileError");
                    log.error("分析Excel，出错 {}",e);
                    e.printStackTrace();
                }
            }else{
                map.put("errorBack","errorFileError");
            }
            if(wb!=null){
                map=getImportListInfo(wb,tip);
            }
        }catch(Exception e){
            log.error("分析Excel，组装显示在页面中,错误信息{}",e);
            e.printStackTrace();
        }
        return map;
    }
    /**
     * @Description: (处理excel文件数据)
     * @param: @param wb Workbook 对象
     * @param: @param tip 标示
     * @Date 2014-6-10 上午10:27:33
     */
    private Map<String,Object> getImportListInfo(Workbook wb,String tip){
        List<Object> objTList=new LinkedList<Object>();
        Map<String,Object> map=new HashMap<String,Object>();
        StringBuffer errorBack=new StringBuffer();
        StringBuffer errorBack_two=new StringBuffer();
        try{
            //多个标签 导入数据
            log.error("进入excel解析方法");
            int tipA=0, tipC=0;
            for(int h=0;h<1;h++){//获取每个Sheet表
                int tipB=0;
                Sheet sh=wb.getSheetAt(h);
                String sheetName=sh.getSheetName();
                boolean aBool = sheetName.indexOf("ShtDictionary")!=-1,bBool= sheetName.indexOf("说明")!=-1;
                if(aBool||bBool){
                    continue;
                }
                int rowNum=sh.getLastRowNum()+1;
                if(rowNum==2){//没有数据
                    continue;
                }else{
                    if(Constant.PHONE_IMPORT.equals(tip)) {
                        //号码导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";
                        String tc4 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(3)) : "";
                        String tc5 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(4)) : "";
                        String tc6 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(5)) : "";
                        String tc7 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(6)) : "";
                        String tc8 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(7)) : "";
                        String tc9 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(8)) : "";
                        String tc10 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(9)) : "";
                        String tc11 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(10)) : "";
                        String tc12 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(11)) : "";
                        String tc13 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(12)) : "";
                        String tc14 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(13)) : "";
                        String tc15 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(14)) : "";
                        String tc16 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(15)) : "";

                        if (!"号码".equals(tc1) || !"ICCID".equals(tc2) || !"IMSI".equals(tc3) || !"归属地".equals(tc4)
                                || !"号码等级".equals(tc5) || !"低消".equals(tc6) || !"预存".equals(tc7) || !"面值".equals(tc8) || !"有效期(yyyy-mm-dd)".equals(tc9)
                                || !"套餐".equals(tc10) || !"运营商".equals(tc11) || !"是否预开".equals(tc12) || !"预开时间(yyyy-mm-dd)".equals(tc13) || !"一级渠道(编号)".equals(tc14)
                                || !"二级渠道(编号)".equals(tc15) || !"网点(编号)".equals(tc16)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                Cell c5 = row.getCell(4); //
                                Cell c6 = row.getCell(5); //
                                Cell c7 = row.getCell(6); //
                                Cell c8 = row.getCell(7); //
                                Cell c9 = row.getCell(8); //
                                Cell c10 = row.getCell(9); //
                                Cell c11 = row.getCell(10); //
                                Cell c12 = row.getCell(11); //
                                Cell c13 = row.getCell(12); //
                                Cell c14 = row.getCell(13); //
                                Cell c15 = row.getCell(14); //
                                Cell c16 = row.getCell(15); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2))&& Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4))&& Utils.isEmptyString(getValueByCell(c5))&& Utils.isEmptyString(getValueByCell(c6))
                                        && Utils.isEmptyString(getValueByCell(c7))&& Utils.isEmptyString(getValueByCell(c8))&& Utils.isEmptyString(getValueByCell(c9))
                                        && Utils.isEmptyString(getValueByCell(c10))&& Utils.isEmptyString(getValueByCell(c11))&& Utils.isEmptyString(getValueByCell(c12))
                                     ){
                                    break;
                                }

                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2)) ||Utils.isEmptyString(getValueByCell(c3))
                                        || Utils.isEmptyString(getValueByCell(c4)) || Utils.isEmptyString(getValueByCell(c5)) || Utils.isEmptyString(getValueByCell(c6))
                                        || Utils.isEmptyString(getValueByCell(c7)) || Utils.isEmptyString(getValueByCell(c8)) || Utils.isEmptyString(getValueByCell(c9))
                                        || Utils.isEmptyString(getValueByCell(c10)) || Utils.isEmptyString(getValueByCell(c11))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    PhoneImportDto dto = new PhoneImportDto();
                                    dto.setPhone(getValueByCell(c1).trim());
                                    dto.setIccid(getValueByCell(c2).trim());
                                    dto.setImsi(getValueByCell(c3).trim());
                                    dto.setAscription(getValueByCell(c4).trim());
                                    dto.setLevel(getValueByCell(c5).trim());
                                    dto.setMinFloat(getValueByCell(c6).trim());
                                    dto.setPrestore(getValueByCell(c7).trim());
                                    dto.setMoney(getValueByCell(c8).trim());
                                    dto.setValidity(getValueByCell(c9).trim());
                                    dto.setPackages(getValueByCell(c10).trim());
                                    dto.setOperatorCode(getValueByCell(c11).trim());
                                    dto.setIsPre(getValueByCell(c12).trim());
                                    dto.setPreDate(getValueByCell(c13).trim());
                                    dto.setChannelCode1(getValueByCell(c14).trim());
                                    dto.setChannelCode2(getValueByCell(c15).trim());
                                    dto.setChannelCode3(getValueByCell(c16).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    } else if(Constant.PHONE_ALLOT_COMP.equals(tip)) {
                        //总部号码分配导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";
                        String tc4 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(3)) : "";

                        if (!"号码".equals(tc1) || !"一级渠道(编号)".equals(tc2) || !"二级渠道(编号)".equals(tc3) || !"网点(编号)".equals(tc4)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2))&& Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4))){
                                    break;
                                }

                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    PhoneImportDto dto = new PhoneImportDto();
                                    dto.setPhone(getValueByCell(c1).trim());
                                    dto.setChannelCode1(getValueByCell(c2).trim());
                                    dto.setChannelCode2(getValueByCell(c3).trim());
                                    dto.setChannelCode3(getValueByCell(c4).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.PHONE_ALLOT_1.equals(tip)) {
                        //一级代理商号码分配导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";

                        if (!"号码".equals(tc1) || !"二级渠道(编号)".equals(tc2) || !"网点(编号)".equals(tc3)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2))&& Utils.isEmptyString(getValueByCell(c3))){
                                    break;
                                }

                                if (Utils.isEmptyString(getValueByCell(c1)) || (Utils.isEmptyString(getValueByCell(c2)) && Utils.isEmptyString(getValueByCell(c3)))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    PhoneImportDto dto = new PhoneImportDto();
                                    dto.setPhone(getValueByCell(c1).trim());
                                    dto.setChannelCode2(getValueByCell(c2).trim());
                                    dto.setChannelCode3(getValueByCell(c3).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.PHONE_ALLOT_2.equals(tip)) {
                        //二级代理商号码分配导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";

                        if (!"号码".equals(tc1) || !"网点(编号)".equals(tc2)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2))){
                                    break;
                                }

                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    PhoneImportDto dto = new PhoneImportDto();
                                    dto.setPhone(getValueByCell(c1).trim());
                                    dto.setChannelCode3(getValueByCell(c2).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.PHONE_TAKE_BACK.equals(tip) || Constant.PHONE_DEL.equals(tip) || Constant.PHONE_CANCEL.equals(tip)) {
                        //号码回收或号码下架
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";

                        if (!"号码".equals(tc1)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                if(Utils.isEmptyString(getValueByCell(c1))){
                                    break;
                                }

                                if (Utils.isEmptyString(getValueByCell(c1))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    PhoneImportDto dto = new PhoneImportDto();
                                    dto.setPhone(getValueByCell(c1).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.PHONE_PRE_IMPORT.equals(tip)) {
                        //预开户号码导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";
                        String tc4 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(3)) : "";
                        String tc5 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(4)) : "";
                        String tc6 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(5)) : "";

                        if (!"号码".equals(tc1) || !"ICCID".equals(tc2) || !"IMSI".equals(tc3) || !"预开时间".equals(tc4)
                                || !"预开套餐编号".equals(tc5) || !"预开套餐名称".equals(tc6)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                Cell c5 = row.getCell(4); //
                                Cell c6 = row.getCell(5); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2))&& Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4))&& Utils.isEmptyString(getValueByCell(c5))&& Utils.isEmptyString(getValueByCell(c6))){
                                    break;
                                }

                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2)) ||Utils.isEmptyString(getValueByCell(c3)) || Utils.isEmptyString(getValueByCell(c4)) || Utils.isEmptyString(getValueByCell(c5)) || Utils.isEmptyString(getValueByCell(c6))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    PreImportDto dto = new PreImportDto();
                                    dto.setPhone(getValueByCell(c1).trim());
                                    dto.setIccid(getValueByCell(c2).trim());
                                    dto.setImsi(getValueByCell(c3).trim());
                                    dto.setAdvanceTime(getValueByCell(c4).trim());
                                    dto.setServCode(getValueByCell(c5).trim());
                                    dto.setServName(getValueByCell(c6).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.CARD_IMPORT.equals(tip)) {//卡密导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";
                        String tc4 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(3)) : "";
                        String tc5 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(4)) : "";
                        String tc6 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(5)) : "";
                        String tc7 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(6)) : "";
                        String tc8 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(7)) : "";
                        String tc9 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(8)) : "";
                        String tc10 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(9)) : "";
                        String tc11 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(10)) : "";

                        if (!"账号".equals(tc1) || !"密码".equals(tc2) || !"实体卡".equals(tc3) || !"商品类型".equals(tc4)
                                || !"使用范围".equals(tc5) || !"商品规格".equals(tc6) || !"使用时长".equals(tc7) || !"有效期".equals(tc8)
                                || !"一级渠道(编号)".equals(tc9) || !"二级渠道(编号)".equals(tc10) || !"网点(编号)".equals(tc11)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                Cell c5 = row.getCell(4); //
                                Cell c6 = row.getCell(5); //
                                Cell c7 = row.getCell(6); //
                                Cell c8 = row.getCell(7); //
                                Cell c9 = row.getCell(8); //
                                Cell c10 = row.getCell(9); //
                                Cell c11 = row.getCell(10); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2)) && Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4)) && Utils.isEmptyString(getValueByCell(c5)) && Utils.isEmptyString(getValueByCell(c6))
                                        && Utils.isEmptyString(getValueByCell(c7)) && Utils.isEmptyString(getValueByCell(c8))){
                                    break;
                                }
                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2)) ||Utils.isEmptyString(getValueByCell(c3)) ||Utils.isEmptyString(getValueByCell(c4)) ||Utils.isEmptyString(getValueByCell(c5)) ||Utils.isEmptyString(getValueByCell(c6)) ||Utils.isEmptyString(getValueByCell(c7)) ||Utils.isEmptyString(getValueByCell(c8)) ) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    CardImportDto dto = new CardImportDto();
                                    dto.setCardNo(getValueByCell(c1).trim());
                                    dto.setCardPwd(getValueByCell(c2).trim());
                                    dto.setIsCard(getValueByCell(c3).trim());
                                    dto.setProType(getValueByCell(c4).trim());
                                    dto.setRanges(getValueByCell(c5).trim());
                                    dto.setVariety(getValueByCell(c6).trim());
                                    dto.setProAttr(getValueByCell(c7).trim());
                                    dto.setValidity(getValueByCell(c8).trim());
                                    dto.setChannelCode1(getValueByCell(c9).trim());
                                    dto.setChannelCode2(getValueByCell(c10).trim());
                                    dto.setChannelCode3(getValueByCell(c11).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    } else if(Constant.CARD_ALLOT_COMP.equals(tip)) {
                        //总部卡密分配导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";
                        String tc4 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(3)) : "";
                        if (!"账号".equals(tc1) || !"一级渠道(编号)".equals(tc2) || !"二级渠道(编号)".equals(tc3) || !"网点(编号)".equals(tc4)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }
                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2)) && Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4))){
                                    break;
                                }
                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                } else {
                                    CardImportDto dto = new CardImportDto();
                                    dto.setCardNo(getValueByCell(c1).trim());
                                    dto.setChannelCode1(getValueByCell(c2).trim());
                                    dto.setChannelCode2(getValueByCell(c3).trim());
                                    dto.setChannelCode3(getValueByCell(c4).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.CARD_ALLOT_1.equals(tip)) {
                        //一级卡密分配导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        String tc3 = null != sh.getRow(1) ? getValueByCell(sh.getRow(1).getCell(2)) : "";
                        if (!"账号".equals(tc1) || !"二级渠道(编号)".equals(tc2) || !"网点(编号)".equals(tc3)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }
                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2)) && Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4))){
                                    break;
                                }
                                if (Utils.isEmptyString(getValueByCell(c1)) || (Utils.isEmptyString(getValueByCell(c2)) && Utils.isEmptyString(getValueByCell(c3)))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                }else {
                                    CardImportDto dto = new CardImportDto();
                                    dto.setCardNo(getValueByCell(c1).trim());
                                    dto.setChannelCode2(getValueByCell(c2).trim());
                                    dto.setChannelCode3(getValueByCell(c3).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.CARD_ALLOT_2.equals(tip)) {
                        //二级卡密分配导入
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        String tc2 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(1)) : "";
                        if (!"账号".equals(tc1) || !"网点(编号)".equals(tc2)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                Cell c2 = row.getCell(1); //
                                Cell c3 = row.getCell(2); //
                                Cell c4 = row.getCell(3); //
                                if(Utils.isEmptyString(getValueByCell(c1)) && Utils.isEmptyString(getValueByCell(c2)) && Utils.isEmptyString(getValueByCell(c3))
                                        && Utils.isEmptyString(getValueByCell(c4))){
                                    break;
                                }
                                if (Utils.isEmptyString(getValueByCell(c1)) || Utils.isEmptyString(getValueByCell(c2))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                }else {
                                    CardImportDto dto = new CardImportDto();
                                    dto.setCardNo(getValueByCell(c1).trim());
                                    dto.setChannelCode3(getValueByCell(c2).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }else if(Constant.CARD_TAKE_BACK.equals(tip) || Constant.CARD_DEL.equals(tip)) {
                        //卡密回收，下架
                        //头记录
                        String tc1 = null != sh.getRow(1) ?getValueByCell(sh.getRow(1).getCell(0)) : "";
                        if (!"账号".equals(tc1)) {
                            errorBack.append("对不起您导入的文件格式不正确！");
                        }

                        if(Utils.isEmptyString(errorBack)){
                            for (int i = 2; i < rowNum; i++) {
                                Row row = sh.getRow(i);
                                if(null == row){
                                    break;
                                }
                                Cell c1 = row.getCell(0); //
                                if(Utils.isEmptyString(getValueByCell(c1))){
                                    break;
                                }
                                if (Utils.isEmptyString(getValueByCell(c1))) {//判断不能为空
                                    if (tipB == 0) {
                                        if (tipA > 0) {
                                            errorBack = new StringBuffer(errorBack.substring(0, errorBack.length() - 1)).append("行").append(",");
                                        }
                                        errorBack.append("sheet").append(h + 1).append("中,第").append(i + 1).append(",");
                                    } else {
                                        errorBack.append(i + 1).append(",");
                                    }
                                    tipA++;
                                    tipB++;
                                    continue;
                                }else {
                                    CardImportDto dto = new CardImportDto();
                                    dto.setCardNo(getValueByCell(c1).trim());
                                    objTList.add(dto);
                                }

                            }
                        }
                    }
                }
            }
        //读取sheet文件
        if(tipA>0){
            errorBack.append("行").append("_不能为空");
        }
        if(tipC>0){
            errorBack_two.append("行").append("@isValidatorError");
            //errorBack.append("@").append(errorBack_two);
            errorBack.append(errorBack_two);
        }
        //if(Constant.CARD_IMPORT.equals(tip)){
            map.put("objTList",objTList);
        //}
        //map.put("objList",objList);
        /*if(Utils.isEmpityCollection(objTList)){
            map.put("errorBack","failError");
        }else{*/
            map.put("errorBack",errorBack.toString());
        /*}*/
        log.error("excel解析完成");
        }catch(Exception e){
            log.error("导入信息出错，信息{}",e);
            e.printStackTrace();
        }
        if(0 == map.size()){
            map.put("errorBack", "操作失败，请重新输入或联系管理员");
        }
        return map;
    }
    /**
     * @Description: (获取传入参数实际值)
     * @param: @param cc 待传入参数
     * @return: String    retuStr
     */
    private String getValueByCell(Cell cc){
        String retuStr="";
        if(null!=cc){
            try{
               /*CellType 类型 值
                  CELL_TYPE_NUMERIC 数值型 0
				  CELL_TYPE_STRING 字符串型 1
				  CELL_TYPE_FORMULA 公式型 2
				  CELL_TYPE_BLANK 空值 3
				  CELL_TYPE_BOOLEAN 布尔型 4
				  CELL_TYPE_ERROR 错误 5*/
                int cellType=cc.getCellType();
                if(0==cellType){
                   /* Date excelFromDate=HSSFDateUtil.getJavaDate(cc.getNumericCellValue());
                    retuStr=new DateTime(excelFromDate).toString("yyyy-MM-dd HH:mm");*/
                    retuStr=String.valueOf((long)cc.getNumericCellValue());
                }else if(1==cellType){
                    retuStr=cc.getStringCellValue();
                }else if(2==cellType){
                    retuStr=cc.getCachedFormulaResultType()+"";
                }else if(3==cellType){
                    retuStr=cc.getStringCellValue();
                }else if(4==cellType){
                    retuStr=cc.getBooleanCellValue()+"";
                }else if(5==cellType){
                    retuStr=cc.getStringCellValue();
                }
            }catch(Exception e){
                retuStr=cc.getStringCellValue();
                e.printStackTrace();
            }
            if(!Utils.isEmptyString(retuStr)){
                Pattern p=Pattern.compile("\\s*|\t|\r|\n");
                Matcher m=p.matcher(retuStr.trim());
                retuStr=m.replaceAll("");
            }
        }
        return retuStr;
    }
    
    /**
     * excel 2003版本的导出方法 支持多个sheet导出 导出的文件后缀为.xls
     *
     * @param dataMap       要导出的数据
     * @param excelFilePath excel文件的存放位置
     * @param fileName      excel文件名字
     *
     * @return
     */
    public String exportXlsExcel(Map<String,List<String[]>> dataMap,String excelFilePath,String fileName){
        FileOutputStream fout=null;
        String fileLocal="";
        try{
            File file=new File(excelFilePath);
            if(!file.exists()){
                file.mkdirs();
            }
            // 第一步，创建一个webbook，对应一个Excel文件
            HSSFWorkbook wb=new HSSFWorkbook();
            // 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
            HSSFSheet sheet=null;
            List<String[]> dataList=null;
            HSSFCellStyle style=wb.createCellStyle();
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            Set<String> keyTitle=dataMap.keySet();
            for(String title : keyTitle){
                sheet=wb.createSheet(title);
                dataList=dataMap.get(title);
                for(int i=0;null!=dataList&&i<dataList.size();i++){
                    // 生成第一行
                    HSSFRow row=sheet.createRow(i);
                    String[] arr=dataList.get(i);
                    for(int j=0;null!=arr&&j<arr.length;j++){
                        // 给这一行的第一列赋值
                        HSSFCell cell=row.createCell(j);
                        cell.setCellValue(arr[j]);
                        cell.setCellStyle(style);
                        if(i==0){
                            HSSFCellStyle tempStyle=style;
                            tempStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
                            tempStyle.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
                            cell.setCellStyle(tempStyle);
                        }
                    }
                }
            }
            // 第六步，将文件存到指定位置
            fileLocal=excelFilePath+"/"+fileName+".xls";
            fout=new FileOutputStream(fileLocal);
            wb.write(fout);
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try{
                if(fout != null) {
                    fout.close();
                }
            }catch(IOException e){
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return fileLocal;
    }
    
    /**
     * 具体下载文件
     *
     * @param response 响应的请求
     * @param filePath 文件路径
     */
    @SuppressWarnings("unused")
    private void downLoadFile(HttpServletResponse response,String filePath){
        try{
            response.reset();
            response.setContentType("application/octet-stream");
            String fileName=new File(filePath).getName();
            fileName=response.encodeURL(new String(fileName.getBytes(),"ISO8859_1"));//转码
            response.setHeader("Content-Disposition","inline; filename=\""+fileName+"\"");
            ServletOutputStream out=response.getOutputStream();
            InputStream inStream=new FileInputStream(filePath);
            //循环取出流中的数据
            byte[] b=new byte[1024];
            int len;
            while((len=inStream.read(b))>0){
                out.write(b,0,len);
            }
            response.setStatus(HttpServletResponse.SC_OK);
            response.flushBuffer();
            out.close();
            inStream.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * 通过响应输出流实现文件下载
     *
     * @param response     响应的请求
     * @param fileLocal    文件的绝对路径 请用/斜杠表示路径
     * @param downloadName 自定义的文件名 ( 不要后缀),如果此值为空则使用时间日期做为默认的文件名
     * @param deleFile     下载完成后是否删除文件（true: 删除 , false：不删除）
     */
    public void downLoadFile(HttpServletResponse response,String fileLocal,String downloadName,boolean deleFile){
        InputStream in=null;
        OutputStream out=null;
        try{
            if(!"".equals(downloadName)){
                downloadName=downloadName+fileLocal.substring(fileLocal.lastIndexOf("."));
            }else{
                downloadName=fileLocal.substring(fileLocal.lastIndexOf("/")+1);
            }
            response.setHeader("content-disposition","attachment;filename="+URLEncoder.encode(downloadName,"UTF-8"));
            in=new FileInputStream(fileLocal);
            int len=0;
            byte buffer[]=new byte[1024];
            out=response.getOutputStream();
            while((len=in.read(buffer))>0){
                out.write(buffer,0,len);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            if(in!=null){
                try{
                    //
                    in.close();
                    if(deleFile){
                        Thread.sleep(1000l);
                        File file=new File(fileLocal);
                        file.delete();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

}