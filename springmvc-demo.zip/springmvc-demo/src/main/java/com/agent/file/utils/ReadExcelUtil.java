package com.agent.file.utils;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import com.agent.constant.Constant;
import com.agent.exception.ExcelReadException;
import com.agent.file.dto.CardImportDto;
import com.agent.file.dto.PhoneImportDto;
import com.agent.file.dto.PreImportDto;
import com.agent.order.common.util.Utils;

public class ReadExcelUtil extends DefaultHandler {
    private static Logger logger = LoggerFactory.getLogger(ReadExcelUtil.class);
    private SharedStringsTable sst;
    private String lastContents;
    private boolean nextIsString;

    private int sheetIndex = -1;
    private List<String> rowlist = new ArrayList<String>();
    private int curRow = 0;
    private int curCol = 0;
    private String tip;
    private List<Object> objTList=null;
    private StringBuffer errorBack = null;
    private int excelMax = 0;
    // 当前遍历的Excel单元格列索引    
    protected int thisColumnIndex = -1;
    

    /**
     * 读取所有工作簿的入口方法
     * 
     * @param path
     * @throws Exception
     */
    public void process(String path) throws Exception {
        OPCPackage pkg = OPCPackage.open(path);
        XSSFReader r = new XSSFReader(pkg);
        SharedStringsTable sst = r.getSharedStringsTable();
        XMLReader parser = fetchSheetParser(sst);
        Iterator<InputStream> sheets = r.getSheetsData();
        while (sheets.hasNext()) {
            curRow = 0;
            sheetIndex++;
            InputStream sheet = sheets.next();
            InputSource sheetSource = new InputSource(sheet);
            parser.parse(sheetSource);
            sheet.close();
        }
    }

    public XMLReader fetchSheetParser(SharedStringsTable sst) throws SAXException {
        XMLReader parser = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
        this.sst = sst;
        parser.setContentHandler(this);
        return parser;
    }

    /**
     * 读取第一个工作簿的入口方法
     * 
     * @param path
     */
    public Map<String,Object> readOneSheet(String path,String tip,Integer excelMax) throws Exception {
        objTList = new ArrayList<Object>();
        errorBack = new StringBuffer();
        this.tip = tip;
        this.excelMax = excelMax;
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("errorBack","");
        try {
            String fileType = path.substring(path.lastIndexOf("."),path.length());
            if(!fileType.equals(".xlsx") && !fileType.equals(".xls")){
                map.put("errorBack","请选择excel文件进行导入");
                return map;
            }
            OPCPackage pkg = OPCPackage.open(path);
            XSSFReader r = new XSSFReader(pkg);
            SharedStringsTable sst = r.getSharedStringsTable();
            XMLReader parser = fetchSheetParser(sst);
            InputStream sheet = r.getSheet("rId1");
            InputSource sheetSource = new InputSource(sheet);
            parser.parse(sheetSource);
            sheet.close();
            map.put("objTList", objTList);
            if(!Utils.isEmptyString(errorBack)){
                errorBack.append("请修改后重新上传！");
                map.put("errorBack",errorBack.toString());
            }
        } catch (ExcelReadException x) {
            logger.error("解析excel文件出错,文件："+path+",原因："+x.getMessage(),x);
            if(!Utils.isEmptyString(errorBack)){
                errorBack.append("请修改后重新上传！");
                map.put("errorBack",errorBack.toString());
            }
            map.put("objTList", objTList);
        } catch (Exception e) {
            logger.error("解析excel文件出错,文件："+path+",原因："+e.getMessage(),e);
            map.put("errorBack",e.getMessage());
        }
        return map;
    }

    /**
     * 该方法自动被调用，每读一行调用一次，在方法中写自己的业务逻辑即可
     * 
     * @param sheetIndex
     *            工作簿序号
     * @param curRow
     *            处理到第几行
     * @param rowList
     *            当前数据行的数据集合
     */
    public void optRow(int sheetIndex, int curRow, List<String> rowList) throws SAXException{
        String rowStr = "";
        if(curRow >0){
            for(int i=0;i<rowList.size();i++){
                rowStr += rowList.get(i) + "_";
            }
            String ct = "";
            for(String t:rowStr.split("_")){
                if(!Utils.isEmptyString(t)){
                    ct+=t;
                }
            }
            if(Utils.isEmptyString(ct)){
                logger.error("解析文件出现空行，不解析以下数据，行数："+(curRow+1));
                throw new ExcelReadException("解析文件出现空行，不解析以下数据，行数："+(curRow+1));
            }
        }
        String[] rows = rowStr.split("_");
        if(Constant.PHONE_IMPORT.equals(tip)){
            //号码导入
            if(curRow == 1){
                if(rows.length < 14){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new SAXException("对不起您导入的文件格式不正确！");
                }else if(!"号码".equals(rows[0]) || !"ICCID".equals(rows[1]) || !"IMSI".equals(rows[2]) || !"归属地".equals(rows[3])
                        || !"低消".equals(rows[4]) || !"预存".equals(rows[5]) || !"面值".equals(rows[6]) || !"有效期(yyyy-mm-dd)".equals(rows[7])
                        || !"套餐".equals(rows[8]) || !"是否预开".equals(rows[9]) || !"预开时间(yyyy-mm-dd)".equals(rows[10]) || !"一级渠道(编号)".equals(rows[11])
                        || !"二级渠道(编号)".equals(rows[12]) || !"网点(编号)".equals(rows[13])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new SAXException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 10){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1]) || Utils.isEmptyString(rows[2]) || Utils.isEmptyString(rows[3])
                        || Utils.isEmptyString(rows[4]) || Utils.isEmptyString(rows[5]) || Utils.isEmptyString(rows[6]) || Utils.isEmptyString(rows[7]) 
                        || Utils.isEmptyString(rows[9])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PhoneImportDto dto = new PhoneImportDto();
                dto.setPhone(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setIccid(rows[1].trim().replaceAll("\\u00A0",""));
                dto.setImsi(rows[2].trim().replaceAll("\\u00A0",""));
                dto.setAscription(rows[3].trim().replaceAll("\\u00A0",""));
                dto.setMinFloat(rows[4].trim().replaceAll("\\u00A0",""));
                dto.setPrestore(rows[5].trim().replaceAll("\\u00A0",""));
                dto.setMoney(rows[6].trim().replaceAll("\\u00A0",""));
                dto.setValidity(rows[7].trim().replaceAll("\\u00A0",""));
                dto.setPackages(rows[8].trim().replaceAll("\\u00A0",""));
                dto.setIsPre(rows[9].trim().replaceAll("\\u00A0",""));
                dto.setPreDate(rows.length >10 ? rows[10].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode1(rows.length >11 ? rows[11].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode2(rows.length >12 ? rows[12].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode3(rows.length >13 ? rows[13].trim().replaceAll("\\u00A0","") : "");
                objTList.add(dto);
            }
        }else if(Constant.PHONE_ALLOT_COMP.equals(tip)) {
            //总部号码分配导入
            if(curRow == 1){
                if(rows.length < 4){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"号码".equals(rows[0]) || !"一级渠道(编号)".equals(rows[1]) || !"二级渠道(编号)".equals(rows[2]) || !"网点(编号)".equals(rows[3])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PhoneImportDto dto = new PhoneImportDto();
                dto.setPhone(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode1(rows[1].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode2(rows.length >2 ? rows[2].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode3(rows.length >3 ? rows[3].trim().replaceAll("\\u00A0","") : "");
                objTList.add(dto);
            }
        }else if(Constant.PHONE_ALLOT_1.equals(tip)) {
            //一级代理商号码分配导入
            if(curRow == 1){
                if(rows.length < 3){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"号码".equals(rows[0]) ||  !"二级渠道(编号)".equals(rows[1]) || !"网点(编号)".equals(rows[2])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(rows.length ==2 && Utils.isEmptyString(rows[0]) && Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                if(rows.length == 3 && Utils.isEmptyString(rows[0]) || (Utils.isEmptyString(rows[1]) && Utils.isEmptyString(rows[2]))){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PhoneImportDto dto = new PhoneImportDto();
                dto.setPhone(rows[0].trim().replaceAll("\\u00A0","").replaceAll("\\u00A0",""));
                dto.setChannelCode2(rows.length >1 ? rows[1].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode3(rows.length >2 ? rows[2].trim().replaceAll("\\u00A0","") : "");
                objTList.add(dto);
            }
        }else if(Constant.PHONE_ALLOT_2.equals(tip)) {
            //二级代理商号码分配导入
            if(curRow == 1){
                if(rows.length < 2){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"号码".equals(rows[0]) || !"网点(编号)".equals(rows[1])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PhoneImportDto dto = new PhoneImportDto();
                dto.setPhone(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode3(rows[1].trim().replaceAll("\\u00A0",""));
                objTList.add(dto);
            }
        }else if(Constant.PHONE_TAKE_BACK.equals(tip) || Constant.PHONE_DEL.equals(tip) || Constant.PHONE_CANCEL.equals(tip)) {
           //号码回收或号码下架
            if(curRow == 1){
                if(rows.length < 1){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"号码".equals(rows[0])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 1){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PhoneImportDto dto = new PhoneImportDto();
                dto.setPhone(rows[0].trim().replaceAll("\\u00A0",""));
                objTList.add(dto);
            }
        }else if(Constant.PHONE_PRE_IMPORT.equals(tip)) {
            if(curRow == 1){
                if(rows.length < 6){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"号码".equals(rows[0]) || !"ICCID".equals(rows[1]) || !"IMSI".equals(rows[2]) || !"预开时间".equals(rows[3])
                        || !"预开套餐编号".equals(rows[4]) || !"预开套餐名称".equals(rows[5])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 6){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1]) || Utils.isEmptyString(rows[2]) || Utils.isEmptyString(rows[3])
                        || Utils.isEmptyString(rows[4]) || Utils.isEmptyString(rows[5])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PreImportDto dto = new PreImportDto();
                dto.setPhone(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setIccid(rows[1].trim().replaceAll("\\u00A0",""));
                dto.setImsi(rows[2].trim().replaceAll("\\u00A0",""));
                dto.setAdvanceTime(rows[3].trim().replaceAll("\\u00A0",""));
                dto.setServCode(rows[4].trim().replaceAll("\\u00A0",""));
                dto.setServName(rows[5].trim().replaceAll("\\u00A0",""));
                objTList.add(dto);
            }
        }else if(Constant.CARD_IMPORT.equals(tip)) {
            //卡密导入
            if(curRow == 1){
                if(rows.length < 11){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"账号".equals(rows[0]) || !"密码".equals(rows[1]) || !"实体卡".equals(rows[2]) || !"商品类型".equals(rows[3])
                        || !"使用范围".equals(rows[4]) || !"商品规格".equals(rows[5]) || !"使用时长".equals(rows[6]) || !"有效期".equals(rows[7])
                        || !"一级渠道(编号)".equals(rows[8]) || !"二级渠道(编号)".equals(rows[9]) || !"网点(编号)".equals(rows[10])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 8){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1]) || Utils.isEmptyString(rows[2]) || Utils.isEmptyString(rows[3])
                        || Utils.isEmptyString(rows[4]) || Utils.isEmptyString(rows[5]) || Utils.isEmptyString(rows[6]) || Utils.isEmptyString(rows[7])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                CardImportDto dto = new CardImportDto();
                dto.setCardNo(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setCardPwd(rows[1].trim().replaceAll("\\u00A0",""));
                dto.setIsCard(rows[2].trim().replaceAll("\\u00A0",""));
                dto.setProType(rows[3].trim().replaceAll("\\u00A0",""));
                dto.setRanges(rows[4].trim().replaceAll("\\u00A0",""));
                dto.setVariety(rows[5].trim().replaceAll("\\u00A0",""));
                dto.setProAttr(rows[6].trim().replaceAll("\\u00A0",""));
                dto.setValidity(rows[7].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode1(rows.length >8 ? rows[8].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode2(rows.length >10 ? rows[9].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode3(rows.length >11 ? rows[10].trim().replaceAll("\\u00A0","") : "");
                objTList.add(dto);
            }
        } else if(Constant.CARD_ALLOT_COMP.equals(tip)) {
            //总部卡密分配导入
            if(curRow == 1){
                if(rows.length < 4){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"账号".equals(rows[0]) || !"一级渠道(编号)".equals(rows[1]) || !"二级渠道(编号)".equals(rows[2]) || !"网点(编号)".equals(rows[3])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                CardImportDto dto = new CardImportDto();
                dto.setCardNo(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode1(rows[1].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode2(rows.length >2 ? rows[2].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode3(rows.length >3 ? rows[3].trim().replaceAll("\\u00A0","") : "");
                objTList.add(dto);
            }
        }else if(Constant.CARD_ALLOT_1.equals(tip)) {
            //一级卡密分配导入
            if(curRow == 1){
                if(rows.length < 3){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"账号".equals(rows[0]) || !"二级渠道(编号)".equals(rows[1]) || !"网点(编号)".equals(rows[2])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(rows.length ==2 && Utils.isEmptyString(rows[0]) && Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                if(rows.length == 3 && Utils.isEmptyString(rows[0]) || (Utils.isEmptyString(rows[1]) && Utils.isEmptyString(rows[2]))){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                CardImportDto dto = new CardImportDto();
                dto.setCardNo(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode2(rows.length >1 ? rows[1].trim().replaceAll("\\u00A0","") : "");
                dto.setChannelCode3(rows.length >2 ? rows[2].trim().replaceAll("\\u00A0","") : "");
                objTList.add(dto);
            }
        }else if(Constant.CARD_ALLOT_2.equals(tip)) {
            //二级卡密分配导入
            if(curRow == 1){
                if(rows.length < 2){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if((!"账号".equals(rows[0]) || !"网点(编号)".equals(rows[1]))){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                CardImportDto dto = new CardImportDto();
                dto.setCardNo(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setChannelCode3(rows[1]);
                objTList.add(dto);
            }
        }else if(Constant.CARD_TAKE_BACK.equals(tip) || Constant.CARD_DEL.equals(tip)) {
            //卡密回收，下架
            if(curRow == 1){
                if(rows.length < 1){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"账号".equals(rows[0])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 1){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                CardImportDto dto = new CardImportDto();
                dto.setCardNo(rows[0].trim().replaceAll("\\u00A0",""));
                objTList.add(dto);
            }
        }else if(Constant.ICCID_OUT.equals(tip)) {
            //ICCID出库
            if(curRow == 1){
                if(rows.length < 1){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
                if(!"ICCID".equals(rows[0]) || !"IMSI".equals(rows[1])){
                    errorBack.append("对不起您导入的文件格式不正确！");
                    throw new ExcelReadException("对不起您导入的文件格式不正确！");
                }
            }else if(curRow > 1){
                if(rows.length < 2){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return ;
                }
                if(Utils.isEmptyString(rows[0]) || Utils.isEmptyString(rows[1])){
                    errorBack.append("第").append(curRow+1).append("行有必填字段为空，");
                    return;
                }
                PhoneImportDto dto = new PhoneImportDto();
                dto.setIccid(rows[0].trim().replaceAll("\\u00A0",""));
                dto.setImsi(rows[1].trim().replaceAll("\\u00A0",""));
                objTList.add(dto);
            }
        }
    }

    public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
        // c => 单元格
        if (name.equals("c")) {
            // 如果下一个元素是 SST 的索引，则将nextIsString标记为true
            String cellType = attributes.getValue("t");
            if (cellType != null && cellType.equals("s")) {
                nextIsString = true;
            } else {
                nextIsString = false;
            }
            String r = attributes.getValue("r");    
            int firstDigit = -1;    
            for (int c = 0; c < r.length(); ++c) {    
                if (Character.isDigit(r.charAt(c))) {    
                    firstDigit = c;    
                    break;    
                }    
            }    
            thisColumnIndex = nameToColumn(r.substring(0, firstDigit));
        }
        // 置空
        lastContents = "";
    }
    
    /**  
     * 从列名转换为列索引  
     * @param name  
     * @return  
     */   
    private static int nameToColumn(String name) {    
        int column = -1;    
        for (int i = 0; i < name.length(); ++i) {    
            int c = name.charAt(i);    
            column = (column + 1) * 26 + c - 'A';    
        }    
        return column;    
    }

    public void endElement(String uri, String localName, String name) throws SAXException {
        if(curRow >= excelMax){
            logger.error("对不起，导入文件最多："+excelMax+" 条数据");
            throw new SAXException("对不起，导入文件最多："+excelMax+" 条数据");
        }
        // 根据SST的索引值的到单元格的真正要存储的字符串
        // 这时characters()方法可能会被调用多次
        if (nextIsString) {
            try {
                int idx = Integer.parseInt(lastContents);
                lastContents = new XSSFRichTextString(sst.getEntryAt(idx)).toString();
            } catch (Exception e) {
                
            }
        }

        // v => 单元格的值，如果单元格是字符串则v标签的值为该字符串在SST中的索引
        // 将单元格内容加入rowlist中，在这之前先去掉字符串前后的空白符
        /*if (name.equals("v")) {
            String value = lastContents.trim().replaceAll("\\u00A0","");
            value = value.equals("") ? " " : value;
            rowlist.add(curCol, value);
            curCol++;
        } else {
            // 如果标签名称为 row ，这说明已到行尾，调用 optRows() 方法
            if (name.equals("row")) {
                optRow(sheetIndex, curRow, rowlist);
                rowlist.clear();
                curRow++;
                curCol = 0;
            }
        }*/
        
        if ("v".equals(name)) { 
            paddingNullCell(); 
            String value = lastContents.trim().replaceAll("\\u00A0","");  
            value = value.equals("") ? " " : value;  
            rowlist.add(curCol, value);
            curCol++;  
        } else {  
            // 如果标签名称为 row ，这说明已到行尾，调用 optRows() 方法  
            if (name.equals("row")) {  
                optRow(sheetIndex, curRow, rowlist);  
                rowlist.clear();  
                curRow++;  
                curCol = 0;  
            }  
        }  
    }
    
    /** 
     * 空的单元个填充 
     */  
    private void paddingNullCell() {  
        int index = curCol;  
        if(thisColumnIndex > index){  
            for(int i = index; i < thisColumnIndex; i++){  
                rowlist.add(curCol, "");  
                curCol++;  
            }  
        }  
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        // 得到单元格内容的值
        lastContents += new String(ch, start, length);
    }
    
    
    public static void main(String[] args) {
        /*ReadExcelUtil e = new ReadExcelUtil();
        try {
            //e.readOneSheet("C:\\Users\\zhangwei\\Desktop\\回收模板.xlsx");
        } catch (Exception e1) {
            e1.printStackTrace();
        }*/
    }

}
