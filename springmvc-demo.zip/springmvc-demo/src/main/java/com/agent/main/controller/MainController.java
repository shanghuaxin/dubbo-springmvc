package com.agent.main.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.agent.common.DetailDTO;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.common.SessionData;
import com.agent.stock.service.StockService;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;
import com.agent.util.Utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.brokerage.service.BossServiceHisService;
import com.agent.business.entity.RechargeRecord;
import com.agent.business.service.RechargeRecordService;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelAccountTransactionService;
import com.agent.channel.service.ChannelsService;
import com.agent.constant.Constant;
import com.agent.number.service.NumberService;
import com.agent.openaccount.service.IdentityService;
import com.agent.order.entity.PayTracode;
import com.agent.order.service.OrderDetailService;
import com.agent.order.service.PayTracodeService;
import com.agent.system.entity.Privilege;
import com.agent.system.entity.Role;
import com.agent.system.entity.User;
import com.agent.system.service.MenuService;
import com.agent.task.FileDataCdrDownloadJob;
import com.agent.task.ThreadJobTest;
import com.agent.technology.entity.Announcement;
import com.agent.technology.service.AnnouncementService;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("mainpage")
public class MainController {
    
    private static Logger logger = LoggerFactory.getLogger(MainController.class);
    
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private ChannelAccountService channelAccountService;
    @Autowired
    private ChannelAccountTransactionService transactionService;
    @Autowired
    private StockService stockService;
    @Autowired
    private MenuService menuService;
    @Autowired
    private PayTracodeService payTracodeService;
    @Autowired
    private RechargeRecordService rechargeRecordService;
    @Autowired
    private BossServiceHisService bossServiceHisService;
    @Autowired
    private NumberService numberService;
    @Autowired
    private FileDataCdrDownloadJob fileDataCdrDownloadJob;
    @Autowired
    private ThreadJobTest threadTest;
    @Autowired
    private IdentityService identityService;
    @Autowired
    private AnnouncementService announcementService;
    @Autowired
    private OrderDetailService orderDetailService;
    
    @RequestMapping("/index")
    public String channelList(HttpServletRequest request, HttpServletResponse response) {
        
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
            }
            //以下是渠道主页获取渠道信息
            String url = "/views/main/main.jsp";
            Channels channels = channelsService.findChannelByUserId(user.getId());
            //渠道员工登录，登录首页权限和渠道一样
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("accountType", "5");
            
            // 公告map
            Map<String, Object> announcementMap = new HashMap<String, Object>();
            // 只能看到已发布的公告
            announcementMap.put("status", "1");
            // 最多显示3条记录
            announcementMap.put("limit", 0);
            announcementMap.put("offset", 3);
            //总部员工登录
            if(channels == null && user.getChannelId() == null){
                List<Role> roles = menuService.userRoleList(user.getId());
                if(roles != null && roles.size() > 0){
                    if(1 == roles.get(0).getId() || 4 == roles.get(0).getId()){
                        //跳转到市场人员/超级管理员主页
                        url = "/views/main/main.jsp";
                    }else if(3 == roles.get(0).getId()){
                        //跳转稽核人员主页界面
                        url =  "/views/main/jhmain.jsp";
                    }else if(5 == roles.get(0).getId()){
                        //仓管
                        url =  "/views/main/cgmain.jsp";
                    }else if(9 == roles.get(0).getId()){
                        //跳转到客服主页界面
                        url =  "/views/main/kfmain.jsp";
                    }else if(11 == roles.get(0).getId()){
                        //跳转到财务主页界面
                        url =  "/views/main/cwmain.jsp";
                    } else if(16 == roles.get(0).getId()){
                        // 跳转到汇杰核查主页界面
                        url =  "/views/main/hjhcmain.jsp";
                    }
                }
                
//            BigDecimal brokerageTotalMoney = channelAccountService.statisticsChannelBrokerage(map);
//            brokerageTotalMoney = brokerageTotalMoney.divide(new BigDecimal(100));
//            String allBrokerage = statisticsAllBrokerage(request, response, null, null);
//            BigDecimal brokerageTotalMoney = new BigDecimal(allBrokerage);
//            // 格式化佣金，小数点后截取两位
//            brokerageTotalMoney = Utils.formatBigDecimal(brokerageTotalMoney, "#,###.00");
//            request.setAttribute("brokerageTotalMoney", brokerageTotalMoney);
                
                /*Map<String, Object> params = new HashMap<String, Object>();
                // 获取当天时间
                String nowDate = DateUtil.getNowDateTimeString(DateUtil.yyyy_MM_dd);
                String startDate = nowDate + " 00:00:00";
                String endDate = nowDate + " 23:59:59";
                params.put("startDate", startDate);
                params.put("endDate", endDate);

                // 统计渠道下当天的开户量
                int dayAddCount = identityService.statisticsOpenCount(params);
                startDate = DateUtil.getFirstDateOfMonth();
                endDate = DateUtil.getLastDateOfMonth();
                params.put("startDate", startDate);
                params.put("endDate", endDate);
                // 统计渠道下当月的开户量
                int monthAddCount = identityService.statisticsOpenCount(params);
                params.put("startDate", "");
                params.put("endDate", "");
                // 统计渠道下全部开户量
                int totalAddCount = identityService.statisticsOpenCount(params);*/
                
                // 查询公告列表
                // 总部人员可以查看全部的公告，不用设置releaseObj属性
                List<Announcement> list = announcementService.list(announcementMap);
                // 由于公告条数不同，页面的展示也不同，需要根据条数设置样式
                String divClass = null;
                if (null!=list && list.size()>0) {
                    divClass = String.valueOf(list.size());
                } else {
                    // 为空时，显示跟只有一条记录的样式一样
                    divClass = "1";
                }
                /*request.setAttribute("dayAddCount", dayAddCount);
                request.setAttribute("monthAddCount", monthAddCount);
                request.setAttribute("totalAddCount", totalAddCount);*/
                request.setAttribute("announceList", list);
                request.setAttribute("divClass", divClass);
                
                return url;
            }

            Map<String, Object> params = new HashMap<String, Object>();
            if(channels.getChannelLevel() == 1){
                ChannelAccount channelAccountKK =channelAccountService.findByChannelIdAndType(channels.getId(), 1);
                ChannelAccount channelAccountHB =channelAccountService.findByChannelIdAndType(channels.getId(), 2);
                ChannelAccount channelAccountZC =channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                BigDecimal openMoney = channelAccountKK.getAccountBalanceYuan();
                BigDecimal allotMoney = channelAccountHB.getAccountBalanceYuan();
                BigDecimal rechargeMoney = channelAccountZC.getAccountBalanceYuan();
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 1);
                // 未处理的开卡账户订单金额
                BigDecimal freezeOpenMoney = orderDetailService.calcOrderMoney(param1);
                param1.put("accountType", 2);
                // 未处理的划拨账户订单金额
                BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                openMoney = openMoney.subtract(freezeOpenMoney);
                allotMoney = allotMoney.subtract(freezeAllotMoney);
                rechargeMoney = rechargeMoney.subtract(freezeRechargeMoney);
                
                BigDecimal accountAmount = openMoney.add(allotMoney).add(rechargeMoney);
                request.setAttribute("accountAmount", accountAmount.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("accountYE", allotMoney.add(rechargeMoney).setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("kkAmount", openMoney.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("hbAmount", allotMoney.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("zcAmount", rechargeMoney.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("loginType", 1);
                map.put("channelIdLevel1", channels.getId());
                params.put("channelLevel", "1");
                // 一级只能看到发布给代理商的公告 1：全部 2：代理商 3：网点
                announcementMap.put("releaseObj", "2");
            }else if(channels.getChannelLevel() == 2 && channels.getChannelType() ==1){
                ChannelAccount channelAccountHB =channelAccountService.findByChannelIdAndType(channels.getId(), 2);
                ChannelAccount channelAccountZC =channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                
                BigDecimal allotMoney = channelAccountHB.getAccountBalanceYuan();
                BigDecimal rechargeMoney = channelAccountZC.getAccountBalanceYuan();
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 2);
                // 未处理的划拨账户订单金额
                BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                allotMoney = allotMoney.subtract(freezeAllotMoney);
                rechargeMoney = rechargeMoney.subtract(freezeRechargeMoney);
                
                BigDecimal accountAmount = allotMoney.add(rechargeMoney);
                request.setAttribute("accountAmount", accountAmount.setScale(2,BigDecimal.ROUND_DOWN));
                request.setAttribute("kkAmount", 0);
                request.setAttribute("hbAmount", allotMoney.setScale(2,BigDecimal.ROUND_DOWN));
                request.setAttribute("zcAmount", rechargeMoney.setScale(2,BigDecimal.ROUND_DOWN));
                request.setAttribute("loginType",2);
                map.put("channelIdLevel2", channels.getId());
                params.put("channelLevel", "2");
                // 二级只能看到发布给代理商的公告 1：全部 2：代理商 3：网点
                announcementMap.put("releaseObj", "2");
            } else {
                ChannelAccount channelAccountHB =channelAccountService.findByChannelIdAndType(channels.getId(), 2);
                ChannelAccount channelAccountZC =channelAccountService.findByChannelIdAndType(channels.getId(), 3);
                ChannelAccount channelAccountZCYJ =channelAccountService.findByChannelIdAndType(channels.getId(), 6);
                
                BigDecimal allotMoney = channelAccountHB.getAccountBalanceYuan();
                BigDecimal rechargeMoney = channelAccountZC.getAccountBalanceYuan();
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("channelId", channels.getId());
                param1.put("accountType", 2);
                // 未处理的划拨账户订单金额
                BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                allotMoney = allotMoney.subtract(freezeAllotMoney);
                rechargeMoney = rechargeMoney.subtract(freezeRechargeMoney);
                BigDecimal accountAmount = allotMoney.add(rechargeMoney);
                
                request.setAttribute("accountAmount", accountAmount.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("kkAmount", 0);
                request.setAttribute("hbAmount", allotMoney.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("zcAmount", rechargeMoney.setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("zcyjAmount", channelAccountZCYJ.getAccountBalanceYuan().setScale(2, BigDecimal.ROUND_DOWN));
                request.setAttribute("loginType",3);
                map.put("channelId", channels.getId());
                params.put("channelLevel", "3");
                // 网点只能看到发布给代理商的公告 1：全部 2：代理商 3：网点
                announcementMap.put("releaseObj", "3");
            }

            /*params.put("channelId", channels.getId());
            // 获取当天时间
            String nowDate = DateUtil.getNowDateTimeString(DateUtil.yyyy_MM_dd);
            String startDate = nowDate + " 00:00:00";
            String endDate = nowDate + " 23:59:59";
            params.put("startDate", startDate);
            params.put("endDate", endDate);

            // 统计渠道下当天的开户量
            int dayAddCount = identityService.statisticsOpenCount(params);
            startDate = DateUtil.getFirstDateOfMonth();
            endDate = DateUtil.getLastDateOfMonth();
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            // 统计渠道下当月的开户量
            int monthAddCount = identityService.statisticsOpenCount(params);
            params.put("startDate", "");
            params.put("endDate", "");
            // 统计渠道下全部开户量
            int totalAddCount = identityService.statisticsOpenCount(params);*/
            
            BigDecimal brokerageTotalMoney = channelAccountService.statisticsChannelBrokerage(map);
            brokerageTotalMoney = brokerageTotalMoney.divide(new BigDecimal(100));
            brokerageTotalMoney = brokerageTotalMoney.setScale(2,BigDecimal.ROUND_DOWN);
            
            // 查询公告列表
            List<Announcement> list = announcementService.list(announcementMap);
            // 由于公告条数不同，页面的展示也不同，需要根据条数设置样式
            String divClass = null;
            if (null!=list && list.size()>0) {
                divClass = String.valueOf(list.size());
            } else {
                // 为空时，显示跟只有一条记录的样式一样
                divClass = "1";
            }
            
            request.setAttribute("brokerageTotalMoney", brokerageTotalMoney);
            request.setAttribute("channels", channels);
            /*request.setAttribute("dayAddCount", dayAddCount);
            request.setAttribute("monthAddCount", monthAddCount);
            request.setAttribute("totalAddCount", totalAddCount);*/
            request.setAttribute("announceList", list);
            request.setAttribute("divClass", divClass);

            return "/views/main/channelmain.jsp";
        } catch (Exception e) {
            logger.error("系统异常："+e.getMessage(), e);
        }
        return "/views/main/channelmain.jsp";
    }
    
    //加值记录[财务人员主页]
    @SuppressWarnings("static-access")
    @RequestMapping("/autoaccount")
    public String autoaccount(HttpServletRequest request, HttpSession session, ChannelAccountTransaction transaction, Integer pageSize, Integer pageIndex) {
            
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);

        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotBlank(transaction.getChannelName())) {
            params.put("channelName", transaction.getChannelName());
        }
        
        if (transaction.getPayType() != null) {
            params.put("payType", transaction.getPayType());
        }
        
        if (transaction.getcTime() != null) {
            String month = DateUtil.getNowDateTimeString("yyyy-MM");
            Calendar calendar=Calendar.getInstance();   
            calendar.setTime(new Date());
            calendar.add(calendar.MONTH, -1);
            Date date = calendar.getTime();
            String lastMonth = DateUtil.getTimeStringByDate(date, "yyyy-MM");
            if(transaction.getcTime() == 1){
                params.put("lastMonth", lastMonth + "-01 00:00:00");
            }
            params.put("month", month + "-01 00:00:00");
            params.put("cTime", transaction.getcTime());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<ChannelAccountTransaction> transactionList = transactionService.listAddTransation(params);
        int total = transactionService.countAddTotal(params);
        BigDecimal sum = transactionService.sumTransactionMoney(params);
        pageEntity.setTotal(total);

        request.setAttribute("transactionList", transactionList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("transaction", transaction);
        request.setAttribute("sum", sum);
        
        return "/views/main/account/autoaccount.jsp";
    }
    
    //加值
    @RequestMapping(value = "/addAccount")
    public String addAccount(HttpServletRequest request , HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
        }
        
        //当前渠道ID
        Integer id = Integer.parseInt(request.getParameter("id"));
        PayTracode payTracode = payTracodeService.selectByChannelId(id);
        request.setAttribute("payTracode", payTracode);

        return "/views/main/channel/addaccount.jsp";
    }
    
    @RequestMapping(value = "/accountHb")
    public String accountHb(HttpServletRequest request ){
        
        //当前渠道ID
        Integer id = Integer.parseInt(request.getParameter("id"));
        Channels channels = channelsService.findById(id);
        //查找当前渠道的划拨账户、直充账户
        ChannelAccount channelAccountHb = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
        ChannelAccount channelAccountZc = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
        
        BigDecimal allotMoney = channelAccountHb.getAccountBalanceYuan();
        BigDecimal rechargeMoney = channelAccountZc.getAccountBalanceYuan();
        Map<String, Object> param1 = new HashMap<String, Object>();
        param1.put("channelId", channels.getId());
        param1.put("accountType", 2);
        // 未处理的划拨账户订单金额
        BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
        param1.put("accountType", 3);
        // 未处理的充值账户订单金额
        BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
        allotMoney = allotMoney.subtract(freezeAllotMoney);
        rechargeMoney = rechargeMoney.subtract(freezeRechargeMoney);
        BigDecimal accountAmount = allotMoney.add(rechargeMoney);
        
        request.setAttribute("accountBalance", accountAmount);
        request.setAttribute("channelId", id);
        
        return "/views/main/channel/accountHb.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountHb"}, method = RequestMethod.POST)
    public RestStatus saveAccountHb(HttpServletRequest request ,Channels channels, HttpSession session){
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount  ="";
        
        Channels channel = channelsService.findChannelByUserId(user.getId());
            
        if(channel != null){
            transactionAccount = "[" + channel.getChannelCode() + "] " + channel.getChannelName();
        }else{
//            transactionAccount = "总部：" + user.getNickName();
            return new RestStatus(Boolean.FALSE, "500", "当前用户不是代理商用户，不能进行划拨操作！");
        }
        
        if(channel.getId().intValue() != channels.getParentChannelId().intValue()) {
            return new RestStatus(Boolean.FALSE, "500", "参数异常，不能进行划拨操作");
        }
        
        Channels c = channelsService.findChannelByCodeAndPid(channels.getChannelCode(), String.valueOf(channels.getParentChannelId()));
        if(c == null) {
            return new RestStatus(Boolean.FALSE, "500", "您输入的渠道编号(" + channels.getChannelCode() + ")不是您的下级渠道/网点或网点未生效，将不能进行划拨，请重新输入渠道编号！");
        }
        
        if(c.getId().intValue() != channels.getId()) {
            return new RestStatus(Boolean.FALSE, "500", "参数异常，不能进行划拨操作");
        }
        
        if(channels.getAccountBalanceHb() == null || channels.getAccountBalanceHb().compareTo(BigDecimal.ZERO) <= 0){
            return new RestStatus(Boolean.FALSE, "500", "您输入的划拨金额("+channels.getAccountBalanceHb()+")错误！");
        }
        
        try {
            restStatus = channelsService.saveAccountHb(channels, user.getId(), transactionAccount, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new RestStatus(Boolean.FALSE, "500", "划拨操作失败！");
        }
        
        return restStatus;
    }
    
    @RequestMapping(value = "/accountCorrect")
    public String accountCorrect(HttpServletRequest request ){
        Integer id = Integer.parseInt(request.getParameter("id"));
        request.setAttribute("channelId", id);
        return "/views/main/channel/accountCorrect.jsp";
    }
    
    @ResponseBody
    @RequestMapping(value = {"/saveAccountCorrect"}, method = RequestMethod.POST)
    public RestStatus saveAccountCorrect(HttpServletRequest request ,Channels channels, HttpSession session){
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        
        String transactionAccount  ="";
        
        Channels channel = channelsService.findChannelByUserId(user.getId());
            
        if(channel != null){
            transactionAccount = "[" + channel.getChannelCode() + "] " + channel.getChannelName();
        }else{
//            transactionAccount = "总部：" + user.getNickName();
            return new RestStatus(Boolean.FALSE, "500", "当前用户不是代理商用户，不能进行纠正操作！");
        }
        
        if(channel.getId().intValue() != channels.getParentChannelId().intValue()) {
            return new RestStatus(Boolean.FALSE, "500", "参数异常，不能进行纠正操作");
        }
        
        Channels c = channelsService.findChannelByCodeAndPid(channels.getChannelCode(), String.valueOf(channels.getParentChannelId()));
        if(c == null) {
            return new RestStatus(Boolean.FALSE, "500", "您输入的渠道编号(" + channels.getChannelCode() + ")不是您的下级渠道/网点或网点未生效，将不能进行纠正，请重新输入渠道编号！");
        }
        
        if(c.getId().intValue() != channels.getId()) {
            return new RestStatus(Boolean.FALSE, "500", "参数异常，不能进纠正操作");
        }
        
        if(channels.getAccountBalanceHb() == null || channels.getAccountBalanceHb().compareTo(BigDecimal.ZERO) <= 0){
            return new RestStatus(Boolean.FALSE, "500", "您输入的纠正金额("+channels.getAccountBalanceHb()+")错误！");
        }
        
        try {
            restStatus = channelsService.saveAccountCorrect(channels, user.getId(), transactionAccount, user);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new RestStatus(Boolean.FALSE, "500", "纠正操作失败！");
        }
        
        return restStatus;
    }
    
    /**
     * 渠道查找下级渠道总个数
     * @param channelId  当前渠道ID，当总部人员查询时，当前渠道ID为空
     * @param channelLevel   查找的渠道级别
     * @param level    当前渠道级别,level=0表示是总部人员
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/findChannelByChannelIdLevel")
    public Integer findChannelByChannelIdLevel(Integer channelId, Integer channelLevel, Integer level){
        return channelsService.findChannelByChannelIdLevel(channelId, channelLevel, level);
    }
    
    /**
     * 渠道查找下级渠道详情
     * @param channelId  当前渠道ID，当总部人员查询时，当前渠道ID为空
     * @param channelLevel   查找的渠道级别
     * @param level    当前渠道级别,level=0表示是总部人员
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/findChannelDetailByChannelIdLevel")
    public List<Channels> findChannelDetailByChannelIdLevel(Integer channelId, Integer channelLevel, Integer level){
        return channelsService.findChannelDetailByChannelIdLevel(channelId, channelLevel, level);
    }
    
    /**
     * 渠道查找下级渠道总个数
     * @param channelId  当前渠道ID，当总部人员查询时，当前渠道ID为空
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/findThreeChannelByChannelId")
    public Integer findThreeChannelByChannelId(Integer channelId, Integer level){
        return channelsService.findThreeChannelByChannelId(channelId, level);
    }
    
    /**
     * 开户待审核数
     * @param channelId  当前渠道ID，当总部人员查询时，当前渠道ID为空
     * @param channelLevel 渠道级别
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/findAuditCountByChannelId")
    public Integer findAuditCountByChannelId(Integer channelLevel, Integer channelId){
        return numberService.findAuditCountByChannelId(channelLevel, channelId);
    }


    /**
     * 库存总统计
     * @param model
     * @return
     */
    @RequestMapping(value = "stock-data", method = RequestMethod.POST)
    @ResponseBody
    public DetailDTO<Map<String,Integer>> stockCntList(Model model, HttpServletRequest request) {
        try{
            Map<String,Integer> cntMap = new HashMap<String,Integer>();
            Integer loginType = 0;
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            if(null == ch){
                loginType = 0;
            }else if(Channels.CHANNEL_LEVEL_1.intValue() == ch.getChannelLevel().intValue()){
                loginType = 1;
            }else if(Channels.CHANNEL_LEVEL_2.intValue() == ch.getChannelLevel().intValue()
                    && Channels.CHANNEL_TYPE_1.intValue() == ch.getChannelType().intValue()){
                loginType = 2;
            }else{
                loginType = 3;
            }
            model.addAttribute("loginType",loginType);
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("statisticsType", Utils.isEmptyString(request.getParameter("statisticsType")) ? "" : request.getParameter("statisticsType"));
            cntMap =  stockService.stockCnt(loginType,ch,searchMap);
            return new DetailDTO<Map<String,Integer>>(true,cntMap);
        }catch (Exception e){
            logger.error("查询登录账户库存统计信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new DetailDTO<Map<String,Integer>>(false,"500","查询库存统计失败");
        }
    }
    
    /**
     * 根据路径查找菜单信息
     * @param path
     * @return
     */
    @RequestMapping(value = "/findPrivByPath")
    public @ResponseBody Privilege findPrivByPath(String path) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("path", path);
        List<Privilege> list = menuService.findPrivByCondition(map);
        if (null!=list && list.size()>0) {
            return (Privilege)list.get(0);
        }
        return null;
    }
    
    
  //加值记录导出[财务人员主页]
    @SuppressWarnings({"unchecked", "rawtypes", "static-access" })
    @RequestMapping(value="/autoaccountexport",method=RequestMethod.GET)
    public void autoAccountExport(HttpServletRequest request, HttpServletResponse response, ChannelAccountTransaction transaction, Integer pageSize) {
        try {
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
    
            Map<String, Object> params = new HashMap<String, Object>();
    
            if (StringUtils.isNotBlank(transaction.getChannelName())) {
                params.put("channelName", transaction.getChannelName());
            }
            
            if (transaction.getPayType() != null) {
                params.put("payType", transaction.getPayType());
            }
            
            if (transaction.getcTime() != null) {
                String month = DateUtil.getNowDateTimeString("yyyy-MM");
                Calendar calendar=Calendar.getInstance();   
                calendar.setTime(new Date());
                calendar.add(calendar.MONTH, -1);
                Date date = calendar.getTime();
                String lastMonth = DateUtil.getTimeStringByDate(date, "yyyy-MM");
                if(transaction.getcTime() == 1){
                    params.put("lastMonth", lastMonth + "-01 00:00:00");
                }
                params.put("month", month + "-01 00:00:00");
                params.put("cTime", transaction.getcTime());
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
    
            params.put("limit", limit);
            params.put("offset", offset);
            List<ChannelAccountTransaction> list = transactionService.listAddTransation(params);
            String dateStr = DateUtil.getInstance().getNowDateTimeString("yyyyMMdd");
            String downloadName = "财务加值记录详情导出" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"加值时间","加值渠道名称","渠道编码","渠道属性","归属一级渠道","归属二级渠道","加值金额","实际支付金额", "交易码", "支付方式"};
            properties = new String[]{"operationTimeStr","channelName","channelCode","channelLevelStr","channelIdName1","channelIdName2","transactionMoneyYuan",
                    "transactionMoneyRealYuan","transactionFlow","payName"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(),headers,list,properties);
        } catch (IOException e) {
            logger.info("总部财务加值记录导出失败");
            e.printStackTrace();
        }
    }
    
    @ResponseBody
    @RequestMapping(value = "/statisticsBrokerage")
    public String statisticsBrokerage(HttpServletRequest request, HttpServletResponse response, 
            Integer channelLevel, Integer channelId) {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            // 渠道员工登录，登录首页权限和渠道一样
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            // 渠道当前的级别
            if (null != channels) {
                Integer currentChannelLevel = channels.getChannelLevel();
                Integer currentChannelType = channels.getChannelType();
                map.put("currentChannelId", channels.getId());
                map.put("currentChannelType", currentChannelType);
                if (currentChannelLevel == 1) {
                    // 一级
                    if (channelLevel == 1) {
                        map.put("currentChannelLevel", "0");
                    } else {
                        map.put("currentChannelLevel", "1");
                    }
                } else if (currentChannelLevel==2 && currentChannelType == 1) {
                    // 二级
                    if (channelLevel == 2) {
                        map.put("currentChannelLevel", "0");
                    } else {
                        map.put("currentChannelLevel", "2");
                    }
                } else {
                    // 网点和直属网点
                    map.put("currentChannelLevel", "0");
                }
            }
            map.put("channelId", channelId);
            map.put("accountType", "5");
            map.put("channelLevel", channelLevel);
            
            BigDecimal brokerageMoney = channelAccountService.statisticsChannelBrokerage(map);
            brokerageMoney = Utils.formatBigDecimal(brokerageMoney.divide(Constant.cnt100), "#,###.00");
            return brokerageMoney.toString();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "0.00";
    }
    
    @ResponseBody
    @RequestMapping(value = "/statistics170Brokerage")
    public String statistics170Brokerage(HttpServletRequest request, HttpServletResponse response, 
            Integer channelLevel, Integer channelId) {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            // 渠道员工登录
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            // 渠道当前的级别
            if (null != channels) {
                Integer currentChannelLevel = channels.getChannelLevel();
                Integer currentChannelType = channels.getChannelType();
                map.put("currentChannelId", channels.getId());
                map.put("currentChannelType", currentChannelType);
                if (currentChannelLevel == 1) {
                    // 一级
                    if (channelLevel == 1) {
                        map.put("currentChannelLevel", "0");
                    } else {
                        map.put("currentChannelLevel", "1");
                    }
                } else if (currentChannelLevel==2 && currentChannelType == 1) {
                    // 二级
                    if (channelLevel == 2) {
                        map.put("currentChannelLevel", "0");
                    } else {
                        map.put("currentChannelLevel", "2");
                    }
                } else {
                    // 网点和直属网点
                    map.put("currentChannelLevel", "2");
                }
            }
            map.put("channelLevel", channelLevel);
            
            String sttlDateYm = DateUtil.getInstance().getDateStr(new Date(), "yyyyMM");
            map.put("tableName", "t_boss_service_his_"+sttlDateYm);
            BigDecimal brokerageMoney = bossServiceHisService.statistics170Brokerage(map);
            String money = Constant.df0.format(brokerageMoney.divide(Constant.cnt100));
            return money;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "0.00";
    }
    
    @ResponseBody
    @RequestMapping(value = "/statisticsAllBrokerage")
    public String statisticsAllBrokerage(HttpServletRequest request, HttpServletResponse response, 
            Integer channelLevel, Integer channelId) {
        String brokerageMoneyStr = statisticsBrokerage(request, response, channelLevel, channelId);
        String brokerageMoney170Str = statistics170Brokerage(request, response, channelLevel, channelId);
        BigDecimal brokerageMoney = new BigDecimal(brokerageMoneyStr);
        BigDecimal brokerageMoney170 = new BigDecimal(brokerageMoney170Str);
        BigDecimal brokerageTotalMoney = Utils.formatBigDecimal(brokerageMoney.add(brokerageMoney170), "#,###.00");
        return brokerageTotalMoney.toString();
    }
    
    @RequestMapping(value = "/countBro")
    public String countBro(HttpServletRequest request, HttpServletResponse response) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if (null != channels) {
            request.setAttribute("channels", channels);
        }
        return "/views/main/brokerage/bro_statistics.jsp";
    }

    @RequestMapping(value = "/countChannelBro")
    public String countChannelBro(HttpServletRequest request, HttpServletResponse response, 
            String channelInfo, String searchTime, Integer channelLevel, Integer channelId, 
            Integer trailLevel1, Integer trailLevel2, Integer trailLevel3, Integer channelType,
            Integer channelIdLevel1, Integer channelIdLevel2, Integer channelIdLevel3,
            Integer fromMainPage, Integer fromPageLevel, Integer pageIndex, Integer pageSize) {
        Map<String, Object> map = new HashMap<String, Object>();
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if (channels == null && user.getChannelId() != null) {
            channels = channelsService.findById(user.getChannelId());
        }
        if (null == channelLevel) {
            channelLevel = 0;
        }
        map.put("channelLevel", channelLevel);
        map.put("channelType", channelType);
        
        // 当前登录的渠道ID和级别
        if (null != channels) {
            Integer currentChannelType = channels.getChannelType();
            map.put("currentChannelId", channels.getId());
            map.put("currentChannelType", currentChannelType);
            Integer currentChannelLevel = channels.getChannelLevel();
            if (currentChannelLevel == 1) {
                // 一级
                if (channelLevel == 1) {
                    map.put("currentChannelLevel", "0");
                } else {
                    map.put("currentChannelLevel", "1");
                }
            } else if (currentChannelLevel==2 && currentChannelType == 1) {
                // 二级
                if (channelLevel == 2) {
                    map.put("currentChannelLevel", "0");
                } else {
                    map.put("currentChannelLevel", "2");
                }
            } else {
                // 网点和直属网点
                map.put("currentChannelLevel", "0");
            }
        }
        
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;
        channelInfo = null==channelInfo?"":channelInfo.trim();
        if (StringUtils.isNotEmpty(channelInfo)) {
            map.put("channelInfo", channelInfo);
        }
        
        // 上月
        if ("1".equals(searchTime)) {
            String startDate = DateUtil.getLastMonthFirstDay();
            String endDate = DateUtil.getLastMonthLastDay();
            map.put("startDate", startDate+" 00:00:00");
            map.put("endDate", endDate+" 23:59:59");
        } else if ("2".equals(searchTime)) {
            // 本月
            String startDate = DateUtil.getCurrentMonthFirstDay();
            String endDate = DateUtil.getCurrentMonthLastDay();
            map.put("startDate", startDate+" 00:00:00");
            map.put("endDate", endDate+" 23:59:59");
        }
        
        if (null != channelId) {
            if (null!=fromPageLevel && 1==fromPageLevel) {
                map.put("channelIdLevel1", channelId);
            } else if (null!=fromPageLevel && 2==fromPageLevel) {
                map.put("channelIdLevel2", channelId);
            } else if (null!=fromPageLevel && 3==fromPageLevel) {
                map.put("channelIdLevel3", channelId);
            }
        }
        
        map.put("limit", limit);
        map.put("offset", offset);
        
        List<Channels> list = channelsService.countLevelBro(map);
        int total = channelsService.countLevelBroTotal(map);
        pageEntity.setTotal(total);
        request.setAttribute("broList", list);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("channelInfo", channelInfo);
        request.setAttribute("fromPageLevel", fromPageLevel);
        request.setAttribute("channelLevel", channelLevel);
        request.setAttribute("channelId", channelId);
        request.setAttribute("searchTime", searchTime);
        request.setAttribute("fromMainPage", fromMainPage);
        request.setAttribute("trailLevel1", trailLevel1);
        request.setAttribute("trailLevel2", trailLevel2);
        request.setAttribute("trailLevel3", trailLevel3);
        request.setAttribute("channelIdLevel1", channelIdLevel1);
        request.setAttribute("channelIdLevel2", channelIdLevel2);
        request.setAttribute("channelIdLevel3", channelIdLevel3);
        request.setAttribute("channelType", channelType);
        
        String result = null;
        if (1 == channelLevel) {
            result = "/views/main/brokerage/bro_channellevel1.jsp";
        } else if (2 == channelLevel) {
            result = "/views/main/brokerage/bro_channellevel2.jsp";
        } else {
            result = "/views/main/brokerage/bro_channellevel3.jsp";
        }
        return result;
    }

    @RequestMapping(value = "/getOrderBroDetail")
    public String getOrderBroDetail(HttpServletRequest request, HttpServletResponse response, 
            String channelName, String msisdn, String startDate, String endDate, Integer fromPageLevel,
            Integer fromMainPage, Integer channelLevel, Integer channelId, 
            Integer trailLevel1, Integer trailLevel2, Integer trailLevel3,
            Integer channelIdLevel1, Integer channelIdLevel2, Integer channelIdLevel3,
            Integer pageIndex, Integer pageSize) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        Channels channels = channelsService.findChannelByUserId(user.getId());
        Integer channelType = null;
        if(channels == null && user.getChannelId() != null){
            channels = channelsService.findById(user.getChannelId());
        }
        
        Map<String, Object> map = new HashMap<String, Object>();
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;
        channelName = null==channelName?"":channelName.trim();
        if (StringUtils.isNotEmpty(channelName)) {
            map.put("channelName", channelName);
        }
        msisdn = null==msisdn?"":msisdn.trim();
        if (StringUtils.isNotEmpty(msisdn)) {
            map.put("msisdn", msisdn);
        }
        if (StringUtils.isNotEmpty(startDate)) {
            map.put("startDate", startDate+" 00:00:00");
        }
        if (StringUtils.isNotEmpty(endDate)) {
            map.put("endDate", endDate+" 23:59:59");
        }
        if (null != channelLevel) {
            map.put("channelLevel", channelLevel);
        }
        if (null != channelId) {
            map.put("channelId", channelId);
            Channels channelTmp = channelsService.findById(channelId);
            if (null != channelTmp) {
                channelType = channelTmp.getChannelType(); 
                map.put("channelType", channelType);
            }
        }
        
        map.put("limit", limit);
        map.put("offset", offset);
        
        List<RechargeRecord> list = rechargeRecordService.getOrderBroDetail(map);
        int total = rechargeRecordService.countOrderBroDetail(map);
        pageEntity.setTotal(total);
        request.setAttribute("broList", list);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("channelName", channelName);
        request.setAttribute("msisdn", msisdn);
        request.setAttribute("startDate", startDate);
        request.setAttribute("endDate", endDate);
        request.setAttribute("channelLevel", channelLevel);
        request.setAttribute("channelType", channelType);
        request.setAttribute("channelId", channelId);
        request.setAttribute("fromPageLevel", fromPageLevel);
        request.setAttribute("fromMainPage", fromMainPage);
        request.setAttribute("trailLevel1", trailLevel1);
        request.setAttribute("trailLevel2", trailLevel2);
        request.setAttribute("trailLevel3", trailLevel3);
        request.setAttribute("channelIdLevel1", channelIdLevel1);
        request.setAttribute("channelIdLevel2", channelIdLevel2);
        request.setAttribute("channelIdLevel3", channelIdLevel3);
        request.setAttribute("channels", channels);
        
        return "/views/main/brokerage/agent_bro_list.jsp";
    }

    @RequestMapping(value = "/returnBack")
    public String returnBack(HttpServletRequest request, HttpServletResponse response, 
            Integer channelLevel, Integer fromPageLevel, Integer channelId, Integer fromMainPage,
            Integer trailLevel1, Integer trailLevel2, Integer trailLevel3,
            Integer channelIdLevel1, Integer channelIdLevel2, Integer channelIdLevel3,
            Integer pageIndex, Integer pageSize) {
        Map<String, Object> map = new HashMap<String, Object>();
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if(channels == null && user.getChannelId() != null){
            channels = channelsService.findById(user.getChannelId());
        }
        // 当前登录的渠道ID和级别
        if (null != channels) {
            Integer currentChannelLevel = channels.getChannelLevel();
            Integer currentChannelType = channels.getChannelType();
            map.put("currentChannelId", channels.getId());
            map.put("currentChannelType", currentChannelType);
            if (currentChannelLevel == 1) {
                // 一级
                if (channelLevel == 1) {
                    map.put("currentChannelLevel", "0");
                } else {
                    map.put("currentChannelLevel", "1");
                }
            } else if (currentChannelLevel==2 && currentChannelType == 1) {
                // 二级
                if (channelLevel == 2) {
                    map.put("currentChannelLevel", "0");
                } else {
                    map.put("currentChannelLevel", "2");
                }
            } else {
                // 网点和直属网点
                map.put("currentChannelLevel", "0");
            }
        }
        
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;
        if (null != channelLevel) {
            map.put("channelLevel", channelLevel);
        }
        
        if (null!=fromPageLevel && 2==fromPageLevel) {
            map.put("channelIdLevel1", channelIdLevel1);
        } else if (null!=fromPageLevel && 3==fromPageLevel) {
            map.put("channelIdLevel2", channelIdLevel2);
            if (null != channelIdLevel2) {
                Channels channelTmp = channels = channelsService.findById(channelIdLevel2);
                map.put("channelType", channelTmp.getChannelType());
            }
        }
        
        map.put("limit", limit);
        map.put("offset", offset);
        
        List<Channels> list = channelsService.countLevelBro(map);
        int total = channelsService.countLevelBroTotal(map);
        pageEntity.setTotal(total);
        request.setAttribute("broList", list);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("fromPageLevel", fromPageLevel);
        request.setAttribute("channelLevel", channelLevel);
        request.setAttribute("channelId", channelId);
        request.setAttribute("fromMainPage", fromMainPage);
        request.setAttribute("trailLevel1", trailLevel1);
        request.setAttribute("trailLevel2", trailLevel2);
        request.setAttribute("trailLevel3", trailLevel3);
        request.setAttribute("channelIdLevel1", channelIdLevel1);
        request.setAttribute("channelIdLevel2", channelIdLevel2);
        request.setAttribute("channelIdLevel3", channelIdLevel3);
        
        String result = null;
        if (null!=fromPageLevel && 1==fromPageLevel) {
            result = "/views/main/brokerage/bro_channellevel1.jsp";
        } else if (null!=fromPageLevel && 2==fromPageLevel) {
            result = "/views/main/brokerage/bro_channellevel2.jsp";
        } else {
            result = "/views/main/brokerage/bro_channellevel3.jsp";
        }
        return result;
    }
    
    @RequestMapping(value = "/openNumberStatistics")
    @ResponseBody
    public Integer openNumberStatistics(HttpServletRequest request, HttpServletResponse response, String type) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
        }
        //以下是渠道主页获取渠道信息
        Channels channels = channelsService.findChannelByUserId(user.getId());
        //渠道员工登录，登录首页权限和渠道一样
        if(channels == null && user.getChannelId() != null){
            channels = channelsService.findById(user.getChannelId());
        }
        Integer cnt = 0;
        Map<String, Object> params = new HashMap<String, Object>();
        if (null != channels) {
            if (channels.getChannelLevel() == 1) {
                params.put("channelLevel", "1");
            } else if (channels.getChannelLevel() == 2 && channels.getChannelType() ==1) {
                params.put("channelLevel", "2");
            } else {
                params.put("channelLevel", "3");
            }
            params.put("channelId", channels.getId());
        }
        
        // 获取当天时间
        String nowDate = DateUtil.getNowDateTimeString(DateUtil.yyyy_MM_dd);
        String startDate = nowDate + " 00:00:00";
        String endDate = nowDate + " 23:59:59";
        if ("1".equals(type)) {
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            // 统计渠道下当天的开户量
            cnt = identityService.statisticsOpenCount(params);
        } else if ("2".equals(type)) {
            startDate = DateUtil.getFirstDateOfMonth();
            endDate = DateUtil.getLastDateOfMonth();
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            // 统计渠道下当月的开户量
            cnt = identityService.statisticsOpenCount(params);
        } else {
            params.put("startDate", "");
            params.put("endDate", "");
            // 统计渠道下全部开户量
            cnt = identityService.statisticsOpenCount(params);
        }
        return cnt;
    }
    
    /**
     * 通过点击按钮处理BOSS话单，仅对admin开放，有权限控制"/boss/cdr"
     * @param request
     * @param response
     */
    @RequestMapping(value = "/cdrStatistics")
    public void cdrStatistics(HttpServletRequest request, HttpServletResponse response) {
        fileDataCdrDownloadJob.execute();
    }
    
    /**
     * 同步方法测试，仅供测试使用
     * @param request
     * @param response
     */
    @RequestMapping(value = "/threadTest")
    public void threadTest(HttpServletRequest request, HttpServletResponse response) {
        threadTest.execute();
    }
}
