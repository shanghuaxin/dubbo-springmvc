package com.agent.online.entity;

import java.io.Serializable;
import java.util.Date;

import com.agent.online.common.OlBaseDomain;

/**
 * 审批表
 */
public class OlCheck extends OlBaseDomain implements Serializable {

    private static final long serialVersionUID = -3454663429972875144L;
    private Integer sourceId;     //来源id
    private String sourceType;    //来源类型：1.实名补录   2.补换卡
    private String phone;         //号码
    private String status;        //状态（1待审核，2审核通过，3审核不通过，4取消）
    private Date passDate;        //通过时间
    private String checkOpinion;  //审批意见
    private Integer createId;     //创建人
    private Integer updateId;     //修改人

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getPassDate() {
        return passDate;
    }

    public void setPassDate(Date passDate) {
        this.passDate = passDate;
    }

    public String getCheckOpinion() {
        return checkOpinion;
    }

    public void setCheckOpinion(String checkOpinion) {
        this.checkOpinion = checkOpinion;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    @Override
    public String toString() {
        return "Check [sourceId=" + sourceId + ", sourceType=" + sourceType + ", phone=" + phone + ", status=" + status
                + ", passDate=" + passDate + ", checkOpinion=" + checkOpinion + ", createId=" + createId + ", updateId="
                + updateId + "]";
    }

}
