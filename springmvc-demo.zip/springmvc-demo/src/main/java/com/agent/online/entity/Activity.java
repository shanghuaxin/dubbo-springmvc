package com.agent.online.entity;

import com.agent.common.BaseDomain;
import com.agent.common.enumeration.ActivityType;

public class Activity extends BaseDomain {
    
    private static final long serialVersionUID = 8621367838098678392L;
    private String activityName;
    private String activityImagePath;
    private String activityLink;
    // 活动类型：1.轮播图 2.活动 3.移动专区 4.联通专区 5.更多产品
    private Integer activityType;
    // 大标题
    private String titleBig;
    // 小标题
    private String titleSmall;
    private String effectDate;
    private String expiryDate;
    private Integer sort;
    private Integer status;
    private String remark;
    
    public String getActivityName() {
        return activityName;
    }
    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }
    public String getActivityImagePath() {
        return activityImagePath;
    }
    public void setActivityImagePath(String activityImagePath) {
        this.activityImagePath = activityImagePath;
    }
    public String getActivityLink() {
        return activityLink;
    }
    public void setActivityLink(String activityLink) {
        this.activityLink = activityLink;
    }
    public Integer getActivityType() {
        return activityType;
    }
    public String getActivityTypeStr(Integer activityType) {
        if (null != activityType) {
            return ActivityType.getName(activityType);
        }
        return activityType+"";
    }
    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }
    public String getTitleBig() {
        return titleBig;
    }
    public void setTitleBig(String titleBig) {
        this.titleBig = titleBig;
    }
    public String getTitleSmall() {
        return titleSmall;
    }
    public void setTitleSmall(String titleSmall) {
        this.titleSmall = titleSmall;
    }
    public String getEffectDate() {
        return effectDate;
    }
    public void setEffectDate(String effectDate) {
        this.effectDate = effectDate;
    }
    public String getExpiryDate() {
        return expiryDate;
    }
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
