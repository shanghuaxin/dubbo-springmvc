package com.agent.online.entity;

import java.math.BigDecimal;

import com.agent.online.common.OlBaseDomain;

/**
 * 充值记录表
 * @author zhangwei
 *
 */
public class OlRecharge extends OlBaseDomain{

    /**
     * 
     */
    private static final long serialVersionUID = 3348509435590000383L;
    /** 充话费 */
    public static final String R_TYPE_1 = "1";
    /** 充流量 */
    public static final String R_TYPE_2 = "2";
    /** 网厅充值 */
    public static final String SOURCE_TYPE_ONLINE = "online";
    /** 掌厅充值 */
    public static final String SOURCE_TYPE_WAP = "wap";
    /** 微信公众号*/
    public static final String SOURCE_TYPE_MP = "wx_mp";
    
    
    private String orderNo;//订单编号
    private String buyOrderNo;//流量平台订单编号
    private String userIp;//操作ip
    private Integer dctId;//优惠表id
    private String phone;//充值号码
    private String rType;//充值类型：1-充值，2-充流量
    private String payType;//支付方：alipay_ol：支付宝，wx_ol：微信，card_yeepay:易宝支付，card_pay:19PAY支付，card_dx:鼎信支付支付
    private String payStatus;//支付状态：1-成功，2-待支付，3-失败
    private String rStatus;//充值状态：1-成功，2-待充值，3-接口失败，4-充值失败
    private BigDecimal money;//充值金额
    private BigDecimal accountBalance;//实际支付金额
    private Integer proId;//产品id
    private String proCode;//产品编号
    private String proName;//商品名称（30元话费，500M流量）
    private String proRemark;//商品描述（充30元省0.99元）
    private String errorMsg;//错误信息
    private String remark;//备注
    private String sourceType;//充值来源：online-网厅，wap-掌厅
    private String loginName;//登录账号
    
    
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public String getBuyOrderNo() {
        return buyOrderNo;
    }
    public void setBuyOrderNo(String buyOrderNo) {
        this.buyOrderNo = buyOrderNo;
    }
    public String getUserIp() {
        return userIp;
    }
    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }
    public Integer getDctId() {
        return dctId;
    }
    public void setDctId(Integer dctId) {
        this.dctId = dctId;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getrType() {
        return rType;
    }
    public void setrType(String rType) {
        this.rType = rType;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public BigDecimal getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }
    public Integer getProId() {
        return proId;
    }
    public void setProId(Integer proId) {
        this.proId = proId;
    }
    public String getProName() {
        return proName;
    }
    public void setProName(String proName) {
        this.proName = proName;
    }
    public String getProRemark() {
        return proRemark;
    }
    public void setProRemark(String proRemark) {
        this.proRemark = proRemark;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getProCode() {
        return proCode;
    }
    public void setProCode(String proCode) {
        this.proCode = proCode;
    }
    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    public String getLoginName() {
        return loginName;
    }
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
    public String getPayStatus() {
        return payStatus;
    }
    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }
    public String getrStatus() {
        return rStatus;
    }
    public void setrStatus(String rStatus) {
        this.rStatus = rStatus;
    }
    public String getPayType() {
        return payType;
    }
    public void setPayType(String payType) {
        this.payType = payType;
    }
    public String getSourceType() {
        return sourceType;
    }
    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }
}