package com.agent.online.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.online.dto.BizDTO;
import com.agent.online.entity.Biz;

public interface BizMapper extends BaseMapper<Biz, Integer> {
    
    public Biz findById(@Param(value="id") Integer id);
    
    public BizDTO findRealnameById(@Param(value="id") Integer id);
    
    public BizDTO findSIMById(@Param(value="id") Integer id);
    
    public List<BizDTO> listRealname(Map<String, Object> params);
    
    public int countRealName(Map<String, Object> params);
    
    public List<BizDTO> listduplicateSIM(Map<String, Object> params);

    public int countDuplicateSIM(Map<String, Object> params);
    
    public int updateSimCancle(@Param(value="bizId") Integer bizId);
    
    public List<BizDTO> listCancel(Map<String, Object> params);

    public int countCancle(Map<String, Object> params);
    
    public Biz findByPhoneAndType(@Param(value="phone") String phone, @Param(value="bizType") String bizType);
    
    public int udpateCheckStatus (@Param(value="statusCheck") String statusCheck, @Param(value="bizId") Integer bizId);

    //查询待报竣biz id
    public List<Biz> servCompleteId(@Param(value="phone") String phone);
    //业务办理报竣
    public int servComplete(@Param(value="bizId") Integer bizId);
    public void batchInsert(List<Biz> list);
    //根据订单号修改状态
    public void updateByOrderNo(Biz biz);
    
    // 在途工单查询
    public List<BizDTO> queryByPhone(Map<String, Object> params);
}
