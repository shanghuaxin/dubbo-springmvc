package com.agent.online.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.online.entity.InvoiceApply;

/**
 * 发票打印
 * @author auto
 */
@Repository
public interface InvoiceApplyMapper extends BaseMapper<InvoiceApply, Integer> {
    // 根据条件过滤发票信息
    public List<InvoiceApply> selectByCondition(Map<String, Object> map);
    // 查询数量
    public int count(Map<String, Object> map);
    // 修改发票打印的状态
    public int updateStatus(InvoiceApply entity);
    // 删除发票打印记录
    public int delete(Integer id);
}
