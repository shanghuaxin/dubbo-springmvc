package com.agent.online.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.common.DataTable;
import com.agent.online.dto.BrandDynamicSaveDTO;
import com.agent.online.entity.BrandDynamic;
import com.agent.online.mapper.BrandDynamicMapper;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.mapper.AttachedDocumentsMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;

/**
 * 品牌动态
 * @author auto
 */
@Service("brandDynamicService")
@Transactional(rollbackFor=Exception.class)
public class BrandDynamicService {
    @Autowired
    private BrandDynamicMapper brandDynamicMapper;
    @Autowired
    private BusinessLogService businessLogService;
    @Autowired
    private AttachedDocumentsMapper documentsMapper;
    
    /**
     * 品牌动态列表查询
     * @param dt
     * @param searchParams
     * @return
     * @throws Exception
     */
    public DataTable<BrandDynamicSaveDTO> brandList(DataTable<BrandDynamicSaveDTO> dt,Map<String, Object> searchParams,String resourceIP) throws Exception{
        List<BrandDynamicSaveDTO> list = brandDynamicMapper.listDTO(searchParams);
        if(null != list && list.size() >0){
            for(BrandDynamicSaveDTO s:list){
                s.setTitleFilePatch(resourceIP+s.getTitleFilePatch());
                s.setInfoFilePatch(resourceIP+s.getInfoFilePatch());
            }
        }
        int count = brandDynamicMapper.count(searchParams);
        dt.setAaData(list);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    /**
     * 查询品牌动态详情
     * @param id
     * @return
     * @throws Exception
     */
    public BrandDynamicSaveDTO findById(Integer id) throws Exception{
        BrandDynamicSaveDTO dto = new BrandDynamicSaveDTO();
        BrandDynamic findBrandDynamic = brandDynamicMapper.findById(id);
        if(null != findBrandDynamic){
            BeanUtils.copyProperties(dto, findBrandDynamic);
            List<AttachedDocuments> documents = documentsMapper.findBySourceIdAndSourceName(id, "t_brand_dynamic");
            if (null != documents && documents.size() > 0){
                for(AttachedDocuments s:documents){
                    if("10".equals(s.getSourceType())){
                        dto.setTitleFileName(s.getAttachmentName());
                        dto.setTitleFilePatch(s.getAttachmentUrl());
                    }else if("20".equals(s.getSourceType())){
                        dto.setInfoFileName(s.getAttachmentName());
                        dto.setInfoFilePatch(s.getAttachmentUrl());
                    }
                }
            }
        }
        return dto;
    }
    
            
    /**
     *保存品牌动态
     * @param b
     * @return
     * @throws Exception
     */
    public Integer save(BrandDynamicSaveDTO brand,User us) throws Exception{
        Integer cnt = 0;
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        if(brand.getId() != null){
            //修改
            BrandDynamic findBrand = brandDynamicMapper.findById(brand.getId());
            findBrand.setStatus(brand.getStatus());
            findBrand.setContent(brand.getContent());
            findBrand.setValidTime(DateUtil.getInstance().parseDate(brand.getValidTimeStr(), DateUtil.yyyy_MM_dd));
            findBrand.setSysType(brand.getSysType());
            findBrand.setIsHome(brand.getIsHome());
            findBrand.setUpdateId(us.getId());
            cnt = brandDynamicMapper.update(findBrand);
            
            List<AttachedDocuments> documents = documentsMapper.findBySourceIdAndSourceName(brand.getId(), "t_brand_dynamic");
            if (null != documents && documents.size() > 0){
                documentsMapper.deleteBySourceIdAndSourceName(brand.getId(), "t_brand_dynamic");
            }
            List<AttachedDocuments> atts = new ArrayList<>();
            AttachedDocuments att = new AttachedDocuments();
            att.setAttachmentName(brand.getTitleFileName());
            att.setAttachmentUrl(brand.getTitleFilePatch());
            att.setSourceName("t_brand_dynamic");
            att.setSourceId(brand.getId());
            att.setSourceType("10");
            atts.add(att);
            att = new AttachedDocuments();
            att.setAttachmentName(brand.getInfoFileName());
            att.setAttachmentUrl(brand.getInfoFilePatch());
            att.setSourceName("t_brand_dynamic");
            att.setSourceId(brand.getId());
            att.setSourceType("20");
            atts.add(att);
            documentsMapper.batchInsert(atts);
            
            logmap.put("title",brand.getTitle());
            logmap.put("oldInfoStr",findBrand.toString());
            logmap.put("infoStr",brand.toString());
            businessLogService.businessSaveLog(Business.online_brand_update,String.valueOf(us.getId()),us.getLoginName(),null != cnt ? String.valueOf(cnt) : "0","修改品牌动态",logmap);
        }else{
            //新增
            brand.setDynamicTime(DateUtil.getInstance().parseDate(brand.getDynamicTimeStr(), DateUtil.yyyy_MM_dd));
            brand.setValidTime(DateUtil.getInstance().parseDate(brand.getValidTimeStr(), DateUtil.yyyy_MM_dd));
            if("2".equals(brand.getStatus())){
                brand.setReleaseTime(new Date());
            }
            cnt = brandDynamicMapper.insert(brand);
            List<AttachedDocuments> atts = new ArrayList<>();
            AttachedDocuments att = new AttachedDocuments();
            att.setAttachmentName(brand.getTitleFileName());
            att.setAttachmentUrl(brand.getTitleFilePatch());
            att.setSourceName("t_brand_dynamic");
            att.setSourceId(brand.getId());
            att.setSourceType("10");
            atts.add(att);
            att = new AttachedDocuments();
            att.setAttachmentName(brand.getInfoFileName());
            att.setAttachmentUrl(brand.getInfoFilePatch());
            att.setSourceName("t_brand_dynamic");
            att.setSourceId(brand.getId());
            att.setSourceType("20");
            atts.add(att);
            documentsMapper.batchInsert(atts);
            
            logmap.put("title",brand.getTitle());
            logmap.put("infoStr",brand.toString());
            businessLogService.businessSaveLog(Business.online_brand_insert,String.valueOf(us.getId()),us.getLoginName(),null != cnt ? String.valueOf(cnt) : "0","新增品牌动态",logmap);
        }
        return cnt;
    }
    
    /**
     *发布品牌动态
     * @param b
     * @return
     * @throws Exception
     */
    public Integer releaseBrand(BrandDynamic brand,User us) throws Exception{
        Integer cnt = brandDynamicMapper.releaseBrand(brand);
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logmap.put("title",brand.getTitle());
        businessLogService.businessSaveLog(Business.online_brand_release,String.valueOf(us.getId()),us.getLoginName(),brand.getId().toString(),"发布品牌动态",logmap);
        return cnt;
    }

    
    /**
     *关闭品牌动态
     * @param b
     * @return
     * @throws Exception
     */
    public Integer closeBrand(BrandDynamic brand,User us) throws Exception{
        Integer cnt = brandDynamicMapper.closeBrand(brand);
        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        logmap.put("title",brand.getTitle());
        businessLogService.businessSaveLog(Business.online_brand_close,String.valueOf(us.getId()),us.getLoginName(),brand.getId().toString(),"关闭品牌动态",logmap);
        return cnt;
    }
    
}
