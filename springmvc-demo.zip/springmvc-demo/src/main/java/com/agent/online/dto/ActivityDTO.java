package com.agent.online.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import com.agent.common.enumeration.ActivityType;
import com.agent.util.DateUtil;

public class ActivityDTO implements Serializable {
    
    private static final long serialVersionUID = 685172629359678751L;
    private Integer id;
    private String activityName;
    private String activityImagePath;
    private String activityLink;
    // 活动类型：1.轮播图 2.活动 3.移动专区 4.联通专区 5.更多产品
    private Integer activityType;
    // 大标题
    private String titleBig;
    // 小标题
    private String titleSmall;
    private String effectDate;
    private String expiryDate;
    private Integer sort;
    private Integer status;
    private String remark;
    private Date createTime;
    private Date updateTime;
    private String title;
    private String title1;
    private String content1;
    private String title2;
    private String content2;
    private String title3;
    private String content3;
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    
    private MultipartFile activityImageFile;
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getActivityName() {
        return activityName;
    }
    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }
    public String getActivityImagePath() {
        return activityImagePath;
    }
    public void setActivityImagePath(String activityImagePath) {
        this.activityImagePath = activityImagePath;
    }
    public String getActivityLink() {
        return activityLink;
    }
    public void setActivityLink(String activityLink) {
        this.activityLink = activityLink;
    }
    public Integer getActivityType() {
        return activityType;
    }
    public String getActivityTypeStr() {
        if (null != activityType) {
            return ActivityType.getName(activityType);
        }
        return activityType+"";
    }
    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }
    public String getTitleBig() {
        return titleBig;
    }
    public void setTitleBig(String titleBig) {
        this.titleBig = titleBig;
    }
    public String getTitleSmall() {
        return titleSmall;
    }
    public void setTitleSmall(String titleSmall) {
        this.titleSmall = titleSmall;
    }
    public String getEffectDate() {
        return effectDate;
    }
    public String getEffectDateStr() {
        if (null != effectDate) {
            Date date = DateUtil.getInstance().parseDate(effectDate,DateUtil.yyyy_MM_dd_HH_mm_ss);
            return effectDate !=null ? DateUtil.getInstance().formatDate(date, DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
        }
        return "";
    }
    public void setEffectDate(String effectDate) {
        this.effectDate = effectDate;
    }
    public String getExpiryDate() {
        return expiryDate;
    }
    public String getExpiryDateStr() {
        if (null != expiryDate) {
            Date date = DateUtil.getInstance().parseDate(expiryDate,DateUtil.yyyy_MM_dd_HH_mm_ss);
            return expiryDate !=null ? DateUtil.getInstance().formatDate(date, DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
        }
        return "";
    }
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getStatus() {
        return status;
    }
    public String getStatusStr() {
        String statusStr = "";
        if (0 == status) {
            statusStr = "关闭";
        } else {
            statusStr = "已发布";
        }
        return statusStr;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public Date getCreateTime() {
        return createTime;
    }
    public String getCreateTimeStr() {
        return createTime !=null ? DateUtil.getInstance().formatDate(createTime, DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    public Date getUpdateTime() {
        return updateTime;
    }
    public String getUpdateTimeStr() {
        return updateTime !=null ? DateUtil.getInstance().formatDate(updateTime, DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getTitle1() {
        return title1;
    }
    public void setTitle1(String title1) {
        this.title1 = title1;
    }
    public String getContent1() {
        return content1;
    }
    public void setContent1(String content1) {
        this.content1 = content1;
    }
    public String getTitle2() {
        return title2;
    }
    public void setTitle2(String title2) {
        this.title2 = title2;
    }
    public String getContent2() {
        return content2;
    }
    public void setContent2(String content2) {
        this.content2 = content2;
    }
    public String getTitle3() {
        return title3;
    }
    public void setTitle3(String title3) {
        this.title3 = title3;
    }
    public String getContent3() {
        return content3;
    }
    public void setContent3(String content3) {
        this.content3 = content3;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public MultipartFile getActivityImageFile() {
        return activityImageFile;
    }
    public void setActivityImageFile(MultipartFile activityImageFile) {
        this.activityImageFile = activityImageFile;
    }
}
