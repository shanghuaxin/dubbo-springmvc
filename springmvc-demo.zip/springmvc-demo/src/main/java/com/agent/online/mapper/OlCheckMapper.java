package com.agent.online.mapper;

import com.agent.common.BaseMapper;
import com.agent.online.entity.OlCheck;

public interface OlCheckMapper extends BaseMapper<OlCheck, Integer> {

}
