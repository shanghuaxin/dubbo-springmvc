package com.agent.online.entity;

import com.agent.common.BaseDomain;

public class ActivityAttr extends BaseDomain {
    
    private static final long serialVersionUID = -1988083846735947159L;
    // 活动表ID
    private Integer activityId;
    // 总标题
    private String title;
    // 标题1
    private String title1;
    // 内容1
    private String content1;
    private String title2;
    private String content2;
    private String title3;
    private String content3;
    public Integer getActivityId() {
        return activityId;
    }
    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getTitle1() {
        return title1;
    }
    public void setTitle1(String title1) {
        this.title1 = title1;
    }
    public String getContent1() {
        return content1;
    }
    public void setContent1(String content1) {
        this.content1 = content1;
    }
    public String getTitle2() {
        return title2;
    }
    public void setTitle2(String title2) {
        this.title2 = title2;
    }
    public String getContent2() {
        return content2;
    }
    public void setContent2(String content2) {
        this.content2 = content2;
    }
    public String getTitle3() {
        return title3;
    }
    public void setTitle3(String title3) {
        this.title3 = title3;
    }
    public String getContent3() {
        return content3;
    }
    public void setContent3(String content3) {
        this.content3 = content3;
    }
}
