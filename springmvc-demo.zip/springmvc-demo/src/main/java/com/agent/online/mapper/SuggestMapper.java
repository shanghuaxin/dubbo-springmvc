package com.agent.online.mapper;

import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.online.entity.Suggest;

/**
 * 新版吐槽管理
 * @author auto
 */
@Repository
public interface SuggestMapper extends BaseMapper<Suggest, Integer> {
    // 查询数量
    public int count(Map<String, Object> map);
    // 更新新版吐槽的回复
    public int updateApply(Suggest entity);
    // 删除新版吐槽记录
    public int delete(Integer id);
}
