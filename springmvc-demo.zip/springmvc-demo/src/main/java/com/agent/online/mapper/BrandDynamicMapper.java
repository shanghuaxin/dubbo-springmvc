package com.agent.online.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.online.dto.BrandDynamicSaveDTO;
import com.agent.online.entity.BrandDynamic;

/**
 * 品牌动态
 * @author auto
 */
@Repository
public interface BrandDynamicMapper extends BaseMapper<BrandDynamic, Integer> {
    public int releaseBrand(BrandDynamic brand);
    public int closeBrand(BrandDynamic brand);
    public BrandDynamic findById(Integer brandId);
    public List<BrandDynamicSaveDTO> listDTO(Map<String, Object> map);
}

