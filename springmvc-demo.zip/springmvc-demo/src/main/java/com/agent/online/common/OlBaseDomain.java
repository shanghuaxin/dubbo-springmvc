package com.agent.online.common;

import java.io.Serializable;
import java.util.Date;

import com.agent.util.DateUtil;

/**
 * Created by zw on 2017/7/06.
 */
public class OlBaseDomain implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = -4549306767643806270L;
    private Integer id;
    private Date createTime;
    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public String getCreateTimeStr() {
        return createTime !=null ? DateUtil.getInstance().getDateStr(createTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public String getCreateTimeYMD() {
        return createTime !=null ? DateUtil.getInstance().getDateStr(createTime,DateUtil.yyyy_MM_dd) : "";
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime !=null ? DateUtil.getInstance().getDateDate(createTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : null;

    }

    public Date getUpdateTime() {
        return updateTime;
    }
    public String getUpdateTimeStr() {
        return updateTime !=null ? DateUtil.getInstance().getDateStr(updateTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime !=null ? DateUtil.getInstance().getDateDate(updateTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : null;

    }
}
