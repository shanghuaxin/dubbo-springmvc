package com.agent.online.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;

/**
 * 发票打印申请表
 *
 */
public class InvoiceApply extends BaseDomain{

    private static final long serialVersionUID = -5552353325209033944L;
    // 申请人手机号码
    private String phone;
    // 账期，格式201701
    private String billCycle;
    // 账期，格式201701_300,201712_200
    private String billCycles;
    // 账单金额
    private BigDecimal billDue;
    // 发票抬头
    private String invoiceTitle;
    // 税号（发票抬头为单位时，不能为空）
    private String taxNumber;
    // 收货人
    private String receiver;
    // 收货人号码
    private String receiverPhone;
    // 发票邮寄地址
    private String invoiceAddress;
    // 邮编
    private String postcode;
    // 申请状态 0:待处理  1:已打印
    private Integer status;
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getBillCycle() {
        return billCycle;
    }

    public void setBillCycle(String billCycle) {
        this.billCycle = billCycle;
    }

    public String getBillCycles() {
        return billCycles;
    }

    public void setBillCycles(String billCycles) {
        this.billCycles = billCycles;
    }

    public BigDecimal getBillDue() {
        return billDue;
    }
    
    public String getBillDueStr() {
        if(null != billDue){
            return Constant.df0.format(billDue.divide(Constant.cnt100));
        }
        return "0.00";
    }

    public void setBillDue(BigDecimal billDue) {
        this.billDue = billDue;
    }

    public String getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(String invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getInvoiceAddress() {
        return invoiceAddress;
    }

    public void setInvoiceAddress(String invoiceAddress) {
        this.invoiceAddress = invoiceAddress;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public Integer getStatus() {
        return status;
    }
    
    public String getStatusStr() {
        String statusStr = null;
        if (null != status) {
            if (0 == status) {
                statusStr = "待处理";
            } else {
                statusStr = "已打印";
            }
        }
        return statusStr;
    }
    
    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
