package com.agent.online.common.enumeration;

public enum CheckStatusType {
    
    //收费模式：1-一次性收费，2，按月收费，3-实时收费
    WAIT_CHECK("待审核", "1"), CHECKED("审核通过", "2"), CHECK_NO("审核不通过", "3");
    
    // 成员变量 
    private String name;
    private String code;
    // 构造方法 
    private CheckStatusType(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (CheckStatusType ot : CheckStatusType.values()) {
            if (ot.getCode() == code) {
                return ot.name;
            }
        }
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
