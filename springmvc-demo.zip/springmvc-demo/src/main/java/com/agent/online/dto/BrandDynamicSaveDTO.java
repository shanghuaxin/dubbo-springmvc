package com.agent.online.dto;

import com.agent.online.entity.BrandDynamic;

public class BrandDynamicSaveDTO extends BrandDynamic{

    /**
     * 
     */
    private static final long serialVersionUID = 4211476540297823432L;

    private String dynamicTimeStr;
    private String releaseTimeStr;
    private String validTimeStr;
    private String titleFileName;
    private String titleFilePatch;
    private String infoFileName;
    private String infoFilePatch;
    
    public String getDynamicTimeStr() {
        return dynamicTimeStr;
    }
    public void setDynamicTimeStr(String dynamicTimeStr) {
        this.dynamicTimeStr = dynamicTimeStr;
    }
    public String getReleaseTimeStr() {
        return releaseTimeStr;
    }
    public void setReleaseTimeStr(String releaseTimeStr) {
        this.releaseTimeStr = releaseTimeStr;
    }
    public String getValidTimeStr() {
        return validTimeStr;
    }
    public void setValidTimeStr(String validTimeStr) {
        this.validTimeStr = validTimeStr;
    }
    public String getTitleFileName() {
        return titleFileName;
    }
    public void setTitleFileName(String titleFileName) {
        this.titleFileName = titleFileName;
    }
    public String getTitleFilePatch() {
        return titleFilePatch;
    }
    public void setTitleFilePatch(String titleFilePatch) {
        this.titleFilePatch = titleFilePatch;
    }
    public String getInfoFileName() {
        return infoFileName;
    }
    public void setInfoFileName(String infoFileName) {
        this.infoFileName = infoFileName;
    }
    public String getInfoFilePatch() {
        return infoFilePatch;
    }
    public void setInfoFilePatch(String infoFilePatch) {
        this.infoFilePatch = infoFilePatch;
    }
}
