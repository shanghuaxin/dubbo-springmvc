package com.agent.online.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.common.CommonService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.constant.Constant;
import com.agent.online.dto.BizDTO;
import com.agent.online.dto.RealnameLookDTO;
import com.agent.online.entity.BizRealname;
import com.agent.online.service.BizService;
import com.agent.online.service.RealnameService;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.service.AttachedDocumentsService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;

@Controller
@RequestMapping(value="realname")
public class RealnameController {
    
    private static Logger logger = LoggerFactory.getLogger(RealnameController.class);
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Autowired
    private BizService bizService;
    @Autowired
    private RealnameService realnameService;
    @Autowired
    private AttachedDocumentsService documentsService;
    @Autowired
    private CommonService commonService;
    
    @RequestMapping("/realnameList" )
    public String realnameList(HttpServletRequest request, BizDTO dto, Integer pageSize, Integer pageIndex, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        
        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotBlank(dto.getPhone())) {
            params.put("phone", dto.getPhone());
        }
        
        if (StringUtils.isNotBlank(dto.getCode())) {
            params.put("code", dto.getCode());
        }
        
        if (StringUtils.isNotBlank(dto.getOperationTimeStr())) {
            params.put("operationTime", dto.getOperationTimeStr());
        }
        
        if (StringUtils.isNotBlank(dto.getWayType())) {
            params.put("wayType", dto.getWayType());
        }
        
        if (StringUtils.isNotBlank(dto.getCheckTimeStr())) {
            params.put("checkTime", dto.getCheckTimeStr());
        }
        
        if (StringUtils.isNotBlank(dto.getCheckStatus())) {
            params.put("checkStatus", dto.getCheckStatus());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<BizDTO> realnameList = bizService.listRealname(params);
        int total = bizService.countRealName(params);
        pageEntity.setTotal(total);
        

//        request.setAttribute("phoneLevel", DicUtil.getDictionarysByKey("PHONE_LEVEL_CODE"));
        request.setAttribute("realnameList", realnameList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("dto", dto);

        return "/views/olbiz/realnamelist.jsp";
    }
    
    /**
     * 审核初始化页面
     * @param request
     * @param session
     * @return
     */
    @RequestMapping("/audit" )
    public String audit(HttpServletRequest request, HttpSession session) {
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return "login.jsp";
            }
            
            String idStr = request.getParameter("id");
            if(StringUtils.isBlank(idStr)){
                request.setAttribute("flag", "2");
                return "/views/olbiz/audit.jsp";
            }
            Integer id = Integer.parseInt(idStr);
            String sourceName = request.getParameter("type");
            
            //根据开户记录查看用户资料信息
            BizRealname realname = realnameService.findById(id);
            if (realname == null) {
                realname = new BizRealname();
            }
            IdcardInfo idcardInfo = new IdcardInfo();
            List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
            AttachedDocuments cardHeadImg = null;
            List<AttachedDocuments> attachedDocuments = null;
            if(null != atts && atts.size() >0){
                attachedDocuments = new ArrayList<AttachedDocuments>();
                idcardInfo = commonService.imgIdcardInfo(atts, realname.getPhone(), request,imageURL);
                for(AttachedDocuments s : atts){
                    s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                    if(s.getSourceType().equals("cardHeadImg")){
                        try{
                            cardHeadImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHeadImg, s);
                        }catch (Exception e){
                            logger.error("头像图片获取失败");
                        }
                    }else{
                        attachedDocuments.add(s);
                    }
                }
            }
            idcardInfo.setName(realname.getName());
            idcardInfo.setIdNumber(realname.getCode());
            idcardInfo.setAddress(realname.getAddress());
            
            request.setAttribute("id", id);
            request.setAttribute("type", sourceName);
            request.setAttribute("realname", realname);
            request.setAttribute("idcardInfo", idcardInfo);
            request.setAttribute("attachedDocuments", attachedDocuments);
        } catch (Exception e) {
            logger.error("进入实名补录审核页面异常，error="+e.getMessage(),e);
        }
        return "/views/olbiz/audit.jsp";
    }
    
    /**
     * 审核-显示照片
     * @param request
     * @param session
     * @return
     */
    @RequestMapping("/picShow" )
    public String picShow(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");
        Integer id = null;
        if (StringUtils.isEmpty(idStr)) {
            id = 0;
        } else {
            id = Integer.parseInt(request.getParameter("id"));
        }
        String sourceName = request.getParameter("type");
        
        List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
        List<AttachedDocuments> attachedDocuments = null;
        if(null != atts && atts.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : atts){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                attachedDocuments.add(s);
            }
        }

        request.setAttribute("attachedDocuments", attachedDocuments);
        
        return "/views/olbiz/picShow.jsp";
    }
    
    //审核不通过描述
    @RequestMapping("/auditDetail" )
    public String auditDetail(HttpServletRequest request, String phone, String pass, HttpSession session) {
        
        request.setAttribute("phone", phone);
        request.setAttribute("pass", pass);
        
        return "/views/olbiz/auditDetail.jsp";
    }
    
    /**
     * 实名设置审核
     */
    @ResponseBody
    @RequestMapping(value = "updateCardVfnList", method = RequestMethod.POST)
    public Map<String,Object> updateRealnameVfnList(RealnameLookDTO dto, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        StringBuffer logStr = new StringBuffer();
        boolean hasSuccFlag = false;
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(StringUtils.isBlank(dto.getPhone())){
            returnStr.append("需要进行审核的号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        try{
            String operate = null;
            if ("1".equals(dto.getPass())) {
                operate = "审核通过";
            } else {
                operate="审核不通过";
            }
            
            RestStatus restStatus = bizService.updateRealnameVfnList(dto, user);
            
            if(!restStatus.getStatus()){
                if(restStatus.getErrorMessage()!=null){
                    if("1".equals(dto.getPass())){// true时通过,false不通过
                        returnStr.append(dto.getPhone()).append("实名补录审核失败！原因："+restStatus.getErrorMessage()+"</p>");
                        logStr.append(dto.getPhone()).append("实名补录失败！原因："+restStatus.getErrorMessage()+"</p>");
                    }else{
                        returnStr.append(dto.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                        logStr.append(dto.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                    }
                }else{
                    returnStr.append(dto.getPhone()).append(operate).append("失败！</p>");
                    logStr.append(dto.getPhone()).append(operate).append("失败！</p>");
                }
                map.put("status",false);
            }else{
                if("1".equals(dto.getPass())){//true时通过,false不通过
                    returnStr.append(dto.getPhone()).append("实名补录成功！</p>");
                    logStr.append(dto.getPhone()).append("实名补录成功！</p>");
                }else{
                    returnStr.append(dto.getPhone()).append("审核成功，审核结果为不通过！</p>");
                    logStr.append(dto.getPhone()).append("审核成功，审核结果为不通过！</p>");
                    
                }
                map.put("status",true);
                hasSuccFlag = true;
            }
        } catch (Exception e) {
            logger.error("实名设置审核失败，原因："+e.getMessage(), e);
            returnStr.append(dto.getPhone()).append("审核失败！ </p>" + e.getMessage());
            logStr.append(dto.getPhone()).append("审核失败！</p>" + e.getMessage());
            map.put("status",false);
        }
        
        map.put("hasSuccFlag", hasSuccFlag);
        map.put("errorMsg",returnStr) ;
        return map;
        
    }
    
    @RequestMapping("/view" )
    public String view(HttpServletRequest request, HttpSession session) {
        try {
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return "login.jsp";
            }

            String idStr = request.getParameter("id");
            if(StringUtils.isBlank(idStr)){
                request.setAttribute("flag", "2");
                return "/views/olbiz/audit.jsp";
            }
            Integer id = Integer.parseInt(idStr);
            String sourceName = request.getParameter("type");
            
            //根据开户记录查看用户资料信息
            BizRealname realname = realnameService.findById(id);
            if(realname == null){
                realname = new BizRealname();
            }
            IdcardInfo idcardInfo = new IdcardInfo();
            
            List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
            AttachedDocuments cardHeadImg = null;
            List<AttachedDocuments> attachedDocuments = null;
            if(null != atts && atts.size() >0){
                attachedDocuments = new ArrayList<AttachedDocuments>();
                idcardInfo = commonService.imgIdcardInfo(atts, realname.getPhone(), request,imageURL);
                for(AttachedDocuments s : atts){
                    s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                    if(s.getSourceType().equals("cardHeadImg")){
                        try{
                            cardHeadImg = new AttachedDocuments();
                            BeanUtils.copyProperties(cardHeadImg, s);
                        }catch (Exception e){
                            logger.error("头像图片获取失败");
                        }
                    }else{
                        attachedDocuments.add(s);
                    }
                }
                
            }

            idcardInfo.setName(realname.getName());
            idcardInfo.setIdNumber(realname.getCode());
            idcardInfo.setAddress(realname.getAddress());
            request.setAttribute("id", id);
            request.setAttribute("type", sourceName);
            request.setAttribute("realname", realname);
            request.setAttribute("idcardInfo", idcardInfo);
            request.setAttribute("attachedDocuments", attachedDocuments);
        } catch (Exception e) {
            logger.error("进入实名补录详情页面异常，error="+e.getMessage(),e);
        }
        return "/views/olbiz/view.jsp";
    }
    
    
    
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/realnameDetailExport",method=RequestMethod.GET)
    public void realnameDetailExport(HttpServletRequest request, HttpServletResponse response, BizDTO dto , Integer pageSize, HttpSession session){
        logger.info("-------------开户列表导出开始-------------");
        try {
            @SuppressWarnings("unused")
            User user = (User) session.getAttribute(Constant.SESSION_USER);

            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            
            Map<String, Object> params = new HashMap<String, Object>();

            if (StringUtils.isNotBlank(dto.getPhone())) {
                params.put("phone", dto.getPhone());
            }
            
            if (StringUtils.isNotBlank(dto.getCode())) {
                params.put("code", dto.getCode());
            }
            
            if (StringUtils.isNotBlank(dto.getOperationTimeStr())) {
                params.put("operationTime", dto.getOperationTimeStr());
            }
            
            if (StringUtils.isNotBlank(dto.getWayType())) {
                params.put("wayType", dto.getWayType());
            }
            
            if (StringUtils.isNotBlank(dto.getCheckTimeStr())) {
                params.put("checkTime", dto.getCheckTimeStr());
            }
            
            if (StringUtils.isNotBlank(dto.getCheckStatus())) {
                params.put("checkStatus", dto.getCheckStatus());
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;

            params.put("limit", limit);
            params.put("offset", offset);
            List<BizDTO> realnameList = bizService.listRealname(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "实名设置" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"申请时间","手机号码" ,"身份证号码" ,"姓名" ,"渠道" ,"审核状态" ,"审核时间" };
            properties = new String[]{"operTimeStr","phone" ,"code" ,"name" ,"wayType" ,"checkStatusStr" ,"checkTimeString"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, realnameList, properties);
            
        } catch (Exception e) {
            logger.error("开户列表记录导出失败"+e.getMessage(), e);
        }
        logger.info("-------------开户列表导出结束-------------");
    }

}
