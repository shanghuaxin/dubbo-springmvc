package com.agent.online.dto;

/**
 * 实名审核 提交
 * @author zhangwei
 *
 */
public class RealnameLookDTO {
    private String phone;
    private String pass;
    private String opinion;
    private String sexual;
    private String nation;
    private String organs;
    private String expiryDate;
    private String address;
    private String isReplace;//是否替换开户照片：checked 替换，其他不替换
    
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getPass() {
        return pass;
    }
    public void setPass(String pass) {
        this.pass = pass;
    }
    public String getOpinion() {
        return opinion;
    }
    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }
    public String getSexual() {
        return sexual;
    }
    public void setSexual(String sexual) {
        this.sexual = sexual;
    }
    public String getNation() {
        return nation;
    }
    public void setNation(String nation) {
        this.nation = nation;
    }
    public String getOrgans() {
        return organs;
    }
    public void setOrgans(String organs) {
        this.organs = organs;
    }
    public String getExpiryDate() {
        return expiryDate;
    }
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
    public String getIsReplace() {
        return isReplace;
    }
    public void setIsReplace(String isReplace) {
        this.isReplace = isReplace;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
}
