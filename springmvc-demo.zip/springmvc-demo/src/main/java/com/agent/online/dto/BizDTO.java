package com.agent.online.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.constant.Constant;
import com.agent.online.entity.Biz;
import com.agent.util.DateUtil;

public class BizDTO extends Biz {

    private static final long serialVersionUID = 7575982208932140307L;
    private Integer sourceId;          //业务办理表Id
    //实名设置信息
    private String name;            //姓名
    private String code;            //身份证号
    private String oldName;         //原姓名
    private String oldCode;         //原身份证号
    private String flag;            //是否需要过户：1-是，0-否
    //补换卡信息
    private String level;           //号码级别：0-普号，1-靓号
    private String address;         //邮寄地址
    private String receiver;        // 收货人
    private String receiverPhone;   // 收人人手机
    private String postcode;        // 邮编
    private String newStatus;       //补换卡状态：1-待补换卡，2-补换卡完成
    private String newIMSI;         //新IMSI
    private String newICCID;        //新ICCID
    private String trackStatus;     //发货状态：1-待发货，2-发货完成
    /**
     * 物流代码 
     * 顺丰 SF 百世快递 HTKY 中通 ZTO 申通 STO 圆通 YTO 韵达 YD 邮政平邮 YZPY EMS EMS
     * 天天 HHTT 京东 JD 全峰 QFKD 国通 GTO 优速 UC 德邦 DBL 快捷 FAST 亚马逊 AMAZON 宅急送 ZJS
     */
    private String trackingType;    //物流公司
    private String trackingNo;      //物流单号
    private Date trackDate;         //发货时间
    
    private BigDecimal bal;         //余额
    private String bankName;        //银行名称
    private String subbranchName;   //支行名称
    private String account;         //银行卡号
    private String accountName;     //开户名
    private String contactPhone;    //联系方式
    private String auditStatus;     //审核状态：1-待审核，2-已审核
    
    //时间查询条件
    private String checkTimeStr;         //审核时间
    private String operationTimeStr;     //受理时间
    private String trackDateStr;         //发货时间
    private String sDate;                //开始时间
    private String eDate;                //结束时间
    
    // 在途工单查询
    private String ascription; // 归属地
    private String nickName; // 操作人

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    public String getOldCode() {
        return oldCode;
    }

    public void setOldCode(String oldCode) {
        this.oldCode = oldCode;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getLevelStr() {
        String levelStr = "";
        if ("0".equals(level)) {
            levelStr = "普号";
        } else if ("1".equals(level)) {
            levelStr = "靓号";
        } else {
            levelStr = level;
        }
        return levelStr;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getNewIMSI() {
        return newIMSI;
    }

    public void setNewIMSI(String newIMSI) {
        this.newIMSI = newIMSI;
    }

    public String getNewICCID() {
        return newICCID;
    }

    public void setNewICCID(String newICCID) {
        this.newICCID = newICCID;
    }

    public String getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(String newStatus) {
        this.newStatus = newStatus;
    }

    public String getTrackStatus() {
        return trackStatus;
    }

    public void setTrackStatus(String trackStatus) {
        this.trackStatus = trackStatus;
    }

    public String getTrackingType() {
        return trackingType;
    }

    public void setTrackingType(String trackingType) {
        this.trackingType = trackingType;
    }

    public Date getTrackDate() {
        return trackDate;
    }

    public void setTrackDate(Date trackDate) {
        this.trackDate = trackDate;
    }
    
    public String getTrackDateString() {
        if(trackDate == null){
            return "";
        }
        return DateUtil.getInstance().formatDate(trackDate, "yyyy-MM-dd HH:mm:ss");
    }

    public String getCheckTimeStr() {
        return checkTimeStr;
    }

    public void setCheckTimeStr(String checkTimeStr) {
        this.checkTimeStr = checkTimeStr;
    }

    public String getOperationTimeStr() {
        return operationTimeStr;
    }

    public void setOperationTimeStr(String operationTimeStr) {
        this.operationTimeStr = operationTimeStr;
    }

    public String getTrackDateStr() {
        return trackDateStr;
    }

    public void setTrackDateStr(String trackDateStr) {
        this.trackDateStr = trackDateStr;
    }

    public String getsDate() {
        return sDate;
    }

    public void setsDate(String sDate) {
        this.sDate = sDate;
    }

    public String geteDate() {
        return eDate;
    }

    public void seteDate(String eDate) {
        this.eDate = eDate;
    }

    public BigDecimal getBal() {
        return bal;
    }
    
    public String getBalYuan() {
        if(null != bal){
            return Constant.df0.format(bal.divide(Constant.cnt100));
        }
        return "";
    }

    public void setBal(BigDecimal bal) {
        this.bal = bal;
    }

    public String getSubbranchName() {
        return subbranchName;
    }

    public void setSubbranchName(String subbranchName) {
        this.subbranchName = subbranchName;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getAuditStatus() {
        return auditStatus;
    }
    
    public String getAuditStatusStr() {
        String auditStatusStr = "";
        if ("1".equals(auditStatus)) {
            auditStatusStr = "未标记";
        } else if ("2".equals(auditStatus)) {
            auditStatusStr = "已标记";
        } else {
            auditStatusStr = auditStatus;
        }
        return auditStatusStr;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getAscription() {
        return ascription;
    }

    public void setAscription(String ascription) {
        this.ascription = ascription;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    
}
