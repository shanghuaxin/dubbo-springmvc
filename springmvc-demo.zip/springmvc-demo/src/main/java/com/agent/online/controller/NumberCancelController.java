package com.agent.online.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.common.PageEntity;
import com.agent.constant.Constant;
import com.agent.online.dto.BizDTO;
import com.agent.online.service.BizBankInfoService;
import com.agent.online.service.BizService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.ExcelUtils;

@Controller
@RequestMapping(value="numberCancel")
public class NumberCancelController {
    
    private static Logger logger = LoggerFactory.getLogger(NumberCancelController.class);
    
    @Autowired
    private BizService bizService;
    @Autowired
    private BizBankInfoService bankInfoService;
    
    @RequestMapping("/cancleList" )
    public String cancleList(HttpServletRequest request, BizDTO dto, Integer pageSize, Integer pageIndex, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        
        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotBlank(dto.getPhone())) {
            params.put("phone", dto.getPhone());
        }
        
        if (StringUtils.isNotBlank(dto.getOperationTimeStr())) {
            params.put("operationTime", dto.getOperationTimeStr());
        }
        
        if (StringUtils.isNotBlank(dto.getAuditStatus())) {
            params.put("auditStatus", dto.getAuditStatus());
        }
        
        if (StringUtils.isNotBlank(dto.getWayType())) {
            params.put("wayType", dto.getWayType());
        }
        
        if (StringUtils.isNotBlank(dto.getsDate())) {
            params.put("sDate", dto.getsDate());
        }
        
        if (StringUtils.isNotBlank(dto.geteDate())) {
            params.put("eDate", dto.geteDate());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<BizDTO> listCancel = bizService.listCancel(params);
        int total = bizService.countCancle(params);
        pageEntity.setTotal(total);
        

        request.setAttribute("phoneLevel", DicUtil.getDictionarysByKey("PHONE_LEVEL_CODE"));
        request.setAttribute("listCancel", listCancel);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("dto", dto);

        return "/views/olbiz/cancle/canclelist.jsp";
    }
    
    /**
     * 打印发票（这个只是做标记，真正的打印还是要依赖线下财务那边处理）
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "audit/{id}", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> audit(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try {
            bankInfoService.updateAuditStatus("2", id);
        } catch (Exception e) {
            logger.error("打印发票异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "打印发票异常");
        }
        return map;
    }
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/cancleDetailExport",method=RequestMethod.GET)
    public void cancleDetailExport(HttpServletRequest request, HttpServletResponse response, BizDTO dto , Integer pageSize, HttpSession session){
        logger.info("-------------销户列表导出开始-------------");
        try {
            @SuppressWarnings("unused")
            User user = (User) session.getAttribute(Constant.SESSION_USER);

            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            
            Map<String, Object> params = new HashMap<String, Object>();

            if (StringUtils.isNotBlank(dto.getPhone())) {
                params.put("phone", dto.getPhone());
            }
            
            if (StringUtils.isNotBlank(dto.getOperationTimeStr())) {
                params.put("operationTime", dto.getOperationTimeStr());
            }
            
            if (StringUtils.isNotBlank(dto.getAuditStatus())) {
                params.put("auditStatus", dto.getAuditStatus());
            }
            
            if (StringUtils.isNotBlank(dto.getWayType())) {
                params.put("wayType", dto.getWayType());
            }
            
            if (StringUtils.isNotBlank(dto.getsDate())) {
                params.put("sDate", dto.getsDate());
            }
            
            if (StringUtils.isNotBlank(dto.geteDate())) {
                params.put("eDate", dto.geteDate());
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;

            params.put("limit", limit);
            params.put("offset", offset);
            List<BizDTO> listCancel = bizService.listCancel(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "预销户" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;

            headers = new String[]{"申请时间", "手机号码","开户行" ,"支行名称" ,"账号" ,"开户名" ,"联系电话" , "余额(元)" ,"是否标记" };
            properties = new String[]{"operTimeStr", "phone" ,"bankName" ,"subbranchName" ,"account" ,"accountName", "contactPhone", "balYuan", "auditStatusStr"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, listCancel, properties);
            
        } catch (Exception e) {
            logger.error("预销户列表记录导出失败"+e.getMessage(), e);
        }
        logger.info("-------------预销户列表导出结束-------------");
    }

}
