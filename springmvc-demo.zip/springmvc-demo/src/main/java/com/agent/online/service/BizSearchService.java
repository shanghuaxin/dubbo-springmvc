package com.agent.online.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.online.entity.Biz;
import com.agent.online.entity.Recharge;
import com.agent.online.mapper.BizSearchMapper;

/**
 *
 */
@Service("bizSearchService")
@Transactional(rollbackFor=Exception.class)
public class BizSearchService {
    
    @Autowired
    private BizSearchMapper bizSearchMapper;
    
    // 根据条件过滤
    public List<Recharge> selectByCondition(Map<String, Object> map) {
        return bizSearchMapper.selectByCondition(map);
    }
    // 查询数量
    public int count(Map<String, Object> map) {
        return bizSearchMapper.count(map);
    }
    
    // 根据条件过滤
    public List<Biz> selectBizByCondition(Map<String, Object> map) {
        return bizSearchMapper.selectBizByCondition(map);
    }
    // 查询数量
    public int countBiz(Map<String, Object> map) {
        return bizSearchMapper.countBiz(map);
    }
}
