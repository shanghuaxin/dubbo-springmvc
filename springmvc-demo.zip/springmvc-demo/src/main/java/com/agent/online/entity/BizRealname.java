package com.agent.online.entity;

import java.io.Serializable;

import com.agent.online.common.OlBaseDomain;

/**
 * 实名补录
 * @author Administrator
 *
 */
public class BizRealname extends OlBaseDomain implements Serializable {

    private static final long serialVersionUID = 8896785924705624028L;
    private String phone;           //手机号码
    private Integer bizId;          //业务办理表Id
    private String bankName;        //银行名称
    private String name;            //姓名
    private String code;            //身份证号
    private String address;            //身份证号

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getBizId() {
        return bizId;
    }

    public void setBizId(Integer bizId) {
        this.bizId = bizId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "BizRealname [phone=" + phone + ", bizId=" + bizId + ", bankName=" + bankName + ", name=" + name
                + ", code=" + code + "]";
    }

}
