package com.agent.online.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.online.entity.BizRealname;
import com.agent.online.mapper.BizRealnameMapper;

@Transactional(rollbackFor=Exception.class)
@Service("realnameService")
public class RealnameService {
    @Autowired
    private BizRealnameMapper bizRealnameMapper;
    
    public BizRealname findById(Integer id) {
        return bizRealnameMapper.findById(id);
    }
}
