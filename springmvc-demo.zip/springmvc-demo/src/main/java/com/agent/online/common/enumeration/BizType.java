package com.agent.online.common.enumeration;

/**
 * 业务办理类型枚举
 * @author Administrator
 *
 */
public enum BizType {
    
    //1-流量订购 ，2-来电提醒 ，3-来电显示，4-无条件呼叫转移，5-炫铃服务，6-语音呼入，7-上网功能，8-短信功能,9-实名补录，10-补换卡，11-挂失解挂，12-停机保号停复机，13-销户申请
    FLOW_ORDER("流量订购", "1"),
    INCONING_CALL("来电提醒", "2"),
    INCONING_SHOW("来电显示", "3"),
    CALL_FORWARDING("无条件呼叫转移", "4"),
    RINGING("炫铃服务", "5"),
    VOICE_CALL("语音呼入", "6"),
    INTERNET_FUNCTION("上网功能", "7"),
    SMS_FUNCTION("短信功能", "8"),
    REALNAME("实名补录", "9"),
    DUPLICATE_SIM("补换卡", "10"),
    LOST_OR_RESTORE("挂失解挂", "11"),
    BLOCK_OR_REACT("停机保号停复机", "12"),
    NUMBER_CANCEL_APPLY("销户申请", "13"),
    SETMEAL_UP("套餐变更", "14"),
    APPEND_FLOW("叠加包", "15"),
    VOICE("语音包", "16"),
    DAY_FLOW("普通日包", "17"),
    DAY_FLOW_KEEP_ON("自动续订日包", "18"),
    USER_PWD_RESET("重置密码", "19"),
    BLOCK_OPEN_CLOSE("强制停复机", "20"),
    MMS_FUNCTION("彩信功能", "21"),
    OPEN_ACCOUNT("开户", "26"),
    MOD_CUSTOMER("过户", "27")
    ;
    
    // 成员变量 
    private String name;
    private String code;
    // 构造方法 
    private BizType(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    public static String getName(String code) {
        for (BizType ot : BizType.values()) {
            if (ot.getCode() == code) {
                return ot.name;
            }
        }
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
