package com.agent.online.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import com.agent.online.common.OlBaseDomain;

/**
 * 销户操作  号码用户银行信息表
 * @author Administrator
 *
 */
public class BizBankInfo extends OlBaseDomain implements Serializable {

    private static final long serialVersionUID = 5876767359692800571L;
    private String phone;           //手机号码
    private Integer bizId;          //业务办理表Id
    private BigDecimal bal;         //余额
    private String bankName;        //银行名称
    private String subbranchName;   //支行名称
    private String account;         //银行卡号
    private String AccountName;     //开户名
    private String contactPhone;    //联系方式
    private String auditStatus;     //审核状态：1-待审核，2-已审核

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getBizId() {
        return bizId;
    }

    public void setBizId(Integer bizId) {
        this.bizId = bizId;
    }

    public BigDecimal getBal() {
        return bal;
    }

    public void setBal(BigDecimal bal) {
        this.bal = bal;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getSubbranchName() {
        return subbranchName;
    }

    public void setSubbranchName(String subbranchName) {
        this.subbranchName = subbranchName;
    }

    public String getAccountName() {
        return AccountName;
    }

    public void setAccountName(String accountName) {
        AccountName = accountName;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    @Override
    public String toString() {
        return "BizBankInfo [phone=" + phone + ", bizId=" + bizId + ", bankName=" + bankName + ", subbranchName="
                + subbranchName + ", account=" + account + ", AccountName=" + AccountName + ", contactPhone="
                + contactPhone + "]";
    }

}
