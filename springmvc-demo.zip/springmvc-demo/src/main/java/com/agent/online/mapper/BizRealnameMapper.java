package com.agent.online.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.online.entity.BizRealname;

public interface BizRealnameMapper extends BaseMapper<BizRealname, Integer> {
    
    public BizRealname findById(@Param(value="id") Integer id);

}
