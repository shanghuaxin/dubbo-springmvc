package com.agent.online.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.online.mapper.BizBankInfoMapper;

@Transactional(rollbackFor=Exception.class)
@Service("bizBankInfoService")
public class BizBankInfoService {
    
    @Autowired
    private BizBankInfoMapper bankInfoMapper;
    
    public int updateAuditStatus(String auditStatus, Integer bizId) {
        return bankInfoMapper.updateAuditStatus(auditStatus, bizId);
    }

}
