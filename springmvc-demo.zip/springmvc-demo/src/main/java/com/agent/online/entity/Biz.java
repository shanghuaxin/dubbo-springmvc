package com.agent.online.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.agent.common.enumeration.BizSourceType;
import com.agent.common.enumeration.WayType;
import com.agent.online.common.OlBaseDomain;
import com.agent.util.DateUtil;
import com.agent.util.Utils;


/**
 * 业务办理表
 * @author Administrator
 *
 */
public class Biz extends OlBaseDomain implements Serializable {
    /***  订购     **/
    public static final String opt_type_0 = "0";
    /***  取消     **/
    public static final String opt_type_1 = "1";
    /***  变更     **/
    public static final String opt_type_2 = "2";
    /***  实时生效     **/
    public static final String wayType_AGENT = "AGENT";
    public static final String wayType_ONLINE = "ONLINE";
    public static final String wayType_AGENTAPP = "AGENTAPP";
    public static final String wayType_WAP = "WAP";

    private static final long serialVersionUID = 6605500621554903268L;
    private String phone;      //手机号码
    private String orderNo;    //订单编号
    private String servCode;   //业务编码
    private String servName;   //业务名称
    //业务类型：1-流量订购 ，2-来电提醒 ，3-来电显示，4-无条件呼叫转移，5-炫铃服务，6-语音呼入，7-上网功能，8-短信功能，9-实名补录,10-补换卡,11-挂失解挂,
    //12-停机保号停复机,13-销户申请,14-套餐变更，15-叠加包,16-语音包，17-普通日包，18-自动续订日包
    private String bizType;         
    private String bizName;         //业务名称：1-流量订购 ，2-来电提醒 ，3-来电显示，4-无条件呼叫转移，5-炫铃服务，6-语音呼入，7-上网功能，8-短信功能
    private String operationType;   //操作类型：0-订购，1-取消，2-变更
    private String status;          //状态：1-成功，2-失败，3-处理中,4-取消
    private String checkStatus;     //审核状态：1-待审核，2-审核通过，3-审核不通过， 4-取消， 6-审核中
    private Date checkTime;         //审核时间
    private Date operationTime;     //受理时间
    private String validType;       //生效方式：1-实时生效， 2-次月生效
    private Date validTime;         //生效时间
    private BigDecimal money;       //金额
    private String feeStyle;        //收费模式：1-一次性收费，2，按月收费，3-实时收费
    private String wayType;         //渠道类型：AGENT-酷商，ONLINE-网厅，AGENTAPP-酷商APP，WAP-掌厅，KF-客服
    private String ip;              //操作IP
    private String reason;          //操作原因
    private String remark;          //备注
    private String nickName;          //登录名
    private String newServCode;   //新业务编码
    private String newServName;   //新业务名称
    private String oldServCode;   //旧业务编码
    private String oldServName;   //旧业务名称

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getServCode() {
        return servCode;
    }

    public void setServCode(String servCode) {
        this.servCode = servCode;
    }

    public String getServName() {
        return servName;
    }
    
    public String getServNameStr() {
        if(StringUtils.isNotEmpty(operationType) && StringUtils.isNotEmpty(servName) && !"开户".equals(servName) && !"过户".equals(servName)){
            if("1".equals(bizType) || "2".equals(bizType) ||"3".equals(bizType) ||"14".equals(bizType) ||"15".equals(bizType) 
                    ||"16".equals(bizType) || "17".equals(bizType) ||"18".equals(bizType)){
                if("0".equals(operationType) && servName.indexOf("订购") < 0){
                    return "订购"+servName;
                }else if("1".equals(operationType) && servName.indexOf("退订") < 0){
                    return "退订"+servName;
                }else if("2".equals(operationType) && servName.indexOf("变更") < 0){
                    if(StringUtils.isNotEmpty(oldServName)){
                        return oldServName+"变为"+newServName;
                    }else{
                        return servName;
                    }
                }
            }else if("7".equals(bizType) || "8".equals(bizType)){
                if("0".equals(operationType)){
                    return servName+"开通";
                }else if("1".equals(operationType)){
                    return servName+"关闭";
                }
            }else if("12".equals(bizType)){
                if("0".equals(operationType)){
                    return servName+"(停机)";
                }else if("1".equals(operationType)){
                    return servName+"(复机)";
                }
            }else if("20".equals(bizType)){
                if("0".equals(operationType)){
                    return servName+"(强开)";
                }else if("1".equals(operationType)){
                    return servName+"(强停)";
                }
            }
        }
        return servName;
    }

    public void setServName(String servName) {
        this.servName = servName;
    }

    public String getBizTypeStr() {
        return BizSourceType.getName(bizType);
    }
    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getBizName() {
        return bizName;
    }

    public void setBizName(String bizName) {
        this.bizName = bizName;
    }

    public String getOperationType() {
        return operationType;
    }
    
    public String getOperationTypStr() {
        if (!Utils.isEmptyString(operationType)) {
            if ("0".equals(operationType)) {
                return "订购";
            } else if ("1".equals(operationType)) {
                return "取消";
            } else if ("2".equals(operationType)) {
                return "变更";
            }
        }
        return "";
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getStatusStr() {
        if (!Utils.isEmptyString(status)) {
            if ("1".equals(status)) {
                return "已报竣";
            } else if ("2".equals(status)) {
                return "失败";
            } else if ("3".equals(status)) {
                return "待报竣";
            } else if ("4".equals(status)) {
                return "已取消";
            }
        }
        return "";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }
    
    public String getCheckStatusStr() {
        String checkStatusStr = "";
        if ("1".equals(checkStatus)) {
            checkStatusStr = "待审核";
        } else if ("2".equals(checkStatus)) {
            checkStatusStr = "审核通过";
        } else if ("3".equals(checkStatus)) {
            checkStatusStr = "审核不通过";
        } else if ("4".equals(checkStatus)) {
            checkStatusStr = "取消";
        } else if ("6".equals(checkStatus)) {
            checkStatusStr = "审核中";
        } else {
            checkStatusStr = checkStatus;
        }
        return checkStatusStr;
    }
    
    public String getCheckTimeString() {
        if(checkTime == null){
            return "";
        }
        return DateUtil.getInstance().formatDate(checkTime, "yyyy-MM-dd HH:mm:ss");
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public String getOperTimeStr() {
        if(operationTime == null){
            return "";
        }
        return DateUtil.getInstance().formatDate(operationTime, "yyyy-MM-dd HH:mm:ss");
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public String getValidType() {
        return validType;
    }
    
    public String getValidTypeStr() {
        if(!Utils.isEmptyString(validType)){
            if("1".equals(validType)){
                return "实时生效";
            }else if("2".equals(validType)){
                return "次月生效";
            }else if("3".equals(validType)){
                return "次日生效";
            }
        }
        return "";
    }

    public void setValidType(String validType) {
        this.validType = validType;
    }

    public String getValidTimeStr() {
        if(null != validTime){
           DateUtil.getInstance().formatDate(validTime, DateUtil.yyyy_MM_dd);
        }
        return "";
    }

    public Date getValidTime() {
        if(StringUtils.equals(validType, "1")) {   //实时生效
            return new Date();
        }else if(StringUtils.equals(validType, "2")) {   //次月生效
            SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MONTH, 1);
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            try {
                return dft.parse(dft.format(calendar.getTime()));
            } catch (ParseException e) {
                return validTime;
            }
        }
        return validTime;
    }

    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }

    public String getMoneyStr() {
        if(null != money){
            return new DecimalFormat("#0.00").format(money.divide(new BigDecimal(100)));
        }
        return "--";
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal bigDecimal) {
        this.money = bigDecimal;
    }

    public String getFeeStyle() {
        return feeStyle;
    }

    public void setFeeStyle(String feeStyle) {
        this.feeStyle = feeStyle;
    }

    public String getWayType() {
        return wayType;
    }
    
    public String getWayTypeStr() {
        if (!Utils.isEmptyString(wayType)) {
            return WayType.getName(wayType);
        }
        return "";
    }

    public void setWayType(String wayType) {
        this.wayType = wayType;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getNewServCode() {
        return newServCode;
    }

    public void setNewServCode(String newServCode) {
        this.newServCode = newServCode;
    }

    public String getNewServName() {
        return newServName;
    }

    public void setNewServName(String newServName) {
        this.newServName = newServName;
    }

    public String getOldServCode() {
        return oldServCode;
    }

    public void setOldServCode(String oldServCode) {
        this.oldServCode = oldServCode;
    }

    public String getOldServName() {
        return oldServName;
    }

    public void setOldServName(String oldServName) {
        this.oldServName = oldServName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    @Override
    public String toString() {
        return "Biz [phone=" + phone + ", orderNo=" + orderNo + ", servCode=" + servCode + ", servName=" + servName
                + ", bizType=" + bizType + ", bizName=" + bizName + ", operationType=" + operationType + ", status="
                + status + ", checkStatus=" + checkStatus + ", checkTime=" + checkTime + ", operationTime="
                + operationTime + ", validType=" + validType + ", validTime=" + validTime + ", money=" + money
                + ", feeStyle=" + feeStyle + ", wayType=" + wayType + ", ip=" + ip + ", reason=" + reason + ", remark="
                + remark + ", newServCode=" + newServCode + ", newServName=" + newServName + ", oldServCode="
                + oldServCode + ", oldServName=" + oldServName + "]";
    }

}
