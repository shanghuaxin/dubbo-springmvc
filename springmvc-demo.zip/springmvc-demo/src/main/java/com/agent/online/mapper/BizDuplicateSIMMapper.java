package com.agent.online.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.online.entity.BizDuplicateSIM;

public interface BizDuplicateSIMMapper extends BaseMapper<BizDuplicateSIM, Integer> {
    
    public BizDuplicateSIM findById(@Param(value="id") Integer id);
    
    public int updateNewStatus(@Param(value="newStatus") String newStatus, @Param(value="bizId") Integer bizId);
    
    public int duplicateCard(BizDuplicateSIM sim);
    
    public int updateTrack(BizDuplicateSIM sim);

}
