package com.agent.online.entity;

import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.util.DateUtil;

/**
 * 用户建议表
 *
 */
public class Suggest extends BaseDomain {

    private static final long serialVersionUID = -8952567219442850069L;
    // 评论人
    private String suggestUser;
    // 评论标题
    private String title;
    // 评论内容
    private String content;
    // 联系电话
    private String contactPhone;
    // 评论人类型，1.用户 2.代理商
    private Integer suggestType;
    // 回复状态 0：待回复  1：已回复
    private Integer applyStatus;
    // 回复内容
    private String applyContent;
    // 回复人ID
    private String applyPersonId;
    // 回复时间
    private Date applyTime;
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    
    public String getSuggestUser() {
        return suggestUser;
    }
    public void setSuggestUser(String suggestUser) {
        this.suggestUser = suggestUser;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getContactPhone() {
        return contactPhone;
    }
    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }
    public Integer getSuggestType() {
        return suggestType;
    }
    public void setSuggestType(Integer suggestType) {
        this.suggestType = suggestType;
    }
    public Integer getApplyStatus() {
        return applyStatus;
    }
    public String getApplyStatusStr() {
        String applyStatusStr = null;
        if (null != applyStatus) {
            if (0 == applyStatus) {
                applyStatusStr = "待回复";
            } else {
                applyStatusStr = "已回复";
            }
        }
        return applyStatusStr;
    }
    public void setApplyStatus(Integer applyStatus) {
        this.applyStatus = applyStatus;
    }
    public String getApplyContent() {
        return applyContent;
    }
    public void setApplyContent(String applyContent) {
        this.applyContent = applyContent;
    }
    public String getApplyPersonId() {
        return applyPersonId;
    }
    public void setApplyPersonId(String applyPersonId) {
        this.applyPersonId = applyPersonId;
    }
    public Date getApplyTime() {
        return applyTime;
    }
    public String getApplyTimeStr() {
        return applyTime !=null ? DateUtil.getInstance().getDateStr(applyTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
