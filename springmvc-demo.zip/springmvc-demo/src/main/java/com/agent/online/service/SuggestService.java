package com.agent.online.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.common.DataTable;
import com.agent.online.entity.Suggest;
import com.agent.online.mapper.SuggestMapper;

/**
 * 新版吐槽管理
 * @author FengLu
 *
 */
@Service("suggestService")
@Transactional(rollbackFor=Exception.class)
public class SuggestService {
    
    @Autowired
    private SuggestMapper suggestMapper;
    
    /**
     * 查询用户反馈意见列表
     * @param dt
     * @param searchMap
     * @return
     */
    public DataTable<Suggest> list(DataTable<Suggest> dt,Map<String,Object> searchMap) throws Exception{
        List<Suggest> listDto = suggestMapper.list(searchMap);
        int count = suggestMapper.count(searchMap);
        dt.setAaData(listDto);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    // 根据条件过滤新版吐槽信息
    public List<Suggest> selectByCondition(Map<String, Object> map) {
        return suggestMapper.list(map);
    }
    // 查询数量
    public int count(Map<String, Object> map) {
        return suggestMapper.count(map);
    }
    // 更新新版吐槽的回复
    public int updateApply(Suggest entity) {
        return suggestMapper.updateApply(entity);
    }
    // 删除新版吐槽记录
    public int delete(Integer id) {
        return suggestMapper.delete(id);
    }
}
