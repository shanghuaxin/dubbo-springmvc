package com.agent.online.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;

import com.agent.common.enumeration.BizSourceType;
import com.agent.util.Utils;

/**
 * 充值记录表
 * @author zhangwei
 *
 */
public class Recharge implements Serializable{
    
    private static final long serialVersionUID = 3348509435590000383L;
    
    private String orderNo;//订单编号
    private String buyOrderNo;//流量平台订单编号
    private String phone;//充值号码
    private String rtype;//充值类型：1-充值，2-充流量
    private String payType;//支付方：alipay_ol：支付宝，wx_ol：微信，card_yeepay:易宝支付，card_pay:19PAY支付，card_dx:鼎信支付支付
    private String payStatus;//支付状态：1-成功，2-待支付，3-失败
    private String rstatus;//充值状态：1-成功，2-待充值，3-接口失败，4-充值失败
    private BigDecimal money;//充值金额
    private BigDecimal accountBalance;//实际支付金额
    private String createTime;//充值时间
    private String sourceType;//充值来源：online-网厅，wap-掌厅
    private String updateTime;//充值时间
    private String carrier;   // 网络
    private String city;      // 归属地
    private String ip;        // IP
    
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public String getBuyOrderNo() {
        return buyOrderNo;
    }
    public void setBuyOrderNo(String buyOrderNo) {
        this.buyOrderNo = buyOrderNo;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getRtypeStr() {
        if(!Utils.isEmptyString(rtype)){
            if("1".equals(rtype)){
                return "充话费";
            }else if("2".equals(rtype)){
                return "充流量";
            }
        }
        return "";
    }
    
    public String getRtype() {
        return rtype;
    }
    public void setRtype(String rtype) {
        this.rtype = rtype;
    }
    public String getMoneyStr(){
        return new DecimalFormat("#0.00").format(money.divide(new BigDecimal(100)));
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public BigDecimal getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }
    public String getPayStatus() {
        return payStatus;
    }
    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }
    public String getRstatusStr() {
        if (!Utils.isEmptyString(rstatus)) {
            if ("1".equals(rstatus)) {
                return "充值成功";
            } else if ("2".equals(rstatus)) {
                return "待充值";
            } else if ("3".equals(rstatus)) {
                return "接口失败";
            } else if ("4".equals(rstatus)) {
                return "充值失败";
            }
        }
        return "";
    }
    public String getRstatus() {
        return rstatus;
    }
    public void setRstatus(String rstatus) {
        this.rstatus = rstatus;
    }
    public String getPayType() {
        return payType;
    }
    public void setPayType(String payType) {
        this.payType = payType;
    }
    public String getCreateTime() {
        return createTime.substring(0,19);
    }
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
    public String getSourceTypeStr() {
        
        return BizSourceType.getName(this.sourceType);
    }
    public String getSourceType() {
        return sourceType;
    }
    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }
    public String getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }
    public String getCarrier() {
        return carrier;
    }
    public String getCarrierStr() {
        if (null != carrier) {
            if ("YD".equals(carrier)) {
                return "移动";
            } else if ("LT".equals(carrier)) {
                return "联通";
            } else if ("DX".equals(carrier)) {
                return "电信";
            }
        }
        return "";
    }
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
}