package com.agent.online.entity;

import java.io.Serializable;

import com.agent.util.Utils;

/**
 * 销户操作  号码用户银行信息表
 * @author Administrator
 *
 */
public class BizSearch implements Serializable {

    private static final long serialVersionUID = 6605500621554903268L;
    private String phone;      //手机号码
    private String type;    //类型
    private String orderNo;    //订单编号
    private String thirdOrderNo;    //第三方流水号
    private String status;          //状态
    private String carrier;   // 网络
    private String startDate;     //受理时间
    private String endDate;     //受理时间
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getStatusStr() {
        if(Utils.isEmptyString(status)){
            if("0".equals(status)){
                return "成功";
            }else if("1".equals(status)){
                return "失败";
            }
        }
        return "";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTypeStr() {
        if(Utils.isEmptyString(status)){
            if("0".equals(status)){
                return "充话费";
            }else if("1".equals(status)){
                return "充流量";
            }
        }
        return "";
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getThirdOrderNo() {
        return thirdOrderNo;
    }

    public void setThirdOrderNo(String thirdOrderNo) {
        this.thirdOrderNo = thirdOrderNo;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
