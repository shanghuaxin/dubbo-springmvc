package com.agent.online.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.online.dto.ActivityDTO;
import com.agent.online.entity.Activity;
import com.agent.online.entity.ActivityAttr;

/**
 * 活动
 * @author auto
 */
@Repository
public interface ActivityMapper extends BaseMapper<ActivityDTO, Integer> {
    // 根据ID查询活动信息
    public Activity selectActivityById(Integer id);
    // 查询活动信息
    public List<ActivityDTO> selectActivity(Map<String, Object> map);
    // 查询活动信息数量
    public int count(Map<String, Object> map);
    // 根据活动ID获取活动的附加属性
    public ActivityAttr selectActivityAttrById(Integer id);
    // 新增活动
    public int insertActivity(Activity activity);
    // 新增活动附加属性
    public int insertActivityAttr(ActivityAttr activityAttr);
    // 修改活动
    public int updateActivity(Activity activity);
    // 修改活动状态，关闭或发布
    public int updateActivityStatus(Activity activity);
    // 修改活动附加属性
    public int updateActivityAttr(ActivityAttr activityAttr);
    // 删除活动
    public int deleteActivity(Integer id);
    // 删除活动附加属性
    public int deleteActivityAttr(Integer id);
}
