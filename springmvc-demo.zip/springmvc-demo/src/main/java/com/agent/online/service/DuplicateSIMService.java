package com.agent.online.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.common.RestStatus;
import com.agent.online.dto.BizDTO;
import com.agent.online.entity.BizDuplicateSIM;
import com.agent.online.entity.OlCheck;
import com.agent.online.mapper.BizDuplicateSIMMapper;
import com.agent.online.mapper.BizMapper;
import com.agent.online.mapper.OlCheckMapper;
import com.agent.openaccount.entity.Check;
import com.agent.system.entity.User;

@Transactional(rollbackFor=Exception.class)
@Service("duplicateSIMService")
public class DuplicateSIMService {
    
    @Autowired
    private BizDuplicateSIMMapper duplicateSIMMapper;
    @Autowired
    private BizMapper bizMapper;
    @Autowired
    private OlCheckMapper checkMapper;
    
    public  final static Map<Long,ReentrantLock> locks = new HashMap<Long, ReentrantLock>();
    
    public BizDuplicateSIM findById(Integer id) {
        return duplicateSIMMapper.findById(id);
    }
    
    /**
     * 开户号码取消操作，修改开户申请表和号码表
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateCardCancle(Integer id, User us) throws Exception {
        RestStatus restStatus = new RestStatus(Boolean.TRUE, "200", "取消成功，该号码已取消补换卡！");;
        getLock(Long.valueOf(id)).lock();
            try {
                BizDTO dto = bizMapper.findSIMById(id);
                
                if(StringUtils.equals(dto.getCheckStatus(), "6")){
                    restStatus = new RestStatus(Boolean.FALSE, "500", "取消失败，该号码正在补换卡审核中！");
                    return restStatus;
                }

                if(!StringUtils.equals(dto.getCheckStatus(), Check.audit_apply) && !(StringUtils.isBlank(dto.getCheckStatus()) && StringUtils.equals(dto.getNewStatus(), "1"))){
                    restStatus = new RestStatus(Boolean.FALSE, "500", "取消失败，该号码不能取消补换卡！");
                    return restStatus;
                }
                
                // 从开卡申请表中获取业务金额
                bizMapper.updateSimCancle(dto.getId());
                
                // 审核表添加数据
                OlCheck check = new OlCheck();
                check.setSourceId(dto.getSourceId());
                check.setSourceType("ol_biz_duplicate_sim");
                check.setPhone(dto.getPhone());
                check.setStatus("4");
                check.setCheckOpinion("客服取消");
                check.setCreateId(us.getId());
                check.setCreateTime(new Date());
                check.setUpdateId(us.getId());
                check.setUpdateTime(new Date());
                
                checkMapper.insert(check);


            } catch (Exception e) {
                e.printStackTrace();
                throw new Exception("号码取消失败!");
            }finally {
                getLock(Long.valueOf(id)).unlock();
            }
        return restStatus;
    }
    
    public synchronized  ReentrantLock getLock(Long value){

        if(!locks.containsKey(value)){
            locks.put(value,new ReentrantLock());
        }

        return locks.get(value);

    }

}
