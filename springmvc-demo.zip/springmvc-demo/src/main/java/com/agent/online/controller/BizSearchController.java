package com.agent.online.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.agent.common.PageEntity;
import com.agent.online.entity.Biz;
import com.agent.online.entity.BizSearch;
import com.agent.online.entity.Recharge;
import com.agent.online.service.BizSearchService;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;

/**
 * 充值-业务办理记录查询
 * @author auto
 */
@Controller
@RequestMapping(value="online")
public class BizSearchController {
    
    private static Logger logger = LoggerFactory.getLogger(BizSearchController.class);
    
    @Autowired
    private BizSearchService bizSearchService;
    
    @RequestMapping(value = "/bizsearch/recharge-list")
    public String rechargeList(HttpServletRequest request, HttpServletResponse response, BizSearch bizSearch) {
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            PageEntity pageEntity = new PageEntity(bizSearch.getPageSize(), bizSearch.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(bizSearch.getPhone())) {
                params.put("phone", bizSearch.getPhone().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getType())) {
                params.put("r_type", bizSearch.getType().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getOrderNo())) {
                params.put("order_no", bizSearch.getOrderNo().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getThirdOrderNo())) {
                params.put("buy_order_no", bizSearch.getThirdOrderNo().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getStartDate())) {
                params.put("start_time", bizSearch.getStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(bizSearch.getEndDate())) {
                params.put("end_time", bizSearch.getEndDate()+" 23:59:59");
            }
            if (StringUtils.isNotEmpty(bizSearch.getStatus())) {
                params.put("r_status", bizSearch.getStatus());
            }
            if (StringUtils.isNotEmpty(bizSearch.getCarrier())) {
                params.put("carrier", bizSearch.getCarrier());
            }
            // 分页查询
            List<Recharge> rechargeList = bizSearchService.selectByCondition(params);
            // 总数
            int total = bizSearchService.count(params);
            pageEntity.setTotal(total);
            
            request.setAttribute("rechargeList", rechargeList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("bizSearch", bizSearch);
        } catch (Exception e) {
            logger.error("充值记录查询异常："+e.getMessage(), e);
        }
        return "/views/online/bizsearch.jsp";
    }
    
    /**
     * 充值记录导出
     * @param request
     * @param response
     * @param bizSearch
     * @param pageSize
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @RequestMapping(value="/bizsearch/recharge-export",method=RequestMethod.GET)
    public void operationListExport(HttpServletRequest request, HttpServletResponse response, BizSearch bizSearch, Integer pageSize) {
        try {
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
    
            Map<String, Object> params = new HashMap<String, Object>();
            if (StringUtils.isNotEmpty(bizSearch.getPhone())) {
                params.put("phone", bizSearch.getPhone().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getOrderNo())) {
                params.put("order_no", bizSearch.getOrderNo().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getThirdOrderNo())) {
                params.put("buy_order_no", bizSearch.getThirdOrderNo().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getType())) {
                params.put("r_type", bizSearch.getType().trim());
            }
            if (StringUtils.isNotEmpty(bizSearch.getStatus())) {
                params.put("r_status", bizSearch.getStatus());
            }
            if (StringUtils.isNotEmpty(bizSearch.getCarrier())) {
                params.put("carrier", bizSearch.getCarrier());
            }
            if (StringUtils.isNotEmpty(bizSearch.getStartDate())) {
                params.put("start_time", bizSearch.getStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(bizSearch.getEndDate())) {
                params.put("end_time", bizSearch.getEndDate()+" 23:59:59");
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            
            List<Recharge> rechargeList = bizSearchService.selectByCondition(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "充值记录详情" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"手机号码","充值渠道 ","充值类型 ","网络","归属地","充值时间", "充值金额", "充值状态","充值单号", "第三方流水号"};
            properties = new String[]{"phone","sourceTypeStr","rtypeStr","carrierStr","city",
                    "createTime", "moneyStr", "rstatusStr", "orderNo", "buyOrderNo"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, rechargeList, properties);
        } catch (Exception e) {
            logger.error("充值记录详情导出失败"+e.getMessage(), e);
            e.printStackTrace();
        }
    }
    
    @RequestMapping(value = "/bizsearch/business-list")
    public String businessList(HttpServletRequest request, HttpServletResponse response, BizSearch bizSearch) {
        List<Biz> bizList = new ArrayList<Biz>();
        
        Map<String, Object> params = new HashMap<String, Object>();
        PageEntity pageEntity = new PageEntity(bizSearch.getPageSize(), bizSearch.getPageIndex());
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;
        params.put("limit", limit);
        params.put("offset", offset);
        if (StringUtils.isNotEmpty(bizSearch.getPhone())) {
            params.put("phone", bizSearch.getPhone());
        }
        if (StringUtils.isNotEmpty(bizSearch.getType())) {
            params.put("r_type", bizSearch.getType());
        }
        if (StringUtils.isNotEmpty(bizSearch.getStatus())) {
            params.put("r_status", bizSearch.getStatus());
        }
        if (StringUtils.isNotEmpty(bizSearch.getStartDate())) {
            params.put("start_time", bizSearch.getStartDate());
        }
        if (StringUtils.isNotEmpty(bizSearch.getEndDate())) {
            params.put("end_time", bizSearch.getEndDate()+" 23:59:59");
        }
        // 分页查询
        bizList = bizSearchService.selectBizByCondition(params);
        // 总数
        int total = bizSearchService.countBiz(params);
        pageEntity.setTotal(total);
        
        request.setAttribute("bizList", bizList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("bizSearch", bizSearch);
        
        return "/views/online/businesssearch.jsp";
    }
    
    
}
