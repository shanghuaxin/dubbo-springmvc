package com.agent.online.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.online.entity.BizBankInfo;

public interface BizBankInfoMapper extends BaseMapper<BizBankInfo, Integer> {
    
    public int updateAuditStatus(@Param(value="auditStatus") String auditStatus, @Param(value="bizId") Integer bizId);

}
