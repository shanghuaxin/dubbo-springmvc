package com.agent.online.entity;

import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.util.DateUtil;
import com.agent.util.Utils;

/**
 * 品牌动态
 * @author zhangwei
 *
 */
public class BrandDynamic extends BaseDomain {

    /**
     * 
     */
    private static final long serialVersionUID = 8066562715637233005L;
    
    private String title ;//'标题',
    private String content ;//'内容',
    private String sysType ;//系统类型：online-网厅，wap-掌厅
    private String status ;//状态：1-待发布，2-已发布，3-已关闭
    private Date dynamicTime ;// '动态时间',
    private Date releaseTime ;// '发布时间',
    private Date validTime ;// '有效时间',
    private String isHome ;// '是否首页展示：1-是，2-否
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContent() {
        return content;
    }
    public String getContentStr() {
        if(!Utils.isEmptyString(content)){
            if(content.length() > 50){
                return content.substring(0, 50)+"......";
            }else{
                return content;
            }
        }
        return "";
    }
    public void setContent(String content) {
        this.content = content;
    }
    public Date getDynamicTime() {
        return dynamicTime;
    }
    public String getDynamicTimeStrYMD() {
        return dynamicTime !=null ? DateUtil.getInstance().getDateStr(dynamicTime,DateUtil.yyyy_MM_dd) : "";
    }
    public void setDynamicTime(Date dynamicTime) {
        this.dynamicTime = dynamicTime;
    }
    public Date getReleaseTime() {
        return releaseTime;
    }
    public String getReleaseTimeStrYMD() {
        return releaseTime !=null ? DateUtil.getInstance().getDateStr(releaseTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }
    public String getStatus() {
        return status;
    }
    public String getStatusStr() {
        if("1".equals(status)){
            return "待发布";
        }else if("2".equals(status)){
            return "已发布";
        }else if("3".equals(status)){
            return "已关闭";
        }
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Date getValidTime() {
        return validTime;
    }
    public String getValidTimeStrYMD() {
        return validTime !=null ? DateUtil.getInstance().getDateStr(validTime,DateUtil.yyyy_MM_dd) : "";
    }
    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }
    public String getIsHome() {
        return isHome;
    }
    public String getIsHomeStr() {
        if("1".equals(isHome)){
            return "是";
        }else if("2".equals(isHome)){
            return "否";
        }
        return isHome;
    }
    public void setIsHome(String isHome) {
        this.isHome = isHome;
    }
    public String getSysTypeStr() {
        if("online".equals(sysType)){
            return "网厅";
        }else if("wap".equals(sysType)){
            return "掌厅";
        }else{
            return "";
        }
    }
    public String getSysType() {
        return sysType;
    }
    public void setSysType(String sysType) {
        this.sysType = sysType;
    }
    @Override
    public String toString() {
        return "BrandDynamic [title=" + title + ", content=" + content + ", sysType=" + sysType + ", status=" + status
                + ", dynamicTime=" + dynamicTime + ", releaseTime=" + releaseTime + ", validTime=" + validTime
                + ", isHome=" + isHome + "]";
    }
}
