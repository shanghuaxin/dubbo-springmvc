package com.agent.online.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.common.DataTable;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.constant.Constant;
import com.agent.file.utils.FileUtil;
import com.agent.online.dto.ActivityDTO;
import com.agent.online.dto.BrandDynamicSaveDTO;
import com.agent.online.entity.Activity;
import com.agent.online.entity.ActivityAttr;
import com.agent.online.entity.BrandDynamic;
import com.agent.online.entity.InvoiceApply;
import com.agent.online.entity.Suggest;
import com.agent.online.service.ActivityService;
import com.agent.online.service.BrandDynamicService;
import com.agent.online.service.InvoiceApplyService;
import com.agent.online.service.SuggestService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;

/**
 * 网厅后台管理
 * @author auto
 */
@Controller
@RequestMapping(value="online")
public class OnlineController {
    private static Logger logger = LoggerFactory.getLogger(OnlineController.class);
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    @Autowired
    private ActivityService activityService;
    @Autowired
    private InvoiceApplyService invoiceApplyService;
    @Autowired
    private SuggestService suggestService;
    @Autowired
    private BusinessLogService businessLogService;
    @Autowired
    private BrandDynamicService brandDynamicService;
    
    @RequestMapping(value = "/activity/list")
    public String activityList(HttpServletRequest request, HttpServletResponse response, ActivityDTO activityDTO) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            PageEntity pageEntity = new PageEntity(activityDTO.getPageSize(), activityDTO.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(activityDTO.getActivityName())) {
                params.put("activityName", activityDTO.getActivityName().trim());
                activityDTO.setActivityName(activityDTO.getActivityName().trim());
            }
            // 分页查询
            List<ActivityDTO> list = activityService.selectActivity(params);
            // 总数
            int total = activityService.count(params);
            pageEntity.setTotal(total);
            
            request.setAttribute("activityList", list);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("resourceIP", resourceIP);
            request.setAttribute("activityDTO", activityDTO);
        } catch (Exception e) {
            logger.error("查询活动异常："+e.getMessage(), e);
        }
        return "/views/online/activity.jsp";
    }
    
    @RequestMapping(value = "/activity/initAdd", method=RequestMethod.GET)
    public String activityInitAdd(HttpServletRequest request, HttpServletResponse response) {
        return "/views/online/activity_add.jsp";
    }
    
    @RequestMapping(value = {"/activity/add"}, method = RequestMethod.POST, produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String activityAdd(HttpServletRequest request, HttpServletResponse response,
            ActivityDTO activityDTO) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        StringBuffer str = new StringBuffer();
        try {
            // 上传图片到服务器中，并返回图片相对路径，保存到数据库中
            String activityImagePath = FileUtil.saveImageFile(activityDTO.getActivityImageFile(), imageURL);
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Activity activity = new Activity();
            activity.setActivityName(activityDTO.getActivityName());
            activity.setActivityImagePath(activityImagePath);
            activity.setActivityLink(activityDTO.getActivityLink());
            activity.setActivityType(activityDTO.getActivityType());
            activity.setTitleBig(activityDTO.getTitleBig());
            activity.setTitleSmall(activityDTO.getTitleSmall());
            if (StringUtils.isNotEmpty(activityDTO.getEffectDate())) {
                activity.setEffectDate(activityDTO.getEffectDate()+" 00:00:00");
            }
            if (StringUtils.isNotEmpty(activityDTO.getExpiryDate())) {
                activity.setExpiryDate(activityDTO.getExpiryDate()+" 23:59:59");
            }
            activity.setSort(activityDTO.getSort());
            activity.setStatus(activityDTO.getStatus());
            activity.setRemark(activityDTO.getRemark());
            activityService.insertActivity(activity);
            
            // 类型为更多产品时，才需要设置附加属性表
            if (activityDTO.getActivityType() == 5) {
                Integer activityId = activity.getId();
                ActivityAttr activityAttr = new ActivityAttr();
                activityAttr.setActivityId(activityId);
                activityAttr.setTitle(activityDTO.getTitle());
                activityAttr.setTitle1(activityDTO.getTitle1());
                activityAttr.setContent1(activityDTO.getContent1());
                activityAttr.setTitle2(activityDTO.getTitle2());
                activityAttr.setContent2(activityDTO.getContent2());
                activityAttr.setTitle3(activityDTO.getTitle3());
                activityAttr.setContent3(activityDTO.getContent3());
                activityService.insertActivityAttr(activityAttr);
            }
            
            // 记录日志
            businessSaveLog(user, Business.technology_activity_add, activityDTO.getActivityName(), "新增活动");
        } catch (Exception e) {
            logger.error("新增活动异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("result", "新增活动异常");
        }
        str.append("FILE@UPLOAD");
        str.append(map.get("status")).append(":");
        str.append(map.get("result"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
    
    @RequestMapping(value = "/activity/initEdit", method=RequestMethod.GET)
    public String activityInitEdit(HttpServletRequest request, HttpServletResponse response, Integer id) {
        // 根据ID获取要编辑的活动对象
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("id", id);
        List<ActivityDTO> activityList = activityService.selectActivity(map);
        ActivityDTO activityDTO = null;
        if (null!=activityList && activityList.size()>0) {
            activityDTO = activityList.get(0);
        }
        request.setAttribute("activityDTO", activityDTO);
        request.setAttribute("resourceIP", resourceIP);
        return "/views/online/activity_edit.jsp";
    }
    
    @RequestMapping(value = {"/activity/edit"}, method = RequestMethod.POST, produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String activityEdit(HttpServletRequest request, HttpServletResponse response, ActivityDTO activityDTO) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        StringBuffer str = new StringBuffer();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            // 上传图片到服务器中，并返回图片相对路径，保存到数据库中
            String activityImagePath = null;
            if(activityDTO.getActivityImageFile() != null && activityDTO.getActivityImageFile().getSize() > 0){
                activityImagePath = FileUtil.saveImageFile(activityDTO.getActivityImageFile(), imageURL);
            }
            // 获取数据库中原始的对象
            Activity activity = new Activity();
            activity.setId(activityDTO.getId());
            activity.setActivityName(activityDTO.getActivityName());
            if (null != activityImagePath) {
                activity.setActivityImagePath(activityImagePath);
            } else {
                activity.setActivityImagePath(activityDTO.getActivityImagePath());
            }
            activity.setActivityLink(activityDTO.getActivityLink());
            activity.setActivityType(activityDTO.getActivityType());
            activity.setTitleBig(activityDTO.getTitleBig());
            activity.setTitleSmall(activityDTO.getTitleSmall());
            if (StringUtils.isNotEmpty(activityDTO.getEffectDate())) {
                activity.setEffectDate(activityDTO.getEffectDate());
            }
            if (StringUtils.isNotEmpty(activityDTO.getExpiryDate())) {
                activity.setExpiryDate(activityDTO.getExpiryDate());
            }
            activity.setSort(activityDTO.getSort());
            activity.setStatus(activityDTO.getStatus());
            activity.setRemark(activityDTO.getRemark());
            activityService.updateActivity(activity);
            
            // 获取数据库中原始的对象
            ActivityAttr activityAttrOld = activityService.selectActivityAttrById(activityDTO.getId());
            // 类型为5时，如果原来有附加属性，就更新，否则新增
            if (activityDTO.getActivityType() == 5) {
                ActivityAttr activityAttr = new ActivityAttr();
                activityAttr.setActivityId(activityDTO.getId());
                activityAttr.setTitle(activityDTO.getTitle());
                activityAttr.setTitle1(activityDTO.getTitle1());
                activityAttr.setContent1(activityDTO.getContent1());
                activityAttr.setTitle2(activityDTO.getTitle2());
                activityAttr.setContent2(activityDTO.getContent2());
                activityAttr.setTitle3(activityDTO.getTitle3());
                activityAttr.setContent3(activityDTO.getContent3());
                if (null != activityAttrOld) {
                    // 修改
                    activityService.updateActivityAttr(activityAttr);
                } else {
                    // 新增
                    activityService.insertActivityAttr(activityAttr);
                }
            } else {
                // 类型不等于5时，如果原来有附件属性，则删除
                if (null != activityAttrOld) {
                    activityService.deleteActivityAttr(activityDTO.getId());
                }
            }
            // 记录日志
            businessSaveLog(user, Business.technology_activity_edit, activityDTO.getActivityName(), "修改活动");
        } catch (Exception e) {
            logger.error("编辑活动异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("result", "编辑活动异常");
        }
        str.append("FILE@UPLOAD");
        str.append(map.get("status")).append(":");
        str.append(map.get("result"));
        str.append("FILE@UPLOAD");
        return str.toString();
    }
    
    /**
     * 发布活动
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "activity/release/{id}", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> activityRelease(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            // 获取数据库中原始的对象
            Activity activity = activityService.selectActivityById(id);
            activity.setStatus(1);
            activityService.updateActivityStatus(activity);
            // 记录日志
            businessSaveLog(user, Business.technology_activity_release, activity.getActivityName(), "发布活动");
        } catch (Exception e) {
            logger.error("关闭活动异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "关闭活动异常");
        }
        return map;
    }
    
    /**
     * 关闭活动
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "activity/close/{id}", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> activityClose(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            // 获取数据库中原始的对象
            Activity activity = activityService.selectActivityById(id);
            activity.setStatus(0);
            activityService.updateActivityStatus(activity);
            // 记录日志
            businessSaveLog(user, Business.technology_activity_close, activity.getActivityName(), "关闭活动");
        } catch (Exception e) {
            logger.error("关闭活动异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "关闭活动异常");
        }
        return map;
    }
    
    /**
     * 发票打印
     * @param request
     * @param response
     * @param invoiceApply
     * @return
     */
    @RequestMapping(value = "/invoice/list")
    public String invoiceList(HttpServletRequest request, HttpServletResponse response, InvoiceApply invoiceApply) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            PageEntity pageEntity = new PageEntity(invoiceApply.getPageSize(), invoiceApply.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(invoiceApply.getPhone())) {
                params.put("phone", invoiceApply.getPhone());
            }
            if (StringUtils.isNotEmpty(invoiceApply.getBillCycle())) {
                params.put("billCycle", invoiceApply.getBillCycle());
            }
            if (null != invoiceApply.getStatus()) {
                params.put("status", invoiceApply.getStatus());
            }
            // 分页查询
            List<InvoiceApply> invoiceApplyList = invoiceApplyService.selectByCondition(params);
            // 总数
            int total = invoiceApplyService.count(params);
            pageEntity.setTotal(total);
            
            String minDate = "2015-09-30";
            String maxDate = DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd");
            
            request.setAttribute("invoiceApplyList", invoiceApplyList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("invoiceApply", invoiceApply);
            request.setAttribute("minDate", minDate);
            request.setAttribute("maxDate", maxDate);
        } catch (Exception e) {
            logger.error("查询发票打印信息异常："+e.getMessage(), e);
        }
        return "/views/online/invoice.jsp";
    }
    
    /**
     * 打印发票（这个只是做标记，真正的打印还是要依赖线下财务那边处理）
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "invoice/print/{id}", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> invoicePrint(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try {
            InvoiceApply invoiceApply = new InvoiceApply();
            invoiceApply.setId(id);
            invoiceApply.setStatus(1);
            invoiceApplyService.updateStatus(invoiceApply);
        } catch (Exception e) {
            logger.error("打印发票异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "打印发票异常");
        }
        return map;
    }
    
    /**
     * 导出发票打印记录
     * @param request
     * @param response
     * @param invoiceApply
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/invoice/exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, InvoiceApply invoiceApply) {
        logger.info("-------------发票打印记录导出开始-------------");
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            // 最大导出5000条记录
            params.put("limit", 0);
            params.put("offset", 5000);
            if (StringUtils.isNotEmpty(invoiceApply.getPhone())) {
                params.put("phone", invoiceApply.getPhone());
            }
            if (StringUtils.isNotEmpty(invoiceApply.getBillCycle())) {
                params.put("billCycle", invoiceApply.getBillCycle());
            }
            if (null != invoiceApply.getStatus()) {
                params.put("status", invoiceApply.getStatus());
            }
            // 分页查询
            List<InvoiceApply> invoiceApplyList = invoiceApplyService.selectByCondition(params);
            
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "发票打印记录" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"时间","申请账号" ,"账期" ,"金额" ,"发票抬头" ,"税号" , "收件人" ,"收件人手机", "详细地址", "邮编", "状态" };
            properties = new String[]{"updateTimeStr", "phone" ,"billCycle" ,"billDueStr" ,"invoiceTitle" ,"taxNumber", "receiver", "receiverPhone", "invoiceAddress", "postcode", "statusStr"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, invoiceApplyList, properties);
        } catch (Exception e) {
            logger.error("导出发票打印记录异常："+e.getMessage(), e);
        }
        logger.info("-------------发票打印记录导出结束-------------");
    }
    
    /**
     * 新版吐槽
     * @param request
     * @param response
     * @param invoiceApply
     * @return
     */
    @RequestMapping(value = "/suggest/list")
    public String suggestList(HttpServletRequest request, HttpServletResponse response, Suggest suggest) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            PageEntity pageEntity = new PageEntity(suggest.getPageSize(), suggest.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(suggest.getSuggestUser())) {
                params.put("phone", suggest.getSuggestUser());
            }
            params.put("suggestType", 1);
            // 分页查询
            List<Suggest> suggestList = suggestService.selectByCondition(params);
            // 总数
            int total = suggestService.count(params);
            pageEntity.setTotal(total);
            
            request.setAttribute("suggestList", suggestList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("suggest", suggest);
        } catch (Exception e) {
            logger.error("查询发票打印信息异常："+e.getMessage(), e);
        }
        return "/views/online/suggest.jsp";
    }
    
    /**
     * 新版吐槽
     * @param request
     * @param response
     * @param invoiceApply
     * @return
     */
    @RequestMapping(value = "/suggest/applyInit/{id}")
    public String applyInit(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {
        request.setAttribute("id", id);
        return "/views/online/suggest_apply.jsp";
    }
    
    /**
     * 新版吐槽回复
     * @param request
     * @param response
     * @param invoiceApply
     * @return
     */
    @RequestMapping(value = "/suggest/apply")
    @ResponseBody
    public Map<String, Object> apply(HttpServletRequest request, HttpServletResponse response, Integer id, String applyContent) {
        
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Suggest suggest = new Suggest();
            suggest.setId(id);
            suggest.setApplyContent(applyContent);
            suggest.setApplyPersonId(user.getLoginName());
            suggest.setApplyStatus(1);
            suggestService.updateApply(suggest);
        } catch (Exception e) {
            logger.error("新版吐槽回复异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "新版吐槽回复异常");
        }
        return map;
    }
    
    /**
     * 记录日志
     * @param user
     * @param title
     * @param businessName
     */
    private void businessSaveLog(User user, String logType, String title, String businessName) {
        // 记录日志
        Map<String,String> logMap = new HashMap<String,String>();
        logMap.put("staff", user.getLoginName());
        logMap.put("title", title);
        logMap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logMap.put("result","成功！");
        businessLogService.businessSaveLog(logType, String.valueOf(user.getId()), user.getLoginName(), "", businessName, logMap);
    }
    
    
    /**
     * 品牌动态
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "/brand/list", method = RequestMethod.GET)
    public String brandList(HttpServletRequest request, HttpServletResponse response) {
        return "/views/online/brandList.jsp";
    }
    
    /**
     * 品牌动态
     * @param request
     * @param response
     * @param invoiceApply
     * @return
     */
    @RequestMapping(value = "/brand/list")
    @ResponseBody
    public DataTable<BrandDynamicSaveDTO> brandList(DataTable<BrandDynamicSaveDTO> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("status", request.getParameter("status"));
            searchMap.put("isHome",request.getParameter("isHome"));
            searchMap.put("sysType",request.getParameter("sysType"));
            searchMap.put("validTimeStart",request.getParameter("validTimeStart"));
            searchMap.put("validTimeEnd",request.getParameter("validTimeEnd"));
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return brandDynamicService.brandList(dt, searchMap,resourceIP);
        }catch(Exception e){
            logger.error("查看 品牌动态失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 进入保存品牌动态
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "/brand/save", method = RequestMethod.GET)
    public String brandAdd(HttpServletRequest request, HttpServletResponse response,Model model) {
        model.addAttribute("resourceIP", resourceIP);
        return "/views/online/brandSave.jsp";
    }
    
    /**
     * 新增品牌信息
     * @param brand
     * @param request
     * @return
     */
    @RequestMapping(value = "/brand/save", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus brandInsert(BrandDynamicSaveDTO brand,HttpServletRequest request) {
        try{
            User us = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            brandDynamicService.save(brand,us);
        }catch(Exception e){
            logger.error("新增 品牌动态失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE,"500",e.getMessage());
        }
        return new RestStatus(Boolean.TRUE,"200","新增动态成功");
    }
    


    /**
     * 进入保存品牌动态
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value = "/brand/info", method = RequestMethod.GET)
    public String brandInfo(HttpServletRequest request, HttpServletResponse response,Model model) {
        model.addAttribute("resourceIP", resourceIP);
        return "/views/online/brandInfo.jsp";
    }
    
    /**
     * 查询品牌动态信息
     * @param brand
     * @param request
     * @return
     */
    @RequestMapping(value = "/brand/info/{brandId}", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus brandInfo(@PathVariable Integer brandId,HttpServletRequest request) {
        try{
            if(brandId == null){
                return new RestStatus(Boolean.FALSE,"1003","参数不能为空");
            }
            BrandDynamicSaveDTO findBrand = brandDynamicService.findById(brandId);
            if(null == findBrand){
                return new RestStatus(Boolean.FALSE,"1003","参数错误");
            }
            return new RestStatus(Boolean.TRUE,"200","查询品牌动态信息成功",findBrand);
        }catch(Exception e){
            logger.error("查询品牌动态信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE,"500","查询动态失败");
        }
    }
    /**
     * 关闭品牌动态
     * @param brand
     * @param request
     * @return
     */
    @RequestMapping(value = "/brand/close/{brandId}", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus brandClose(@PathVariable Integer brandId,HttpServletRequest request) {
        try{
            if(brandId == null){
                return new RestStatus(Boolean.FALSE,"1003","参数不能为空");
            }
            BrandDynamic findBrand = brandDynamicService.findById(brandId);
            if(null == findBrand){
                return new RestStatus(Boolean.FALSE,"1003","参数错误");
            }
            User us = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            BrandDynamic brand = new BrandDynamic();
            brand.setId(brandId);
            brand.setStatus("3");
            brand.setUpdateId(us.getId());
            brandDynamicService.closeBrand(brand,us);
        }catch(Exception e){
            logger.error("关闭品牌动态失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE,"500","关闭动态失败");
        }
        return new RestStatus(Boolean.TRUE,"200","关闭动态成功");
    }
    /**
     * 发布品牌动态
     * @param brand
     * @param request
     * @return
     */
    @RequestMapping(value = "/brand/release/{brandId}", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus brandRelease(@PathVariable Integer brandId,HttpServletRequest request) {
        try{
            if(brandId == null){
                return new RestStatus(Boolean.FALSE,"1003","参数不能为空");
            }
            BrandDynamic findBrand = brandDynamicService.findById(brandId);
            if(null == findBrand){
                return new RestStatus(Boolean.FALSE,"1003","参数错误");
            }
            User us = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            BrandDynamicSaveDTO brand = new BrandDynamicSaveDTO();
            brand.setId(brandId);
            brand.setStatus("2");
            brand.setUpdateId(us.getId());
            brandDynamicService.releaseBrand(brand,us);
        }catch(Exception e){
            logger.error("发布品牌动态失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            return new RestStatus(Boolean.FALSE,"500","发布动态失败");
        }
        return new RestStatus(Boolean.TRUE,"200","发布动态成功");
    }
}
