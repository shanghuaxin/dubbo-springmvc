package com.agent.online.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.QueryUser;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;

import com.agent.business.entity.MobileArea;
import com.agent.business.service.MobileAreaService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.UnicomStatus;
import com.agent.constant.Constant;
import com.agent.exception.BusException;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.dto.BizDTO;
import com.agent.online.entity.Biz;
import com.agent.online.entity.BizDuplicateSIM;
import com.agent.online.service.BizService;
import com.agent.online.service.DuplicateSIMService;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.service.AttachedDocumentsService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.ExcelUtils;

@Controller
@RequestMapping(value="duplicateSIM")
public class DuplicateSIMController {
    
    private static Logger logger = LoggerFactory.getLogger(DuplicateSIMController.class);
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    @Autowired
    private BizService bizService;
    @Autowired
    private DuplicateSIMService duplicateSIMService;
    @Autowired
    private AttachedDocumentsService documentsService;
    @Autowired
    private BOSSNewBuyService bossNewBuyService;
    @Autowired
    private MobileAreaService mobileAreaService;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    
    @RequestMapping("/duplicateSIMList" )
    public String duplicateSIMList(HttpServletRequest request, BizDTO dto, Integer pageSize, Integer pageIndex, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        
        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotBlank(dto.getPhone())) {
            params.put("phone", dto.getPhone());
        }
        
        if (StringUtils.isNotBlank(dto.getOperationTimeStr())) {
            params.put("operationTime", dto.getOperationTimeStr());
        }
        
        if (StringUtils.isNotBlank(dto.getWayType())) {
            params.put("wayType", dto.getWayType());
        }
        
        if (StringUtils.isNotBlank(dto.getLevel())) {
            params.put("level", dto.getLevel());
        }
        
        if (StringUtils.isNotBlank(dto.getCheckTimeStr())) {
            params.put("checkTime", dto.getCheckTimeStr());
        }
        
        if (StringUtils.isNotBlank(dto.getCheckStatus())) {
            params.put("checkStatus", dto.getCheckStatus());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<BizDTO> duplicateSIMList = bizService.listduplicateSIM(params);
        int total = bizService.countDuplicateSIM(params);
        pageEntity.setTotal(total);
        

        request.setAttribute("phoneLevel", DicUtil.getDictionarysByKey("PHONE_LEVEL_CODE"));
        request.setAttribute("duplicateSIMList", duplicateSIMList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("dto", dto);

        return "/views/olbiz/duplicateSIM/duplicateSIMlist.jsp";
    }
    
    //审核
    @RequestMapping("/audit" )
    public String audit(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");
        if(StringUtils.isBlank(idStr)){
            request.setAttribute("flag", "2");
            return "/views/olbiz/duplicateSIM/audit.jsp";
        }
        Integer id = Integer.parseInt(idStr);
        String sourceName = request.getParameter("type");
        
        //根据开户记录查看用户资料信息
        BizDuplicateSIM duplicateSIM = duplicateSIMService.findById(id);
        if(duplicateSIM == null){
            duplicateSIM = new BizDuplicateSIM();
        }
        
        List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
        List<AttachedDocuments> attachedDocuments = null;
        if(null != atts && atts.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : atts){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                attachedDocuments.add(s);
            }
        }
        
        request.setAttribute("id", id);
        request.setAttribute("type", sourceName);
        request.setAttribute("duplicateSIM", duplicateSIM);
        request.setAttribute("attachedDocuments", attachedDocuments);
        
        return "/views/olbiz/duplicateSIM/audit.jsp";
    }
    
    //审核
    @RequestMapping("/picShow" )
    public String picShow(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");
        Integer id = null;
        if (StringUtils.isEmpty(idStr)) {
            id = 0;
        } else {
            id = Integer.parseInt(request.getParameter("id"));
        }
        String sourceName = request.getParameter("type");
        
        List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
        List<AttachedDocuments> attachedDocuments = null;
        if(null != atts && atts.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : atts){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                attachedDocuments.add(s);
            }
        }

        request.setAttribute("attachedDocuments", attachedDocuments);
        
        return "/views/olbiz/duplicateSIM/picShow.jsp";
    }
    
    /**
     * 开卡取消
     */
    @ResponseBody
    @RequestMapping(value = "updateSimCancle", method = RequestMethod.POST)
    public Map<String,Object> updateSimCancle(@RequestParam("id") Integer id, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        try {
            RestStatus restStatus = duplicateSIMService.updateCardCancle(id, user);
            if(!restStatus.getStatus()){
                map.put("status", false);
                map.put("errorMsg", restStatus.getErrorMessage());
            }else{
                map.put("status", true);
            }
        }catch (BusException e) {
            map.put("status", false);
            map.put("errorMsg", e.getMessage());
            logger.error("错误信息：{}", e);
        } catch (Exception e) {
            map.put("status", false);
            map.put("errorMsg", e.getMessage());
            logger.error("错误信息：{}", e);
        }
        return map;
    }
    
    //审核不通过描述
    @RequestMapping("/auditDetail" )
    public String auditDetail(HttpServletRequest request, String phone, String pass, HttpSession session) {
        
        request.setAttribute("phone", phone);
        request.setAttribute("pass", pass);
        
        return "/views/olbiz/duplicateSIM/auditDetail.jsp";
    }
    
    /**
     * 靓号补换卡审核
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    @ResponseBody
    @RequestMapping(value = "updateCardVfnList", method = RequestMethod.POST)
    public Map<String,Object> updateDuplicateSIMVfnList(@RequestParam("phone") String phone, @RequestParam("pass") String pass, @RequestParam("opinion") String opinion, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        StringBuffer logStr = new StringBuffer();
        boolean hasSuccFlag = false;
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(StringUtils.isBlank(phone)){
            returnStr.append("需要进行审核的号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        String operate;
        if("1".equals(pass)){// true时通过,false不通过
           
            operate="审核通过";
        }else{
            operate="审核不通过";
        }
        
        Biz biz;
        try {
            biz = bizService.findByPhoneAndType(phone, BizType.DUPLICATE_SIM.getCode());
        } catch (Exception e1) {
            logger.error("实名补录审核失败，原因："+e1.getMessage(),e1);
            map.put("status",false);
            map.put("errorMsg", "号码异常,无法进行审核操作！") ;
            return map;
        }
        
        if("1".equals(pass)){
            //需要判断号码是中兴视通号码
            Map<String, Object> parment = new HashMap<>();
            parment.put("prefix", Integer.valueOf(phone.substring(0, 7)));
            parment.put("virtualCode", MobileArea.virtual_code_zxst);
            MobileArea ps = mobileAreaService.findByPrefix(parment);
            if("YD".equals(ps.getCarrier())){
              //查询用户信息
                TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
                bo.setMSISDN("86"+biz.getPhone());
                RestStatus rs;
                String bal = "";   //基本余额，单位：分
                try {
                    rs = bossNewBuyService.QueryUserProfileBOSS(bo, new User());
                    if(rs.getStatus()){
                        TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
                        bal = res.getBal();
                    }else{
                        logger.error("实名补录审核失败，原因：" + rs.getErrorMessage());
                        map.put("status",false);
                        map.put("errorMsg", "号码异常,无法进行审核操作！") ;
                        return map;
                    }
                } catch (Exception e) {
                    logger.error("查询用户信息调用接口错误：phone=" + biz.getPhone() + "，原因：" + e.getMessage(), e);
                    map.put("status",false);
                    map.put("errorMsg", "系统网络异常，请联系客服！") ;
                    return map;
                }
                
                //订购需要比较账户余额
                BigDecimal balance = new BigDecimal(bal);  //账户基本余额，单位:元
                //比较账户金额是否能够订购流量套餐
                if(balance.compareTo(biz.getMoney()) < 0) {
                    logger.error("用户" + biz.getPhone() + "账户余额不足，不能办理补换卡业务！");
                    map.put("status",false);
                    map.put("errorMsg", "账户余额不足，不能办理补换卡业务！") ;
                    return map;
                }
            } else if("LT".equals(ps.getCarrier())){
                QueryUser cd = new QueryUser();
                cd.setQueryValue(biz.getPhone());
                cd.setQueryType("0");
                cd.setProductId("-1");
                cd.setCityCode("360");
                RestStatus  rs = bossUnicomService.queryUserService(cd,user);
                if(rs.getStatus()){
                    ContractRoot cr = (ContractRoot)rs.getResponseData();
                    if(!"109999".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                        map.put("status", false);
                        map.put("msg", "号码："+biz.getPhone()+"当前状态为："+UnicomStatus.getName(Integer.valueOf(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())) + "，不可订购业务");
                        return map;
                    }else{
                        BigDecimal userBal = new BigDecimal(cr.getSvcCont().getUserInfoView().getUserInfo().getAvailableBalance());
                        map.put("bal",userBal);
                        
                        //比较账户金额是否能够订购流量套餐
                        if(userBal.compareTo(biz.getMoney()) < 0) {
                            logger.error("用户" + biz.getPhone() + "账户余额不足，不能办理补换卡业务！");
                            map.put("status",false);
                            map.put("errorMsg", "账户余额不足，不能办理补换卡业务！") ;
                            return map;
                        }
                    }
                }
            }
        }
        

        try{
            /**
             * synchronized (obj) {
             * 1.查询号码的审核状态
             * 2.判断是否为“审核中”
             * 3.1 如果非“审核中”状态，则修改状态
             * 3.2如果是“审核中”状态，则直接返回错误信息
             */
            synchronized (this) {
                // 1.查询号码的审核状态
                // 2.判断是否为“审核中”
                // 3.1如果是“审核中”、“已审核”状态，则直接返回错误信息
                if(StringUtils.equals(biz.getCheckStatus(), "6")){
//                               logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                    returnStr.append("号码补换卡审核失败，该手机号("+biz.getPhone()+")正在审核中！");
                    map.put("status",false);
                    map.put("errorMsg",returnStr) ;
                    return map;
                }if(StringUtils.equals(biz.getCheckStatus(), "2") || StringUtils.equals(biz.getCheckStatus(), "3")){
//                               logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                    returnStr.append("号码补换卡审核失败，该手机号("+biz.getPhone()+")已审核！");
                    map.put("status",false);
                    map.put("errorMsg",returnStr) ;
                    return map;
                }else{
                    // 3.2 如果非“审核中”状态，则修改状态
                    bizService.udpateCheckStatus("6", biz.getId());
                }
            }
            
            RestStatus restStatus = bizService.updateDuplicateSIMVfnList(biz.getId(), pass, opinion, user);
            
            if(!restStatus.getStatus()){
                if(restStatus.getErrorMessage()!=null){
                    if("1".equals(pass)){// true时通过,false不通过
                        returnStr.append(biz.getPhone()).append("补换卡审核失败！原因："+restStatus.getErrorMessage()+"</p>");
                        logStr.append(biz.getPhone()).append("补换卡审核失败！原因："+restStatus.getErrorMessage()+"</p>");
                    }else{
                        returnStr.append(biz.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                        logStr.append(biz.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                    }
                }else{
                    returnStr.append(biz.getPhone()).append(operate).append("失败！</p>");
                    logStr.append(biz.getPhone()).append(operate).append("失败！</p>");
                }
                map.put("status",false);
            }else{
                if("1".equals(pass)){//true时通过,false不通过
                    returnStr.append(biz.getPhone()).append("补换卡成功！</p>");
                    logStr.append(biz.getPhone()).append("补换卡成功！</p>");
                }else{
                    returnStr.append(biz.getPhone()).append("补换卡成功，补换卡审核结果为不通过！</p>");
                    logStr.append(biz.getPhone()).append("补换卡成功，补换卡审核结果为不通过！</p>");
                    
                }
                map.put("status",true);
                hasSuccFlag = true;
            }
        }catch (Exception e){
            bizService.udpateCheckStatus("1", biz.getId());
            
            logger.error("实名设置审核失败，原因："+e.getMessage(),e);
            returnStr.append(biz.getPhone()).append("审核失败！ </p>" + e.getMessage());
            logStr.append(biz.getPhone()).append("审核失败！</p>" + e.getMessage());
            map.put("status",false);
        }
        
        map.put("hasSuccFlag", hasSuccFlag);
        map.put("errorMsg",returnStr) ;
        return map;
        
    }
    
  //审核
    @RequestMapping("/view" )
    public String view(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");
        if(StringUtils.isBlank(idStr)){
            request.setAttribute("flag", "2");
            return "/views/olbiz/duplicateSIM/audit.jsp";
        }
        Integer id = Integer.parseInt(idStr);
        String sourceName = request.getParameter("type");
        
        //根据开户记录查看用户资料信息
        BizDuplicateSIM duplicateSIM = duplicateSIMService.findById(id);
        if(duplicateSIM == null){
            duplicateSIM = new BizDuplicateSIM();
        }
        
        BizDTO biz = bizService.findSIMById(duplicateSIM.getBizId());
        String reason = biz.getReason();
        
        List<AttachedDocuments> atts = documentsService.findBySourceIdAndSourceName(id, sourceName);
        List<AttachedDocuments> attachedDocuments = null;
        if(null != atts && atts.size() >0){
            attachedDocuments = new ArrayList<AttachedDocuments>();
            for(AttachedDocuments s : atts){
                s.setAttachmentUrl(resourceIP+ s.getAttachmentUrl());
                attachedDocuments.add(s);
            }
        }
        
        request.setAttribute("id", id);
        request.setAttribute("type", sourceName);
        request.setAttribute("reason", reason);
        request.setAttribute("duplicateSIM", duplicateSIM);
        request.setAttribute("attachedDocuments", attachedDocuments);
        
        return "/views/olbiz/duplicateSIM/view.jsp";
    }
    
    //补换卡
    @RequestMapping("/makeCard" )
    public String makeCard(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");

        Integer id = Integer.parseInt(idStr);
        
        request.setAttribute("id", id);
        
        return "/views/olbiz/duplicateSIM/makeCard.jsp";
    }
    
    /**
     * 补换卡
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    @ResponseBody
    @RequestMapping(value = "duplicateCard", method = RequestMethod.POST)
    public Map<String,Object> duplicateCard(BizDuplicateSIM dto, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(dto.getId() == null){
            returnStr.append("号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(StringUtils.isBlank(dto.getNewICCID())) {
            returnStr.append("ICCID为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        if(StringUtils.isBlank(dto.getNewIMSI())) {
            returnStr.append("IMSI为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        BizDuplicateSIM sim;
        try {
            sim = duplicateSIMService.findById(dto.getId());
        } catch (Exception e1) {
            logger.error("补换卡失败，原因："+e1.getMessage(),e1);
            map.put("status",false);
            map.put("errorMsg", "号码异常,无法进行补换卡操作！") ;
            return map;
        }
        
        if(sim == null) {
            returnStr.append("号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        sim.setNewICCID(dto.getNewICCID());
        sim.setNewIMSI(dto.getNewIMSI());

        BizDTO biz = bizService.findSIMById(sim.getBizId());
        if(StringUtils.isNotBlank(biz.getNewICCID())) {
            returnStr.append("号码补换卡失败，该手机号("+biz.getPhone()+")补换卡已处理！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        try{
            
            RestStatus restStatus = bizService.duplicateCard(sim, user);
            
            if(!restStatus.getStatus()){
                returnStr.append(restStatus.getErrorMessage());
                map.put("status",false);
                map.put("errorMsg",returnStr) ;
                return map;
            }else{
                returnStr.append(restStatus.getErrorMessage());
                map.put("status",true);
                map.put("errorMsg",returnStr) ;
                return map;
            }
        }catch (Exception e){
            
            returnStr.append(e.getMessage());
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
    }
    
    //补换卡--物流信息
    @RequestMapping("/tracking" )
    public String tracking(HttpServletRequest request, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        String idStr = request.getParameter("id");

        Integer id = Integer.parseInt(idStr);
        
        request.setAttribute("id", id);
        
        return "/views/olbiz/duplicateSIM/tracking.jsp";
    }
    
    /**
     * 补换卡
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    @ResponseBody
    @RequestMapping(value = "updateTrack", method = RequestMethod.POST)
    public Map<String,Object> updateTrack(BizDuplicateSIM dto, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(dto.getId() == null){
            returnStr.append("号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(StringUtils.isBlank(dto.getTrackingType())) {
            returnStr.append("物流公司为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        if(StringUtils.isBlank(dto.getTrackingNo())) {
            returnStr.append("快递单号为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        BizDuplicateSIM sim;
        try {
            sim = duplicateSIMService.findById(dto.getId());
        } catch (Exception e1) {
            logger.error("补换卡发货失败，原因："+e1.getMessage(),e1);
            map.put("status",false);
            map.put("errorMsg", "号码异常,无法进行补换卡操作！") ;
            return map;
        }
        
        if(sim == null) {
            returnStr.append("号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        BizDTO biz = bizService.findSIMById(sim.getBizId());
        if(StringUtils.isNotBlank(biz.getTrackingNo())) {
            returnStr.append("号码补换卡发货失败，该手机号("+biz.getPhone()+")已发货！");
            map.put("status",false);
            map.put("errorMsg",returnStr);
            return map;
        }
        
        sim.setTrackingType(dto.getTrackingType());
        sim.setTrackingNo(dto.getTrackingNo());

        try{
            
            RestStatus restStatus = bizService.updateTrack(sim, user);
            
            if(!restStatus.getStatus()){
                returnStr.append(restStatus.getErrorMessage());
                map.put("status",false);
                map.put("errorMsg",returnStr) ;
                return map;
            }else{
                returnStr.append(restStatus.getErrorMessage());
                map.put("status",true);
                map.put("errorMsg",returnStr) ;
                return map;
            }
        }catch (Exception e){
            
            returnStr.append(e.getMessage());
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
    }
    
    
    @RequestMapping("/trackDetailList" )
    public String trackDetailList(HttpServletRequest request, BizDTO dto, Integer pageSize, Integer pageIndex, HttpSession session) {
        
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        // 设置分页初始化数据
        PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
        
        Map<String, Object> params = new HashMap<String, Object>();

        params.put("trackStatus", "2");
        if (StringUtils.isNotBlank(dto.getPhone())) {
            params.put("phone", dto.getPhone());
        }
        
        if (StringUtils.isNotBlank(dto.getTrackingType())) {
            params.put("trackingType", dto.getTrackingType());
        }
        
        if (StringUtils.isNotBlank(dto.getTrackDateStr())) {
            params.put("trackDate", dto.getTrackDateStr());
        }

        if (StringUtils.isNotBlank(dto.getWayType())) {
            params.put("wayType", dto.getWayType());
        }
        
        if (StringUtils.isNotBlank(dto.getsDate())) {
            params.put("sDate", dto.getsDate());
        }
        
        if (StringUtils.isNotBlank(dto.geteDate())) {
            params.put("eDate", dto.geteDate());
        }
        
        // 从页面获取每页展示的条数
        int limit = 0;
        int offset = pageEntity.getPageSize();
        limit = (pageEntity.getPageIndex() - 1) * offset;

        params.put("limit", limit);
        params.put("offset", offset);
        List<BizDTO> duplicateSIMList = bizService.listduplicateSIM(params);
        int total = bizService.countDuplicateSIM(params);
        pageEntity.setTotal(total);
        

        request.setAttribute("phoneLevel", DicUtil.getDictionarysByKey("PHONE_LEVEL_CODE"));
        request.setAttribute("duplicateSIMList", duplicateSIMList);
        request.setAttribute("pageEntity", pageEntity);
        request.setAttribute("dto", dto);

        return "/views/olbiz/duplicateSIM/trackDetailList.jsp";
    }
    
    
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/duplicateSIMInfoExport",method=RequestMethod.GET)
    public void duplicateSIMInfoExport(HttpServletRequest request, HttpServletResponse response, BizDTO dto , Integer pageSize, HttpSession session){
        logger.info("-------------补换卡列表导出开始-------------");
        try {
            @SuppressWarnings("unused")
            User user = (User) session.getAttribute(Constant.SESSION_USER);

            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            
            Map<String, Object> params = new HashMap<String, Object>();

            if (StringUtils.isNotBlank(dto.getPhone())) {
                params.put("phone", dto.getPhone());
            }
            
            if (StringUtils.isNotBlank(dto.getOperationTimeStr())) {
                params.put("operationTime", dto.getOperationTimeStr());
            }
            
            if (StringUtils.isNotBlank(dto.getWayType())) {
                params.put("wayType", dto.getWayType());
            }
            
            if (StringUtils.isNotBlank(dto.getLevel())) {
                params.put("level", dto.getLevel());
            }
            
            if (StringUtils.isNotBlank(dto.getCheckTimeStr())) {
                params.put("checkTime", dto.getCheckTimeStr());
            }
            
            if (StringUtils.isNotBlank(dto.getCheckStatus())) {
                params.put("checkStatus", dto.getCheckStatus());
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;

            params.put("limit", limit);
            params.put("offset", offset);
            List<BizDTO> duplicateSIMList = bizService.listduplicateSIM(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "补换卡" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"申请时间","手机号码","是否靓号" ,"邮寄地址", "收货人" ,"收货人电话" ,"邮编" ,"渠道" ,"审核状态" ,"审核时间" };
            properties = new String[]{"operTimeStr", "phone", "levelStr" ,"address" ,"receiver" ,"receiverPhone" ,"postcode" ,"wayType" ,"checkStatusStr" ,"checkTimeString"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, duplicateSIMList, properties);
            
        } catch (Exception e) {
            logger.error("补换卡列表记录导出失败"+e.getMessage(), e);
        }
        logger.info("-------------补换卡列表导出结束-------------");
    }
    
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    @RequestMapping(value="/duplicateSIMDetailExport",method=RequestMethod.GET)
    public void duplicateSIMDetailExport(HttpServletRequest request, HttpServletResponse response, BizDTO dto , Integer pageSize, HttpSession session){
        logger.info("-------------补换卡记录列表导出开始-------------");
        try {
            @SuppressWarnings("unused")
            User user = (User) session.getAttribute(Constant.SESSION_USER);

            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            
            Map<String, Object> params = new HashMap<String, Object>();

            params.put("trackStatus", "2");
            if (StringUtils.isNotBlank(dto.getPhone())) {
                params.put("phone", dto.getPhone());
            }
            
            if (StringUtils.isNotBlank(dto.getTrackingType())) {
                params.put("trackingType", dto.getTrackingType());
            }
            
            if (StringUtils.isNotBlank(dto.getTrackDateStr())) {
                params.put("trackDate", dto.getTrackDateStr());
            }

            if (StringUtils.isNotBlank(dto.getWayType())) {
                params.put("wayType", dto.getWayType());
            }
            
            if (StringUtils.isNotBlank(dto.getsDate())) {
                params.put("sDate", dto.getsDate());
            }
            
            if (StringUtils.isNotBlank(dto.geteDate())) {
                params.put("eDate", dto.geteDate());
            }
            
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;

            params.put("limit", limit);
            params.put("offset", offset);
            List<BizDTO> duplicateSIMList = bizService.listduplicateSIM(params);
            String dateStr = DateUtil.getNowDateTimeString("yyyyMMdd");
            String downloadName = "补换卡记录" + dateStr;
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"手机号码","是否靓号" ,"ICCID" ,"IMSI" ,"物流公司" ,"物流单号" , "邮寄地址", "收货人" ,"收货人电话" ,"邮编" ,"发货时间", "渠道" };
            properties = new String[]{"phone", "levelStr" ,"newICCID" ,"newIMSI" ,"trackingType" ,"trackingNo", "address" ,"receiver" ,"receiverPhone" ,"postcode", "trackDateString", "wayType"};
        
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            util.exportExcel(response.getOutputStream(), headers, duplicateSIMList, properties);
            
        } catch (Exception e) {
            logger.error("补换卡记录列表记录导出失败"+e.getMessage(), e);
        }
        logger.info("-------------补换卡记录列表导出结束-------------");
    }

}
