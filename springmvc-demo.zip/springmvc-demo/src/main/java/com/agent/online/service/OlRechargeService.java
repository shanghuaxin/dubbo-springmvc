package com.agent.online.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.online.entity.OlRecharge;
import com.agent.online.mapper.OlRechargeMapper;

/**
 * 充值管理
 */
@Service("olRechargeService")
@Transactional(rollbackFor=Exception.class)
public class OlRechargeService {
    
    @Autowired
    private OlRechargeMapper olRechargeMapper;
    
    /**
     * 新增
     * @param entity
     * @return
     */
    public int insert(OlRecharge entity) {
        return olRechargeMapper.insert(entity);
    }
}
