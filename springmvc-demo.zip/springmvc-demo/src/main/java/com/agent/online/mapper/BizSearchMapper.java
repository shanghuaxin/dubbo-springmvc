package com.agent.online.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.online.entity.Biz;
import com.agent.online.entity.Recharge;

/**
 * @author auto
 */
@Repository
public interface BizSearchMapper extends BaseMapper<Recharge, Integer> {
    // 根据条件过滤
    public List<Recharge> selectByCondition(Map<String, Object> map);
    // 查询数量
    public int count(Map<String, Object> map);
    
    // 根据条件过滤
    public List<Biz> selectBizByCondition(Map<String, Object> map);
    // 查询数量
    public int countBiz(Map<String, Object> map);
}
