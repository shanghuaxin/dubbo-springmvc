package com.agent.online.entity;

import java.io.Serializable;
import java.util.Date;

import com.agent.online.common.OlBaseDomain;

/**
 * 补换卡信息表
 */
public class BizDuplicateSIM extends OlBaseDomain implements Serializable {

    private static final long serialVersionUID = 6426396352089453810L;
    private String phone;           //手机号码
    private String userPwd;         //服务密码
    private Integer bizId;          //业务办理表Id
    private String level;           //号码级别：0-普号，1-靓号
    private String address;         //邮寄地址
    private String newStatus;       //补换卡状态：1-待补换卡，2-补换卡完成
    private String newIMSI;         //新IMSI
    private String newICCID;        //新ICCID
    private String trackStatus;     //发货状态：1-待发货，2-发货完成
    /**
     * 物流代码 
     * 顺丰 SF 百世快递 HTKY 中通 ZTO 申通 STO 圆通 YTO 韵达 YD 邮政平邮 YZPY EMS EMS
     * 天天 HHTT 京东 JD 全峰 QFKD 国通 GTO 优速 UC 德邦 DBL 快捷 FAST 亚马逊 AMAZON 宅急送 ZJS
     */
    private String trackingType;    //物流公司
    private String trackingNo;      //物流单号
    private Date trackDate;         //发货时间
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public Integer getBizId() {
        return bizId;
    }

    public void setBizId(Integer bizId) {
        this.bizId = bizId;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(String newStatus) {
        this.newStatus = newStatus;
    }

    public String getNewIMSI() {
        return newIMSI;
    }

    public void setNewIMSI(String newIMSI) {
        this.newIMSI = newIMSI;
    }

    public String getNewICCID() {
        return newICCID;
    }

    public void setNewICCID(String newICCID) {
        this.newICCID = newICCID;
    }

    public String getTrackStatus() {
        return trackStatus;
    }

    public void setTrackStatus(String trackStatus) {
        this.trackStatus = trackStatus;
    }

    public String getTrackingType() {
        return trackingType;
    }

    public void setTrackingType(String trackingType) {
        this.trackingType = trackingType;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public Date getTrackDate() {
        return trackDate;
    }

    public void setTrackDate(Date trackDate) {
        this.trackDate = trackDate;
    }

    @Override
    public String toString() {
        return "BizDuplicateSIM [phone=" + phone + ", userPwd=" + userPwd + ", bizId=" + bizId + ", level=" + level
                + ", address=" + address + ", newStatus=" + newStatus + ", newIMSI=" + newIMSI + ", newICCID="
                + newICCID + ", trackStatus=" + trackStatus + ", trackingType=" + trackingType + ", trackingNo="
                + trackingNo + ", trackDate=" + trackDate + "]";
    }

}
