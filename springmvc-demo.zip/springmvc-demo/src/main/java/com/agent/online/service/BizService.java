package com.agent.online.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.example.usermonthfeelist.UserMonthFeeListRequest;
import org.example.usermonthfeelist.UserMonthFeeListResponse;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.api.service.IDCheckService;
import com.agent.business.entity.MobileArea;
import com.agent.business.service.MobileAreaService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.RestStatus;
import com.agent.number.entity.TNumber;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.dto.BizDTO;
import com.agent.online.dto.RealnameLookDTO;
import com.agent.online.entity.Biz;
import com.agent.online.entity.BizDuplicateSIM;
import com.agent.online.entity.OlCheck;
import com.agent.online.mapper.BizDuplicateSIMMapper;
import com.agent.online.mapper.BizMapper;
import com.agent.online.mapper.OlCheckMapper;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.HisIdentity;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.mapper.AttachedDocumentsMapper;
import com.agent.openaccount.mapper.HisIdentityMapper;
import com.agent.openaccount.mapper.IdcardInfoMapper;
import com.agent.openaccount.mapper.IdentityMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.SysConfig;

import namespace.webservice.crmsps.ChangeCardOrder;
import namespace.webservice.crmsps.ContractRoot;
import zsmart.ztesoft.com.xsd.TDuplicateSIMCardBOSSBO;
import zsmart.ztesoft.com.xsd.TModCustomerBOSSBO;


@Transactional(rollbackFor=Exception.class)
@Service("bizService")
public class BizService {
    
    private static Logger logger = LoggerFactory.getLogger(BizService.class);
    @Autowired
    private BizMapper bizMapper;
    @Autowired
    private OlCheckMapper checkMapper;
    @Autowired
    private BizDuplicateSIMMapper duplicateSIMMapper;
    @Autowired
    private BOSSNewBuyService bossNewBuyService;
    @Autowired
    private IDCheckService idCheckService;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    @Autowired
    private MobileAreaService mobileAreaService;
    @Resource
    private IdentityMapper identityMapper;
    @Resource
    private HisIdentityMapper hisIdentityMapper;
    @Autowired
    private AttachedDocumentsMapper documentsMapper;
    @Autowired
    private IdcardInfoMapper idcardInfoMapper;
    
    public Biz findByPhoneAndType(String phone, String bizType) {
        return bizMapper.findByPhoneAndType(phone, bizType);
    }
    
    public BizDTO findSIMById(Integer id) {
        return bizMapper.findSIMById(id);
    }
    
    public int udpateCheckStatus(String statusStr, Integer bizId) {
        return bizMapper.udpateCheckStatus(statusStr, bizId);
    }
    
    public List<BizDTO> listRealname(Map<String, Object> params) {
        List<BizDTO> list = new ArrayList<BizDTO>();
        params.put("statusNo", "4");
        List<BizDTO> dtos = bizMapper.listRealname(params);
        for (BizDTO dto : dtos) {
            dto.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(dto.getLevel()));
            list.add(dto);
        }
        return list;
    }
    

    public int countRealName(Map<String, Object> params) {
        return bizMapper.countRealName(params);
    }
    
    public List<BizDTO> listduplicateSIM(Map<String, Object> params) {
        List<BizDTO> list = new ArrayList<BizDTO>();
        params.put("statusNo", "4");
        List<BizDTO> dtos = bizMapper.listduplicateSIM(params);
        for (BizDTO dto : dtos) {
//            dto.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(dto.getLevel()));
            list.add(dto);
        }
        return list;
    }
    
    public int countDuplicateSIM(Map<String, Object> params) {
        return bizMapper.countDuplicateSIM(params);
    }
    
    public List<BizDTO> listCancel(Map<String, Object> params) {
        params.put("statusNo", "4");
        return bizMapper.listCancel(params);
    }
    
    public int countCancle(Map<String, Object> params) {
        return bizMapper.countCancle(params);
    }
    
    public List<Biz> list(Map<String, Object> params) {
        params.put("statusNo", "4");
        return bizMapper.list(params);
    }
    
    //实名设置审核
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateRealnameVfnList(RealnameLookDTO dto, User us) throws Exception {
        synchronized (BizService.class) {
            Biz biz = bizMapper.findByPhoneAndType(dto.getPhone(), BizType.REALNAME.getCode());
            /**
             * 1.查询号码的审核状态
             * 2.判断是否为“审核中”
             * 3.1 如果非“审核中”状态，则修改状态
             * 3.2如果是“审核中”状态，则直接返回错误信息
             */
            if (StringUtils.equals(biz.getCheckStatus(), "6")) {
                logger.error("号码审核失败，原因：该手机号("+biz.getPhone()+")正在审核中");
                return new RestStatus(Boolean.FALSE, "500", "号码审核失败，该手机号("+biz.getPhone()+")正在审核中！");
            } else if (StringUtils.equals(biz.getCheckStatus(), "2") || StringUtils.equals(biz.getCheckStatus(), "3")) {
                logger.error("号码审核失败，原因：该手机号("+biz.getPhone()+")正在审核中");
                return new RestStatus(Boolean.FALSE, "500", "号码审核失败，该手机号("+biz.getPhone()+")已审核！");
            } else {
                // 3.2 如果非“审核中”状态，则修改状态
                bizMapper.udpateCheckStatus("6", biz.getId());
            }
            BizDTO bizDto = null;
            String errorMessage = "实名设置审核失败！";
            try {
                bizDto = bizMapper.findRealnameById(biz.getId());
                if(bizDto == null) {
                    throw new Exception("实名补录审核失败，数据不存在！");
                }
                String statusType = "3";
                if ("1".equals(dto.getPass())) {
                    statusType = "2";
                    //调用国政通验证身份证号码真伪
                    String flag = DicUtil.getMapDictionary("SYS_CONFIG").get("REALNAME_IDCARD_VALID");
                    if (flag != null && flag.equals("true")) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("userId", bizDto.getCode());
                        jsonObject.put("userName", bizDto.getName());
                        jsonObject.put("needCharging", 1);
                        
                        String jsonStr = idCheckService.idCheck(jsonObject.toString(), us);
                        
                        JSONObject json = new JSONObject(jsonStr);
                        String result = json.getString("result");
                        String message = json.getString("message");
                        
                        if (StringUtils.equals("0", result)) {
                            statusType = "2";
                        } else if (StringUtils.equals("500", result) || StringUtils.equals("999", result)) {
                            logger.error("实名设置审核失败! 原因：身份证核验，" + message);
                            errorMessage = "实名设置审核失败! 原因：身份证核验，" + message;
                            throw new Exception(errorMessage);
                        } else {
                            // 审核不通过
                            dto.setPass("0");
                            statusType = "3";
                            dto.setOpinion("身份证核验：" + message);
                        }
                    }
                }
                
                bizDto.setCheckStatus(statusType);
                bizDto.setReason(dto.getOpinion());
                bizMapper.update(bizDto);
                
                // 审核表添加数据
                OlCheck check = new OlCheck();
                check.setSourceId(bizDto.getSourceId());
                check.setSourceType("ol_biz_realname");
                check.setPhone(bizDto.getPhone());
                check.setStatus(statusType);
                if (statusType == "2") {// true时通过,有通过时间
                    check.setPassDate(new Date());
                } 
                check.setCheckOpinion(dto.getOpinion());
                check.setCreateId(us.getId());
                check.setCreateTime(new Date());
                check.setUpdateId(us.getId());
                check.setUpdateTime(new Date());
                
                checkMapper.insert(check);
                
            } catch (Exception e) {
                logger.error("实名设置审核失败", e);
                throw new Exception(errorMessage);
            }
            
            //审核通过 修改开户记录表，图片，开户申请表
            if ("1".equals(dto.getPass())) {
                Map<String,Object> searchMap = new HashMap<String,Object>();
                searchMap.put("phone",dto.getPhone());
                searchMap.put("pStatusNot",TNumber.STATUS_CANCEL);
                List<Identity> identitys = identityMapper.list(searchMap);
                Identity identity = null;
                if(null != identitys && identitys.size() >0){
                    //有开户记录才可以修改
                    identity = identitys.get(0);
                    //开户历史记录备份
                    HisIdentity his = new HisIdentity();
                    BeanUtils.copyProperties(his, identity);
                    hisIdentityMapper.insert(his);
                    //修改开户信息附件归属
                    documentsMapper.upAttachment(identity.getId(), "t_identity", his.getId(), "t_his_identity");//修改图片归属
                    
                    //修改开户记录姓名，身份证。联系电话
                    identity.setCode(bizDto.getCode());
                    identity.setName(bizDto.getName());
                    identityMapper.updateNameCode(identity);
                    
                    if("checked".equals(dto.getIsReplace())){//替换开户照片
                        //复制过户附件信息给开户信息
                        List<AttachedDocuments> attr = documentsMapper.findBySourceIdAndSourceName(bizDto.getSourceId(), "ol_biz_realname");
                        for (AttachedDocuments att : attr) {
                            att.setSourceId(identity.getId());
                            att.setSourceName("t_identity");
                        }
                        documentsMapper.batchInsert(attr);
                    }
                }
                
                IdcardInfo idcardInfo = new IdcardInfo();
                idcardInfo.setName(bizDto.getName());
                idcardInfo.setSexual(dto.getSexual());
                idcardInfo.setNation(dto.getNation());
                idcardInfo.setOrgans(dto.getOrgans());
                idcardInfo.setIdNumber(bizDto.getCode());
                idcardInfo.setExpiryDate(dto.getExpiryDate());
                idcardInfo.setAddress(dto.getAddress());
                int totalCount = idcardInfoMapper.findCountByIdNumber(bizDto.getCode());
                if(totalCount == 0){
                    // 向身份证信息表添加数据
                    idcardInfoMapper.insert(idcardInfo);
                }else{
                    // 向身份证信息表更新数据
                    idcardInfoMapper.update(idcardInfo);
                }
            }
            
            //修改用户信息，调用过户接口
            if(StringUtils.equals(dto.getPass(), "1") && StringUtils.equals(bizDto.getFlag(), "1")) {
                // 查询调用调用BOSS接口是否打开
                String flag = SysConfig.getValue("SendToBoss");
                if (flag != null && flag.equals("true")) {
                    //需要判断号码是中兴视通号码
                    Map<String, Object> parment = new HashMap<>();
                    parment.put("prefix", Integer.valueOf(bizDto.getPhone().substring(0, 7)));
                    parment.put("virtualCode", MobileArea.virtual_code_zxst);
                    MobileArea ps = mobileAreaService.findByPrefix(parment);
                    logger.error("----------------------------- 号码：" + bizDto.getPhone() + "实名设置过户接口调用开始,时间："
                            + System.nanoTime() + "-----------------------------");
                    if ("YD".equals(ps.getCarrier())) {
                        // 移动号码
                        TModCustomerBOSSBO bo = new TModCustomerBOSSBO();
                        bo.setMSISDN("86" + bizDto.getPhone());
                        bo.setCertType("1");// 身份证
                        bo.setCertNbr(bizDto.getCode());
                        bo.setCustName(bizDto.getName());
                        
                        RestStatus rs1 = bossNewBuyService.ModCustomerBOSS(bo, "1", us);
                        
                        if (!rs1.getStatus()) {
                            logger.error("实名设置过户调用接口错误！" + rs1.getErrorMessage());
                            throw new Exception("实名设置过户调用接口错误！" + rs1.getErrorMessage());
                        }
                    } else {
                        // 联通号码
                    }
                    logger.error("-----------------------------号码：" + bizDto.getPhone() + "实名设置过户接口调用完成,时间："
                            + System.nanoTime() + "-----------------------------");
                }
            }
            
            return new RestStatus(Boolean.TRUE, "200", "实名设置审核成功！");
        }
    }
    
    //补换卡审核
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateDuplicateSIMVfnList(Integer bizId, String pass, String opinion, User us) throws Exception {
        synchronized (BizService.class) {
            RestStatus restStatus = new RestStatus(Boolean.TRUE, "200", "补换卡审核成功！");
            try {
                BizDTO biz = bizMapper.findSIMById(bizId);
                if(biz == null) {
                    return new RestStatus(Boolean.FALSE, "500", "补换卡审核失败，数据不存在！");
                }
                
                String statusType = "3";
                if ("1".equals(pass)) {// true时通过,false不通过
                    statusType = "2";
                    //靓号审核通过，补换卡状态更新为1
                    duplicateSIMMapper.updateNewStatus("1", bizId);
                }
                
                biz.setCheckStatus(statusType);
                biz.setReason(opinion);
                bizMapper.update(biz);
                
                // 审核表添加数据
                OlCheck check = new OlCheck();
                check.setSourceId(biz.getSourceId());
                check.setSourceType("ol_biz_duplicate_sim");
                check.setPhone(biz.getPhone());
                check.setStatus(statusType);
                if (statusType == "2") {// true时通过,有通过时间
                    check.setPassDate(new Date());
                } 
                check.setCheckOpinion(opinion);
                check.setCreateId(us.getId());
                check.setCreateTime(new Date());
                check.setUpdateId(us.getId());
                check.setUpdateTime(new Date());
                
                checkMapper.insert(check);
                
                /*if(StringUtils.equals(biz.getLevel(), "1")) {
                    // 查询调用调用BOSS接口是否打开
                    String flag = SysConfig.getValue("SendToBoss");
                    logger.error("接口配置：" + flag + "调用接口开始");
                    if (flag != null && flag.equals("true")) {
                        logger.info("----------------------------- 扣费开始调用接口 ,时间：" + System.nanoTime() + "-----------------------------");
                        String amountStr = String.valueOf(biz.getMoney().multiply(new BigDecimal(100)));
                        TDeductFeeBOSSBO bo = new TDeductFeeBOSSBO();
                        bo.setMSISDN("86" + biz.getPhone());
                        bo.setAmount(Long.valueOf(amountStr)*(-1));
//                        bo.setDays("");
                        bo.setAcctResCode("1001");
                        bo.setAcctItemTypeCode("320101");
                        bo.setChannelId("130");
                        try {
                            //这里需要调用扣费接口DeductFeeBOSS
                            RestStatus rs = bossNewBuyService.DeductFeeBOSS(bo, us);   // 调用停机保号停复机接口
                            if (!rs.getStatus()) {
                                restStatus = new RestStatus(Boolean.FALSE, "500", "补换卡审核失败！<br>" + rs.getErrorMessage());
                                throw new Exception(rs.getErrorMessage());
                            }
                        } catch (Exception e) {
                            logger.error("补换卡调用接口错误：phone=" + biz.getPhone() + "，原因：" + e.getMessage(), e);
                            throw new Exception(e.getMessage());
                        }
                        logger.info("-----------------------------扣费接口调用完成,时间：" + System.nanoTime() + "-----------------------------");
                    }
                }*/
            } catch (Exception e) {
                logger.error("补换卡审核失败", e);
                throw new Exception("补换卡审核失败");
            }
            
            return restStatus;
        }
    }
    

    public RestStatus duplicateCard(BizDuplicateSIM sim, User us) throws Exception {
        
        RestStatus restStatus = new RestStatus(Boolean.TRUE, "200", "补换卡审核成功！");
        
        try {
            sim.setNewStatus("2");
            sim.setTrackStatus("1");
            duplicateSIMMapper.duplicateCard(sim);
        } catch (Exception e) {
            logger.error("补换卡失败：phone=" + sim.getPhone() + "，原因：" + e.getMessage(), e);
            throw new Exception(e.getMessage());
        }
        
        //需要判断号码是中兴视通号码
        Map<String, Object> parment = new HashMap<>();
        parment.put("prefix", Integer.valueOf(sim.getPhone().substring(0, 7)));
        parment.put("virtualCode", MobileArea.virtual_code_zxst);
        MobileArea ps = mobileAreaService.findByPrefix(parment);
        // 查询调用调用BOSS接口是否打开
        String flag = SysConfig.getValue("SendToBoss");
        logger.error("接口配置：" + flag + "调用接口开始");
        if (flag != null && flag.equals("true")) {
            if("YD".equals(ps.getCarrier())){
                TDuplicateSIMCardBOSSBO bo = new TDuplicateSIMCardBOSSBO();
                bo.setMSISDN("86" + sim.getPhone());
                bo.setUserPwd(sim.getUserPwd());
                bo.setNewICCID(sim.getNewICCID());
                bo.setNewIMSI(sim.getNewIMSI());
                try {
                    //这里需要调用扣费接口DeductFeeBOSS
                    RestStatus rs = bossNewBuyService.DuplicateSIMCardBOSS(bo, us);   // 调用停机保号停复机接口
                    if (!rs.getStatus()) {
                        restStatus = new RestStatus(Boolean.FALSE, "500", "补换卡失败！<br>" + rs.getErrorMessage());
                        throw new Exception(rs.getErrorMessage());
                    }
                } catch (Exception e) {
                    logger.error("补换卡调用接口错误：phone=" + sim.getPhone() + "，原因：" + e.getMessage(), e);
                    throw new Exception(e.getMessage());
                }
            } else if("LT".equals(ps.getCarrier())){
                try {
                    // 综合信息查询接口
                    UserMonthFeeListRequest request = new UserMonthFeeListRequest();
                    request.setServiceId(sim.getPhone());
                    // 传空不用查询历史历史账单明细
                    request.setFeeDate("");
                    RestStatus rs = bossUnicomService.userMonthFeeList(request, us);
                    if (rs.getStatus()) {
                        UserMonthFeeListResponse resp = (UserMonthFeeListResponse) rs.getResponseData();
                        // 账户余额
                        BigDecimal balance = new BigDecimal(resp.getRestFee()).divide(com.agent.constant.Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
                        
                        // 此配置需要跟boss一致
                        String union_changecard_money = DicUtil.getMapDictionary("SYS_CONFIG").get("UNION_CHANGECARD_MONEY");
                        if(union_changecard_money==null || "".equals(union_changecard_money)){
                            union_changecard_money = "10.00";
                        }
                        // 余额足够扣款
                        if(balance.subtract(new BigDecimal(union_changecard_money)).doubleValue()>=0){
                            ChangeCardOrder changeCardOrder = new ChangeCardOrder();
                            changeCardOrder.setOperKind("00");
                            changeCardOrder.setServiceId(sim.getPhone());
                            changeCardOrder.setOldCard("");
                            changeCardOrder.setNewCard(sim.getNewICCID());
                            changeCardOrder.setChangeReason("1");
                            changeCardOrder.setChangeKind("0");
                            changeCardOrder.setExtOrderId(DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyyMMddHHmmssSSS));
                            // 生成补换卡订单
                            RestStatus vrs = bossUnicomService.changeCardOrder(us, changeCardOrder );
                            if (!vrs.getStatus()) {
                                restStatus = new RestStatus(Boolean.FALSE, "500", "补换卡失败！<br>" + vrs.getErrorMessage());
                                throw new Exception(vrs.getErrorMessage());
                            } else {
                                ContractRoot root = (ContractRoot)vrs.getResponseData();
                                String custOrderId = root.getSvcCont().getCustOrderId();
                                // 提交补换卡订单
                                vrs = bossUnicomService.doCompleteOrder(custOrderId, us);
                                if (!vrs.getStatus()) {
                                    restStatus = new RestStatus(Boolean.FALSE, "500", "补换卡失败！<br>" + vrs.getErrorMessage());
                                    throw new Exception(vrs.getErrorMessage());
                                }
                            }
                        } else {
                            restStatus = new RestStatus(Boolean.FALSE, "500", "补换卡失败！原因：账户余额不足");
                            throw new Exception("账户余额不足");
                        }
                    } else {
                        restStatus = new RestStatus(Boolean.FALSE, "500", "补换卡调用账户余额查询接口错误");
                        throw new Exception(rs.getErrorMessage());
                    }
                } catch (Exception e) {
                    logger.error("补换卡调用接口错误：phone=" + sim.getPhone() + "，原因：" + e.getMessage(), e);
                    throw new Exception(e.getMessage());
                }
            }
        }
        return restStatus;
    }
    
    public RestStatus updateTrack(BizDuplicateSIM sim, User us) throws Exception {
        
        try {
            sim.setTrackStatus("2");
            sim.setTrackDate(new Date());
            duplicateSIMMapper.updateTrack(sim);

        } catch (Exception e) {
            logger.error("补换卡更新物流信息失败：phone=" + sim.getPhone() + "，原因：" + e.getMessage(), e);
            throw new Exception("补换卡更新物流信息失败："+e.getMessage());
        }
        
        return new RestStatus(Boolean.TRUE, "200", "补换卡更新物流成功！");
    }
    
    /**
     * 在途工单查询
     * @param params
     * @return
     */
    public List<BizDTO> queryByPhone(Map<String, Object> params) {
        List<BizDTO> bizList = bizMapper.queryByPhone(params);
        return bizList;
    }
}
