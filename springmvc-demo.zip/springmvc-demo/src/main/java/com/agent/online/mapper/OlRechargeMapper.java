package com.agent.online.mapper;

import com.agent.common.BaseMapper;
import com.agent.online.entity.OlRecharge;

public interface OlRechargeMapper extends BaseMapper<OlRecharge, Integer> {
    
}
