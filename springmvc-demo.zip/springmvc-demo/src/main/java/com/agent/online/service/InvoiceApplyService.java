package com.agent.online.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.online.entity.InvoiceApply;
import com.agent.online.mapper.InvoiceApplyMapper;

/**
 * 发票管理
 * @author FengLu
 *
 */
@Service("invoiceApplyService")
@Transactional(rollbackFor=Exception.class)
public class InvoiceApplyService {
    
    @Autowired
    private InvoiceApplyMapper invoiceApplyMapper;
    
    // 根据条件过滤发票信息
    public List<InvoiceApply> selectByCondition(Map<String, Object> map) {
        return invoiceApplyMapper.selectByCondition(map);
    }
    // 查询数量
    public int count(Map<String, Object> map) {
        return invoiceApplyMapper.count(map);
    }
    // 修改发票打印的状态
    public int updateStatus(InvoiceApply entity) {
        return invoiceApplyMapper.updateStatus(entity);
    }
    // 删除发票打印记录
    public int delete(Integer id) {
        return invoiceApplyMapper.delete(id);
    }
}
