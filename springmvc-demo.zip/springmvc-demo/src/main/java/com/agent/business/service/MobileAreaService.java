package com.agent.business.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.business.entity.MobileArea;
import com.agent.business.mapper.MobileAreaMapper;

@Transactional(rollbackFor=Exception.class)
@Service
public class MobileAreaService {
    
    @Autowired
    private MobileAreaMapper mobileAreaMapper;
    
    /**
     * 根据号段获取号码信息
     * @param sectionNo 号段，号码的前七位数字
     * @return
     */
    public MobileArea findByPrefix(Map<String, Object> parment) {
        return mobileAreaMapper.findByPrefix(parment);
    }
}
