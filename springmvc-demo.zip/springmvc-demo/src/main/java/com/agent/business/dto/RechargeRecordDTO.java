package com.agent.business.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;
import com.agent.util.DateUtil;

/**
 * 订单扩展表
 */
public class RechargeRecordDTO extends BaseDomain {

    private static final long serialVersionUID = 98391634216008540L;
    // 订单编号
    private String orderNo;
    // 订单类型(1.流量 2.话费)
    private Integer orderType;
    // 办理业务的手机号码
    private String msisdn;
    // 渠道id
    private Integer channelId;
    // 商品id
    private String productCode;
    // 商品类型(1.运营商流量 2.运营商语音 3.COOL170实体卡密 4.COOL170虚拟卡密)
    private Integer productType;
    // 商品名称
    private String productName;
    // 订单总金额(单位：分)
    private BigDecimal orderMoney;
    // 商品成本价(单位：分)
    private BigDecimal costMoney;
    // 一级渠道佣金(单位：分)
    private BigDecimal bro1;
    // 二级渠道佣金(单位：分)
    private BigDecimal bro2;
    // 三级渠道佣金(单位：分)
    private BigDecimal bro3;
    // 订单状态(0.未完成订单 1.已完成订单 2.异常订单 3.已删除订单)
    private Integer status;
    // 订购回执时间
    private Date orderReceiptTime;
    // 来源 PC/APP
    private String source;
    // 备注
    private String remark;
    // 渠道名称
    private String channelName;
    // 直充账户扣款值
    private BigDecimal directAccount;
    // 划拨账户扣款值
    private BigDecimal allotAccount;
    // 网络 移动，联通，电信
    private String operator;
    
    /* 扩展属性 begin */
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    // 查询开始时间
    private String startDate;
    // 查询结束时间
    private String endDate;
    /* 扩展属性 end */

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Integer getProductType() {
        return productType;
    }
    
    public String getProductTypeStr() {
        if (1 == productType) {
            return "国内语音";
        } else if (2 == productType) {
            return "国际语音";
        } else if (3 == productType) {
            return "移动流量";
        } else if (4 == productType) {
            return "联通流量";
        } else if (5 == productType) {
            return "电信流量";
        }
        return "";
    }

    public void setProductType(Integer productType) {
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(BigDecimal orderMoney) {
        this.orderMoney = orderMoney;
    }

    public BigDecimal getCostMoney() {
        return costMoney;
    }

    public void setCostMoney(BigDecimal costMoney) {
        this.costMoney = costMoney;
    }

    public BigDecimal getBro1() {
        return bro1;
    }
    
    public String getBro1Yuan() {
        if(null != bro1){
            return Constant.df0.format(bro1.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setBro1(BigDecimal bro1) {
        this.bro1 = bro1;
    }

    public BigDecimal getBro2() {
        return bro2;
    }
    
    public String getBro2Yuan() {
        if(null != bro2){
            return Constant.df0.format(bro2.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setBro2(BigDecimal bro2) {
        this.bro2 = bro2;
    }

    public BigDecimal getBro3() {
        return bro3;
    }
    
    public String getBro3Yuan() {
        if(null != bro3){
            return Constant.df0.format(bro3.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setBro3(BigDecimal bro3) {
        this.bro3 = bro3;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getStatusStr() {
        String statusStr = "";
        if (null != status) {
            if (0 == status.intValue()) {
                statusStr = "充值中";
            } else if (1 == status.intValue()) {
                statusStr = "充值成功";
            } else if (2 == status.intValue()) {
                statusStr = "充值失败";
            } else if (3 == status.intValue()) {
                statusStr = "已删除";
            }
        }
        return statusStr;
    }

    public Date getOrderReceiptTime() {
        return orderReceiptTime;
    }
    
    public String getOrderReceiptTimeStr() {
        return orderReceiptTime !=null ? DateUtil.getInstance().getDateStr(orderReceiptTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }

    public void setOrderReceiptTime(Date orderReceiptTime) {
        this.orderReceiptTime = orderReceiptTime !=null ? DateUtil.getInstance().getDateDate(orderReceiptTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : null;;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public BigDecimal getDirectAccount() {
        return directAccount;
    }
    
    public String getDirectAccountYuan() {
        if(null != directAccount){
            return Constant.df0.format(directAccount.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setDirectAccount(BigDecimal directAccount) {
        this.directAccount = directAccount;
    }

    public BigDecimal getAllotAccount() {
        return allotAccount;
    }
    
    public String getAllotAccountYuan() {
        if(null != allotAccount){
            return Constant.df0.format(allotAccount.divide(Constant.cnt100)).toString();
        }
        return "";
    }

    public void setAllotAccount(BigDecimal allotAccount) {
        this.allotAccount = allotAccount;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "Order [id=" + super.getId() + ", orderNo=" + orderNo + ", orderType=" + orderType + ", msisdn=" + msisdn
                + ", channelId=" + channelId + ", productCode=" + productCode + ", productType=" + productType
                + ", productName=" + productName + ", orderMoney=" + orderMoney + ", status=" + status+ ", orderReceiptTime=" + getOrderReceiptTimeStr()
                + ", remark=" + remark + ", createId=" + super.getCreateId() + ", createTime=" + super.getCreateTimeStr()
                + ", updateId=" + super.getUpdateId() + ", updateTime=" + super.getUpdateTimeStr() + "]";
    }

}
