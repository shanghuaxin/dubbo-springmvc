package com.agent.business.mapper;

import org.springframework.stereotype.Repository;

import com.agent.business.entity.CardInfoRecord;
import com.agent.common.BaseMapper;

@Repository
public interface CardInfoRecordMapper extends BaseMapper<CardInfoRecord, Integer> {
    
}
