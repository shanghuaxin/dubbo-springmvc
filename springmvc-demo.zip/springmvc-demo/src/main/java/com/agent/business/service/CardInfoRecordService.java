package com.agent.business.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.business.entity.CardInfoRecord;
import com.agent.business.mapper.CardInfoRecordMapper;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service
public class CardInfoRecordService {
    
    private static Logger logger = (Logger) LoggerFactory.getLogger(CardInfoRecordService.class);
    
    @Autowired
    private CardInfoRecordMapper cardInfoRecordMapper;
    
    /**
     * 获取查询列表
     * @param param
     * @return
     */
    public List<CardInfoRecord> getRecordList(Map<String, Object> param) {
        List<CardInfoRecord> result = null;
        try {
            return cardInfoRecordMapper.list(param);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result = new ArrayList<CardInfoRecord>();
        }
        return result;
    }
    
    /**
     * 统计充值记录数
     * @param param
     * @return
     */
    public int countRecord(Map<String, Object> param) {
        return cardInfoRecordMapper.count(param);
    }
    
    /**
     * 往表t_card_info_record中添加一条记录
     * @param order
     * @return
     */
    public int insertRecord(CardInfoRecord card) {
        return cardInfoRecordMapper.insert(card);
    }
    
    /**
     * 更新t_card_info_record表
     * @param card
     * @return
     */
    public int updateRecord(CardInfoRecord card) {
        return cardInfoRecordMapper.update(card);
    }
}
