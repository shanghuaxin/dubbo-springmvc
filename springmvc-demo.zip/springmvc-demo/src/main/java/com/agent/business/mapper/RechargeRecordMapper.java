package com.agent.business.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.business.entity.RechargeRecord;
import com.agent.common.BaseMapper;

@Repository
public interface RechargeRecordMapper extends BaseMapper<RechargeRecord, Integer> {
    
    /**
     * 根据订单号获取订单信息
     * @param orderNo
     * @return
     */
    public RechargeRecord findByOrderNo(String orderNo);
    
    /**
     * 查询充值订单佣金
     * @param map
     * @return
     */
    public List<RechargeRecord> getOrderBro(Map<String, Object> map);
    
    /**
     * 查询充值订单数量
     * @param map
     * @return
     */
    public int countOrderBro(Map<String, Object> map);
    
    /**
     * 查询佣金详情
     * @param map
     * @return
     */
    public List<RechargeRecord> getOrderBroDetail(Map<String, Object> map);
    
    /**
     * 查询佣金详情总记录数
     * @param map
     * @return
     */
    public int countOrderBroDetail(Map<String, Object> map);
}
