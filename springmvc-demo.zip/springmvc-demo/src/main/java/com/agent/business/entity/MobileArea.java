package com.agent.business.entity;

import java.io.Serializable;

/**
 * 号码归属地表
 */
public class MobileArea implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 2923886749919738683L;
    /** 运营商*/
    public static final String carrier_YD = "YD";
    public static final String carrier_LT = "LT";
    public static final String carrier_DX = "DX";
    public static final String virtual_code_zxst = "ZXST";
    
    private Integer prefix;//号段
    private String carrier;//手机号码运营商(YD：移动   LT：联通   DX：电信   OT：其他)
    private String corp;//手机运营商
    private String provincePy;//手机归属省份拼音
    private String province;//手机归属省份
    private String city;//手机归属城市
    private String virtualCorp;//虚商名称
    private String virtualCode;//虚商编码
    
    public Integer getPrefix() {
        return prefix;
    }
    public void setPrefix(Integer prefix) {
        this.prefix = prefix;
    }
    public String getCarrier() {
        return carrier;
    }
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }
    public String getCorp() {
        return corp;
    }
    public void setCorp(String corp) {
        this.corp = corp;
    }
    public String getProvincePy() {
        return provincePy;
    }
    public void setProvincePy(String provincePy) {
        this.provincePy = provincePy;
    }
    public String getProvince() {
        return province;
    }
    public void setProvince(String province) {
        this.province = province;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getVirtualCorp() {
        return virtualCorp;
    }
    public void setVirtualCorp(String virtualCorp) {
        this.virtualCorp = virtualCorp;
    }
    public String getVirtualCode() {
        return virtualCode;
    }
    public void setVirtualCode(String virtualCode) {
        this.virtualCode = virtualCode;
    }
}
