package com.agent.business.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import com.agent.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.enumeration.OperationType;
import com.agent.number.service.NumberService;
import com.agent.product.entity.Product;
import com.agent.product.service.ProductService;
import com.agent.stock.service.CardInfoService;
import com.agent.stock.service.StockService;
import com.agent.system.entity.User;
import com.agent.system.service.CodeDictionaryService;

@Transactional(rollbackFor=Exception.class)
@Service
public class Cool170Service {
    
    @Resource
    private ChannelsService channelsService;
    
    @Resource
    private ChannelAccountService channelAccountService;
    
    @Resource
    private CodeDictionaryService codeDictionaryService;
    
    @Resource
    private CardInfoService cardInfoService;
    
    @Resource
    private CardInfoRecordService cardInfoRecordService;
    
    @Resource
    private StockService stockService;
    
    @Resource
    private ProductService productService;
    
    @Resource
    private NumberService numberService;
    
    /**
     * 获取查询列表
     * @param productInfo
     * @return
     * @throws Exception 
     * @throws  
     */
    public String replenish(User curUser, String productInfo) throws Exception {
        Channels channel = channelsService.findChannelByUserId(curUser.getId());
        String msg = "";
        
        BigDecimal totalMoney = new BigDecimal(0);
        // 计算价格，如果账户余额小于商品总和，则提示用户余额不足
        // productInfo的数据格式：productId,productNum; 50,12;51,2;
        if (StringUtils.isNotEmpty(productInfo)) {
            String[] productInfos = productInfo.split(";");
            for (int i = 0; i < productInfos.length; i++) {
                Map<String, Object> map = new HashMap<String, Object>();
                String productId = productInfos[i].split(",")[0];
                String productName = productInfos[i].split(",")[1];
                String productNum = productInfos[i].split(",")[2];
                map.put("channelId", "0");
                map.put("productId", productId);
                map.put("status", "0");
                map.put("expireStartdate", DateUtil.getInstance().formatDate(new Date(),DateUtil.yyyy_MM_dd));
                // 重新获取商品信息，计算商品总价，防止前台页面计算出错
                Product product = productService.findById(Integer.parseInt(productId));
                BigDecimal salePrice = product.getSalePrice();
                totalMoney = totalMoney.add(salePrice.multiply(new BigDecimal(Integer.parseInt(productNum))));
                // 查询当前商品的库存数量
                int stockNum = cardInfoService.listCardInfoCount(map);
                // 判断库存数量是否大于当前要补货的数量，如果大于则提示库存不足(因涉及到扣钱的逻辑，如果库存不足，不允许任何操作)
                if (stockNum < Integer.parseInt(productNum)) {
                    //msg += "商品【"+productName+"】的总库存为【"+stockNum+"】，数量不足，请重新选择！<br/>";
                    msg += "商品【"+productName+"】的总部库存数量不足，请重新选择！<br/>";
                }
            }
        }
        // errMsg为空，表示数量充足
        if (StringUtils.isEmpty(msg)) {
            // 构造takeMoney入参
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("us", curUser);
            param.put("channel", channel);
            param.put("productInfo", productInfo);
            param.put("totalMoney", totalMoney);
            param.put("operationType", OperationType.REPLENISH.getId());
            param.put("money", totalMoney.divide(new BigDecimal(100)));
            numberService.takeMoney(param);
            msg = "补货成功";
        }
        return msg;
    }
}
