package com.agent.business.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.business.entity.MobileArea;
import com.agent.business.service.MobileAreaService;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelsService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.UnicomStatus;
import com.agent.constant.Constant;
import com.agent.exception.SeeComException;
import com.agent.number.dto.BuyServDTO;
import com.agent.openaccount.dto.BuyServRecordListDTO;
import com.agent.openaccount.entity.BuyServiceRecord;
import com.agent.openaccount.mapper.BuyServiceRecordMapper;
import com.agent.openaccount.service.BuyService;
import com.agent.order.common.util.IpUtil;
import com.agent.product.entity.Packages;
import com.agent.product.service.PackagesService;
import com.agent.system.entity.Role;
import com.agent.system.entity.User;
import com.agent.system.service.MenuService;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.MD5;
import com.agent.util.SysConfig;
import com.agent.util.Utils;

import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.OfferWithStatus;
import namespace.webservice.crmsps.UserInfoView;
import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TService;
import zsmart.ztesoft.com.xsd.TUserServiceQryRequest;
import zsmart.ztesoft.com.xsd.TUserServiceQryResponse;

/**
 * Created by Administrator on 2016/11/9.
 * 业务办理
 */
@Controller
@RequestMapping(value="/buy-service")
public class BuyServiceController {
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private BOSSNewBuyService buyNewService;
    @Autowired
    private BOSSUnicomService bOSSUnicomService;
    @Autowired
    private PackagesService pacService;
    @Autowired
    private BuyService buyService;
    @Autowired
    private MenuService menuService;
    @Autowired
    private MobileAreaService mobileAreaService;
    @Autowired
    private BuyServiceRecordMapper buyServiceRecordMapper;

    private static Logger logger = LoggerFactory.getLogger(BuyServiceController.class);


    /**
     * 进入业务办理也
     * @return
     */
    @RequiresPermissions("buy-page")
    @RequestMapping(value = "buy-page", method = RequestMethod.GET)
    public String customer(Model model, HttpSession session) {
        return "/views/business/buyServ/buyService.jsp";
    }


    /***
     * 获取用户信息
     * @param request
     * @param dto
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "buy-user-info", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> userInfo(HttpServletRequest request, BuyServDTO dto, HttpSession session) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        RestStatus resCheck = buyService.checkData(dto);
        if (!resCheck.getStatus()) {
            map.put("status", false);
            map.put("msg", resCheck.getErrorMessage());
            return map;
        }
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(1 != channels.getStatus().intValue() && 3 != channels.getStatus().intValue()){
                map.put("status", false);
                map.put("msg", "对不起，您的渠道状态不正常，不能进行业务办理！");
                return map;
            }
            map.put("phone", dto.getPhone());
            Map<String, Object> parment = new HashMap<>();
            parment.put("prefix", Integer.valueOf(dto.getPhone().substring(0, 7)));
            parment.put("virtualCode", "ZXST");
            MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
            if(mobileArea == null){
                map.put("status", false);
                map.put("msg", "对不起，该号码为非中兴视通号码不能进行业务办理！");
                return map;
            }
            //查询所有套餐
            Map<String, Object> searchMap = new HashMap<String, Object>();
            Set<String> codeSet = new HashSet<String>();
            List<Packages> pacList = pacService.pacList(searchMap);
            if(null != pacList && pacList.size() >0){
                for(Packages p:pacList){
                    if(!codeSet.contains(p.getCode())){
                        codeSet.add(p.getCode());
                    }
                }
            }
            user.setPhone(dto.getPhone());
            map.put("network",mobileArea.getCarrier());
            List<TService> listBo = new ArrayList<TService>();
            if(MobileArea.carrier_YD.equals(mobileArea.getCarrier())){
                //查询用户套餐编号及校验号码状态
                RestStatus rs = buyService.queryPacCodeMobile(user, MD5.GetMD5Code(dto.getUserpwd()));
                if(rs.getStatus()){
                    TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
                    if(!"A".equals(res.getState())){
                        map.put("status", false);
                        map.put("msg", "号码："+dto.getPhone()+"当前状态为："+DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()) + "，不可订购业务");
                        return map;
                    }
                    map.put("qPhone",dto.getPhone());
                    map.put("qStatus",DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()));
                    map.put("certName",res.getCustName());
                    map.put("certNbr",res.getCertNbr());
                    map.put("qName",res.getCustName().substring(0, 0) + "*" + res.getCustName().substring(1, res.getCustName().length()));
                    map.put("qCode",res.getCertNbr().substring(0, 8)+"*****"+res.getCertNbr().substring(12, 18));
                    map.put("subsPlanName",res.getSubsPlanName());
                    map.put("subsPlanCode",res.getSubsPlanCode());
                    if("cool2".equals(res.getSubsPlanCode())){
                        map.put("subsPlanCode","xcool2");
                    }
                    
                    BigDecimal userBal = new BigDecimal(res.getBal());
                    map.put("bal",userBal.divide(Constant.cnt100));
                    map.put("certNbr",res.getCertNbr().substring(0, 8)+"*****"+res.getCertNbr().substring(12, 18));
                }else{
                    map.put("status", false);
                    map.put("msg", rs.getErrorMessage());
                    return map;
                }
                //查询订购业务
                TUserServiceQryRequest qry = new TUserServiceQryRequest();
                qry.setMSISDN("86"+user.getPhone());
                RestStatus qryRs = buyNewService.UserServiceQry(qry,user);
                
                if(qryRs.getStatus()){
                    StringBuffer orderServ = new StringBuffer();
                    TUserServiceQryResponse res = (TUserServiceQryResponse) qryRs.getResponseData();
                    if(null != res.getOrderedServiceList() && res.getOrderedServiceList().getService().size() >0){
                        for(int i=0;i< res.getOrderedServiceList().getService().size();i++){
                            if(StringUtils.equals(res.getOrderedServiceList().getService().get(i).getServiceState(), "A")) {
                                if(codeSet.contains(res.getOrderedServiceList().getService().get(i).getServiceCode())){
                                    listBo.add(res.getOrderedServiceList().getService().get(i));
                                    if(!Utils.isEmptyString(orderServ)){
                                        orderServ.append(",");
                                    }
                                    orderServ.append(res.getOrderedServiceList().getService().get(i).getServiceName());
                                    Date effDate = DateUtil.getInstance().parseDate(res.getOrderedServiceList().getService().get(i).getServiceEffDate(), DateUtil.yyyy_MM_dd_HH_mm_ss);
                                    if(null != effDate && DateUtil.getInstance().compareDate(effDate, new Date()) == 1){//未生效
                                        orderServ.append("(待生效)");
                                    }
                                }
                            }
                        }
                    }
                    map.put("orderServ",orderServ);
                }else{
                    map.put("status", false);
                    map.put("msg", qryRs.getErrorMessage());
                    return map;
                }
                String flag = SysConfig.getValue("SendToBoss");
                if (flag != null && flag.equals("false")) {
                    TService s = new TService();
                    s.setServiceCode("1807");
                    listBo.add(s);
                    s = new TService();
                    s.setServiceCode("420");
                    listBo.add(s);
                    s = new TService();
                    s.setServiceCode("1206");
                    listBo.add(s);
                    s = new TService();
                    s.setServiceCode("30028");
                    listBo.add(s);
                }
            }else{
                RestStatus  vrs = bOSSUnicomService.userValidation(dto.getPhone(),MD5.GetMD5Code(dto.getUserpwd()),user);
                if(!vrs.getStatus()){
                    map.put("status", false);
                    map.put("msg", vrs.getErrorMessage());
                    return map;
                }
                RestStatus rs = buyService.queryPacCodeUnicom(user);
                if(rs.getStatus()){
                    UserInfoView cr = (UserInfoView)rs.getResponseData();
                    map.put("qPhone",dto.getPhone());
                    map.put("qStatus",UnicomStatus.getName(Integer.valueOf(cr.getUserInfo().getServingStatus())));
                    String cName = cr.getCustInfo().getCustName();
                    String cCode = cr.getCustInfo().getIdentityCode();
                    map.put("certName",cName);
                    map.put("certNbr",cCode);
                    map.put("subsPlanName",cr.getUserInfo().getProdOfferName());
                    map.put("subsPlanCode",cr.getUserInfo().getProdOfferId());
                    
                    BigDecimal userBal = new BigDecimal(cr.getUserInfo().getAvailableBalance());
                    map.put("bal",userBal.divide(Constant.cnt100));
                    //有效和预约销售品信息查询
                    OfferWithStatus svcCont = new OfferWithStatus();
                    svcCont.setAccNbr(user.getPhone());
                    svcCont.setProductId("-1");
                    svcCont.setCityCode("360");
                    svcCont.setReserveStatus("1");
                    RestStatus ows = bOSSUnicomService.offerWithStatus(svcCont,user);
                    if(!ows.getStatus()){
                        map.put("status", false);
                        map.put("msg", ows.getErrorMessage());
                        return map;
                    }
                    ContractRoot crt = (ContractRoot)ows.getResponseData();
                    StringBuffer orderServ = new StringBuffer();
                    if(null != crt.getSvcCont().getProdOfferList() && crt.getSvcCont().getProdOfferList().size() >0){
                        for(int i=0;i< crt.getSvcCont().getProdOfferList().size();i++){
                            if("1000".equals(crt.getSvcCont().getProdOfferList().get(i).getStatusCd())
                                    && !"1".equals(crt.getSvcCont().getProdOfferList().get(i).getOfferTypeName())){//状态正常，并且非主套餐
                                if(codeSet.contains(crt.getSvcCont().getProdOfferList().get(i).getProdOfferId())){
                                    TService ts = new TService();
                                    ts.setServiceCode(crt.getSvcCont().getProdOfferList().get(i).getProdOfferId());
                                    ts.setServiceName(crt.getSvcCont().getProdOfferList().get(i).getProdOfferName());
                                    //ts.setServiceState(value);
                                    ts.setServiceEffDate(crt.getSvcCont().getProdOfferList().get(i).getEffDate());
                                    listBo.add(ts);
                                    if(!Utils.isEmptyString(orderServ)){
                                        orderServ.append(",");
                                    }
                                    orderServ.append(crt.getSvcCont().getProdOfferList().get(i).getProdOfferName());
                                }
                            }
                        }
                    }
                    map.put("orderServ",orderServ.toString().replaceAll("漏电提醒", "来电提醒"));
                }else{
                    map.put("status", false);
                    map.put("msg", rs.getErrorMessage());
                    return map;
                }
            }
            //map.put("subsPlanCode","LT_CS_02");
            pacService.packageInfoByBossCode(map,listBo,mobileArea.getCarrier(),dto.getPhone());
        }catch (Exception e){
            e.printStackTrace();
            logger.error("获取用户信息失败，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "获取用户信息失败，请重新提交！");
            return map;
        }
        return map;
    }

    /***
     * 获取当前融合包可订购业务
     * @param groupId
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "group-low", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> groupLow(Integer groupId,Integer pacId,String oldServ, HttpSession session) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        if (Utils.isEmptyString(groupId)) {
            map.put("status", false);
            map.put("msg", "参数不完整！");
            return map;
        }
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(1 != channels.getStatus().intValue() && 3 != channels.getStatus().intValue()){
                map.put("status", false);
                map.put("msg", "对不起，您的渠道状态不正常，不能进行业务办理！");
                return map;
            }
            pacService.groupIsLow(map, groupId,pacId,oldServ);
        }catch (SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
            logger.error("订购业务失败，原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "获取融合包可订购业务失败，请重新提交！");
        }
        map.put("status", true);
        return map;
    }

    /***
     * 提交业务办理
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "buy-sub", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> buySub(BuyServDTO dto,HttpServletRequest request, HttpSession session) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            dto.setSourceType("PC");
            if(dto.getOldServ().equals(dto.getNewServ())){
                map.put("status", false);
                map.put("msg", "您没有进行业务变更或订购，请重新提交！");
                return map;
            }
            
            Map<String, Object> parment = new HashMap<>();
            parment.put("prefix", Integer.valueOf(dto.getPhone().substring(0, 7)));
            parment.put("virtualCode", "ZXST");
            MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
            if(mobileArea == null){
                map.put("status", false);
                map.put("msg", "对不起，该号码为非中兴视通号码不能进行业务办理！");
                return map;
            }
            dto.setIp(IpUtil.getIp(request));
            if(MobileArea.carrier_YD.equals(mobileArea.getCarrier())){
                buyService.buySubMobile(dto,user);
            }else{
                buyService.buySubUnicom(dto,user);
            }
        } catch (SeeComException e) {
            e.printStackTrace();
            logger.error("业务提交失败号码="+dto.getPhone()+",原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", e.getMessage());
            return map;
        }catch (Exception e) {
            e.printStackTrace();
            logger.error("业务提交失败号码="+dto.getPhone()+",原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "业务办理失败！");
            return map;
        }
        map.put("status", true);
        return map;
    }

    /***
     * 重新提交业务办理
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "buy-again-sub", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> buyAgainSub(Integer buyId,HttpServletRequest request, HttpSession session) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            List<Integer> ids = new ArrayList<Integer>();
            ids.add(buyId);
            BuyServiceRecord buys = buyServiceRecordMapper.findById(ids.get(0));
            Map<String, Object> parment = new HashMap<>();
            parment.put("prefix", Integer.valueOf(buys.getPhone().substring(0, 7)));
            parment.put("virtualCode", "ZXST");
            MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
            if(mobileArea == null){
                map.put("status", false);
                map.put("msg", "对不起，该号码为非中兴视通号码不能进行业务办理！");
                return map;
            }
            if(MobileArea.carrier_YD.equals(mobileArea.getCarrier())){
                buyService.buyAgainSubMobile(ids,user,buys);
            }else{
                buyService.buyAgainSubMobile(ids,user,buys);
            }
        } catch (SeeComException e) {
            e.printStackTrace();
            logger.error("重新提交失败号码,原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", e.getMessage());
            return map;
        }catch (Exception e) {
            e.printStackTrace();
            logger.error("重新提交失败号码,原因："+e.getMessage(),e);
            map.put("status", false);
            map.put("msg", "业务办理失败！");
            return map;
        }
        map.put("status", true);
        return map;
    }

    /**
     * 进入业务办理列表页面
     * @return
     */
    @RequiresPermissions("buy-list")
    @RequestMapping(value = "buy-list", method = RequestMethod.GET)
    public String buyList(Model model, HttpSession session, HttpServletRequest request) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        //以下是获取当前渠道信息
        String type = Utils.isEmptyString(request.getParameter("type")) ? "" : request.getParameter("type");
        if("buy".equals(type)){
            model.addAttribute("channelType", 1);
        }else{
            model.addAttribute("channelType", 0);
        }
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if(null != channels && Channels.CHANNEL_TYPE_2.intValue() == channels.getChannelType().intValue()){
            model.addAttribute("isWD", 1);
        }else{
            model.addAttribute("isWD", 0);
        }
        return "/views/business/buyServ/buyServiceList.jsp";
    }

    /**
     * 查询业务办理列表
     * @return
     */
    @RequestMapping(value="buy-list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<BuyServRecordListDTO> buyList(DataTable<BuyServRecordListDTO> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = new HashMap<String, Object>();
            searchMap.put("phoneLike", request.getParameter("phoneLike"));
            searchMap.put("status",request.getParameter("status"));
            searchMap.put("network",request.getParameter("network"));
            searchMap.put("channelName",request.getParameter("channelName"));
            searchMap.put("channelParName",request.getParameter("channelParName"));
            searchMap.put("startdate",request.getParameter("startdate"));
            searchMap.put("enddate",request.getParameter("enddate"));
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(null != channels && Channels.CHANNEL_TYPE_2.intValue() == channels.getChannelType().intValue()){
                searchMap.put("channelId",channels.getId());
            }else if(null != channels && Channels.CHANNEL_LEVEL_1.intValue() == channels.getChannelLevel().intValue()){
                searchMap.put("channelId1",channels.getId());
            }
            List<Role> roles = menuService.userRoleList(user.getId());
            if(9 != roles.get(0).getId().intValue() && 10 != roles.get(0).getId().intValue()){
                searchMap.put("nowsType","2");
            }
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            dt = buyService.listBuy(dt,searchMap);
            return dt;
        }catch(Exception e){
            logger.error("查看业务办理信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }


}
