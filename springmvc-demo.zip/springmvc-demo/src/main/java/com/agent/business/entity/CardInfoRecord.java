package com.agent.business.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.agent.constant.Constant;
import com.agent.util.DateUtil;

/**
 * 订单表
 */
public class CardInfoRecord implements Serializable {

    private static final long serialVersionUID = -7001304106269873074L;
    
    private Integer id;
    private String cardNo;
    private String cardPwd;
    private Integer channelId;
    private String businessType;
    private Integer productId;
    private Integer productType;
    private String msisdn;
    private Integer isCard;
    private Integer saleType;
    private BigDecimal money;
    private Date saleTime;
    private Date activeTime;
    private Integer status;
    private String requestContent;
    private String msgSign;
    private String responseContent;
    private Integer createId;
    private Date createTime;
    
    /* 扩展属性 begin */
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    // 查询开始时间
    private String startDate;
    // 查询结束时间
    private String endDate;
    // 渠道名称
    private String channelName;
    // 渠道编码
    private String channelCode;
    /* 扩展属性 end */
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getCardNo() {
        return cardNo;
    }
    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }
    public String getCardPwd() {
        return cardPwd;
    }
    public void setCardPwd(String cardPwd) {
        this.cardPwd = cardPwd;
    }
    public Integer getChannelId() {
        return channelId;
    }
    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }
    public String getBusinessType() {
        return businessType;
    }
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }
    public Integer getProductId() {
        return productId;
    }
    public void setProductId(Integer productId) {
        this.productId = productId;
    }
    public Integer getProductType() {
        return productType;
    }
    public void setProductType(Integer productType) {
        this.productType = productType;
    }
    public String getMsisdn() {
        return msisdn;
    }
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
    public Integer getIsCard() {
        return isCard;
    }
    public String getIsCardStr() {
        String isCardStr = "";
        if (null != isCard) {
            if (0 == isCard.intValue()) {
                isCardStr = "否";
            } else if (1 == isCard.intValue()) {
                isCardStr = "是";
            }
        }
        return isCardStr;
    }
    public void setIsCard(Integer isCard) {
        this.isCard = isCard;
    }
    public Integer getSaleType() {
        return saleType;
    }
    public String getSaleTypeStr() {
        String saleTypeStr = "";
        if (null != saleType) {
            if (1 == saleType.intValue()) {
                saleTypeStr = "线上";
            } else if (2 == saleType.intValue()) {
                saleTypeStr = "线下";
            }
        }
        return saleTypeStr;
    }
    public void setSaleType(Integer saleType) {
        this.saleType = saleType;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public String getMoneyYuan() {
        if(null != money){
            return Constant.df0.format(money.divide(Constant.cnt100)).toString();
        }
        return "";
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public Date getSaleTime() {
        return saleTime;
    }
    public String getSaleTimeStr() {
        return saleTime !=null ? DateUtil.getInstance().getDateStr(saleTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setSaleTime(Date saleTime) {
        this.saleTime = saleTime;
    }
    public Date getActiveTime() {
        return activeTime;
    }
    public String getActiveTimeStr() {
        return activeTime !=null ? DateUtil.getInstance().getDateStr(activeTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setActiveTime(Date activeTime) {
        this.activeTime = activeTime;
    }
    public Integer getStatus() {
        return status;
    }
    public String getStatusStr() {
        String statusStr = "";
        if (null != status) {
            if (0 == status.intValue()) {
                statusStr = "未激活";
            } else if (1 == status.intValue()) {
                statusStr = "充值成功";
            } else if (2 == status.intValue()) {
                statusStr = "充值失败";
            }
        }
        return statusStr;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getRequestContent() {
        return requestContent;
    }
    public void setRequestContent(String requestContent) {
        this.requestContent = requestContent;
    }
    public String getMsgSign() {
        return msgSign;
    }
    public void setMsgSign(String msgSign) {
        this.msgSign = msgSign;
    }
    public String getResponseContent() {
        return responseContent;
    }
    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }
    public Integer getCreateId() {
        return createId;
    }
    public void setCreateId(Integer createId) {
        this.createId = createId;
    }
    public Date getCreateTime() {
        return createTime;
    }
    public String getCreateTimeStr() {
        return createTime !=null ? DateUtil.getInstance().getDateStr(createTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public String getChannelName() {
        return channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getChannelCode() {
        return channelCode;
    }
    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }
    @Override
    public String toString() {
        return "Order [id=" + id + ", cardNo=" + cardNo + ", cardPwd=" + cardPwd + ", businessType=" + businessType 
                + ", productId=" + productId + ", productType=" + productType 
                + ", isCard=" + isCard + ", saleType=" + saleType + ", money=" + getMoneyYuan() 
                + ", saleTime=" + getSaleTimeStr() + ", activeTime=" + getActiveTimeStr() 
                + ", status=" + getStatusStr() + ", createId=" + createId + ", createTime=" + getCreateTimeStr();
    }

}
