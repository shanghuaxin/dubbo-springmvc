package com.agent.business.dto;

import com.agent.common.CommonUtil;

/**
 * 号码状态通用DTO
 * 适用于界面查询
 * @author Administrator
 *
 */
public class PhoneStatusDTO {
    
    // A：正常    B:销户    D：单停    E:双停    G：未激活
    private String prodState;
    // 停机状态位
    private String blockReason;
    
    public PhoneStatusDTO() {
        super();
    }

    public PhoneStatusDTO(String prodState, String blockReason) {
        super();
        this.prodState = prodState;
        this.blockReason = blockReason;
    }

    public String getProdState() {
        return prodState;
    }
    
    public void setProdState(String prodState) {
        this.prodState = prodState;
    }
    
    public String getBlockReason() {
        return blockReason;
    }
    
    public void setBlockReason(String blockReason) {
        this.blockReason = blockReason;
    }
    
    public String getProdStateStr() {
        return CommonUtil.getInstance().getProdStateStr(prodState, blockReason);
    }
}
