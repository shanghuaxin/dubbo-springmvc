package com.agent.business.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.business.entity.RechargeRecord;
import com.agent.business.mapper.RechargeRecordMapper;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service
public class RechargeRecordService {
    
    private static Logger logger = (Logger) LoggerFactory.getLogger(RechargeRecordService.class);
    
    @Autowired
    private RechargeRecordMapper rechargeRecordMapper;
    
    /**
     * 获取查询列表
     * @param param
     * @return
     */
    public List<RechargeRecord> getOrderList(Map<String, Object> param) {
        List<RechargeRecord> result = null;
        try {
            return rechargeRecordMapper.list(param);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result = new ArrayList<RechargeRecord>();
        }
        return result;
    }
    
    /**
     * 统计订单数
     * @param param
     * @return
     */
    public int countOrder(Map<String, Object> param) {
        return rechargeRecordMapper.count(param);
    }
    
    /**
     * 往订单表t_order中添加一条记录
     * @param order
     * @return
     */
    public int insertOrder(RechargeRecord order) {
        int result = 0;
        try {
            result = rechargeRecordMapper.insert(order);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return result;
    }
    
    public int updateOrder(RechargeRecord order) {
        int result = 0;
        try {
            result = rechargeRecordMapper.update(order);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return result;
    }
    
    /**
     * 根据订单号获取订单信息
     * @param orderNo
     * @return
     */
    public RechargeRecord findByOrderNo(String orderNo) {
        return rechargeRecordMapper.findByOrderNo(orderNo);
    }
    
    /**
     * 查询充值订单佣金
     * @param map
     * @return
     */
    public List<RechargeRecord> getOrderBro(Map<String, Object> map) {
        return rechargeRecordMapper.getOrderBro(map);
    }
    
    /**
     * 查询充值订单数量
     * @param map
     * @return
     */
    public int countOrderBro(Map<String, Object> map) {
        return rechargeRecordMapper.countOrderBro(map);
    }
    
    /**
     * 查询佣金详情
     * @param map
     * @return
     */
    public List<RechargeRecord> getOrderBroDetail(Map<String, Object> map) {
        return rechargeRecordMapper.getOrderBroDetail(map);
    }
    
    /**
     * 查询佣金详情总记录数
     * @param map
     * @return
     */
    public int countOrderBroDetail(Map<String, Object> map) {
        return rechargeRecordMapper.countOrderBroDetail(map);
    }
}
