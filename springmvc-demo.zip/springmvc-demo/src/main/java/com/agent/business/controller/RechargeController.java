package com.agent.business.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBElement;

import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.CustInfo;
import namespace.webservice.crmsps.QueryUser;
import namespace.webservice.crmsps.UserInfo;
import namespace.webservice.crmsps.UserInfoView;

import org.apache.commons.lang3.StringUtils;
import org.example.paymentbank.ObjectFactory;
import org.example.paymentbank.PaymentBankRequest;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBO;

import com.agent.api.InterfaceUtil;
import com.agent.business.dto.RechargeRecordDTO;
import com.agent.business.entity.MobileArea;
import com.agent.business.entity.RechargeRecord;
import com.agent.business.service.MobileAreaService;
import com.agent.business.service.RechargeRecordService;
import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.common.SessionData;
import com.agent.common.enumeration.OperationType;
import com.agent.constant.Constant;
import com.agent.number.entity.TNumber;
import com.agent.number.service.NumberService;
import com.agent.online.entity.OlRecharge;
import com.agent.online.service.OlRechargeService;
import com.agent.common.enumeration.RechargeWayType;
import com.agent.order.common.util.IpUtil;
import com.agent.order.service.OrderDetailService;
import com.agent.product.entity.Product;
import com.agent.product.service.ProductService;
import com.agent.system.entity.CodeDictionary;
import com.agent.system.entity.User;
import com.agent.system.service.CodeDictionaryService;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.MD5;
import com.agent.util.SysConfig;
import com.agent.util.Utils;

/**
 * 充值控制器
 *
 * @author fenglu
 */
@Controller
@RequestMapping(value="business/recharge")
public class RechargeController {
    
    private static Logger logger = LoggerFactory.getLogger(RechargeController.class);
    
    @Autowired
    private RechargeRecordService rechargeRecordService;
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private ChannelsService channelsService;
    
    @Autowired
    private ChannelAccountService channelAccountService;
    
    @Autowired
    private CodeDictionaryService codeDictionaryService;
    
    @Autowired
    private MobileAreaService mobileAreaService;
    
    @Autowired
    private BusinessLogService businessLogService;
    
    @Autowired
    private NumberService numberService;
    @Autowired
    private BOSSNewBuyService bossNewBuyService;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    @Autowired
    private OrderDetailService orderDetailService;
    @Autowired
    private OlRechargeService olRechargeService;
    
    /**
     * 进入列表页面（网点）
     */
    @RequestMapping("list")
    public String list(HttpServletRequest request, HttpServletResponse response, RechargeRecordDTO rechargeRecordDTO) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            if (null == user) {
                logger.error("---登录超时(list方法)，操作人IP为：" + IpUtil.getIp(request));
                return "login.jsp";
            }
            Channels channels = channelsService.findChannelByUserId(user.getId());
            // 总部或渠道员工登录，不允许做业务
            if ((channels==null && user.getChannelId()==null)
                    || (channels==null && user.getChannelId()!=null)
                    || (channels==null && user.getBelongChannelId()!=null)) {
                return "/deny.jsp";
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(rechargeRecordDTO.getPageSize(), rechargeRecordDTO.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // 只能查询当前渠道下的记录
            if (null != channels) {
                params.put("channelId", channels.getId());
            }
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getMsisdn())) {
                params.put("msisdn", rechargeRecordDTO.getMsisdn());
            }
            if (null != rechargeRecordDTO.getProductType()) {
                params.put("productType", rechargeRecordDTO.getProductType());
            }
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getOperator())) {
                params.put("operator", rechargeRecordDTO.getOperator());
            }
            if (null != rechargeRecordDTO.getStatus()) {
                params.put("status", rechargeRecordDTO.getStatus());
            }
            
            String startDate = "";
            String endDate = "";
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getStartDate())) {
                startDate = rechargeRecordDTO.getStartDate() + " 00:00:00";
                params.put("startDate", startDate);
            }
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getEndDate())) {
                endDate = rechargeRecordDTO.getEndDate() + " 23:59:59";
                params.put("endDate", endDate);
            }

            List<RechargeRecord> orderList = rechargeRecordService.getOrderList(params);
            // 转换数据字典
            Map<String, String> dictMap = DicUtil.getMapDictionary("PRO_TYPE");
            if (null!=orderList && orderList.size()>0) {
                for(RechargeRecord order : orderList){
                    order.setProductTypeStr(dictMap.get(order.getProductType().toString()));
                }
            }
            int total = rechargeRecordService.countOrder(params);
            pageEntity.setTotal(total);
            Map<String, Object> map = new HashMap<String, Object>();
            // 获取商品列表
            List<Product> productList = productService.getProductList(map);
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("dicKey", "PRO_TYPE");
            // 商品类型
            List<CodeDictionary> dictList = codeDictionaryService.findChildByDickey(map1);
            
            // 默认展示中国移动的流量包
            List<Product> flowProdList = getProductList("移动", request);
            StringBuilder flowProdStr = new StringBuilder();
            StringBuilder billProdStr = new StringBuilder();
            if (null!=flowProdList && flowProdList.size()>0) {
                for (int i = 0; i < flowProdList.size(); i++) {
                    Product product = flowProdList.get(i);
                    if ("3".equals(product.getProductType())) {
                        flowProdStr.append("<a href='javascript:;' onclick='changeStyle(this)'>");
                        flowProdStr.append("<input type='radio' name='flow' id='"+product.getProductCode()+"' />");
                        flowProdStr.append("<label for='"+product.getProductCode()+"'>");
                        flowProdStr.append(product.getProductName());
                        flowProdStr.append("</label>");
                        flowProdStr.append("</a>");
                    } else if ("6".equals(product.getProductType())) {
                        billProdStr.append("<a href='javascript:;' onclick='changeStyle(this)'>");
                        billProdStr.append("<input type='radio' name='bill' id='"+product.getProductCode()+"' />");
                        billProdStr.append("<label for='"+product.getProductCode()+"'>");
                        billProdStr.append(product.getProductName());
                        billProdStr.append("</label>");
                        billProdStr.append("</a>");
                    }
                }
            }
            
            // 划拨账户
            ChannelAccount channelAccountHB = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
            // 充值账户
            ChannelAccount channelAccountCZ = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
            // 未处理的划拨账户订单金额
            Map<String, Object> param1 = new HashMap<String, Object>();
            param1.put("channelId", channels.getId());
            param1.put("accountType", 2);
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
            // 未处理的充值账户订单金额
            param1.put("accountType", 3);
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
            // 计算账户余额：划拨账户+充值账户-未处理订单金额
            BigDecimal accountBalance = channelAccountHB.getAccountBalanceYuan().add(channelAccountCZ.getAccountBalanceYuan()).subtract(freezeAllotMoney).subtract(freezeRechargeMoney);
            accountBalance = Utils.formatBigDecimal(accountBalance, "#.00");

            // 类型 fare=充话费  flow=充流量，默认为fare
            String type = request.getParameter("type");
            if (StringUtils.isEmpty(type)) {
                type = "fare";
            }
            
            request.setAttribute("orderList", orderList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("rechargeRecordDTO", rechargeRecordDTO);
            request.setAttribute("productList", productList);
            request.setAttribute("dictList", dictList);
            request.setAttribute("flowProdList", flowProdList);
            request.setAttribute("flowProdStr", flowProdStr.toString());
            request.setAttribute("billProdStr", billProdStr.toString());
            request.setAttribute("accountBalance", accountBalance);
            request.setAttribute("type", type);
        } catch (Exception e) {
            logger.error("网点查询充值记录异常："+e.getMessage(), e);
        }
        return "/views/business/rechargeList.jsp";
    }
    
    /**
     * 进入列表页面（客服人员）
     */
    @RequestMapping("qryList")
    public String qryList(HttpServletRequest request, HttpServletResponse response, RechargeRecordDTO rechargeRecordDTO) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            if (null == user) {
                logger.error("---登录超时(qryList方法)，操作人IP为：" + IpUtil.getIp(request));
                return "login.jsp";
            }
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if (null != channels) {
                // 查询当前客服人员所属一级渠道下的所有网点信息
                Integer channelIdLevel1 = channels.getChannelIdLevel1();
                if (channels.getChannelLevel() == 1) {
                    channelIdLevel1 = channels.getId();
                }
                List<Channels> channelList = channelsService.findChannelDetailByChannelIdLevel(channelIdLevel1, new Integer(3), 1);
                if (null != channelList && channelList.size()>0) {
                    List<Integer> channelIds = new ArrayList<Integer>();
                    for (int i = 0; i < channelList.size(); i++) {
                        Channels channel = channelList.get(i);
                        channelIds.add(channel.getId());
                    }
                    params.put("channelIds", channelIds);
                }
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(rechargeRecordDTO.getPageSize(), rechargeRecordDTO.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getChannelName())) {
                rechargeRecordDTO.setChannelName(rechargeRecordDTO.getChannelName().trim());
                params.put("channelName", rechargeRecordDTO.getChannelName());
            }
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getMsisdn())) {
                rechargeRecordDTO.setMsisdn(rechargeRecordDTO.getMsisdn().trim());
                params.put("msisdn", rechargeRecordDTO.getMsisdn());
            }
            if (null != rechargeRecordDTO.getProductType()) {
                params.put("productType", rechargeRecordDTO.getProductType());
            }
            if (null != rechargeRecordDTO.getStatus()) {
                params.put("status", rechargeRecordDTO.getStatus());
            }
            
            String startDate = "";
            String endDate = "";
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getStartDate())) {
                startDate = rechargeRecordDTO.getStartDate() + " 00:00:00";
                params.put("startDate", startDate);
            }
            if (StringUtils.isNotEmpty(rechargeRecordDTO.getEndDate())) {
                endDate = rechargeRecordDTO.getEndDate() + " 23:59:59";
                params.put("endDate", endDate);
            }

            List<RechargeRecord> recordList = rechargeRecordService.getOrderList(params);
            // 转换数据字典
            Map<String, String> dictMap = DicUtil.getMapDictionary("PRO_TYPE");
            if (null!=recordList && recordList.size()>0) {
                for(RechargeRecord record : recordList){
                    record.setProductTypeStr(dictMap.get(record.getProductType().toString()));
                }
            }
            int total = rechargeRecordService.countOrder(params);
            pageEntity.setTotal(total);
            
            Map<String, Object> map = new HashMap<String, Object>();
            // 获取商品列表
            List<Product> productList = productService.getProductList(map);
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("dicKey", "PRO_TYPE");
            // 商品类型
            List<CodeDictionary> dictList = codeDictionaryService.findChildByDickey(map1);
            
            
            request.setAttribute("orderList", recordList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("rechargeRecordDTO", rechargeRecordDTO);
            request.setAttribute("productList", productList);
            request.setAttribute("dictList", dictList);
        } catch (Exception e) {
            logger.error("客服查询充值记录异常："+e.getMessage(), e);
        }
        return "/views/business/rechargeList_customer.jsp";
    }
    
    /**
     * 获取号码归属地
     * @param request
     * @param msisdn
     * @param type 1:话费 2：流量
     * @return
     * @throws Exception
     */
    @RequestMapping(value="getMobileFrom", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getMobileFrom(HttpServletRequest request, String msisdn) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            Pattern pattern = Pattern.compile("1\\d{10}");
            Matcher matcher = pattern.matcher(msisdn);
            if (matcher.matches()) {
                Map<String, Object> parment = new HashMap<>();
                parment.put("prefix", Integer.valueOf(msisdn.substring(0, 7)));
                MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
                if (null != mobileArea) {
                    String area = mobileArea.getProvince();
                    if (null!=area && !area.equals(mobileArea.getCity())) {
                        area += mobileArea.getCity();
                    }
                    area += "-" + mobileArea.getCorp();
                    
                    map.put("status", true);
                    map.put("msg", area);
                    map.put("result", area);
                } else {
                    // 未找到归属地
                    map.put("status", false);
                    map.put("msg", msisdn + "：手机号码格式错误！");
                }
            } else {
                map.put("status", false);
                map.put("msg", msisdn + "：手机号码格式错误！");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map = new HashMap<String, Object>();
            map.put("status", false);
            map.put("msg", e.getMessage());
        }
        return map;
    }
    
    /**
     * 获取170号码归属地
     * @param msisdn
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value="get170MobileFrom", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> get170MobileFrom(@RequestParam("msisdn")String msisdn, HttpServletRequest request) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            if (null == user) {
                map.put("status", false);
                map.put("msg", "登录超时");
                logger.error("获取170号码归属地登录超时,号码："+msisdn+",IP地址："+IpUtil.getIp(request));
                return map;
            }
            Channels channel = channelsService.findChannelByUserId(user.getId());
            if (null == channel) {
                map.put("status", false);
                map.put("msg", "参数异常，请重新提交!");
                logger.error("获取170号码归属地参数异常,号码:"+msisdn+",用户:"+user.getLoginName()+",IP地址："+IpUtil.getIp(request));
                return map;
            }
            if (channel.getChannelType().intValue() != 2) {
                map.put("status", false);
                map.put("msg", "非网点，不能操作此业务!");
                logger.error("渠道【"+channel.getChannelCode()+"】"+channel.getChannelName()+"非网点，不能获取号码归属地,号码+"+msisdn+",IP地址："+IpUtil.getIp(request));
                return map;
            }
            logger.info("----------渠道["+channel.getChannelCode()+"]"+channel.getChannelName()+"对号码+"+msisdn+",进行充值操作，IP地址："+IpUtil.getIp(request));
            Pattern pattern = Pattern.compile("17\\d{9}");
            Matcher matcher = pattern.matcher(msisdn);
            if (matcher.matches()) {
                // 查找是否属于中兴视通的号码
                Map<String, Object> parment = new HashMap<>();
                parment.put("prefix", Integer.valueOf(msisdn.substring(0, 7)));
                parment.put("virtualCode", "ZXST");
                MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
                if (mobileArea == null) {
                    map.put("status", false);
                    map.put("msg", "对不起，该号码非中兴视通号码不能进行话费充值！");
                    return map;
                }
                String area = mobileArea.getProvince();
                if (null!=area && !area.equals(mobileArea.getCity())) {
                    area += mobileArea.getCity();
                }
                area += "-" + mobileArea.getCorp();
                if (null!=area && !area.equals(mobileArea.getVirtualCorp())) {
                    area += "-" + mobileArea.getVirtualCorp();
                }
                map.put("status", true);
                map.put("msg", area);
                map.put("result", area);
                
                String userName = null;
                String balance = null;
                // 根据号码网络，调用不同的接口
                String network = mobileArea.getCarrier();
                if ("LT".equals(network)) {
                    // 调用用户综合信息查询接口
                    QueryUser svcCont = new QueryUser();
                    svcCont.setQueryValue(msisdn);
                    svcCont.setQueryType("0");
                    svcCont.setProductId("-1");
                    svcCont.setCityCode("360");
                    RestStatus restStatus = bossUnicomService.queryUserService(svcCont, user);
                    if (restStatus.getStatus()) {
                        ContractRoot contractRoot = (ContractRoot) restStatus.getResponseData();
                        UserInfoView userInfoView = contractRoot.getSvcCont().getUserInfoView();
                        CustInfo custInfo = userInfoView.getCustInfo();
                        userName = custInfo.getCustName();
                        // 第一个字符用星号代替
                        userName = "*"+userName.substring(1, userName.length());
                        UserInfo userInfo = userInfoView.getUserInfo();
                        balance = userInfo.getAvailableBalance();
                        // 格式化
                        balance = Constant.df0.format(new BigDecimal(balance).divide(Constant.cnt100));
                    } else {
                        map.put("status", false);
                        map.put("msg", "非中兴视通号码或未开户，不支持充值!");
                        logger.error("获取号码信息失败："+restStatus.getErrorMessage());
                        return map;
                    }
                } else {
                    TQueryUserProfileRequestBO userProfile= new TQueryUserProfileRequestBO();
                    userProfile.setMSISDN("86"+msisdn);
                    RestStatus restStatus = bossNewBuyService.QueryUserProfileBOSS(userProfile, user);
                    if (restStatus.getStatus()) {
                        TQueryUserProfile4BaseBOResponse userProfileResponse = (TQueryUserProfile4BaseBOResponse) restStatus.getResponseData();
                        userName = userProfileResponse.getCustName();
                        // 第一个字符用星号代替
                        userName = "*"+userName.substring(1, userName.length());
                        balance = userProfileResponse.getBal();
                        // 把余额由分转换成元
                        balance = Constant.df0.format(new BigDecimal(balance).divide(Constant.cnt100));
                    } else {
                        map.put("status", false);
                        map.put("msg", "非中兴视通号码或未开户，不支持充值!");
                        logger.error("获取号码信息失败："+restStatus.getErrorMessage());
                        return map;
                    }
                }
                // 查询归属地
                //map = MobileFromUtil.getMobilDetail(msisdn);
                map.put("userName", userName);
                map.put("balance", balance);
            } else {
                map.put("status", false);
                map.put("msg", msisdn + "：非中兴视通号码不能进行该业务！");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map = new HashMap<String, Object>();
            map.put("status", false);
            map.put("msg", e.getMessage());
        }
        return map;
    }
    
    /**
     * 获取可用的商品列表
     * @param operator
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "getProductList", method = RequestMethod.POST)
    @ResponseBody
    public List<Product> getProductList(@RequestParam("operator")String operator, HttpServletRequest request) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        if (null != operator) {
            if (operator.contains("移动")) {
                operator = "移动";
            } else if (operator.contains("联通")) {
                operator = "联通";
            } else if (operator.contains("电信")) {
                operator = "电信";
            }
        }
        map.put("operator", operator);
        map.put("category", "1");
        map.put("status", "2");
        map.put("isShow", "1");
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        Channels channels = channelsService.findChannelByUserId(user.getId());
        if (null != channels) {
            map.put("channelId", channels.getChannelIdLevel1());
        }
        List<Product> list = productService.getProductList(map);
        return list;
    }
    
    /**
     * 充流量
     * @param request
     * @param response
     * @param mobile 手机号
     * @param productCode 产品编码
     * @return
     */
    @RequestMapping(value="rechargeFlow", method = RequestMethod.POST)
    public @ResponseBody Map<String, Object> rechargeFlow(HttpServletRequest request, HttpServletResponse response, 
            String mobile, String productCode) {
        Map<String, Object> map = new HashMap<String, Object>();
        JSONObject json = new JSONObject();
        String result = null;
        try {
            User curUser = SessionData.getInstance().getUser(request);
            if (null == curUser) {
                map.put("status", false);
                map.put("msg", "登录超时");
                logger.error("充流量登录超时,IP地址："+IpUtil.getIp(request));
                return map;
            }
            Channels channel = channelsService.findChannelByUserId(curUser.getId());
            if (null == channel) {
                map.put("status", false);
                map.put("msg", "参数异常，请重新提交!");
                logger.error("充流量参数异常,号码:"+mobile+",用户:"+curUser.getLoginName()+",IP地址："+IpUtil.getIp(request));
                return map;
            }
            if (channel.getChannelType().intValue() != 2) {
                map.put("status", false);
                map.put("msg", "非网点，不能操作此业务!");
                logger.error("渠道【"+channel.getChannelCode()+"】"+channel.getChannelName()+"非网点，不能操作充流量业务,号码+"+mobile+",IP地址："+IpUtil.getIp(request));
                return map;
            }
            
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("productCode", productCode);
            map1.put("category", "1");
            map1.put("status", "2");
            map1.put("isShow", "1");
            map1.put("channelId", channel.getChannelIdLevel1());
            Product product = productService.getProductByCondition(map1);
            if (null == product) {
                map.put("status", false);
                map.put("msg", "参数异常，请重新提交!");
                return map;
            }
            String productName = product.getProductName();
            Integer productType = Integer.parseInt(product.getProductType());
            
            // 获取直充账户余额
            Integer channelId = channel.getId();
            ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channelId, 3);
            BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
            // 获取划拨账户余额
            ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channelId, 2);
            BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
            // 未处理的划拨账户订单金额
            Map<String, Object> para = new HashMap<String, Object>();
            para.put("channelId", channel.getId());
            para.put("accountType", 2);
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
            BigDecimal allotBalanceTmp = allotBalance.subtract(freezeAllotMoney);
            // 未处理的充值账户订单金额
            para.put("accountType", 3);
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
            BigDecimal directRechargeBalanceTmp = directRechargeBalance.subtract(freezeRechargeMoney);

            BigDecimal orderMoney = product.getSalePrice();
            orderMoney = orderMoney.divide(new BigDecimal(100));
            
            // 判断订单金额是否大于等于充值账户和划拨账户的总额，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
            if (orderMoney.compareTo(directRechargeBalanceTmp.add(allotBalanceTmp)) == 1) {
                map.put("status", false);
                map.put("msg", "账户余额不足，充值失败!");
                return map;
            }

            if (directRechargeBalanceTmp.compareTo(orderMoney) > -1) {
               logger.info("渠道"+channel.getChannelName()+"/"+channel.getChannelCode()+"充流量充值账户金额余额为："+directRechargeBalanceTmp+"元");
            } else {
                // 订单总额-充值账户的金额-未处理订单的充值账户总额，得到划拨账户应该扣除的金额
                BigDecimal allotOrderMoney = orderMoney.subtract(directRechargeBalanceTmp);
                if (allotBalanceTmp.compareTo(allotOrderMoney) > -1) {
                    logger.info("渠道"+channel.getChannelName()+"/"+channel.getChannelCode()+"充流量划拨账户金额余额为："+directRechargeBalanceTmp+"元");
                } else {
                    map.put("status", false);
                    map.put("msg", "账户余额不足，充值失败!");
                    return map;
                }
            }
            
            /** ===调用客户订购流量接口 begin=== */
            /*
            // 服务端地址
            String url = SysConfig.getValue("CoolUrl");
            String buyFlow = SysConfig.getValue("CoolBuyFlow");
            
            // 接口地址
            String thirdUrl = SysConfig.getValue("FlowUrl");
            // 平台账号
            String user = SysConfig.getValue("User");
            // 代理渠道号
            String agent_id = SysConfig.getValue("AgentId");
            // 通讯密钥
            String key = SysConfig.getValue("SecretKey");
            // 流量订购接口名
            String buyFlowI = SysConfig.getValue("BuyFlow");
            // 通讯的时间戳（单位秒）
            String nonce = String.valueOf(System.currentTimeMillis()/1000);
            // 订购方交易号
            String third_no = "";
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("coolUrl", url+buyFlow);
            param.put("url", thirdUrl+buyFlowI);
            param.put("agent_id", agent_id);
            param.put("nonce", nonce);
            param.put("user", user);
            param.put("mobile", mobile);
            // 流量商品编码
            param.put("flow_id", productCode);
            param.put("third_no", third_no);
            param.put("key", key);
            result = OperatorFlowService.getInstance().buyFlow(param);*/

            String urlStr = SysConfig.getValue("CoolUrl")+SysConfig.getValue("CoolBuyFlow");//"services/flowServlet";
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("url", urlStr);
            param.put("mobile", mobile);
            param.put("goods_id", productCode);
            result = InterfaceUtil.getInstance().httpPost(param);
            
            json = new JSONObject(result);
            /** ===调用客户订购流量接口 end=== */

            // code=0 表示订购成功，否则为失败
            String code = json.getString("code");
            map.put("msg", json.get("msg"));
            String orderNo = null;
            Integer status = null;
            Double money = null;
            BigDecimal costMoney = null;
            String remark = json.getString("msg");
            if ("0".equals(code)) {
                TNumber number = new TNumber();
                number.setPhone(mobile);
                JSONObject data = (JSONObject) json.get("data");
                // 订单号
                orderNo = (String) data.get("order_no");
                // 成本价
                money = (Double) data.get("money");
                costMoney = new BigDecimal(money);
                
                // 构造takeMoney方法的入参
                Map<String, Object> param1 = new HashMap<String, Object>();
                param1.put("productCode", productCode);
                param1.put("us", curUser);
                param1.put("channel", channel);
                param1.put("number", number);
                param1.put("product", product);
                param1.put("productName", productName);
                param1.put("productType", productType);
                param1.put("directRechargeBalance", directRechargeBalanceTmp);
                param1.put("allotBalance", allotBalanceTmp);
                param1.put("orderMoney", orderMoney);
                param1.put("orderNo", orderNo);
                param1.put("operationType", OperationType.RECHARGE_FLOW.getId());
                param1.put("money", orderMoney);
                RestStatus rs = numberService.takeMoney(param1);
                if (!rs.getStatus()) {
                    map.put("status", false);
                    map.put("msg", rs.getErrorMessage());
                    return map;
                }

                // 0表示充值中
                status = 0;
                // 生成充值记录
                RechargeRecord rechargeRecord = new RechargeRecord();
                rechargeRecord.setOrderNo(orderNo);
                rechargeRecord.setOrderType(1);
                rechargeRecord.setMsisdn(mobile);
                rechargeRecord.setChannelId(channel.getId());
                rechargeRecord.setProductCode(productCode);
                rechargeRecord.setProductType(productType);
                rechargeRecord.setProductName(productName);
                rechargeRecord.setOrderMoney(orderMoney.multiply(Constant.cnt100));
                if (null != costMoney) {
                    rechargeRecord.setCostMoney(costMoney.multiply(Constant.cnt100));
                }
                rechargeRecord.setStatus(status);
                rechargeRecord.setSource("PC");
                rechargeRecord.setRemark(remark);
                rechargeRecord.setIp(IpUtil.getIp(request));
                rechargeRecord.setCreateId(curUser.getId());
                rechargeRecord.setUpdateId(curUser.getId());
                rechargeRecordService.insertOrder(rechargeRecord);
                
                // 目前网点和掌网厅的充值不在一张表里，不方便统计，所以网点充值增加记录ol_recharge表，用于统一查询
                OlRecharge recharge = new OlRecharge();
                recharge.setOrderNo(orderNo);
                recharge.setBuyOrderNo(null);
                recharge.setUserIp(IpUtil.getIp(request));
                recharge.setDctId(null);
                recharge.setPhone(number.getPhone());
                recharge.setrType("1");
                recharge.setPayType("agent_pc");
                recharge.setPayStatus("1");
                recharge.setrStatus("1");
                recharge.setMoney(orderMoney);
                recharge.setAccountBalance(orderMoney);
                recharge.setProId(product.getId());
                recharge.setProCode(productCode);
                recharge.setProName(productName);
                recharge.setProRemark("充流量"+productName);
                recharge.setLoginName(curUser.getLoginName());
                recharge.setSourceType("PC");
                olRechargeService.insert(recharge);
                
                map.put("status", true);
                
                // 记录日志
                Map<String,String> logMap = new HashMap<String,String>();
                logMap.put("staff", curUser.getLoginName());
                logMap.put("phone", mobile);
                logMap.put("productName", productName);
                logMap.put("money", orderMoney.toString()+"元");
                logMap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                logMap.put("result","成功！");
                businessLogService.businessSaveLog(Business.phone_recharge_flow, String.valueOf(curUser.getId()), curUser.getLoginName(), "", "充流量", logMap);
            } else {
                map.put("status", false);
            }
        } catch (Exception e) {
            map.put("status", false);
            map.put("msg", "网络访问异常，请稍后再试!");
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return map;
    }
    
    /**
     * 充话费
     * @param request
     * @param response
     * @param mobile 手机号
     * @param productCode 产品编码
     * @return
     */
    @RequestMapping(value="rechargePhoneCost", method = RequestMethod.POST)
    public @ResponseBody Map<String, Object> rechargePhoneCost(HttpServletRequest request, HttpServletResponse response, 
            String mobile, String productCode) {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            User curUser = SessionData.getInstance().getUser(request);
            Channels channel = channelsService.findChannelByUserId(curUser.getId());
            if (null == channel) {
                map.put("status", false);
                map.put("msg", "参数异常，请重新提交!");
                logger.error("充话费登录超时,IP地址："+IpUtil.getIp(request));
                return map;
            }
            if (channel.getChannelType().intValue() != 2) {
                map.put("status", false);
                map.put("msg", "非网点，不能操作此业务!");
                logger.error("渠道【"+channel.getChannelCode()+"】"+channel.getChannelName()+"不是网点，不能进行充话费操作,IP地址："+IpUtil.getIp(request));
                return map;
            }
            
            TNumber number = new TNumber();
            number.setPhone(mobile);
            
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("productCode", productCode);
            map1.put("category", "1");
            map1.put("status", "2");
            map1.put("isShow", "1");
            map1.put("channelId", channel.getChannelIdLevel1());
            Product product = productService.getProductByCondition(map1);
            if (null == product) {
                map.put("status", false);
                map.put("msg", "参数异常，请重新提交!");
                return map;
            }
            String productName = product.getProductName();
            Integer productType = Integer.parseInt(product.getProductType());
            
            /**
             * 扣款流程：先扣直充账户，不够再扣划拨账户，划拨账户也不够，则充值失败
             * 每次扣款时，都要把当前扣除的金额记录到账户表的freeze_balance字段
             */
            // 获取直充账户余额
            ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 3);
            // 获取划拨账户余额
            ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 2);
            // 未处理的划拨账户订单金额
            Map<String, Object> para = new HashMap<String, Object>();
            para.put("channelId", channel.getId());
            para.put("accountType", 2);
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
            // 未处理的充值账户订单金额
            para.put("accountType", 3);
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
            
            BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
            allotBalance = allotBalance.subtract(freezeAllotMoney);
            BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
            directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
            
            BigDecimal orderMoney = product.getSalePrice();
            orderMoney = orderMoney.divide(new BigDecimal(100));
            // 判断订单金额是否大于等于充值账户和划拨账户的总额，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
            if (orderMoney.compareTo(directRechargeBalance.add(allotBalance)) == 1) {
                map.put("status", false);
                map.put("msg", "账户余额不足，充值失败!");
                return map;
            }
            
            // 是否调用boss接口
            String flag = SysConfig.getValue("SendToBoss");
            String rechargeId = SysConfig.getValue("RechargeId");
            String rechargePwd = SysConfig.getValue("RechargePwd");
            String orderNo = Utils.getOrderNo("F");
            String salePriceYuen = product.getSalePrice().divide(new BigDecimal(100)).toString();
            RestStatus restStatus = null;
            if ("true".equals(flag)) {
                // 根据号码的网络调用不同的接口
                Map<String, Object> parment = new HashMap<>();
                parment.put("prefix", Integer.valueOf(mobile.substring(0, 7)));
                parment.put("virtualCode", "ZXST");
                MobileArea mobileArea = mobileAreaService.findByPrefix(parment);
                if ("LT".equals(mobileArea.getCarrier())) {
                    PaymentBankRequest paymentBank = new PaymentBankRequest();
                    paymentBank.setRequestId(Utils.getRandomString(10));
                    paymentBank.setSystemId("0001");
                    paymentBank.setServiceId(mobile);
                    paymentBank.setServiceKind(8);
                    paymentBank.setPayFee(product.getSalePrice().longValue());
                    ObjectFactory objFac=new ObjectFactory();  
                    JAXBElement<String> flowNumber = objFac.createPaymentBankRequestFlowNumber("");
                    JAXBElement<String> notifyDate = objFac.createPaymentBankRequestNotifyDate("");
                    paymentBank.setFlowNumber(flowNumber);
                    paymentBank.setNotifyDate(notifyDate);
                    paymentBank.setPayWay(4);
                    paymentBank.setPayKind(1);
                    paymentBank.setIfContinue(false);
                    // 充值类型
                    paymentBank.setDealerId(RechargeWayType.AGENT.getCode());
                    // 充值渠道ID
                    paymentBank.setWorkNo(String.valueOf(channel.getId()));
                    paymentBank.setPresentFee(0);
                    restStatus = bossUnicomService.paymentBank(paymentBank, curUser);
                } else {
                    TRechargeBOSSBO rechargeBO = new TRechargeBOSSBO();
                    rechargeBO.setMSISDN("86" + mobile);
                    rechargeBO.setAmount(product.getSalePrice().longValue());
                    rechargeBO.setSN(orderNo);// 流水号唯一
                    rechargeBO.setOperateDate(DateUtil.dateToXmlDate(new Date()));// 调用方操作时间
                    rechargeBO.setChannalId(rechargeId);// 充值Id
                    rechargeBO.setChannalPwd(MD5.GetMD5Code(rechargePwd));// 充值密码
                    restStatus = bossNewBuyService.RechargeBOSS(rechargeBO, curUser);
                }
            }
            
            if (restStatus==null || restStatus.getStatus()) {
                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("productCode", productCode);
                param.put("us", curUser);
                param.put("channel", channel);
                param.put("number", number);
                param.put("product", product);
                param.put("productName", productName);
                param.put("productType", productType);
                param.put("directRechargeBalance", directRechargeBalance);
                param.put("allotBalance", allotBalance);
                param.put("orderMoney", orderMoney);
                param.put("orderNo", orderNo);
                param.put("operationType", OperationType.RECHARGE_COST.getId());
                param.put("money", orderMoney);
                param.put("ip", IpUtil.getIp(request));
                RestStatus rs = numberService.takeMoney(param);
                if (!rs.getStatus()) {
                    map.put("status", false);
                    map.put("msg", rs.getErrorMessage());
                    return map;
                }
                map.put("status", true);
                
                // 记录日志
                Map<String,String> logMap = new HashMap<String,String>();
                logMap.put("staff", curUser.getLoginName());
                logMap.put("phone", mobile);
                logMap.put("money", salePriceYuen+"元");
                logMap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                logMap.put("result","成功！");
                businessLogService.businessSaveLog(Business.phone_recharge, String.valueOf(curUser.getId()),curUser.getLoginName(), "", "号码充值", logMap);
            } else {
                map.put("status", false);
                map.put("msg", restStatus.getErrorMessage());
            }
        } catch (Exception e) {
            map.put("status", false);
            map.put("msg", "网络访问异常，请稍后再试!");
            logger.error(e.getMessage(), e);
        }
        return map;
    }
}
