package com.agent.business.controller;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.agent.stock.service.StockService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.business.entity.CardInfoRecord;
import com.agent.business.service.CardInfoRecordService;
import com.agent.business.service.Cool170Service;
import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.PageEntity;
import com.agent.common.SessionData;
import com.agent.constant.Constant;
import com.agent.order.service.OrderDetailService;
import com.agent.product.entity.Product;
import com.agent.product.service.ProductService;
import com.agent.stock.entity.CardInfo;
import com.agent.stock.service.CardInfoService;
import com.agent.system.entity.CodeDictionary;
import com.agent.system.entity.User;
import com.agent.system.service.CodeDictionaryService;
import com.agent.util.DateUtil;
import com.agent.util.Utils;

/**
 * 卡密控制器
 *
 * @author fenglu
 */
@Controller
@RequestMapping(value="business/cool170")
public class Cool170Controller {
    
    private static Logger logger = LoggerFactory.getLogger(Cool170Controller.class);
    
    @Autowired
    private ChannelsService channelsService;
    
    @Autowired
    private CodeDictionaryService codeDictionaryService;
    
    @Autowired
    private CardInfoService cardInfoService;
    
    @Autowired
    private CardInfoRecordService cardInfoRecordService;
    
    @Autowired
    private StockService stockService;
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private ChannelAccountService channelAccountService;
    
    @Autowired
    private Cool170Service cool170Service;
    
    @Autowired
    private BusinessLogService businessLogService;
    
    @Autowired
    private OrderDetailService orderDetailService;
    
    /**
     * 进入列表页面（网点）
     */
    @RequestMapping("list")
    public String list(HttpServletRequest request, HttpServletResponse response, CardInfoRecord record) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            // 总部或渠道员工登录，不允许做业务
            if ((channels==null && user.getChannelId()==null)
                    || (channels==null && user.getChannelId()!=null)
                    || (channels==null && user.getBelongChannelId()!=null)) {
                return "/deny.jsp";
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(record.getPageSize(), record.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            
            if (StringUtils.isNotEmpty(record.getMsisdn())) {
                params.put("msisdn", record.getMsisdn());
            }
            if (StringUtils.isNotEmpty(record.getCardNo())) {
                params.put("cardNo", record.getCardNo());
            }
            if (null != record.getProductType()) {
                params.put("productType", record.getProductType());
            }
            if (null != record.getSaleType()) {
                params.put("saleType", record.getSaleType());
            }
            if (null != record.getStatus()) {
                params.put("status", record.getStatus());
            }
            // 只能查询当前渠道下的记录
            params.put("channelId", channels.getId());
            String startDate = "";
            String endDate = "";
            if (StringUtils.isNotEmpty(record.getStartDate())) {
                startDate = record.getStartDate() + " 00:00:00";
                params.put("startDate", startDate);
            }
            if (StringUtils.isNotEmpty(record.getEndDate())) {
                endDate = record.getEndDate() + " 23:59:59";
                params.put("endDate", endDate);
            }
            List<CardInfoRecord> recordList = cardInfoRecordService.getRecordList(params);
            int total = cardInfoRecordService.countRecord(params);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("dicKey", "PRO_TYPE");
            List<CodeDictionary> dictList = codeDictionaryService.findChildByDickey(map);
            pageEntity.setTotal(total);
            request.setAttribute("recordList", recordList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("record", record);
            request.setAttribute("dictList", dictList);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "/views/business/cardPassList.jsp";
    }
    
    /**
     * 进入列表页面（客服人员）
     */
    @RequestMapping("qryList")
    public String qryist(HttpServletRequest request, HttpServletResponse response, CardInfoRecord record) {
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if (null != channels) {
                // 查询当前客服人员所属一级渠道下的所有网点信息
                Integer channelIdLevel1 = channels.getChannelIdLevel1();
                if (channels.getChannelLevel() == 1) {
                    channelIdLevel1 = channels.getId();
                }
                List<Channels> channelList = channelsService.findChannelDetailByChannelIdLevel(channelIdLevel1, new Integer(3), 1);
                if (null != channelList && channelList.size()>0) {
                    List<Integer> channelIds = new ArrayList<Integer>();
                    for (int i = 0; i < channelList.size(); i++) {
                        Channels channel = channelList.get(i);
                        channelIds.add(channel.getId());
                    }
                    params.put("channelIds", channelIds);
                }
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(record.getPageSize(), record.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            
            if (StringUtils.isNotEmpty(record.getChannelName())) {
                record.setChannelName(record.getChannelName().trim());
                params.put("channelName", record.getChannelName());
            }
            if (StringUtils.isNotEmpty(record.getMsisdn())) {
                record.setMsisdn(record.getMsisdn().trim());
                params.put("msisdn", record.getMsisdn());
            }
            if (StringUtils.isNotEmpty(record.getCardNo())) {
                record.setCardNo(record.getCardNo().trim());
                params.put("cardNo", record.getCardNo());
            }
            if (null != record.getProductType()) {
                params.put("productType", record.getProductType());
            }
            if (null != record.getSaleType()) {
                params.put("saleType", record.getSaleType());
            }
            if (null != record.getStatus()) {
                params.put("status", record.getStatus());
            }
            
            String startDate = "";
            String endDate = "";
            if (StringUtils.isNotEmpty(record.getStartDate())) {
                startDate = record.getStartDate() + " 00:00:00";
                params.put("startDate", startDate);
            }
            if (StringUtils.isNotEmpty(record.getEndDate())) {
                endDate = record.getEndDate() + " 23:59:59";
                params.put("endDate", endDate);
            }
            List<CardInfoRecord> recordList = cardInfoRecordService.getRecordList(params);
            int total = cardInfoRecordService.countRecord(params);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("dicKey", "PRO_TYPE");
            List<CodeDictionary> dictList = codeDictionaryService.findChildByDickey(map);
            pageEntity.setTotal(total);
            request.setAttribute("recordList", recordList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("record", record);
            request.setAttribute("dictList", dictList);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "/views/business/cardPassList_customer.jsp";
    }
    
    /**
     * 根据商品类型，获取商品其余属性，因map不支持排序，因此使用了List<Map<String, List<CodeDictionary>>>
     * @param dicId 商品类型ID
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "getProductSelect", method = RequestMethod.POST)
    @ResponseBody
    public List<Map<String, List<CodeDictionary>>> getProductSelect(@RequestParam("dicId")String dicId, HttpServletRequest request) throws Exception {
        List<Map<String, List<CodeDictionary>>> result = new ArrayList<Map<String, List<CodeDictionary>>>();
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("dicId", dicId);
        List<CodeDictionary> dictList = codeDictionaryService.findChildByDicId(map);
        if (null!=dictList && dictList.size()>0) {
            for (int i = 0; i < dictList.size(); i++) {
                CodeDictionary dic = dictList.get(i);
                map.put("dicId", dic.getId());
                Map<String, List<CodeDictionary>> result1 = new HashMap<String, List<CodeDictionary>>();
                result1.put(dic.getDicName(), codeDictionaryService.findChildByDicId(map));
                result.add(i, result1);
            }
        }
        return result;
    }
    
    /**
     * 根据商品类型等信息，随机获取一张卡信息
     * @param request
     * @param productType
     * @param productVariety
     * @param productAttr
     * @param productRange
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "getCardInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getCardInfo(HttpServletRequest request, String productType, 
            String productVariety, String productAttr, String productRange) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            User curUser = SessionData.getInstance().getUser(request);
            Channels channel = channelsService.findChannelByUserId(curUser.getId());
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("channelId", channel.getId());
            params.put("productType", productType);
            params.put("productVariety", productVariety);
            params.put("productAttr", productAttr);
            params.put("productRange", productRange);
            // 只查询虚拟卡
            params.put("isCard", 0);
            params.put("status", 1);
            // 过期时间
            params.put("expire", DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss));
            CardInfo cardInfo = cardInfoService.getCardInfoByCondition(params);
            if (null != cardInfo) {
                params = new HashMap<String, Object>();
                params.put("productId", cardInfo.getProductId());
                params.put("channelId", channel.getChannelIdLevel1());
                params.put("proType", "1");
                // 判断该渠道下的商品是否可用，不可用的话，不能卖出
                int result = productService.findByProductIdAndChannelId(params);
                if (result > 0) {
                    map.put("status", true);
                    map.put("result", cardInfo);
                } else {
                    map.put("status", false);
                    map.put("msg", "该商品已下架，请选择其它商品!");
                }
            } else {
                map.put("status", false);
                map.put("msg", "未匹配到卡信息!");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "未匹配到卡信息!");
        }
        return map;
    }
    
    /**
     * 调取卡密
     * @param request
     * @param cardNo 卡号
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "retrieveCardInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> retrieveCardInfo(HttpServletRequest request, String cardNo) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("cardNo", cardNo);
            CardInfo cardInfo = cardInfoService.getCardInfoByCondition(params);
            if (null != cardInfo) {
                // 更新卡密表的使用者渠道id,状态和销售时间
                User curUser = SessionData.getInstance().getUser(request);
                Channels channel = channelsService.findChannelByUserId(curUser.getId());
                cardInfo.setUseChannelId(channel.getId());
                // 状态：1-待销售，2-销售待激活，3-已激活
                cardInfo.setStatus(2);
                cardInfo.setSellTime(new Date());
                cardInfo.setUpdateId(curUser.getId());
                cardInfo.setUpdateTime(new Date());
                cardInfoService.updateCardInfo(cardInfo);
                
                // 记录卡密记录表
                CardInfoRecord record = new CardInfoRecord();
                record.setCardNo(cardInfo.getCardNo());
                record.setCardPwd(cardInfo.getCardPwd());
                record.setChannelId(channel.getId());
                record.setBusinessType("调取卡密");
                record.setProductId(cardInfo.getProductId());
                record.setProductType(cardInfo.getProductType());
                record.setMsisdn(null);
                record.setIsCard(cardInfo.getIsCard());
                // 销售方式 1:线上 2:线下
                record.setSaleType(2);
                record.setMoney(cardInfo.getPrice());
                record.setSaleTime(new Date());
                record.setActiveTime(null);
                // 状态 0:未激活 1:充值成功 2:充值失败
                record.setStatus(new Integer(0));
                record.setCreateId(curUser.getId());
                record.setCreateTime(new Date());
                cardInfoRecordService.insertRecord(record);
                //修改库存信息
                stockService.cardActivation(cardInfo,channel,curUser);
                map.put("status", true);
                map.put("result", cardInfo);
                
                // 记录日志
                Map<String,String> logMap = new HashMap<String,String>();
                logMap.put("staff", curUser.getLoginName());
                logMap.put("cardNo", cardNo);
                logMap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                logMap.put("result","成功！");
                businessLogService.businessSaveLog(Business.retrieve_card, String.valueOf(curUser.getId()),curUser.getLoginName(), "", "调取卡密", logMap);
            } else {
                map.put("status", false);
                map.put("msg", "未匹配到卡信息!");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "调取卡密失败!");
        }
        return map;
    }
    
    /**
     * 初始化补货页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("replenishInit")
    public String replenishInit(HttpServletRequest request, HttpServletResponse response) {
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            Channels channels = channelsService.findChannelByUserId(user.getId());
            // 总部员工登录
            if (channels==null && user.getChannelId()==null) {
                return "/deny.jsp";
            }
            
            // 划拨账户
            ChannelAccount channelAccountHB = channelAccountService.findByChannelIdAndType(channels.getId(), 2);
            // 充值账户
            ChannelAccount channelAccountZC = channelAccountService.findByChannelIdAndType(channels.getId(), 3);
            // 未处理的划拨账户订单金额（元）
            Map<String, Object> para = new HashMap<String, Object>();
            para.put("channelId", channels.getId());
            para.put("accountType", 2);
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
            // 未处理的充值账户订单金额（元）
            para.put("accountType", 3);
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
            // 计算账户余额：划拨账户+充值账户-未处理订单金额
            // 计算账户余额
            BigDecimal accountBalance = channelAccountHB.getAccountBalanceYuan().add(channelAccountZC.getAccountBalanceYuan())
                    .subtract(freezeAllotMoney).subtract(freezeRechargeMoney);
            accountBalance = Utils.formatBigDecimal(accountBalance, "#.00");
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("dicKey", "PRO_TYPE");
            List<CodeDictionary> dictList = codeDictionaryService.findChildByDickey(map);
            request.setAttribute("accountBalance", accountBalance);
            request.setAttribute("dictList", dictList);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            request.setAttribute("msg", "补货失败!");
        }
        return "/views/business/replenish.jsp";
    }
    
    /**
     * 根据商品类型等信息，获取商品详情，并判断该商品是否属于当前渠道
     * @param request
     * @param productType
     * @param productVariety
     * @param productAttr
     * @param productRange
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "getProductInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getProductInfo(HttpServletRequest request, String productType, 
            String productVariety, String productAttr, String productRange) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            User curUser = SessionData.getInstance().getUser(request);
            Channels channel = channelsService.findChannelByUserId(curUser.getId());
            Map<String, Object> params = new HashMap<String, Object>();
            StringBuilder proOnlyStr = new StringBuilder();
            proOnlyStr.append(productType).append(productVariety).append(productRange).append(productAttr);
            params.put("proOnlyStr", proOnlyStr.toString());
            params.put("status", "2");
            // 根据商品的四个属性，获取唯一的商品信息
            List<Product> list = productService.getProductList(params);
            Product product = null;
            if (null!=list && list.size()>0) {
                product = list.get(0);
                params = new HashMap<String, Object>();
                params.put("productId", product.getId());
                params.put("channelId", channel.getChannelIdLevel1());
                params.put("proType", "1");
                int result = productService.findByProductIdAndChannelId(params);
                if (result > 0) {
                    map.put("status", true);
                    map.put("result", product);
                } else {
                    map.put("status", false);
                    map.put("msg", "该商品已下架，请选择其它商品!");
                }
            } else {
                map.put("status", false);
                map.put("msg", "当前渠道没有该商品信息!");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "网络异常，请稍后再试!");
        }
        return map;
    }
    
    /**
     * 申请补货
     * @param request
     * @param response
     * @param productInfo
     * @return
     */
    @RequestMapping("replenish")
    public String replenish(HttpServletRequest request, HttpServletResponse response, String productInfo) {
        try {
            productInfo = URLDecoder.decode(productInfo, "utf-8");
            User curUser = SessionData.getInstance().getUser(request);
            String msg = cool170Service.replenish(curUser, productInfo);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("dicKey", "PRO_TYPE");
            List<CodeDictionary> dictList = codeDictionaryService.findChildByDickey(map);
            request.setAttribute("dictList", dictList);
            request.setAttribute("msg", msg);
            
            if ("补货成功".equals(msg)) {
                String[] productInfos = productInfo.split(";");
                StringBuilder productDetails = new StringBuilder();
                for (int i = 0; i < productInfos.length; i++) {
                    String productId = productInfos[i].split(",")[0];
                    String productName = productInfos[i].split(",")[1];
                    String productNum = productInfos[i].split(",")[2];
                    productDetails.append("商品名称:").append(productName).append(",商品ID:").append(productId).append(",")
                            .append("数量:").append(productNum);
                    if (i < productInfos.length-1) {
                        productDetails.append(";");
                    }
                }
                // 记录日志
                Map<String,String> logMap = new HashMap<String,String>();
                logMap.put("staff", curUser.getLoginName());
                logMap.put("productInfo", productDetails.toString());
                logMap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                logMap.put("result","成功！");
                businessLogService.businessSaveLog(Business.replenish, String.valueOf(curUser.getId()),curUser.getLoginName(), "", "申请补货", logMap);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            request.setAttribute("msg", "补货失败!");
        }
        return replenishInit(request, response);
    }
}
