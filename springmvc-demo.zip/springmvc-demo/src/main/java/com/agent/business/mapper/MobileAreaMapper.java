package com.agent.business.mapper;


import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.business.entity.MobileArea;
import com.agent.common.BaseMapper;

@Repository
public interface MobileAreaMapper extends BaseMapper<MobileArea, Integer> {
    public MobileArea findByPrefix(Map<String, Object> parment);
}
