package com.agent.business.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.CommonUtil;
import com.agent.constant.Constant;
import com.agent.util.DateUtil;

/**
 * 查询号码DTO
 * @author zhangwei
 *
 */
public class SubsDTO {
    // 正常在用
    public static final String SUBS_STATE_A = "A";
    // 销户
    public static final String SUBS_STATE_B = "B";
    // 停机
    public static final String SUBS_STATE_E = "E";
    // 未激活
    public static final String SUBS_STATE_G = "G";
    public static final String BLOCK_REASON_2 = "2";
    
    // 用户ID，对应BOSS的cc.subs表的subs_id字段
    private Integer subsId;
    // 手机号码
    private String phone;
    // 密码
    private String pwd;
    // A：正常    B:销户    D：单停    E:双停    G：未激活
    private String prodState;
    // 停机状态位
    private String blockReason;
    // 用户姓名
    private String custName;
    // 用户身份证号码
    private String certNbr;
    // 靓号标识，非空表示是靓号
    private String beautifulFlag;
    // 用户余额
    private BigDecimal balance;
    // 当月消费额
    private BigDecimal consumeBal;
    // 入网时间
    private String openDate;
    // 套餐编码
    private String offerId;
    // 套餐名称
    private String offerName;
    // 总流量（单位：MB）
    private String totalFlow = "0";
    // 当月已使用流量（单位：MB）
    private String usedFlow = "0";
    // 剩余流量（单位：MB）
    private String remaindFlow = "0";
    // 语音总分钟数（单位：分钟）
    private String totalVoice = "0";
    // 语音已使用分钟数（单位：分钟）
    private String usedVoice = "0";
    // 语音剩余分钟数（单位：分钟）
    private String remaindVoice = "0";
    // 短信总条数（单位：条）
    private String totalSMS = "0";
    // 短信已使用条数（单位：条）
    private String usedSMS = "0";
    // 短信剩余条数（单位：条）
    private String remaindSMS = "0";
    // 费用项名称
    private String itemName;
    // 费用项ID
    private Integer itemType;
    // 费用(分)
    private BigDecimal itemCharge;
    // 账期
    private Date accountPeriod;
    // 月消费总额(分)
    private BigDecimal due;
    // 网络 LT:联通 YD:移动
    private String network;
    
    public Integer getSubsId() {
        return subsId;
    }
    public void setSubsId(Integer subsId) {
        this.subsId = subsId;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getPwd() {
        return pwd;
    }
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    public String getProdState() {
        return prodState;
    }
    public String getProdStateStr() {
        return CommonUtil.getInstance().getProdStateStr(prodState, blockReason);
    }
    public void setProdState(String prodState) {
        this.prodState = prodState;
    }
    public String getBlockReason() {
        return blockReason;
    }
    public void setBlockReason(String blockReason) {
        this.blockReason = blockReason;
    }
    public String getCustName() {
        return custName;
    }
    public void setCustName(String custName) {
        this.custName = custName;
    }
    public String getCertNbr() {
        return certNbr;
    }
    public void setCertNbr(String certNbr) {
        this.certNbr = certNbr;
    }
    public String getBeautifulFlag() {
        return beautifulFlag;
    }
    public void setBeautifulFlag(String beautifulFlag) {
        this.beautifulFlag = beautifulFlag;
    }
    public BigDecimal getBalance() {
        return balance;
    }
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    public BigDecimal getConsumeBal() {
        return consumeBal;
    }
    public void setConsumeBal(BigDecimal consumeBal) {
        this.consumeBal = consumeBal;
    }
    public String getOpenDate() {
        return openDate;
    }
    public void setOpenDate(String openDate) {
        this.openDate = openDate;
    }
    public String getOfferId() {
        return offerId;
    }
    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }
    public String getOfferName() {
        return offerName;
    }
    public void setOfferName(String offerName) {
        this.offerName = offerName;
    }
    public String getTotalFlow() {
        return totalFlow;
    }
    public void setTotalFlow(String totalFlow) {
        this.totalFlow = totalFlow;
    }
    public String getUsedFlow() {
        return usedFlow;
    }
    public void setUsedFlow(String usedFlow) {
        this.usedFlow = usedFlow;
    }
    public String getRemaindFlow() {
        return remaindFlow;
    }
    public void setRemaindFlow(String remaindFlow) {
        this.remaindFlow = remaindFlow;
    }
    public String getTotalVoice() {
        return totalVoice;
    }
    public void setTotalVoice(String totalVoice) {
        this.totalVoice = totalVoice;
    }
    public String getUsedVoice() {
        return usedVoice;
    }
    public void setUsedVoice(String usedVoice) {
        this.usedVoice = usedVoice;
    }
    public String getRemaindVoice() {
        return remaindVoice;
    }
    public void setRemaindVoice(String remaindVoice) {
        this.remaindVoice = remaindVoice;
    }
    public String getTotalSMS() {
        return totalSMS;
    }
    public void setTotalSMS(String totalSMS) {
        this.totalSMS = totalSMS;
    }
    public String getUsedSMS() {
        return usedSMS;
    }
    public void setUsedSMS(String usedSMS) {
        this.usedSMS = usedSMS;
    }
    public String getRemaindSMS() {
        return remaindSMS;
    }
    public void setRemaindSMS(String remaindSMS) {
        this.remaindSMS = remaindSMS;
    }
    public String getItemName() {
        return itemName;
    }
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    public BigDecimal getItemCharge() {
        return itemCharge;
    }
    public BigDecimal getItemChargeYuan() {
        BigDecimal itemChargeYuan = itemCharge;
        if (null != itemCharge) {
            itemChargeYuan = itemCharge.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN);
        }
        return itemChargeYuan;
    }
    public void setItemCharge(BigDecimal itemCharge) {
        this.itemCharge = itemCharge;
    }
    public Integer getItemType() {
        return itemType;
    }
    public void setItemType(Integer itemType) {
        this.itemType = itemType;
    }
    public Date getAccountPeriod() {
        return accountPeriod;
    }
    public String getAccountPeriodStr() {
        String accountPeriodStr = null;
        if (null != accountPeriod) {
            accountPeriodStr = DateUtil.getInstance().formatDate(accountPeriod, "yyyy年MM月");
        }
        return accountPeriodStr;
    }
    public String getAccountPeriodyyyyMM() {
        String accountPeriodStr = null;
        if (null != accountPeriod) {
            accountPeriodStr = DateUtil.getInstance().formatDate(accountPeriod, "yyyyMM");
        }
        return accountPeriodStr;
    }
    public void setAccountPeriod(Date accountPeriod) {
        this.accountPeriod = accountPeriod;
    }
    public BigDecimal getDue() {
        return due;
    }
    public String getDueYuan() {
        String dueYuan = null;
        try {
            if (null != due) {
                dueYuan = String.valueOf(due.divide(Constant.cnt100).setScale(2,BigDecimal.ROUND_DOWN));
            }
        } catch (Exception e) {
            dueYuan = null;
        }
        return dueYuan;
    }
    public void setDue(BigDecimal due) {
        this.due = due;
    }
    public String getNetwork() {
        return network;
    }
    public void setNetwork(String network) {
        this.network = network;
    }
}
