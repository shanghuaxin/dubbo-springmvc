package com.agent.brokerage.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.brokerage.entity.BossServiceHis;
import com.agent.brokerage.mapper.BossServiceHisMapper;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service
public class BossServiceHisService {
    
    private static Logger logger = LoggerFactory.getLogger(BossServiceHisService.class);
    
    @Autowired
    private BossServiceHisMapper bossServiceMapper;
    
    /**
     * 根据渠道等级计算佣金总额
     * @param map
     * @return
     */
    public BigDecimal statistics170Brokerage(Map<String, Object> map) {
        try {
            return bossServiceMapper.statistics170Brokerage(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return new BigDecimal(0);
    }
    
    /**
     * 根据渠道等级计算消费总额
     * @param map id和账期月
     * @return
     */
    public BigDecimal statistics170TotalFeeChannelLevel(Map<String, Object> map) {
        try {
            return bossServiceMapper.statistics170TotalFeeChannelLevel(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return new BigDecimal(0);
    }
    
    /**
     * 根据业务类型汇总佣金和消费金额
     * @param map
     * @return
     */
    public List<BossServiceHis> countFeeByBssCode(Map<String, Object> map) {
        try {
            return bossServiceMapper.countFeeByBssCode(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 根据渠道等级计算用户数量
     * @param map id和账期月
     * @return
     */
    public int statistics170NumberCount(Map<String, Object> map) {
        try {
            return bossServiceMapper.statistics170NumberCount(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return 0;
    }
    
    /**
     * 根据ID查找佣金信息
     * @param map id和账期月
     * @return
     */
    public List<BossServiceHis> findById(Map<String, Object> map) {
        try {
            return bossServiceMapper.findById(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 根据业务编码汇总佣金
     * @param map
     * @return
     */
    public List<BossServiceHis> countByBssCode(Map<String, Object> map) {
        try {
            return bossServiceMapper.countByBssCode(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 获取分页的渠道ID集合
     * @param map
     * @return
     */
    public List<BossServiceHis> qryChannelId(Map<String, Object> map) {
        try {
            return bossServiceMapper.qryChannelId(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 获取分页的渠道ID集合
     * @param map
     * @return
     */
    public int countByChannelId(Map<String, Object> map) {
        try {
            return bossServiceMapper.countByChannelId(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return 0;
    }
    
    /**
     * 获取指定渠道的汇总信息
     * @param map
     * @return
     */
    public List<BossServiceHis> qryFeeByChannelId(Map<String, Object> map) {
        try {
            return bossServiceMapper.qryFeeByChannelId(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 用户使用情况汇总
     * @param map
     * @return
     */
    public List<BossServiceHis> qryNumberCountByChannelId(Map<String, Object> map) {
        try {
            return bossServiceMapper.qryNumberCountByChannelId(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 用户使用情况汇总
     * @param map
     * @return
     */
    public List<BossServiceHis> countNumberCountByBssCode(Map<String, Object> map) {
        try {
            return bossServiceMapper.countNumberCountByBssCode(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 汇总某个渠道下所有的佣金、消费金额总额和用户数
     * @param map
     * @return
     */
    public BossServiceHis statistics170FeeDetail(Map<String, Object> map) {
        try {
            return bossServiceMapper.statistics170FeeDetail(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 根据业务类型汇总某个渠道下的佣金、消费金额总额和用户数
     * @param map
     * @return
     */
    public List<BossServiceHis> qry170FeeByBssCodeDetail(Map<String, Object> map) {
        try {
            return bossServiceMapper.qry170FeeByBssCodeDetail(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 统计某个渠道下的号码（分页）
     * @param map
     * @return
     */
    public List<BossServiceHis> qry170BroNumberDetail(Map<String, Object> map) {
        try {
            return bossServiceMapper.qry170BroNumberDetail(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
    
    /**
     * 统计某个渠道下的号码（总页数）
     * @param map
     * @return
     */
    public int count170BroNumberDetail(Map<String, Object> map) {
        try {
            return bossServiceMapper.count170BroNumberDetail(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return 0;
    }

    /**
     * 统计某个渠道下的佣金详情
     * @param map
     * @return
     */
    public List<BossServiceHis> qry170BroByChannelIdDetail(Map<String, Object> map) {
        try {
            return bossServiceMapper.qry170BroByChannelIdDetail(map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
}
