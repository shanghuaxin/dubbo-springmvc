package com.agent.brokerage.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.brokerage.entity.BossServiceHis;
import com.agent.common.BaseMapper;

@Repository
public interface BossServiceHisMapper extends BaseMapper<BossServiceHis, Integer> {
    
    /**
     * 根据渠道等级计算佣金总额
     * @param map
     * @return
     */
    public BigDecimal statistics170Brokerage(Map<String, Object> map);
    
    /**
     * 根据渠道等级计算消费总额
     * @param map
     * @return
     */
    public BigDecimal statistics170TotalFeeChannelLevel(Map<String, Object> map);
    
    /**
     * 根据渠道等级计算用户数量
     * @param map
     * @return
     */
    public int statistics170NumberCount(Map<String, Object> map);
    
    /**
     * 根据业务类型汇总佣金和消费金额
     * @param map
     * @return
     */
    public List<BossServiceHis> countFeeByBssCode(Map<String, Object> map);
    
    /**
     * 根据ID查找佣金信息
     * @param map
     * @return
     */
    public List<BossServiceHis> findById(Map<String, Object> map);
    
    /**
     * 根据业务编码汇总佣金
     * @param map
     * @return
     */
    public List<BossServiceHis> countByBssCode(Map<String, Object> map);
    
    /**
     * 获取分页的渠道ID集合
     * @param map
     * @return
     */
    public List<BossServiceHis> qryChannelId(Map<String, Object> map);
    
    /**
     * 获取渠道数量
     * @param map
     * @return
     */
    public int countByChannelId(Map<String, Object> map);
    
    /**
     * 获取指定渠道的汇总信息
     * @param map
     * @return
     */
    public List<BossServiceHis> qryFeeByChannelId(Map<String, Object> map);
    
    /**
     * 根据渠道ID汇总业务的使用数量
     * @param map
     * @return
     */
    public List<BossServiceHis> qryNumberCountByChannelId(Map<String, Object> map);
    
    /**
     * 汇总业务的使用数量
     * @param map
     * @return
     */
    public List<BossServiceHis> countNumberCountByBssCode(Map<String, Object> map);
    
    /**
     * 汇总某个渠道下所有的佣金、消费金额总额和用户数(佣金详情)
     * @param map
     * @return
     */
    public BossServiceHis statistics170FeeDetail(Map<String, Object> map);
    
    /**
     * 根据业务类型汇总某个渠道下的佣金、消费金额总额和用户数(佣金详情)
     * @param map
     * @return
     */
    public List<BossServiceHis> qry170FeeByBssCodeDetail(Map<String, Object> map);
    
    /**
     * 统计某个渠道下的号码（分页）(佣金详情)
     * @param map
     * @return
     */
    public List<BossServiceHis> qry170BroNumberDetail(Map<String, Object> map);
    
    /**
     * 统计某个渠道下的号码（总页数）(佣金详情)
     * @param map
     * @return
     */
    public int count170BroNumberDetail(Map<String, Object> map);
    
    /**
     * 统计某个渠道下的佣金详情(佣金详情)
     * @param map
     * @return
     */
    public List<BossServiceHis> qry170BroByChannelIdDetail(Map<String, Object> map);
}
