package com.agent.brokerage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agent.brokerage.entity.Brokerage;
import com.agent.brokerage.mapper.BrokerageMapper;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor=Exception.class)
@Service
public class BrokerageService {
    
    @Autowired
    private BrokerageMapper brokerageMapper;
    
    /**
     * 根据渠道ID、商品类型查找该渠道可见商品
     * @param channelId 渠道ID
     * @param category  商品类型  0-cool170,1-充值
     * @return
     */
    public List<Brokerage> findByChannelIdAndCategory(Integer channelId, Integer category){
        return brokerageMapper.findByChannelIdAndCategory(channelId, category);
    }

}
