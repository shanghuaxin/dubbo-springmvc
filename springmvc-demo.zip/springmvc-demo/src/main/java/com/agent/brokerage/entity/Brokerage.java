package com.agent.brokerage.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 佣金设置表
 * @author weijialiang
 *
 */
public class Brokerage implements Serializable {

    private static final long serialVersionUID = -2522894431198862166L;
    private Integer id;                  //id
    private Integer channelIdFrom;       //父级渠道ID
    private String channelCodeFrom;      //父级渠道编码
    private String channelNameFrom;      //父级渠道名称
    private Integer channelIdLevel1;     //归属一级渠道id
    private Integer channelIdLevel2;     //归属二级渠道id
    private Integer channelIdTo;         //渠道ID
    private String channelCodeTo;        //渠道编码
    private String channelNameTo;        //渠道名称
    private Integer productCategory;         //产品类 别，0-cool170,1-充值
    private Integer productId;           //产品ID
    private String productCode;          //产品编码
    private String proType;          //商品类型：1-产品，2-套餐
    private String businessCode;         //业务编码
    private BigDecimal ratio;                //佣金比例
    private BigDecimal ratio1;                //佣金比例
    private BigDecimal ratio2;                //佣金比例
    private Integer createId;            //创建人ID
    private Date createTime;             //创建时间
    private Integer updateId;            //更新人ID
    private Date updateTime;             //更新时间
    
    //扩充字段
    private BigDecimal channelBro1;//一级渠道佣金比例
    private BigDecimal channelBro2;//二级渠道佣金比例
    private BigDecimal channelBro3;//三级渠道佣金比例
    private String productName;    //产品名称

    public Brokerage() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelIdFrom() {
        return channelIdFrom;
    }

    public void setChannelIdFrom(Integer channelIdFrom) {
        this.channelIdFrom = channelIdFrom;
    }

    public String getChannelCodeFrom() {
        return channelCodeFrom;
    }

    public void setChannelCodeFrom(String channelCodeFrom) {
        this.channelCodeFrom = channelCodeFrom;
    }

    public String getChannelNameFrom() {
        return channelNameFrom;
    }

    public void setChannelNameFrom(String channelNameFrom) {
        this.channelNameFrom = channelNameFrom;
    }

    public Integer getChannelIdLevel1() {
        return channelIdLevel1;
    }

    public void setChannelIdLevel1(Integer channelIdLevel1) {
        this.channelIdLevel1 = channelIdLevel1;
    }

    public Integer getChannelIdLevel2() {
        return channelIdLevel2;
    }

    public void setChannelIdLevel2(Integer channelIdLevel2) {
        this.channelIdLevel2 = channelIdLevel2;
    }

    public Integer getChannelIdTo() {
        return channelIdTo;
    }

    public void setChannelIdTo(Integer channelIdTo) {
        this.channelIdTo = channelIdTo;
    }

    public String getChannelCodeTo() {
        return channelCodeTo;
    }

    public void setChannelCodeTo(String channelCodeTo) {
        this.channelCodeTo = channelCodeTo;
    }

    public String getChannelNameTo() {
        return channelNameTo;
    }

    public void setChannelNameTo(String channelNameTo) {
        this.channelNameTo = channelNameTo;
    }

    public Integer getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(Integer productCategory) {
        this.productCategory = productCategory;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode;
    }

    public BigDecimal getRatio() {
        return ratio;
    }

    public void setRatio(BigDecimal ratio) {
        this.ratio = ratio;
    }

    public BigDecimal getRatio1() {
        return ratio1;
    }

    public void setRatio1(BigDecimal ratio1) {
        this.ratio1 = ratio1;
    }

    public BigDecimal getRatio2() {
        return ratio2;
    }

    public void setRatio2(BigDecimal ratio2) {
        this.ratio2 = ratio2;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getChannelBro1() {
        return channelBro1;
    }

    public void setChannelBro1(BigDecimal channelBro1) {
        this.channelBro1 = channelBro1;
    }

    public BigDecimal getChannelBro2() {
        return channelBro2;
    }

    public void setChannelBro2(BigDecimal channelBro2) {
        this.channelBro2 = channelBro2;
    }

    public BigDecimal getChannelBro3() {
        return channelBro3;
    }

    public void setChannelBro3(BigDecimal channelBro3) {
        this.channelBro3 = channelBro3;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType;
    }

    @Override
    public String toString() {
        return "Brokerage [id=" + id + ", channelIdFrom=" + channelIdFrom + ", channelCodeFrom=" + channelCodeFrom
                + ", channelNameFrom=" + channelNameFrom + ", channelIdTo=" + channelIdTo + ", channelCodeTo="
                + channelCodeTo + ", channelNameTo=" + channelNameTo + ", productCategory=" + productCategory
                + ", productId=" + productId + ", productCode=" + productCode + ", businessCode=" + businessCode
                + ", ratio=" + ratio + ", createId=" + createId + ", createTime=" + createTime + ", updateId="
                + updateId + ", updateTime=" + updateTime + "]";
    }

}
