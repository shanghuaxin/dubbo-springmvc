package com.agent.brokerage.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.agent.brokerage.dto.BossServiceHisDTO;
import com.agent.brokerage.entity.BossServiceHis;
import com.agent.brokerage.service.BossServiceHisService;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelAccountTransactionService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.PageEntity;
import com.agent.constant.Constant;
import com.agent.system.entity.CodeDictionary;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.ExcelUtils;

@Controller
@RequestMapping("brokerage")
public class BrokerageController {
    
    private static Logger logger = LoggerFactory.getLogger(BrokerageController.class);
    
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private BossServiceHisService bossServiceHisService;
    @Autowired
    private ChannelAccountService channelAccountService;
    @Autowired
    private ChannelAccountTransactionService transactionService;

    @RequestMapping(value = "/count170Bro")
    public String count170Bro(HttpServletRequest request, HttpServletResponse response, 
            String sttlDateYm, String channelInfo, Integer channelLevel, Integer tabIndex,
            Integer pageIndex, Integer pageSize) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        if (user == null) {
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        try {
            channelInfo = null==channelInfo?"":channelInfo.trim();
            // 需要展示的tab页签索引，默认为0
            if (null == tabIndex) {
                tabIndex = 0;
            }
            Map<String, Object> params = new HashMap<String, Object>();
            // 当前登录的渠道ID，总部登录时为空
            Integer currentChannelLevel = null;
            Integer currentChannelType = null;
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            if (null != channels) {
                currentChannelLevel = channels.getChannelLevel();
                currentChannelType = channels.getChannelType();
                params.put("currentChannelType", currentChannelType);
                params.put("currentChannelId", channels.getId());
                if (currentChannelLevel == 1) {
                    // 一级
                    if (channelLevel == 1) {
                        params.put("currentChannelLevel", "0");
                    } else {
                        params.put("currentChannelLevel", "1");
                    }
                } else if (currentChannelLevel==2 && currentChannelType==1) {
                    // 二级
                    if (channelLevel == 2) {
                        params.put("currentChannelLevel", "0");
                    } else {
                        params.put("currentChannelLevel", "2");
                    }
                } else {
                    // 网点和直属网点
                    params.put("currentChannelLevel", "0");
                }
            }
            List<BossServiceHisDTO> bossServiceHisDTOList = new ArrayList<BossServiceHisDTO>();
            List<BossServiceHisDTO> bossServiceHisCountList = new ArrayList<BossServiceHisDTO>();
            
            if (StringUtils.isEmpty(sttlDateYm)) {
                sttlDateYm = DateUtil.getInstance().getDateStr(new Date(), "yyyyMM");
            }
            if (null == channelLevel) {
                channelLevel = 1;
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
            params.put("tableName", "t_boss_service_his_"+sttlDateYm);
            // 要查询的渠道等级
            params.put("channelLevel", channelLevel);
            // 渠道名称或编码(预编译，字符串必须要用单引号包括起来)
            if (StringUtils.isNotEmpty(channelInfo)) {
                params.put("channelInfo", "'"+channelInfo.trim()+"'");
            }
            // 查询要当前页的渠道ID
            List<BossServiceHis> bossServiceHisListTmp = bossServiceHisService.qryChannelId(params);
            int total = bossServiceHisService.countByChannelId(params);
            pageEntity.setTotal(total);
            if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                List<Integer> channelIds = new ArrayList<Integer>();
                for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                    BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                    if (1 == channelLevel) {
                        channelIds.add(bossServiceHisTmp.getChannelId1());
                    } else if (2 == channelLevel) {
                        channelIds.add(bossServiceHisTmp.getChannelId2());
                    } else {
                        channelIds.add(bossServiceHisTmp.getChannelId3());
                    }
                }
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("channelIds", channelIds);
                // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
                map.put("tableName", "t_boss_service_his_"+sttlDateYm);
                map.put("channelLevel", channelLevel);
                // 查找指定渠道集合的汇总信息
                bossServiceHisListTmp = bossServiceHisService.qryFeeByChannelId(map);
                // 组装话单信息，按渠道ID和业务编码分组展示
                if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                    Integer channelId = null;
                    BossServiceHisDTO bossServiceHisDTO = null;
                    for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                        BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                        Integer tempChannelId = null;
                        // 保存第一条记录的渠道ID，用于后续的比较
                        if (i == 0) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisDTOList.add(bossServiceHisDTO);
                            if (channelLevel == 1) {
                                channelId = bossServiceHisTmp.getChannelId1();
                            } else if (channelLevel == 2) {
                                channelId = bossServiceHisTmp.getChannelId2();
                            } else {
                                channelId = bossServiceHisTmp.getChannelId3();
                            }
                        }
                        if (channelLevel == 1) {
                            tempChannelId = bossServiceHisTmp.getChannelId1();
                        } else if (channelLevel == 2) {
                            tempChannelId = bossServiceHisTmp.getChannelId2();
                        } else {
                            tempChannelId = bossServiceHisTmp.getChannelId3();
                        }
                        // 判断渠道ID是否重复，重复了直接
                        if (i!=0 && channelId.intValue()!=tempChannelId.intValue()) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisDTOList.add(bossServiceHisDTO);
                            channelId = tempChannelId;
                        }
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        // 根据渠道等级，设置不同的属性
                        setChannelInfo(channelLevel, bossServiceHisDTO, bossServiceHisTmp);
                        // 根据业务类型的不同组装参数
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                }
                
                // 根据渠道ID汇总业务使用数量
                List<BossServiceHis> bossServicelist = bossServiceHisService.qryNumberCountByChannelId(map);
                if (null!=bossServicelist && bossServicelist.size()>0) {
                    Integer channelId = null;
                    BossServiceHisDTO bossServiceHisDTO = null;
                    for (int i = 0; i < bossServicelist.size(); i++) {
                        BossServiceHis bossServiceHisTmp = bossServicelist.get(i);
                        Integer tempChannelId = null;
                        // 保存第一条记录的渠道ID，用于后续的比较
                        if (i == 0) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisCountList.add(bossServiceHisDTO);
                            channelId = bossServiceHisTmp.getChannelId1();
                            if (channelLevel == 1) {
                                channelId = bossServiceHisTmp.getChannelId1();
                            } else if (channelLevel == 2) {
                                channelId = bossServiceHisTmp.getChannelId2();
                            } else {
                                channelId = bossServiceHisTmp.getChannelId3();
                            }
                        }
                        if (channelLevel == 1) {
                            tempChannelId = bossServiceHisTmp.getChannelId1();
                        } else if (channelLevel == 2) {
                            tempChannelId = bossServiceHisTmp.getChannelId2();
                        } else {
                            tempChannelId = bossServiceHisTmp.getChannelId3();
                        }
                        // 判断渠道ID是否重复，重复了直接
                        if (i!=0 && channelId.intValue()!=tempChannelId.intValue()) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisCountList.add(bossServiceHisDTO);
                            channelId = tempChannelId;
                        }
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        // 根据渠道等级，设置不同的属性
                        setChannelInfo(channelLevel, bossServiceHisDTO, bossServiceHisTmp);
                        // 根据业务类型的不同组装参数
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                }
                
                // 根据业务类型汇总佣金和消费总额
                List<BossServiceHis> hisList = bossServiceHisService.countFeeByBssCode(map);
                if (null!=hisList && hisList.size()>0) {
                    BossServiceHisDTO bossServiceHisDTO = new BossServiceHisDTO();
                    for (int i = 0; i < hisList.size(); i++) {
                        BossServiceHis bossServiceHisTmp = hisList.get(i);
                        // 保存第一条记录的渠道ID，用于后续的比较
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        // 根据渠道等级，设置不同的属性
                        setChannelInfo(channelLevel, bossServiceHisDTO, bossServiceHisTmp);
                        // 根据业务类型的不同组装参数
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                    request.setAttribute("totalFeeDTO", bossServiceHisDTO);
                }
                
                // 汇总业务的使用数量
                List<BossServiceHis> countList = bossServiceHisService.countNumberCountByBssCode(params);
                if (null!=countList && countList.size()>0) {
                    BossServiceHisDTO bossServiceHisDTO = new BossServiceHisDTO();
                    for (int i = 0; i < countList.size(); i++) {
                        BossServiceHis bossServiceHisTmp = countList.get(i);
                        // 保存第一条记录的渠道ID，用于后续的比较
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        // 根据渠道等级，设置不同的属性
                        setChannelInfo(channelLevel, bossServiceHisDTO, bossServiceHisTmp);
                        // 根据业务类型的不同组装参数
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                    request.setAttribute("numberCountDTO", bossServiceHisDTO);
                }
            }
            // 佣金汇总
            BigDecimal totalBrokerageB = bossServiceHisService.statistics170Brokerage(params);
            // 消费金额汇总
            BigDecimal totalCostFeeB = bossServiceHisService.statistics170TotalFeeChannelLevel(params);
            // 使用人数汇总
            int numberCount = bossServiceHisService.statistics170NumberCount(params);
            String totalBrokerage = Constant.df0.format(totalBrokerageB.divide(Constant.cnt100));
            String totalCostFee = Constant.df0.format(totalCostFeeB.divide(Constant.cnt100));
            // 构造统计时间的下拉框，展示最近3个月的值
            List<CodeDictionary> sttlDateYms = getCountTime(new Date(), 1, "yyyyMM", "yyyy-MM");
            request.setAttribute("bossServiceHisDTOList", bossServiceHisDTOList);
            request.setAttribute("bossServiceHisCountList", bossServiceHisCountList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("sttlDateYms", sttlDateYms);
            request.setAttribute("sttlDateYm", sttlDateYm);
            request.setAttribute("channelInfo", channelInfo);
            request.setAttribute("channelLevel", channelLevel);
            request.setAttribute("currentChannelLevel", currentChannelLevel);
            request.setAttribute("totalBrokerage", totalBrokerage);
            request.setAttribute("totalCostFee", totalCostFee);
            request.setAttribute("numberCount", numberCount);
            request.setAttribute("tabIndex", tabIndex);
        } catch (Exception e) {
            logger.error("统计佣金汇总信息异常："+e.getMessage(), e);
        }
        return "/views/brokerage/bro_170_list.jsp";
    }
    
    /**
     * 统计佣金详情
     * @param request
     * @param response
     * @param sttlDateYm 统计月
     * @param channelInfo 渠道名称或编码
     * @param channelLevel 当前查询的渠道等级
     * @param tabIndex 显示的页签索引 0,1,2
     * @param pageIndex 当前页
     * @param pageSize 页面大小
     * @return
     */
    @RequestMapping(value = "/count170BroDetail")
    public String count170BroDetail(HttpServletRequest request, HttpServletResponse response, 
            Integer channelId, String channelName, String sttlDateYm, String phoneNumber, Integer channelLevel, 
            Integer tabIndex, Integer pageIndex, Integer pageSize) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        if (user == null) {
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        try {
            phoneNumber = null==phoneNumber?"":phoneNumber.trim();
            // 需要展示的tab页签索引，默认为0
            if (null == tabIndex) {
                tabIndex = 0;
            }
            Map<String, Object> params = new HashMap<String, Object>();
            // 当前登录的渠道ID，总部登录时为空
            Integer currentChannelId = null;
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            // 渠道用户登录
            if(channels == null && user.getBelongChannelId() != null){
                channels = channelsService.findById(user.getBelongChannelId());
            }
            if (null != channels) {
                currentChannelId = channels.getId();
            }
            if (null == channelId) {
                channelId = currentChannelId;
            }
            if (null == channelName) {
                channelName = "";
            }
            List<BossServiceHisDTO> bossServiceHisDTOList = new ArrayList<BossServiceHisDTO>();
            List<BossServiceHisDTO> bossServiceHisCountList = new ArrayList<BossServiceHisDTO>();
            
            if (StringUtils.isEmpty(sttlDateYm)) {
                sttlDateYm = DateUtil.getInstance().getDateStr(new Date(), "yyyyMM");
            }
            if (null == channelLevel) {
                channelLevel = 1;
            }
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
            params.put("tableName", "t_boss_service_his_"+sttlDateYm);
            // 要查询的渠道ID
            params.put("channelId", channelId);
            // 要查询的渠道等级
            params.put("channelLevel", channelLevel);
            // 渠道名称或编码(预编译，字符串必须要用单引号包括起来)
            if (StringUtils.isNotEmpty(phoneNumber)) {
                params.put("msisdn", "'"+phoneNumber+"'");
            }
            // 汇总某个渠道下所有的佣金、消费金额总额和用户数
            BossServiceHis bossServiceHisFee = bossServiceHisService.statistics170FeeDetail(params);
            if (null == bossServiceHisFee) {
                bossServiceHisFee = new BossServiceHis();
            }
            // 汇总某个渠道下的用户数
            int numberCount = 0;
            if (null != bossServiceHisFee.getCnt()) {
                numberCount = bossServiceHisFee.getCnt().intValue();
            }
            
            // 查询要当前页的号码
            List<BossServiceHis> bossServiceHisListTmp = bossServiceHisService.qry170BroNumberDetail(params);
            // 页面大小
            int total = bossServiceHisService.count170BroNumberDetail(params);
            pageEntity.setTotal(total);
            if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                List<String> msisdns = new ArrayList<String>();
                for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                    BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                    // 由于sql是预编译的（statementType="STATEMENT"），字符串需要特殊处理，用单引号引起来
                    msisdns.add("'"+bossServiceHisTmp.getMsisdn()+"'");
                }
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("msisdns", msisdns);
                // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
                map.put("tableName", "t_boss_service_his_"+sttlDateYm);
                map.put("channelId", channelId);
                map.put("channelLevel", channelLevel);
                // 查找指定渠道集合的汇总信息
                bossServiceHisListTmp = bossServiceHisService.qry170BroByChannelIdDetail(map);
                // 组装话单信息，按号码分组展示
                if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                    String msisdn = null;
                    BossServiceHisDTO bossServiceHisDTO = null;
                    for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                        BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                        // 保存第一条记录的手机号码，用于后续的比较
                        if (i == 0) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisDTOList.add(bossServiceHisDTO);
                            msisdn = bossServiceHisTmp.getMsisdn();
                        }
                        // 判断手机号码是否重复，重复了直接覆盖
                        if (i!=0 && !msisdn.equals(bossServiceHisTmp.getMsisdn())) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisDTOList.add(bossServiceHisDTO);
                            msisdn = bossServiceHisTmp.getMsisdn();
                        }
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        bossServiceHisDTO.setMealCode(bossServiceHisTmp.getMealCode());
                        bossServiceHisDTO.setMsisdn(bossServiceHisTmp.getMsisdn());
                        // 设置默认值
                        bossServiceHisTmp.setCnt(1);
                        // 根据业务类型的不同组装参数
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                }
                
                // 根据业务类型汇总佣金和消费总额
                List<BossServiceHis> hisList = bossServiceHisService.qry170FeeByBssCodeDetail(params);
                if (null!=hisList && hisList.size()>0) {
                    BossServiceHisDTO bossServiceHisDTO = new BossServiceHisDTO();
                    for (int i = 0; i < hisList.size(); i++) {
                        BossServiceHis bossServiceHisTmp = hisList.get(i);
                        // 保存第一条记录的渠道ID，用于后续的比较
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        // 根据业务类型的不同组装参数
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                    request.setAttribute("totalFeeDTO", bossServiceHisDTO);
                }
            }
            
            // 构造统计时间的下拉框，展示最近3个月的值
            List<CodeDictionary> sttlDateYms = getCountTime(new Date(), 1, "yyyyMM", "yyyy-MM");
            request.setAttribute("bossServiceHisDTOList", bossServiceHisDTOList);
            request.setAttribute("bossServiceHisCountList", bossServiceHisCountList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("sttlDateYms", sttlDateYms);
            request.setAttribute("sttlDateYm", sttlDateYm);
            request.setAttribute("phoneNumber", phoneNumber);
            request.setAttribute("channelLevel", channelLevel);
            request.setAttribute("channelId", channelId);
            request.setAttribute("channelName", channelName);
            request.setAttribute("bossServiceHisFee", bossServiceHisFee);
            request.setAttribute("numberCount", numberCount);
            request.setAttribute("tabIndex", tabIndex);
        } catch (Exception e) {
            logger.error("统计佣金汇总信息异常："+e.getMessage(), e);
        }
        return "/views/brokerage/bro_170_detail.jsp";
    }
    
    /**
     * 导出佣金统计
     * @param request
     * @param response
     * @param sttlDateYm 统计时间（YYYYMM）
     * @param channelInfo 渠道名称或编码
     * @param channelLevel 渠道等级
     * @param tabIndex 要导出数据的维度（0：佣金 1：消费金额 2：用户数）
     * @param pageSize
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, 
            String sttlDateYm, String channelInfo, Integer channelLevel, Integer tabIndex, Integer pageSize) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        if (user == null) {
            //跳转到登录界面
            logger.error("session过期");
            return;
        }
        try {
            if (StringUtils.isEmpty(channelInfo)) {
                channelInfo = "";
            }
            // 需要展示的tab页签索引，默认为0
            if (null == tabIndex) {
                tabIndex = 0;
            }
            if (null == channelLevel) {
                channelLevel = 1;
            }
            Map<String, Object> params = new HashMap<String, Object>();
            // 当前登录的渠道ID，总部登录时为空
            Integer currentChannelLevel = null;
            Integer currentChannelType = null;
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            // 渠道用户登录
            if(channels == null && user.getBelongChannelId() != null){
                channels = channelsService.findById(user.getBelongChannelId());
            }
            if (null != channels) {
                currentChannelLevel = channels.getChannelLevel();
                currentChannelType = channels.getChannelType();
                params.put("currentChannelType", currentChannelType);
                params.put("currentChannelId", channels.getId());
                if (currentChannelLevel == 1) {
                    // 一级
                    if (channelLevel == 1) {
                        params.put("currentChannelLevel", "0");
                    } else {
                        params.put("currentChannelLevel", "1");
                    }
                } else if (currentChannelLevel==2 && currentChannelType==1) {
                    // 二级
                    if (channelLevel == 2) {
                        params.put("currentChannelLevel", "0");
                    } else {
                        params.put("currentChannelLevel", "2");
                    }
                } else {
                    // 网点和直属网点
                    params.put("currentChannelLevel", "0");
                }
            }
            List<BossServiceHisDTO> bossServiceHisDTOList = new ArrayList<BossServiceHisDTO>();
            List<BossServiceHisDTO> bossServiceHisCountList = new ArrayList<BossServiceHisDTO>();
            
            if (StringUtils.isEmpty(sttlDateYm)) {
                sttlDateYm = DateUtil.getInstance().getDateStr(new Date(), "yyyyMM");
            }
            
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
            params.put("tableName", "t_boss_service_his_"+sttlDateYm);
            // 要查询的渠道等级
            params.put("channelLevel", channelLevel);
            // 渠道名称或编码(预编译，字符串必须要用单引号包括起来)
            params.put("channelInfo", "'"+channelInfo+"'");
            // 查询要当前页的渠道ID
            List<BossServiceHis> bossServiceHisListTmp = bossServiceHisService.qryChannelId(params);
            int total = bossServiceHisService.countByChannelId(params);
            pageEntity.setTotal(total);
            if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                List<Integer> channelIds = new ArrayList<Integer>();
                for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                    BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                    if (1 == channelLevel) {
                        channelIds.add(bossServiceHisTmp.getChannelId1());
                    } else if (2 == channelLevel) {
                        channelIds.add(bossServiceHisTmp.getChannelId2());
                    } else {
                        channelIds.add(bossServiceHisTmp.getChannelId3());
                    }
                }
                
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("channelIds", channelIds);
                // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
                map.put("tableName", "t_boss_service_his_"+sttlDateYm);
                map.put("channelLevel", channelLevel);
                
                String downloadName = "170佣金统计";
                ExcelUtils<BossServiceHisDTO> util = ExcelUtils.getInstall();
                String[] headers = null;
                String [] properties = null;
                if (tabIndex==0 || tabIndex==1) {
                    // 查找指定渠道集合的汇总信息
                    bossServiceHisListTmp = bossServiceHisService.qryFeeByChannelId(map);
                    // 组装话单信息，按渠道ID分组展示
                    if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                        Integer channelId = null;
                        BossServiceHisDTO bossServiceHisDTO = null;
                        for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                            BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                            Integer tempChannelId = null;
                            // 保存第一条记录的渠道ID，用于后续的比较
                            if (i == 0) {
                                bossServiceHisDTO = new BossServiceHisDTO();
                                bossServiceHisDTOList.add(bossServiceHisDTO);
                                if (channelLevel == 1) {
                                    channelId = bossServiceHisTmp.getChannelId1();
                                } else if (channelLevel == 2) {
                                    channelId = bossServiceHisTmp.getChannelId2();
                                } else {
                                    channelId = bossServiceHisTmp.getChannelId3();
                                }
                            }
                            if (channelLevel == 1) {
                                tempChannelId = bossServiceHisTmp.getChannelId1();
                            } else if (channelLevel == 2) {
                                tempChannelId = bossServiceHisTmp.getChannelId2();
                            } else {
                                tempChannelId = bossServiceHisTmp.getChannelId3();
                            }
                            // 判断渠道ID是否重复，重复了直接
                            if (i!=0 && channelId.intValue()!=tempChannelId.intValue()) {
                                bossServiceHisDTO = new BossServiceHisDTO();
                                bossServiceHisDTOList.add(bossServiceHisDTO);
                                channelId = tempChannelId;
                            }
                            bossServiceHisDTO.setChannelLevel(channelLevel);
                            // 根据渠道等级，设置不同的属性
                            setChannelInfo(channelLevel, bossServiceHisDTO, bossServiceHisTmp);
                            // 根据业务类型的不同组装参数
                            setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                        }
                        
                        // 构造报表
                        headers = new String[]{"渠道","渠道等级","补扣低消","170语音","170套餐外流量","170流量包","基本套餐月租","来电显示","来电提醒","短信","彩信"};
                        if (tabIndex == 0) {
                            if (channelLevel == 1) {
                                properties = new String[]{"channelNameStr","channelLevelStr","lowCodeRatio1Yuan","voice170Ratio1Yuan",
                                        "flow170Ratio1Yuan","coolFlowRatio1Yuan","flowNomalRatio1Yuan","callShowRatio1Yuan","callReminderRatio1Yuan",
                                        "smsRatio1Yuan","mmsRatio1Yuan"};
                            } else if (channelLevel == 2) {
                                properties = new String[]{"channelNameStr","channelLevelStr","lowCodeRatio2Yuan","voice170Ratio2Yuan",
                                        "flow170Ratio2Yuan","coolFlowRatio2Yuan","flowNomalRatio2Yuan","callShowRatio2Yuan","callReminderRatio2Yuan",
                                        "smsRatio2Yuan","mmsRatio2Yuan"};
                            } else {
                                properties = new String[]{"channelNameStr","channelLevelStr","lowCodeRatio3Yuan","voice170Ratio3Yuan",
                                        "flow170Ratio3Yuan","coolFlowRatio3Yuan","flowNomalRatio3Yuan","callShowRatio3Yuan","callReminderRatio3Yuan",
                                        "smsRatio3Yuan","mmsRatio3Yuan"};
                            }
                        } else {
                            properties = new String[]{"channelNameStr","channelLevelStr","lowCodeYuan","voice170Yuan","flow170Yuan"
                                    ,"coolFlowYuan","flowNomalYuan","callShowYuan","callReminderYuan","smsYuan","mmsYuan"};
                        }
                        response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
                        util.exportExcel(response.getOutputStream(),headers, bossServiceHisDTOList, properties);
                    }
                } else {
                    // 根据渠道ID汇总业务使用数量
                    List<BossServiceHis> bossServicelist = bossServiceHisService.qryNumberCountByChannelId(map);
                    if (null!=bossServicelist && bossServicelist.size()>0) {
                        Integer channelId = null;
                        BossServiceHisDTO bossServiceHisDTO = null;
                        for (int i = 0; i < bossServicelist.size(); i++) {
                            BossServiceHis bossServiceHisTmp = bossServicelist.get(i);
                            Integer tempChannelId = null;
                            // 保存第一条记录的渠道ID，用于后续的比较
                            if (i == 0) {
                                bossServiceHisDTO = new BossServiceHisDTO();
                                bossServiceHisCountList.add(bossServiceHisDTO);
                                channelId = bossServiceHisTmp.getChannelId1();
                                if (channelLevel == 1) {
                                    channelId = bossServiceHisTmp.getChannelId1();
                                } else if (channelLevel == 2) {
                                    channelId = bossServiceHisTmp.getChannelId2();
                                } else {
                                    channelId = bossServiceHisTmp.getChannelId3();
                                }
                            }
                            if (channelLevel == 1) {
                                tempChannelId = bossServiceHisTmp.getChannelId1();
                            } else if (channelLevel == 2) {
                                tempChannelId = bossServiceHisTmp.getChannelId2();
                            } else {
                                tempChannelId = bossServiceHisTmp.getChannelId3();
                            }
                            // 判断渠道ID是否重复，重复了直接
                            if (i!=0 && channelId.intValue()!=tempChannelId.intValue()) {
                                bossServiceHisDTO = new BossServiceHisDTO();
                                bossServiceHisCountList.add(bossServiceHisDTO);
                                channelId = tempChannelId;
                            }
                            bossServiceHisDTO.setChannelLevel(channelLevel);
                            // 根据渠道等级，设置不同的属性
                            setChannelInfo(channelLevel, bossServiceHisDTO, bossServiceHisTmp);
                            // 根据业务类型的不同组装参数
                            setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                        }
                        
                        // 构造报表
                        headers = new String[]{"渠道","渠道等级","补扣低消","170语音","170套餐外流量","170流量包","基本套餐月租","来电显示","来电提醒","短信","彩信"};
                        properties = new String[]{"channelNameStr","channelLevelStr","lowCodeCount","voice170Count","flow170Count"
                                ,"coolFlowCount","flowNomalCount","callShowCount","callReminderCount","smsCount","mmsCount"};
                        response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
                        util.exportExcel(response.getOutputStream(),headers, bossServiceHisCountList, properties);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("统计佣金汇总信息异常："+e.getMessage(), e);
        }
    }
    
    /**
     * 导出佣金详情表单
     * @param request
     * @param response
     * @param channelId 渠道ID
     * @param sttlDateYm 统计时间（YYYYMM）
     * @param phoneNumber 手机号码
     * @param channelLevel 渠道等级
     * @param tabIndex 要导出数据的维度（0：佣金 1：消费金额 2：用户数）
     * @param pageSize
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/exportDataDetail")
    public void exportDataDetail(HttpServletRequest request, HttpServletResponse response, 
            Integer channelId, String sttlDateYm, String phoneNumber, Integer channelLevel, Integer tabIndex, Integer pageSize) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        if (user == null) {
            //跳转到登录界面
            logger.error("session过期");
            return;
        }
        try {
            if (StringUtils.isEmpty(phoneNumber)) {
                phoneNumber = "";
            }
            // 需要展示的tab页签索引，默认为0
            if (null == tabIndex) {
                tabIndex = 0;
            }
            Map<String, Object> params = new HashMap<String, Object>();
            // 当前登录的渠道ID，总部登录时为空
            Integer currentChannelId = null;
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            // 渠道用户登录
            if(channels == null && user.getBelongChannelId() != null){
                channels = channelsService.findById(user.getBelongChannelId());
            }
            if (null != channels) {
                currentChannelId = channels.getId();
            }
            if (null == channelId) {
                channelId = currentChannelId;
            }
            List<BossServiceHisDTO> bossServiceHisDTOList = new ArrayList<BossServiceHisDTO>();
            
            if (StringUtils.isEmpty(sttlDateYm)) {
                sttlDateYm = DateUtil.getInstance().getDateStr(new Date(), "yyyyMM");
            }
            if (null == channelLevel) {
                channelLevel = 1;
            }
            // 设置分页初始化数据
            if (null != pageSize) {
                pageSize = 50000;
            }
            PageEntity pageEntity = new PageEntity(pageSize, 1);
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
            params.put("tableName", "t_boss_service_his_"+sttlDateYm);
            // 要查询的渠道ID
            params.put("channelId", channelId);
            // 要查询的渠道等级
            params.put("channelLevel", channelLevel);
            // 渠道名称或编码(预编译，字符串必须要用单引号包括起来)
            params.put("msisdn", "'"+phoneNumber+"'");
            
            // 查询要当前页的号码
            List<BossServiceHis> bossServiceHisListTmp = bossServiceHisService.qry170BroNumberDetail(params);
            // 页面大小
            int total = bossServiceHisService.count170BroNumberDetail(params);
            pageEntity.setTotal(total);
            if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                List<String> msisdns = new ArrayList<String>();
                for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                    BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                    // 由于sql是预编译的（statementType="STATEMENT"），字符串需要特殊处理，用单引号引起来
                    msisdns.add("'"+bossServiceHisTmp.getMsisdn()+"'");
                }
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("msisdns", msisdns);
                // 传入动态的表面，xml文件中要使用statementType="STATEMENT"预编译的方式
                map.put("tableName", "t_boss_service_his_"+sttlDateYm);
                map.put("channelId", channelId);
                map.put("channelLevel", channelLevel);
                // 查找指定渠道集合的汇总信息
                bossServiceHisListTmp = bossServiceHisService.qry170BroByChannelIdDetail(map);
                // 组装话单信息，按号码分组展示
                if (null!=bossServiceHisListTmp && bossServiceHisListTmp.size()>0) {
                    String msisdn = null;
                    BossServiceHisDTO bossServiceHisDTO = null;
                    for (int i = 0; i < bossServiceHisListTmp.size(); i++) {
                        BossServiceHis bossServiceHisTmp = bossServiceHisListTmp.get(i);
                        // 保存第一条记录的手机号码，用于后续的比较
                        if (i == 0) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisDTOList.add(bossServiceHisDTO);
                            msisdn = bossServiceHisTmp.getMsisdn();
                        }
                        // 判断手机号码是否重复，重复了直接覆盖
                        if (i!=0 && !msisdn.equals(bossServiceHisTmp.getMsisdn())) {
                            bossServiceHisDTO = new BossServiceHisDTO();
                            bossServiceHisDTOList.add(bossServiceHisDTO);
                            msisdn = bossServiceHisTmp.getMsisdn();
                        }
                        bossServiceHisDTO.setChannelLevel(channelLevel);
                        bossServiceHisDTO.setMealCode(bossServiceHisTmp.getMealCode());
                        bossServiceHisDTO.setMsisdn(bossServiceHisTmp.getMsisdn());
                        // 根据业务类型的不同组装参数
                        bossServiceHisTmp.setCnt(1);
                        setPropertyByBssCode(bossServiceHisDTO, bossServiceHisTmp);
                    }
                    
                    // 构造报表
                    String downloadName = "170佣金统计详情";
                    ExcelUtils<BossServiceHisDTO> util = ExcelUtils.getInstall();
                    
                    String[] headers = new String[]{"手机号","套餐","补扣低消","170语音","170套餐外流量","170流量包","基本套餐月租","来电显示","来电提醒","短信","彩信"};
                    String[] properties = null;
                    if (tabIndex == 0) {
                        if (channelLevel == 1) {
                            properties = new String[]{"msisdn","mealCode","lowCodeRatio1Yuan","voice170Ratio1Yuan",
                                    "flow170Ratio1Yuan","coolFlowRatio1Yuan","flowNomalRatio1Yuan",
                                    "callShowRatio1Yuan","callReminderRatio1Yuan","smsRatio1Yuan","mmsRatio1Yuan"};
                        } else if (channelLevel == 2) {
                            properties = new String[]{"msisdn","mealCode","lowCodeRatio2Yuan","voice170Ratio2Yuan",
                                    "flow170Ratio2Yuan","coolFlowRatio2Yuan","flowNomalRatio2Yuan",
                                    "callShowRatio2Yuan","callReminderRatio2Yuan","smsRatio2Yuan","mmsRatio2Yuan"};
                        } else {
                            properties = new String[]{"msisdn","mealCode","lowCodeRatio3Yuan","voice170Ratio3Yuan",
                                    "flow170Ratio3Yuan","coolFlowRatio3Yuan","flowNomalRatio3Yuan",
                                    "callShowRatio3Yuan","callReminderRatio3Yuan","smsRatio3Yuan","mmsRatio3Yuan"};
                        }
                        
                    } else if (tabIndex == 1) {
                        properties = new String[]{"msisdn","mealCode","lowCodeYuan","voice170Yuan","flow170Yuan"
                                ,"coolFlowYuan","flowNomalYuan","callShowYuan","callReminderYuan","smsYuan","mmsYuan"};
                    } else {
                        properties = new String[]{"msisdn","mealCode","lowCodeCount","voice170Count","flow170Count"
                                ,"coolFlowCount","flowNomalCount","callShowCount","callReminderCount","smsCount","mmsCount"};
                    }
                    
                    response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
                    util.exportExcel(response.getOutputStream(),headers, bossServiceHisDTOList, properties);
                }
            }
        } catch (Exception e) {
            logger.error("统计佣金汇总信息异常："+e.getMessage(), e);
        }
    }

    /**
     * 获取统计的月份
     * @param date 开始月份
     * @param len 统计的月份长度
     * @return
     */
    private List<CodeDictionary> getCountTime(Date date, int len, String keyFormat, String valueformat) {
        List<CodeDictionary> dictionaryList = new ArrayList<CodeDictionary>();
        CodeDictionary code = new CodeDictionary();
        try {
            String key = DateUtil.getInstance().getDateStr(date, keyFormat);
            String value = DateUtil.getInstance().getDateStr(date, valueformat);
            code.setDicKey(key);
            code.setDicValue(value);
            dictionaryList.add(code);
            for (int i = 1; i <= len; i++) {
                code = new CodeDictionary();
                Date d = DateUtil.getInstance().minusDateMonth(i);
                key = DateUtil.getInstance().getDateStr(d, keyFormat);
                value = DateUtil.getInstance().getDateStr(d, valueformat);
                code.setDicKey(key);
                code.setDicValue(value);
                dictionaryList.add(code);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return dictionaryList;
    }
    
    /**
     * 根据渠道等级，设置不同的属性
     * @param channelLevel 渠道等级
     * @param bossServiceHisDTO 目标对象
     * @param bossServiceHisTmp 源对象
     */
    private void setChannelInfo(Integer channelLevel, BossServiceHisDTO bossServiceHisDTO, BossServiceHis bossServiceHisTmp) {
        // 根据渠道等级，设置不同的属性
        if (1 == channelLevel) {
            bossServiceHisDTO.setChannelId(bossServiceHisTmp.getChannelId1());
            bossServiceHisDTO.setChannelCode(bossServiceHisTmp.getChannelCode1());
            bossServiceHisDTO.setChannelName(bossServiceHisTmp.getChannelName1());
        } else if (2 == channelLevel) {
            bossServiceHisDTO.setChannelId(bossServiceHisTmp.getChannelId2());
            bossServiceHisDTO.setChannelCode(bossServiceHisTmp.getChannelCode2());
            bossServiceHisDTO.setChannelName(bossServiceHisTmp.getChannelName2());
        } else {
            bossServiceHisDTO.setChannelId(bossServiceHisTmp.getChannelId3());
            bossServiceHisDTO.setChannelCode(bossServiceHisTmp.getChannelCode3());
            bossServiceHisDTO.setChannelName(bossServiceHisTmp.getChannelName3());
        }
    }
    
    /**
     * 根据业务类型的不同组装参数
     * @param bossServiceHisDTO 目标对象
     * @param bossServiceHisTmp 源对象
     */
    private void setPropertyByBssCode(BossServiceHisDTO bossServiceHisDTO, BossServiceHis bossServiceHisTmp) {
        if ("103".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setVoiceAPP(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setVoiceAPPCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setVoiceAPPRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setVoiceAPPRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setVoiceAPPRatio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("201".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setVoice170(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setVoice170Count(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setVoice170Ratio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setVoice170Ratio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setVoice170Ratio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("202".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setSms(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setSmsCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setSmsRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setSmsRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setSmsRatio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("203".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setMms(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setMmsCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setMmsRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setMmsRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setMmsRatio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("204".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setFlow170(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setFlow170Count(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setFlow170Ratio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setFlow170Ratio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setFlow170Ratio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("205".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setCoolFlow(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setCoolFlowCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setCoolFlowRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setCoolFlowRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setCoolFlowRatio3(bossServiceHisTmp.getChannelMoney3());
        }  else if ("206".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setFlowNomal(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setFlowNomalCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setFlowNomalRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setFlowNomalRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setFlowNomalRatio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("208".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setLowCode(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setLowCodeCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setLowCodeRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setLowCodeRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setLowCodeRatio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("209".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setCallShow(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setCallShowCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setCallShowRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setCallShowRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setCallShowRatio3(bossServiceHisTmp.getChannelMoney3());
        } else if ("210".equals(bossServiceHisTmp.getBssCode())) {
            bossServiceHisDTO.setCallReminder(bossServiceHisTmp.getTotalFee());
            bossServiceHisDTO.setCallReminderCount(bossServiceHisTmp.getCnt());
            bossServiceHisDTO.setCallReminderRatio1(bossServiceHisTmp.getChannelMoney1());
            bossServiceHisDTO.setCallReminderRatio2(bossServiceHisTmp.getChannelMoney2());
            bossServiceHisDTO.setCallReminderRatio3(bossServiceHisTmp.getChannelMoney3());
        }
    }
    
    @RequestMapping("/rechargeBrokerageDetail")
    public String rechargeBrokerageDetail(HttpServletRequest request, String sttlDateYm, 
            Integer pageIndex, Integer pageSize) {
        
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            if (user == null) {
                //跳转到登录界面
                logger.error("session过期");
                return "login.jsp";
            }
            Channels channels = channelsService.findChannelByUserId(user.getId());
            if(channels == null && user.getChannelId() != null){
                channels = channelsService.findById(user.getChannelId());
            }
            Integer channelId = null;
            if (null != channels) {
                channelId = channels.getId();
            }
            String nowDate = DateUtil.getInstance().getDateStr(new Date(), "yyyyMM");
            // 查询月份，默认取当前月份
            if (StringUtils.isEmpty(sttlDateYm)) {
                sttlDateYm = nowDate;
            }
            // 如果是当月，则显示未结算，否则显示已结算
            String square = "已结算";
            if (nowDate.equals(sttlDateYm)) {
                square = "未结算";
            }
            // 构造统计时间段，展示最近6个月的值
            List<CodeDictionary> sttlDateYms = getCountTime(new Date(), 5, "yyyyMM", "yyyy年MM月");
            
            Map<String, Object> params = new HashMap<String, Object>();
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(pageSize, pageIndex);
            // 从页面获取每页展示的条数
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);

            if (null != channelId) {
                params.put("channelId", channelId);
            }
            params.put("accountType", 6);
            
            Date date = DateUtil.getInstance().parseDate(sttlDateYm,"yyyyMM");
            String startDate = DateUtil.getInstance().formatDate(date, "yyyy-MM-dd HH:mm:ss");
            String endDate = DateUtil.getInstance().formatDate(date, "yyyy-MM");
            endDate = DateUtil.getInstance().getLastDay(endDate);
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            
            ChannelAccount rechargeBroAccount = channelAccountService.findByChannelIdAndType(channelId, 6);
            BigDecimal totalMoney = rechargeBroAccount.getAccountBalanceYuan();
            
            BigDecimal monthTotalMoney = transactionService.countBrokerageMoney(params);
            monthTotalMoney = monthTotalMoney.divide(new BigDecimal(100));
            List<ChannelAccountTransaction> transactionList = transactionService.queryBrokerageDetail(params);
            int total = transactionService.countBrokerageDetailTotal(params);
            pageEntity.setTotal(total);

            request.setAttribute("totalMoney", totalMoney);
            request.setAttribute("monthTotalMoney", monthTotalMoney.setScale(2, BigDecimal.ROUND_DOWN));
            request.setAttribute("transactionList", transactionList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("sttlDateYm", sttlDateYm);
            request.setAttribute("sttlDateYms", sttlDateYms);
            request.setAttribute("square", square);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        // 充值佣金详情
        return "/views/brokerage/recharge_bro_list.jsp";
    }
}
