package com.agent.brokerage.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.agent.brokerage.entity.Brokerage;
import com.agent.common.BaseMapper;

@Repository
public interface BrokerageMapper extends BaseMapper<Brokerage, Integer> {
    
    public List<Brokerage> findByChannelId(Integer channelId);
    /**
     * 根据渠道ID、商品类型查找该渠道可见商品
     * @param channelId 渠道ID
     * @param category  商品类型  0-cool170,1-充值
     * @return
     */
    public List<Brokerage> findByChannelIdAndCategory(@Param(value="channelId") Integer channelId, @Param(value="category") Integer category);
    /**
     *  根据渠道ID、商品类型查找该渠道佣金设置详情
     * @param channelId
     * @param category
     * @return
     */
    public Brokerage findCzByChannelIdAndCategory(@Param(value="channelId") Integer channelId, @Param(value="category") Integer category);
    public void batchInsert(List<Brokerage> list);
    public void updateBatch(List<Brokerage> list);
    public void batchUpdate(Map<String, Object> params);
    public void deleteCzByChannelIdAndCategory(@Param(value="channelId") Integer channelId, @Param(value="category") Integer category);
    public void deleteByProId(Integer proId);
    public void deleteByChIds(@Param(value="chIds") List<Integer> chIds,@Param(value="productId") Integer productId,@Param(value="proType") String proType);

}
