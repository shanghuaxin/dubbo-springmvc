package com.agent.brokerage.dto;

import java.math.BigDecimal;

import com.agent.constant.Constant;

public class BossServiceHisDTO {
    private Integer channelId; // 渠道ID
    private String channelCode; // 渠道编码
    private String channelName; // 渠道名称
    private Integer channelLevel; // 渠道等级
    private BigDecimal overdue; // 欠费
    private BigDecimal overdueRatio1; // 欠费佣金
    private BigDecimal overdueRatio2; // 欠费佣金
    private BigDecimal overdueRatio3; // 欠费佣金
    private Integer overdueCount; // 欠费人数
    private BigDecimal lowCode; // 补扣低消 208
    private BigDecimal lowCodeRatio1; // 补扣低消佣金 208
    private BigDecimal lowCodeRatio2; // 补扣低消佣金 208
    private BigDecimal lowCodeRatio3; // 补扣低消佣金 208
    private Integer lowCodeCount; // 补扣低消使用人数
    private BigDecimal voice170; // 170语音 201
    private BigDecimal voice170Ratio1; // 170语音佣金 201
    private BigDecimal voice170Ratio2; // 170语音佣金 201
    private BigDecimal voice170Ratio3; // 170语音佣金 201
    private Integer voice170Count; // 170语音使用人数
    private BigDecimal flow170; // 170套餐外流量 204
    private BigDecimal flow170Ratio1; // 170套餐外流量佣金 204
    private BigDecimal flow170Ratio2; // 170套餐外流量佣金 204
    private BigDecimal flow170Ratio3; // 170套餐外流量佣金 204
    private Integer flow170Count; // 170套餐外流量使用人数
    private BigDecimal coolFlow; // 170流量包 205
    private BigDecimal coolFlowRatio1; // 170流量包佣金 205
    private BigDecimal coolFlowRatio2; // 170流量包佣金 205
    private BigDecimal coolFlowRatio3; // 170流量包佣金 205
    private Integer coolFlowCount; // 170流量包使用人数
    private BigDecimal voiceAPP; // 170APP国内语音月免特权 103
    private BigDecimal voiceAPPRatio1; // 170APP国内语音月免特权佣金 103
    private BigDecimal voiceAPPRatio2; // 170APP国内语音月免特权佣金 103
    private BigDecimal voiceAPPRatio3; // 170APP国内语音月免特权佣金 103
    private Integer voiceAPPCount; // APP语音包使用人数
    private BigDecimal flowNomal; // 基本套餐月租 206
    private BigDecimal flowNomalRatio1; // 基本套餐月租佣金 206
    private BigDecimal flowNomalRatio2; // 基本套餐月租佣金 206
    private BigDecimal flowNomalRatio3; // 基本套餐月租佣金 206
    private Integer flowNomalCount; // 基本套餐月租使用人数 206
    private BigDecimal callShow; // 来电显示 209
    private BigDecimal callShowRatio1; // 来电显示佣金 209
    private BigDecimal callShowRatio2; // 来电显示佣金 209
    private BigDecimal callShowRatio3; // 来电显示佣金 209
    private Integer callShowCount; // 来电显示使用人数
    private BigDecimal callReminder; // 来电提醒 210
    private BigDecimal callReminderRatio1; // 来电提醒佣金 210
    private BigDecimal callReminderRatio2; // 来电提醒佣金 210
    private BigDecimal callReminderRatio3; // 来电提醒佣金 210
    private Integer callReminderCount; // 来电提醒使用人数
    private BigDecimal sms; // 短信 202
    private BigDecimal smsRatio1; // 短信佣金 202
    private BigDecimal smsRatio2; // 短信佣金 202
    private BigDecimal smsRatio3; // 短信佣金 202
    private Integer smsCount; // 短信使用人数
    private BigDecimal mms; // 彩信 203
    private BigDecimal mmsRatio1; // 彩信佣金 203
    private BigDecimal mmsRatio2; // 彩信佣金 203
    private BigDecimal mmsRatio3; // 彩信佣金 203
    private Integer mmsCount; // 彩信语音包使用人数
    private String msisdn; // 手机号码
    private String mealCode; // 套餐
    
    public Integer getChannelId() {
        return channelId;
    }
    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }
    public String getChannelCode() {
        return channelCode;
    }
    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }
    public String getChannelName() {
        return channelName;
    }
    public String getChannelNameStr() {
        return "["+channelCode+"]"+channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public Integer getChannelLevel() {
        return channelLevel;
    }
    public String getChannelLevelStr() {
        if (null != channelLevel) {
            if (channelLevel.intValue() == 1) {
                return "一级渠道";
            } else if (channelLevel.intValue() == 2) {
                return "二级渠道";
            } else if (channelLevel.intValue() == 3) {
                return "三级渠道";
            }
        }
        return "";
    }
    public void setChannelLevel(Integer channelLevel) {
        this.channelLevel = channelLevel;
    }
    public BigDecimal getOverdue() {
        return overdue;
    }
    public String getOverdueYuan() {
        if(null != overdue){
            return Constant.df0.format(overdue.divide(Constant.cnt100));
        }
        return "";
    }
    public void setOverdue(BigDecimal overdue) {
        this.overdue = overdue;
    }
    public BigDecimal getLowCode() {
        return lowCode;
    }
    public String getLowCodeYuan() {
        if(null != lowCode){
            return Constant.df0.format(lowCode.divide(Constant.cnt100));
        }
        return "";
    }
    public void setLowCode(BigDecimal lowCode) {
        this.lowCode = lowCode;
    }
    public BigDecimal getVoice170() {
        return voice170;
    }
    public String getVoice170Yuan() {
        if(null != voice170){
            return Constant.df0.format(voice170.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoice170(BigDecimal voice170) {
        this.voice170 = voice170;
    }
    public BigDecimal getFlow170() {
        return flow170;
    }
    public String getFlow170Yuan() {
        if(null != flow170){
            return Constant.df0.format(flow170.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlow170(BigDecimal flow170) {
        this.flow170 = flow170;
    }
    public BigDecimal getCoolFlow() {
        return coolFlow;
    }
    public String getCoolFlowYuan() {
        if(null != coolFlow){
            return Constant.df0.format(coolFlow.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCoolFlow(BigDecimal coolFlow) {
        this.coolFlow = coolFlow;
    }
    public BigDecimal getVoiceAPP() {
        return voiceAPP;
    }
    public String getVoiceAPPYuan() {
        if(null != voiceAPP){
            return Constant.df0.format(voiceAPP.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoiceAPP(BigDecimal voiceAPP) {
        this.voiceAPP = voiceAPP;
    }
    public BigDecimal getFlowNomal() {
        return flowNomal;
    }
    public String getFlowNomalYuan() {
        if(null != flowNomal){
            return Constant.df0.format(flowNomal.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlowNomal(BigDecimal flowNomal) {
        this.flowNomal = flowNomal;
    }
    public BigDecimal getCallShow() {
        return callShow;
    }
    public String getCallShowYuan() {
        if(null != callShow){
            return Constant.df0.format(callShow.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallShow(BigDecimal callShow) {
        this.callShow = callShow;
    }
    public BigDecimal getCallReminder() {
        return callReminder;
    }
    public String getCallReminderYuan() {
        if(null != callReminder){
            return Constant.df0.format(callReminder.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallReminder(BigDecimal callReminder) {
        this.callReminder = callReminder;
    }
    public BigDecimal getSms() {
        return sms;
    }
    public String getSmsYuan() {
        if(null != sms){
            return Constant.df0.format(sms.divide(Constant.cnt100));
        }
        return "";
    }
    public void setSms(BigDecimal sms) {
        this.sms = sms;
    }
    public BigDecimal getMms() {
        return mms;
    }
    public String getMmsYuan() {
        if(null != mms){
            return Constant.df0.format(mms.divide(Constant.cnt100));
        }
        return "";
    }
    public void setMms(BigDecimal mms) {
        this.mms = mms;
    }
    
    public BigDecimal getOverdueRatio1() {
        return overdueRatio1;
    }
    public String getOverdueRatio1Yuan() {
        if(null != overdueRatio1){
            return Constant.df0.format(overdueRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setOverdueRatio1(BigDecimal overdueRatio1) {
        this.overdueRatio1 = overdueRatio1;
    }
    public BigDecimal getLowCodeRatio1() {
        return lowCodeRatio1;
    }
    public String getLowCodeRatio1Yuan() {
        if(null != lowCodeRatio1){
            return Constant.df0.format(lowCodeRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setLowCodeRatio1(BigDecimal lowCodeRatio1) {
        this.lowCodeRatio1 = lowCodeRatio1;
    }
    public BigDecimal getVoice170Ratio1() {
        return voice170Ratio1;
    }
    public String getVoice170Ratio1Yuan() {
        if(null != voice170Ratio1){
            return Constant.df0.format(voice170Ratio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoice170Ratio1(BigDecimal voice170Ratio1) {
        this.voice170Ratio1 = voice170Ratio1;
    }
    public BigDecimal getFlow170Ratio1() {
        return flow170Ratio1;
    }
    public String getFlow170Ratio1Yuan() {
        if(null != flow170Ratio1){
            return Constant.df0.format(flow170Ratio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlow170Ratio1(BigDecimal flow170Ratio1) {
        this.flow170Ratio1 = flow170Ratio1;
    }
    public BigDecimal getCoolFlowRatio1() {
        return coolFlowRatio1;
    }
    public String getCoolFlowRatio1Yuan() {
        if(null != coolFlowRatio1){
            return Constant.df0.format(coolFlowRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCoolFlowRatio1(BigDecimal coolFlowRatio1) {
        this.coolFlowRatio1 = coolFlowRatio1;
    }
    public BigDecimal getVoiceAPPRatio1() {
        return voiceAPPRatio1;
    }
    public String getVoiceAPPRatio1Yuan() {
        if(null != voiceAPPRatio1){
            return Constant.df0.format(voiceAPPRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoiceAPPRatio1(BigDecimal voiceAPPRatio1) {
        this.voiceAPPRatio1 = voiceAPPRatio1;
    }
    public BigDecimal getFlowNomalRatio1() {
        return flowNomalRatio1;
    }
    public String getFlowNomalRatio1Yuan() {
        if(null != flowNomalRatio1){
            return Constant.df0.format(flowNomalRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlowNomalRatio1(BigDecimal flowNomalRatio1) {
        this.flowNomalRatio1 = flowNomalRatio1;
    }
    public BigDecimal getCallShowRatio1() {
        return callShowRatio1;
    }
    public String getCallShowRatio1Yuan() {
        if(null != callShowRatio1){
            return Constant.df0.format(callShowRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallShowRatio1(BigDecimal callShowRatio1) {
        this.callShowRatio1 = callShowRatio1;
    }
    public BigDecimal getCallReminderRatio1() {
        return callReminderRatio1;
    }
    public String getCallReminderRatio1Yuan() {
        if(null != callReminderRatio1){
            return Constant.df0.format(callReminderRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallReminderRatio1(BigDecimal callReminderRatio1) {
        this.callReminderRatio1 = callReminderRatio1;
    }
    public BigDecimal getSmsRatio1() {
        return smsRatio1;
    }
    public String getSmsRatio1Yuan() {
        if(null != smsRatio1){
            return Constant.df0.format(smsRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setSmsRatio1(BigDecimal smsRatio1) {
        this.smsRatio1 = smsRatio1;
    }
    public BigDecimal getMmsRatio1() {
        return mmsRatio1;
    }
    public String getMmsRatio1Yuan() {
        if(null != mmsRatio1){
            return Constant.df0.format(mmsRatio1.divide(Constant.cnt100));
        }
        return "";
    }
    public void setMmsRatio1(BigDecimal mmsRatio1) {
        this.mmsRatio1 = mmsRatio1;
    }

    public BigDecimal getOverdueRatio2() {
        return overdueRatio2;
    }
    public String getOverdueRatio2Yuan() {
        if(null != overdueRatio2){
            return Constant.df0.format(overdueRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setOverdueRatio2(BigDecimal overdueRatio2) {
        this.overdueRatio2 = overdueRatio2;
    }
    public BigDecimal getLowCodeRatio2() {
        return lowCodeRatio2;
    }
    public String getLowCodeRatio2Yuan() {
        if(null != lowCodeRatio2){
            return Constant.df0.format(lowCodeRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setLowCodeRatio2(BigDecimal lowCodeRatio2) {
        this.lowCodeRatio2 = lowCodeRatio2;
    }
    public BigDecimal getVoice170Ratio2() {
        return voice170Ratio2;
    }
    public String getVoice170Ratio2Yuan() {
        if(null != voice170Ratio2){
            return Constant.df0.format(voice170Ratio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoice170Ratio2(BigDecimal voice170Ratio2) {
        this.voice170Ratio2 = voice170Ratio2;
    }
    public BigDecimal getFlow170Ratio2() {
        return flow170Ratio2;
    }
    public String getFlow170Ratio2Yuan() {
        if(null != flow170Ratio2){
            return Constant.df0.format(flow170Ratio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlow170Ratio2(BigDecimal flow170Ratio2) {
        this.flow170Ratio2 = flow170Ratio2;
    }
    public BigDecimal getCoolFlowRatio2() {
        return coolFlowRatio2;
    }
    public String getCoolFlowRatio2Yuan() {
        if(null != coolFlowRatio2){
            return Constant.df0.format(coolFlowRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCoolFlowRatio2(BigDecimal coolFlowRatio2) {
        this.coolFlowRatio2 = coolFlowRatio2;
    }
    public BigDecimal getVoiceAPPRatio2() {
        return voiceAPPRatio2;
    }
    public String getVoiceAPPRatio2Yuan() {
        if(null != voiceAPPRatio2){
            return Constant.df0.format(voiceAPPRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoiceAPPRatio2(BigDecimal voiceAPPRatio2) {
        this.voiceAPPRatio2 = voiceAPPRatio2;
    }
    public BigDecimal getFlowNomalRatio2() {
        return flowNomalRatio2;
    }
    public String getFlowNomalRatio2Yuan() {
        if(null != flowNomalRatio2){
            return Constant.df0.format(flowNomalRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlowNomalRatio2(BigDecimal flowNomalRatio2) {
        this.flowNomalRatio2 = flowNomalRatio2;
    }
    public BigDecimal getCallShowRatio2() {
        return callShowRatio2;
    }
    public String getCallShowRatio2Yuan() {
        if(null != callShowRatio2){
            return Constant.df0.format(callShowRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallShowRatio2(BigDecimal callShowRatio2) {
        this.callShowRatio2 = callShowRatio2;
    }
    public BigDecimal getCallReminderRatio2() {
        return callReminderRatio2;
    }
    public String getCallReminderRatio2Yuan() {
        if(null != callReminderRatio2){
            return Constant.df0.format(callReminderRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallReminderRatio2(BigDecimal callReminderRatio2) {
        this.callReminderRatio2 = callReminderRatio2;
    }
    public BigDecimal getSmsRatio2() {
        return smsRatio2;
    }
    public String getSmsRatio2Yuan() {
        if(null != smsRatio2){
            return Constant.df0.format(smsRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setSmsRatio2(BigDecimal smsRatio2) {
        this.smsRatio2 = smsRatio2;
    }
    public BigDecimal getMmsRatio2() {
        return mmsRatio2;
    }
    public String getMmsRatio2Yuan() {
        if(null != mmsRatio2){
            return Constant.df0.format(mmsRatio2.divide(Constant.cnt100));
        }
        return "";
    }
    public void setMmsRatio2(BigDecimal mmsRatio2) {
        this.mmsRatio2 = mmsRatio2;
    }
    
    public BigDecimal getOverdueRatio3() {
        return overdueRatio3;
    }
    public String getOverdueRatio3Yuan() {
        if(null != overdueRatio3){
            return Constant.df0.format(overdueRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setOverdueRatio3(BigDecimal overdueRatio3) {
        this.overdueRatio3 = overdueRatio3;
    }
    public BigDecimal getLowCodeRatio3() {
        return lowCodeRatio3;
    }
    public String getLowCodeRatio3Yuan() {
        if(null != lowCodeRatio3){
            return Constant.df0.format(lowCodeRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setLowCodeRatio3(BigDecimal lowCodeRatio3) {
        this.lowCodeRatio3 = lowCodeRatio3;
    }
    public BigDecimal getVoice170Ratio3() {
        return voice170Ratio3;
    }
    public String getVoice170Ratio3Yuan() {
        if(null != voice170Ratio3){
            return Constant.df0.format(voice170Ratio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoice170Ratio3(BigDecimal voice170Ratio3) {
        this.voice170Ratio3 = voice170Ratio3;
    }
    public BigDecimal getFlow170Ratio3() {
        return flow170Ratio3;
    }
    public String getFlow170Ratio3Yuan() {
        if(null != flow170Ratio3){
            return Constant.df0.format(flow170Ratio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlow170Ratio3(BigDecimal flow170Ratio3) {
        this.flow170Ratio3 = flow170Ratio3;
    }
    public BigDecimal getCoolFlowRatio3() {
        return coolFlowRatio3;
    }
    public String getCoolFlowRatio3Yuan() {
        if(null != coolFlowRatio3){
            return Constant.df0.format(coolFlowRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCoolFlowRatio3(BigDecimal coolFlowRatio3) {
        this.coolFlowRatio3 = coolFlowRatio3;
    }
    public BigDecimal getVoiceAPPRatio3() {
        return voiceAPPRatio3;
    }
    public String getVoiceAPPRatio3Yuan() {
        if(null != voiceAPPRatio3){
            return Constant.df0.format(voiceAPPRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setVoiceAPPRatio3(BigDecimal voiceAPPRatio3) {
        this.voiceAPPRatio3 = voiceAPPRatio3;
    }
    public BigDecimal getFlowNomalRatio3() {
        return flowNomalRatio3;
    }
    public String getFlowNomalRatio3Yuan() {
        if(null != flowNomalRatio3){
            return Constant.df0.format(flowNomalRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setFlowNomalRatio3(BigDecimal flowNomalRatio3) {
        this.flowNomalRatio3 = flowNomalRatio3;
    }
    public BigDecimal getCallShowRatio3() {
        return callShowRatio3;
    }
    public String getCallShowRatio3Yuan() {
        if(null != callShowRatio3){
            return Constant.df0.format(callShowRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallShowRatio3(BigDecimal callShowRatio3) {
        this.callShowRatio3 = callShowRatio3;
    }
    public BigDecimal getCallReminderRatio3() {
        return callReminderRatio3;
    }
    public String getCallReminderRatio3Yuan() {
        if(null != callReminderRatio3){
            return Constant.df0.format(callReminderRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setCallReminderRatio3(BigDecimal callReminderRatio3) {
        this.callReminderRatio3 = callReminderRatio3;
    }
    public BigDecimal getSmsRatio3() {
        return smsRatio3;
    }
    public String getSmsRatio3Yuan() {
        if(null != smsRatio3){
            return Constant.df0.format(smsRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setSmsRatio3(BigDecimal smsRatio3) {
        this.smsRatio3 = smsRatio3;
    }
    public BigDecimal getMmsRatio3() {
        return mmsRatio3;
    }
    public String getMmsRatio3Yuan() {
        if(null != mmsRatio3){
            return Constant.df0.format(mmsRatio3.divide(Constant.cnt100));
        }
        return "";
    }
    public void setMmsRatio3(BigDecimal mmsRatio3) {
        this.mmsRatio3 = mmsRatio3;
    }
    public Integer getOverdueCount() {
        return overdueCount;
    }
    public void setOverdueCount(Integer overdueCount) {
        this.overdueCount = overdueCount;
    }
    public Integer getLowCodeCount() {
        return lowCodeCount;
    }
    public void setLowCodeCount(Integer lowCodeCount) {
        this.lowCodeCount = lowCodeCount;
    }
    public Integer getVoice170Count() {
        return voice170Count;
    }
    public void setVoice170Count(Integer voice170Count) {
        this.voice170Count = voice170Count;
    }
    public Integer getFlow170Count() {
        return flow170Count;
    }
    public void setFlow170Count(Integer flow170Count) {
        this.flow170Count = flow170Count;
    }
    public Integer getCoolFlowCount() {
        return coolFlowCount;
    }
    public void setCoolFlowCount(Integer coolFlowCount) {
        this.coolFlowCount = coolFlowCount;
    }
    public Integer getVoiceAPPCount() {
        return voiceAPPCount;
    }
    public void setVoiceAPPCount(Integer voiceAPPCount) {
        this.voiceAPPCount = voiceAPPCount;
    }
    public Integer getFlowNomalCount() {
        return flowNomalCount;
    }
    public void setFlowNomalCount(Integer flowNomalCount) {
        this.flowNomalCount = flowNomalCount;
    }
    public Integer getCallShowCount() {
        return callShowCount;
    }
    public void setCallShowCount(Integer callShowCount) {
        this.callShowCount = callShowCount;
    }
    public Integer getCallReminderCount() {
        return callReminderCount;
    }
    public void setCallReminderCount(Integer callReminderCount) {
        this.callReminderCount = callReminderCount;
    }
    public Integer getSmsCount() {
        return smsCount;
    }
    public void setSmsCount(Integer smsCount) {
        this.smsCount = smsCount;
    }
    public Integer getMmsCount() {
        return mmsCount;
    }
    public void setMmsCount(Integer mmsCount) {
        this.mmsCount = mmsCount;
    }
    public String getMsisdn() {
        return msisdn;
    }
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
    public String getMealCode() {
        return mealCode;
    }
    public void setMealCode(String mealCode) {
        this.mealCode = mealCode;
    }
}
