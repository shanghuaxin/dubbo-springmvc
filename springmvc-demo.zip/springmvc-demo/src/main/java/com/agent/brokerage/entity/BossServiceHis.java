package com.agent.brokerage.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.agent.constant.Constant;

/**
 * 佣金设置表
 * @author weijialiang
 *
 */
public class BossServiceHis implements Serializable {

    private static final long serialVersionUID = -2522894431198862166L;
    
    private Integer id;                  //id
    private String bssCode; // 业务编码
    private String channel; // 渠道编码
    private String channelName; // 渠道名称
    private Date eventts; // 发生该事件的时间
    private String eventType; // 事件、动作或功能类型
    private String msisdn; // 手机号码
    private Date sttlDate; // 账期日
    private String sttlDateYm; // 账期月(YYYYMM)
    private BigDecimal totalFee; // 消费金额，单位：分
    private BigDecimal hisTotalFee; // 累计消费金额，单位：分
    private String setmeal; // 套餐
    private Integer channelId3; // 渠道ID
    private String channelCode3; // 渠道编码
    private String channelName3; // 渠道名称
    private String parentChannelCode3; // 父级渠道编码
    private BigDecimal channelMoney3; // 三级佣金，单位：分
    private BigDecimal brokerageRadio3; // 三级佣金比例
    private Integer channelId2; // 渠道ID
    private String channelCode2; // 渠道编码
    private String channelName2; // 渠道名称
    private String parentChannelCode2; // 父级渠道编码
    private BigDecimal channelMoney2; // 二级佣金，单位：分
    private BigDecimal brokerageRadio2; // 二级佣金比例
    private Integer channelId1; // 渠道ID
    private String channelCode1; // 渠道编码
    private String channelName1; // 渠道名称
    private BigDecimal channelMoney1; // 一级佣金，单位：分
    private BigDecimal brokerageRadio1; // 一级佣金比例
    private String mealCode; // 套餐编码
    private Date cTime; // 创建时间
    private Integer cnt;

    public BossServiceHis() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBssCode() {
        return bssCode;
    }

    public void setBssCode(String bssCode) {
        this.bssCode = bssCode;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Date getEventts() {
        return eventts;
    }

    public void setEventts(Date eventts) {
        this.eventts = eventts;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public Date getSttlDate() {
        return sttlDate;
    }

    public void setSttlDate(Date sttlDate) {
        this.sttlDate = sttlDate;
    }

    public String getSttlDateYm() {
        return sttlDateYm;
    }

    public void setSttlDateYm(String sttlDateYm) {
        this.sttlDateYm = sttlDateYm;
    }

    public BigDecimal getTotalFee() {
        return totalFee;
    }
    
    public String getTotalFeeYuan() {
        if(null != totalFee){
            return Constant.df0.format(totalFee.divide(Constant.cnt100));
        }
        return "0.00";
    }

    public void setTotalFee(BigDecimal totalFee) {
        this.totalFee = totalFee;
    }

    public BigDecimal getHisTotalFee() {
        return hisTotalFee;
    }

    public void setHisTotalFee(BigDecimal hisTotalFee) {
        this.hisTotalFee = hisTotalFee;
    }

    public String getSetmeal() {
        return setmeal;
    }

    public void setSetmeal(String setmeal) {
        this.setmeal = setmeal;
    }

    public Integer getChannelId3() {
        return channelId3;
    }

    public void setChannelId3(Integer channelId3) {
        this.channelId3 = channelId3;
    }

    public String getChannelCode3() {
        return channelCode3;
    }

    public void setChannelCode3(String channelCode3) {
        this.channelCode3 = channelCode3;
    }

    public String getChannelName3() {
        return channelName3;
    }

    public void setChannelName3(String channelName3) {
        this.channelName3 = channelName3;
    }

    public String getParentChannelCode3() {
        return parentChannelCode3;
    }

    public void setParentChannelCode3(String parentChannelCode3) {
        this.parentChannelCode3 = parentChannelCode3;
    }

    public BigDecimal getChannelMoney3() {
        return channelMoney3;
    }

    public void setChannelMoney3(BigDecimal channelMoney3) {
        this.channelMoney3 = channelMoney3;
    }

    public BigDecimal getBrokerageRadio3() {
        return brokerageRadio3;
    }

    public void setBrokerageRadio3(BigDecimal brokerageRadio3) {
        this.brokerageRadio3 = brokerageRadio3;
    }

    public Integer getChannelId2() {
        return channelId2;
    }

    public void setChannelId2(Integer channelId2) {
        this.channelId2 = channelId2;
    }

    public String getChannelCode2() {
        return channelCode2;
    }

    public void setChannelCode2(String channelCode2) {
        this.channelCode2 = channelCode2;
    }

    public String getChannelName2() {
        return channelName2;
    }

    public void setChannelName2(String channelName2) {
        this.channelName2 = channelName2;
    }

    public String getParentChannelCode2() {
        return parentChannelCode2;
    }

    public void setParentChannelCode2(String parentChannelCode2) {
        this.parentChannelCode2 = parentChannelCode2;
    }

    public BigDecimal getChannelMoney2() {
        return channelMoney2;
    }

    public void setChannelMoney2(BigDecimal channelMoney2) {
        this.channelMoney2 = channelMoney2;
    }

    public BigDecimal getBrokerageRadio2() {
        return brokerageRadio2;
    }

    public void setBrokerageRadio2(BigDecimal brokerageRadio2) {
        this.brokerageRadio2 = brokerageRadio2;
    }

    public Integer getChannelId1() {
        return channelId1;
    }

    public void setChannelId1(Integer channelId1) {
        this.channelId1 = channelId1;
    }

    public String getChannelCode1() {
        return channelCode1;
    }

    public void setChannelCode1(String channelCode1) {
        this.channelCode1 = channelCode1;
    }

    public String getChannelName1() {
        return channelName1;
    }

    public void setChannelName1(String channelName1) {
        this.channelName1 = channelName1;
    }

    public BigDecimal getChannelMoney1() {
        return channelMoney1;
    }
    
    public String getChannelMoney1Yuan() {
        if(null != channelMoney1){
            return Constant.df0.format(channelMoney1.divide(Constant.cnt100));
        }
        return "0.00";
    }

    public void setChannelMoney1(BigDecimal channelMoney1) {
        this.channelMoney1 = channelMoney1;
    }

    public BigDecimal getBrokerageRadio1() {
        return brokerageRadio1;
    }

    public void setBrokerageRadio1(BigDecimal brokerageRadio1) {
        this.brokerageRadio1 = brokerageRadio1;
    }

    public String getMealCode() {
        return mealCode;
    }

    public void setMealCode(String mealCode) {
        this.mealCode = mealCode;
    }

    public Date getcTime() {
        return cTime;
    }

    public void setcTime(Date cTime) {
        this.cTime = cTime;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }
}
