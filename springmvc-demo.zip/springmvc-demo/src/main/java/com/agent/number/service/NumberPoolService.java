package com.agent.number.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.common.DataTable;
import com.agent.number.dto.NumberPoolListDTO;
import com.agent.number.entity.NumberRecord;
import com.agent.number.mapper.NumberPoolMapper;
import com.agent.number.mapper.NumberRecordMapper;

@Transactional(rollbackFor=Exception.class)
@Service("numberPoolService")
public class NumberPoolService {
    @Autowired
    private NumberPoolMapper numberPoolMapper;
    @Autowired
    private NumberRecordMapper numberRecordMapper;
    
    
    
    /**
     * 号码池列表查询
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<NumberPoolListDTO> numPoolList(DataTable<NumberPoolListDTO> dt,Map<String, Object> searchParams) throws Exception{
        List<NumberPoolListDTO> list = numberPoolMapper.infoList(searchParams);
        dt.setAaData(list);
        int count = numberPoolMapper.infoCount(searchParams);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    /**
     * 号码池列表查询导出
     * @param dt
     * @param searchParams
     * @return
     */
    public List<NumberPoolListDTO> numPoolListExpor(Map<String, Object> searchParams) throws Exception{
        List<NumberPoolListDTO> list = numberPoolMapper.infoList(searchParams);
        if(null != list && list.size()>0){
            for(NumberPoolListDTO d:list){
                if(searchParams.containsKey("numStatusUS20")){
                    d.setStatus("销户待上架");
                }else{
                    d.setStatus(d.getStatusStr());
                }
            }
        }
        return list;
    }
    
    /**
     * 号码池变动记录列表查询
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<NumberRecord> numPoolListUp(DataTable<NumberRecord> dt,Map<String, Object> searchParams) throws Exception{
        List<NumberRecord> list = numberRecordMapper.list(searchParams);
        dt.setAaData(list);
        int count = numberRecordMapper.count(searchParams);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
}

