package com.agent.number.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by zw on 2015/8/25.
 */
public class ChannelDeductMoneyDTO implements Serializable {

    private static final long serialVersionUID = -4948408584391519854L;
    public static final String ACCOUNT_TYPE_OPEN = "OPEN";
    public static final String ACCOUNT_TYPE_RES = "RES";

    private Integer channelId;
    private BigDecimal openMoney;//开卡账户
    private BigDecimal resMoney;//充值账户
    private BigDecimal privMoney;//私人账户
    private BigDecimal recBre = BigDecimal.ZERO;//充值账户充值佣金
    private BigDecimal privBre = BigDecimal.ZERO;//私人账户充值佣金
    private String accountType;

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public BigDecimal getOpenMoney() {
        return openMoney;
    }

    public void setOpenMoney(BigDecimal openMoney) {
        this.openMoney = openMoney;
    }

    public BigDecimal getResMoney() {
        return resMoney;
    }

    public void setResMoney(BigDecimal resMoney) {
        this.resMoney = resMoney;
    }

    public BigDecimal getRecBre() {
        return recBre;
    }

    public void setRecBre(BigDecimal recBre) {
        this.recBre = recBre;
    }

    public BigDecimal getPrivBre() {
        return privBre;
    }

    public void setPrivBre(BigDecimal privBre) {
        this.privBre = privBre;
    }

    public BigDecimal getPrivMoney() {
        return privMoney;
    }

    public void setPrivMoney(BigDecimal privMoney) {
        this.privMoney = privMoney;
    }
}

