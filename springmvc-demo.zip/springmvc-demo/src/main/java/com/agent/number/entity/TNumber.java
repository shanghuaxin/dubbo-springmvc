package com.agent.number.entity;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.agent.common.BaseDomain;
import com.agent.common.enumeration.NumberStatus;
import com.agent.constant.Constant;
import com.agent.openaccount.entity.Check;
import com.agent.order.common.util.Utils;
import com.agent.util.DateUtil;

/**
 * 号码表
 */
public class TNumber extends BaseDomain {
    /* 待分配  ***/
    public static final String STATUS_WAIT_ALLOT = "US01";
    /* 未开户  ***/
    public static final String STATUS_WAIT_ACTIVATE = "US02";
    /* 开户待确认  ***/
    public static final String STATUS_WAIT_FINISH = "US03";
    /* 已开户  ***/
    public static final String STATUS_FINISH_ACTIVATE = "US10";
    /* 已销户  ***/
    public static final String STATUS_CANCEL = "US20";
    
    /* 待审核  ***/
    public static final String CHECK_STATUS_1= "1";
    /* 审核不通过  ***/
    public static final String CHECK_STATUS_3= "3";

    private static final long serialVersionUID = 7752145623006219560L;
    private int seq;
    private String phone;      //号码
    private String iccid;      //ICCID
    private String resInstId;      //号码实例ID
    private String uimResInstId;      //UIM实例ID
    private String imsi;       //IMSI
    private String level;      //号码级别
    private String ascription; //号码归属地
    private Integer packagesId;  //套餐id
    private Integer channelId;   //渠道id
    private String channelName;  //渠道名称
    private Integer curOpenChannelId;  //当前开户渠道，专供开户列表查询使用
    private Integer openChannelId;  //开户渠道id
    private String openChannelName; //开户渠道名称
    private Date openTime;        //开户时间
    private String openWay;  //识别方式：1-阅读识别器,2-照片识别
    private String status;        //状态：待分配：WAIT_ALLOT，待开户：WAIT_ACTIVATE，开户待确认：WAIT_FINISH，已开户：FINISH_ACTIVATE
    private BigDecimal minFloat;  //低消：单位：分
    private BigDecimal prestore;  //预存：单位：分
    private BigDecimal money;     //面额
    private BigDecimal khMoney;     //开户金额
    private BigDecimal wdMoney;     //网点扣款金额
    private Date validTime;       //有效期
    private Integer subCheckId;   //提交审核渠道id
    private String checkStatus;   //当前审核状态（1待审核，2审核通过，3审核不通过，4稽核不通过，5稽核通过，6审核中）
    private String isPre;  //是否预开户：1-是，0-否
    private Integer checkNoNum;   //开卡前审核，审核不通过次数
    private Integer operatorCode; //运营商:1-移动，2-联通，3-电信
    private String remark;//备注
    
    private BigDecimal channelMoney;     //面额(代理商对号码面额更新)
    private String openSources;  //开户来源
    private String checkOpinion; //审核描述
    private String packagesName;  //套餐名称
    private String packageNotes;//套餐描述
    private String packageMoney;//套餐价格
    private String sDate;     //开始时间
    private String eDate;     //结束时间
    private Integer applyIdentityId;    //开户申请表ID
    private Integer identityId;         //开户记录表ID
    private String channelCode;   //渠道编码
    private String bussContactPhone;   //渠道联系电话
    private String name;   //开户人姓名
    private String code;   //开户人身份证号码
    private String cardHandPic;   //手持身份证照
    private String cardFrontPic;  //正面照
    private String cardRearPic;   //背面照
    private Integer channelLevel;       //渠道级别，1：一级，2：二级，3：三级
    private String channelNameLevel1;    //归属一级渠道名称
    private String channelNameLevel2;    //归属二级渠道名称
    
    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getResInstId() {
        return resInstId;
    }

    public void setResInstId(String resInstId) {
        this.resInstId = resInstId;
    }

    public String getUimResInstId() {
        return uimResInstId;
    }

    public void setUimResInstId(String uimResInstId) {
        this.uimResInstId = uimResInstId;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getAscription() {
        return ascription;
    }

    public void setAscription(String ascription) {
        this.ascription = ascription;
    }

    public Integer getPackagesId() {
        return packagesId;
    }

    public void setPackagesId(Integer packagesId) {
        this.packagesId = packagesId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelNameStr() {
        if(Utils.isEmptyString(channelName)){
            return "总部";
        }else{
            return channelName;
        }
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getCurOpenChannelId() {
        return curOpenChannelId;
    }

    public void setCurOpenChannelId(Integer curOpenChannelId) {
        this.curOpenChannelId = curOpenChannelId;
    }

    public Integer getOpenChannelId() {
        return openChannelId;
    }

    public void setOpenChannelId(Integer openChannelId) {
        this.openChannelId = openChannelId;
    }

    public String getOpenChannelName() {
        return openChannelName;
    }

    public void setOpenChannelName(String openChannelName) {
        this.openChannelName = openChannelName;
    }

    public Date getOpenTime() {
        return openTime;
    }

    public void setOpenTime(Date openTime) {
        this.openTime = openTime;
    }
    
    public String getOpenTimeStr() {
        if(openTime == null){
            return "";
        }
        return DateUtil.getInstance().formatDate(openTime, "yyyy-MM-dd HH:mm:ss");
    }

    public String getOpenWay() {
        return openWay;
    }

    public void setOpenWay(String openWay) {
        this.openWay = openWay;
    }
    
    ////识别方式：1-阅读识别器,2-照片识别
    public String getOpenWayStr() {
        if(StringUtils.equals(openWay, "2")) {
            return "是";
        }else {
            return "否";
        }
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    //状态：待分配：WAIT_ALLOT，待开户：WAIT_ACTIVATE，开户待确认：WAIT_FINISH，已开户：FINISH_ACTIVATE
    public String getStatusStr() {
        if (null != status) {
            return NumberStatus.getName(status);
        }
        
        return status;
    }
    
    public String getCancleBtn() {
        if(StringUtils.equals(status, STATUS_WAIT_ACTIVATE) && StringUtils.equals(checkStatus, Check.audit_apply)) {
            return "1";
        }
        return "0";
    }

    public BigDecimal getMinFloat() {
        return minFloat;
    }

    public void setMinFloat(BigDecimal minFloat) {
        this.minFloat = minFloat;
    }
    
    public String getMinFloatYuan() {
        if(null != minFloat){
            return Constant.df0.format(minFloat.divide(Constant.cnt100));
        }
        return "";
    }

    public BigDecimal getPrestore() {
        return prestore;
    }

    public void setPrestore(BigDecimal prestore) {
        this.prestore = prestore;
    }
    
    public String getPrestoreYuan() {
        if(null != prestore){
            return Constant.df0.format(prestore.divide(Constant.cnt100));
        }
        return "";
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    
    public BigDecimal getKhMoney() {
        return khMoney;
    }

    public void setKhMoney(BigDecimal khMoney) {
        this.khMoney = khMoney;
    }

    public BigDecimal getWdMoney() {
        return wdMoney;
    }

    public void setWdMoney(BigDecimal wdMoney) {
        this.wdMoney = wdMoney;
    }

    public String getMoneyYuan() {
        if(null != money){
            return Constant.df0.format(money.divide(Constant.cnt100));
        }
        return "";
    }
    
    public String getKhMoneyYuan() {
        if(null != khMoney){
            return Constant.df0.format(khMoney.divide(Constant.cnt100));
        }
        return "";
    }
    
    public String getWdMoneyYuan() {
        if(null != khMoney && null != money){
            return Constant.df0.format(khMoney.subtract(money).divide(Constant.cnt100));
        }
        return "";
    }

    public String getValidTimeStr() {
        return validTime !=null ? DateUtil.getInstance().getDateStr(validTime,DateUtil.yyyy_MM_dd) : "";
    }

    public Date getValidTime() {
        return validTime;
    }

    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }

    public Integer getSubCheckId() {
        return subCheckId;
    }

    public void setSubCheckId(Integer subCheckId) {
        this.subCheckId = subCheckId;
    }

    public String getCheckStatus() {
        return checkStatus;
    }
    
    //1待审核，2审核通过，3审核不通过，4稽核不通过，5稽核通过，6审核中
    public String getCheckStatusStr() {
        if(StringUtils.equals(checkStatus, "1")) {
            return "待审核";
        }else if(StringUtils.equals(checkStatus, "2")) {
            return "审核通过";
        }else if(StringUtils.equals(checkStatus, "3")) {
            return "审核不通过";
        }else if(StringUtils.equals(checkStatus, "4")) {
            return "稽核不通过";
        }else if(StringUtils.equals(checkStatus, "5")) {
            return "稽核通过";
        }else if(StringUtils.equals(checkStatus, "6")) {
            return "审核中";
        }
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public BigDecimal getChannelMoney() {
        return channelMoney;
    }

    public void setChannelMoney(BigDecimal channelMoney) {
        this.channelMoney = channelMoney;
    }
    
    public String getChannelMoneyYuan() {
        if(null != channelMoney){
            return Constant.df0.format(channelMoney.divide(Constant.cnt100));
        }
        return "";
    }

    public String getIsPre() {
        return isPre;
    }

    public String getIsPreStr(){
        if("1".equals(isPre)){
            return "预开户";
        }else{
            return "非预开";
        }
    }

    public void setIsPre(String isPre) {
        this.isPre = isPre;
    }

    public Integer getCheckNoNum() {
        return checkNoNum;
    }

    public void setCheckNoNum(Integer checkNoNum) {
        this.checkNoNum = checkNoNum;
    }

    public String getOpenSources() {
        return openSources;
    }

    public void setOpenSources(String openSources) {
        this.openSources = openSources;
    }

    public String getCheckOpinion() {
        return checkOpinion;
    }

    public void setCheckOpinion(String checkOpinion) {
        this.checkOpinion = checkOpinion;
    }

    public String getPackagesName() {
        return packagesName;
    }

    public void setPackagesName(String packagesName) {
        this.packagesName = packagesName;
    }

    public String getPackageNotes() {
        return packageNotes;
    }

    public void setPackageNotes(String packageNotes) {
        this.packageNotes = packageNotes;
    }

    public String getPackageMoney() {
        return packageMoney;
    }

    public void setPackageMoney(String packageMoney) {
        this.packageMoney = packageMoney;
    }

    public String getsDate() {
        return sDate;
    }

    public void setsDate(String sDate) {
        this.sDate = sDate;
    }

    public String geteDate() {
        return eDate;
    }

    public void seteDate(String eDate) {
        this.eDate = eDate;
    }

    public Integer getApplyIdentityId() {
        return applyIdentityId;
    }

    public void setApplyIdentityId(Integer applyIdentityId) {
        this.applyIdentityId = applyIdentityId;
    }

    public Integer getIdentityId() {
        return identityId;
    }

    public void setIdentityId(Integer identityId) {
        this.identityId = identityId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getBussContactPhone() {
        return bussContactPhone;
    }

    public void setBussContactPhone(String bussContactPhone) {
        this.bussContactPhone = bussContactPhone;
    }
    
    

    public Integer getOperatorCode() {
        return operatorCode;
    }
    
    public String getOperatorCodeStr() {
        if(null != operatorCode){
            if(1 == operatorCode.intValue()){
                return "移动";
            }else if(2 == operatorCode.intValue()){
                return "联通";
            }else {
                return "电信";
            }
        }
        return "";
    }

    public void setOperatorCode(Integer operatorCode) {
        this.operatorCode = operatorCode;
    }
    
    public String getRemark() {
        return remark;
    }
    

    public String getRemarkShow() {
        if(!Utils.isEmptyString(remark)){
            if(remark.length() > 4){
                return remark.substring(0, 4)+"...";
            } else{
                return remark;
            }
        }
        return "";
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCardHandPic() {
        return cardHandPic;
    }

    public void setCardHandPic(String cardHandPic) {
        this.cardHandPic = cardHandPic;
    }

    public String getCardFrontPic() {
        return cardFrontPic;
    }

    public void setCardFrontPic(String cardFrontPic) {
        this.cardFrontPic = cardFrontPic;
    }

    public String getCardRearPic() {
        return cardRearPic;
    }

    public void setCardRearPic(String cardRearPic) {
        this.cardRearPic = cardRearPic;
    }
    
    public Integer getChannelLevel() {
        return channelLevel;
    }

    public void setChannelLevel(Integer channelLevel) {
        this.channelLevel = channelLevel;
    }

    public String getChannelNameLevel1() {
        return channelNameLevel1;
    }

    public void setChannelNameLevel1(String channelNameLevel1) {
        this.channelNameLevel1 = channelNameLevel1;
    }

    public String getChannelNameLevel2() {
        return channelNameLevel2;
    }

    public void setChannelNameLevel2(String channelNameLevel2) {
        this.channelNameLevel2 = channelNameLevel2;
    }

    public String getChannelNameLevel() {
        if (channelLevel == null || channelLevel == 1) {
            return "--";
        }else if (channelLevel == 2) {
            return channelNameLevel1;
        }else if (channelLevel == 3) {
            return channelNameLevel1 + " / " + channelNameLevel2;
        }
        return "";
    }

    @Override
    public String toString() {
        return "Number [phone=" + phone + ", iccid=" + iccid + ", imsi=" + imsi + ", level=" + level + ", ascription="
                + ascription + ", packagesId=" + packagesId + ", channelId=" + channelId + ", channelName="
                + channelName + ", openChannelId=" + openChannelId + ", openChannelName=" + openChannelName
                + ", openTime=" + openTime + ", status=" + status + ", minFloat=" + minFloat + ", prestore=" + prestore
                + ", money=" + money + ", validTime=" + validTime + ", subCheckId=" + subCheckId + ", isPre=" + isPre + ", checkStatus="
                + checkStatus + "，operatorCode="+operatorCode+"，remark="+remark+"]";
    }

}
