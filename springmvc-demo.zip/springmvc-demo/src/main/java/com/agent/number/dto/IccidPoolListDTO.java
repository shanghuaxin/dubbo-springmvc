package com.agent.number.dto;

import java.util.Date;

import com.agent.number.entity.IccidPool;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;

/**
 * ICCID池列表dto
 */
public class IccidPoolListDTO extends IccidPool {

    /**
     * 
     */
    private static final long serialVersionUID = 4760310462792024057L;

    private String phone;//号码
    private String ascription;//归属地
    private Integer level;//级别
    private Date ncTime;//出库时间
    
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getAscription() {
        return ascription;
    }
    public void setAscription(String ascription) {
        this.ascription = ascription;
    }
    public String getLevelStr() {
        if(null != level){
            return DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(level);   
        }
        return "";
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public String getNcTimeStr() {
        return ncTime !=null ? DateUtil.getInstance().getDateStr(ncTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public Date getNcTime() {
        return ncTime;
    }
    public void setNcTime(Date ncTime) {
        this.ncTime = ncTime;
    }
    @Override
    public String toString() {
        return "IccidPoolListDTO [phone=" + phone + ", ascription=" + ascription + ", level=" + level + ", ncTime="
                + ncTime + "]";
    }
}
