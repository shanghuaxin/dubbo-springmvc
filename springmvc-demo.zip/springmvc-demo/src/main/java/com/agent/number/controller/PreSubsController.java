package com.agent.number.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.agent.common.DataTable;
import com.agent.common.SessionData;
import com.agent.exception.SeeComException;
import com.agent.number.service.PreSubsService;
import com.agent.openaccount.entity.PreSubs;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;


/**
 * Created by Administrator on 2017/02/16
 *  * 预开户号码管理控制器
 * @author auto
 */
@Controller
@RequestMapping(value="preSubs")
public class PreSubsController {
    private static Logger logger = LoggerFactory.getLogger(PreSubsController.class);
    @Resource
    private PreSubsService preSubsService;
    
    /**
     * 进入预开户号码管理表
     * @param model
     * @return
     */
    @RequestMapping(value = "pre/list", method = RequestMethod.GET)
    public String preList(Model model) {
        return "/views/preSubs/preSubsList.jsp";
    }
    
    /**
     * 查询预开户号码管理表
     * @return
     */
    @RequestMapping(value="pre/list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<PreSubs> productList(DataTable<PreSubs> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("phone", request.getParameter("phone"));
            //searchMap.put("source",2);
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return preSubsService.preList(dt, searchMap);
        }catch(Exception e){
            logger.error("查看预开户号码失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    
    
    /**
     * 保存预开户号码
     * @param product
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="pre/save", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> preSave(@RequestParam("phone") String phone, @RequestParam("iccid") String iccid, @RequestParam("imsi") String imsi, 
            @RequestParam("advanceTime") String advanceTime, @RequestParam("servCode") String servCode, RedirectAttributes redirectAttributes,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            PreSubs pre = new PreSubs();
            pre.setPhone(phone);
            pre.setIccid(iccid);
            pre.setImsi(imsi);
            pre.setAdvanceTime(DateUtil.getInstance().parseDate(advanceTime,DateUtil.yyyy_MM_dd));
            pre.setServCode(servCode);
            pre.setPasswd("111111");
            pre.setSource(2);
            Date date = new Date();
            pre.setCreateId(us.getId());
            pre.setCreateTime(date);
            pre.setUpdateId(us.getId());
            pre.setCreateTime(date);
            preSubsService.savePre(pre, us);
            redirectAttributes.addFlashAttribute("message","标记预开户成功");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("标记预开户号码失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("标记预开户号码失败，原因：" + e.getMessage(), e);
        }
        return map;
    }
    
    /**
     * 删除预开户号码
     * @param product
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="pre/del", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> perDel(@RequestParam("phone") String phone,RedirectAttributes redirectAttributes,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            PreSubs pre = new PreSubs();
            pre.setPhone(phone.trim());
            preSubsService.delPre(pre, us);
            redirectAttributes.addFlashAttribute("message","删除预开户号码成功");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("删除预开户号码标记失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("删除预开户号码标记失败，原因：" + e.getMessage(), e);
        }
        return map;
    }
}
