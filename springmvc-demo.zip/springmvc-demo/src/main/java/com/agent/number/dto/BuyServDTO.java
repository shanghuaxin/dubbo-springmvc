package com.agent.number.dto;

import java.util.List;

/**
 * 业务办理DTO
 * @author zw
 *
 */
public class BuyServDTO {
	private String phone;//号码
	private String codes;//业务编号集合逗号隔开  a,b,c
	private List<String> codeList;//业务编号集合
	private String ids;//业务id集合逗号隔开  a,b,c
	private List<Integer> idList;//业务id集合
	private String userpwd;//服务密码
	private String certName;//订购业务号码用户
	private String certNbr;//订购业务号码身份证
	private String sourceType;//app,pc
    private String ip;

	private String oldServ;//已经订购业务id逗号隔开。顺序：融合包，流量包，语音包，来显，来电
	private String newServ;//当前订购业务id逗号隔开。顺序：融合包，流量包，语音包，来显，来电

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCodes() {
		return codes;
	}

	public void setCodes(String codes) {
		this.codes = codes;
	}
	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public List<String> getCodeList() {
		return codeList;
	}

	public void setCodeList(List<String> codeList) {
		this.codeList = codeList;
	}

	public String getCertName() {
		return certName;
	}

	public void setCertName(String certName) {
		this.certName = certName;
	}

	public String getCertNbr() {
		return certNbr;
	}

	public void setCertNbr(String certNbr) {
		this.certNbr = certNbr;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public List<Integer> getIdList() {
		return idList;
	}

	public void setIdList(List<Integer> idList) {
		this.idList = idList;
	}

	public String getOldServ() {
		return oldServ;
	}

	public void setOldServ(String oldServ) {
		this.oldServ = oldServ;
	}

	public String getNewServ() {
		return newServ;
	}

	public void setNewServ(String newServ) {
		this.newServ = newServ;
	}

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
}
