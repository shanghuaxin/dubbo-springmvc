package com.agent.number.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelsService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.SessionData;
import com.agent.constant.Constant;
import com.agent.exception.BusException;
import com.agent.number.dto.IccidPoolListDTO;
import com.agent.number.dto.NumberDTO;
import com.agent.number.dto.NumberPoolListDTO;
import com.agent.number.dto.NumberTopUpRestDTO;
import com.agent.number.entity.IccidRecord;
import com.agent.number.entity.NumberChannel;
import com.agent.number.entity.NumberRecord;
import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberMapper;
import com.agent.number.service.IccidPoolService;
import com.agent.number.service.NumberPoolService;
import com.agent.number.service.NumberService;
import com.agent.openaccount.entity.ApplyIdentity;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.service.ApplyIdentityService;
import com.agent.openaccount.service.IdentityService;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.common.util.Utils;
import com.agent.product.service.PackagesService;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.ExcelUtils;
import com.agent.util.PhoneOpenUtil;

/**
 * Created by Administrator on 2016/10/28
 *  * 号码管理控制器
 * @author auto
 */
@Controller
@RequestMapping(value="number")
public class NumberController {
    private static Logger logger = LoggerFactory.getLogger(NumberController.class);
    @Resource
    private NumberService numService;
    @Resource
    private NumberMapper numberMapper;
    @Resource
    private PackagesService pacService;
    @Resource
    private ChannelsService channelsService;
    @Resource
    private ApplyIdentityService applyIdentityService;
    @Resource
    private IdentityService identityService;
    @Resource
    private BusinessLogService businessLogService;
    @Resource
    private NumberPoolService numberPoolService;
    @Resource
    private IccidPoolService iccidPoolService;
    
    
    /**
     * 开卡审核
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    @ResponseBody
    @RequestMapping(value = "updateCardVfnList", method = RequestMethod.POST)
    public Map<String,Object> updateCardVfnList(@RequestParam("phone") String phone, @RequestParam("pass") String pass, @RequestParam("opinion") String opinion, IdcardInfo idcardinfo, HttpServletRequest request) throws Exception {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        StringBuffer logStr = new StringBuffer();
        boolean hasSuccFlag = false;
        String idNumber = null;
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        //以下是渠道主页获取渠道信息
        Channels fd = channelsService.findChannelByUserId(user.getId());
        if(fd != null && fd.getChannelType() == 2) {
            returnStr.append("当前用户网点用户，不能审核！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        /*try {
            logger.info(String.format("---开卡审核开始：审核人：%s,被审核号码：%s,审核时间：%s---", user.getNickName(), phone, DateUtil.getInstance().formatDate(new Date(), null)));
            map = numService.checkTran(phone, pass, opinion, idcardinfo, user);
            logger.info(String.format("---开卡审核完成：审核人：%s,被审核号码：%s,审核时间：%s---", user.getNickName(), phone, DateUtil.getInstance().formatDate(new Date(), null)));
        } catch (Exception e) {
            map.put("status",false);
            map.put("errorMsg", e.getMessage()) ;
            logger.error("开卡审核异常："+e.getMessage(), e);
        }
        return map;*/
        
        if(StringUtils.isBlank(phone)){
            returnStr.append("需要进行审核的号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }else{
            String operate;
            if("1".equals(pass)){// true时通过,false不通过
                RestStatus isPool = PhoneOpenUtil.isPool();//当前时间是否为出账时间，是否可以办理业务，不能办理业务走审核流程
                RestStatus isExce = PhoneOpenUtil.isExcpetion();//当前时间是否为系统异常时间，是否可以办理业务，不能办理业务走审核流程
                if(!isPool.getStatus()){
                    map.put("status",false);
                    map.put("errorMsg",isPool.getErrorMessage()+",无法进行审核操作！") ;
                    return map;
                }else if(!isExce.getStatus()){
                    map.put("status",false);
                    map.put("errorMsg",isExce.getErrorMessage()+",无法进行审核操作！") ;
                    return map;
                }
                operate="开户";
            }else{
                operate="审核不通过";
            }
            
            TNumber number;
            try {
                number = numService.findByPhone(phone);
            } catch (Exception e1) {
                logger.error("调用接口号码开户失败，原因："+e1.getMessage(),e1);
                map.put("status",false);
                map.put("errorMsg", "号码异常,无法进行审核操作！") ;
                return map;
            }
            
            Integer phoneId = number.getId();
            List<ApplyIdentity> applyIdentities = applyIdentityService.applyIdentityByPhoneId(number.getId());
            ApplyIdentity app = new ApplyIdentity();
            if(applyIdentities != null && applyIdentities.size() > 0){
                app = applyIdentities.get(0);
                
                // 审核通过时将审核时修改的身份信息更新到数据库中
                if("1".equals(pass) && idcardinfo!=null 
                        && !StringUtils.isBlank(idcardinfo.getIdNumber())
                        &&!StringUtils.isBlank(idcardinfo.getName())) {
                    if(StringUtils.isEmpty(idcardinfo.getSexual()) 
                            || "NaN".equals(idcardinfo.getSexual())) {
                        idcardinfo.setSexual("0");
                    }
                    idNumber = idcardinfo.getIdNumber();
                    //更新数据库中对应字段
                    app.setIdcardinfo(JSONUtil.objectToJson(idcardinfo));
                    app.setCode(idNumber);
                    app.setName(idcardinfo.getName());
                }
            }
            
            try{
                /**
                 * synchronized (obj) {
                 * 1.查询号码的审核状态
                 * 2.判断是否为“审核中”
                 * 3.1 如果非“审核中”状态，则修改状态
                 * 3.2如果是“审核中”状态，则直接返回错误信息
                 */
                 synchronized (this) {
                     // 1.查询号码的审核状态
                     TNumber f = numService.findById(phoneId);
                     // 2.判断是否为“审核中”
                     // 3.1如果是“审核中”、“已审核”状态，则直接返回错误信息
                     if (StringUtils.equals(f.getCheckStatus(), "6")) {
                         logger.error("号码审核失败，原因：该开户手机号("+f.getPhone()+")正在审核中");
                         returnStr.append("号码审核失败，该手机号("+f.getPhone()+")正在审核中！");
                         map.put("status",false);
                         map.put("errorMsg",returnStr) ;
                         return map;
                     }
                     if (StringUtils.equals(f.getCheckStatus(), "2") || StringUtils.equals(f.getCheckStatus(), "3")) {
                         logger.error("号码审核失败，原因：该开户手机号("+f.getPhone()+")正在审核中");
                         returnStr.append("号码审核失败，该手机号("+f.getPhone()+")已审核！");
                         map.put("status",false);
                         map.put("errorMsg",returnStr) ;
                         return map;
                     } else {
                         // 3.2 如果非“审核中”状态，则修改状态
                         numService.udpateNumCheckStatus("6", phoneId);
                     }
                 }
                 logger.info(String.format("---开卡审核开始：审核人：%s,被审核号码：%s,审核时间：%s---", user.getNickName(), phone, DateUtil.getInstance().formatDate(new Date(), null)));
                 RestStatus restStatus;
                 if(StringUtils.equals(number.getStatus(), TNumber.STATUS_WAIT_FINISH) || StringUtils.equals(number.getStatus(), TNumber.STATUS_FINISH_ACTIVATE)) {
                     List<Identity> identities = identityService.findIdentityByPhoneId(number.getId());
                     if(identities == null || identities.size() <= 0){
                         returnStr.append("号码审核失败，该手机号("+number.getPhone()+")开户信息错误！");
                         map.put("status",false);
                         map.put("errorMsg",returnStr) ;
                         return map;
                     }
                     //开卡后审核（只改变号码审核状态）
                     restStatus = numService.updateCardVfn(identities.get(0).getId(), phoneId,pass, opinion, user);
                 }else {
                     restStatus = numService.updateCardVfnList(app, phoneId,pass, opinion, user);
                 }
                 logger.info(String.format("---开卡审核完成：审核人：%s,被审核号码：%s,审核时间：%s---", user.getNickName(), phone, DateUtil.getInstance().formatDate(new Date(), null)));
                
                 if(!restStatus.getStatus()){
                     if(restStatus.getErrorMessage()!=null){
                         if("1".equals(pass)){// true时通过,false不通过
                             returnStr.append(app.getPhone()).append("开户失败！原因："+restStatus.getErrorMessage()+"</p>");
                             logStr.append(app.getPhone()).append("开户失败！原因："+restStatus.getErrorMessage()+"</p>");
                         }else{
                             returnStr.append(app.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                             logStr.append(app.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                         }
                     }else{
                         returnStr.append(app.getPhone()).append(operate).append("失败！</p>");
                         logStr.append(app.getPhone()).append(operate).append("失败！</p>");
                     }
                     map.put("status",false);
                 }else{
                     if("1".equals(pass)){//true时通过,false不通过
                         returnStr.append(app.getPhone()).append("开户成功！</p>");
                         logStr.append(app.getPhone()).append("开户成功！</p>");
                     }else{
                         returnStr.append(app.getPhone()).append("审核成功，审核结果为不通过！</p>");
                         logStr.append(app.getPhone()).append("审核成功，审核结果为不通过！</p>");
                     }
                     map.put("status",true);
                     hasSuccFlag = true;
                 }
            } catch (Exception e){
                TNumber n = numService.findById(phoneId);
                // 判断号码是否被取消，没有取消时，才需要更新号码的审核状态为1
                List<ApplyIdentity> applys = applyIdentityService.applyIdentityByPhoneId(number.getId());
                if (null==applys || applys.size()==0) {
                    n.setSubCheckId(null);
                    n.setCheckStatus(null);
                    n.setUpdateId(user.getId());
                    n.setUpdateTime(new Date());
                    numberMapper.updateCanclePhone(n);
                } else {
                    numService.udpateNumCheckStatus("1", phoneId);
                }
                
                logger.error("号码开户失败，原因："+e.getMessage(),e);
                returnStr.append(phone).append("开户失败！ </p>" + e.getMessage());
                logStr.append(phone).append("开户失败！</p>" + e.getMessage());
                map.put("status",false);
            }

            map.put("hasSuccFlag", hasSuccFlag);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
    }
    
    
    /**
     * 批量开卡审核信息
     */
    @ResponseBody
    @RequestMapping(value = "batchUpdateCardVfnList", method = RequestMethod.POST)
    public Map<String,Object> batchUpdateCardVfnList(@RequestParam("phones") String phones, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        StringBuffer returnStrSuccess = new StringBuffer();
        StringBuffer returnStrFailse = new StringBuffer();
        int m = 1, n = 1;   //m表示号码审核成功时数字标记，n 表示号码审核失败时数字标记
        StringBuffer logStr = new StringBuffer();
        String pass = "1";
        String opinion = "";
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        
        //以下是渠道主页获取渠道信息
        Channels fd = channelsService.findChannelByUserId(user.getId());
        if(fd != null && fd.getChannelType() == 2) {
            returnStr.append("当前用户网点用户，不能审核！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }

        if(StringUtils.isBlank(phones)){
            returnStr.append("需要进行审核的号码为空！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }else{
            String operate;
            if("1".equals(pass)){// true时通过,false不通过
                RestStatus isPool = PhoneOpenUtil.isPool();//当前时间是否为出账时间，是否可以办理业务，不能办理业务走审核流程
                RestStatus isExce = PhoneOpenUtil.isExcpetion();//当前时间是否为系统异常时间，是否可以办理业务，不能办理业务走审核流程
                if(!isPool.getStatus()){
                    map.put("status",false);
                    map.put("errorMsg",isPool.getErrorMessage()+",无法进行审核操作！") ;
                    return map;
                }else if(!isExce.getStatus()){
                    map.put("status",false);
                    map.put("errorMsg",isExce.getErrorMessage()+",无法进行审核操作！") ;
                    return map;
                }
                operate="开户";
            }else{
                operate="审核不通过";
            }
            
            logger.info(String.format("---开卡审核开始：审核人：%s,被审核号码：%s,审核时间：%s---", user.getNickName(), phones, DateUtil.getInstance().formatDate(new Date(), null)));
            String[] phoneArr = phones.split(",");
            for (int i = 0; i < phoneArr.length; i++) {
                TNumber number = numService.findByPhone(phoneArr[i]);
                
                Integer phoneId = number.getId();
                List<ApplyIdentity> applyIdentities = applyIdentityService.applyIdentityByPhoneId(number.getId());
                ApplyIdentity app = new ApplyIdentity();
                NumberTopUpRestDTO obj = new NumberTopUpRestDTO();
                if(applyIdentities != null && applyIdentities.size() > 0){
                    app = applyIdentities.get(0);
                    
                    obj.setMealCodes(app.getOpenMealCode());
                    obj.setPhone(app.getPhone());
                    obj.setCode(app.getCode());
                    obj.setName(app.getName());
                    obj.setMoney(String.valueOf(app.getMoney()));
                    obj.setContactPhone(app.getContactPhone());
                }
                
                
                try{
                    /**
                     * synchronized (obj) {
                     * 1.查询号码的审核状态
                     * 2.判断是否为“审核中”
                     * 3.1 如果非“审核中”状态，则修改状态
                     * 3.2如果是“审核中”状态，则直接返回错误信息
                     */
                    synchronized (this) {
                        // 1.查询号码的审核状态
                        TNumber f = numService.findById(phoneId);
                        // 2.判断是否为“审核中”
                        // 3.1如果是“审核中”、“已审核”状态，则直接返回错误信息
                        if(StringUtils.isBlank(f.getCheckStatus())){
//                          logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                            returnStrFailse.append(n + "、 号码("+f.getPhone()+")审核失败，该手机号已取消开户！<br>");
                            n++;
                            continue;
                        }else if(StringUtils.equals(f.getCheckStatus(), "6")){
//                               logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                            returnStrFailse.append(n + "、 号码("+f.getPhone()+")审核失败，该手机号正在审核中！<br>");
                            n++;
                            continue;
                        }else if(StringUtils.equals(f.getCheckStatus(), "2") || StringUtils.equals(f.getCheckStatus(), "3")){
//                               logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                            returnStrFailse.append(n + "、 号码("+f.getPhone()+")审核失败，该手机号已审核！<br>");
                            n++;
                            continue;
                        }else{
                            // 3.2 如果非“审核中”状态，则修改状态
                            numService.udpateNumCheckStatus("6", phoneId);
                        }
                    }
                    
                    RestStatus restStatus;
                    if(StringUtils.equals(number.getStatus(), TNumber.STATUS_WAIT_FINISH) || StringUtils.equals(number.getStatus(), TNumber.STATUS_FINISH_ACTIVATE)) {
                        
                        List<Identity> identities = identityService.findIdentityByPhoneId(number.getId());
                        if(identities == null || identities.size() <= 0){
                            returnStrFailse.append(n + "、 号码("+number.getPhone()+")审核失败，该手机号开户信息错误！<br>");
                            n++;
                            continue;
                        }
                        //开卡后审核（只改变号码审核状态）
                        restStatus = numService.updateCardVfn(identities.get(0).getId(), phoneId,pass, opinion, user);
                    }else {
                        restStatus = numService.updateCardVfnList(app, phoneId,pass, opinion, user);
                    }
                    
                    if(!restStatus.getStatus()){
                        if(restStatus.getErrorMessage()!=null){
                            if("1".equals(pass)){// true时通过,false不通过
                                returnStrFailse.append(n + "、 " + app.getPhone()).append("开户失败！原因："+restStatus.getErrorMessage()+"</br>");
                                logStr.append(app.getPhone()).append("开户失败！原因："+restStatus.getErrorMessage()+"</p>");
                            }else{
                                returnStrFailse.append(n + "、 " + app.getPhone()).append(restStatus.getErrorMessage()+"</br>");
                                logStr.append(app.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                            }
                        }else{
                            returnStrFailse.append(n + "、 " + app.getPhone()).append(operate).append("失败！</br>");
                            logStr.append(app.getPhone()).append(operate).append("失败！</p>");
                        }
                        n++;
                    }else{
                        if("1".equals(pass)){//true时通过,false不通过
                            returnStrSuccess.append(m + "、 " + number.getPhone()).append("开户成功！</p>");
                            logStr.append(number.getPhone()).append("开户成功！</p>");
                            m++;
                        }else{
                            returnStr.append(m + "、 " + number.getPhone()).append("审核成功，审核结果为不通过！</p>");
                            logStr.append(number.getPhone()).append("审核成功，审核结果为不通过！</p>");
                            m++;
                        }
                    }
                } catch (Exception e) {
                    TNumber n1 = numService.findById(phoneId);
                    // 判断号码是否被取消，没有取消时，才需要更新号码的审核状态为1
                    List<ApplyIdentity> applys = applyIdentityService.applyIdentityByPhoneId(number.getId());
                    if (null==applys || applys.size()==0) {
                        n1.setSubCheckId(null);
                        n1.setCheckStatus(null);
                        n1.setUpdateId(user.getId());
                        n1.setUpdateTime(new Date());
                        numberMapper.updateCanclePhone(n1);
                    } else {
                        numService.udpateNumCheckStatus("1", phoneId);
                    }
                    numService.udpateNumCheckStatus("1", phoneId);
                    
                    logger.error("号码开户失败，原因："+e.getMessage(),e);
                    returnStrFailse.append(n + "、 " + app.getPhone()).append("开户失败！ </p>" + e.getMessage()+"</br>");
                    logStr.append(app.getPhone()).append("开户失败！</p>" + e.getMessage());
                    n++;
                }
            }
            logger.info(String.format("---开卡审核完成：审核人：%s,被审核号码：%s,审核时间：%s---", user.getNickName(), phones, DateUtil.getInstance().formatDate(new Date(), null)));
            
            if(m > 1 && n > 1){
                returnStr = returnStr.append("审核成功号码：<br>").append(returnStrSuccess).append("<br>审核失败号码：<br>").append(returnStrFailse);
            }else if(m > 1 && n == 1){
                returnStr = returnStr.append("号码批量审核成功！");
            }else {
                returnStr = returnStr.append("号码批量审核失败：<br>").append(returnStrFailse);
            }
            
            map.put("status",true);
            map.put("hasSuccFlag", true);
            map.put("errorMsg",returnStr);
            return map;
        }
    }
    
    /**
     * 修改开卡稽核信息
     */
    @ResponseBody
    @RequestMapping(value = "updateCardAduitList", method = RequestMethod.POST)
    public Map<String,Object> updateCardAduitList(@RequestParam("id") Integer id, @RequestParam("pass") String pass, @RequestParam("opinion") String opinion,@RequestParam("sourceId") Integer sourceId, HttpSession session) throws Exception {

        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        try {
            RestStatus restStatus = numService.updateCardAuditList(id, pass, opinion,sourceId, user);
            if(!restStatus.getStatus()){
                map.put("status", false);
                map.put("errorMsg", restStatus.getErrorMessage());
            }else{
                map.put("status", true);
            }
        }catch (BusException e) {
            map.put("status", false);
            map.put("errorMsg", e.getMessage());
            logger.error("错误信息：{}", e);
        } catch (Exception e) {
            map.put("status", false);
            map.put("errorMsg", e.getMessage());
            logger.error("错误信息：{}", e);
        }
        return map;
    }
    
    /**
     * 开卡取消
     */
    @ResponseBody
    @RequestMapping(value = "updateCardCancle", method = RequestMethod.POST)
    public Map<String,Object> updateCardCancle(@RequestParam("id") Integer id, @RequestParam("sourceId") Integer sourceId, HttpSession session) throws Exception {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            returnStr.append("session过期！");
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            return map;
        }
        try {
            RestStatus restStatus = numService.updateCardCancle(id, sourceId, user);
            if(!restStatus.getStatus()){
                map.put("status", false);
                map.put("errorMsg", restStatus.getErrorMessage());
            }else{
                map.put("status", true);
            }
        }catch (BusException e) {
            map.put("status", false);
            map.put("errorMsg", e.getMessage());
            logger.error("错误信息：{}", e);
        } catch (Exception e) {
            map.put("status", false);
            map.put("errorMsg", e.getMessage());
            logger.error("错误信息：{}", e);
        }
        return map;
    }
    

    /**
     * 库存模块 号码详情列表
     * @param model
     * @return
     */
    @RequestMapping(value = "stock-phone-info", method = RequestMethod.GET)
    public String phoneInfo(Model model, HttpServletRequest request) {
        try{
            model.addAttribute("phoneLevel", DicUtil.getDictionary("PHONE_LEVEL_CODE"));
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("servType", "0");
            model.addAttribute("pacList", pacService.pacList(searchMap));
            String channelId = Utils.isEmptyString(request.getParameter("channelId")) ? "" : request.getParameter("channelId");
            model.addAttribute("channelId", channelId);
            String allChannelId = Utils.isEmptyString(request.getParameter("allChannelId")) ? "" : request.getParameter("allChannelId");
            model.addAttribute("allChannelId", allChannelId);
            String stockType = Utils.isEmptyString(request.getParameter("stockType")) ? "" : request.getParameter("stockType") ;
            model.addAttribute("stockType",stockType);
            String isOpen = Utils.isEmptyString(request.getParameter("isOpen")) ? "" : request.getParameter("isOpen") ;
            model.addAttribute("isOpen",isOpen);
            String isCgUser = Utils.isEmptyString(request.getParameter("isCgUser")) ? "" : request.getParameter("isCgUser") ;
            model.addAttribute("isCgUser",isCgUser);
            String isPre = Utils.isEmptyString(request.getParameter("isPre")) ? "" : request.getParameter("isPre") ;
            model.addAttribute("isPre",isPre);
            String channelLevel = Utils.isEmptyString(request.getParameter("channelLevel")) ? "" : request.getParameter("channelLevel") ;
            String channelLevel1Id = Utils.isEmptyString(request.getParameter("channelLevel1Id")) ? "" : request.getParameter("channelLevel1Id");
            String channelLevel2Id = Utils.isEmptyString(request.getParameter("channelLevel2Id")) ? "" : request.getParameter("channelLevel2Id");
            //if ("0".equals(String.valueOf(request.getParameter("isOpen")))){//查询非开户号码详情
                model.addAttribute("channelLevel", channelLevel);
            //}
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            Channels queryCh = new Channels();
            if(!Utils.isEmptyString(allChannelId)){
                queryCh = channelsService.findById(Integer.valueOf(allChannelId));
            }else{
                queryCh.setChannelLevel(0);//默认为0，方便判断
            }
            if(null == ch){
                model.addAttribute("isCg", "0");
            }else{
                model.addAttribute("isCg", "1");
            }
            String parUrl = "";//导航上一个页面路径
            String parName = "";//导航上一个页面名称
            if(Utils.isEmptyString(allChannelId) || "0".equals(allChannelId)){
                if(null == ch){
                    parUrl = "stock-cnt-phone?isCgUser="+isCgUser;
                    parName = "总部";
                }else{
                    parUrl = "stock-cnt-phone";
                    parName = "我的";
                }
            }else if("1".equals(channelLevel) || Channels.CHANNEL_LEVEL_1.intValue() == queryCh.getChannelLevel().intValue()){
                if(null == ch){//总部查询一级库存详情
                    parUrl = "stock-channel-phone?isCgUser="+isCgUser+"&channelLevel=1&isPre="+isPre;
                    parName = "一级";
                }else if(null != ch && null != allChannelId && ch.getId().intValue() == Integer.valueOf(allChannelId).intValue()){ //代理商登录，并查看自己详情
                    parUrl = "stock-ch-me?channelLevel=1&dataType=2";
                    parName = "我的";
                }
            }else if("2".equals(channelLevel)|| Channels.CHANNEL_LEVEL_2.intValue() == queryCh.getChannelLevel().intValue()){
                if(null == ch){//总部查询二级库存详情
                    parUrl = "stock-channel-phone?isCgUser="+isCgUser+"&allChannelId="+allChannelId+"&channelLevel1Id="+channelLevel1Id+"&channelLevel=2&isPre="+isPre;
                    parName = "二级";
                }else if(null != ch && null != channelId && ch.getId().intValue() == Integer.valueOf(allChannelId).intValue()){ //代理商登录，并查看自己详情
                    if(Channels.CHANNEL_TYPE_1.intValue() == ch.getChannelType()){
                        parUrl = "stock-ch-me?channelLevel=2&dataType=2";
                    }else{
                        parUrl = "stock-ch-me?channelLevel=3&dataType=2";
                    }
                    parName = "我的";
                }else{
                    //代理商查询二级详情
                    parUrl = "stock-channel-phone?isCgUser="+isCgUser+"&channelLevel=2&channelLevel1Id="+channelLevel1Id;
                    parName = "二级";
                }
            }else if("3".equals(channelLevel)|| Channels.CHANNEL_LEVEL_3.intValue() == queryCh.getChannelLevel().intValue()){
                if(null == ch){//总部查询二级库存详情
                    parUrl = "stock-channel-phone?isCgUser="+isCgUser+"&allChannelId="+allChannelId+"&channelLevel1Id="+channelLevel1Id+"&channelLevel2Id="+channelLevel2Id+"&channelLevel=3&isPre="+isPre;
                    parName = "三级";
                }else if(null != ch && null != channelId && ch.getId().intValue() == Integer.valueOf(allChannelId).intValue()){ //代理商登录，并查看自己详情
                    parUrl = "stock-ch-me?channelLevel=3&dataType=2";
                    parName = "我的";
                }else{
                    //代理商查看三级详情
                    parUrl = "stock-channel-phone?isCgUser="+isCgUser+"&channelLevel=3&channelLevel1Id="+channelLevel1Id+"&channelLevel2Id="+channelLevel2Id;
                    parName = "三级";
                }
            }
            model.addAttribute("parUrl", parUrl);
            model.addAttribute("parName", parName);
        }catch (Exception e){
            logger.error("进入库存号码详情异常，error"+e.getMessage(),e);
        }
        return "/views/stock/stockPhoneInfo.jsp";
    }

    /**
     * 库存模块 号码详情
     * @return
     */
    @RequestMapping(value = "stock-phone-info", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<NumberDTO> phoneInfo(DataTable<NumberDTO> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("channelType", Utils.isEmptyString(request.getParameter("channelType")) ? "" : request.getParameter("channelType"));
            searchMap.put("operatorCode", Utils.isEmptyString(request.getParameter("operatorCode")) ? "" : request.getParameter("operatorCode"));
            if(!Utils.isEmptyString(request.getParameter("startMoney")))
                searchMap.put("startMoney", Integer.valueOf(request.getParameter("startMoney"))*100);
            if(!Utils.isEmptyString(request.getParameter("endMoney")))
                searchMap.put("endMoney", Integer.valueOf(request.getParameter("endMoney"))*100);
            if(!Utils.isEmptyString(request.getParameter("startMinFloat")))
                searchMap.put("startMinFloat", Integer.valueOf(request.getParameter("startMinFloat"))*100);
            if(!Utils.isEmptyString(request.getParameter("endMinFloat")))
                searchMap.put("endMinFloat", Integer.valueOf(request.getParameter("endMinFloat"))*100);
            searchMap.put("likeRemark", Utils.isEmptyString(request.getParameter("likeRemark")) ? "" : request.getParameter("likeRemark"));
            
            searchMap.put("channelId", Utils.isEmptyString(request.getParameter("channelId")) ? "" : request.getParameter("channelId"));
            searchMap.put("startPhone", Utils.isEmptyString(request.getParameter("startPhone")) ? "" : request.getParameter("startPhone"));
            searchMap.put("endPhone", Utils.isEmptyString(request.getParameter("endPhone")) ? "" : request.getParameter("endPhone"));
            searchMap.put("startdate", Utils.isEmptyString(request.getParameter("startdate")) ? "" : request.getParameter("startdate"));
            searchMap.put("enddate", Utils.isEmptyString(request.getParameter("enddate")) ? "" : request.getParameter("enddate"));
            String levels = Utils.isEmptyString(request.getParameter("levels")) ? "" : request.getParameter("levels");
            if(!Utils.isEmptyString(levels)){
                String[] le = levels.split(",");
                if(le.length >0){
                    List<String> list = new ArrayList<String>();
                    for(int i=0;i<le.length;i++){
                        if(!Utils.isEmptyString(le[i])){
                            list.add(le[i]);
                        }
                    }
                    if(list.size() >0){
                        searchMap.put("levels",list);
                    }
                }
            }

            searchMap.put("packagesId", Utils.isEmptyString(request.getParameter("packagesId")) ? "" : request.getParameter("packagesId"));
            String status =  Utils.isEmptyString(request.getParameter("status")) ? "" : request.getParameter("status");
            String isOpen = Utils.isEmptyString(request.getParameter("isOpen")) ? "" : request.getParameter("isOpen");//是否查开户  0-否，1-是
            if(Utils.isEmptyString(status)){
                //只判断查询非开户，不查库存查开户会有默认状态
               if("0".equals(isOpen)){
                   List<String> list = new ArrayList<String>();
                   list.add(TNumber.STATUS_WAIT_ALLOT);
                   list.add(TNumber.STATUS_WAIT_ACTIVATE);
                   searchMap.put("statusList",list);
               }
            }else{
                if("FINISH".equals(status)){
                    List<String> list = new ArrayList<String>();
                    list.add(TNumber.STATUS_WAIT_FINISH);
                    list.add(TNumber.STATUS_FINISH_ACTIVATE);
                    list.add(TNumber.STATUS_CANCEL);
                    searchMap.put("statusList",list);
                }else{
                    searchMap.put("status",status);
                }
            }

            searchMap.put("phoneLike", Utils.isEmptyString(request.getParameter("phoneLike")) ? "" : request.getParameter("phoneLike"));
            searchMap.put("iccidLike", Utils.isEmptyString(request.getParameter("iccidLike")) ? "" : request.getParameter("iccidLike"));
            searchMap.put("cityLike", Utils.isEmptyString(request.getParameter("cityLike")) ? "" : request.getParameter("cityLike"));
            searchMap.put("channelName", Utils.isEmptyString(request.getParameter("channelName")) ? "" : request.getParameter("channelName"));
            if(Utils.isEmptyString(status)){
                searchMap.put("channelLevel", Utils.isEmptyString(request.getParameter("channelLevel")) ? "" : request.getParameter("channelLevel"));
            }
            searchMap.put("allChannelId", Utils.isEmptyString(request.getParameter("allChannelId")) ? "0" : Integer.valueOf(request.getParameter("allChannelId")));
            searchMap.put("isPre", Utils.isEmptyString(request.getParameter("isPre")) ? "" : request.getParameter("isPre"));
            searchMap.put("limit",dt.getiDisplayStart());
            String pageNum= request.getParameter("pageNum");
            if(!Utils.isEmptyString(pageNum)){
                Integer pageNumInt = Integer.parseInt(pageNum);
                searchMap.put("limit",(pageNumInt-1)*dt.getiDisplayLength());
            }
            searchMap.put("pageSize",dt.getiDisplayLength());
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            if("3".equals(String.valueOf(request.getParameter("channelLevel"))) && 
                    ("1".equals(isOpen) || "FINISH".equals(status))){ //网点查询已开户数据
                searchMap.put("openChannelId",searchMap.get("allChannelId"));
                searchMap.put("allChannelId", "0");
            }
            if (!"0".equals(String.valueOf(request.getParameter("isOpen")))){//查询非开户号码详情
                searchMap.put("channelLevel", "");
            }
            if(null != ch && Channels.CHANNEL_TYPE_2.intValue() == ch.getChannelType().intValue()){
                if("FINISH".equals(status)){
                    searchMap.put("openChannelId",searchMap.get("allChannelId"));
                    searchMap.put("allChannelId", "0");
                }else if("".equals(status)){
                    searchMap.put("statusAll",searchMap.get("allChannelId"));
                    searchMap.put("allChannelId", "0");
                }
            }
            
            dt = numService.numPreList(dt,searchMap,ch);
        }catch (Exception ex){
            logger.error("查询号码明细异常：原因："+ ex.getMessage(),ex);
        }
        return dt;
    }


    /**
     * 号码详情导出
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @RequestMapping(value = "stock-phone-info-expor", method = RequestMethod.GET)
    public void phoneInfoExpor(DataTable<NumberDTO> dt,HttpServletResponse response,HttpServletRequest request){
        OutputStream out = null;
        List listExport = null;
        try{
            Map<String,Object> searchMap = new HashMap();
            searchMap.put("channelType", Utils.isEmptyString(request.getParameter("channelType")) ? "" : request.getParameter("channelType"));
            searchMap.put("operatorCode", Utils.isEmptyString(request.getParameter("operatorCode")) ? "" : request.getParameter("operatorCode"));
            if(!Utils.isEmptyString(request.getParameter("startMoney")))
                searchMap.put("startMoney", Integer.valueOf(request.getParameter("startMoney"))*100);
            if(!Utils.isEmptyString(request.getParameter("endMoney")))
                searchMap.put("endMoney", Integer.valueOf(request.getParameter("endMoney"))*100);
            if(!Utils.isEmptyString(request.getParameter("startMinFloat")))
                searchMap.put("startMinFloat", Integer.valueOf(request.getParameter("startMinFloat"))*100);
            if(!Utils.isEmptyString(request.getParameter("endMinFloat")))
                searchMap.put("endMinFloat", Integer.valueOf(request.getParameter("endMinFloat"))*100);
            searchMap.put("likeRemark", Utils.isEmptyString(request.getParameter("likeRemark")) ? "" : request.getParameter("likeRemark"));
            
            searchMap.put("phoneLike", Utils.isEmptyString(request.getParameter("phoneLike")) ? "" : request.getParameter("phoneLike"));
            searchMap.put("iccidLike", Utils.isEmptyString(request.getParameter("iccidLike")) ? "" : request.getParameter("iccidLike"));
            searchMap.put("channelId", Utils.isEmptyString(request.getParameter("channelId")) ? "" : request.getParameter("channelId"));
            searchMap.put("startPhone", Utils.isEmptyString(request.getParameter("startPhone")) ? "" : request.getParameter("startPhone"));
            searchMap.put("endPhone", Utils.isEmptyString(request.getParameter("endPhone")) ? "" : request.getParameter("endPhone"));
            searchMap.put("startdate", Utils.isEmptyString(request.getParameter("startdate")) ? "" : request.getParameter("startdate"));
            searchMap.put("enddate", Utils.isEmptyString(request.getParameter("enddate")) ? "" : request.getParameter("enddate"));
            String levels = Utils.isEmptyString(request.getParameter("levels")) ? "" : request.getParameter("levels");
            if(!Utils.isEmptyString(levels)){
                String[] le = levels.split(",");
                if(le.length >0){
                    List<String> list = new ArrayList<String>();
                    for(int i=0;i<le.length;i++){
                        if(!Utils.isEmptyString(le[i])){
                            list.add(le[i]);
                        }
                    }
                    if(list.size() >0){
                        searchMap.put("levels",list);
                    }
                }
            }

            searchMap.put("packagesId", Utils.isEmptyString(request.getParameter("packagesId")) ? "" : request.getParameter("packagesId"));
            String status =  Utils.isEmptyString(request.getParameter("status")) ? "" : request.getParameter("status");
            String isOpen = Utils.isEmptyString(request.getParameter("isOpen")) ? "" : request.getParameter("isOpen");//是否查开户  0-否，1-是
            if(Utils.isEmptyString(status)){
                //只判断查询非开户，不查库存查开户会有默认状态
                if("0".equals(isOpen)){
                    List<String> list = new ArrayList<String>();
                    list.add(TNumber.STATUS_WAIT_ALLOT);
                    list.add(TNumber.STATUS_WAIT_ACTIVATE);
                    searchMap.put("statusList",list);
                }
            }else{
                if("FINISH".equals(status)){
                    List<String> list = new ArrayList<String>();
                    list.add(TNumber.STATUS_WAIT_FINISH);
                    list.add(TNumber.STATUS_FINISH_ACTIVATE);
                    list.add(TNumber.STATUS_CANCEL);
                    searchMap.put("statusList",list);
                }else{
                    searchMap.put("status",status);
                }
            }

            searchMap.put("cityLike", Utils.isEmptyString(request.getParameter("cityLike")) ? "" : URLDecoder.decode(request.getParameter("cityLike"), "UTF-8"));
            searchMap.put("channelName", Utils.isEmptyString(request.getParameter("channelName")) ? "" : URLDecoder.decode(request.getParameter("channelName"), "UTF-8"));
            if(Utils.isEmptyString(status)){
                searchMap.put("channelLevel", Utils.isEmptyString(request.getParameter("channelLevel")) ? "" : request.getParameter("channelLevel"));
            }
            searchMap.put("allChannelId", Utils.isEmptyString(request.getParameter("allChannelId")) ? "0" : Integer.valueOf(request.getParameter("allChannelId")));
            searchMap.put("isPre", Utils.isEmptyString(request.getParameter("isPre")) ? "" : request.getParameter("isPre"));
            /*Integer startCnt = Integer.valueOf(request.getParameter("startCnt"));
            Integer endCnt = Integer.valueOf(request.getParameter("endCnt"));*/
            searchMap.put("limit",0);
            searchMap.put("pageSize",60000);
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            if("3".equals(String.valueOf(request.getParameter("channelLevel"))) && 
                    ("1".equals(isOpen) || "FINISH".equals(status))){ //网点查询已开户数据
                searchMap.put("openChannelId",searchMap.get("allChannelId"));
                searchMap.put("allChannelId", "0");
            }
            if (!"0".equals(String.valueOf(request.getParameter("isOpen")))){//查询非开户号码详情
                searchMap.put("channelLevel", "");
            }
            if(null != ch && Channels.CHANNEL_TYPE_2.intValue() == ch.getChannelType().intValue()){
                if("FINISH".equals(status)){
                    searchMap.put("openChannelId",searchMap.get("allChannelId"));
                    searchMap.put("allChannelId", "0");
                }else if("".equals(status)){
                    searchMap.put("statusAll",searchMap.get("allChannelId"));
                    searchMap.put("allChannelId", "0");
                }
            }
            dt = numService.numPreListExpor(dt,searchMap,ch);

            listExport = dt.getAaData();
            String downloadName = "170号码信息";
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
                //网点登录
            if(null != ch && Channels.CHANNEL_TYPE_2.intValue() == ch.getChannelType().intValue()){
                headers = new String[]{"手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期"};
                properties = new String[]{"phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr"};
            }else if(null != ch){
                //其他查询库存详情
                headers = new String[]{"当前渠道编码","当前渠道","渠道属性","二级渠道","一级渠道","手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期"};
                properties = new String[]{"channelCode","channelNameStr","channelLevelStr","channelPar2Name","channelPar1Name","phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr"};
            }else{
                //其他查询库存详情
                headers = new String[]{"当前渠道编码","当前渠道","渠道属性","二级渠道","一级渠道","手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期","是否预开"};
                properties = new String[]{"channelCode","channelNameStr","channelLevelStr","channelPar2Name","channelPar1Name","phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr","isPreStr"};
            }
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            out = response.getOutputStream();
            util.exportExcel(out,headers,listExport,properties);
        }catch (Exception ex){
            logger.error("号码详情导出异常：原因："+ ex.getMessage(),ex);
        } finally {
            dt = null;
            listExport = null;
            if (null != out) {
                try {
                    out.close();
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }
                out = null;
            }
        }
    }
    
    
    /**
     * 号码批量操作
     *
     * @param ids
     * @param type
     * @param optionVal
     * @return
     */
    @RequestMapping(value = "batch-option", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus batchOption(@RequestParam("parIds") String parIds, @RequestParam("optionType") String type, 
            @RequestParam("optionVal") String optionVal,HttpServletRequest request) throws Exception {
        RestStatus rs = new RestStatus(Boolean.TRUE, "200", "操作成功！");
        String optionType = "分配渠道"; //type:1-分配渠道，2-回收，3-备注
        try {
            User us = SessionData.getInstance().getUser(request);
            List<Integer> ids = Utils.listStrByint(parIds);
            if(ids.size() <=0){
                return rs = new RestStatus(Boolean.FALSE, "500", "输入ids参数错误，请联系管理员！");
            }
            if ("1".equals(type)) {
                if(Utils.isEmptyString(optionVal)){
                    return rs = new RestStatus(Boolean.FALSE, "500", "号码批量分配渠道，编号不能为空");
                }
                optionType = "分配渠道";
                rs = numService.batchAllot(ids, us, optionVal);
            } else if ("2".equals(type)) {
                optionType = "回收";
                rs = numService.batchCallback(ids, us);
            }else if ("3".equals(type)) {
                if(Utils.isEmptyString(optionVal)){
                    return rs = new RestStatus(Boolean.FALSE, "500", "号码批量备注，备注信息不能为空");
                }
                optionType = "备注";
                rs = numService.batchRemark(ids, us, optionVal);
            }
        } catch (Exception e) {
            logger.error("号码批量操作"+optionType+"异常，错误信息：{}", e);
            return rs = new RestStatus(Boolean.FALSE, "500", "操作失败！");
        }
        return rs;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * 库存模块 号码库存信息
     * @param model
     * @return
     */
    @RequestMapping(value = "stock-sum-phone", method = RequestMethod.GET)
    public String stockSumPhone(Model model, HttpServletRequest request) {
        String url = "/views/stock/stockSumPhone.jsp";
        try {
            model.addAttribute("isHome",request.getParameter("isHome"));//是否主页进入  1-是
            model.addAttribute("phoneLevel", DicUtil.getDictionary("PHONE_LEVEL_CODE"));
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("servType", "0");
            model.addAttribute("pacList", pacService.pacList(searchMap));
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            String isLogin = request.getParameter("isLogin");//1-我的库存
            if(null == ch){
                searchMap.put("userLevel", 0);
                model.addAttribute("userLevel", 0);
            }else if(1 == ch.getChannelLevel()){
                searchMap.put("userLevel", 1);
                model.addAttribute("userLevel", 1);
                if("1".equals(isLogin)){
                    model.addAttribute("nameOrCode", ch.getChannelCode());
                }
            }else if(2 == ch.getChannelLevel() && 1 == ch.getChannelType()){
                searchMap.put("userLevel", 2);
                model.addAttribute("userLevel", 2);
                if("1".equals(isLogin)){
                    model.addAttribute("nameOrCode", ch.getChannelCode());
                }
            }else{
                searchMap.put("userLevel", 3);
                model.addAttribute("userLevel", 3);
                if("1".equals(isLogin)){
                    model.addAttribute("nameOrCode", ch.getChannelCode());
                }
            }
            
            String allChannelCode = request.getParameter("allChannelCode");
            if(!Utils.isEmptyString(allChannelCode)){
                Channels allCh = channelsService.findByCode(allChannelCode);
                if(allCh.getChannelType() == 2){
                    model.addAttribute("nameOrCode", request.getParameter("allChannelCode"));
                }else{
                    model.addAttribute("allChannelCode", request.getParameter("allChannelCode"));
                }
                
            }
            if(!Utils.isEmptyString(request.getParameter("nameOrCode"))){
                model.addAttribute("nameOrCode", request.getParameter("nameOrCode"));
            }
            if(!Utils.isEmptyString(request.getParameter("isOpen"))){
                url = "/views/stock/stockSumPhoneOpen.jsp";
            }
            model.addAttribute("isOpen", request.getParameter("isOpen"));
            model.addAttribute("isCh", request.getParameter("isCh"));
            model.addAttribute("channelLevel", request.getParameter("chLevel"));
            model.addAttribute("channelType", request.getParameter("chType"));
        }catch (Exception e){
            logger.error("进入库存号码详情异常，error"+e.getMessage(),e);
        }
        return url;
    }
    
    /**
     * 库存统计号码详情
     * @param model
     * @param request
     * @return
     */
    @RequestMapping(value="stock-phone-list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<NumberDTO> stockPhoneList(DataTable<NumberDTO> dt, HttpServletRequest request){
        try{
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            Map<String,Object> searchMap = searchListMap(request,ch);
            searchMap.put("limit", dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return numService.stockPhoneList(dt,searchMap,ch);
        }catch(Exception e){
            logger.error("查看一二级库存统计失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    
    
    /**
     * 号码详情导出
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @RequestMapping(value = "stock-phone-list-expor", method = RequestMethod.GET)
    public void stockPhoneListExpor(DataTable<NumberDTO> dt,HttpServletResponse response,HttpServletRequest request){
        OutputStream out = null;
        List listExport = null;
        try{
            Channels ch = channelsService.findChannelByUserId(SessionData.getInstance().getUser(request).getId());
            Map<String,Object> searchMap = searchListMap(request,ch);
            searchMap.put("limit", 0);
            searchMap.put("pageSize",50000);
            dt = numService.stockPhoneListExport(dt,searchMap,ch);

            listExport = dt.getAaData();
            String downloadName = "170号码信息";
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            if(searchMap.containsKey("isOpen") && "1".equals(searchMap.get("isOpen"))){
                //网点登录
                if(null != ch && Channels.CHANNEL_TYPE_2.intValue() == ch.getChannelType().intValue()){
                    headers = new String[]{"手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期","开户时间"};
                    properties = new String[]{"phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr","openTimeStr"};
                }else if(null != ch){
                    //其他查询库存详情
                    headers = new String[]{"当前渠道编码","当前渠道","渠道属性","二级渠道","一级渠道","手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期","开户时间"};
                    properties = new String[]{"channelCode","channelNameStr","channelLevelStr","channelPar2Name","channelPar1Name","phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr","openTimeStr"};
                }else{
                    //其他查询库存详情
                    headers = new String[]{"当前渠道编码","当前渠道","渠道属性","二级渠道","一级渠道","手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期","是否预开","开户时间"};
                    properties = new String[]{"channelCode","channelNameStr","channelLevelStr","channelPar2Name","channelPar1Name","phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr","isPreStr","openTimeStr"};
                }
            }else{
              //网点登录
                if(null != ch && Channels.CHANNEL_TYPE_2.intValue() == ch.getChannelType().intValue()){
                    headers = new String[]{"手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期"};
                    properties = new String[]{"phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr"};
                }else if(null != ch){
                    //其他查询库存详情
                    headers = new String[]{"当前渠道编码","当前渠道","渠道属性","二级渠道","一级渠道","手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期"};
                    properties = new String[]{"channelCode","channelNameStr","channelLevelStr","channelPar2Name","channelPar1Name","phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr"};
                }else{
                    //其他查询库存详情
                    headers = new String[]{"当前渠道编码","当前渠道","渠道属性","二级渠道","一级渠道","手机号码","ICCID号","号码级别","套餐","号码低消","面值","归属地","状态","有效期","是否预开"};
                    properties = new String[]{"channelCode","channelNameStr","channelLevelStr","channelPar2Name","channelPar1Name","phone","iccid","level","packName","minFloatYuan","ncMoneyYuan","ascription","status","validTimeStr","isPreStr"};
                }
            }
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            out = response.getOutputStream();
            util.exportExcel(out,headers,listExport,properties);
        }catch (Exception ex){
            logger.error("号码详情导出异常：原因："+ ex.getMessage(),ex);
        } finally {
            dt = null;
            listExport = null;
            if (null != out) {
                try {
                    out.close();
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }
                out = null;
            }
        }
    }
    
    /**
     * 号码池查询条件组装
     * @param dt
     * @param request
     * @param ch
     * @return
     * @throws Exception
     */
    private Map<String,Object> searchListMap(HttpServletRequest request,Channels ch) throws Exception{
        Map<String,Object> searchMap = new HashMap<String,Object>();
        String allChannelCode = request.getParameter("allChannelCode");
        Channels allCh = null;
        if(!Utils.isEmptyString(allChannelCode)){
            allCh = channelsService.findByCode(allChannelCode);
            if(null == allCh){
                searchMap.put("id", "0");//输入上级编号没有查询到渠道
            }
        }
        String parChCode = request.getParameter("parChCode");
        Channels parCh = null;
        if(!Utils.isEmptyString(parChCode)){
            parCh = channelsService.findByCode(parChCode);
            if(null == parCh){
                searchMap.put("id", "0");//输入上级编号没有查询到渠道
            }else{
                searchMap.put("parChId", parCh.getId());
            }
        }
        searchMap.put("startPhone", request.getParameter("startPhone"));
        searchMap.put("endPhone", request.getParameter("endPhone"));;
        searchMap.put("iccidLike", request.getParameter("iccidLike"));
        searchMap.put("nameOrCode", request.getParameter("nameOrCode"));
        searchMap.put("channelLevel", request.getParameter("channelLevel"));
        searchMap.put("channelType", request.getParameter("channelType"));
        searchMap.put("operatorCode", request.getParameter("operatorCode"));
        searchMap.put("levels", request.getParameter("levels"));
        if(!Utils.isEmptyString(request.getParameter("startMoney"))){
            searchMap.put("startMoney", Integer.valueOf(request.getParameter("startMoney"))*100);
        }
        if(!Utils.isEmptyString(request.getParameter("endMoney")) && "0".equals(request.getParameter("endMoney"))){
            searchMap.put("endMoney", 100);
        }else if(!Utils.isEmptyString(request.getParameter("endMoney"))){
            searchMap.put("endMoney", Integer.valueOf(request.getParameter("endMoney"))*100);
        }
        if(!Utils.isEmptyString(request.getParameter("startMinFloat"))){
            searchMap.put("startMinFloat", Integer.valueOf(request.getParameter("startMinFloat"))*100);
        }
        if(!Utils.isEmptyString(request.getParameter("endMinFloat")) && "0".equals(request.getParameter("endMinFloat"))){
            searchMap.put("endMinFloat", 100);
        }else if(!Utils.isEmptyString(request.getParameter("endMinFloat"))){
            searchMap.put("endMinFloat", Integer.valueOf(request.getParameter("endMinFloat"))*100);
        }
        searchMap.put("cityLike", Utils.isEmptyString(request.getParameter("cityLike")) ? null : request.getParameter("cityLike"));
        searchMap.put("startdate", Utils.isEmptyString(request.getParameter("startdate")) ? null : request.getParameter("startdate")+" 00:00:00");
        searchMap.put("enddate", Utils.isEmptyString(request.getParameter("enddate")) ? null : request.getParameter("enddate")+" 23:59:59");
        searchMap.put("openStartdate", Utils.isEmptyString(request.getParameter("openStartdate")) ? null : request.getParameter("openStartdate")+" 00:00:00");
        searchMap.put("openEnddate", Utils.isEmptyString(request.getParameter("openEnddate")) ? null : request.getParameter("openEnddate")+" 23:59:59");
        searchMap.put("likeRemark", request.getParameter("likeRemark"));
        searchMap.put("isPre", request.getParameter("isPre"));
        searchMap.put("packagesId", request.getParameter("packagesId"));
        String isOpen = request.getParameter("isOpen");
        searchMap.put("isOpen",isOpen);
        String createDateStart = Utils.isEmptyString(request.getParameter("createDateStart")) ? null : request.getParameter("createDateStart")+" 00:00:00";
        String createDateEnd = Utils.isEmptyString(request.getParameter("createDateEnd")) ? null : request.getParameter("createDateEnd")+" 23:59:59";
        
        if(ch != null){//渠道代理商登录
            if(ch.getChannelType() == 2){ //网点登录
                if("1".equals(isOpen)){
                    searchMap.put("openChannelId", ch.getId());
                }else{
                    searchMap.put("allChannelId", ch.getId());
                }
                searchMap.put("queryChId", ch.getId());//查询登录渠道id
                if(ch.getChannelLevel().intValue() == 1){
                    searchMap.put("chType", 1);//一级渠道
                }else if(ch.getChannelLevel().intValue() == 2 && ch.getChannelType().intValue() == 1){
                    searchMap.put("chType", 2);//二级渠道
                }else{
                    searchMap.put("chType", 3);//网点
                }
            }else if(null != allCh){//渠道统计进入
                if("1".equals(isOpen)){ //查询网点开户号码信息
                    if(allCh.getChannelType() == 2){
                        searchMap.put("openChannelId", allCh.getId());
                    }
                    searchMap.put("queryChId", allCh.getId());//查询归属渠道ID
                    if(allCh.getChannelLevel().intValue() == 1){
                        searchMap.put("chType", 1);//一级渠道
                    }else if(allCh.getChannelLevel().intValue() == 2 && allCh.getChannelType().intValue() == 1){
                        searchMap.put("chType", 2);//二级渠道
                    }else{
                        searchMap.put("chType", 3);//网点
                    }
                    
                    if(ch.getChannelLevel().intValue() == 1){
                        searchMap.put("logQueryChId1", ch.getId());//一级渠道
                    }else if(ch.getChannelLevel().intValue() == 2 && ch.getChannelType().intValue() == 1){
                        searchMap.put("logQueryChId2", ch.getId());//二级渠道
                    }else{
                        searchMap.put("logQueryChId3", ch.getId());//网点
                    }
                }else{
                    searchMap.put("allLoginChannelId", allCh.getId());// 并且归属这个渠道的
                    searchMap.put("allChannelId", ch.getId());//查询渠道号码详情
                }
            }else{
                if(ch.getChannelType() == 2 && "1".equals(isOpen)){ //查询网点开户号码信息
                    searchMap.put("openChannelId", ch.getId());
                }else{
                    searchMap.put("allChannelId", ch.getId());//查询渠道号码详情
                }
                searchMap.put("queryChId", ch.getId());//查询登录渠道id
                if(ch.getChannelLevel().intValue() == 1){
                    searchMap.put("chType", 1);//一级渠道
                }else if(ch.getChannelLevel().intValue() == 2 && ch.getChannelType().intValue() == 1){
                    searchMap.put("chType", 2);//二级渠道
                }else{
                    searchMap.put("chType", 3);//网点
                }
            }
            searchMap.put("ncCreateDateStart", createDateStart);
            searchMap.put("ncCreateDateEnd", createDateEnd);
        }else{//总部登录
            if(null != allCh){//渠道统计进入
                if(allCh.getChannelType() == 2 && "1".equals(isOpen)){ //查看网点开户号码信息
                    searchMap.put("openChannelId", allCh.getId());
                }else{
                    searchMap.put("allChannelId", allCh.getId());//查询渠道号码详情
                }
            }
            searchMap.put("createDateStart", createDateStart);
            searchMap.put("createDateEnd", createDateEnd);
        }
        
        if(!"1".equals(isOpen)){
            List<String> statusList = new ArrayList<>();
            statusList.add(TNumber.STATUS_WAIT_ALLOT);
            statusList.add(TNumber.STATUS_WAIT_ACTIVATE);
            searchMap.put("statusList",statusList);
        }
        
        String status = request.getParameter("status");
        if("WAIT_ALLOT".equals(status)){//待分配
            if(null == ch){//总部
                searchMap.put("status",TNumber.STATUS_WAIT_ALLOT);
            }else{
                searchMap.put("ncStatus",NumberChannel.STATUS_1);
            }
        }else if("FINISH".equals(status)){//已开户
            List<String> list = new ArrayList<String>();
            list.add(TNumber.STATUS_WAIT_ALLOT);
            list.add(TNumber.STATUS_WAIT_ACTIVATE);
            searchMap.put("statusNotList",list);
        }else if("OPEN".equals(status)){//已开户
            List<String> list = new ArrayList<String>();
            list.add(TNumber.STATUS_WAIT_ALLOT);
            list.add(TNumber.STATUS_WAIT_ACTIVATE);
            list.add(TNumber.STATUS_CANCEL);
            searchMap.put("statusNotList",list);
        }else{
            if(null != ch && ch.getChannelLevel() == 1 && "WAIT_ACTIVATE".equals(status)){ //一级代理商查询待开户不能查询出一级待分配号码
                searchMap.put("channelNotId",ch.getId());
            }
            searchMap.put("status",status);
        }
        String levels = Utils.isEmptyString(request.getParameter("levels")) ? "" : request.getParameter("levels");
        if(!Utils.isEmptyString(levels)){
            String[] le = levels.split(",");
            if(le.length >0){
                List<String> list = new ArrayList<String>();
                for(int i=0;i<le.length;i++){
                    if(!Utils.isEmptyString(le[i])){
                        list.add(le[i]);
                    }
                }
                if(list.size() >0){
                    searchMap.put("levels",list);
                }
            }
        }
        return searchMap;
    }
    
    /**
     * 查看号码信息
     * @param id
     * @return
     */
    @RequestMapping(value="detail/{phoneId}",method=RequestMethod.POST)
    @ResponseBody
    public TNumber detailPhone(@PathVariable Integer phoneId){
        try{
            return numService.findById(phoneId);
        }catch(Exception e){
            logger.error("查看号码信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * 修改号码iccid
     * @param
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="iccidUp", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> pacSave(@Valid TNumber tn,RedirectAttributes redirectAttributes,HttpServletRequest request ,HttpSession session){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            if(Utils.isEmptyString(tn.getId()) || Utils.isEmptyString(tn.getIccid()) || Utils.isEmptyString(tn.getImsi())){
                map.put("status", false);
                map.put("msg", "参数输入不完整");
                return map;
            }
            User us = (User) session.getAttribute(Constant.SESSION_USER);
            RestStatus r = numService.upIccid(tn, us);
            if(!r.getStatus()){
                map.put("status", false);
                map.put("msg", r.getErrorMessage());
            }
        }catch(Exception e){
            logger.error("修改号码ICCID，原因：" + e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
        }
        return map;
    }
    
    /**
     * 号码池管理
     * @param model
     * @return
     */
    @RequestMapping(value = "stock-num-pool", method = RequestMethod.GET)
    public String stockNumPool(Model model, HttpServletRequest request) {
        String url = "/views/stock/stockNumberPoolInfo.jsp";
        model.addAttribute("isHome", request.getParameter("isHome"));
        model.addAttribute("network", request.getParameter("network"));
        model.addAttribute("numStatus", request.getParameter("numStatus"));
        return url;
    }

    /**
     * 号码池查询条件组装
     * @param request
     * @return
     * @throws Exception
     */
    private Map<String,Object> searchPoolMap(HttpServletRequest request) throws Exception{
        Map<String,Object> searchMap = new HashMap<>();
        String numStatus = request.getParameter("numStatus");
        if(!Utils.isEmptyString(numStatus)){
            if(numStatus.equals("US20")){
                searchMap.put("nbStatus","0");
                searchMap.put("numStatusUS20","US20");
            }else if(numStatus.indexOf("US") > -1){
                searchMap.put("numStatus",numStatus);
            }else{
                searchMap.put("nbStatus",numStatus);
            }
        }
        
        searchMap.put("startPhone",request.getParameter("startPhone"));
        searchMap.put("endPhone",request.getParameter("endPhone"));
        searchMap.put("iccidLike",request.getParameter("iccidLike"));
        searchMap.put("npDateStart",request.getParameter("npDateStart"));
        searchMap.put("npDateEnd",request.getParameter("npDateEnd"));
        searchMap.put("nDateStart",request.getParameter("nDateStart"));
        searchMap.put("nDateEnd",request.getParameter("nDateEnd"));
        searchMap.put("levels",request.getParameter("levels"));
        searchMap.put("cityLike",request.getParameter("cityLike"));
        searchMap.put("validStartdate",request.getParameter("validStartdate"));
        searchMap.put("validEnddate",request.getParameter("validEnddate"));
        searchMap.put("imsiLike",request.getParameter("imsiLike"));
        searchMap.put("packagesId",request.getParameter("packagesId"));
        searchMap.put("eqMoney",request.getParameter("eqMoney"));
        searchMap.put("nameOrCode",request.getParameter("nameOrCode"));
        searchMap.put("likeRemark",request.getParameter("likeRemark"));
        searchMap.put("openNameOrCode",request.getParameter("openNameOrCode"));
        searchMap.put("network",request.getParameter("network"));
        searchMap.put("isPre",request.getParameter("isPre"));
        return searchMap;
    }
    
    
    /**
     * 查询号码池列表
     * @return
     */
    @RequestMapping(value="stock-num-pool",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<NumberPoolListDTO> numPoolList(DataTable<NumberPoolListDTO> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = searchPoolMap(request);
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return numberPoolService.numPoolList(dt,searchMap);
        }catch(Exception e){
            logger.error("查看查询号码池列表信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    /**
     * 号码池详情导出
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @RequestMapping(value = "stock-num-pool-expor", method = RequestMethod.GET)
    public void stockNumPoolExpor(HttpServletResponse response,HttpServletRequest request){
        OutputStream out = null;
        List listExport = null;
        try{
            Map<String,Object> searchMap = searchPoolMap(request);
            searchMap.put("limit", 0);
            searchMap.put("pageSize",50000);
            listExport = numberPoolService.numPoolListExpor(searchMap);
            String downloadName = "号码池信息";
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"序号","当前渠道","渠道属性","入库时间","一级渠道","二级渠道","是否预开","网络","号码","级别","面值","ICCID","IMSI","上架时间","有效期","状态","销售渠道","备注"};
            properties = new String[]{"id","chNameStr","chTypeStr","createTimeStr","ch1Name","ch2Name","isPreStr","networkStr","phone","levelStr","moneyYuan","iccid","imsi","numDateStr","validTimeStr","status","opChName","remark"};
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            out = response.getOutputStream();
            util.exportExcel(out,headers,listExport,properties);
        }catch (Exception ex){
            logger.error("号码池详情导出异常：原因："+ ex.getMessage(),ex);
        } finally {
            listExport = null;
            if (null != out) {
                try {
                    out.close();
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }
                out = null;
            }
        }
    }
    
    /**
     * 查询号码变动记录表
     * @return
     */
    @RequestMapping(value="stock-num-pool-up",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<NumberRecord> numPoolListUp(DataTable<NumberRecord> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = new HashMap<>();
            searchMap.put("phone",request.getParameter("phone"));
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return numberPoolService.numPoolListUp(dt,searchMap);
        }catch(Exception e){
            logger.error("查询号码变动记录表信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * ICCID管理
     * @param model
     * @return
     */
    @RequestMapping(value = "stock-iccid-pool", method = RequestMethod.GET)
    public String stockIccidPool(Model model, HttpServletRequest request) {
        String url = "/views/stock/stockIccidPoolInfo.jsp";
        return url;
    }
    
    /**
     * iccid池查询条件组装
     * @param request
     * @return
     * @throws Exception
     */
    private Map<String,Object> searchIccidPoolMap(HttpServletRequest request) throws Exception{
        Map<String,Object> searchMap = new HashMap<>();
        searchMap.put("icStatus",request.getParameter("icStatus"));
        searchMap.put("startPhone",request.getParameter("startPhone"));
        searchMap.put("endPhone",request.getParameter("endPhone"));
        searchMap.put("iccidLike",request.getParameter("iccidLike"));
        searchMap.put("icDateStart",request.getParameter("icDateStart"));
        searchMap.put("icDateEnd",request.getParameter("icDateEnd"));
        searchMap.put("nDateStart",request.getParameter("nDateStart"));
        searchMap.put("nDateEnd",request.getParameter("nDateEnd"));
        searchMap.put("imsiLike",request.getParameter("imsiLike"));
        searchMap.put("network",request.getParameter("network"));
        return searchMap;
    }
    
    /**
     * ICCID管理查询
     * @return
     */
    @RequestMapping(value="stock-iccid-pool",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<IccidPoolListDTO> stockIccidPool(DataTable<IccidPoolListDTO> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = searchIccidPoolMap(request);
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return iccidPoolService.stockIccidPool(dt,searchMap);
        }catch(Exception e){
            logger.error("查询号码变动记录表信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    

    /**
     * iccid池详情导出
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @RequestMapping(value = "stock-iccid-pool-expor", method = RequestMethod.GET)
    public void stockIccidPoolExpor(HttpServletResponse response,HttpServletRequest request){
        OutputStream out = null;
        List listExport = null;
        try{
            Map<String,Object> searchMap = searchIccidPoolMap(request);
            searchMap.put("limit", 0);
            searchMap.put("pageSize",50000);
            listExport = iccidPoolService.stockIccidPoolExpor(searchMap);
            String downloadName = "ICCID信息";
            ExcelUtils util = ExcelUtils.getInstall();
            String[] headers = null;
            String [] properties = null;
            headers = new String[]{"序号","手机号段","手机号码","号码级别","网络","ICCID","IMSI","出库日期","入库日期","状态"};
            properties = new String[]{"id","area","phone","levelStr","networkStr","iccid","imsi","ncTimeStr","createTimeStr","icStatusStr"};
            response.setHeader("content-disposition", "attachment;filename=" + new String(downloadName.getBytes("GBK"), "ISO-8859-1")+".xls");
            out = response.getOutputStream();
            util.exportExcel(out,headers,listExport,properties);
        }catch (Exception ex){
            logger.error(" iccid池详情导出异常：原因："+ ex.getMessage(),ex);
        } finally {
            listExport = null;
            if (null != out) {
                try {
                    out.close();
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }
                out = null;
            }
        }
    }
    
    /**
     * 查询ICCID绑定记录表
     * @return
     */
    @RequestMapping(value="stock-num-iccid-up",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<IccidRecord> numIccidListUp(DataTable<IccidRecord> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = new HashMap<>();
            searchMap.put("iccid",request.getParameter("iccid"));
            searchMap.put("phone",request.getParameter("phone"));
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return iccidPoolService.numIccidListUp(dt,searchMap);
        }catch(Exception e){
            logger.error("查询ICCID绑定记录表信息失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    
    /**
     * 查询延期号码数量
     * @return
     */
    @RequestMapping(value="stock-num-delay-sum",method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> numDelaySum(HttpServletRequest request, HttpSession session){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            Map<String,Object> searchMap = new HashMap<>();
            String hisValidTime = request.getParameter("hisValidTime");
            if(Utils.isEmptyString(hisValidTime)){
                map.put("status", false);
                map.put("msg", "非法请求，请重新登录");
                return map;
            }
            searchMap.put("hisValidTime",hisValidTime);
            String chCode = request.getParameter("chCode");
            if(!Utils.isEmptyString(chCode)){
                Channels ch = channelsService.findByCode(chCode);
                if(null == ch){
                    map.put("status", false);
                    map.put("msg", "一级渠道编号输入不正确");
                    return map;
                }
                if(Channels.CHANNEL_LEVEL_1.intValue() == ch.getChannelLevel().intValue()){
                    searchMap.put("chID1",ch.getId());
                }else{
                    map.put("status", false);
                    map.put("msg", "请填写一级渠道编号");
                    return map;
                }
            }
            List<String> list = new ArrayList<String>();
            list.add("US01");
            list.add("US02");
            searchMap.put("statusList", list);
            int cnt = numService.listCount(searchMap);
            map.put("cnt", cnt);
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("查询延期号码数量失败，原因：" + e.getMessage(), e);
        }
        return map;
    }
    
    /**
     * 号码延期
     * @return
     */
    @RequestMapping(value="stock-num-delay-up",method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> numDelayUp(HttpServletRequest request, HttpSession session){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            Map<String,Object> searchMap = new HashMap<>();
            String hisValidTime = request.getParameter("hisValidTime");
            String newValidTime = request.getParameter("newValidTime");
            if(Utils.isEmptyString(hisValidTime) || Utils.isEmptyString(newValidTime)){
                map.put("status", false);
                map.put("msg", "非法请求，请重新登录");
                return map;
            }
            List<String> list = new ArrayList<String>();
            list.add("US01");
            list.add("US02");
            searchMap.put("statusList", list);
            searchMap.put("hisValidTime",hisValidTime);
            searchMap.put("newValidTime",newValidTime);
            String chCode = request.getParameter("chCode");
            if(!Utils.isEmptyString(chCode)){
                Channels ch = channelsService.findByCode(chCode);
                if(null == ch){
                    map.put("status", false);
                    map.put("msg", "一级渠道编号输入不正确");
                    return map;
                }
                if(Channels.CHANNEL_LEVEL_1.intValue() == ch.getChannelLevel().intValue()){
                    searchMap.put("chID1",ch.getId());
                }else{
                    map.put("status", false);
                    map.put("msg", "请填写一级渠道编号");
                    return map;
                }
            }
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(null == user){
                map.put("status", false);
                map.put("msg", "您的登录已超时，请重新登录");
                return map;
            }
            int upCnt = numService.numberDelay(searchMap, user);
            map.put("upCnt", upCnt);
            if(upCnt == 0){
                map.put("status", false);
                map.put("msg", "没有需要延期的号码");
            }
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("号码延期失败，原因：" + e.getMessage(), e);
        }
        return map;
    }
}
