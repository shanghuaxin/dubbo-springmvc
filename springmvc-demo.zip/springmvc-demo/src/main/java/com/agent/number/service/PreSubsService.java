package com.agent.number.service;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.common.DataTable;
import com.agent.exception.SeeComException;
import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberMapper;
import com.agent.openaccount.entity.PreSubs;
import com.agent.openaccount.mapper.PreSubsMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;

@Transactional(rollbackFor=Exception.class)
@Service("preSubsService")
public class PreSubsService {
    
    private static Logger logger = LoggerFactory.getLogger(PreSubsService.class);
    @Resource
    private PreSubsMapper preSubsMapper;
    @Autowired
    private BusinessLogService businessLogService;
    @Autowired
    private NumberMapper numberMapper;
    
    /**
     * 库存统计列表
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<PreSubs> preList(DataTable<PreSubs> dt,Map<String, Object> searchParams) throws Exception{
       List<PreSubs> list = preSubsMapper.list(searchParams);
        dt.setAaData(list);
        int count = preSubsMapper.count(searchParams);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    /**
     * 新增预开户标记
     * @param pre
     * @throws Exception
     */
    public int savePre(PreSubs pre,User us) throws Exception{
        TNumber t = numberMapper.findByPhone(pre.getPhone());
        if(null == t){
            throw new SeeComException("标记号码不存在！");
        }
        if(t.getStatus().equals(TNumber.STATUS_FINISH_ACTIVATE) || t.getStatus().equals(TNumber.STATUS_WAIT_FINISH)){
            throw new SeeComException("号码已经开户不能再标记！");
        }
        Map<String, Object> searchMap = new HashMap<>();
        searchMap.put("phoneEq", pre.getPhone());
        List<PreSubs> findPre = preSubsMapper.list(searchMap);
        if(null != findPre && findPre.size() >0){
            throw new SeeComException("号码已经为预开户号码！");
        }
        
        int ct = preSubsMapper.insert(pre);
        t.setIsPre("1");
        numberMapper.updateIsPre(t);
        savePreLog(us,pre.getPhone());
        return ct;
    }
    
    /**
     * 新增预开户号码
     * @param us
     */
    public void savePreLog(User us,String phone){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("phone", phone);
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessLogService.businessSaveLog(Business.stock_phone_pre_save,String.valueOf(us.getId()),us.getLoginName(),"0","新增预开户号码",logmap);
        }catch (Exception  e){
            logger.error("新增预开户号码错误：原因："+e.getMessage(),e);
        }
    }
    
    /**
     * 删除预开户标记
     * @param pre
     * @throws Exception
     */
    public void delPre(PreSubs pre,User us) throws Exception{
        TNumber t = numberMapper.findByPhone(pre.getPhone());
        if(null == t){
            throw new SeeComException("删除标记号码不存在！");
        }
        if(t.getStatus().equals(TNumber.STATUS_FINISH_ACTIVATE) || t.getStatus().equals(TNumber.STATUS_WAIT_FINISH)){
            throw new SeeComException("号码已经开户不能再删除标记！");
        }
        Map<String, Object> searchMap = new HashMap<>();
        searchMap.put("phoneEq", pre.getPhone());
        List<PreSubs> findPre = preSubsMapper.list(searchMap);
        if(null != findPre && findPre.size() >0){
        }else{
            throw new SeeComException("号码不是预开户号码！");
        }
        preSubsMapper.deleteSubsByPhone(pre.getPhone());
        t.setIsPre("0");
        numberMapper.updateIsPre(t);
        delPreLog(us,pre.getPhone());
    }
    
    /**
     * 删除预开户号码
     * @param us
     */
    public void delPreLog(User us,String phone){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("phone", phone);
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessLogService.businessSaveLog(Business.stock_phone_pre_del,String.valueOf(us.getId()),us.getLoginName(),"0","删除预开户号码",logmap);
        }catch (Exception  e){
            logger.error("新增预开户号码错误：原因："+e.getMessage(),e);
        }
    }
    
}

