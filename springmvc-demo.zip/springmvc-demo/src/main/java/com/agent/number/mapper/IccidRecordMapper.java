package com.agent.number.mapper;

import java.util.List;

import com.agent.common.BaseMapper;
import com.agent.number.entity.IccidRecord;

public interface IccidRecordMapper extends BaseMapper<IccidRecord, Integer> {
    public void batchInsert(List<IccidRecord> list);
    
}
