package com.agent.number.dto;

import com.agent.number.entity.TNumber;

public class NumberImportDTO extends TNumber {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String packageCode;

    public String getPackageCode() {
        return packageCode;
    }

    public void setPackageCode(String packageCode) {
        this.packageCode = packageCode;
    }
}
