package com.agent.number.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;

/**
 * 号码池信息表
 */
public class NumberPool extends BaseDomain {
    //待上架
    public static final Integer NB_STATUS_0 = 0;
    //已上架
    public static final Integer NB_STATUS_1 = 1;
    /**
     * 
     */
    private static final long serialVersionUID = 7122466957883505358L;
    private String phone;//号码',
    private String area;// '号段'
    private Integer nbStatus;//状态：0-待上架，1-已上架
    private Integer network;//网络：1-移动，2-联通，3-电信
    private Integer nbLevel;//酷商号码级别
    private Long instId;//号码源系统id
    private String levelName;//级别名称
    private String levelCode;//级别编号
    private BigDecimal minFloat;  //低消：单位：分
    
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getArea() {
        return area;
    }
    public void setArea(String area) {
        this.area = area;
    }
    public Integer getNbStatus() {
        return nbStatus;
    }
    public void setNbStatus(Integer nbStatus) {
        this.nbStatus = nbStatus;
    }
    public Integer getNetwork() {
        return network;
    }
    public void setNetwork(Integer network) {
        this.network = network;
    }
    
    public Integer getNbLevel() {
        return nbLevel;
    }
    public void setNbLevel(Integer nbLevel) {
        this.nbLevel = nbLevel;
    }
    public String getNetworkStr() {
        if(null != network){
            if(1 == network.intValue()){
                return "移动";
            }else if(2 == network.intValue()){
                return "联通";
            }else {
                return "电信";
            }
        }
        return "";
    }
    public Long getInstId() {
        return instId;
    }
    public void setInstId(Long instId) {
        this.instId = instId;
    }
    public String getLevelName() {
        return levelName;
    }
    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }
    public String getLevelCode() {
        return levelCode;
    }
    public void setLevelCode(String levelCode) {
        this.levelCode = levelCode;
    }
    public BigDecimal getMinFloat() {
        return minFloat;
    }
    public void setMinFloat(BigDecimal minFloat) {
        this.minFloat = minFloat;
    }
}
