//package com.agent.number.service;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.math.BigDecimal;
//import java.nio.channels.FileChannel;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.concurrent.ConcurrentHashMap;
//
//import javax.annotation.Resource;
//import javax.servlet.http.HttpServletRequest;
//
//import org.apache.commons.beanutils.BeanUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.agent.businesslog.service.BusinessLogService;
//import com.agent.businesslog.util.Business;
//import com.agent.channel.entity.Channels;
//import com.agent.channel.mapper.ChannelProductMapper;
//import com.agent.channel.service.ChannelsService;
//import com.agent.common.SessionData;
//import com.agent.constant.Constant;
//import com.agent.file.dto.PhoneImportDto;
//import com.agent.file.dto.PreImportDto;
//import com.agent.file.entity.AttachFile;
//import com.agent.file.mapper.AttachFileMapper;
//import com.agent.file.service.ImportExcelService;
//import com.agent.file.utils.FileUtil;
//import com.agent.number.dto.NumberDTO;
//import com.agent.number.dto.NumberImportDTO;
//import com.agent.number.entity.NumberChannel;
//import com.agent.number.entity.TNumber;
//import com.agent.number.entity.TNumberHis;
//import com.agent.number.mapper.NumberChannelMapper;
//import com.agent.number.mapper.NumberHisMapper;
//import com.agent.number.mapper.NumberMapper;
//import com.agent.number.util.NumberUtil;
//import com.agent.openaccount.entity.PreSubs;
//import com.agent.openaccount.mapper.PreSubsMapper;
//import com.agent.product.dto.ChannelProductDto;
//import com.agent.product.entity.Packages;
//import com.agent.product.mapper.PackagesMapper;
//import com.agent.stock.dto.CardInfoDto;
//import com.agent.stock.dto.StockNumDto;
//import com.agent.stock.entity.Stock;
//import com.agent.stock.entity.StockAllot;
//import com.agent.stock.mapper.StockAllotMapper;
//import com.agent.stock.service.StockService;
//import com.agent.system.entity.User;
//import com.agent.util.DateUtil;
//import com.agent.util.DicUtil;
//import com.agent.util.Utils;
//
//@Transactional(rollbackFor=Exception.class)
//@Service("numberImportService")
//public class NumberImportService {
//    private static Logger logger = LoggerFactory.getLogger(NumberImportService.class);
//    @Value("#{configProperties['imageURL']}")
//    private String imageURL;
//    @Resource
//    private NumberMapper numMapper;
//    @Resource
//    private PackagesMapper pacMapper;
//    @Resource
//    private ImportExcelService importExcelService;
//    @Autowired
//    private BusinessLogService logService;
//    @Resource
//    private StockService stockService;
//    @Resource
//    private StockAllotMapper stockAllotMapper;
//    @Resource
//    private AttachFileMapper attachFileMapper;
//    @Resource
//    private ChannelsService channelsService;
//    @Resource
//    private NumberChannelMapper numChMapper;
//    @Resource
//    private NumberHisMapper numHisMapper;
//    @Resource
//    private PreSubsMapper preSubsMapper;
//    @Resource
//    private ChannelProductMapper chProMapper;
//    @Resource
//    private NumberUtil numberUtil;
//
//    /**
//     * 号码信息导入
//     * @param file
//     * @param importType
//     * @param request
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("unchecked")
//    public Map<String,Object> importPhoneInfoFile(MultipartFile file,String importType,HttpServletRequest request) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        rtnMap.put("stat",true);
//        String fileExt= file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1).toLowerCase();//扩展名
//        Date dt = new Date();
//        String fileName = DateUtil.getInstance().getDateStr(dt,DateUtil.yyyyMMddHHmmss)+importType+"."+fileExt;
//        String filePatch = Constant.STOCK_IMPORT + File.separator + DateUtil.getInstance().getYear(dt) + File.separator + DateUtil.getInstance().getMonth(dt);
//        File upFile = new File(imageURL + File.separator +filePatch + File.separator + fileName);
//        if(!upFile.getParentFile().exists()){
//            upFile.getParentFile().mkdirs();
//        }
//        User us = SessionData.getInstance().getUser(request);
//        //上传文件
//        String rtStr = FileUtil.saveImageFile(file, imageURL, filePatch, fileName);
//        //调用Excel解析
//        Map<String,Object> map = importExcelService.GetObjInfOfExcel(upFile,fileExt,importType);
//        if(Utils.isEmptyString(map.get("errorBack").toString())){
//            List<PhoneImportDto> impList=(List<PhoneImportDto>)map.get("objTList");
//            if(null != impList && impList.size() >0){
//                //保存导入的数据
//                rtnMap = saveMapImprt(impList,us ,rtStr,upFile,file.getOriginalFilename());
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    upFile.delete();
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg",rtnMap.get("msg"));
//                }
//            }else{
//                upFile.delete();
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","请填写导入数据！");
//            }
//            importLog(us,impList.size());
//        }else{
//            upFile.delete();
//            rtnMap.put("stat",false);
//            rtnMap.put("msg",map.get("errorBack"));
//        }
//        return rtnMap;
//    }
//
//    /**
//     * 库存导入
//     * @param us
//     */
//    public void importLog(User us,Integer dataNum){
//        try{
//            Map<String,String> logmap = new ConcurrentHashMap<String,String>();
//            logmap.put("staff", us.getLoginName());
//            logmap.put("dataNum", dataNum.toString());
//            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
//            logmap.put("result","成功！");
//            logService.businessSaveLog(Business.stock_phone_import,String.valueOf(us.getId()),us.getLoginName(),"0","号码导入",logmap);
//        }catch (Exception  e){
//            logger.error("号码库存导入日志记录错误：原因："+e.getMessage(),e);
//        }
//    }
//
//    /**
//     * 号码导入数据校验入库
//     * @param impList
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("resource")
//    public Map<String,Object> saveMapImprt(List<PhoneImportDto> impList,User us,String fileUrl,File file,String fileName) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        Map<String,Packages> packCodeMap = new ConcurrentHashMap<String,Packages>();//套餐编号,id Map
//        List<String> packageList = null;//套餐编号
//        List<String> phoneList  = null;//号码
//        List<String> iccidList = null;//Iccid
//        List<String> imsiList = null;//imsi
//        List<NumberImportDTO> numDtos = new ArrayList<NumberImportDTO>();//入库数据list
//        List<PreSubs> pres = new ArrayList<PreSubs>();//入库数据list
//        Date date = new Date();
//
//        List<String> chCodes = null;//channelCode
//        Map<String,List<PhoneImportDto>> chNumMap = new ConcurrentHashMap<String,List<PhoneImportDto>>();
//        Map<Integer,StockNumDto> stockMap = new ConcurrentHashMap<Integer,StockNumDto>();  //总库存：渠道id  ，类型数量
//        Map<String, Integer> operatorMap = new ConcurrentHashMap<String, Integer>();//运营商转换
//        operatorMap.put("移动", 1);
//        operatorMap.put("联通", 2);
//        operatorMap.put("电信", 3);
//
//        Integer maxId = numMapper.maxId();
//        //分批基础数据校验
//        Integer dataCount = impList.size();
//        int page = 0;//页数
//        int pageCount = 10000;
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                packageList = new ArrayList<String>();//套餐编号
//                phoneList = new ArrayList<String>();//号码
//                iccidList = new ArrayList<String>();//Iccid
//                imsiList = new ArrayList<String>();//imsi
//                chCodes = new ArrayList<String>();//chCodes
//                rtnMap = vaildCheck(start, end, impList,pres,packageList, phoneList, iccidList,imsiList,chCodes);
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    return rtnMap;
//                }
//                //数据库校验
//                rtnMap = vaildDataCheck(maxId,start, end,chNumMap,stockMap,impList,numDtos,packCodeMap,packageList,phoneList,iccidList,imsiList,chCodes,operatorMap,date);
//                maxId = maxId + pageCount;
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    return rtnMap;
//                }
//            }
//        }else {
//            packageList = new ArrayList<String>();//套餐编号
//            phoneList = new ArrayList<String>();//号码
//            iccidList = new ArrayList<String>();//Iccid
//            imsiList = new ArrayList<String>();//imsi
//            chCodes = new ArrayList<String>();//chCodes
//
//            rtnMap = vaildCheck(0, dataCount,impList,pres,packageList, phoneList, iccidList,imsiList,chCodes);
//            if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                return rtnMap;
//            }
//            //数据库校验
//            rtnMap = vaildDataCheck(maxId,0, dataCount,chNumMap,stockMap,impList,numDtos,packCodeMap,packageList,phoneList,iccidList,imsiList,chCodes,operatorMap,date);
//            if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                return rtnMap;
//            }
//        }
//        impList.clear();
//        packageList.clear();
//        phoneList.clear();
//        iccidList.clear();
//        imsiList.clear();
//
//        //预开户信息入库
//        if(pres.size() >0){
//            for(PreSubs p:pres){
//                p.setCreateId(us.getId());
//                p.setCreateTime(date);;
//                p.setUpdateId(us.getId());
//                p.setUpdateTime(date);
//                p.setServName(null != packCodeMap.get(p.getServCode()) ? packCodeMap.get(p.getServCode()).getName() : null);
//            }
//            preSubsMapper.batchInsert(pres);
//        }
//
//        //记录库存导入批次表
//        StockAllot stockAllot = new StockAllot();
//        stockAllot.setServType(StockAllot.serv_type_2);
//        stockAllot.setNum(numDtos.size());
//        stockAllot.setAllotType(StockAllot.allot_type_1);
//        stockAllot.setChannelIdFrom(0);
//        stockAllot.setChannelCodeFrom("0");
//        stockAllot.setChannelNameFrom(StockAllot.com_name);
//        stockAllot.setChannelIdTo(0);
//        stockAllot.setChannelCodeTo("0");
//        stockAllot.setChannelNameTo(StockAllot.com_name);
//        stockAllot.setCreateId(us.getId());
//        stockAllot.setCreateTime(date);
//        stockAllot.setUpdateId(us.getId());
//        stockAllot.setUpdateTime(date);
//        stockAllotMapper.insert(stockAllot);
//        //附件信息表入库
//        AttachFile af = new AttachFile();
//        af.setAttachName(fileName);
//        af.setAttachDesc("号码导入附件");
//        af.setAttachUrl(fileUrl);
//        af.setAttrachType(0);
//        af.setSort(1);
//        FileInputStream fis= new FileInputStream(file);
//        FileChannel fc= fis.getChannel();
//        af.setSize(fc.size());
//        af.setSourceId(stockAllot.getId());
//        af.setSourceType("t_stock_allot");
//        af.setCreateId(us.getId());
//        af.setCreateTime(date);
//        af.setUpdateId(us.getId());
//        af.setUpdateTime(date);
//        attachFileMapper.insert(af);
//        //库存信息入库
//        numberUtil.insertStock(stockMap,date,us);
//
//        //号码信息入库
//        List<TNumber> saveNumbers = new ArrayList<TNumber>();
//        for(NumberImportDTO d:numDtos){
//            d.setPackagesId(null != packCodeMap.get(d.getPackageCode()) ? packCodeMap.get(d.getPackageCode()).getId() : null);
//            d.setCreateId(us.getId());
//            d.setCreateTime(date);;
//            d.setUpdateId(us.getId());
//            d.setUpdateTime(date);
//            TNumber n = new TNumber();
//            BeanUtils.copyProperties(n, d);
//            saveNumbers.add(n);
//        }
//        packCodeMap.clear();
//        //号码表分批入库
//        dataCount = saveNumbers.size();
//        page = 0;//页数
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                insertSavePhone(saveNumbers, start, end);
//            }
//        }else {
//            insertSavePhone(saveNumbers, 0, dataCount);
//        }
//
//        //录入批次表和库存表信息  有进行分配的时候
//        List<NumberChannel> numChs = new ArrayList<NumberChannel>();//入库数据list
//        if(chNumMap.keySet().size() > 0){
//            numberUtil.saveImportData(numChs,chNumMap,us,date,Constant.PHONE_ALLOT_COMP);//号码导入是总部分配
//        }
//        if(numChs.size() >0){
//            //号码分配记录表分批入库
//            dataCount = numChs.size();
//            page = 0;//页数
//            if(dataCount > pageCount){
//                if(dataCount%pageCount !=0){
//                    page = dataCount/pageCount +1;
//                }else{
//                    page = dataCount/pageCount;
//                }
//                int start=0,end=0;
//                for (int i = 1; i <= page; i++) {
//                    if (i * pageCount > dataCount) {
//                        end = dataCount;
//                    } else {
//                        end = i * pageCount;
//                    }
//                    if (i == 1) {
//                        start = i - 1;
//                    } else {
//                        start = (i - 1) * pageCount;
//                    }
//                    insertSaveNumChannel(numChs, start, end);
//                }
//            }else {
//                insertSaveNumChannel(numChs, 0, dataCount);
//            }
//        }
//
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//
//
//    /**
//     * 号码分批入库
//     * @param phones
//     * @throws Exception
//     */
//    public void insertSavePhone(List<TNumber> phones,int start,int end) throws Exception{
//        List<TNumber> saveList = new ArrayList<TNumber>();
//        for (int i = start; i < end; i++) {
//            saveList.add(phones.get(i));
//        }
//        numMapper.batchInsert(saveList);
//    }
//
//    /**
//     * 基础数据校验
//     * @param start
//     * @param end
//     * @param impList
//     * @param packageList
//     * @param phoneList
//     * @param iccidList
//     * @param imsiList
//     * @return
//     * @throws Exception
//     */
//    public Map<String,Object> vaildCheck(int start, int end,List<PhoneImportDto> impList,List<PreSubs> pres,List<String> packageList,List<String> phoneList,List<String> iccidList,List<String> imsiList,List<String> chCodes) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        //基本数据校验
//        for (int i = start; i < end; i++) {
//            if(!packageList.contains(impList.get(i).getPackages()) && !Utils.isEmptyString(impList.get(i).getPackages())){
//                packageList.add(impList.get(i).getPackages());
//            }
//
//            if(Utils.isEmptyString(impList.get(i).getChannelCode1()) &&
//                    (!Utils.isEmptyString(impList.get(i).getChannelCode2()) || !Utils.isEmptyString(impList.get(i).getChannelCode3()))){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"分配请填写一级代理商编号");
//                return rtnMap;
//            }
//
//            if(!chCodes.contains(impList.get(i).getChannelCode1()) && !Utils.isEmptyString(impList.get(i).getChannelCode1())){
//                chCodes.add(impList.get(i).getChannelCode1());
//            }
//            if(!chCodes.contains(impList.get(i).getChannelCode2()) && !Utils.isEmptyString(impList.get(i).getChannelCode2())){
//                chCodes.add(impList.get(i).getChannelCode2());
//            }
//            if(!chCodes.contains(impList.get(i).getChannelCode3()) && !Utils.isEmptyString(impList.get(i).getChannelCode3())){
//                chCodes.add(impList.get(i).getChannelCode3());
//            }
//
//            if(11 != impList.get(i).getPhone().length()){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"不是11位号码");
//                return rtnMap;
//            }
//
//            if(phoneList.contains(impList.get(i).getPhone())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            phoneList.add(impList.get(i).getPhone());
//
//            if(iccidList.contains(impList.get(i).getIccid())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","ICCID"+impList.get(i).getIccid()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            iccidList.add(impList.get(i).getIccid());
//
//
//            if(imsiList.contains(impList.get(i).getImsi())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","IMSI"+impList.get(i).getImsi()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            imsiList.add(impList.get(i).getImsi());
//
//            Integer minFloat = 0;
//            try{
//                minFloat = Integer.valueOf(impList.get(i).getMinFloat());
//            }catch (Exception e){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"抵消不是数字");
//                return rtnMap;
//            }
//            Integer prestore = 0;
//            try{
//                prestore = Integer.valueOf(impList.get(i).getPrestore());
//            }catch (Exception e){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"预存不是数字");
//                return rtnMap;
//            }
//            Integer money = 0;
//            try{
//                money = Integer.valueOf(impList.get(i).getMoney());
//            }catch (Exception e){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"面额不是数字");
//                return rtnMap;
//            }
//
//            if(money.intValue() < prestore.intValue() || money.intValue() < minFloat.intValue()){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"面额必须大于等于抵消和预存款的最大值");
//                return rtnMap;
//            }
//
//            try{
//                DateUtil.getInstance().parseDateException(impList.get(i).getValidity(), DateUtil.yyyy_MM_dd);
//            }catch (Exception e){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"有效期格式不正确");
//                return rtnMap;
//            }
//            
//
//            
//            if(!"移动".equals(impList.get(i).getOperatorCode()) && !"联通".equals(impList.get(i).getOperatorCode()) && !"电信".equals(impList.get(i).getOperatorCode())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"运营商不正确");
//                return rtnMap;
//            }
//            
//            if(!"是".equals(impList.get(i).getIsPre()) && !"否".equals(impList.get(i).getIsPre())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"是否预开户只能输入是/否");
//                return rtnMap;
//            }
//            if("是".equals(impList.get(i).getIsPre())){
//                try{
//                    DateUtil.getInstance().parseDateException(impList.get(i).getPreDate(), DateUtil.yyyy_MM_dd);
//                }catch (Exception e){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+impList.get(i).getPhone()+ "预开时间格式不正确");
//                    return rtnMap;
//                }
//                if(Utils.isEmptyString(impList.get(i).getPackages())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+impList.get(i).getPhone()+ "为预开户号码，套餐必须填写");
//                    return rtnMap;
//                }
//                PreSubs pre = new PreSubs();
//                pre.setIccid(impList.get(i).getIccid());
//                pre.setImsi(impList.get(i).getImsi());
//                pre.setAdvanceTime(DateUtil.getInstance().parseDateException(impList.get(i).getPreDate(), DateUtil.yyyy_MM_dd));
//                pre.setPasswd("111111");
//                pre.setPhone(impList.get(i).getPhone());
//                pre.setServCode(impList.get(i).getPackages());
//                pres.add(pre);
//                impList.get(i).setIsPre("1");
//            }else{
//                impList.get(i).setIsPre("0");//默认不是预开户
//            }
//        }
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//    /**
//     * 号码导入数据库校验
//     * @param packageList
//     * @param phoneList
//     * @param iccidList
//     * @param imsiList
//     * @return
//     * @throws Exception
//     */
//    public Map<String,Object> vaildDataCheck(Integer maxId,int start, int end,Map<String,List<PhoneImportDto>> chNumMap,Map<Integer,StockNumDto> stockMap,List<PhoneImportDto> impList,List<NumberImportDTO> numDtos,Map<String,Packages> packMap,List<String> packageList,List<String> phoneList,List<String> iccidList,List<String> imsiList,List<String> chCodes,Map<String, Integer> operatorMap,Date date) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        Map<String, Object> mapSearch = new ConcurrentHashMap<String, Object>();
//        if(packageList.size() > 0){
//            mapSearch.put("codes",packageList);
//            List<Packages> packList = pacMapper.listPac(mapSearch);
//            if(null != packList && packList.size() >0){
//                Set<String> pacSet = new HashSet<String>();
//                for(Packages p:packList){
//                    pacSet.add(p.getCode());
//                    packMap.put(p.getCode(),p);
//                }
//                if(packList.size() != packageList.size()){
//                    StringBuffer errStr = new StringBuffer();
//                    for(int i=0;i<packageList.size();i++){
//                        if(!pacSet.contains(packageList.get(i))){
//                            errStr.append(packageList.get(i)).append(",");
//                        }
//                    }
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","套餐编号："+errStr.toString()+ "在系统中不存在");
//                    return rtnMap;
//                }
//            }else{
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","所有套餐编号在系统中不存在");
//                return rtnMap;
//            }
//        }
//        Map<String, Channels> chMaps = new ConcurrentHashMap<String, Channels>();//渠道编号对应渠道信息
//        Map<String, List<String>> chPacIsShow = new ConcurrentHashMap<String, List<String>>();//渠道可见对应套餐
//        if(chCodes.size() >0){
//            mapSearch = new ConcurrentHashMap<String, Object>();
//            mapSearch.put("codes",chCodes);
//            List<Channels> findChs = channelsService.listChannels(mapSearch);
//            if(null != findChs && findChs.size() >0){
//                Set<String> pacSet = new HashSet<String>();
//                for(Channels p:findChs){
//                    pacSet.add(p.getChannelCode());
//                    chMaps.put(p.getChannelCode(),p);
//                }
//                if(chCodes.size() != findChs.size()){
//                    StringBuffer errStr = new StringBuffer();
//                    for(int i=0;i<chCodes.size();i++){
//                        if(!pacSet.contains(chCodes.get(i))){
//                            errStr.append(chCodes.get(i)).append(",");
//                        }
//                    }
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道编号："+errStr.toString()+ "在系统中不存在");
//                    return rtnMap;
//                }
//            }else{
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","所有渠道编号在系统中不存在");
//                return rtnMap;
//            }
//
//            mapSearch = new ConcurrentHashMap<String, Object>();
//            mapSearch.put("channelCodes",chCodes);
//            mapSearch.put("isShow","1");
//            mapSearch.put("proCodes",packageList);
//            List<ChannelProductDto> chProList = chProMapper.listChPacIsShow(mapSearch);
//            if(null != chProList && chProList.size() >0){
//                for(ChannelProductDto d:chProList){
//                    if(chPacIsShow.containsKey(d.getChannelCode())){
//                        List<String> pacList = chPacIsShow.get(d.getChannelCode());
//                        pacList.add(d.getProCode());
//                        chPacIsShow.put(d.getChannelCode(),pacList);
//                    }else{
//                        List<String> pacList = new ArrayList<String>();
//                        pacList.add(d.getProCode());
//                        chPacIsShow.put(d.getChannelCode(),pacList);
//                    }
//                }
//            }else{
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","所有号码套餐对应的渠道都没有可见性，不能进行分配");
//                return rtnMap;
//            }
//        }
//
//
//        mapSearch = new ConcurrentHashMap<String, Object>();
//        mapSearch.put("phones",phoneList);
//        List<TNumber> findPhoneList = numMapper.list(mapSearch);
//        if(null != findPhoneList && findPhoneList.size() >0){
//            StringBuffer errStr = new StringBuffer();
//            for(int i=0;i<findPhoneList.size();i++){
//                errStr.append(findPhoneList.get(i).getPhone()).append(",");
//            }
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","号码："+errStr.toString()+ "在系统中已存在");
//            return rtnMap;
//        }
//
//        mapSearch = new ConcurrentHashMap<String, Object>();
//        mapSearch.put("iccids",iccidList);
//        List<TNumber> findIccidList = numMapper.list(mapSearch);
//        if(null != findIccidList && findIccidList.size() >0){
//            StringBuffer errStr = new StringBuffer();
//            for(int i=0;i<findIccidList.size();i++){
//                errStr.append(findIccidList.get(i).getIccid()).append(",");
//            }
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","ICCID："+errStr.toString()+ "在系统中已存在");
//            return rtnMap;
//        }
//
//        mapSearch = new ConcurrentHashMap<String, Object>();
//        mapSearch.put("imsis",imsiList);
//        List<TNumber> findImsiList = numMapper.list(mapSearch);
//        if(null != findImsiList && findImsiList.size() >0){
//            StringBuffer errStr = new StringBuffer();
//            for(int i=0;i<findImsiList.size();i++){
//                errStr.append(findImsiList.get(i).getImsi()).append(",");
//            }
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","IMSI："+errStr.toString()+ "在系统中已存在");
//            return rtnMap;
//        }
//        for (int i = start; i < end; i++) {
//            NumberImportDTO dto = new NumberImportDTO();
//            dto.setId(maxId++);
//            dto.setMoney((new BigDecimal(impList.get(i).getMoney())).multiply(Constant.cnt100));
//            dto.setOperatorCode(operatorMap.get(impList.get(i).getOperatorCode()));
//            impList.get(i).setMoney((new BigDecimal(impList.get(i).getMoney())).multiply(Constant.cnt100).toString());
//            impList.get(i).setPhoneId(dto.getId());
//            impList.get(i).setChannelDate1(date);
//            impList.get(i).setChannelDate2(date);
//            impList.get(i).setChannelDate3(date);
//            numberUtil.stockMapSet(stockMap, 0, null, null, Stock.statistics_type_1, 1);
//            if(!Utils.isEmptyString(impList.get(i).getChannelCode1()) && Utils.isEmptyString(impList.get(i).getChannelCode2()) && Utils.isEmptyString(impList.get(i).getChannelCode3())){
//                if(Channels.CHANNEL_LEVEL_1.intValue() != chMaps.get(impList.get(i).getChannelCode1()).getChannelLevel().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode1()+ "不是一级代理商");
//                    return rtnMap;
//                }
//                if(!chPacIsShow.get(impList.get(i).getChannelCode1()).contains(impList.get(i).getPackages())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+impList.get(i).getPhone()+"的套餐"+impList.get(i).getPackages()+"对渠道："+impList.get(i).getChannelCode1()+ "没有可见性不能进行分配");
//                    return rtnMap;
//                }
//                //分配给一级代理商
//                dto.setChannelId(chMaps.get(impList.get(i).getChannelCode1()).getId());
//                dto.setChannelName(chMaps.get(impList.get(i).getChannelCode1()).getChannelName());
//
//                impList.get(i).setAllotType(CardInfoDto.allot_type_1);
//                impList.get(i).setChannelId1(chMaps.get(impList.get(i).getChannelCode1()).getId());
//                impList.get(i).setChannelCode1(chMaps.get(impList.get(i).getChannelCode1()).getChannelCode());
//                impList.get(i).setChannelName1(chMaps.get(impList.get(i).getChannelCode1()).getChannelName());
//                if(chNumMap.containsKey(impList.get(i).getChannelCode1())){
//                    List<PhoneImportDto> channesList = chNumMap.get(impList.get(i).getChannelCode1());
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode1(),channesList);
//                }else{
//                    List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode1(),channesList);
//                }
//                //库存
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId1(), null,null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId1(), null,null, Stock.statistics_type_2,1);
//            }else if(!Utils.isEmptyString(impList.get(i).getChannelCode1()) && Utils.isEmptyString(impList.get(i).getChannelCode2()) && !Utils.isEmptyString(impList.get(i).getChannelCode3())){
//                //分配给直属网点
//                if(Channels.CHANNEL_LEVEL_1.intValue() != chMaps.get(impList.get(i).getChannelCode1()).getChannelLevel().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode1()+ "不是一级代理商");
//                    return rtnMap;
//                }
//                if(Channels.CHANNEL_TYPE_2.intValue() != chMaps.get(impList.get(i).getChannelCode3()).getChannelType().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode3()+ "不是网点代理商");
//                    return rtnMap;
//                }
//                if(chMaps.get(impList.get(i).getChannelCode3()).getParentChannelId().intValue() != chMaps.get(impList.get(i).getChannelCode1()).getId().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode3()+ "不是一级代理商"+impList.get(i).getChannelCode1()+"的直属网点渠道");
//                    return rtnMap;
//                }
//                if(!chPacIsShow.get(impList.get(i).getChannelCode1()).contains(impList.get(i).getPackages())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+impList.get(i).getPhone()+"的套餐"+impList.get(i).getPackages()+"对渠道："+impList.get(i).getChannelCode1()+ "没有可见性不能进行分配");
//                    return rtnMap;
//                }
//                dto.setChannelId(chMaps.get(impList.get(i).getChannelCode3()).getId());
//                dto.setChannelName(chMaps.get(impList.get(i).getChannelCode3()).getChannelName());
//
//                impList.get(i).setChannelId(chMaps.get(impList.get(i).getChannelCode3()).getId());
//                impList.get(i).setChannelName(chMaps.get(impList.get(i).getChannelCode3()).getChannelName());
//                impList.get(i).setAllotType(CardInfoDto.allot_type_4);
//                impList.get(i).setChannelId1(chMaps.get(impList.get(i).getChannelCode1()).getId());
//                impList.get(i).setChannelCode1(chMaps.get(impList.get(i).getChannelCode1()).getChannelCode());
//                impList.get(i).setChannelName1(chMaps.get(impList.get(i).getChannelCode1()).getChannelName());
//
//                impList.get(i).setChannelId3(chMaps.get(impList.get(i).getChannelCode3()).getId());
//                impList.get(i).setChannelCode3(chMaps.get(impList.get(i).getChannelCode3()).getChannelCode());
//                impList.get(i).setChannelName3(chMaps.get(impList.get(i).getChannelCode3()).getChannelName());
//                if(chNumMap.containsKey(impList.get(i).getChannelCode3())){
//                    List<PhoneImportDto> channesList = chNumMap.get(impList.get(i).getChannelCode3());
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode3(),channesList);
//                }else{
//                    List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode3(),channesList);
//                }
//
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId1(), null,null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId3(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId3(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_2,1);
//            }else if(!Utils.isEmptyString(impList.get(i).getChannelCode1()) && !Utils.isEmptyString(impList.get(i).getChannelCode2()) && Utils.isEmptyString(impList.get(i).getChannelCode3())){
//                //分配给二级渠道
//                if(Channels.CHANNEL_LEVEL_1.intValue() != chMaps.get(impList.get(i).getChannelCode1()).getChannelLevel().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode1()+ "不是一级代理商");
//                    return rtnMap;
//                }
//                if(Channels.CHANNEL_LEVEL_2.intValue() != chMaps.get(impList.get(i).getChannelCode2()).getChannelLevel().intValue() ||
//                        Channels.CHANNEL_TYPE_1.intValue() != chMaps.get(impList.get(i).getChannelCode2()).getChannelType().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode2()+ "不是二级代理商");
//                    return rtnMap;
//                }
//                if(chMaps.get(impList.get(i).getChannelCode2()).getParentChannelId().intValue() != chMaps.get(impList.get(i).getChannelCode1()).getId().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode2()+ "不是一级代理商"+impList.get(i).getChannelCode1()+"的下属二级渠道");
//                    return rtnMap;
//                }
//                if(!chPacIsShow.get(impList.get(i).getChannelCode1()).contains(impList.get(i).getPackages())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+impList.get(i).getPhone()+"的套餐"+impList.get(i).getPackages()+"对渠道："+impList.get(i).getChannelCode1()+ "没有可见性不能进行分配");
//                    return rtnMap;
//                }
//
//                dto.setChannelId(chMaps.get(impList.get(i).getChannelCode2()).getId());
//                dto.setChannelName(chMaps.get(impList.get(i).getChannelCode2()).getChannelName());
//
//                impList.get(i).setChannelId(chMaps.get(impList.get(i).getChannelCode2()).getId());
//                impList.get(i).setChannelName(chMaps.get(impList.get(i).getChannelCode2()).getChannelName());
//                impList.get(i).setAllotType(CardInfoDto.allot_type_2);
//                impList.get(i).setChannelId1(chMaps.get(impList.get(i).getChannelCode1()).getId());
//                impList.get(i).setChannelCode1(chMaps.get(impList.get(i).getChannelCode1()).getChannelCode());
//                impList.get(i).setChannelName1(chMaps.get(impList.get(i).getChannelCode1()).getChannelName());
//
//                impList.get(i).setChannelId2(chMaps.get(impList.get(i).getChannelCode2()).getId());
//                impList.get(i).setChannelCode2(chMaps.get(impList.get(i).getChannelCode2()).getChannelCode());
//                impList.get(i).setChannelName2(chMaps.get(impList.get(i).getChannelCode2()).getChannelName());
//                if(chNumMap.containsKey(impList.get(i).getChannelCode2())){
//                    List<PhoneImportDto> channesList = chNumMap.get(impList.get(i).getChannelCode2());
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode2(),channesList);
//                }else{
//                    List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode2(),channesList);
//                }
//
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId1(), null,null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId2(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId2(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_2,1);
//            }else if(!Utils.isEmptyString(impList.get(i).getChannelCode1()) && !Utils.isEmptyString(impList.get(i).getChannelCode2()) && !Utils.isEmptyString(impList.get(i).getChannelCode3())){
//                //分配给三级渠道
//                if(Channels.CHANNEL_LEVEL_1.intValue() != chMaps.get(impList.get(i).getChannelCode1()).getChannelLevel().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode1()+ "不是一级代理商");
//                    return rtnMap;
//                }
//                if(Channels.CHANNEL_LEVEL_2.intValue() != chMaps.get(impList.get(i).getChannelCode2()).getChannelLevel().intValue()
//                        &&Channels.CHANNEL_TYPE_1.intValue() != chMaps.get(impList.get(i).getChannelCode2()).getChannelType().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode2()+ "不是二级代理商");
//                    return rtnMap;
//                }
//                if(Channels.CHANNEL_TYPE_2.intValue() != chMaps.get(impList.get(i).getChannelCode3()).getChannelType().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","渠道："+impList.get(i).getChannelCode3()+ "不是网点代理商");
//                    return rtnMap;
//                }
//                if(chMaps.get(impList.get(i).getChannelCode2()).getParentChannelId().intValue() != chMaps.get(impList.get(i).getChannelCode1()).getId().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","二级渠道："+impList.get(i).getChannelCode2()+ "不是一级代理商"+impList.get(i).getChannelCode1()+"的下属二级渠道");
//                    return rtnMap;
//                }
//                if(chMaps.get(impList.get(i).getChannelCode3()).getParentChannelId().intValue() != chMaps.get(impList.get(i).getChannelCode2()).getId().intValue()){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","三渠道："+impList.get(i).getChannelCode3()+ "不是二级代理商"+impList.get(i).getChannelCode2()+"的下属三级渠道");
//                    return rtnMap;
//                }
//                if(!chPacIsShow.get(impList.get(i).getChannelCode1()).contains(impList.get(i).getPackages())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+impList.get(i).getPhone()+"的套餐"+impList.get(i).getPackages()+"对渠道："+impList.get(i).getChannelCode1()+ "没有可见性不能进行分配");
//                    return rtnMap;
//                }
//
//                dto.setChannelId(chMaps.get(impList.get(i).getChannelCode3()).getId());
//                dto.setChannelName(chMaps.get(impList.get(i).getChannelCode3()).getChannelName());
//
//                impList.get(i).setChannelId(chMaps.get(impList.get(i).getChannelCode2()).getId());
//                impList.get(i).setChannelName(chMaps.get(impList.get(i).getChannelCode2()).getChannelName());
//                impList.get(i).setAllotType(CardInfoDto.allot_type_3);
//                impList.get(i).setChannelId1(chMaps.get(impList.get(i).getChannelCode1()).getId());
//                impList.get(i).setChannelCode1(chMaps.get(impList.get(i).getChannelCode1()).getChannelCode());
//                impList.get(i).setChannelName1(chMaps.get(impList.get(i).getChannelCode1()).getChannelName());
//
//                impList.get(i).setChannelId2(chMaps.get(impList.get(i).getChannelCode2()).getId());
//                impList.get(i).setChannelCode2(chMaps.get(impList.get(i).getChannelCode2()).getChannelCode());
//                impList.get(i).setChannelName2(chMaps.get(impList.get(i).getChannelCode2()).getChannelName());
//
//                impList.get(i).setChannelId3(chMaps.get(impList.get(i).getChannelCode3()).getId());
//                impList.get(i).setChannelCode3(chMaps.get(impList.get(i).getChannelCode3()).getChannelCode());
//                impList.get(i).setChannelName3(chMaps.get(impList.get(i).getChannelCode3()).getChannelName());
//                if(chNumMap.containsKey(impList.get(i).getChannelCode3())){
//                    List<PhoneImportDto> channesList = chNumMap.get(impList.get(i).getChannelCode3());
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode3(),channesList);
//                }else{
//                    List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
//                    channesList.add(impList.get(i));
//                    chNumMap.put(impList.get(i).getChannelCode3(),channesList);
//                }
//
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId1(), null,null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId2(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId3(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_1,1);
//                numberUtil.stockMapSet(stockMap, impList.get(i).getChannelId3(), chMaps.get(impList.get(i).getChannelCode1()).getId(),null, Stock.statistics_type_2,1);
//            }else{
//                //不进行分配，在总部
//                dto.setChannelId(0);
//                numberUtil.stockMapSet(stockMap, 0, null,null, Stock.statistics_type_2,1);
//            }
//
//            dto.setPackageCode(impList.get(i).getPackages());
//            dto.setPhone(impList.get(i).getPhone());
//            dto.setIccid(impList.get(i).getIccid());
//            dto.setImsi(impList.get(i).getImsi());
//            dto.setLevel(DicUtil.getNameKeyMap("PHONE_LEVEL_CODE").get(impList.get(i).getLevel()));
//            dto.setAscription(impList.get(i).getAscription());
//            if(Utils.isEmptyString(impList.get(i).getChannelCode1())){
//                dto.setStatus(TNumber.STATUS_WAIT_ALLOT);
//            }else{
//                dto.setStatus(TNumber.STATUS_WAIT_ACTIVATE);
//            }
//            dto.setMinFloat((new BigDecimal(impList.get(i).getMinFloat())).multiply(Constant.cnt100));
//            dto.setPrestore((new BigDecimal(impList.get(i).getPrestore())).multiply(Constant.cnt100));
//            dto.setValidTime(DateUtil.getInstance().parseDateException(impList.get(i).getValidity(), DateUtil.yyyy_MM_dd));
//            dto.setIsPre(impList.get(i).getIsPre());
//            numDtos.add(dto);
//        }
//        rtnMap.put("stat", true);
//        return rtnMap;
//    }
//
//
//    /**
//     * 预开户号码导入
//     * @param file
//     * @param importType
//     * @param request
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("unchecked")
//    public Map<String,Object> importPreFile(MultipartFile file,String importType,HttpServletRequest request) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        rtnMap.put("stat",true);
//        String fileExt= file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1).toLowerCase();//扩展名
//        Date dt = new Date();
//        String fileName = DateUtil.getInstance().getDateStr(dt,DateUtil.yyyyMMddHHmmss)+importType+"."+fileExt;
//        String filePatch = Constant.STOCK_IMPORT + File.separator + DateUtil.getInstance().getYear(dt) + File.separator + DateUtil.getInstance().getMonth(dt);
//        File upFile = new File(imageURL + File.separator +filePatch + File.separator + fileName);
//        if(!upFile.getParentFile().exists()){
//            upFile.getParentFile().mkdirs();
//        }
//        User us = SessionData.getInstance().getUser(request);
//        //上传文件
//        String rtStr = FileUtil.saveImageFile(file, imageURL, filePatch, fileName);
//        //调用Excel解析
//        Map<String,Object> map = importExcelService.GetObjInfOfExcel(upFile,fileExt,importType);
//        if(Utils.isEmptyString(map.get("errorBack").toString())){
//            List<PreImportDto> impList=(List<PreImportDto>)map.get("objTList");
//            if(null != impList && impList.size() >0){
//                //保存导入的数据
//                rtnMap = savePrePhoneMapImprt(impList, us, rtStr, upFile,file.getOriginalFilename());
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    upFile.delete();
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg",rtnMap.get("msg"));
//                }
//            }else{
//                upFile.delete();
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","请填写导入数据！");
//            }
//            importPreLog(us, impList.size());
//        }else{
//            upFile.delete();
//            rtnMap.put("stat",false);
//            rtnMap.put("msg",map.get("errorBack"));
//        }
//        return rtnMap;
//    }
//
//    /**
//     * 预开户号码导入
//     * @param us
//     */
//    public void importPreLog(User us,Integer dataNum){
//        try{
//            Map<String,String> logmap = new ConcurrentHashMap<String,String>();
//            logmap.put("staff", us.getLoginName());
//            logmap.put("dataNum", dataNum.toString());
//            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
//            logmap.put("result","成功！");
//            logService.businessSaveLog(Business.stock_phone_pre_import,String.valueOf(us.getId()),us.getLoginName(),"0","预开户号码导入",logmap);
//        }catch (Exception  e){
//            logger.error("号码库存导入日志记录错误：原因："+e.getMessage(),e);
//        }
//    }
//
//
//    /**
//     * 预开户号码导入数据校验入库
//     * @param impList
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("resource")
//    public Map<String,Object> savePrePhoneMapImprt(List<PreImportDto> impList,User us,String fileUrl,File file,String fileName) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        List<String> phoneList  = null;//号码
//        List<Integer> phoneIdList  = new ArrayList<Integer>();//号码id
//        List<String> iccidList = null;//Iccid
//        List<String> imsiList = null;//imsi
//        Date date = new Date();
//        List<PreSubs> pres = new ArrayList<PreSubs>();
//
//        //分批基础数据校验
//        Integer dataCount = impList.size();
//        int page = 0;//页数
//        int pageCount = 10000;
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                phoneList = new ArrayList<String>();//号码
//                iccidList = new ArrayList<String>();//Iccid
//                imsiList = new ArrayList<String>();//imsi
//                rtnMap = vaildPreCheck(start, end, impList,phoneList, iccidList, imsiList);
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    return rtnMap;
//                }
//                //数据库校验
//                rtnMap = vaildDataPreCheck(phoneList,phoneIdList);
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    return rtnMap;
//                }
//            }
//        }else {
//            phoneList = new ArrayList<String>();//号码
//            iccidList = new ArrayList<String>();//Iccid
//            imsiList = new ArrayList<String>();//imsi
//
//            rtnMap = vaildPreCheck(0, dataCount,impList,phoneList, iccidList, imsiList);
//            if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                return rtnMap;
//            }
//            //数据库校验
//            rtnMap = vaildDataPreCheck(phoneList,phoneIdList);
//            if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                return rtnMap;
//            }
//        }
//        phoneList.clear();
//        iccidList.clear();
//        imsiList.clear();
//
//        for(PreImportDto d:impList){
//            PreSubs n = new PreSubs();
//            n.setPhone(d.getPhone());
//            n.setIccid(d.getIccid());
//            n.setImsi(d.getImsi());
//            n.setServCode(d.getServCode());
//            n.setServName(d.getServName());
//            n.setAdvanceTime(DateUtil.getInstance().parseDateException(d.getAdvanceTime(), DateUtil.yyyy_MM_dd));
//            n.setSource(1);
//            n.setCreateId(us.getId());
//            n.setCreateTime(date);
//            n.setUpdateId(us.getId());
//            n.setUpdateTime(date);
//            pres.add(n);
//        }
//
//        //记录库存导入批次表
//        StockAllot stockAllot = new StockAllot();
//        stockAllot.setServType(StockAllot.serv_type_3);
//        stockAllot.setNum(impList.size());
//        stockAllot.setAllotType(StockAllot.allot_type_1);
//        stockAllot.setChannelIdFrom(0);
//        stockAllot.setChannelCodeFrom("0");
//        stockAllot.setChannelNameFrom(StockAllot.com_name);
//        stockAllot.setChannelIdTo(0);
//        stockAllot.setChannelCodeTo("0");
//        stockAllot.setChannelNameTo(StockAllot.com_name);
//        stockAllot.setCreateId(us.getId());
//        stockAllot.setCreateTime(date);
//        stockAllot.setUpdateId(us.getId());
//        stockAllot.setUpdateTime(date);
//        stockAllotMapper.insert(stockAllot);
//        //附件信息表入库
//        AttachFile af = new AttachFile();
//        af.setAttachName(fileName);
//        af.setAttachDesc("预开户号码导入附件");
//        af.setAttachUrl(fileUrl);
//        af.setAttrachType(0);
//        af.setSort(1);
//        FileInputStream fis= new FileInputStream(file);
//        FileChannel fc= fis.getChannel();
//        af.setSize(fc.size());
//        af.setSourceId(stockAllot.getId());
//        af.setSourceType("t_stock_allot");
//        af.setCreateTime(date);
//        af.setUpdateId(us.getId());
//        af.setUpdateTime(date);
//        attachFileMapper.insert(af);
//
//        //号码表分批修改状态
//        dataCount = phoneIdList.size();
//        page = 0;//页数
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                upPrePhone(phoneIdList, start, end);
//            }
//        }else {
//            upPrePhone(phoneIdList, 0, dataCount);
//        }
//
//        //预开户表分批入库
//        dataCount = pres.size();
//        page = 0;//页数
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                insertSavePrePhone(pres, start, end);
//            }
//        }else {
//            insertSavePrePhone(pres, 0, dataCount);
//        }
//
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//    /**
//     * 预开户号码分批入库
//     * @param pres
//     * @throws Exception
//     */
//    public void insertSavePrePhone(List<PreSubs> pres,int start,int end) throws Exception{
//        List<PreSubs> saveList = new ArrayList<PreSubs>();
//        for (int i = start; i < end; i++) {
//            saveList.add(pres.get(i));
//        }
//        preSubsMapper.batchInsert(saveList);
//    }
//
//    /**
//     * 号码表修改是否预开户
//     * @param ids
//     * @throws Exception
//     */
//    public void upPrePhone(List<Integer> ids,int start,int end) throws Exception{
//        List<Integer> saveList = new ArrayList<Integer>();
//        for (int i = start; i < end; i++) {
//            saveList.add(ids.get(i));
//        }
//        numMapper.upPrePhone(saveList);
//    }
//
//
//
//    /**
//     * 基础数据校验
//     * @param start
//     * @param end
//     * @param impList
//     * @param phoneList
//     * @param iccidList
//     * @param imsiList
//     * @return
//     * @throws Exception
//     */
//    public Map<String,Object> vaildPreCheck(int start, int end,List<PreImportDto> impList,List<String> phoneList,List<String> iccidList,List<String> imsiList) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        //基本数据校验
//        for (int i = start; i < end; i++) {
//            if(phoneList.contains(impList.get(i).getPhone())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            phoneList.add(impList.get(i).getPhone());
//
//            if(iccidList.contains(impList.get(i).getIccid())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","ICCID"+impList.get(i).getIccid()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            iccidList.add(impList.get(i).getIccid());
//
//
//            if(imsiList.contains(impList.get(i).getImsi())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","IMSI"+impList.get(i).getImsi()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            imsiList.add(impList.get(i).getImsi());
//
//            try{
//                DateUtil.getInstance().parseDateException(impList.get(i).getAdvanceTime(), DateUtil.yyyy_MM_dd);
//            }catch (Exception e){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+impList.get(i).getPhone()+"预开户时间格式不正确");
//                return rtnMap;
//            }
//        }
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//    /**
//     * 号码导入数据库校验
//     * @param phoneList
//     * @return
//     * @throws Exception
//     */
//    public Map<String,Object> vaildDataPreCheck(List<String> phoneList,List<Integer> phoneIdList) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        Map<String, Object> mapSearch = new ConcurrentHashMap<String, Object>();
//
//        mapSearch = new ConcurrentHashMap<String, Object>();
//        mapSearch.put("phones",phoneList);
//        List<TNumber> findPhoneList = numMapper.list(mapSearch);
//        if(null != findPhoneList && findPhoneList.size() >0){
//            Set<String> pacSet = new HashSet<String>();
//            for(TNumber p:findPhoneList){
//                pacSet.add(p.getPhone());
//                phoneIdList.add(p.getId());
//                if(TNumber.STATUS_FINISH_ACTIVATE.equals(p.getStatus()) || TNumber.STATUS_WAIT_FINISH.equals(p.getStatus())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码已开户："+p.getPhone()+ "不能再标记为预开户号码！");
//                    return rtnMap;
//                }
//            }
//            if(findPhoneList.size() != phoneList.size()){
//                StringBuffer errStr = new StringBuffer();
//                for(int i=0;i<phoneList.size();i++){
//                    if(!pacSet.contains(phoneList.get(i))){
//                        errStr.append(phoneList.get(i)).append(",");
//                    }
//                }
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码："+errStr.toString()+ "在系统中不存在");
//                return rtnMap;
//            }
//        }else{
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","所有号码在系统中不存在");
//            return rtnMap;
//        }
//
//        mapSearch = new ConcurrentHashMap<String, Object>();
//        mapSearch.put("phones",phoneList);
//        List<PreSubs> findPres = preSubsMapper.list(mapSearch);
//        if(null != findPres && findPres.size() >0){
//            StringBuffer errStr = new StringBuffer();
//            for(int i=0;i<findPres.size(); i++){
//                errStr.append(findPres.get(i).getImsi()).append(",");
//            }
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","号码："+errStr.toString()+ "在系统中已经是预开户号码");
//            return rtnMap;
//        }
//
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//
//    /**
//     * 号码信息分配导入
//     * @param file
//     * @param importType
//     * @param request
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("unchecked")
//    public Map<String,Object> importPhoneAllotFile(MultipartFile file,String importType,HttpServletRequest request) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        rtnMap.put("stat",true);
//        String fileExt= file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1).toLowerCase();//扩展名
//        Date dt = new Date();
//        String fileName = DateUtil.getInstance().getDateStr(dt,DateUtil.yyyyMMddHHmmss)+importType+"."+fileExt;
//        String filePatch = Constant.STOCK_ALLOT + File.separator + DateUtil.getInstance().getYear(dt) + File.separator + DateUtil.getInstance().getMonth(dt);
//        File upFile = new File(imageURL + File.separator +filePatch + File.separator + fileName);
//        if(!upFile.getParentFile().exists()){
//            upFile.getParentFile().mkdirs();
//        }
//        User us = SessionData.getInstance().getUser(request);
//        //上传文件
//        String rtStr = FileUtil.saveImageFile(file, imageURL, filePatch, fileName);
//        //调用Excel解析
//        Map<String,Object> map = importExcelService.GetObjInfOfExcel(upFile,fileExt,importType);
//        if(Utils.isEmptyString(map.get("errorBack").toString())){
//            List<PhoneImportDto> impList=(List<PhoneImportDto>)map.get("objTList");
//            if(null != impList && impList.size() >0){
//                //保存导入的数据
//                rtnMap = saveMapAllotImprt(impList, us, rtStr, upFile,importType,file.getOriginalFilename());
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    upFile.delete();
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg",rtnMap.get("msg"));
//                }
//            }else{
//                upFile.delete();
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","请填写导入数据！");
//            }
//            logService.importAllotLog(us, impList.size(),Business.stock_phone_allot);
//        }else{
//            upFile.delete();
//            rtnMap.put("stat",false);
//            rtnMap.put("msg",map.get("errorBack"));
//        }
//        return rtnMap;
//    }
//
//    /**
//     * 号码分配导入数据校验入库
//     * @param impList
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("resource")
//    public Map<String,Object> saveMapAllotImprt(List<PhoneImportDto> impList,User us,String fileUrl,File file,String importType,String fileName) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        List<String> phoneList  = null;//号码
//        List<String> chCodes = null;//channelCode
//        Map<String,List<PhoneImportDto>> chNumMap = new ConcurrentHashMap<String,List<PhoneImportDto>>();
//        List<TNumber> upNums = new ArrayList<TNumber>();//修改号码状态为待开户列表
//        List<String> upNumChList = new ArrayList<String>();//修改号码分配记录表状态，结构：phone_idchannel_id 的字符串
//        Map<Integer,StockNumDto> stockMap = new ConcurrentHashMap<Integer,StockNumDto>();  //总库存：渠道id  ，类型数量
//        Date date = new Date();//当前时间
//        Channels loginCh = channelsService.findChannelByUserId(us.getId());//当前登录渠道
//        //分批基础数据校验
//        Integer dataCount = impList.size();
//        int page = 0;//页数
//        int pageCount = 10000;
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                phoneList = new ArrayList<String>();//号码
//                chCodes = new ArrayList<String>();//渠道编号
//                rtnMap = numberUtil.vaildAllotCheck(start, end, impList,chCodes, phoneList,loginCh);
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    return rtnMap;
//                }
//                //数据库校验
//                rtnMap = numberUtil.vaildDataAllotCheck(start, end,chNumMap,upNumChList,upNums, stockMap,impList,chCodes,phoneList,loginCh,date,us);
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    return rtnMap;
//                }
//            }
//        }else {
//            phoneList = new ArrayList<String>();//号码
//            chCodes = new ArrayList<String>();//渠道编号
//            rtnMap = numberUtil.vaildAllotCheck(0, dataCount, impList,chCodes, phoneList,loginCh);
//            if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                return rtnMap;
//            }
//            //数据库校验
//            rtnMap = numberUtil.vaildDataAllotCheck(0, dataCount,chNumMap,upNumChList,upNums, stockMap,impList,chCodes,phoneList,loginCh,date,us);
//            if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                return rtnMap;
//            }
//        }
//        chCodes.clear();
//        phoneList.clear();
//
//        //库存信息入库
//        numberUtil.insertStock(stockMap,date,us);
//
//        //记录库存分配批次表
//        StockAllot stockAllot = new StockAllot();
//        stockAllot.setServType(StockAllot.serv_type_2);
//        stockAllot.setNum(impList.size());
//        stockAllot.setAllotType(StockAllot.allot_type_2);
//        if(null == loginCh){
//            stockAllot.setChannelIdFrom(0);
//            stockAllot.setChannelCodeFrom("0");
//            stockAllot.setChannelNameFrom(StockAllot.com_name);
//        }else {
//            stockAllot.setChannelIdFrom(loginCh.getId());
//            stockAllot.setChannelCodeFrom(loginCh.getChannelCode());
//            stockAllot.setChannelNameFrom(loginCh.getChannelName());
//        }
//        stockAllot.setCreateId(us.getId());
//        stockAllot.setCreateTime(date);
//        stockAllot.setUpdateId(us.getId());
//        stockAllot.setUpdateTime(date);
//        stockAllotMapper.insert(stockAllot);
//        //附件信息表入库
//        AttachFile af = new AttachFile();
//        af.setAttachName(fileName);
//        af.setAttachDesc("号码分配附件");
//        af.setAttachUrl(fileUrl);
//        af.setAttrachType(0);
//        af.setSort(1);
//        FileInputStream fis= new FileInputStream(file);
//        FileChannel fc= fis.getChannel();
//        af.setSize(fc.size());
//        af.setSourceId(stockAllot.getId());
//        af.setSourceType("t_stock_allot");
//        af.setCreateId(us.getId());
//        af.setCreateTime(date);
//        af.setUpdateId(us.getId());
//        af.setUpdateTime(date);
//        attachFileMapper.insert(af);
//
//        //录入批次表和库存表信息  有进行分配的时候
//        List<NumberChannel> numChs = new ArrayList<NumberChannel>();//入库数据list
//        if(chNumMap.keySet().size() > 0){
//            numberUtil.saveImportData(numChs,chNumMap,us,date,importType);
//        }
//        //号码分配记录表分批入库
//        dataCount = numChs.size();
//        page = 0;//页数
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                insertSaveNumChannel(numChs, start, end);
//            }
//        }else {
//            insertSaveNumChannel(numChs, 0, dataCount);
//        }
//
//        if(upNumChList.size() > 0){
//            //号码分配记录表分批入库
//            dataCount = upNumChList.size();
//            page = 0;//页数
//            if(dataCount > pageCount){
//                if(dataCount%pageCount !=0){
//                    page = dataCount/pageCount +1;
//                }else{
//                    page = dataCount/pageCount;
//                }
//                int start=0,end=0;
//                for (int i = 1; i <= page; i++) {
//                    if (i * pageCount > dataCount) {
//                        end = dataCount;
//                    } else {
//                        end = i * pageCount;
//                    }
//                    if (i == 1) {
//                        start = i - 1;
//                    } else {
//                        start = (i - 1) * pageCount;
//                    }
//                    updateNumChannel(upNumChList,start, end);
//                }
//            }else {
//                updateNumChannel(upNumChList, 0, dataCount);
//            }
//        }
//
//        //修改号码状态和号码当前渠道id
//        dataCount = upNums.size();
//        page = 0;//页数
//        if(dataCount > pageCount){
//            if(dataCount%pageCount !=0){
//                page = dataCount/pageCount +1;
//            }else{
//                page = dataCount/pageCount;
//            }
//            int start=0,end=0;
//            for (int i = 1; i <= page; i++) {
//                if (i * pageCount > dataCount) {
//                    end = dataCount;
//                } else {
//                    end = i * pageCount;
//                }
//                if (i == 1) {
//                    start = i - 1;
//                } else {
//                    start = (i - 1) * pageCount;
//                }
//                numberUtil.updateNum(upNums, start, end);
//            }
//        }else {
//            numberUtil.updateNum(upNums, 0, dataCount);
//        }
//
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//    
//    /**
//     * 号码分配记录分批入库
//     * @param numChs
//     * @throws Exception
//     */
//    public void insertSaveNumChannel(List<NumberChannel> numChs,int start,int end) throws Exception{
//        List<NumberChannel> saveList = new ArrayList<NumberChannel>();
//        for (int i = start; i < end; i++) {
//            saveList.add(numChs.get(i));
//        }
//        numChMapper.batchInsert(saveList);
//    }
//
//    /**
//     * 号码分配记录修改状态
//     * @param numChIds
//     * @throws Exception
//     */
//    public void updateNumChannel(List<String> numChIds,int start,int end) throws Exception{
//        List<String> saveList = new ArrayList<String>();
//        for (int i = start; i < end; i++) {
//            saveList.add(numChIds.get(i));
//        }
//        numChMapper.batchUpdateStatus2(saveList);
//    }
//
//    
//    
//
//    //获取号码分配记录
//    /*private NumberChannel getNumCh(TNumber nu,Integer chId,Integer parchId,Integer status,Date date,User us){
//        NumberChannel nc = new NumberChannel();
//        nc.setPhoneId(nu.getId());
//        nc.setMoney(nu.getMoney());
//        nc.setParChannelId(parchId);
//        nc.setChannelId(chId);
//        nc.setStatus(status);
//        nc.setCreateId(us.getId());
//        nc.setCreateTime(date);
//        nc.setUpdateId(us.getId());
//        nc.setUpdateTime(date);
//        return nc;
//    }*/
//
//
//    
//    
//    /**
//     * 号码库存回收导入
//     * @param file
//     * @param importType
//     * @param request
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("unchecked")
//    public Map<String,Object> takeBackImport(MultipartFile file,String importType,HttpServletRequest request) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        rtnMap.put("stat",true);
//        String fileExt= file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1).toLowerCase();//扩展名
//        Date dt = new Date();
//        String fileName = DateUtil.getInstance().getDateStr(dt,DateUtil.yyyyMMddHHmmss)+importType+"."+fileExt;
//        String filePatch = Constant.STOCK_TAKE_BACK + File.separator;
//        File upFile = new File(imageURL + File.separator  +filePatch + File.separator + fileName);
//        if(!upFile.getParentFile().exists()){
//            upFile.getParentFile().mkdirs();
//        }
//        User us = SessionData.getInstance().getUser(request);
//        //上传文件
//        String rtStr = FileUtil.saveImageFile(file, imageURL, filePatch, fileName);
//        //调用Excel解析
//        Map<String,Object> map = importExcelService.GetObjInfOfExcel(upFile,fileExt,importType);
//        if(Utils.isEmptyString(map.get("errorBack").toString())){
//            List<PhoneImportDto> impList=(List<PhoneImportDto>)map.get("objTList");
//            if(null != impList && impList.size() >0){
//                //保存导入的数据
//                rtnMap = saveMapTakeBackImprt(impList,us , rtStr, upFile,file.getOriginalFilename());
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    upFile.delete();
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg",rtnMap.get("msg"));
//                }
//            }else{
//                upFile.delete();
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","请填写导入数据！");
//            }
//            logService.takeBackImportLog(us,impList.size(),Business.stock_phone_back);
//        }else{
//            upFile.delete();
//            rtnMap.put("stat",false);
//            rtnMap.put("msg",map.get("errorBack"));
//        }
//        return rtnMap;
//    }
//
//    /**
//     * 号码回收导入入库
//     * @param impList
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("resource")
//    public Map<String,Object> saveMapTakeBackImprt(List<PhoneImportDto> impList,User us,String fileUrl,File file,String fileName) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        Map<String,Object> searchMap = new ConcurrentHashMap<String,Object>();
//        List<String> phoneList = new ArrayList<String>();
//        Map<Integer,StockNumDto> stockMap = new ConcurrentHashMap<Integer,StockNumDto>();  //总库存：渠道id <商品id，类型数量>
//        Map<Integer,Integer> chPhoneNum = new ConcurrentHashMap<Integer,Integer>();//各渠道回收数量
//        Date date = new Date(); //当前时间
//        List<TNumber> tns = new ArrayList<TNumber>(); //号码表修改
//        List<TNumberHis> tnhis = new ArrayList<TNumberHis>(); //号码历史表修改
//        List<String> delNumChs = new ArrayList<String>();//删除分配记录表信息
//        List<String> upNumChs = new ArrayList<String>();//修改分配记录表信息
//        Channels loginCh = channelsService.findChannelByUserId(us.getId()); //当前登录渠道
//
//        Set<Integer> lowerCId = new HashSet<Integer>();//当前登录渠道的下级id
//        Map<Integer,Channels> lowerCIdMap = new ConcurrentHashMap<Integer,Channels>();//当前登录渠道的下级id
//        if(null != loginCh){
//            searchMap = new ConcurrentHashMap<String,Object>();
//            searchMap.put("parentChannelId",loginCh.getId());
//            List<Channels> channelsList = channelsService.listChannels(searchMap);
//            if(channelsList != null && channelsList.size() >0){
//                for(Channels c:channelsList){
//                    lowerCId.add(c.getId());
//                    lowerCIdMap.put(c.getId(),c);
//                }
//            }
//        }else{
//            searchMap = new ConcurrentHashMap<String,Object>();
//            searchMap.put("channelLevelEq","1");
//            List<Channels> channelsList = channelsService.listChannels(searchMap);
//            if(channelsList != null && channelsList.size() >0){
//                for(Channels c:channelsList){
//                    lowerCId.add(c.getId());
//                    lowerCIdMap.put(c.getId(),c);
//                }
//            }
//        }
//
//        //数据校验
//        for(PhoneImportDto dto:impList){
//            if(phoneList.contains(dto.getPhone())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+dto.getPhone()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            phoneList.add(dto.getPhone());
//        }
//        if(null == loginCh){
//            searchMap.put("allChannelId",0);
//        }else{
//            searchMap.put("allChannelId",loginCh.getId());
//        }
//        searchMap.put("phones",phoneList);
//        List<NumberDTO> oldNums = numMapper.numPreList(searchMap); //查询号码信息
//        if(null != oldNums && oldNums.size() >0){
//            Set<String> pacSet = new HashSet<String>();
//            for(TNumber p:oldNums){
//                pacSet.add(p.getPhone());
//            }
//            if(phoneList.size() != oldNums.size()){
//                StringBuffer errStr = new StringBuffer();
//                for(int i=0;i<phoneList.size();i++){
//                    if(!pacSet.contains(phoneList.get(i))){
//                        errStr.append(phoneList.get(i)).append(",");
//                    }
//                }
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码："+errStr.toString()+ "在系统中不存在");
//                return rtnMap;
//            }
//            
//            for(NumberDTO d:oldNums){
//                TNumberHis ths = new TNumberHis();
//                BeanUtils.copyProperties(ths, d);
//                ths.setOptionType("1");
//                ths.setOptionTime(date);
//                tnhis.add(ths);
//
//                if(TNumber.STATUS_FINISH_ACTIVATE.equals(d.getStatus()) 
//                        || TNumber.STATUS_WAIT_FINISH.equals(d.getStatus()) 
//                        || TNumber.CHECK_STATUS_1.equals(d.getCheckStatus())
//                        || TNumber.CHECK_STATUS_3.equals(d.getCheckStatus())){
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg","号码"+d.getPhone()+"当前状态不可回收");
//                    return rtnMap;
//                }
//                if(chPhoneNum.containsKey(d.getChannelId())){
//                    chPhoneNum.put(d.getChannelId(),chPhoneNum.get(d.getChannelId())+1);
//                }else{
//                    chPhoneNum.put(d.getChannelId(),1);
//                }
//                
//                TNumber tn = new TNumber();
//                tn.setStatus(TNumber.STATUS_WAIT_ALLOT);
//                tn.setId(d.getId());
//                tn.setUpdateId(us.getId());
//                tn.setUpdateTime(date);
//
//                delNumChs.add(d.getId()+""+d.getChannelId());
//
//                //总部回收
//                if(null == loginCh){
//                    tn.setChannelId(0);
//                    if(null == d.getChannelId()){
//                        rtnMap.put("stat",false);
//                        rtnMap.put("msg","号码"+d.getPhone()+"当前属于总部不能回收");
//                        return rtnMap;
//                    }
//                    if(0 == d.getChannelId().intValue()){
//                        rtnMap.put("stat",false);
//                        rtnMap.put("msg","号码"+d.getPhone()+"当前属于总部不能回收");
//                        return rtnMap;
//                    }
//                    if(Channels.CHANNEL_LEVEL_1.intValue() != d.getChannelLevel().intValue()){
//                        rtnMap.put("stat",false);
//                        rtnMap.put("msg","号码"+d.getPhone()+"当前不归属一级代理商，不能进行回收");
//                        return rtnMap;
//                    }
//                    numberUtil.stockMapSet(stockMap, 0, null,null, Stock.statistics_type_2, 1);
//                    numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_1, -1);
//                    numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_2, -1);
//                    d.setChannelId(0);
//                }else{
//                    tn.setChannelId(loginCh.getId());
//                    tn.setChannelName(loginCh.getChannelName());
//                    tn.setStatus(TNumber.STATUS_WAIT_ACTIVATE);
//
//                    upNumChs.add(d.getId()+""+loginCh.getId());
//
//                    numberUtil.stockMapSet(stockMap, loginCh.getId(), null, null, Stock.statistics_type_2, 1);
//                    numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_1, -1);
//                    numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_2, -1);
//
//                    //一级回收
//                    if(Channels.CHANNEL_LEVEL_1.intValue() == loginCh.getChannelLevel().intValue()){
//                        if(null == d.getChannelId()){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前属于总部不能回收");
//                            return rtnMap;
//                        }
//                        if(0 == d.getChannelId().intValue()){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前属于总部不能回收");
//                            return rtnMap;
//                        }
//                        if(Channels.CHANNEL_LEVEL_2.intValue() != d.getChannelLevel().intValue()){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前不归属二级代理商，不能进行回收");
//                            return rtnMap;
//                        }
//                        if(!lowerCId.contains(d.getChannelId())){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前归属代理商不是您的下属代理商，不能进行回收");
//                            return rtnMap;
//                        }
//                    }
//                    //二级回收
//                    if(Channels.CHANNEL_LEVEL_2.intValue() == loginCh.getChannelLevel().intValue()){
//                        if(null == d.getChannelId()){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前属于总部不能回收");
//                            return rtnMap;
//                        }
//                        if(0 == d.getChannelId().intValue()){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前属于总部不能回收");
//                            return rtnMap;
//                        }
//                        if(Channels.CHANNEL_LEVEL_3.intValue() != d.getChannelLevel().intValue()){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前不归属三级代理商，不能进行回收");
//                            return rtnMap;
//                        }
//                        if(!lowerCId.contains(d.getChannelId())){
//                            rtnMap.put("stat",false);
//                            rtnMap.put("msg","号码"+d.getPhone()+"当前归属代理商不是您的下属代理商，不能进行回收");
//                            return rtnMap;
//                        }
//                    }
//                }
//                tns.add(tn);
//            }
//        }else{
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","所有号码在系统中不存在");
//            return rtnMap;
//        }
//
//        //库存信息入库
//        numberUtil.insertStock(stockMap, date, us);
//
//        //记录库存导入批次表
//        List<StockAllot> stockAllots = new ArrayList<StockAllot>();
//        StockAllot stockAllot = new StockAllot();
//        stockAllot.setServType(StockAllot.serv_type_2);
//        stockAllot.setNum(impList.size());
//        stockAllot.setAllotType(StockAllot.allot_type_3);
//        if(null == loginCh){
//            stockAllot.setChannelIdFrom(0);
//            stockAllot.setChannelCodeFrom("0");
//            stockAllot.setChannelNameFrom(StockAllot.com_name);
//        }else {
//            stockAllot.setChannelIdFrom(loginCh.getId());
//            stockAllot.setChannelCodeFrom(loginCh.getChannelCode());
//            stockAllot.setChannelNameFrom(loginCh.getChannelName());
//        }
//        stockAllot.setCreateId(us.getId());
//        stockAllot.setCreateTime(date);
//        stockAllot.setUpdateId(us.getId());
//        stockAllot.setUpdateTime(date);
//        stockAllotMapper.insert(stockAllot);
//
//        //附件信息表入库
//        AttachFile af = new AttachFile();
//        af.setAttachName(fileName);
//        af.setAttachDesc("号码回收附件");
//        af.setAttachUrl(fileUrl);
//        af.setAttrachType(0);
//        af.setSort(1);
//        FileInputStream fis= new FileInputStream(file);
//        FileChannel fc= fis.getChannel();
//        af.setSize(fc.size());
//        af.setSourceId(stockAllot.getId());
//        af.setSourceType("t_stock_allot");
//        af.setCreateId(us.getId());
//        af.setCreateTime(date);
//        af.setUpdateId(us.getId());
//        af.setUpdateTime(date);
//        attachFileMapper.insert(af);
//
//        for(Integer s:chPhoneNum.keySet()){
//            stockAllot = new StockAllot();
//            stockAllot.setServType(StockAllot.serv_type_2);
//            stockAllot.setNum(chPhoneNum.get(s));
//            stockAllot.setAllotType(StockAllot.allot_type_3);
//            if(null == loginCh){
//                stockAllot.setChannelIdFrom(lowerCIdMap.get(s).getId());
//                stockAllot.setChannelCodeFrom(lowerCIdMap.get(s).getChannelCode());
//                stockAllot.setChannelNameFrom(lowerCIdMap.get(s).getChannelName());
//                stockAllot.setChannelIdTo(0);
//                stockAllot.setChannelCodeTo("0");
//                stockAllot.setChannelNameTo(StockAllot.com_name);
//            }else {
//                stockAllot.setChannelIdFrom(lowerCIdMap.get(s).getId());
//                stockAllot.setChannelCodeFrom(lowerCIdMap.get(s).getChannelCode());
//                stockAllot.setChannelNameFrom(lowerCIdMap.get(s).getChannelName());
//                stockAllot.setChannelIdTo(loginCh.getId());
//                stockAllot.setChannelCodeTo(loginCh.getChannelCode());
//                stockAllot.setChannelNameTo(loginCh.getChannelName());
//            }
//            stockAllot.setCreateId(us.getId());
//            stockAllot.setCreateTime(date);
//            stockAllot.setUpdateId(us.getId());
//            stockAllot.setUpdateTime(date);
//            stockAllots.add(stockAllot);
//        }
//        stockAllotMapper.batchInsert(stockAllots);
//        //号码表修改
//        numberUtil.updateNum(tns, 0, tns.size());
//
//        //分配记录表修改数据
//        if(null != upNumChs && upNumChs.size()>0){
//            numChMapper.batchUpdateStatus1(upNumChs);
//        }
//
//        //分配记录表删除数据
//        if(null != delNumChs && delNumChs.size()>0){
//            numChMapper.batchDelPidAndCid(delNumChs);
//        }
//        numHisMapper.batchInsert(tnhis);
//
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//
//
//
//    /**
//     * 库存下架导入
//     * @param file
//     * @param importType
//     * @param request
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("unchecked")
//    public Map<String,Object> stockDelImport(MultipartFile file,String importType,HttpServletRequest request) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        rtnMap.put("stat",true);
//        String fileExt= file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1).toLowerCase();//扩展名
//        Date dt = new Date();
//        String fileName = DateUtil.getInstance().getDateStr(dt,DateUtil.yyyyMMddHHmmss)+importType+"."+fileExt;
//        String filePatch = Constant.PHONE_DEL + File.separator;
//        File upFile = new File(imageURL  + File.separator +filePatch + File.separator + fileName);
//        if(!upFile.getParentFile().exists()){
//            upFile.getParentFile().mkdirs();
//        }
//        User us = SessionData.getInstance().getUser(request);
//        //上传文件
//        String rtStr = FileUtil.saveImageFile(file, imageURL, filePatch, fileName);
//        //调用Excel解析
//        Map<String,Object> map = importExcelService.GetObjInfOfExcel(upFile,fileExt,importType);
//        if(Utils.isEmptyString(map.get("errorBack").toString())){
//            List<PhoneImportDto> impList=(List<PhoneImportDto>)map.get("objTList");
//            if(null != impList && impList.size() >0){
//                //保存导入的数据
//                rtnMap = stockDelImprt(impList, us, rtStr, upFile,file.getOriginalFilename());
//                if("false".equals(String.valueOf(rtnMap.get("stat")))){
//                    upFile.delete();
//                    rtnMap.put("stat",false);
//                    rtnMap.put("msg",rtnMap.get("msg"));
//                }
//            }else{
//                upFile.delete();
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","请填写导入数据！");
//            }
//            stockDelImportLog(us,impList.size());
//        }else{
//            upFile.delete();
//            rtnMap.put("stat",false);
//            rtnMap.put("msg",map.get("errorBack"));
//        }
//        return rtnMap;
//    }
//
//    /**
//     * 库存下架
//     * @param us
//     */
//    public void stockDelImportLog(User us,Integer dataNum){
//        try{
//            Map<String,String> logmap = new ConcurrentHashMap<String,String>();
//            logmap.put("staff", us.getLoginName());
//            logmap.put("dataNum", dataNum.toString());
//            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
//            logmap.put("result","成功！");
//            logService.businessSaveLog(Business.stock_phone_del,String.valueOf(us.getId()),us.getLoginName(),"0","库存下架",logmap);
//        }catch (Exception  e){
//            logger.error("库存下架记录日志记录错误：原因："+e.getMessage(),e);
//        }
//    }
//    /**
//     * 卡密下架导入入库
//     * @param impList
//     * @return
//     * @throws Exception
//     */
//    @SuppressWarnings("resource")
//    public Map<String,Object> stockDelImprt(List<PhoneImportDto> impList,User us,String fileUrl,File file,String fileName) throws Exception{
//        Map<String,Object> rtnMap = new ConcurrentHashMap<String,Object>();
//        List<String> phoneList = new ArrayList<String>();
//        List<Integer> phoneIdList = new ArrayList<Integer>();
//        List<Integer> delNumCh = new ArrayList<Integer>();
//        List<TNumberHis> tnhis = new ArrayList<TNumberHis>(); //号码历史表修改
//        Map<Integer,Integer> chPhoneNum = new ConcurrentHashMap<Integer,Integer>();//各渠道回收数量
//        Date date = new Date();//当前时间
//        Map<Integer,StockNumDto> stockMap = new ConcurrentHashMap<Integer,StockNumDto>();  //总库存：渠道id <是否预开户1-是0否，类型数量>
//        Map<Integer,Channels> chMap = new ConcurrentHashMap<Integer,Channels>();
//        List<String> prePhones = new ArrayList<String>();//预开户信息删除
//
//        //数据校验
//        for(PhoneImportDto dto:impList){
//            if(phoneList.contains(dto.getPhone())){
//                rtnMap.put("stat",false);
//                rtnMap.put("msg","号码"+dto.getPhone()+"在上传文件中有重复");
//                return rtnMap;
//            }
//            phoneList.add(dto.getPhone());
//        }
//
//        Map<String,Object> mapSearch = new ConcurrentHashMap<String, Object>();
//        mapSearch.put("allChannelId",0);
//        mapSearch.put("phones",phoneList);
//        List<NumberDTO> oldNums = numMapper.numPreList(mapSearch); //查询号码信息
//        if(null != oldNums && oldNums.size() >0){
//            if(phoneList.size() != oldNums.size()){
//                Set<String> phoneSet = new HashSet<String>();
//                for(TNumber c:oldNums){
//                    phoneSet.add(c.getPhone());
//                }
//                for (String p:phoneList){
//                    if(!phoneSet.contains(p)){
//                        rtnMap.put("stat", false);
//                        rtnMap.put("msg","号码"+p+"在系统中不存在！");
//                        return rtnMap;
//                    }
//                }
//            }
//            for(NumberDTO d:oldNums) {
//                if("1".equals(d.getIsPre())){
//                    prePhones.add(d.getPhone());
//                }
//                TNumberHis ths = new TNumberHis();
//                BeanUtils.copyProperties(ths, d);
//                ths.setOptionType("1");
//                ths.setOptionTime(date);
//                tnhis.add(ths);
//
//                phoneIdList.add(d.getId());
//
//                if (TNumber.STATUS_FINISH_ACTIVATE.equals(d.getStatus())
//                        || TNumber.STATUS_WAIT_FINISH.equals(d.getStatus())
//                        || TNumber.CHECK_STATUS_1.equals(d.getCheckStatus())) {
//                    rtnMap.put("stat", false);
//                    rtnMap.put("msg", "号码" + d.getPhone() + "当前状态不可下架");
//                    return rtnMap;
//                }
//                if (chPhoneNum.containsKey(d.getChannelId())) {
//                    chPhoneNum.put(d.getChannelId(), chPhoneNum.get(d.getChannelId()) + 1);
//                } else {
//                    chPhoneNum.put(d.getChannelId(), 1);
//                }
//
//                numberUtil.stockMapSet(stockMap, 0, null, null,  Stock.statistics_type_1, -1);
//                if (0 == d.getChannelId().intValue()) {
//                    numberUtil.stockMapSet(stockMap, 0, null, null,  Stock.statistics_type_2, -1);
//                } else {
//                    delNumCh.add(d.getId());
//                    if(!chMap.containsKey(d.getChannelId())){
//                        Channels ch = new Channels();
//                        ch.setId(d.getChannelId());
//                        ch.setChannelCode(d.getChannelCode());
//                        ch.setChannelName(d.getChannelName());
//                        ch.setChannelIdLevel1(d.getChannelPar1Id());
//                        ch.setChannelIdLevel2(d.getChannelPar2Id());
//                        ch.setChannelLevel(d.getChannelLevel());
//                        chMap.put(d.getChannelId(),ch);
//                    }
//                    if(d.getChannelPar1Id() != null && !chMap.containsKey(d.getChannelPar1Id())){
//                        Channels ch = new Channels();
//                        ch.setId(d.getChannelPar1Id());
//                        ch.setChannelCode(d.getChannelPar1Code());
//                        ch.setChannelName(d.getChannelPar1Name());
//                        ch.setChannelLevel(1);
//                        chMap.put(d.getChannelPar1Id(),ch);
//                    }
//                    if(d.getChannelPar2Id() != null && !chMap.containsKey(d.getChannelPar2Id())){
//                        Channels ch = new Channels();
//                        ch.setId(d.getChannelPar2Id());
//                        ch.setChannelCode(d.getChannelPar2Code());
//                        ch.setChannelName(d.getChannelPar2Name());
//                        ch.setChannelIdLevel1(d.getChannelPar1Id());
//                        ch.setChannelLevel(2);
//                        chMap.put(d.getChannelPar2Id(),ch);
//                    }
//                    if (Channels.CHANNEL_LEVEL_1.intValue() == d.getChannelLevel().intValue()) {
//                        numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_1, -1);
//                        numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_2, -1);
//                    } else if (Channels.CHANNEL_LEVEL_2.intValue() == d.getChannelLevel().intValue()) {
//                        numberUtil.stockMapSet(stockMap, d.getChannelPar1Id(), null, null, Stock.statistics_type_1, -1);
//                        numberUtil.stockMapSet(stockMap, d.getChannelId(), d.getChannelPar1Id(), null, Stock.statistics_type_1, -1);
//                        numberUtil.stockMapSet(stockMap, d.getChannelId(), d.getChannelPar1Id(), null, Stock.statistics_type_2, -1);
//                    } else if (Channels.CHANNEL_LEVEL_3.intValue() == d.getChannelLevel().intValue()) {
//                        numberUtil.stockMapSet(stockMap, d.getChannelPar1Id(), null, null, Stock.statistics_type_1, -1);
//                        numberUtil.stockMapSet(stockMap, d.getChannelPar2Id(), null, null, Stock.statistics_type_1, -1);
//                        numberUtil.stockMapSet(stockMap, d.getChannelId(), d.getChannelPar1Id(), d.getChannelPar2Id(), Stock.statistics_type_1, -1);
//                        numberUtil.stockMapSet(stockMap, d.getChannelId(), d.getChannelPar1Id(), d.getChannelPar2Id(), Stock.statistics_type_2, -1);
//                    }
//                }
//            }
//        }else{
//            rtnMap.put("stat",false);
//            rtnMap.put("msg","导入所有号码都不在系统中");
//            return rtnMap;
//        }
//
//        //库存信息入库
//        numberUtil.insertStock(stockMap, date, us);
//
//        //记录库存导入批次表
//        StockAllot stockAllot = new StockAllot();
//        stockAllot.setServType(StockAllot.serv_type_2);
//        stockAllot.setNum(impList.size());
//        stockAllot.setAllotType(StockAllot.allot_type_5);
//        stockAllot.setChannelIdFrom(0);
//        stockAllot.setChannelCodeFrom("0");
//        stockAllot.setChannelNameFrom(StockAllot.com_name);
//        stockAllot.setCreateId(us.getId());
//        stockAllot.setCreateTime(date);
//        stockAllot.setUpdateId(us.getId());
//        stockAllot.setUpdateTime(date);
//        stockAllotMapper.insert(stockAllot);
//        //附件信息表入库
//        AttachFile af = new AttachFile();
//        af.setAttachName(fileName);
//        af.setAttachDesc("号码下架附件");
//        af.setAttachUrl(fileUrl);
//        af.setAttrachType(0);
//        af.setSort(1);
//        FileInputStream fis= new FileInputStream(file);
//        FileChannel fc= fis.getChannel();
//        af.setSize(fc.size());
//        af.setSourceId(stockAllot.getId());
//        af.setSourceType("t_stock_allot");
//        af.setCreateId(us.getId());
//        af.setCreateTime(date);
//        af.setUpdateId(us.getId());
//        af.setUpdateTime(date);
//        attachFileMapper.insert(af);
//
//        List<StockAllot> stockAllots = new ArrayList<StockAllot>();
//        for(Integer s:chPhoneNum.keySet()){
//            if( 0 !=s.intValue()){
//                //当前渠道下架
//                stockAllot = new StockAllot();
//                stockAllot.setServType(StockAllot.serv_type_2);
//                stockAllot.setNum(chPhoneNum.get(s));
//                stockAllot.setAllotType(StockAllot.allot_type_5);
//                stockAllot.setChannelIdFrom(0 == s.intValue() ? 0 : chMap.get(s).getId());
//                stockAllot.setChannelCodeFrom(0 == s.intValue() ? "0" : chMap.get(s).getChannelCode());
//                stockAllot.setChannelNameFrom(0 == s.intValue() ? StockAllot.com_name : chMap.get(s).getChannelName());
//                stockAllot.setChannelIdTo(0);
//                stockAllot.setChannelCodeTo("0");
//                stockAllot.setChannelNameTo(StockAllot.com_name);
//                stockAllot.setCreateId(us.getId());
//                stockAllot.setCreateTime(date);
//                stockAllot.setUpdateId(us.getId());
//                stockAllot.setUpdateTime(date);
//                stockAllots.add(stockAllot);
//
//                if(Channels.CHANNEL_LEVEL_1.intValue() == chMap.get(s).getChannelLevel().intValue()){
//                    //一级无上级
//                }else if(Channels.CHANNEL_LEVEL_2.intValue() == chMap.get(s).getChannelLevel().intValue()){
//                    //当前二级，增加一级下架记录
//                    stockAllot = new StockAllot();
//                    stockAllot.setServType(StockAllot.serv_type_2);
//                    stockAllot.setNum(chPhoneNum.get(s));
//                    stockAllot.setAllotType(StockAllot.allot_type_5);
//                    stockAllot.setChannelIdFrom(chMap.get(chMap.get(s).getChannelIdLevel1()).getId());
//                    stockAllot.setChannelCodeFrom(chMap.get(chMap.get(s).getChannelIdLevel1()).getChannelCode());
//                    stockAllot.setChannelNameFrom(chMap.get(chMap.get(s).getChannelIdLevel1()).getChannelName());
//                    stockAllot.setChannelIdTo(0);
//                    stockAllot.setChannelCodeTo("0");
//                    stockAllot.setChannelNameTo(StockAllot.com_name);
//                    stockAllot.setCreateId(us.getId());
//                    stockAllot.setCreateTime(date);
//                    stockAllot.setUpdateId(us.getId());
//                    stockAllot.setUpdateTime(date);
//                    stockAllots.add(stockAllot);
//                }else{
//                    //当前三级，增加二级，一级下级记录
//                    stockAllot = new StockAllot();
//                    stockAllot.setServType(StockAllot.serv_type_2);
//                    stockAllot.setNum(chPhoneNum.get(s));
//                    stockAllot.setAllotType(StockAllot.allot_type_5);
//                    stockAllot.setChannelIdFrom(chMap.get(chMap.get(s).getChannelIdLevel1()).getId());
//                    stockAllot.setChannelCodeFrom(chMap.get(chMap.get(s).getChannelIdLevel1()).getChannelCode());
//                    stockAllot.setChannelNameFrom(chMap.get(chMap.get(s).getChannelIdLevel1()).getChannelName());
//                    stockAllot.setChannelIdTo(0);
//                    stockAllot.setChannelCodeTo("0");
//                    stockAllot.setChannelNameTo(StockAllot.com_name);
//                    stockAllot.setCreateId(us.getId());
//                    stockAllot.setCreateTime(date);
//                    stockAllot.setUpdateId(us.getId());
//                    stockAllot.setUpdateTime(date);
//                    stockAllots.add(stockAllot);
//
//                    stockAllot = new StockAllot();
//                    stockAllot.setServType(StockAllot.serv_type_2);
//                    stockAllot.setNum(chPhoneNum.get(s));
//                    stockAllot.setAllotType(StockAllot.allot_type_5);
//                    stockAllot.setChannelIdFrom(chMap.get(chMap.get(s).getChannelIdLevel2()).getId());
//                    stockAllot.setChannelCodeFrom(chMap.get(chMap.get(s).getChannelIdLevel2()).getChannelCode());
//                    stockAllot.setChannelNameFrom(chMap.get(chMap.get(s).getChannelIdLevel2()).getChannelName());
//                    stockAllot.setChannelIdTo(0);
//                    stockAllot.setChannelCodeTo("0");
//                    stockAllot.setChannelNameTo(StockAllot.com_name);
//                    stockAllot.setCreateId(us.getId());
//                    stockAllot.setCreateTime(date);
//                    stockAllot.setUpdateId(us.getId());
//                    stockAllot.setUpdateTime(date);
//                    stockAllots.add(stockAllot);
//                }
//            }
//            stockAllot = new StockAllot();
//            stockAllot.setServType(StockAllot.serv_type_2);
//            stockAllot.setNum(chPhoneNum.get(s));
//            stockAllot.setAllotType(StockAllot.allot_type_5);
//            stockAllot.setChannelIdFrom(0);
//            stockAllot.setChannelCodeFrom("0");
//            stockAllot.setChannelNameFrom(0 == s.intValue() ? StockAllot.com_name : chMap.get(s).getChannelName());
//            stockAllot.setChannelIdTo(0);
//            stockAllot.setChannelCodeTo("0");
//            stockAllot.setChannelNameTo(StockAllot.com_name);
//            stockAllot.setCreateId(us.getId());
//            stockAllot.setCreateTime(date);
//            stockAllot.setUpdateId(us.getId());
//            stockAllot.setUpdateTime(date);
//            stockAllots.add(stockAllot);
//        }
//        stockAllotMapper.batchInsert(stockAllots);
//        //删除号码表
//        numMapper.batchDelById(phoneIdList);
//        //分配记录表删除数据
//        if(null != delNumCh && delNumCh.size() >0){
//            numChMapper.batchDelByPhoneId(delNumCh);
//        }
//        //记录下架历史表
//        numHisMapper.batchInsert(tnhis);
//
//        if(prePhones.size() >0){
//            preSubsMapper.deleteSubsByPhoneList(prePhones);
//        }
//
//        rtnMap.put("stat",true);
//        return rtnMap;
//    }
//}
