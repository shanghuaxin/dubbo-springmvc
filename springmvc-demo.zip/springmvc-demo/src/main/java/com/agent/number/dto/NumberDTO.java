package com.agent.number.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.constant.Constant;
import com.agent.number.entity.TNumber;
import com.agent.util.DateUtil;
import com.agent.util.Utils;

public class NumberDTO extends TNumber{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private String channelCode;
    private Integer channelLevel;       //渠道级别，1：一级，2：二级，3：三级
    private Integer channelType;        //渠道属性，1：代理，2：网点
    private Integer channelPar1Id;//归属一级代理商
    private String channelPar1Code;
    private String channelPar1Name;
    private Integer channelPar2Id;//归属二级代理商
    private String channelPar2Code;
    private String channelPar2Name;
    private String packName;//套餐名称
    private String packCode;//套餐编号
    private BigDecimal ncMoney;//分配记录金额
    private String ncStatus;//分配记录状态
    private Date ncCreateTime;//分配时间
    private String parChannelName;//上级名称

    public String getChannelLevelStr() {
        if(null == channelLevel){
            return "总部";
        }else if(1 == channelLevel.intValue()){
            return "一级";
        }else if(2 == channelLevel.intValue() && 1 == channelType.intValue()){
            return "二级";
        }else if(2 == channelType.intValue()){
            return "网点";
        }
        return "";
    }

    public Integer getChannelLevel() {
        return channelLevel;
    }

    public void setChannelLevel(Integer channelLevel) {
        this.channelLevel = channelLevel;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }

    public Integer getChannelPar1Id() {
        return channelPar1Id;
    }

    public void setChannelPar1Id(Integer channelPar1Id) {
        this.channelPar1Id = channelPar1Id;
    }

    public String getChannelPar1Code() {
        return channelPar1Code;
    }

    public void setChannelPar1Code(String channelPar1Code) {
        this.channelPar1Code = channelPar1Code;
    }

    public String getChannelPar1Name() {
        return channelPar1Name;
    }

    public void setChannelPar1Name(String channelPar1Name) {
        this.channelPar1Name = channelPar1Name;
    }

    public Integer getChannelPar2Id() {
        return channelPar2Id;
    }

    public void setChannelPar2Id(Integer channelPar2Id) {
        this.channelPar2Id = channelPar2Id;
    }

    public String getChannelPar2Code() {
        return channelPar2Code;
    }

    public void setChannelPar2Code(String channelPar2Code) {
        this.channelPar2Code = channelPar2Code;
    }

    public String getChannelPar2Name() {
        return channelPar2Name;
    }
    

    public String getChannelParName() {
        if(Utils.isEmptyString(channelPar1Name)){
            return "--";
        }else if(Utils.isEmptyString(channelPar2Name)){
            return channelPar1Name;
        }else{
            return channelPar1Name+"-"+channelPar2Name;
        }
        
    }

    public void setChannelPar2Name(String channelPar2Name) {
        this.channelPar2Name = channelPar2Name;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getPackName() {
        if(Utils.isEmptyString(packName)){
            return "";
        }
        return packName;
    }

    public void setPackName(String packName) {
        this.packName = packName;
    }

    public BigDecimal getNcMoney() {
        return ncMoney;
    }

    public void setNcMoney(BigDecimal ncMoney) {
        this.ncMoney = ncMoney;
    }

    public String getNcMoneyYuan() {
        if(null != ncMoney){
            return Constant.df0.format(ncMoney.divide(Constant.cnt100));
        }else{
            return Constant.df0.format(super.getMoney().divide(Constant.cnt100));
        }
    }

    public String getNcStatus() {
        return ncStatus;
    }

    public void setNcStatus(String ncStatus) {
        this.ncStatus = ncStatus;
    }

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public String getParChannelName() {
        return parChannelName;
    }

    public void setParChannelName(String parChannelName) {
        this.parChannelName = parChannelName;
    }

    public Date getNcCreateTime() {
        return ncCreateTime;
    }

    public void setNcCreateTime(Date ncCreateTime) {
        this.ncCreateTime = ncCreateTime;
    }
    public String getNcCreateTimeYMD() {
        return ncCreateTime !=null ? DateUtil.getInstance().getDateStr(ncCreateTime,DateUtil.yyyy_MM_dd) : "";
    }
    
}
