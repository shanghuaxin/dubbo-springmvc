package com.agent.number.dto;

public class NumberIccidDTO {
    
    private Integer phoneId;
    private String simCode; //iccid编号
    private String imsi; //sims号
    private String mealName;//套餐名称
    private String mealCode;//套餐编号
    private Integer mealId;//套餐id
    private String mealType;//套餐类型：0-组合套餐，1-默认清除套餐，2-基础套餐
    private String parMealCode;//新套餐编号

    public NumberIccidDTO(){}

    public NumberIccidDTO(Integer phoneId,String simCode,String imsi,String mealName,String mealCode,Integer mealId){
        this.phoneId = phoneId;
        this.simCode = simCode;
        this.imsi = imsi;
        this.mealName = mealName;
        this.mealCode = mealCode;
        this.mealId = mealId;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getSimCode() {
        return simCode;
    }

    public void setSimCode(String simCode) {
        this.simCode = simCode;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getMealName() {
        return mealName;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }

    public String getMealCode() {
        return mealCode;
    }

    public void setMealCode(String mealCode) {
        this.mealCode = mealCode;
    }

    public Integer getMealId() {
        return mealId;
    }

    public void setMealId(Integer mealId) {
        this.mealId = mealId;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getParMealCode() {
        return parMealCode;
    }

    public void setParMealCode(String parMealCode) {
        this.parMealCode = parMealCode;
    }
    
}
