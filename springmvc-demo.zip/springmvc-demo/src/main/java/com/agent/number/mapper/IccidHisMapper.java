package com.agent.number.mapper;

import com.agent.common.BaseMapper;
import com.agent.number.entity.IccidHis;

public interface IccidHisMapper extends BaseMapper<IccidHis, Integer> {
    
}
