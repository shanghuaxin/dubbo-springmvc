package com.agent.number.dto;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.agent.constant.Constant;
import com.agent.number.entity.NumberPool;
import com.agent.number.entity.TNumber;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.Utils;

/**
 * 号码池列表dto
 */
public class NumberPoolListDTO extends NumberPool {

    /**
     * 
     */
    private static final long serialVersionUID = 9081462728206749232L;
    
    private String chCode;//当前渠道编号
    private String chName;//当前渠道名称
    private Integer chLevel;//当前渠道级别
    private Integer chType;//当前渠道类型
    private String ch1Name;//一级渠道名称
    private String ch2Name;//二级渠道名称
    private String isPre;//是否预开户
    private String level;//号码级别
    private BigDecimal money;//面额
    private String iccid;//iccid
    private String imsi;//imsi
    private Date numDate;//出库时间
    private Date validTime;//有效期
    private String status;//状态
    private String opChName;//开户渠道
    private String remark;//备注
    
    public String getChCode() {
        return chCode;
    }
    public void setChCode(String chCode) {
        this.chCode = chCode;
    }
    public String getChNameStr() {
        if(0 == getNbStatus().intValue()){
            return "";
        }else if(Utils.isEmptyString(chCode)){
            return "总部";
        }else{
            return "["+chCode+"]</p>"+chName;
        }
    }
    public String getChName() {
        return chName;
    }
    public void setChName(String chName) {
        this.chName = chName;
    }
    public String getCh1Name() {
        return ch1Name;
    }
    public void setCh1Name(String ch1Name) {
        this.ch1Name = ch1Name;
    }
    public String getCh2Name() {
        return ch2Name;
    }
    public void setCh2Name(String ch2Name) {
        this.ch2Name = ch2Name;
    }
    public String getIsPre() {
        return isPre;
    }
    public void setIsPre(String isPre) {
        this.isPre = isPre;
    }
    public String getIsPreStr(){
        if("1".equals(isPre)){
            return "是";
        }else{
            return "否";
        }
    }
    public String getLevel() {
        return level;
    }
    public void setLevel(String level) {
        this.level = level;
    }
    public String getLevelStr() {
        if(null != level){
            return DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(level);   
        }
        return "";
    }
    public String getMoneyYuan() {
        if(null != money){
            return Constant.df0.format(money.divide(Constant.cnt100));
        }
        return "";
    }
    
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public String getIccid() {
        return iccid;
    }
    public void setIccid(String iccid) {
        this.iccid = iccid;
    }
    public String getImsi() {
        return imsi;
    }
    public void setImsi(String imsi) {
        this.imsi = imsi;
    }
    public String getNumDateStr() {
        return numDate !=null ? DateUtil.getInstance().getDateStr(numDate,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public Date getNumDate() {
        return numDate;
    }
    public void setNumDate(Date numDate) {
        this.numDate = numDate;
    }
    public String getValidTimeStr() {
        return validTime !=null ? DateUtil.getInstance().getDateStr(validTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public Date getValidTime() {
        return validTime;
    }
    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }
    public String getStatusStr() {
        if(0 == super.getNbStatus().intValue()){
            return "待上架";
        }else{
            if(StringUtils.equals(status, TNumber.STATUS_WAIT_ALLOT)) {
                return "待分配";
            }else if(StringUtils.equals(status, TNumber.STATUS_WAIT_ACTIVATE)) {
                return "待开户";
            }else if(StringUtils.equals(status, TNumber.STATUS_WAIT_FINISH)) {
                return "开户待确认";
            }else if(StringUtils.equals(status, TNumber.STATUS_FINISH_ACTIVATE)) {
                return "已开户";
            }else if(StringUtils.equals(status, TNumber.STATUS_CANCEL)) {
                return "已销户";
            }else{
                return "";
            }
        }
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getOpChName() {
        return opChName;
    }
    public void setOpChName(String opChName) {
        this.opChName = opChName;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    public Integer getChLevel() {
        return chLevel;
    }
    public void setChLevel(Integer chLevel) {
        this.chLevel = chLevel;
    }
    public Integer getChType() {
        return chType;
    }
    public void setChType(Integer chType) {
        this.chType = chType;
    }
    public String getChTypeStr() {
        if(0 == super.getNbStatus().intValue()){
            return "";
        }else{
            if(null == chLevel){
                return "总部";
            }else if(1 == chLevel.intValue()){
                return "一级";
            }else if(2 == chLevel.intValue() && 1 == chType.intValue()){
                return "二级";
            }else if(2 == chType.intValue()){
                return "网点";
            }
        }
        return "";
    }
    
    @Override
    public String toString() {
        return "NumberPoolListDTO [chCode=" + chCode + ", chName=" + chName + ", chLevel=" + chLevel + ", chType="
                + chType + ", ch1Name=" + ch1Name + ", ch2Name=" + ch2Name + ", isPre=" + isPre + ", level=" + level
                + ", money=" + money + ", iccid=" + iccid + ", imsi=" + imsi + ", numDate=" + numDate + ", validTime="
                + validTime + ", status=" + status + ", opChName=" + opChName + ", remark=" + remark + "]";
    }
}
