package com.agent.number.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.agent.openaccount.entity.AttachedDocuments;

/**
 * Created by zw on 2015/8/25.
 */
public class NumberTopUpRestDTO implements Serializable {
    private static final long serialVersionUID = 2783957290889065796L;
    private String phone;//手机号
    private String userPwd;//服务密码
    private String code;//身份证号
    private String name;//姓名
    private String sexual; //性别
    private String nation; //名族
    private String organs; //organs
    private String expiryDate; //有效期限
    private String money;//金额
    private String contactPhone;//联系电话
    private String address;//身份证地址
    private String mealCode;//套餐
    private String mealCodes;//增值业务编号集合逗号隔开
    private String userId;//用户id
    private String imgStr;//图片字符串
    private String type;//图片类型
    private String optkey; //图片时间戳
    private String status;//充值状态：0-正常充值，1-号码过户充值
    private String imsi;//号码imsi号
    private String openWay;////识别方式：1-阅读识别器,2-照片识别
    private String resInstId;      //号码实例ID
    private String uimResInstId;      //UIM实例ID
    private String iccid;      //iccid
    private List<AttachedDocuments> atts = new ArrayList<>();
    
    private String channelId;
    private String numberLowerMoney;//号码低消

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSexual() {
        return sexual;
    }

    public void setSexual(String sexual) {
        this.sexual = sexual;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getOrgans() {
        return organs;
    }

    public void setOrgans(String organs) {
        this.organs = organs;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMealCode() {
        return mealCode;
    }

    public void setMealCode(String mealCode) {
        this.mealCode = mealCode;
    }

    public String getMealCodes() {
        return mealCodes;
    }

    public void setMealCodes(String mealCodes) {
        this.mealCodes = mealCodes;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<AttachedDocuments> getAtts() {
        return atts;
    }

    public void setAtts(List<AttachedDocuments> atts) {
        this.atts = atts;
    }

    public String getImgStr() {
        return imgStr;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOptkey() {
        return optkey;
    }

    public void setOptkey(String optkey) {
        this.optkey = optkey;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

    public String getOpenWay() {
        return openWay;
    }

    public void setOpenWay(String openWay) {
        this.openWay = openWay;
    }

    public String getResInstId() {
        return resInstId;
    }

    public void setResInstId(String resInstId) {
        this.resInstId = resInstId;
    }

    public String getUimResInstId() {
        return uimResInstId;
    }

    public void setUimResInstId(String uimResInstId) {
        this.uimResInstId = uimResInstId;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getNumberLowerMoney() {
        return numberLowerMoney;
    }

    public void setNumberLowerMoney(String numberLowerMoney) {
        this.numberLowerMoney = numberLowerMoney;
    }

    @Override
    public String toString() {
        return "NumberTopUpRestDTO [phone=" + phone + ", userPwd=" + userPwd + ", code=" + code + ", name=" + name
                + ", sexual=" + sexual + ", nation=" + nation + ", organs=" + organs + ", expiryDate=" + expiryDate
                + ", money=" + money + ", contactPhone=" + contactPhone + ", address=" + address + ", mealCodes="
                + mealCodes + ", userId=" + userId + ", imgStr=" + imgStr + ", type=" + type + ", optkey=" + optkey
                + ", status=" + status + ", imsi=" + imsi + ", openWay=" + openWay + ", atts=" + atts + "]";
    }
}
