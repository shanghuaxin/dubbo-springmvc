package com.agent.number.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelProductMapper;
import com.agent.channel.service.ChannelsService;
import com.agent.common.enumeration.NmbRecordOptType;
import com.agent.constant.Constant;
import com.agent.file.dto.PhoneImportDto;
import com.agent.number.dto.NumberDTO;
import com.agent.number.entity.NumberChannel;
import com.agent.number.entity.NumberRecord;
import com.agent.number.entity.TNumber;
import com.agent.number.mapper.NumberChannelMapper;
import com.agent.number.mapper.NumberMapper;
import com.agent.number.mapper.NumberRecordMapper;
import com.agent.product.dto.ChannelProductDto;
import com.agent.stock.dto.CardInfoDto;
import com.agent.stock.dto.StockNumDto;
import com.agent.stock.entity.Stock;
import com.agent.stock.entity.StockAllot;
import com.agent.stock.mapper.StockAllotMapper;
import com.agent.stock.service.StockService;
import com.agent.system.entity.User;
import com.agent.util.Utils;

@Transactional(rollbackFor=Exception.class)
@Service("numberUtil")
public class NumberUtil {
    @Resource
    private StockService stockService;
    @Resource
    private NumberMapper numMapper;
    @Resource
    private ChannelsService channelsService;
    @Resource
    private ChannelProductMapper chProMapper;
    @Resource
    private StockAllotMapper stockAllotMapper;
    @Resource
    private NumberChannelMapper numberChannelMapper;
    @Resource
    private NumberRecordMapper numberRecordMapper;

    /**
     * 号码库存信息Map
     * @param stockMap
     * @param chId  渠道id
     * @param type 类型：1-总库存，2-未分配数,6-分配出去数量
     * @param network 网络：1-移动，2-联通，3-电信
     * @throws Exception
     */
    public void stockMapSet(Map<Integer,Map<Integer,StockNumDto>> stockMap,
                            Integer chId,Integer chParId1,Integer chParId2,
                            Integer type,Integer num,Integer network) throws Exception{
        StockNumDto dto;
        Map<Integer, StockNumDto> smap;
        if(null != stockMap.get(chId)){
            smap = stockMap.get(chId);
            if(null != smap.get(network)){
                dto = smap.get(network);
            }else{
                dto = new StockNumDto();
            }
        }else{
            //渠道不存在
            smap = new HashMap<>();
            dto = new StockNumDto();
        }
        dto.setChannelIdLevel1(chParId1);
        dto.setChannelIdLevel2(chParId2);
        if(Stock.statistics_type_1.intValue() == type.intValue()){
            dto.setSumNum(dto.getSumNum()+num);
        }else if(Stock.statistics_type_2.intValue() == type.intValue()){
            dto.setAllotNum(dto.getAllotNum()+num);
        }else if(Stock.statistics_type_6.intValue() == type.intValue()){
            dto.setParAllotNum(dto.getParAllotNum()+num);
        }else if(Stock.statistics_type_8.intValue() == type.intValue()){
            dto.setCancleBlackNum(dto.getCancleBlackNum()+num);
        }else if(Stock.statistics_type_9.intValue() == type.intValue()){
            dto.setSurplusNum(dto.getSurplusNum()+num);
        }
        smap.put(network, dto);
        stockMap.put(chId,smap);
    }
    
    /**
     * 库存信息入库
     * @param stockMap
     * @param date
     * @param us
     * @throws Exception
     */
    public void insertStock(Map<Integer,Map<Integer,StockNumDto>> stockMap,Date date,User us) throws Exception{
        //修改库存信息表
        List<Stock> stockList = new ArrayList<Stock>();//库存list
        Stock st;
        for(Integer id:stockMap.keySet()){
            Map<Integer,StockNumDto> sMap = stockMap.get(id);
            for(Integer network:sMap.keySet()){
                StockNumDto snDto = sMap.get(network);
                //分配给自己的总库存
                st = new Stock();
                st.setStockType(id.intValue()==0 ? Stock.stock_type_1 : Stock.stock_type_2);//id 为0是总部，其他为代理商
                st.setDataType(Stock.data_type_2);
                st.setProId(0);
                st.setStatisticsType(Stock.statistics_type_1);
                st.setStockId(id);
                st.setNetwork(network);
                st.setStockNum(snDto.getSumNum());
                st.setChannelIdLevel1(snDto.getChannelIdLevel1());
                st.setChannelIdLevel2(snDto.getChannelIdLevel2());
                st.setCreateId(us.getId());
                st.setCreateTime(date);
                st.setUpdateId(us.getId());
                st.setUpdateTime(date);
                stockList.add(st);

                //分配出去后剩余库存
                st = new Stock();
                st.setStockType(id.intValue()==0 ? Stock.stock_type_1 : Stock.stock_type_2);//id 为0是总部，其他为代理商
                st.setDataType(Stock.data_type_2);
                st.setProId(0);
                st.setStatisticsType(Stock.statistics_type_2);
                st.setStockId(id);
                st.setNetwork(network);
                st.setStockNum(snDto.getAllotNum());
                st.setChannelIdLevel1(snDto.getChannelIdLevel1());
                st.setChannelIdLevel2(snDto.getChannelIdLevel2());
                st.setCreateId(us.getId());
                st.setCreateTime(date);
                st.setUpdateId(us.getId());
                st.setUpdateTime(date);
                stockList.add(st);
                
                //销户回收
                if(snDto.getCancleBlackNum() !=0){
                    st = new Stock();
                    st.setStockType(id.intValue()==0 ? Stock.stock_type_1 : Stock.stock_type_2);//id 为0是总部，其他为代理商
                    st.setDataType(Stock.data_type_2);
                    st.setProId(0);
                    st.setStatisticsType(Stock.statistics_type_8);
                    st.setStockId(0);
                    st.setNetwork(network);
                    st.setStockNum(snDto.getCancleBlackNum());
                    st.setCreateId(us.getId());
                    st.setCreateTime(date);
                    st.setUpdateId(us.getId());
                    st.setUpdateTime(date);
                    stockList.add(st);
                }
                //号码池余量 导入、下架、销户
                if(snDto.getSurplusNum() !=0){
                    st = new Stock();
                    st.setStockType(id.intValue()==0 ? Stock.stock_type_1 : Stock.stock_type_2);//id 为0是总部，其他为代理商
                    st.setDataType(Stock.data_type_2);
                    st.setProId(0);
                    st.setStatisticsType(Stock.statistics_type_9);
                    st.setStockId(0);
                    st.setNetwork(network);
                    st.setStockNum(snDto.getSurplusNum());
                    st.setCreateId(us.getId());
                    st.setCreateTime(date);
                    st.setUpdateId(us.getId());
                    st.setUpdateTime(date);
                    stockList.add(st);
                }
            }
        }
        stockService.stockUpOrAdd(stockList);
    }
    
    /**
     * 修改号码状态和号码当前渠道id
     * @param upNums
     * @param pageCount
     * @throws Exception
     */
    public void updateNumList(List<TNumber> upNums,int pageCount) throws Exception{
      //修改号码状态和号码当前渠道id
        int dataCount = upNums.size();
        int page = 0;//页数
        if(dataCount > pageCount){
            if(dataCount%pageCount !=0){
                page = dataCount/pageCount +1;
            }else{
                page = dataCount/pageCount;
            }
            int start=0,end=0;
            for (int i = 1; i <= page; i++) {
                if (i * pageCount > dataCount) {
                    end = dataCount;
                } else {
                    end = i * pageCount;
                }
                if (i == 1) {
                    start = i - 1;
                } else {
                    start = (i - 1) * pageCount;
                }
                updateNum(upNums, start, end);
            }
        }else {
            updateNum(upNums, 0, dataCount);
        }
    }

    /**
     * 修改号码状态和号码当前渠道id
     * @param upNums
     * @throws Exception
     */
    public void updateNum(List<TNumber> upNums,int start,int end) throws Exception{
        if(null != upNums && upNums.size() >0){
            List<TNumber> saveList = new ArrayList<TNumber>();
            for (int i = start; i < end; i++) {
                saveList.add(upNums.get(i));
            }
            numMapper.batchUpdateNumId(saveList);
        }
    }
    
    /**
     * 基础数据校验
     * @param start
     * @param end
     * @param impList
     * @param phoneList
     * @return
     * @throws Exception
     */
    public Map<String,Object>  vaildAllotCheck(int start, int end,List<PhoneImportDto> impList,List<String> channelCode,List<String> phoneList,Channels loginCh) throws Exception{
        Map<String,Object> rtnMap = new HashMap<String,Object>();
        StringBuffer errStr = new StringBuffer();
        //基本数据校验
        for (int i = start; i < end; i++) {
            if(null == loginCh){
                //总部分配
                if(Utils.isEmptyString(impList.get(i).getChannelCode1())){
                    errStr.append("号码"+impList.get(i).getPhone()+"一级渠道编号不能为空,");
                    continue;
                }
            }else if(Channels.CHANNEL_LEVEL_1.equals(loginCh.getChannelLevel())){
                impList.get(i).setChannelCode1(loginCh.getChannelCode());
                //一级渠道分配
                if(Utils.isEmptyString(impList.get(i).getChannelCode2()) && Utils.isEmptyString(impList.get(i).getChannelCode3())) {
                    errStr.append("号码"+impList.get(i).getPhone()+"二，三级渠道编号不能为空,");
                    continue;
                }
            }else if(Channels.CHANNEL_LEVEL_2.equals(loginCh.getChannelLevel())){
                impList.get(i).setChannelCode1(loginCh.getParentChannelCode());
                impList.get(i).setChannelCode2(loginCh.getChannelCode());
                //二级渠道分配
                if(Utils.isEmptyString(impList.get(i).getChannelCode3())) {
                    errStr.append("号码"+impList.get(i).getPhone()+"三级渠道编号不能为空,");
                    continue;
                }
            }
            if(!channelCode.contains(impList.get(i).getChannelCode1()) && !Utils.isEmptyString(impList.get(i).getChannelCode1())){
                channelCode.add(impList.get(i).getChannelCode1());
            }
            if(!channelCode.contains(impList.get(i).getChannelCode2()) && !Utils.isEmptyString(impList.get(i).getChannelCode2())){
                channelCode.add(impList.get(i).getChannelCode2());
            }
            if(!channelCode.contains(impList.get(i).getChannelCode3()) && !Utils.isEmptyString(impList.get(i).getChannelCode3())){
                channelCode.add(impList.get(i).getChannelCode3());
            }
            if(phoneList.contains(impList.get(i).getPhone())){
                errStr.append("号码"+impList.get(i).getPhone()+"在上传文件中有重复,");
                continue;
            }
            phoneList.add(impList.get(i).getPhone());
        }
        if(!Utils.isEmptyString(errStr)){
            rtnMap.put("stat",false);
            rtnMap.put("msg", errStr.toString());
            return rtnMap;
        }
        rtnMap.put("stat",true);
        return rtnMap;
    }

    /**
     * 号码分配导入数据库校验
     * @param impList
     * @param chCodes
     * @param phoneList
     * @return
     * @throws Exception
     */
    public Map<String,Object> vaildDataAllotCheck(int start, int end,Map<String,List<PhoneImportDto>> chNumMap,List<String> upNumChList,
            List<TNumber> upNums, Map<Integer,Map<Integer,StockNumDto>> stockMap,List<PhoneImportDto> impList,List<String> chCodes,
            List<String> phoneList,Channels loginCh,Date date,User us,List<NumberRecord> nbrRecords) throws Exception{
        Map<String,Object> rtnMap = new HashMap<String,Object>();
        Map<String, Object> mapSearch = new HashMap<String, Object>();
        Map<String, Channels> chMaps = new HashMap<String, Channels>();//渠道编号对应渠道信息
        Map<String, NumberDTO> numMaps = new HashMap<String, NumberDTO>();//号码对应号码信息
        mapSearch.put("codes",chCodes);
        List<Channels> findChs = channelsService.listChannels(mapSearch);
        if(null != findChs && findChs.size() >0){
            Set<String> pacSet = new HashSet<String>();
            for(Channels p:findChs){
                pacSet.add(p.getChannelCode());
                chMaps.put(p.getChannelCode(),p);
            }
            if(chCodes.size() != findChs.size()){
                StringBuffer errStr = new StringBuffer();
                for(int i=0;i<chCodes.size();i++){
                    if(!pacSet.contains(chCodes.get(i))){
                        errStr.append(chCodes.get(i)).append(",");
                    }
                }
                rtnMap.put("stat",false);
                rtnMap.put("msg","渠道编号："+errStr.toString()+ "在系统中不存在");
                return rtnMap;
            }
        }else{
            rtnMap.put("stat",false);
            rtnMap.put("msg","所有渠道编号在系统中不存在");
            return rtnMap;
        }


        List<String> pacCodeList = new ArrayList<String>();//套餐编号
        mapSearch = new HashMap<String, Object>();
        if(null == loginCh){
            mapSearch.put("allChannelId",0);
        }else{
            mapSearch.put("allChannelId",loginCh.getId());
        }
        mapSearch.put("phones",phoneList);
        mapSearch.put("statusNot",TNumber.STATUS_CANCEL);
        List<Integer> phoneIds = new ArrayList<Integer>();
        List<NumberDTO> findPhoneList = numMapper.numPreList(mapSearch);
        if(null != findPhoneList && findPhoneList.size() >0){
            Set<String> pacSet = new HashSet<String>();
            StringBuffer errStr = new StringBuffer();
            for(NumberDTO p:findPhoneList){
                pacSet.add(p.getPhone());
                numMaps.put(p.getPhone(),p);
                if(!pacCodeList.contains(p.getPackCode()) && !Utils.isEmptyString(p.getPackCode())){
                    pacCodeList.add(p.getPackCode());
                }

                if("1".equals(p.getOperatorCode()) && Utils.isEmptyString(p.getPackCode())){
                    errStr.append(p.getPhone()).append(",");
                }
                phoneIds.add(p.getId());
            }
            if(!errStr.toString().equals("")){
                rtnMap.put("stat",false);
                rtnMap.put("msg","号码："+errStr.toString()+ "没有绑定套餐");
                return rtnMap;
            }
            if(phoneList.size() != findPhoneList.size()){
                errStr = new StringBuffer();
                for(int i=0;i<phoneList.size();i++){
                    if(!pacSet.contains(phoneList.get(i))){
                        errStr.append(phoneList.get(i)).append(",");
                    }
                }
                rtnMap.put("stat",false);
                rtnMap.put("msg","号码："+errStr.toString()+ "在系统中不存在");
                return rtnMap;
            }
        }else{
            rtnMap.put("stat",false);
            rtnMap.put("msg","所有号码在系统中不存在");
            return rtnMap;
        }
        
        //当前渠道登录，查询号码各级分配记录时间
        Map<String, PhoneImportDto> phoneAllot = new HashMap<String, PhoneImportDto>();
        if(null != loginCh){
            mapSearch = new HashMap<String, Object>();
            mapSearch.put("phoneIds",phoneIds);
            List<PhoneImportDto> phoneAllotList = numberChannelMapper.phoneAllotList(mapSearch);
            if(null != phoneAllotList && phoneAllotList.size() != 0){
                for(PhoneImportDto s:phoneAllotList){
                    phoneAllot.put(s.getPhone(), s);
                }
            }
        }
        Map<String, List<String>> chPacIsShow = new HashMap<String, List<String>>();//渠道可见对应套餐
        if(pacCodeList.size() >0){
            mapSearch = new HashMap<String, Object>();
            mapSearch.put("channelCodes",chCodes);
            mapSearch.put("isShow","1");
            mapSearch.put("proCodes",pacCodeList);
            List<ChannelProductDto> chProList = chProMapper.listChPacIsShow(mapSearch);
            if(null != chProList && chProList.size() >0){
                for(ChannelProductDto d:chProList){
                    if(chPacIsShow.containsKey(d.getChannelCode())){
                        List<String> pacList = chPacIsShow.get(d.getChannelCode());
                        pacList.add(d.getProCode());
                        chPacIsShow.put(d.getChannelCode(),pacList);
                    }else{
                        List<String> pacList = new ArrayList<String>();
                        pacList.add(d.getProCode());
                        chPacIsShow.put(d.getChannelCode(),pacList);
                    }
                }
            }else{
                rtnMap.put("stat",false);
                rtnMap.put("msg","所有号码套餐对应的渠道都没有可见性，不能进行分配");
                return rtnMap;
            }
        }
        PhoneImportDto impDto;
        StringBuffer errStr = new StringBuffer();
        for (int i = start; i < end; i++) {
            impDto = impList.get(i);
            TNumber tn = numMaps.get(impDto.getPhone());
            impDto.setPhoneId(tn.getId());
            impDto.setMoney(String.valueOf(tn.getMoney()));
            if(tn.getStatus().equals(TNumber.STATUS_WAIT_FINISH) || tn.getStatus().equals(TNumber.STATUS_FINISH_ACTIVATE)){
                errStr.append("号码"+impDto.getPhone()+"已开户").append(",");
                continue;
            }
            if(null == loginCh){
                impDto.setChannelDate1(date);
                impDto.setChannelDate2(date);
                impDto.setChannelDate3(date);
                //总部分配
                if(0 != numMaps.get(impDto.getPhone()).getChannelId().intValue()){
                    errStr.append("号码"+impDto.getPhone()+"不归属于您").append(",");
                    continue;
                }
                if("1".equals(numMaps.get(impDto.getPhone()).getOperatorCode()) && !chPacIsShow.get(impDto.getChannelCode1()).contains(numMaps.get(impDto.getPhone()).getPackCode())){
                    errStr.append("号码"+impDto.getPhone()+"绑定的套餐"+numMaps.get(impDto.getPhone()).getPackCode()+"对渠道："+impDto.getChannelCode1()+ "没有可见性").append(",");
                    continue;
                }
                stockMapSet(stockMap, 0, null, null,  Stock.statistics_type_2, -1,tn.getOperatorCode());
                if(!Utils.isEmptyString(impDto.getChannelCode1()) && Utils.isEmptyString(impDto.getChannelCode2()) && Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给一级渠道
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode1()).getId(), null,null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode1()).getId(), null,null, Stock.statistics_type_2,1,tn.getOperatorCode());

                    impDto.setChannelId(chMaps.get(impDto.getChannelCode1()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode1()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_1);
                    impDto.setChannelId1(chMaps.get(impDto.getChannelCode1()).getId());
                    impDto.setChannelCode1(chMaps.get(impDto.getChannelCode1()).getChannelCode());
                    impDto.setChannelName1(chMaps.get(impDto.getChannelCode1()).getChannelName());
                    if(chNumMap.containsKey(impDto.getChannelCode1())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode1());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode1(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode1(),channesList);
                    }
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            "总部分配到："+chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]" );
                }else  if(!Utils.isEmptyString(impDto.getChannelCode1())
                        && !Utils.isEmptyString(impDto.getChannelCode2())
                        && Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给二级渠道
                    if(!chMaps.get(impDto.getChannelCode2()).getParentChannelCode().equals(chMaps.get(impDto.getChannelCode1()).getChannelCode())){
                        errStr.append("二级代理商"+impDto.getChannelCode2()+"不是一级渠道"+impDto.getChannelCode1()+"的下级渠道").append(",");
                        continue;
                    }
                    if(Channels.CHANNEL_LEVEL_2.intValue() != chMaps.get(impDto.getChannelCode2()).getChannelLevel().intValue() ||
                            Channels.CHANNEL_TYPE_1.intValue() != chMaps.get(impDto.getChannelCode2()).getChannelType().intValue()){
                        errStr.append("渠道："+impDto.getChannelCode2()+ "不是二级代理商").append(",");
                        continue;
                    }
                    //总部分配给二级
                    impDto.setChannelId(chMaps.get(impDto.getChannelCode2()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode2()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_2);
                    impDto.setChannelId1(chMaps.get(impDto.getChannelCode1()).getId());
                    impDto.setChannelCode1(chMaps.get(impDto.getChannelCode1()).getChannelCode());
                    impDto.setChannelName1(chMaps.get(impDto.getChannelCode1()).getChannelName());

                    impDto.setChannelId2(chMaps.get(impDto.getChannelCode2()).getId());
                    impDto.setChannelCode2(chMaps.get(impDto.getChannelCode2()).getChannelCode());
                    impDto.setChannelName2(chMaps.get(impDto.getChannelCode2()).getChannelName());
                    if(chNumMap.containsKey(impDto.getChannelCode2())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode2());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode2(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode2(),channesList);
                    }

                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode1()).getId(), null,null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode2()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode2()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),null, Stock.statistics_type_2,1,tn.getOperatorCode());
                    
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            "总部分配到："+chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]" );
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode2()).getChannelName()+"["+chMaps.get(impDto.getChannelCode2()).getChannelCode()+"]" );
                }else if(!Utils.isEmptyString(impDto.getChannelCode1())
                        && Utils.isEmptyString(impDto.getChannelCode2())
                        && !Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给直属网点
                    if(Channels.CHANNEL_LEVEL_2.intValue() != chMaps.get(impDto.getChannelCode3()).getChannelLevel().intValue() ||
                            Channels.CHANNEL_TYPE_2.intValue() != chMaps.get(impDto.getChannelCode3()).getChannelType().intValue()){
                        errStr.append("渠道："+impDto.getChannelCode3()+ "不是直属网点").append(",");
                        continue;
                    }
                    if(!chMaps.get(impDto.getChannelCode3()).getParentChannelCode().equals(chMaps.get(impDto.getChannelCode1()).getChannelCode())){
                        errStr.append("三级代理商"+impDto.getChannelCode2()+"不是一级渠道"+impDto.getChannelCode1()+"的直属渠道").append(",");
                        continue;
                    }
                    //分配给直属网点
                    impDto.setChannelId(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_4);
                    impDto.setChannelId1(chMaps.get(impDto.getChannelCode1()).getId());
                    impDto.setChannelCode1(chMaps.get(impDto.getChannelCode1()).getChannelCode());
                    impDto.setChannelName1(chMaps.get(impDto.getChannelCode1()).getChannelName());

                    impDto.setChannelId3(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelCode3(chMaps.get(impDto.getChannelCode3()).getChannelCode());
                    impDto.setChannelName3(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    if(chNumMap.containsKey(impDto.getChannelCode3())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode3());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }

                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode1()).getId(), null,null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),null, Stock.statistics_type_2,1,tn.getOperatorCode());
                    
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            "总部分配到："+chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]" );
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode3()).getChannelName()+"["+chMaps.get(impDto.getChannelCode3()).getChannelCode()+"]" );
                }else if(!Utils.isEmptyString(impDto.getChannelCode1())
                        && !Utils.isEmptyString(impDto.getChannelCode2())
                        && !Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给三级网点
                    if(!chMaps.get(impDto.getChannelCode2()).getParentChannelCode().equals(chMaps.get(impDto.getChannelCode1()).getChannelCode())){
                        errStr.append("二级代理商"+impDto.getChannelCode2()+"不是一级渠道"+impDto.getChannelCode1()+"的下级渠道").append(",");
                        continue;
                    }
                    if(!chMaps.get(impDto.getChannelCode3()).getParentChannelCode().equals(chMaps.get(impDto.getChannelCode2()).getChannelCode())){
                        errStr.append("三级代理商"+impDto.getChannelCode3()+"不是二级渠道"+impDto.getChannelCode2()+"的下级渠道").append(",");
                        continue;
                    }
                    //分配给三级
                    impDto.setChannelId(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_3);
                    impDto.setChannelId1(chMaps.get(impDto.getChannelCode1()).getId());
                    impDto.setChannelCode1(chMaps.get(impDto.getChannelCode1()).getChannelCode());
                    impDto.setChannelName1(chMaps.get(impDto.getChannelCode1()).getChannelName());

                    impDto.setChannelId2(chMaps.get(impDto.getChannelCode2()).getId());
                    impDto.setChannelCode2(chMaps.get(impDto.getChannelCode2()).getChannelCode());
                    impDto.setChannelName2(chMaps.get(impDto.getChannelCode2()).getChannelName());

                    impDto.setChannelId3(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelCode3(chMaps.get(impDto.getChannelCode3()).getChannelCode());
                    impDto.setChannelName3(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    if(chNumMap.containsKey(impDto.getChannelCode3())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode3());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }

                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode1()).getId(), null,null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode2()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),null, Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),chMaps.get(impDto.getChannelCode2()).getId(), Stock.statistics_type_1,1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), chMaps.get(impDto.getChannelCode1()).getId(),chMaps.get(impDto.getChannelCode2()).getId(), Stock.statistics_type_2,1,tn.getOperatorCode());
                    
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            "总部分配到："+chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]" );
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            chMaps.get(impDto.getChannelCode1()).getChannelName()+"["+chMaps.get(impDto.getChannelCode1()).getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode2()).getChannelName()+"["+chMaps.get(impDto.getChannelCode2()).getChannelCode()+"]" );
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            chMaps.get(impDto.getChannelCode2()).getChannelName()+"["+chMaps.get(impDto.getChannelCode2()).getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode3()).getChannelName()+"["+chMaps.get(impDto.getChannelCode3()).getChannelCode()+"]" );
                }
            }else if(Channels.CHANNEL_LEVEL_1.intValue() == loginCh.getChannelLevel().intValue()){
                //一级代理商分配
                if(loginCh.getId() != numMaps.get(impDto.getPhone()).getChannelId().intValue()){
                    errStr.append("号码"+impDto.getPhone()+"不归属于您").append(",");
                    continue;
                }
                if("1".equals(numMaps.get(impDto.getPhone()).getOperatorCode()) && !chPacIsShow.get(loginCh.getChannelCode()).contains(numMaps.get(impDto.getPhone()).getPackCode())){
                    errStr.append("号码"+impDto.getPhone()+"绑定的套餐"+numMaps.get(impDto.getPhone()).getPackCode()+"对您没有可见性").append(",");
                    continue;
                }
                chMaps.put(loginCh.getChannelCode(),loginCh);
                upNumChList.add(tn.getId() + "" + loginCh.getId());

                stockMapSet(stockMap, loginCh.getId(), null, null,  Stock.statistics_type_2, -1,tn.getOperatorCode());

                impDto.setChannelId1(loginCh.getId());
                impDto.setChannelCode1(loginCh.getChannelCode());
                impDto.setChannelName1(loginCh.getChannelName());

                if(!Utils.isEmptyString(impDto.getChannelCode2())
                        && Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给二级渠道
                    if(!chMaps.get(impDto.getChannelCode2()).getParentChannelCode().equals(loginCh.getChannelCode())){
                        errStr.append("二级代理商"+impDto.getChannelCode2()+"不是您的二级代理商渠道").append(",");
                        continue;
                    }
                    if(Channels.CHANNEL_LEVEL_2.intValue() != chMaps.get(impDto.getChannelCode2()).getChannelLevel().intValue() ||
                            Channels.CHANNEL_TYPE_1.intValue() != chMaps.get(impDto.getChannelCode2()).getChannelType().intValue()){
                        errStr.append("渠道："+impDto.getChannelCode2()+ "不是二级代理商！").append(",");
                        continue;
                    }
                    impDto.setChannelId(chMaps.get(impDto.getChannelCode2()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode2()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_2);

                    impDto.setChannelId2(chMaps.get(impDto.getChannelCode2()).getId());
                    impDto.setChannelCode2(chMaps.get(impDto.getChannelCode2()).getChannelCode());
                    impDto.setChannelName2(chMaps.get(impDto.getChannelCode2()).getChannelName());
                    impDto.setChannelDate1(phoneAllot.get(impDto.getPhone()).getChannelDate1());
                    impDto.setChannelDate2(date);

                    if(chNumMap.containsKey(impDto.getChannelCode2())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode2());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode2(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode2(),channesList);
                    }
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode2()).getId(), loginCh.getId(), null,  Stock.statistics_type_1, 1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode2()).getId(), loginCh.getId(), null,  Stock.statistics_type_2, 1,tn.getOperatorCode());
                    
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            loginCh.getChannelName()+"["+loginCh.getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode2()).getChannelName()+"["+chMaps.get(impDto.getChannelCode2()).getChannelCode()+"]" );
                }else if(Utils.isEmptyString(impDto.getChannelCode2())
                        && !Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给直属网点
                    if(Channels.CHANNEL_LEVEL_2.intValue() != chMaps.get(impDto.getChannelCode3()).getChannelLevel().intValue() ||
                            Channels.CHANNEL_TYPE_2.intValue() != chMaps.get(impDto.getChannelCode3()).getChannelType().intValue()){
                        errStr.append("渠道："+impDto.getChannelCode3()+ "不是直属网点！").append(",");
                        continue;
                    }
                    if(!chMaps.get(impDto.getChannelCode3()).getParentChannelCode().equals(loginCh.getChannelCode())){
                        errStr.append("渠道"+impDto.getChannelCode3()+"不是您的直属网点渠道").append(",");
                        continue;
                    }
                    impDto.setChannelId(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_4);

                    impDto.setChannelId3(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelCode3(chMaps.get(impDto.getChannelCode3()).getChannelCode());
                    impDto.setChannelName3(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    impDto.setChannelDate1(phoneAllot.get(impDto.getPhone()).getChannelDate1());
                    impDto.setChannelDate3(date);

                    if(chNumMap.containsKey(impDto.getChannelCode3())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode3());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), loginCh.getId(), null,  Stock.statistics_type_1, 1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), loginCh.getId(), null,  Stock.statistics_type_2, 1,tn.getOperatorCode());
                    
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            loginCh.getChannelName()+"["+loginCh.getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode3()).getChannelName()+"["+chMaps.get(impDto.getChannelCode3()).getChannelCode()+"]" );
                }else if(!Utils.isEmptyString(impDto.getChannelCode2())
                        && !Utils.isEmptyString(impDto.getChannelCode3())){
                    //分配给三级代理商
                    if(!chMaps.get(impDto.getChannelCode2()).getParentChannelCode().equals(loginCh.getChannelCode())){
                        errStr.append("二级代理商"+impDto.getChannelCode2()+"不是您的二级代理商渠道").append(",");
                        continue;
                    }
                    if(!chMaps.get(impDto.getChannelCode3()).getParentChannelCode().equals(chMaps.get(impDto.getChannelCode2()).getChannelCode())){
                        errStr.append("三级代理商" + impDto.getChannelCode3()+"不是二级渠道"+impDto.getChannelCode2()+"的下级渠道").append(",");
                        continue;
                    }
                    impDto.setChannelId(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelName(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    impDto.setAllotType(CardInfoDto.allot_type_3);

                    impDto.setChannelId2(chMaps.get(impDto.getChannelCode2()).getId());
                    impDto.setChannelCode2(chMaps.get(impDto.getChannelCode2()).getChannelCode());
                    impDto.setChannelName2(chMaps.get(impDto.getChannelCode2()).getChannelName());

                    impDto.setChannelId3(chMaps.get(impDto.getChannelCode3()).getId());
                    impDto.setChannelCode3(chMaps.get(impDto.getChannelCode3()).getChannelCode());
                    impDto.setChannelName3(chMaps.get(impDto.getChannelCode3()).getChannelName());
                    impDto.setChannelDate1(phoneAllot.get(impDto.getPhone()).getChannelDate1());
                    impDto.setChannelDate2(date);
                    if(chNumMap.containsKey(impDto.getChannelCode3())){
                        List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode3());
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }else{
                        List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                        channesList.add(impDto);
                        chNumMap.put(impDto.getChannelCode3(),channesList);
                    }

                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode2()).getId(), loginCh.getId(), null,  Stock.statistics_type_1, 1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), loginCh.getId(), chMaps.get(impDto.getChannelCode2()).getId(),  Stock.statistics_type_1, 1,tn.getOperatorCode());
                    stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), loginCh.getId(), chMaps.get(impDto.getChannelCode2()).getId(),  Stock.statistics_type_2, 1,tn.getOperatorCode());
                    
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            loginCh.getChannelName()+"["+loginCh.getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode2()).getChannelName()+"["+chMaps.get(impDto.getChannelCode2()).getChannelCode()+"]" );
                    addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                            chMaps.get(impDto.getChannelCode2()).getChannelName()+"["+chMaps.get(impDto.getChannelCode2()).getChannelCode()+"]分配到："
                    +chMaps.get(impDto.getChannelCode3()).getChannelName()+"["+chMaps.get(impDto.getChannelCode3()).getChannelCode()+"]" );
                }
            }else if(Channels.CHANNEL_LEVEL_2.intValue() == loginCh.getChannelLevel().intValue()){
                //二级代理商分配
                if(loginCh.getId() != numMaps.get(impDto.getPhone()).getChannelId().intValue()){
                    errStr.append("号码"+impDto.getPhone()+"不归属于您").append(",");
                    continue;
                }
                if(!chMaps.get(impDto.getChannelCode3()).getParentChannelCode().equals(loginCh.getChannelCode())){
                    errStr.append("三级代理商"+impDto.getChannelCode2()+"不是您的渠道").append(",");
                    continue;
                }
                chMaps.put(loginCh.getParentChannelCode(),new Channels());
                chMaps.put(loginCh.getChannelCode(),loginCh);
                upNumChList.add(tn.getId() + "" + loginCh.getId());

                impDto.setChannelId(chMaps.get(impDto.getChannelCode3()).getId());
                impDto.setChannelName(chMaps.get(impDto.getChannelCode3()).getChannelName());
                impDto.setAllotType(CardInfoDto.allot_type_3);
                impDto.setChannelId1(loginCh.getParentChannelId());
                impDto.setChannelCode1(loginCh.getParentChannelCode());
                impDto.setChannelName1(loginCh.getParentChannelName());
                impDto.setChannelId2(loginCh.getId());
                impDto.setChannelCode2(loginCh.getChannelCode());
                impDto.setChannelName2(loginCh.getChannelName());
                impDto.setChannelId3(chMaps.get(impDto.getChannelCode3()).getId());
                impDto.setChannelCode3(chMaps.get(impDto.getChannelCode3()).getChannelCode());
                impDto.setChannelName3(chMaps.get(impDto.getChannelCode3()).getChannelName());
                impDto.setChannelDate1(phoneAllot.get(impDto.getPhone()).getChannelDate1());
                impDto.setChannelDate2(phoneAllot.get(impDto.getPhone()).getChannelDate2());
                if(chNumMap.containsKey(impDto.getChannelCode3())){
                    List<PhoneImportDto> channesList = chNumMap.get(impDto.getChannelCode3());
                    channesList.add(impDto);
                    chNumMap.put(impDto.getChannelCode3(),channesList);
                }else{
                    List<PhoneImportDto> channesList = new ArrayList<PhoneImportDto>();
                    channesList.add(impDto);
                    chNumMap.put(impDto.getChannelCode3(),channesList);
                }

                stockMapSet(stockMap, loginCh.getId(), loginCh.getChannelIdLevel1(), loginCh.getChannelIdLevel2(),  Stock.statistics_type_2, -1,tn.getOperatorCode());
                stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), chMaps.get(impDto.getChannelCode2()).getId(), loginCh.getId(),  Stock.statistics_type_1, 1,tn.getOperatorCode());
                stockMapSet(stockMap, chMaps.get(impDto.getChannelCode3()).getId(), chMaps.get(impDto.getChannelCode2()).getId(), loginCh.getId(),  Stock.statistics_type_2, 1,tn.getOperatorCode());
                
                addNmbRecord(nbrRecords ,tn, NmbRecordOptType.ALLOT.getId() ,
                        loginCh.getChannelName()+"["+loginCh.getChannelCode()+"]分配到："
                +chMaps.get(impDto.getChannelCode3()).getChannelName()+"["+chMaps.get(impDto.getChannelCode3()).getChannelCode()+"]" );
            }
            tn.setUpdateId(us.getId());
            tn.setUpdateTime(date);
            tn.setChannelId(impDto.getChannelId());
            tn.setChannelName(impDto.getChannelName());
            tn.setStatus(TNumber.STATUS_WAIT_ACTIVATE);
            upNums.add(tn);//需要修改状态为待开户
        }
        if(!Utils.isEmptyString(errStr)){
            rtnMap.put("stat",false);
            rtnMap.put("msg", errStr.toString().substring(0,errStr.toString().length()-1)+"，不能进行分配！");
            return rtnMap;
        }
        
        rtnMap.put("stat",true);
        return rtnMap;
    }
    
    /**
     * 有分配时记录库存分配记录表
     * @param chNumMap
     * @param us
     * @param date
     * @throws Exception
     */
    public void saveImportData(List<NumberChannel> numChs,Map<String,List<PhoneImportDto>> chNumMap,User us,Date date,String importType) throws Exception{
        for (String chaCode:chNumMap.keySet()){
            List<PhoneImportDto> dtos = chNumMap.get(chaCode);
            if(PhoneImportDto.allot_type_1.equals(dtos.get(0).getAllotType())){
                //分配给一级代理商
                allotComp(dtos,numChs,dtos.size(),us,date);//总部分配
            }else if(PhoneImportDto.allot_type_2.equals(dtos.get(0).getAllotType())){
                //分配给二级代理商
                if(Constant.PHONE_ALLOT_COMP.equals(importType)){
                    allotComp(dtos,numChs,dtos.size(),us,date);//总部分配
                    allot1(dtos, numChs, dtos.size(), us,date);//一级分配
                }else{
                    allot1(dtos, numChs, dtos.size(), us,date);//一级分配
                }
            }else if(PhoneImportDto.allot_type_3.equals(dtos.get(0).getAllotType())){
                //分配给三级网点
                if(Constant.PHONE_ALLOT_COMP.equals(importType)){
                    allotComp(dtos,numChs,dtos.size(),us,date);//总部分配一级
                    allot1(dtos, numChs, dtos.size(), us, date);//一级分配二级
                    allot2(dtos, numChs, dtos.size(), us, date);//二级分配网点
                }else if(Constant.PHONE_ALLOT_1.equals(importType)){
                    allot1(dtos, numChs, dtos.size(), us, date);//一级分配
                    allot2(dtos, numChs, dtos.size(), us, date);//二级分配
                }else{
                    allot2(dtos, numChs, dtos.size(), us, date);//二级分配
                }

            }else if(PhoneImportDto.allot_type_4.equals(dtos.get(0).getAllotType())){
                //分配给直属网点
                if(Constant.PHONE_ALLOT_COMP.equals(importType)){
                    allotComp(dtos,numChs,dtos.size(),us,date);//总部分配
                    allot3(dtos, numChs, dtos.size(),us,date);//分配给直属网点
                }else{
                    allot3(dtos, numChs, dtos.size(),us,date);//分配给直属网点
                }
            }
        }
    }

    /**
     * 总部分配
     * @param dtos
     * @param numChs
     * @param size
     * @param us
     * @param date
     * @throws Exception
     */
    public void allotComp(List<PhoneImportDto> dtos,List<NumberChannel> numChs,Integer size,User us,Date date) throws Exception{
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_2);
        stockAllot.setNum(size);
        stockAllot.setAllotType(StockAllot.allot_type_2);
        stockAllot.setChannelIdFrom(0);
        stockAllot.setChannelCodeFrom("0");
        stockAllot.setChannelNameFrom(StockAllot.com_name);
        stockAllot.setChannelIdTo(dtos.get(0).getChannelId1());
        stockAllot.setChannelCodeTo(dtos.get(0).getChannelCode1());
        stockAllot.setChannelNameTo(dtos.get(0).getChannelName1());
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);
        Integer status = NumberChannel.STATUS_2;
        if(PhoneImportDto.allot_type_1.equals(dtos.get(0).getAllotType())){
            status = NumberChannel.STATUS_1;
        }
        for (PhoneImportDto pDto:dtos){
            NumberChannel nc = new NumberChannel();
            nc.setPhoneId(pDto.getPhoneId());
            nc.setMoney(new BigDecimal(pDto.getMoney()));
            nc.setParChannelId(0);
            nc.setChannelId(pDto.getChannelId1());
            nc.setStatus(status);
            nc.setCreateId(us.getId());
            nc.setCreateTime(date);
            nc.setUpdateId(us.getId());
            nc.setUpdateTime(date);
            nc.setChannelIdLevel1(pDto.getChannelId1());
            nc.setCreateTimeLevel1(pDto.getChannelDate1());
            numChs.add(nc);
        }
    }

    /**
     * 一级分配
     * @param dtos
     * @param numChs
     * @param size
     * @param us
     * @param date
     * @throws Exception
     */
    public void allot1(List<PhoneImportDto> dtos,List<NumberChannel> numChs,Integer size,User us,Date date) throws Exception{
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_2);
        stockAllot.setNum(dtos.size());
        stockAllot.setAllotType(StockAllot.allot_type_2);
        stockAllot.setChannelIdFrom(dtos.get(0).getChannelId1());
        stockAllot.setChannelCodeFrom(dtos.get(0).getChannelCode1());
        stockAllot.setChannelNameFrom(dtos.get(0).getChannelName1());
        stockAllot.setChannelIdTo(dtos.get(0).getChannelId2());
        stockAllot.setChannelCodeTo(dtos.get(0).getChannelCode2());
        stockAllot.setChannelNameTo(dtos.get(0).getChannelName2());
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);

        Integer status = NumberChannel.STATUS_2;
        if(PhoneImportDto.allot_type_2.equals(dtos.get(0).getAllotType())){
            status = NumberChannel.STATUS_1;
        }
        for (PhoneImportDto pDto:dtos){
            NumberChannel nc = new NumberChannel();
            nc.setPhoneId(pDto.getPhoneId());
            nc.setMoney(new BigDecimal(pDto.getMoney()));
            nc.setParChannelId(pDto.getChannelId1());
            nc.setChannelId(pDto.getChannelId2());
            nc.setStatus(status);
            nc.setCreateId(us.getId());
            nc.setCreateTime(date);
            nc.setUpdateId(us.getId());
            nc.setUpdateTime(date);
            nc.setChannelIdLevel1(pDto.getChannelId1());
            nc.setCreateTimeLevel1(pDto.getChannelDate1());
            nc.setChannelIdLevel2(pDto.getChannelId2());
            nc.setCreateTimeLevel2(pDto.getChannelDate2());
            numChs.add(nc);
        }
    }

    /**
     * 二级分配
     * @param dtos
     * @param numChs
     * @param size
     * @param us
     * @param date
     * @throws Exception
     */
    public void allot2(List<PhoneImportDto> dtos,List<NumberChannel> numChs,Integer size,User us,Date date) throws Exception{
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_2);
        stockAllot.setNum(dtos.size());
        stockAllot.setAllotType(StockAllot.allot_type_2);
        stockAllot.setChannelIdFrom(dtos.get(0).getChannelId2());
        stockAllot.setChannelCodeFrom(dtos.get(0).getChannelCode2());
        stockAllot.setChannelNameFrom(dtos.get(0).getChannelName2());
        stockAllot.setChannelIdTo(dtos.get(0).getChannelId3());
        stockAllot.setChannelCodeTo(dtos.get(0).getChannelCode3());
        stockAllot.setChannelNameTo(dtos.get(0).getChannelName3());
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);
        Integer status = NumberChannel.STATUS_2;
        for (PhoneImportDto pDto:dtos){
            NumberChannel nc = new NumberChannel();
            nc.setPhoneId(pDto.getPhoneId());
            nc.setMoney(new BigDecimal(pDto.getMoney()));
            nc.setParChannelId(pDto.getChannelId2());
            nc.setChannelId(pDto.getChannelId3());
            nc.setStatus(status);
            nc.setCreateId(us.getId());
            nc.setCreateTime(date);
            nc.setUpdateId(us.getId());
            nc.setUpdateTime(date);
            nc.setChannelIdLevel1(pDto.getChannelId1());
            nc.setCreateTimeLevel1(pDto.getChannelDate1());
            nc.setChannelIdLevel2(pDto.getChannelId2());
            nc.setCreateTimeLevel2(pDto.getChannelDate2());
            numChs.add(nc);
        }
    }

    /**
     * 一级分配给直属网点
     * @param dtos
     * @param numChs
     * @param size
     * @param us
     * @param date
     * @throws Exception
     */
    public void allot3(List<PhoneImportDto> dtos,List<NumberChannel> numChs,Integer size,User us,Date date) throws Exception{
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_2);
        stockAllot.setNum(dtos.size());
        stockAllot.setAllotType(StockAllot.allot_type_2);
        stockAllot.setChannelIdFrom(dtos.get(0).getChannelId1());
        stockAllot.setChannelCodeFrom(dtos.get(0).getChannelCode1());
        stockAllot.setChannelNameFrom(dtos.get(0).getChannelName1());
        stockAllot.setChannelIdTo(dtos.get(0).getChannelId3());
        stockAllot.setChannelCodeTo(dtos.get(0).getChannelCode3());
        stockAllot.setChannelNameTo(dtos.get(0).getChannelName3());
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);
        Integer status = NumberChannel.STATUS_2;
        for (PhoneImportDto pDto:dtos){
            NumberChannel nc = new NumberChannel();
            nc.setPhoneId(pDto.getPhoneId());
            nc.setMoney(new BigDecimal(pDto.getMoney()));
            nc.setParChannelId(pDto.getChannelId1());
            nc.setChannelId(pDto.getChannelId());
            nc.setStatus(status);
            nc.setCreateId(us.getId());
            nc.setCreateTime(date);
            nc.setUpdateId(us.getId());
            nc.setUpdateTime(date);
            nc.setChannelIdLevel1(pDto.getChannelId1());
            nc.setCreateTimeLevel1(pDto.getChannelDate1());
            numChs.add(nc);
        }
    }
    
    /**
     * 记录号码变动记录表
     * @param nbrRecords
     * @param impDto
     * @param optType
     * @param st1
     * @param us
     * @throws Exception
     */
    public void addNmbRecord(List<NumberRecord> nbrRecords,TNumber n,Integer optType,String st1) throws Exception{
        NumberRecord nr = new NumberRecord();
        nr.setPhoneId(n.getId());
        nr.setPhone(n.getPhone());
        nr.setOptType(optType);
        nr.setOptStr(st1);
        nbrRecords.add(nr);
    }
    
    /**
     * 号码变动记录表入库
     * @param nbrRecords
     * @param pageCount
     * @param remark
     * @throws Exception
     */
    public void saveNbrRecordList(List<NumberRecord> nbrRecords,int pageCount,String remark,User us) throws Exception{
        //号码变动记录表入库
        if(nbrRecords.size() > 0){
            int dataCount = nbrRecords.size();
            int page = 0;//页数
            if(dataCount > pageCount){
                if(dataCount%pageCount !=0){
                    page = dataCount/pageCount +1;
                }else{
                    page = dataCount/pageCount;
                }
                int start=0,end=0;
                for (int i = 1; i <= page; i++) {
                    if (i * pageCount > dataCount) {
                        end = dataCount;
                    } else {
                        end = i * pageCount;
                    }
                    if (i == 1) {
                        start = i - 1;
                    } else {
                        start = (i - 1) * pageCount;
                    }
                    saveNbrRecord(nbrRecords,start, end,remark,us);
                }
            }else {
                saveNbrRecord(nbrRecords, 0, dataCount,remark,us);
            }
        }
    }

    
    /**
     * 号码变动记录表入库
     * @param numChIds
     * @throws Exception
     */
    public void saveNbrRecord(List<NumberRecord> nbrs,int start,int end,String remark,User us) throws Exception{
        if(null != nbrs && nbrs.size() >0){
            List<NumberRecord> saveList = new ArrayList<NumberRecord>();
            for (int i = start; i < end; i++) {
                NumberRecord r = nbrs.get(i);
                r.setRemark(remark);
                r.setCreateId(us.getId());
                r.setUpdateId(us.getId());
                saveList.add(r);
            }
            numberRecordMapper.batchInsert(saveList);
        }
    }
}

