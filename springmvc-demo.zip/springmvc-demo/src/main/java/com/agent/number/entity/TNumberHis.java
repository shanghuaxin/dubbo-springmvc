package com.agent.number.entity;

import com.agent.common.BaseDomain;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 号码表
 */
public class TNumberHis extends BaseDomain {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private String optionType;  //操作类型：1-回收，2-下架，3-销户
    private Date optionTime;        //操作时间
    private String phone;      //号码
    private String iccid;      //ICCID
    private String imsi;       //IMSI
    private String level;      //号码级别
    private String ascription; //号码归属地
    private Integer packagesId;  //套餐id
    private Integer channelId;   //渠道id
    private String channelName;  //渠道名称
    private Integer openChannelId;  //开户渠道id
    private String openChannelName; //开户渠道名称
    private Date openTime;        //开户时间
    private String Status;        //状态：待分配：WAIT_ALLOT，待开户：WAIT_ACTIVATE，开户待确认：WAIT_FINISH，已开户：FINISH_ACTIVATE
    private BigDecimal minFloat;  //低消：单位：分
    private BigDecimal prestore;  //预存：单位：分
    private BigDecimal money;     //面额
    private Date validTime;       //有效期
    private Integer subCheckId;   //提交审核渠道id
    private String checkStatus;   //当前审核状态（1待审核，2审核通过，3审核不通过）
    private Integer operatorCode; //运营商:1-移动，2-联通，3-电信
    private String remark;//备注

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getAscription() {
        return ascription;
    }

    public void setAscription(String ascription) {
        this.ascription = ascription;
    }

    public Integer getPackagesId() {
        return packagesId;
    }

    public void setPackagesId(Integer packagesId) {
        this.packagesId = packagesId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getOpenChannelId() {
        return openChannelId;
    }

    public void setOpenChannelId(Integer openChannelId) {
        this.openChannelId = openChannelId;
    }

    public String getOpenChannelName() {
        return openChannelName;
    }

    public void setOpenChannelName(String openChannelName) {
        this.openChannelName = openChannelName;
    }

    public Date getOpenTime() {
        return openTime;
    }

    public void setOpenTime(Date openTime) {
        this.openTime = openTime;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public BigDecimal getMinFloat() {
        return minFloat;
    }

    public void setMinFloat(BigDecimal minFloat) {
        this.minFloat = minFloat;
    }

    public BigDecimal getPrestore() {
        return prestore;
    }

    public void setPrestore(BigDecimal prestore) {
        this.prestore = prestore;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Date getValidTime() {
        return validTime;
    }

    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }

    public Integer getSubCheckId() {
        return subCheckId;
    }

    public void setSubCheckId(Integer subCheckId) {
        this.subCheckId = subCheckId;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public Integer getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(Integer operatorCode) {
        this.operatorCode = operatorCode;
    }

    public Date getOptionTime() {
        return optionTime;
    }

    public void setOptionTime(Date optionTime) {
        this.optionTime = optionTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
