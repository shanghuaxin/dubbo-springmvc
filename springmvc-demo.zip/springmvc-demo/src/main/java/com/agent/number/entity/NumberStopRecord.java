package com.agent.number.entity;

import com.agent.common.BaseDomain;

/**
 * 号码停机记录表
 */
public class NumberStopRecord extends BaseDomain {

    private static final long serialVersionUID = -2576987394038971745L;
    private Integer phoneId;    //号码id
    private String statusType;  //状态：1.停机 2.复机
    private String opinion;     //意见

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getStatusType() {
        return statusType;
    }

    public void setStatusType(String statusType) {
        this.statusType = statusType;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    @Override
    public String toString() {
        return "NumberStopRecord [phoneId=" + phoneId + ", statusType=" + statusType + ", opinion=" + opinion + "]";
    }

}
