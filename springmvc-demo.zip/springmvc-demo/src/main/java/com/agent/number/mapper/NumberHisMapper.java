package com.agent.number.mapper;

import com.agent.common.BaseMapper;
import com.agent.number.entity.TNumberHis;

import java.util.List;

public interface NumberHisMapper extends BaseMapper<TNumberHis, Integer> {
    public int batchInsert(List<TNumberHis> list);
}
