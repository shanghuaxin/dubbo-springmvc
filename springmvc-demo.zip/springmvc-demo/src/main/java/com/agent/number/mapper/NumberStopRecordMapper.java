package com.agent.number.mapper;

import com.agent.common.BaseMapper;
import com.agent.number.entity.NumberStopRecord;

public interface NumberStopRecordMapper extends BaseMapper<NumberStopRecord, Integer> {

}
