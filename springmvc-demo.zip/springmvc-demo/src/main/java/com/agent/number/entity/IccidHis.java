package com.agent.number.entity;

import com.agent.common.BaseDomain;

/**
 * iccid修改记录表
 */
public class IccidHis extends BaseDomain {

    /**
     * 
     */
    private static final long serialVersionUID = 3876161465514359254L;
    private String phone;
    private Integer phoneId;
    private String iccid;
    private String imsi;
    private String hisIccid;
    private String hisImsi;
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public Integer getPhoneId() {
        return phoneId;
    }
    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }
    public String getIccid() {
        return iccid;
    }
    public void setIccid(String iccid) {
        this.iccid = iccid;
    }
    public String getImsi() {
        return imsi;
    }
    public void setImsi(String imsi) {
        this.imsi = imsi;
    }
    public String getHisIccid() {
        return hisIccid;
    }
    public void setHisIccid(String hisIccid) {
        this.hisIccid = hisIccid;
    }
    public String getHisImsi() {
        return hisImsi;
    }
    public void setHisImsi(String hisImsi) {
        this.hisImsi = hisImsi;
    }
}
