package com.agent.number.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Resource;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.business.entity.RechargeRecord;
import com.agent.business.service.RechargeRecordService;
import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.channel.entity.ChannelAccount;
import com.agent.channel.entity.ChannelAccountTransaction;
import com.agent.channel.entity.Channels;
import com.agent.channel.mapper.ChannelAccountMapper;
import com.agent.channel.mapper.ChannelAccountTransactionMapper;
import com.agent.channel.mapper.ChannelsMapper;
import com.agent.channel.service.ChannelAccountService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.CommonUtil;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.AccountType;
import com.agent.common.enumeration.NmbRecordOptType;
import com.agent.common.enumeration.NumberStatus;
import com.agent.common.enumeration.OperationType;
import com.agent.common.enumeration.OrderNOEnum;
import com.agent.common.enumeration.PhoneStatus;
import com.agent.common.enumeration.StatusType;
import com.agent.common.enumeration.UnicomAndAgentStatus;
import com.agent.constant.Constant;
import com.agent.file.dto.PhoneImportDto;
import com.agent.file.mapper.AttachFileMapper;
import com.agent.number.dto.NumberDTO;
import com.agent.number.dto.NumberIccidDTO;
import com.agent.number.dto.NumberTopUpRestDTO;
import com.agent.number.entity.IccidHis;
import com.agent.number.entity.IccidPool;
import com.agent.number.entity.IccidRecord;
import com.agent.number.entity.NumberChannel;
import com.agent.number.entity.NumberRecord;
import com.agent.number.entity.NumberStopRecord;
import com.agent.number.entity.TNumber;
import com.agent.number.entity.TNumberHis;
import com.agent.number.mapper.IccidHisMapper;
import com.agent.number.mapper.IccidPoolMapper;
import com.agent.number.mapper.IccidRecordMapper;
import com.agent.number.mapper.NumberChannelMapper;
import com.agent.number.mapper.NumberHisMapper;
import com.agent.number.mapper.NumberMapper;
import com.agent.number.mapper.NumberRecordMapper;
import com.agent.number.mapper.NumberStopRecordMapper;
import com.agent.number.util.NumberUtil;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.entity.Biz;
import com.agent.online.entity.OlRecharge;
import com.agent.online.mapper.BizMapper;
import com.agent.online.mapper.OlRechargeMapper;
import com.agent.openaccount.dto.BuyServRecordDTO;
import com.agent.openaccount.entity.Account;
import com.agent.openaccount.entity.ApplyIdentity;
import com.agent.openaccount.entity.AttachedDocuments;
import com.agent.openaccount.entity.BizSee;
import com.agent.openaccount.entity.Check;
import com.agent.openaccount.entity.IdcardInfo;
import com.agent.openaccount.entity.Identity;
import com.agent.openaccount.entity.PreSubs;
import com.agent.openaccount.entity.PreSubsHis;
import com.agent.openaccount.mapper.AccountMapper;
import com.agent.openaccount.mapper.ApplyIdentityMapper;
import com.agent.openaccount.mapper.AttachedDocumentsMapper;
import com.agent.openaccount.mapper.BizSeeMapper;
import com.agent.openaccount.mapper.CheckMapper;
import com.agent.openaccount.mapper.IdcardInfoMapper;
import com.agent.openaccount.mapper.IdentityMapper;
import com.agent.openaccount.mapper.PreSubsHisMapper;
import com.agent.openaccount.mapper.PreSubsMapper;
import com.agent.openaccount.service.ApplyIdentityService;
import com.agent.openaccount.service.BuyService;
import com.agent.openaccount.service.IdentityService;
import com.agent.order.common.util.JSONUtil;
import com.agent.order.entity.Order;
import com.agent.order.service.OrderDetailService;
import com.agent.order.service.OrderService;
import com.agent.product.entity.Packages;
import com.agent.product.entity.Product;
import com.agent.product.mapper.PackagesMapper;
import com.agent.stock.dto.StockNumDto;
import com.agent.stock.entity.Stock;
import com.agent.stock.entity.StockAllot;
import com.agent.stock.mapper.StockAllotMapper;
import com.agent.stock.service.StockService;
import com.agent.system.entity.CodeDictionary;
import com.agent.system.entity.User;
import com.agent.system.mapper.UserMapper;
import com.agent.system.service.CodeDictionaryService;
import com.agent.technology.entity.MsgPush;
import com.agent.technology.entity.NewsInfo;
import com.agent.technology.mapper.MsgPushMapper;
import com.agent.technology.mapper.NewsInfoMapper;
import com.agent.util.DateUtil;
import com.agent.util.DecimalUtil;
import com.agent.util.DicUtil;
import com.agent.util.MD5;
import com.agent.util.PhoneOpenUtil;
import com.agent.util.SysConfig;
import com.agent.util.Utils;

import namespace.webservice.crmsps.ContractRoot;
import zsmart.ztesoft.com.xsd.TCoerciveBlockBOSSBO;
import zsmart.ztesoft.com.xsd.TModCustomerBOSSBO;
import zsmart.ztesoft.com.xsd.TNewConnectionBOSSRequest;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBO;
import zsmart.ztesoft.com.xsd.TServiceDto;
import zsmart.ztesoft.com.xsd.TServiceDtoBO;

@Transactional(rollbackFor=Exception.class)
@Service("numberService")
public class NumberService {
    
    private static Logger logger = LoggerFactory.getLogger(NumberService.class);
    @Autowired
    private NumberMapper numberMapper;
    @Autowired
    private ApplyIdentityMapper applyIdentityMapper;
    @Autowired
    private IdentityMapper identityMapper;
    @Autowired
    private AccountMapper accountMapper;
    @Autowired
    private ChannelAccountMapper channelAccountMapper;
    @Autowired
    private PackagesMapper packagesMapper;
    @Autowired
    private IdcardInfoMapper idcardInfoMapper;
    @Autowired
    private CheckMapper checkMapper;
    @Autowired
    private AttachedDocumentsMapper documentsMapper;
    @Autowired
    private BusinessLogService businessLogService;
    @Autowired
    private ChannelsMapper channelsMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PreSubsMapper preSubsMapper;
    @Autowired
    private PreSubsHisMapper preSubsHisMapper;
    @Autowired
    private BuyService buyService;
    @Autowired
    private ChannelsService channelsService;
    @Autowired
    private ApplyIdentityService applyIdentityService;
    @Autowired
    private IdentityService identityService;
    @Autowired
    private ChannelAccountTransactionMapper transactionMapper;
    @Autowired
    private NumberStopRecordMapper numberStopRecordMapper;
    @Autowired
    private CodeDictionaryService codeDictionaryService;
    @Autowired
    private StockService stockService;
    @Resource
    private NumberUtil numberUtil;
    @Resource
    private StockAllotMapper stockAllotMapper;
    @Resource
    private AttachFileMapper attachFileMapper;
    @Resource
    private NumberChannelMapper numChMapper;
    @Resource
    private NumberHisMapper numHisMapper;
    @Autowired
    private BOSSNewBuyService bossNewBuyService;
    @Autowired
    private RechargeRecordService rechargeRecordService;
    @Autowired
    private ChannelAccountService channelAccountService;
    @Autowired
    private ChannelAccountService accountService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private OrderDetailService orderDetailService;
    @Autowired
    private MsgPushMapper msgPushMapper;
    @Autowired
    private NewsInfoMapper newsInfoMapper;
    @Autowired
    private IccidHisMapper iccidHisMapper;
    @Autowired
    private BizSeeMapper bizSeeMapper;
    @Autowired
    private BizMapper bizMapper;
    @Resource
    private IccidRecordMapper iccidRecordMapper;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    @Autowired
    private NumberRecordMapper numberRecordMapper;
    @Autowired
    private IccidPoolMapper iccidPoolMapper;
    @Autowired
    private OlRechargeMapper olRechargeMapper;
    @Autowired
    private com.agent.api.service.IDCheckService IDCheckService;
    
    public  final static Map<Long,ReentrantLock> locks = new HashMap<Long, ReentrantLock>();
    
    public TNumber findByPhoneId(Integer phoneId){
        return numberMapper.select(phoneId);
    }
    
    /**
     * 号码效验。成功后进行号码审核
     * 
     * @param obj
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus phoneTestExamine(NumberTopUpRestDTO obj, String openSources, Channels channel) throws Exception {
        synchronized (NumberService.class) {
            if (null == channel) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，您的登录已超时，请重新登录！");
            }
            //根据当前登录渠道信息查找当前操作用户
            User user = userMapper.findUserByChannelId(channel.getId());
            if(user == null){
                return new RestStatus(Boolean.FALSE, "500", "开户失败，开户网点不存在！");
            }
            try {
                Date date = new Date();
                BigDecimal mm = new BigDecimal("100");
                if (Utils.isEmptyString(obj.getCode()) || Utils.isEmptyString(obj.getName())) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，请正确填写用户资料！");
                } else if (obj.getCode().length() != 15 && obj.getCode().length() != 18) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，请使用正确身份证！");
                }
                BigDecimal moneya = new BigDecimal(obj.getMoney());
                BigDecimal money = moneya.multiply(mm);
                BigDecimal orderMoney = BigDecimal.valueOf(Double.valueOf(obj.getMoney()));   //开卡金额

                TNumber n = numberMapper.findByPhone(obj.getPhone());
                if (null == n) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，号码输入不正确！");
                } else if (!PhoneStatus.US02.getId().equals(n.getStatus())) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，号码已开户！");
                } else if (money.doubleValue() < 0) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，开户金额不能低于0 ！");
                } else if (DecimalUtil.sub(money.doubleValue(), n.getMoney().doubleValue()) < 0) {
                    BigDecimal reMOney = n.getMoney();
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，开户金额不能低于" + reMOney.divide(mm).toString() + "！");
                } else if (1 == DateUtil.getInstance().compareDate(new Date(), n.getValidTime(), "yyyy-MM-dd")) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，该号码已经过期，不能进行开户！");
                } 
                Boolean isApply = phoneIsApply(n.getId());
                if(isApply){//查询待审核信息
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，该号码已经在审核流程中！");
                }
                
                int nu = identityMapper.findIdentityNumByCode(obj.getCode());
                int phoneCountMax = 0;
                try {
                    phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
                } catch (Exception e1) {
                    phoneCountMax = 5;
                }
                if (nu >= phoneCountMax) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，您已开户"+nu+"个号码，不能再进行开户！");
                }

                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", n);
                param.put("channelId", channel.getId());
                param.put("accountType", null);
                param.put("operationType", 16);
                param.put("money", money);
                param.put("busMoney", n.getMoney());
                param.put("remark", null);
                param.put("transactionAccount", null);
                param.put("transId", null);
                param.put("transactionType", null);
                param.put("calcType", null);
                param.put("transactionFlow", null);
                param.put("payType", null);
                param.put("us", user);
                // 扣款
                RestStatus rs = takeMoney(param);
                if (!rs.getStatus()) {
                    return rs; // 账户金额不足
                }

                obj.setCode(obj.getCode().toUpperCase());
                // 获取IMSI 改IMSI一定存在 而且只有一条
                NumberIccidDTO dto = numberMapper.phoneIccidByPhoneId(n.getId());
//                    Integer mealId = dto.getMealId();// 号码绑定套餐id
               
                String mealNames = "";
                // 添加默认选中套餐编码
                if(obj.getMealCodes() != null && !obj.getMealCodes().equals("")) {
                    String[] mealsArr = obj.getMealCodes().split(",");
                    List<String> mealList = Arrays.asList(mealsArr);
                    List<Packages> packages = packagesMapper.findByCodes(mealList);
                    if(packages != null && packages.size() > 0){
                        for (Packages p : packages) {
                            mealNames += p.getName() + ",";
                            
                            if(n.getOperatorCode()==2 && p.getCode().equals(mealsArr[0])) {
                                //联通号码开户的时候需要将number表的packageId字段添加数据,值为主套餐ID
                                n.setPackagesId(p.getId());
                                n.setPackagesName(p.getName());
                                
                                dto.setMealCode(p.getCode());
                                dto.setMealId(p.getId());
                            }
                        }
                        
                        mealNames = mealNames.substring(0, mealNames.length() - 1);
                    }
                }
                
                //如果是联通手机号，需要调用接口
                String custOrderId=null;
                String flag = SysConfig.getValue("SendToBoss");
                if (flag != null && flag.equals("true") && n.getOperatorCode()==2){// 联通接口
                    Packages packages = packagesMapper.findByCode(obj.getMealCodes().split(",")[0]);
                    dto.setMealId(packages.getId());//联通选择套餐ID
                    dto.setMealCode(packages.getCode());//联通选择套餐CODE
                    dto.setMealName(packages.getName());//联通选择套餐NAME
                    
                    obj.setChannelId(channel.getId()+"");
                    RestStatus rsStatus = bossUnicomService.saveBudgetOrder(obj, user);
                    if(rsStatus.getStatus()){
                        ContractRoot root = (ContractRoot)rsStatus.getResponseData();
                        custOrderId = root.getSvcCont().getCustOrderId();
                    } else {
                        throw new Exception(rsStatus.getErrorMessage());
                    }
                }
                
                // 增加身份证信息
                IdcardInfo g = new IdcardInfo();
                g.setName(obj.getName());
                if(StringUtils.equals("男", obj.getSexual())){
                    g.setSexual("1");
                }else if(StringUtils.equals("女", obj.getSexual())){
                    g.setSexual("0");
                }else{
                    g.setSexual(obj.getSexual());
                }
                g.setNation(obj.getNation());
                g.setAddress(obj.getAddress());
                g.setIdNumber(obj.getCode().trim());
                g.setOrgans(obj.getOrgans());
                g.setExpiryDate(obj.getExpiryDate());
                String idcardInfoJson = JSONUtil.objectToJson(g);
                
                // 增加开户信息
                ApplyIdentity d = new ApplyIdentity();
                d.setCode(obj.getCode());
                d.setName(obj.getName());
                d.setPhone(obj.getPhone());
                d.setPhoneId(n.getId());
                d.setStatus("0");
                d.setContactPhone(obj.getContactPhone());
                d.setOpenDate(date);
                if(obj.getMealCodes() == null || obj.getMealCodes().equals("")) {
                    d.setMealNames(dto.getMealName());
                }else {
                    d.setMeals(obj.getMealCodes());
                    d.setMealNames(mealNames);
                }
                d.setChannelId(channel.getId());
                if (!Utils.isEmptyString(obj.getMoney())) {
                    d.setMoney(BigDecimal.valueOf(Float.valueOf(obj.getMoney()) * 100));
                }
                d.setOpenSources(openSources);
                d.setOrderMoney(orderMoney);
                d.setChannelId(channel.getId());
                d.setOpenMeals(obj.getMealCodes());
                d.setOpenMealCode(dto.getMealCode());
                d.setOpenMealId(dto.getMealId());
                d.setCheckStatus("1");
                d.setIdcardinfo(idcardInfoJson);
                d.setCustOrderId(custOrderId);
                
                Integer identId;
                if (isExitFeccheck(n.getPhone()) == 3) {
                    ApplyIdentity f = applyIdentityMapper.findByPhoneId(n.getId());
                    identId=f.getId();
                    
                    d.setId(f.getId());
                    d.setUpdateId(user.getId());
                    d.setUpdateTime(date);
                    
                    applyIdentityMapper.update(d);
                }else{
                    d.setCreateId(user.getId());
                    d.setCreateTime(date);
                    d.setUpdateId(user.getId());
                    d.setUpdateTime(date);
                    
                    applyIdentityMapper.insert(d);
                    identId=d.getId();
                }

                //删除代理商查看号码关系表
                bizSeeMapper.deleteByPhoneId(n.getId());
                //代理商查看号码关系表
                BizSee bizSee = new BizSee();
                bizSee.setChannelIdLevel1(channel.getChannelIdLevel1());
                bizSee.setChannelIdLevel2(channel.getChannelIdLevel2());
                bizSee.setChannelIdLevel3(channel.getId());
                bizSee.setPhone(n.getPhone());
                bizSee.setPhoneId(n.getId());
                bizSee.setProCreateTime(n.getCreateTime());
                bizSee.setCreateId(user.getId());
                bizSee.setCreateTime(date);
                bizSee.setUpdateId(user.getId());
                bizSee.setUpdateTime(date);
                
                bizSeeMapper.insert(bizSee);
                
                // 向审核表添加数据
                Check check = new Check();
                check.setSourceId(identId);
                check.setPhoneId(n.getId());
                check.setWayType("2");
                check.setStatusType("1");
                check.setChannelId(d.getChannelId());
                check.setCreateId(user.getId());
                check.setCreateTime(date);
                check.setUpdateId(user.getId());
                check.setUpdateTime(date);
                
                checkMapper.insert(check);
                //如果重新开卡，删除以前的照片信息
                List<AttachedDocuments> documents = documentsMapper.findBySourceIdAndSourceName(identId, "t_apply_identity");
                if (null != documents && documents.size() > 0){
                    documentsMapper.deleteBySourceIdAndSourceName(identId, "t_apply_identity");
                }
                // pc开户上传照片和开户同时进行
                List<AttachedDocuments> atts = obj.getAtts();
                if (null != atts && atts.size() > 0) {
                    for (AttachedDocuments att : atts) {
                        att.setSourceId(identId);
                    }
                    insertFeAttachment(atts);
                }
                n.setCurOpenChannelId(channel.getId());
                n.setOpenWay(obj.getOpenWay());
                n.setSubCheckId(channel.getId());
                n.setOpenTime(date);
                n.setCheckStatus(Check.audit_apply);
                n.setCheckNoNum(0);
                numberMapper.update(n);

                Map<String, String> map = new HashMap<String, String>();
                map.put("staff", user.getLoginName());
                map.put("channelName", channel.getChannelName());
                map.put("channelCode", channel.getChannelCode());
                map.put("phone", obj.getPhone());
                map.put("money", obj.getMoney());
                map.put("createDate", DateUtil.getInstance().formatDate(date, "yyyy-MM-dd HH:mm:ss"));
                map.put("result", "申请成功,进入待审核！");
                businessLogService.businessSaveLog(Business.phone_open_apply, String.valueOf(user.getId()),
                        user.getLoginName(), "", "号码申请", map);
                return new RestStatus(Boolean.TRUE, "200", "申请成功,进入待审核！");
            } catch (Exception e) {
                logger.error("号码开户失败，号码" + obj.getPhone() + "增值业务" + obj.getMealCodes() + ",原因：" + e.getMessage(), e);
                throw new Exception("号码开户失败，号码" + obj.getPhone() + ",原因：" + e.getMessage());
            }
        }
    }
    
    /**
     * boss预开户号码开户
     * 
     * @param obj
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus prePhoneActivite(NumberTopUpRestDTO obj, String openSources, Channels fd) throws Exception {
        synchronized (NumberService.class) {
            if (null == fd) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，您的登录已超时，请重新登录！");
            }
            //根据当前登录渠道信息查找当前操作用户
            User user = userMapper.findUserByChannelId(fd.getId());
            if(user == null){
                return new RestStatus(Boolean.FALSE, "500", "开户失败，开户网点不存在！");
            }
            
            BigDecimal mm = new BigDecimal("100");
            if (Utils.isEmptyString(obj.getCode()) || Utils.isEmptyString(obj.getName())) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，请正确填写用户资料！");
            } else if (obj.getCode().length() != 15 && obj.getCode().length() != 18) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，请使用正确身份证！");
            }
            
            Date date = new Date();
            try {
                BigDecimal moneya = new BigDecimal(obj.getMoney());
                TNumber n = numberMapper.findByPhone(obj.getPhone());
                BigDecimal money = moneya.multiply(mm);
                BigDecimal orderMoney = BigDecimal.valueOf(Double.valueOf(obj.getMoney()));
                
                if (null == n) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，号码输入不正确！");
                } else if(n.getOperatorCode()==2){
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，联通号码不做预开户！");
                } else if (!PhoneStatus.US02.getId().equals(n.getStatus())) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，号码已开户！");
                } else if (money.doubleValue() < 0) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，开户金额不能低于0 ！");
                } else if (DecimalUtil.sub(money.doubleValue(), n.getMoney().doubleValue()) < 0) {
                    BigDecimal reMOney = n.getMoney();
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，开户金额不能低于" + reMOney.divide(mm).toString() + "！");
                } else if (1 == DateUtil.getInstance().compareDate(new Date(), n.getValidTime(), "yyyy-MM-dd")) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，该号码已经过期，不能进行开户！");
                } else {
                    int nu = identityMapper.findIdentityNumByCode(obj.getCode());
                    int phoneCountMax = 0;
                    try {
                        phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
                    } catch (Exception e1) {
                        phoneCountMax = 5;
                    }
                    if (nu >= phoneCountMax) {
                        return new RestStatus(Boolean.FALSE, "500", "开户失败，您已开户"+phoneCountMax+"个号码，不能再进行开户！");
                    }
                    
                    // 获取IMSI 改IMSI一定存在 而且只有一条
                    NumberIccidDTO dto = numberMapper.phoneIccidByPhoneId(n.getId());
                    Integer mealId = dto.getMealId();// 号码绑定套餐id
                    
                    String mealNames = "";
                    // 添加默认赠送套餐编码
                    if(obj.getMealCodes() != null && !obj.getMealCodes().equals("")) {
                        String[] mealsArr = obj.getMealCodes().split(",");
                        List<String> mealList = Arrays.asList(mealsArr);
                        List<Packages> packages = packagesMapper.findByCodes(mealList);
                        if(packages != null && packages.size() > 0){
                            for (Packages p : packages) {
                                mealNames += p.getName() + ",";
                            }
                            
                            mealNames = mealNames.substring(0, mealNames.length() - 1);
                        }
                    }
                    
                    orderMoney = mealealMoneyByCodes(null, mealId);

                    // 构造takeMoney入参
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("number", n);
                    param.put("channelId", fd.getId());
                    param.put("accountType", null);
                    param.put("operationType", 17);
                    param.put("money", money);
                    param.put("busMoney", n.getMoney());
                    param.put("remark", null);
                    param.put("transactionAccount", null);
                    param.put("transId", null);
                    param.put("transactionType", null);
                    param.put("calcType", null);
                    param.put("transactionFlow", null);
                    param.put("payType", null);
                    param.put("us", user);
                    // 扣款
                    RestStatus rs = takeMoney(param);
                    if (!rs.getStatus()) {
                        return rs; // 预备金不足
                    }
                    
                    // 查询调用调用BOSS接口是否打开
                    String flag = SysConfig.getValue("SendToBoss");
                    n.setCurOpenChannelId(fd.getId());
                    n.setOpenWay(obj.getOpenWay());
                    n.setSubCheckId(fd.getId());
                    n.setCheckStatus("1");
                    n.setStatus(PhoneStatus.US03.getId());
                    n.setOpenTime(date);
                    n.setOpenChannelId(fd.getId());
                    n.setOpenChannelName(fd.getChannelName());
                    numberMapper.update(n);
                    
                    //号码信息变动表
                    NumberRecord r = new NumberRecord();
                    r.setPhoneId(n.getId());
                    r.setPhone(n.getPhone());
                    r.setOptType(NmbRecordOptType.OPEN.getId());
                    r.setOptStr("代理商："+fd.getChannelName()+"["+fd.getChannelCode()+"]开户成功");
                    r.setCreateId(user.getId());
                    r.setUpdateId(user.getId());
                    numberRecordMapper.insert(r);
                    
                    //添加身份信息表
                    IdcardInfo g = new IdcardInfo();
                    g.setName(obj.getName());
                    if(StringUtils.equals("男", obj.getSexual())){
                        g.setSexual("1");
                    }else if(StringUtils.equals("女", obj.getSexual())){
                        g.setSexual("0");
                    }else{
                        g.setSexual(obj.getSexual());
                    }
                    g.setNation(obj.getNation());
                    g.setAddress(obj.getAddress());
                    g.setIdNumber(obj.getCode().trim());
                    g.setOrgans(obj.getOrgans());
                    g.setExpiryDate(obj.getExpiryDate());
                    int totalCount = idcardInfoMapper.findCountByIdNumber(g.getIdNumber());
                    if(totalCount == 0){
                        // 向身份证信息表添加数据
                        idcardInfoMapper.insert(g);
                    }else{
                        // 向身份证信息表更新数据
                        idcardInfoMapper.update(g);
                    }
                    
                    // 增加开户信息
                    Identity d = new Identity();
                    d.setCode(obj.getCode());
                    d.setName(obj.getName());
                    d.setPhone(obj.getPhone());
                    d.setPhoneId(n.getId());
                    d.setStatus("1");// 预开户号码默认已报峻
                    d.setContactPhone(obj.getContactPhone());
                    d.setOpenDate(date);
                    if(obj.getMealCodes() == null || obj.getMealCodes().equals("")) {
                        d.setMeals(String.valueOf(mealId));
                    }else {
                        d.setMeals(obj.getMealCodes());
                    }
                    d.setChannelId(fd.getId());
                    d.setChannelIdLevel1(fd.getChannelIdLevel1());
                    d.setChannelIdLevel2(fd.getChannelIdLevel2());
                    d.setChannelIdLevel3(fd.getId());
                    if (!Utils.isEmptyString(obj.getMoney())) {
                        d.setMoney(BigDecimal.valueOf(Float.valueOf(obj.getMoney()) * 100));
                    }
                    d.setOpenSources(openSources);
                    d.setOrderMoney(orderMoney);
                    d.setOpenMealId(dto.getMealId());
                    d.setOpenMealCode(dto.getMealCode());
                    d.setCreateId(user.getId());
                    d.setCreateTime(date);
                    d.setUpdateId(user.getId());
                    d.setUpdateTime(date);
                    
                    identityMapper.insert(d);
                    Integer identId = d.getId();
                    // pc开户上传照片
                    List<AttachedDocuments> atts = obj.getAtts();
                    if (null != atts && atts.size() > 0) {
                        for (AttachedDocuments att : atts) {
                            att.setSourceId(identId);
                        }
                        insertFeAttachment(atts);
                    }
                    
                    // 预开卡数据处理到已开户表
                    PreSubs preSubs = preSubsMapper.findSubsByPhone(n.getPhone());
                    PreSubsHis preSubsHis = new PreSubsHis();
                    preSubsHis.setPhone(preSubs.getPhone());
                    preSubsHis.setPasswd(preSubs.getPasswd());
                    preSubsHis.setIccid(preSubs.getIccid());
                    preSubsHis.setImsi(preSubs.getImsi());
                    preSubsHis.setServCode(preSubs.getServCode());
                    preSubsHis.setServName(preSubs.getServName());
                    preSubsHis.setAdvanceTime(preSubs.getAdvanceTime());
                    preSubsHis.setSource(preSubs.getSource());
                    preSubsHis.setChannelId(fd.getId());
                    preSubsHis.setOpenTime(date);
                    preSubsHis.setCreateId(user.getId());
                    preSubsHis.setCreateTime(date);
                    preSubsHis.setUpdateId(user.getId());
                    preSubsHis.setUpdateTime(date);
                    //已完成的预开户记录表
                    preSubsHisMapper.insert(preSubsHis);
                    //已完成的预开户记录,删除预开户记录
                    preSubsMapper.deleteSubsByPhone(n.getPhone());
                    
                    //删除代理商查看号码关系表
                    bizSeeMapper.deleteByPhoneId(n.getId());
                    
                    //代理商查看号码关系表
                    BizSee bizSee = new BizSee();
                    bizSee.setChannelIdLevel1(fd.getChannelIdLevel1());
                    bizSee.setChannelIdLevel2(fd.getChannelIdLevel2());
                    bizSee.setChannelIdLevel3(fd.getId());
                    bizSee.setPhone(n.getPhone());
                    bizSee.setPhoneId(n.getId());
                    bizSee.setProCreateTime(n.getCreateTime());
                    bizSee.setCreateId(user.getId());
                    bizSee.setCreateTime(date);
                    bizSee.setUpdateId(user.getId());
                    bizSee.setUpdateTime(date);
                    
                    bizSeeMapper.insert(bizSee);
                    
                    // 向审核表添加数据
                    Check check = new Check();
                    check.setSourceId(identId);
                    check.setPhoneId(n.getId());
                    check.setWayType("2");
                    check.setStatusType("1");
                    check.setChannelId(fd.getId());
                    check.setCreateId(user.getId());
                    check.setCreateTime(date);
                    check.setUpdateId(user.getId());
                    check.setUpdateTime(date);
                    
                    checkMapper.insert(check);
                    
                    // 订购业务入消息推送表
                    List<BuyServRecordDTO> buys = new ArrayList<BuyServRecordDTO>();
                    if (!Utils.isEmptyString(obj.getMealCodes())) {
                        // 选择的增值套餐
                        String meal[] = obj.getMealCodes().split(",");
                        List<String> mealList = new ArrayList<>();
                        for (int i = 0; i < meal.length; i++) {
                            if (Utils.isEmptyString(meal[i])) {
                                continue;
                            }
                            if (!mealList.contains(meal[i])) {
                                mealList.add(meal[i]);
                            } else {
                                continue;
                            }
                            
                        }
                        
                        if(mealList.size() >0){
                            List<Packages> ps  = packagesMapper.findByCodes(mealList);
                            if(ps != null && ps.size() >0){
                                if(ps.size() != mealList.size()){
                                    logger.error("开户失败，您购买的增值业务无法订购");
                                    throw new Exception("开户失败，您购买的增值业务无法订");
                                }else{
                                    for(Packages p:ps){
                                        BuyServRecordDTO recordDTO = new BuyServRecordDTO();
                                        recordDTO.setPhone(obj.getPhone());
                                        recordDTO.setPhoneId(n.getId());
                                        //来电提醒
                                        if("1".equals(p.getServType())){
                                            recordDTO.setBuyType("3");
                                            recordDTO.setMemo("来电提醒");
                                            recordDTO.setServCode(p.getCode());
                                            recordDTO.setServName("来电提醒");
                                        }else if("2".equals(p.getServType())){
                                            //来电显示
                                            recordDTO.setBuyType("3");
                                            recordDTO.setMemo("来电显示");
                                            recordDTO.setServCode(p.getCode());
                                            recordDTO.setServName("来电显示");
                                        }else if("3".equals(p.getServType())){
                                            //语音业务
//                                        recordDTO.setBuyType("3");
//                                        recordDTO.setMemo("语音业务");
//                                        recordDTO.setServCode(p.getCode());
//                                        recordDTO.setServName("语音业务");
                                        }else if("4".equals(p.getServType())){
                                            //流量业务
                                            recordDTO.setBuyType("6");
                                            recordDTO.setMemo("流量业务");
                                            recordDTO.setServCode(p.getCode());
                                            recordDTO.setServName("流量业务");
                                        }else if("5".equals(p.getServType())){
                                            //组合业务
                                            recordDTO.setBuyType("7");
                                            recordDTO.setMemo("组合业务");
                                            recordDTO.setServCode(p.getCode());
                                            recordDTO.setServName("组合业务");
                                        }
                                        
                                        recordDTO.setNowsType("1");
                                        recordDTO.setStatus("1");
                                        recordDTO.setPortNum(0);
                                        StringBuffer parmStr = new StringBuffer();
                                        // 拼接参数内容
                                        if ("1".equals(p.getServType()) || "2".equals(p.getServType())) {
                                            parmStr.append("MSISDN:").append("86" + obj.getPhone()).append(",");
                                            parmStr.append("OperType:").append("0").append(",");
                                            parmStr.append("ServiceCode:").append(p.getCode());
                                            if ("420".equals(p.getCode())) {
                                                recordDTO.setOrderNum(4);
                                            } else {
                                                recordDTO.setOrderNum(5);
                                            }
                                        } else if ("4".equals(p.getServType())) {
                                            parmStr.append("MSISDN:").append("86" + obj.getPhone()).append(",");
                                            parmStr.append("OperType:").append("0").append(",");
                                            parmStr.append("NewOfferId:").append(p.getCode());
                                            recordDTO.setOrderNum(2);
                                        } else if ("5".equals(p.getServType())) {
                                            parmStr.append("MSISDN:").append("86" + obj.getPhone()).append(",");
                                            parmStr.append("OperType:").append("0").append(",");
                                            parmStr.append("NewOfferId:").append(p.getCode());
                                            recordDTO.setOrderNum(3);
                                        }
                                        recordDTO.setParmStr(parmStr.toString());
                                        recordDTO.setChannelId(fd.getId());
                                        recordDTO.setChannelName(fd.getChannelName());
                                        recordDTO.setCertName(obj.getName());
                                        recordDTO.setCertNbr(obj.getCode());
                                        recordDTO.setSourceType(openSources);
                                        recordDTO.setCreateId(user.getId());
                                        recordDTO.setUpdateId(user.getId());
                                        recordDTO.setNetwork(String.valueOf(n.getOperatorCode()));
                                        recordDTO.setPushTime(date);
                                        buys.add(recordDTO);
                                    }
                                }
                            }else{
                                logger.error("开户失败，您购买的增值业务无法订购");
                                throw new Exception("开户失败，您购买的增值业务无法订");
                            }
                        }
                    }
                    
                    BuyServRecordDTO recordDTO = new BuyServRecordDTO();
                    recordDTO.setPhone(obj.getPhone());
                    recordDTO.setPhoneId(n.getId());
                    recordDTO.setBuyType("2");
                    recordDTO.setMemo("号码复机");
                    recordDTO.setNetwork("1");
                    recordDTO.setServCode("");
                    recordDTO.setServName("号码复机");
                    recordDTO.setNowsType("1");
                    recordDTO.setStatus("1");
                    recordDTO.setPortNum(0);
                    StringBuffer parmStr = new StringBuffer();
                    parmStr.append("MSISDN:").append("86" + obj.getPhone());
                    recordDTO.setParmStr(parmStr.toString());
                    recordDTO.setOrderNum(1);
                    recordDTO.setChannelId(fd.getId());
                    recordDTO.setChannelName(fd.getChannelName());
                    recordDTO.setCertName(obj.getName());
                    recordDTO.setCertNbr(obj.getCode());
                    recordDTO.setSourceType(openSources);
                    recordDTO.setCreateId(user.getId());
                    recordDTO.setUpdateId(user.getId());
                    recordDTO.setNetwork(String.valueOf(n.getOperatorCode()));
                    recordDTO.setPushTime(date);
                    buys.add(recordDTO);
                    buyService.busServRecordSave(buys);
                    
                    logger.error("接口配置：" + flag + "调用接口开始");
                    
                    if(n.getOperatorCode()==1){
                     // 同以用户充值或复机失败都不再调用过户接口
                        if (!("1".equals(preSubs.getStatus()) && d.getCode().equals(preSubs.getCode()))) {
                            TModCustomerBOSSBO bo = new TModCustomerBOSSBO();
                            bo.setMSISDN("86" + obj.getPhone());
                            bo.setCertType("1");// 身份证
                            bo.setCertNbr(obj.getCode());
                            // 身份证最后一位为字母转换为0
                            if (obj.getCode().toUpperCase().indexOf("X") > 0) {
                                bo.setCertNbr(obj.getCode().toUpperCase().replaceAll("X", "0"));
                            }
                            bo.setCustName(obj.getName());
                            if (flag != null && flag.equals("true")) {
                                logger.error("----------------------------- 号码：" + obj.getPhone() + "预开卡号码开户开始调用接口 ,时间：" + System.nanoTime() + "-----------------------------");
                                
                                RestStatus rs1 = bossNewBuyService.ModCustomerBOSS(bo,  "1", user);
                                
                                if(!rs1.getStatus()){
                                    throw new Exception("预开卡号码开户调用接口错误！" + rs1.getErrorMessage());
                                }
                                /*try {
                                bossBuyService.modCustomer(bo, user);
                            } catch (Exception e) {
                                logger.error("预开卡号码开户调用接口错误：phone=" + obj.getPhone() + "，原因：" + e.getMessage(), e);
                                throw new Exception("预开卡号码开户调用接口错误！" + e.getMessage());
                            }*/
                                logger.error("-----------------------------号码：" + obj.getPhone() + "预开卡号码开户接口调用完成,时间：" + System.nanoTime() + "-----------------------------");
                            }
                        }
                        // 预存金额为0
                        if (Integer.valueOf(new BigDecimal(obj.getMoney()).setScale(0).intValue()) > 0) {
                            String rechargeId = SysConfig.getValue("RechargeId");
                            String rechargePwd = SysConfig.getValue("RechargePwd");
                            TRechargeBOSSBO rechargeBO = new TRechargeBOSSBO();
                            rechargeBO.setMSISDN("86" + obj.getPhone());
                            Integer amount = Integer.valueOf(new BigDecimal(obj.getMoney()).setScale(0).intValue());
                            rechargeBO.setAmount(Long.valueOf(amount) * 100);
                            rechargeBO.setSN(obj.getPhone() + System.currentTimeMillis());// 流水号唯一，规则：手机号+当前时间戳
                            rechargeBO.setOperateDate(dateToXmlDate(new Date()));// 调用方操作时间
                            rechargeBO.setChannalId(rechargeId);// 充值Id
                            rechargeBO.setChannalPwd(MD5.GetMD5Code(rechargePwd));// 充值密码
                            if (flag != null && flag.equals("true")) {
                                logger.error("-----------------------------号码：" + obj.getPhone() + "预开卡充值开始调用接口,时间："
                                        + System.nanoTime() + "-----------------------------");
                                RestStatus rs1 = bossNewBuyService.RechargeBOSS(rechargeBO, user);
                                
                                if(!rs1.getStatus()){
                                    throw new Exception("充值调用接口错误！" + rs1.getErrorMessage());
                                }
                                logger.error("-----------------------------号码：" + obj.getPhone() + "预开卡充值接口调用完成,时间："
                                        + System.nanoTime() + "-----------------------------");
                            }
                        } else {
                            logger.error("-----------------------------号码：" + obj.getPhone() + "预开卡充值金额为：" + obj.getMoney()
                            + ",不调用充值接口，时间：" + System.nanoTime() + "-----------------------------");
                        }
                    }
                    //联通没有预开情况
                    
                    //记录维护库存数据
                    stockService.phoneActivation(n,user);
                    
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("staff", user.getLoginName());
                    map.put("channelName", fd.getChannelName());
                    map.put("channelCode", fd.getChannelCode());
                    map.put("phone", obj.getPhone());
                    map.put("money", obj.getMoney());
                    if(StringUtils.isBlank(mealNames)){
                        map.put("servtype", "无，开户套餐：" + dto.getMealName());
                    }else {
                        map.put("servtype", mealNames + "，开户套餐：" + dto.getMealName());
                    }
                    map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                    map.put("result", "号码开户成功！");
                    businessLogService.businessSaveLog(Business.phone_open, String.valueOf(user.getId()), user.getLoginName(), "",
                            "号码开户", map);
                    
                    Map<String, String> preMap = new HashMap<String, String>();
                    preMap.put("staff", user.getLoginName());
                    preMap.put("channelName", fd.getChannelName());
                    preMap.put("channelCode", fd.getChannelCode());
                    preMap.put("phone", obj.getPhone());
                    preMap.put("money", obj.getMoney());
                    if(StringUtils.isBlank(mealNames)){
                        preMap.put("servtype", "无，开户套餐：" + dto.getMealName());
                    }else {
                        preMap.put("servtype", mealNames + "，开户套餐：" + dto.getMealName());
                    }
                    preMap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                    preMap.put("result", "预开号码开户成功！");
                    businessLogService.businessSaveLog(Business.phone_pre_open, String.valueOf(user.getId()), user.getLoginName(),
                            "", "预开号码开户", preMap);
                    
                    Map<String, String> rechargeMap = new HashMap<String, String>();
                    rechargeMap.put("staff", fd.getChannelName());
                    rechargeMap.put("phone", obj.getPhone());
                    rechargeMap.put("money", obj.getMoney());
                    rechargeMap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                    rechargeMap.put("result", "预开户号码充值成功！");
                    businessLogService.businessSaveLog(Business.phone_recharge, String.valueOf(user.getId()), user.getLoginName(),
                            "", "预开户号码充值", map);
                    return new RestStatus(Boolean.TRUE, "200", "号码开户成功！");
                }
            } catch (Exception e) {
                logger.error("号码开户失败，号码" + obj.getPhone() + "增值业务" + obj.getMealCodes() + ",原因：" + e.getMessage(), e);
                throw new Exception("号码开户失败，号码" + obj.getPhone() + ",原因：" + e.getMessage());
            }
        }
    }
    
    /**
     * 开卡后审核
     * 
     * @param obj
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus phoneActivite(NumberTopUpRestDTO obj, String openSources, Channels channel) throws Exception {
        synchronized (NumberService.class) {
            if (null == channel) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，您的登录已超时，请重新登录！");
            }
            //根据当前登录渠道信息查找当前操作用户
            User user = userMapper.findUserByChannelId(channel.getId());
            if(user == null){
                return new RestStatus(Boolean.FALSE, "500", "开户失败，开户网点不存在！");
            }
            
            BigDecimal mm = new BigDecimal("100");
            if (Utils.isEmptyString(obj.getCode()) || Utils.isEmptyString(obj.getName())) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，请正确填写用户资料！");
            } else if (obj.getCode().length() != 15 && obj.getCode().length() != 18) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，请使用正确身份证！");
            }
            Date date = new Date();
            try {
                BigDecimal moneya = new BigDecimal(obj.getMoney());
                TNumber n = numberMapper.findByPhone(obj.getPhone());
                BigDecimal money = moneya.multiply(mm);
                BigDecimal orderMoney = BigDecimal.valueOf(Double.valueOf(obj.getMoney()));
                
                if (null == n) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，号码输入不正确！");
                } else if (!PhoneStatus.US02.getId().equals(n.getStatus())) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，号码已开户！");
                } else if (money.doubleValue() < 0) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，开户金额不能低于0 ！");
                } else if (DecimalUtil.sub(money.doubleValue(), n.getMoney().doubleValue()) < 0) {
                    BigDecimal reMOney = n.getMoney();
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，开户金额不能低于" + reMOney.divide(mm).toString() + "！");
                } else if (1 == DateUtil.getInstance().compareDate(new Date(), n.getValidTime(), "yyyy-MM-dd")) {
                    return new RestStatus(Boolean.FALSE, "500", "开户失败，该号码已经过期，不能进行开户！");
                } else {
                    int nu = identityMapper.findIdentityNumByCode(obj.getCode());
                    int phoneCountMax = 0;
                    try {
                        phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
                    } catch (Exception e1) {
                        phoneCountMax = 5;
                    }
                    if (nu >= phoneCountMax) {
                        return new RestStatus(Boolean.FALSE, "500", "开户失败，您已开户"+phoneCountMax+"个号码，不能再进行开户！");
                    }
                    
                    // 获取IMSI 改IMSI一定存在 而且只有一条
                    NumberIccidDTO dto = numberMapper.phoneIccidByPhoneId(n.getId());
                    Integer mealId = dto.getMealId();// 号码绑定套餐id
                    
                    // 添加默认赠送套餐编码
                    String mealNames = "";
//                    StringBuffer mealIds = new StringBuffer();
                    // 添加默认赠送套餐编码
                    if(obj.getMealCodes() != null && !obj.getMealCodes().equals("")) {
                        String[] mealsArr = obj.getMealCodes().split(",");
                        List<String> mealList = Arrays.asList(mealsArr);
                        List<Packages> packages = packagesMapper.findByCodes(mealList);
                        if(packages != null && packages.size() > 0){
                            for (Packages p : packages) {
                                mealNames += p.getName() + ",";
                                
                                if(n.getOperatorCode()==2 && p.getCode().equals(mealsArr[0])) {
                                    //联通号码开户的时候需要将number表的packageId字段添加数据,值为主套餐ID
                                    n.setPackagesId(p.getId());
                                    n.setPackagesName(p.getName());
                                    
                                    dto.setMealCode(p.getCode());
                                    dto.setMealId(p.getId());
                                }
                            }
                            
                            mealNames = mealNames.substring(0, mealNames.length() - 1);
                        }
                    }
                    

                    // 构造takeMoney入参
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("number", n);
                    param.put("channelId", channel.getId());
                    param.put("accountType", null);
                    param.put("operationType", 17);
                    param.put("money", money);
                    param.put("busMoney", n.getMoney());
                    param.put("remark", null);
                    param.put("transactionAccount", null);
                    param.put("transId", null);
                    param.put("transactionType", null);
                    param.put("calcType", null);
                    param.put("transactionFlow", null);
                    param.put("payType", null);
                    param.put("us", user);
                    // 扣款
                    RestStatus rs = takeMoney(param);
                    if (!rs.getStatus()) {
                        return rs; // 上级预备金不足
                    }
                    // 查询调用调用BOSS接口是否打开
                    String flag = SysConfig.getValue("SendToBoss");
                    //如果是联通手机号，需要调用接口
                    String custOrderId=null;
                    if (flag != null && flag.equals("true") && n.getOperatorCode()==2){
                        Packages packages = packagesMapper.findByCode(obj.getMealCodes().split(",")[0]);
                        dto.setMealId(packages.getId());//联通选择套餐ID
                        dto.setMealCode(packages.getCode());//联通选择套餐CODE
                        dto.setMealName(packages.getName());//联通选择套餐NAME
                        
                        obj.setChannelId(channel.getId()+"");
                        RestStatus rsStatus = bossUnicomService.saveBudgetOrder(obj, user);
                        if(rsStatus.getStatus()){
                            ContractRoot root = (ContractRoot)rsStatus.getResponseData();
                            custOrderId = root.getSvcCont().getCustOrderId();
                        } else {
                            throw new Exception(rsStatus.getErrorMessage());
                        }
                    }
                    
                    // 修改开户状态默认开户成功，打开接口状态为待开户确认
                    n.setStatus(PhoneStatus.US10.getId());
                    if (flag != null && flag.equals("true")) {
                        n.setStatus(PhoneStatus.US03.getId());
                    }
                    n.setCurOpenChannelId(channel.getId());
                    n.setOpenWay(obj.getOpenWay());
                    n.setSubCheckId(channel.getId());
                    n.setCheckStatus("1");
                    n.setOpenTime(date);
                    n.setOpenChannelId(channel.getId());
                    n.setOpenChannelName(channel.getChannelName());
                    numberMapper.update(n);
                    
                    //号码信息变动表
                    NumberRecord rd = new NumberRecord();
                    rd.setPhoneId(n.getId());
                    rd.setPhone(n.getPhone());
                    rd.setOptType(NmbRecordOptType.OPEN.getId());
                    rd.setOptStr("代理商："+channel.getChannelName()+"["+channel.getChannelCode()+"]开户成功");
                    rd.setCreateId(user.getId());
                    rd.setUpdateId(user.getId());
                    numberRecordMapper.insert(rd);
                    
                    // 增加开户信息
                    Identity d = new Identity();
                    d.setCode(obj.getCode());
                    d.setName(obj.getName());
                    d.setPhone(obj.getPhone());
                    d.setPhoneId(n.getId());
                    d.setStatus("1");// 预开户号码默认已报峻
                    d.setContactPhone(obj.getContactPhone());
                    d.setOpenDate(date);
                    if(obj.getMealCodes() == null || obj.getMealCodes().equals("")) {
                        d.setMeals(String.valueOf(mealId));
                    }else {
                        d.setMeals(obj.getMealCodes());
                    }
                    d.setMeals(obj.getMealCodes());
                    d.setChannelId(channel.getId());
                    d.setChannelIdLevel1(channel.getChannelIdLevel1());
                    d.setChannelIdLevel2(channel.getChannelIdLevel2());
                    d.setChannelIdLevel3(channel.getId());
                    if (!Utils.isEmptyString(obj.getMoney())) {
                        d.setMoney(new BigDecimal(Float.valueOf(obj.getMoney()) * 100));
                    }
                    d.setOpenSources(openSources);
                    d.setOrderMoney(orderMoney);
                    d.setOpenMealId(dto.getMealId());
                    d.setOpenMealCode(dto.getMealCode());
                    
                    d.setCreateId(user.getId());
                    d.setCreateTime(date);
                    d.setUpdateId(user.getId());
                    d.setUpdateTime(date);
                    
                    d.setCustOrderId(custOrderId);
                    
                    identityMapper.insert(d);
                    Integer identId = d.getId();
                    
                    //删除代理商查看号码关系表
                    bizSeeMapper.deleteByPhoneId(n.getId());
                    
                    //代理商查看号码关系表
                    BizSee bizSee = new BizSee();
                    bizSee.setChannelIdLevel1(channel.getChannelIdLevel1());
                    bizSee.setChannelIdLevel2(channel.getChannelIdLevel2());
                    bizSee.setChannelIdLevel3(channel.getId());
                    bizSee.setPhone(n.getPhone());
                    bizSee.setPhoneId(n.getId());
                    bizSee.setProCreateTime(n.getCreateTime());
                    bizSee.setCreateId(user.getId());
                    bizSee.setCreateTime(date);
                    bizSee.setUpdateId(user.getId());
                    bizSee.setUpdateTime(date);
                    
                    bizSeeMapper.insert(bizSee);
                    
                    
                    // 向审核表添加数据
                    Check check = new Check();
                    check.setSourceId(identId);
                    check.setPhoneId(n.getId());
                    check.setWayType("2");
                    check.setStatusType("1");
                    check.setChannelId(channel.getId());
                    check.setCreateId(user.getId());
                    check.setCreateTime(date);
                    check.setUpdateId(user.getId());
                    check.setUpdateTime(date);
                    
                    checkMapper.insert(check);
                    
                    // 增加申请身份证信息
                    IdcardInfo idcardInfo = new IdcardInfo();
                    idcardInfo.setName(obj.getName());
                    if(StringUtils.equals("男", obj.getSexual())){
                        idcardInfo.setSexual("1");
                    }else if(StringUtils.equals("女", obj.getSexual())){
                        idcardInfo.setSexual("0");
                    }else{
                        idcardInfo.setSexual(obj.getSexual());
                    }
                    idcardInfo.setNation(obj.getNation());
                    idcardInfo.setAddress(obj.getAddress());
                    idcardInfo.setIdNumber(obj.getCode());
                    idcardInfo.setOrgans(obj.getOrgans());
                    idcardInfo.setExpiryDate(obj.getExpiryDate());
                    try {
                        int totalCount = idcardInfoMapper.findCountByIdNumber(idcardInfo.getIdNumber());
                        if(totalCount == 0){
                            // 向身份证信息表添加数据
                            idcardInfoMapper.insert(idcardInfo);
                        }else{
                            // 向身份证信息表更新数据
                            idcardInfoMapper.update(idcardInfo);
                        }
                    } catch (Exception e) {
                        logger.error("号码"+d.getPhone()+"身份证："+idcardInfo.getIdNumber()+"信息输入错误：原因："+e.getMessage(),e);
                    }
                    
                    // pc开户上传照片和开户同时进行
                    List<AttachedDocuments> atts = obj.getAtts();
                    if (null != atts && atts.size() > 0) {
                        for (AttachedDocuments att : atts) {
                            att.setSourceId(identId);
                        }
                        insertFeAttachment(atts);
                    }
                    
                    logger.error("接口配置：" + flag + "调用接口开始");
                    if (flag != null && flag.equals("true")) {
                        if(n.getOperatorCode()==1){
                            TNewConnectionBOSSRequest connectionRequest = new TNewConnectionBOSSRequest();
                            connectionRequest.setMSISDN("86" + d.getPhone());
                            // 增加参数
                            connectionRequest.setSubsPlanCode(dto.getMealCode());// 订户套餐编码
                            connectionRequest.setCertType("1");// 证件类型编码
                            connectionRequest.setCertNbr(d.getCode());// 证件号
                            connectionRequest.setCustomerName(d.getName());// 客户名称
                            connectionRequest.setDefLang("1");// 用户语种，缺省为1
                            connectionRequest.setAccountCode(null);// 付费账户代表编码，可为空
                            connectionRequest.setIMSI(dto.getImsi());// SIMS卡号IMSI
                            connectionRequest.setICCID(dto.getSimCode());// ICCID
                            // 这个号不知道怎么取
                            // 和上面的IMSI有什么区别
                            // 身份证最后一位为字母转换为0
                            String creCode = d.getCode().toUpperCase().replaceAll("X", "0");
                            connectionRequest.setUserPwd(
                                    MD5.GetMD5Code(creCode.substring(creCode.length() - 6, creCode.length())));// 身份证后6位
                            connectionRequest.setAgentId(channel.getChannelCode());// 代理商编码
                            connectionRequest.setAgentName(channel.getChannelName());// 代理商名称
                            connectionRequest.setOrderId(String.valueOf(identId));// 订单编号
                            connectionRequest.setAmount(String.valueOf(new BigDecimal(obj.getMoney()).multiply(new BigDecimal(100)).setScale(0)));
                            connectionRequest.setReturnAmount("0");
                            
                            /*List<Packages> packges = packagesMapper.packgesByPCode(dto.getMealCode());
                            String pacStr = "";
                            if(packges != null && packges.size() > 0) {
                                for (Packages pac : packges) {
                                    pacStr = pacStr + pac.getNewCode() + ",";
                                }
                            }*/
                                // 增值业务
                                if (!Utils.isEmptyString(obj.getMealCodes())) {
                                    TServiceDto sdtos = new TServiceDto();
                                    TServiceDtoBO dbo;
                                    // 选择套餐
                                    String meal[] = obj.getMealCodes().split(",");
                                    List<String> mealList = new ArrayList<>();
                                    for (int i = 0; i < meal.length; i++) {
                                        
                                        if (Utils.isEmptyString(meal[i])) {
                                            continue;
                                        }
                                        if (!mealList.contains(meal[i])) {
                                            mealList.add(meal[i]);
                                        } else {
                                            continue;
                                        }
    //                            if(pacStr.indexOf(meal[i]+",") > 0){
    //                                connectionRequest.setSubsPlanCode(meal[i]);// 订户套餐编码
    //                            }else {
                                        dbo = new TServiceDtoBO();
                                        dbo.setServiceCode(meal[i]);
                                        sdtos.getServiceDto().add(dbo);
    //                            }
                                    }
                                    connectionRequest.setServiceDtoList(sdtos);
                                }
                                /*
                                 * if (flag != null && flag.equals("true")) { throw new
                                 * Exception("开户失败，调错误"); }
                                 */
                                logger.info("MealCodes=" + obj.getMealCodes());
                                logger.info("----------------------------- 开户开始调用接口 ,时间：" + System.nanoTime()
                                        + "-----------------------------");
                                try {
                                    RestStatus r = bossNewBuyService.NewConnectionBOSS(connectionRequest, user); 
                                    if(!r.getStatus()){
                                        logger.error("开户调用接口错误：phone=" + obj.getPhone() + "，原因：" + r.getErrorMessage());
                                        throw new Exception("号码" + obj.getPhone() +"开户调用接口错误！" + r.getErrorMessage());
                                    }
                                } catch (Exception e) {
                                    logger.error("开户调用接口错误：phone=" + obj.getPhone() + "，原因：" + e.getMessage(), e);
                                    throw new Exception("号码=" + obj.getPhone() +"开户调用接口错误！" + e.getMessage());
                                }
                                logger.error("-----------------------------开户接口调用完成,时间：" + System.nanoTime() + "-----------------------------");
                            } else if(n.getOperatorCode()==2){
                                try {
                                    RestStatus rsStatus = bossUnicomService.doCompleteOrder(custOrderId, user);
                                    if(!rsStatus.getStatus()){
                                        logger.error("开户调用接口错误：phone=" + d.getPhone() + "，原因："+rsStatus.getErrorMessage());
                                        throw new Exception(rsStatus.getErrorMessage());
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    throw new Exception("开户调用接口错误！" + e.getMessage());
                                }
                            }
                        }
                    //记录维护库存数据
                    stockService.phoneActivation(n,user);
                    
                    Map<String, Object> params = new HashMap<>();
                    params.put("mainPacId", d.getOpenMealId());
                    params.put("pacIds", d.getMeals().replace(d.getOpenMealCode()+",", ""));
                    List<Packages> list = packagesMapper.listOpenPac(params);
                    for(Packages p : list) {//办理业务的记录
                        Biz b = new Biz();
                        b.setPhone(d.getPhone());
                        b.setBizType(CommonUtil.servTypeMapBiz.get(p.getServType()));
                        b.setBizName(BizType.getName(b.getBizType()));
                        b.setServName(BizType.getName(b.getBizType()));
                        b.setIp("");
                        b.setRemark("");
                        b.setReason("");
                        b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
                        b.setValidType("1");
                        b.setMoney(new BigDecimal(0));
                        b.setFeeStyle("0");
                        b.setOperationType("2");
                        b.setStatus(StatusType.SUCCESS.getCode());
                        b.setOperationTime(new Date());
                        b.setWayType("PC");
                        b.setCreateTime(new Date());
                        b.setUpdateTime(new Date());
                        bizMapper.insert(b);
                    }
                    //开户记录
                    Biz b = new Biz();
                    b.setPhone(d.getPhone());
                    b.setBizType(BizType.OPEN_ACCOUNT.getCode());
                    b.setBizName(BizType.OPEN_ACCOUNT.getName());
                    b.setIp("");
                    b.setRemark("");
                    b.setReason("");
                    b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
                    b.setValidType("1");
                    b.setMoney(new BigDecimal(0));
                    b.setFeeStyle("0");
                    b.setOperationType("2");
                    b.setStatus(StatusType.SUCCESS.getCode());
                    b.setOperationTime(new Date());
                    b.setWayType("PC");
                    b.setCreateTime(new Date());
                    b.setUpdateTime(new Date());
                    bizMapper.insert(b);
                    
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("staff", user.getLoginName());
                    map.put("channelName", channel.getChannelName());
                    map.put("channelCode", channel.getChannelCode());
                    map.put("phone", obj.getPhone());
                    map.put("money", obj.getMoney());
                    if(StringUtils.isBlank(mealNames)){
                        map.put("servtype", "无，开户套餐：" + dto.getMealName());
                    }else {
                        map.put("servtype", mealNames + "，开户套餐：" + dto.getMealName());
                    }
                    map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                    map.put("result", "成功！");
                    businessLogService.businessSaveLog(Business.phone_open, String.valueOf(user.getId()), user.getLoginName(), "",
                            "号码开户", map);
                    return new RestStatus(Boolean.TRUE, "200", "号码开户成功！");
                }
            } catch (Exception e) {
                logger.error("号码开户失败，号码" + obj.getPhone() + "增值业务" + obj.getMealCodes() + ",原因：" + e.getMessage(), e);
                throw new Exception("号码开户失败，号码" + obj.getPhone() + ",原因：" + e.getMessage());
            }
        }
    }
    
    /**审核操作(开卡前审核)*/
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateCardVfnList(ApplyIdentity applyIdentitys, Integer phoneId, String pass, String opinion, User us) throws Exception {
        synchronized (NumberService.class) {
            //ApplyIdentity applyIdentitys = applyIdentityMapper.select(sourceId);
            if(applyIdentitys == null) {
                numberMapper.udpateNumCheckStatus(null, phoneId);
                return new RestStatus(Boolean.FALSE, "500", "开户审核失败！号码已取消开户！");
            }
            
            if(applyIdentityService.hasCheck(phoneId)){
                return new RestStatus(Boolean.FALSE, "200", "审核失败，该号码已审核！");
            }
            
            int statusType = 3;
            String newStr = "审核不通过，原因："+opinion;
            if ("1".equals(pass)) {// true时通过,false不通过
                String idno = applyIdentitys.getCode();
                String name=applyIdentitys.getName();
                // 身份证查证
                if(!idcheck(idno, name, us)){
                    //后台自动处理为审核不通过
                    opinion = "身份证信息不一致或不合法";
                    newStr = "审核不通过，原因："+opinion;
                    statusType = 3;
                    pass = "0";
                } else {
                    statusType = 2;
                    newStr = "审核通过";
                }
            }
            
            TNumber n = numberMapper.select(phoneId);
            
            // 审核表添加数据
            Check check = new Check();
            check.setSourceId(applyIdentitys.getId());
            check.setPhoneId(phoneId);
            check.setWayType("2");
            check.setStatusType(String.valueOf(statusType));
            if (statusType == 2) {// true时通过,有通过时间
                check.setPassDate(new Date());
            } else {// 不通过,通过时间为空
                
            }
            check.setCheckOpinion(opinion);
            check.setChannelId(n.getCurOpenChannelId());
            check.setCreateId(us.getId());
            check.setCreateTime(new Date());
            check.setUpdateId(us.getId());
            check.setUpdateTime(new Date());
            
            /*ApplyIdentity applyIdentitys = applyIdentityMapper.select(sourceId);
            if(applyIdentitys == null) {
                numberMapper.udpateNumCheckStatus(null, phoneId);
                return new RestStatus(Boolean.FALSE, "500", "开户审核失败！号码已取消开户！");
            }*/
            Packages packages = packagesMapper.findById(applyIdentitys.getOpenMealId());
            
            checkMapper.insert(check);
            
            if (pass.equals("1")) {
                Boolean isPreSub = findSubsByPhone(n.getPhone());
                //修改状态，记录审核信息
                applyIdentitys.setCheckStatus(Check.audit_yes);
                applyIdentitys.setUpdateId(us.getId());
                applyIdentitys.setUpdateTime(new Date());
                applyIdentityMapper.update(applyIdentitys);
                
                RestStatus rs;
                if (isPreSub) {
                    // 预开户号码
                    rs = preInsertIdentity(phoneId, opinion, us, applyIdentitys);
                    if (!rs.getStatus()) {
                        throw new Exception(rs.getErrorMessage());
                    }
                } else {
                    rs = insertIdentity(phoneId, opinion, us, applyIdentitys);
                    if (!rs.getStatus()) {
                        throw new Exception(rs.getErrorMessage());
                    }
                }
                //号码信息变动表
                Channels channels = channelsMapper.findById(applyIdentitys.getChannelId());
                NumberRecord r = new NumberRecord();
                r.setPhoneId(n.getId());
                r.setPhone(n.getPhone());
                r.setOptType(NmbRecordOptType.OPEN.getId());
                r.setOptStr("代理商："+channels.getChannelName()+"["+channels.getChannelCode()+"]开户成功");
                r.setCreateId(us.getId());
                r.setUpdateId(us.getId());
                numberRecordMapper.insert(r);
                
                try {
                    NewsInfo newsInfo = new NewsInfo();
                    newsInfo.setNewsType("1");
                    newsInfo.setTitle("开户审核");
                    newsInfo.setContent("号码："+n.getPhone()+" 开户"+newStr);
                    newsInfo.setCreateTime(new Date());
                    newsInfo.setIsRead("0");
                    newsInfo.setTargetId(applyIdentitys.getCreateId());
                    newsInfoMapper.insert(newsInfo);
                    
                    MsgPush m = new MsgPush();
                    m.setNoticeId(newsInfo.getId());
                    m.setNoticeType("t_news_info");
                    m.setTitle(newsInfo.getTitle());
                    m.setContent(newsInfo.getContent());
                    m.setUserId(applyIdentitys.getCreateId());
                    m.setStatus("0");
                    msgPushMapper.insert(m);
                } catch (Exception e) {
                    logger.error(n.getPhone()+"开户，记录消息出错，原因："+e.getMessage(),e);
                    e.printStackTrace();
                }
                
                String idcardInfoJson = applyIdentitys.getIdcardinfo();
                // 增加身份证信息
                IdcardInfo idcardInfo = JSONUtil.jsonToObject(idcardInfoJson, IdcardInfo.class);
                try {
                    int totalCount = idcardInfoMapper.findCountByIdNumber(applyIdentitys.getCode());
                    if(totalCount == 0){
                        // 向身份证信息表添加数据
                        idcardInfoMapper.insert(idcardInfo);
                    }else{
                        // 向身份证信息表更新数据
                        idcardInfoMapper.update(idcardInfo);
                    }
                } catch (Exception e) {
                    logger.error("号码"+n.getPhone()+"信息错误：原因："+e.getMessage(),e);
                }
                
                try {
                    Map<String, Object> params = new HashMap<>();
                    params.put("mainPacId", applyIdentitys.getOpenMealId());
                    //选择的套餐，需要去除主套餐编码
                    String meals[] = applyIdentitys.getOpenMeals().replace(applyIdentitys.getOpenMealCode()+",", "").split(",");
                    for(String m : meals) {
                        if(StringUtils.isNotEmpty(m)) {
                            params.put("pacIds", m);
                            List<Packages> list = packagesMapper.listOpenPac(params);
                            for(Packages p : list) {//办理业务的记录
                                Biz b = new Biz();
                                b.setPhone(applyIdentitys.getPhone());
                                b.setBizType(CommonUtil.servTypeMapBiz.get(p.getServType()));
                                b.setBizName(BizType.getName(b.getBizType()));
                                b.setServName(p.getPackageNotes());
                                b.setIp("");
                                b.setRemark("");
                                b.setReason("");
                                b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
                                b.setValidType("1");
                                b.setMoney(new BigDecimal(0));
                                b.setFeeStyle("0");
                                b.setOperationType("2");
                                b.setStatus(StatusType.SUCCESS.getCode());
                                b.setOperationTime(new Date());
                                b.setWayType("PC");
                                b.setCreateTime(new Date());
                                b.setUpdateTime(new Date());
                                bizMapper.insert(b);
                            }
                        }
                    }
                    
                    //开户记录
                    Biz b = new Biz();
                    b.setPhone(applyIdentitys.getPhone());
                    b.setBizType(BizType.OPEN_ACCOUNT.getCode());
                    b.setBizName(BizType.OPEN_ACCOUNT.getName());
                    b.setServName(BizType.OPEN_ACCOUNT.getName());
                    b.setIp("");
                    b.setRemark("");
                    b.setReason("");
                    b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
                    b.setValidType("1");
                    b.setMoney(new BigDecimal(0));
                    b.setFeeStyle("0");
                    b.setOperationType("2");
                    b.setStatus(StatusType.SUCCESS.getCode());
                    b.setOperationTime(new Date());
                    b.setWayType("PC");
                    b.setCreateTime(new Date());
                    b.setUpdateTime(new Date());
                    bizMapper.insert(b);
                } catch (Exception e) {
                    logger.error("记录biz记录出现异常！"+e.getMessage());
                }
                
                return rs;
            } else {
                int checkNoNum = 0;
                try {
                    checkNoNum = Integer.parseInt(DicUtil.getMapDictionary("CHECK_NO_NUM").get("CHECK_NO_NUMBER"));
                } catch (Exception e1) {
                    checkNoNum = 5;
                }
                n.setCheckNoNum(n.getCheckNoNum() + 1);
                
                // 从开卡申请表中获取业务金额
                ApplyIdentity applyIdentity = applyIdentityMapper.findByPhoneId(n.getId());
                BigDecimal money = new BigDecimal(0);
                if (null != applyIdentity) {
                    money = applyIdentity.getMoney().divide(new BigDecimal(100));
                } else {
                    money = n.getMoney().divide(new BigDecimal(100));
                }
                
                if (n.getCheckNoNum().intValue() >= checkNoNum) {
                    applyIdentityMapper.deleteByPhone(n.getPhone());
                    
                    n.setCheckNoNum(0);
                    n.setCheckStatus(null);
                    n.setOpenChannelId(null);
                    n.setOpenChannelName(null);
                    n.setOpenTime(null);
                    n.setSubCheckId(null);
                    numberMapper.update(n);
                    
                    //删除代理商查看号码关系表
                    bizSeeMapper.deleteByPhoneId(n.getId());

                    // 构造takeMoney入参
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("number", n);
                    param.put("channelId", null);
                    param.put("accountType", null);
                    param.put("operationType", 19);
                    param.put("money", money);
                    param.put("busMoney", money);
                    param.put("remark", null);
                    param.put("transactionAccount", null);
                    param.put("transId", null);
                    param.put("transactionType", null);
                    param.put("calcType", null);
                    param.put("transactionFlow", null);
                    param.put("payType", null);
                    param.put("us", us);
                    //开户前审核，审核不通过，冻结金额回退给一级代理和网点
                    RestStatus rs = takeMoney(param);
                    if (!rs.getStatus()) {
                        throw new Exception(rs.getErrorMessage());
                        //return rs; // 上级预备金不足
                    }
                    
                    return new RestStatus(Boolean.TRUE, "200", "申请号码开户审核成功！");
                }
                
                n.setCheckStatus(Check.audit_no);
                numberMapper.update(n);
                // 记录消息，修改状态，记录审核信息
                //修改状态，记录审核信息
                applyIdentitys.setCheckStatus(Check.audit_no);
                applyIdentitys.setUpdateId(us.getId());
                applyIdentitys.setUpdateTime(new Date());
                applyIdentityMapper.update(applyIdentitys);

                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", n);
                param.put("channelId", null);
                param.put("accountType", null);
                param.put("operationType", 19);
                param.put("money", money);
                param.put("busMoney", money);
                param.put("remark", null);
                param.put("transactionAccount", null);
                param.put("transId", null);
                param.put("transactionType", null);
                param.put("calcType", null);
                param.put("transactionFlow", null);
                param.put("payType", null);
                param.put("us", us);
                //开户前审核，审核不通过，冻结金额回退给一级代理和网点
                RestStatus rs = takeMoney(param);
                if (!rs.getStatus()) {
                    throw new Exception(rs.getErrorMessage());
                    //return rs; // 上级预备金不足
                }
                
                // 查询调用调用BOSS接口是否打开
                String flag = SysConfig.getValue("SendToBoss");
                logger.error("接口配置：" + flag + "调用接口开始");
                if (flag != null && flag.equals("true") && n.getOperatorCode()==2){// 联通号接口调用
                    try {
                        RestStatus rsStatus = bossUnicomService.doDeleteOrder(applyIdentitys.getCustOrderId(), us);
                        if(!rsStatus.getStatus()){
                            logger.error("号码审核调用取消接口错误：phone=" + n.getPhone() + "，原因："+rsStatus.getErrorMessage());
                            throw new Exception(rsStatus.getErrorMessage());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new Exception("号码审核调用取消接口错误！" + e.getMessage());
                    }
                }
                
                //短信通知网点号码审核不通过
                /*Channels channels=channelsMapper.findById(applyIdentitys.getChannelId());
            String text = "您好，您在酷商办理的"+applyIdentitys.getPhone()+"号码开户，审核未通过，请您及时登录酷商查看，谢谢配合！";
            String smsUrl = SysConfigApp.getValue("smsUrl");
            String smsSendUser = SysConfigApp.getValue("smsSendUser");
            String smsSendPwd = SysConfigApp.getValue("smsSendPwd");
            String dtime = String.valueOf(System.currentTimeMillis());
            String pwdString = "key="+MD5App.GetMD5Code(smsSendPwd).toLowerCase()+"&timestamp="+dtime;
            smsUrl = smsUrl+"?user_name="+smsSendUser+"&sub_user=&password="+MD5App.GetMD5Code(pwdString)+
                    "&timestamp="+dtime+"&mobile="+channels.getBussContactPhone()+"&content="+text;
            String respon = servletReqService.GetResponseData(smsUrl,"");
            SmsResponseDTO resDTO = JsonMapper.nonEmptyMapper().fromJson(respon, SmsResponseDTO.class);
            if(Utils.isEmptyStr(respon)){
                throw new SmsException("调用发送短信接口错误：phone="+channels.getBussContactPhone()+"，接口返回"+respon);
            }else if(!"0".equals(resDTO.getCode())){
                throw new SmsException("调用发送短信接口错误：phone="+channels.getBussContactPhone()+"，接口返回"+respon);
            }*/
                
                try {
                    NewsInfo newsInfo = new NewsInfo();
                    newsInfo.setNewsType("1");
                    newsInfo.setTitle("开户审核");
                    newsInfo.setContent("号码："+n.getPhone()+" 开户"+newStr);
                    newsInfo.setCreateTime(new Date());
                    newsInfo.setIsRead("0");
                    newsInfo.setTargetId(applyIdentitys.getCreateId());
                    newsInfoMapper.insert(newsInfo);
                    
                    MsgPush m = new MsgPush();
                    m.setNoticeId(newsInfo.getId());
                    m.setNoticeType("t_news_info");
                    m.setTitle(newsInfo.getTitle());
                    m.setContent(newsInfo.getContent());
                    m.setUserId(applyIdentitys.getCreateId());
                    m.setStatus("0");
                    msgPushMapper.insert(m);
                } catch (Exception e) {
                    logger.error(n.getPhone()+"开户，记录消息出错，原因："+e.getMessage(),e);
                    e.printStackTrace();
                }
                
                Map<String, String> bmap = new HashMap<String,String>();
                bmap.put("staff", us.getLoginName());
                bmap.put("phone", n.getPhone());
                bmap.put("whether", "审核不通过");
                bmap.put("opinion", opinion);
                bmap.put("money", String.valueOf(applyIdentitys.getMoney().divide(new BigDecimal(100)).setScale(2)));
                if(StringUtils.isBlank(applyIdentitys.getMealNames())){
                    bmap.put("servtype", "无，开户套餐：" + packages.getName());
                }else {
                    bmap.put("servtype", applyIdentitys.getMealNames() + "，开户套餐：" + packages.getName());
                }
                bmap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                bmap.put("result", "号码审核操作完成！结果为：</p>"+ n.getPhone() +"审核不通过");
                businessLogService.businessSaveLog(Business.phone_check, String.valueOf(us.getId()), us.getLoginName(), "", "号码审核", bmap);
                
                return new RestStatus(Boolean.TRUE, "200", "申请号码开户审核成功！");
            }
        }
    }
    
    private boolean idcheck(String idno, String name, User user) throws Exception{
        /*String channelDic = DicUtil.getMapDictionary("SYS_CONFIG").get("IDCHECK_CHANNELS");
        if(channelDic == null || !channelDic.contains((";"+channelId+";"))){
            return true;
        }*/
        
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("needCharging", "1");//表示不计费
        jsonObject.put("userId", idno);
        jsonObject.put("userName", name);
        String requestJson = jsonObject.toString();
        
        String result = IDCheckService.idCheck(requestJson, user);
        
        logger.info(result);
        JSONObject json = new JSONObject(result);
        String resultMK = json.getString("result");
        
        return "0".equals(resultMK);//只有0表示一致
    }
    /**审核操作，事务管理*/
    public Map<String,Object> checkTran(String phone, String pass, String opinion, IdcardInfo idcardinfo, User user) throws Exception {
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        boolean hasSuccFlag = false;
        String idNumber = null;
        try{
            if(StringUtils.isBlank(phone)){
                returnStr.append("需要进行审核的号码为空！");
                map.put("status",false);
                map.put("errorMsg",returnStr) ;
                return map;
            }else{
                String operate;
                if("1".equals(pass)){// true时通过,false不通过
                    RestStatus isPool = PhoneOpenUtil.isPool();//当前时间是否为出账时间，是否可以办理业务，不能办理业务走审核流程
                    RestStatus isExce = PhoneOpenUtil.isExcpetion();//当前时间是否为系统异常时间，是否可以办理业务，不能办理业务走审核流程
                    if(!isPool.getStatus()){
                        map.put("status",false);
                        map.put("errorMsg",isPool.getErrorMessage()+",无法进行审核操作！") ;
                        return map;
                    }else if(!isExce.getStatus()){
                        map.put("status",false);
                        map.put("errorMsg",isExce.getErrorMessage()+",无法进行审核操作！") ;
                        return map;
                    }
                    operate="开户";
                }else{
                    operate="审核不通过";
                }
                
                TNumber number = findByPhone(phone);
                
                Integer phoneId = number.getId();
                List<ApplyIdentity> applyIdentities = applyIdentityService.applyIdentityByPhoneId(number.getId());
                ApplyIdentity app = new ApplyIdentity();
                if(applyIdentities != null && applyIdentities.size() > 0){
                    app = applyIdentities.get(0);
                    
                    // 审核通过时将审核时修改的身份信息更新到数据库中
                    if("1".equals(pass) && idcardinfo!=null && !StringUtils.isBlank(idcardinfo.getIdNumber())&&!StringUtils.isBlank(idcardinfo.getName())) {
                        if("NaN".equals(idcardinfo.getSexual())) {
                            idcardinfo.setSexual("0");
                        }
                        idNumber = idcardinfo.getIdNumber();
                        //更新数据库中对应字段
                        app.setIdcardinfo(JSONUtil.objectToJson(idcardinfo));
                        app.setCode(idNumber);
                        app.setName(idcardinfo.getName());
                    }
                }
                /**
                 * synchronized (obj) {
                 * 1.查询号码的审核状态
                 * 2.判断是否为“审核中”
                 * 3.1 如果非“审核中”状态，则修改状态
                 * 3.2如果是“审核中”状态，则直接返回错误信息
                 */
                 synchronized (this) {
                     // 1.查询号码的审核状态
                     TNumber f = findById(phoneId);
                     // 2.判断是否为“审核中”
                     // 3.1如果是“审核中”、“已审核”状态，则直接返回错误信息
                     if(StringUtils.equals(f.getCheckStatus(), "6")){
    //                           logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                         returnStr.append("号码审核失败，该手机号("+f.getPhone()+")正在审核中！");
                         map.put("status",false);
                         map.put("errorMsg",returnStr) ;
                         return map;
                     }if(StringUtils.equals(f.getCheckStatus(), "2") || StringUtils.equals(f.getCheckStatus(), "3")){
    //                           logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                         returnStr.append("号码审核失败，该手机号("+f.getPhone()+")已审核！");
                         map.put("status",false);
                         map.put("errorMsg",returnStr) ;
                         return map;
                     }else{
                         // 3.2 如果非“审核中”状态，则修改状态
                         udpateNumCheckStatus("6", phoneId);
                     }
                 }
                 RestStatus restStatus;
                 if(StringUtils.equals(number.getStatus(), TNumber.STATUS_WAIT_FINISH) || StringUtils.equals(number.getStatus(), TNumber.STATUS_FINISH_ACTIVATE)) {
                     List<Identity> identities = identityService.findIdentityByPhoneId(number.getId());
                     if(identities == null || identities.size() <= 0){
                         returnStr.append("号码审核失败，该手机号("+number.getPhone()+")开户信息错误！");
                         throw new Exception(returnStr.toString());
                     }
                     //开卡后审核（只改变号码审核状态）
                     restStatus = updateCardVfn(identities.get(0).getId(), phoneId,pass, opinion, user);
                 }else {
                     restStatus = updateCardVfnList(app, phoneId, pass, opinion, user);
                 }
                
                 if(!restStatus.getStatus()){
                     if(restStatus.getErrorMessage()!=null){
                         if("1".equals(pass)){// true时通过,false不通过
                             returnStr.append(app.getPhone()).append("开户失败！原因："+restStatus.getErrorMessage()+"</p>");
                         }else{
                             returnStr.append(app.getPhone()).append(restStatus.getErrorMessage()+"</p>");
                         }
                     }else{
                         returnStr.append(app.getPhone()).append(operate).append("失败！</p>");
                     }
                     map.put("status",false);
                 }else{
                     if("1".equals(pass)){//true时通过,false不通过
                         returnStr.append(app.getPhone()).append("开户成功！</p>");
                     }else{
                         returnStr.append(app.getPhone()).append("审核成功，审核结果为不通过！</p>");
    
                     }
                     map.put("status",true);
                     hasSuccFlag  = true;
                 }
                map.put("hasSuccFlag", hasSuccFlag);
                map.put("errorMsg",returnStr) ;
                return map;
            }
        }catch (Exception e){
            logger.error("号码开户失败，原因："+e.getMessage(),e);
            returnStr.append(phone).append("开户失败！ </p>" + e.getMessage());
            map.put("status",false);
            map.put("errorMsg",returnStr) ;
            throw new Exception(returnStr.toString());
        }
    }
    
    /**审核批操作，事务管理*/
    public Map<String, Object> checkBatchTran(String phones, User user){
        Map<String,Object> map = new HashMap<String,Object>();
        StringBuffer returnStr = new StringBuffer();
        StringBuffer returnStrSuccess = new StringBuffer();
        StringBuffer returnStrFailse = new StringBuffer();
        int m = 1, n = 1;   //m表示号码审核成功时数字标记，n 表示号码审核失败时数字标记
        String pass = "1";
        String opinion = "";
        try{
            if(StringUtils.isBlank(phones)){
                returnStr.append("需要进行审核的号码为空！");
                map.put("status",false);
                map.put("errorMsg",returnStr) ;
                return map;
            }else{
                String operate;
                if("1".equals(pass)){// true时通过,false不通过
                    RestStatus isPool = PhoneOpenUtil.isPool();//当前时间是否为出账时间，是否可以办理业务，不能办理业务走审核流程
                    RestStatus isExce = PhoneOpenUtil.isExcpetion();//当前时间是否为系统异常时间，是否可以办理业务，不能办理业务走审核流程
                    if(!isPool.getStatus()){
                        map.put("status",false);
                        map.put("errorMsg",isPool.getErrorMessage()+",无法进行审核操作！") ;
                        return map;
                    }else if(!isExce.getStatus()){
                        map.put("status",false);
                        map.put("errorMsg",isExce.getErrorMessage()+",无法进行审核操作！") ;
                        return map;
                    }
                    operate="开户";
                }else{
                    operate="审核不通过";
                }
                
                String[] phoneArr = phones.split(",");
                for (int i = 0; i < phoneArr.length; i++) {
                    TNumber number = findByPhone(phoneArr[i]);
                    
                    Integer phoneId = number.getId();
                    List<ApplyIdentity> applyIdentities = applyIdentityService.applyIdentityByPhoneId(number.getId());
                    ApplyIdentity app = new ApplyIdentity();
                    NumberTopUpRestDTO obj = new NumberTopUpRestDTO();
                    if(applyIdentities != null && applyIdentities.size() > 0){
                        app = applyIdentities.get(0);
                        
                        obj.setMealCodes(app.getOpenMealCode());
                        obj.setPhone(app.getPhone());
                        obj.setCode(app.getCode());
                        obj.setName(app.getName());
                        obj.setMoney(String.valueOf(app.getMoney()));
                        obj.setContactPhone(app.getContactPhone());
                    }
                
                
                    /**
                     * synchronized (obj) {
                     * 1.查询号码的审核状态
                     * 2.判断是否为“审核中”
                     * 3.1 如果非“审核中”状态，则修改状态
                     * 3.2如果是“审核中”状态，则直接返回错误信息
                     */
                    synchronized (this) {
                        // 1.查询号码的审核状态
                        TNumber f = findById(phoneId);
                        // 2.判断是否为“审核中”
                        // 3.1如果是“审核中”、“已审核”状态，则直接返回错误信息
                        if(StringUtils.isBlank(f.getCheckStatus())){
//                          logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                            returnStrFailse.append(n + "、 号码("+f.getPhone()+")审核失败，该手机号已取消开户！<br>");
                            n++;
                            continue;
                        }else if(StringUtils.equals(f.getCheckStatus(), "6")){
//                               logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                            returnStrFailse.append(n + "、 号码("+f.getPhone()+")审核失败，该手机号正在审核中！<br>");
                            n++;
                            continue;
                        }else if(StringUtils.equals(f.getCheckStatus(), "2") || StringUtils.equals(f.getCheckStatus(), "3")){
//                               logger.error("号码审核失败，原因：该开户手机号("+phoneId+")正在审核中");
                            returnStrFailse.append(n + "、 号码("+f.getPhone()+")审核失败，该手机号已审核！<br>");
                            n++;
                            continue;
                        }else{
                            // 3.2 如果非“审核中”状态，则修改状态
                            udpateNumCheckStatus("6", phoneId);
                        }
                    }
                    
                    RestStatus restStatus;
                    if(StringUtils.equals(number.getStatus(), TNumber.STATUS_WAIT_FINISH) || StringUtils.equals(number.getStatus(), TNumber.STATUS_FINISH_ACTIVATE)) {
                        
                        List<Identity> identities = identityService.findIdentityByPhoneId(number.getId());
                        if(identities == null || identities.size() <= 0){
                            returnStrFailse.append(n + "、 号码("+number.getPhone()+")审核失败，该手机号开户信息错误！<br>");
                            n++;
                            continue;
                        }
                        //开卡后审核（只改变号码审核状态）
                        restStatus = updateCardVfn(identities.get(0).getId(), phoneId,pass, opinion, user);
                    }else {
                        restStatus = updateCardVfnList(app, phoneId,pass, opinion, user);
                    }
                    
                    if(!restStatus.getStatus()){
                        if(restStatus.getErrorMessage()!=null){
                            if("1".equals(pass)){// true时通过,false不通过
                                returnStrFailse.append(n + "、 " + app.getPhone()).append("开户失败！原因："+restStatus.getErrorMessage()+"</br>");
                            }else{
                                returnStrFailse.append(n + "、 " + app.getPhone()).append(restStatus.getErrorMessage()+"</br>");
                            }
                        }else{
                            returnStrFailse.append(n + "、 " + app.getPhone()).append(operate).append("失败！</br>");
                        }
                        n++;
                    }else{
                        if("1".equals(pass)){//true时通过,false不通过
                            returnStrSuccess.append(m + "、 " + number.getPhone()).append("开户成功！</p>");
                            m++;
                        }else{
                            returnStr.append(m + "、 " + number.getPhone()).append("审核成功，审核结果为不通过！</p>");
                            m++;
                        }
                    }
                }
            }
        }catch (Exception e){
            logger.error("号码开户失败，原因："+e.getMessage(),e);
            returnStrFailse.append("号码开户失败，原因：" + e.getMessage()+"</br>");
            n++;
        }
            
        if(m > 1 && n > 1){
            returnStr = returnStr.append("审核成功号码：<br>").append(returnStrSuccess).append("<br>审核失败号码：<br>").append(returnStrFailse);
        }else if(m > 1 && n == 1){
            returnStr = returnStr.append("号码批量审核成功！");
        }else {
            returnStr = returnStr.append("号码批量审核失败：<br>").append(returnStrFailse);
        }
        
        map.put("status",true);
        map.put("hasSuccFlag", true);
        map.put("errorMsg",returnStr);
        return map;
    }
    
    // 审核操作(开卡后审核)
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateCardVfn(Integer sourceId, Integer phoneId, String pass, String opinion, User us) throws Exception {
        if(identityService.hasIdentityCheck(phoneId)){
            return new RestStatus(Boolean.FALSE, "200", "审核失败，该号码已审核！");
        }
        int statusType = 3;
        if ("1".equals(pass)) {// true时通过,false不通过
            statusType = 2;
        }
        // 审核表添加数据
        Check check = new Check();
        check.setSourceId(sourceId);
        check.setPhoneId(phoneId);
        check.setWayType("2");
        check.setStatusType(String.valueOf(statusType));
        if (statusType == 2) {// true时通过,有通过时间
            check.setPassDate(new Date());
        } else {// 不通过,通过时间为空
           
        }
        check.setCheckOpinion(opinion);
        check.setCreateId(us.getId());
        check.setCreateTime(new Date());
        check.setUpdateId(us.getId());
        check.setUpdateTime(new Date());
        
        Identity identity = identityMapper.select(sourceId);
        String mealNames = "";
        if(StringUtils.isNotBlank(identity.getMeals())) {
            String[] mealArr = identity.getMeals().split(",");
            List<String> codes = Arrays.asList(mealArr);
            List<Packages> packages = packagesMapper.findByCodes(codes);
            if(packages != null && packages.size() > 0) {
                for (Packages p : packages) {
                    mealNames += p.getName() + ",";
                }
                mealNames = mealNames.substring(0, mealNames.length() - 1);
            }

        }
        Packages packages = packagesMapper.findById(identity.getOpenMealId());
        
        TNumber n = numberMapper.select(phoneId);

        if (pass.equals("1")) {
            identity.setAduitStatus(Check.audit_yes);
            n.setCheckStatus(Check.audit_yes);
        } else {
            identity.setAduitStatus(Check.audit_no);
            n.setCheckStatus(Check.audit_no);
        }
        check.setChannelId(n.getCurOpenChannelId());
        //修改状态，记录审核信息
        checkMapper.insert(check);
        identity.setUpdateId(us.getId());
        identity.setUpdateTime(new Date());
        identityMapper.update(identity);
        numberMapper.update(n);
        
        String whether="审核不通过";
        String newStr = "审核不通过，原因："+opinion;
        if("1".equals(pass)){
            whether="审核通过";
            newStr = "审核通过";
        }
        
        try {
            NewsInfo newsInfo = new NewsInfo();
            newsInfo.setNewsType("1");
            newsInfo.setTitle("开户审核");
            newsInfo.setContent("号码："+n.getPhone()+" 开户"+newStr);
            newsInfo.setCreateTime(new Date());
            newsInfo.setIsRead("0");
            newsInfo.setTargetId(identity.getCreateId());
            newsInfoMapper.insert(newsInfo);
            
            MsgPush m = new MsgPush();
            m.setNoticeId(newsInfo.getId());
            m.setNoticeType("t_news_info");
            m.setTitle(newsInfo.getTitle());
            m.setContent(newsInfo.getContent());
            m.setUserId(identity.getCreateId());
            m.setStatus("0");
            msgPushMapper.insert(m);
        } catch (Exception e) {
            logger.error(n.getPhone()+"开户，记录消息出错，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        
        Map<String, String> bmap = new HashMap<String,String>();
        bmap.put("staff", us.getLoginName());
        bmap.put("phone", n.getPhone());
        bmap.put("whether", whether);
        bmap.put("opinion", opinion);
        bmap.put("money", String.valueOf(identity.getMoney().divide(new BigDecimal(100)).setScale(2)));
        if(StringUtils.isBlank(mealNames)) {
            bmap.put("servtype", "无，开户套餐：" + packages.getName());
        }else {
            bmap.put("servtype", mealNames + "，开户套餐：" + packages.getName());
        }
        bmap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
        bmap.put("result", "号码审核操作完成！结果为：</p>" + n.getPhone() + whether);
        businessLogService.businessSaveLog(Business.phone_check, String.valueOf(us.getId()), us.getLoginName(), "", "号码审核", bmap);

        return new RestStatus(Boolean.TRUE, "200", "申请号码开户审核成功！");
    }
    
    /**
     * 稽核操作，修改流水表和开户表
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateCardAuditList(Integer id, String pass, String opinion, Integer sourseId, User us) throws Exception {
        RestStatus restStatus = null;
        getLock(Long.valueOf(id)).lock();
            try {
                TNumber n = numberMapper.select(id);
                Channels channels = channelsService.findChannelByUserId(us.getId());
                if(channels != null || us.getChannelId() != null){
                    restStatus = new RestStatus(Boolean.FALSE, "500", "稽核失败，渠道客户不能稽核操作！");
                    return restStatus;
                }
                if(exitAduit(id)){
                    restStatus = new RestStatus(Boolean.FALSE, "500", "稽核失败，该号码已被稽核！");
                    return restStatus;
                }
                
                // 向审核表添加数据
                Check check = new Check();
                check.setSourceId(sourseId);
                check.setPhoneId(n.getId());
                check.setWayType("2");
                check.setStatusType("4");
                check.setCheckOpinion(opinion);
                check.setChannelId(n.getCurOpenChannelId());
                check.setCreateId(us.getId());
                check.setCreateTime(new Date());
                check.setUpdateId(us.getId());
                check.setUpdateTime(new Date());
                
                n.setCheckStatus("4");
                n.setUpdateId(us.getId());
                n.setUpdateTime(new Date());

                // 稽核并不通过停机
                NumberStopRecord record = new NumberStopRecord();
                record.setPhoneId(n.getId());
                record.setStatusType("1");
                record.setOpinion("停机");
                record.setCreateId(us.getId());
                record.setCreateTime(new Date());
                record.setUpdateId(us.getId());
                record.setUpdateTime(new Date());

                String flag = SysConfig.getValue("SendToBoss");// 查询调用调用BOSS接口是否打开
                RestStatus rStatus;
                TCoerciveBlockBOSSBO bo = new TCoerciveBlockBOSSBO();
                bo.setMSISDN("86" + n.getPhone());
                checkMapper.insert(check);
                numberMapper.update(n);
                numberStopRecordMapper.insert(record);
                restStatus = new RestStatus(Boolean.TRUE, "200", "号码稽核不通过！");
                if (flag != null && flag.equals("true")) {
                    rStatus = bossNewBuyService.CoerciveBlockBOSS(bo, us);//// 调用Boss停机接口
                    if (!rStatus.getStatus()) {
                        restStatus = new RestStatus(Boolean.FALSE, "200", "号码稽核失败！<br>" + rStatus.getErrorMessage());
                        throw new Exception(rStatus.getErrorMessage());
                    }
                } 
                
                Map<String, String> map = new HashMap<String, String>();
                map.put("staff", us.getLoginName());
                map.put("phone", n.getPhone());
                map.put("whether", "稽核不通过");
                map.put("opinion", opinion);
                map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                map.put("result", "号码稽核操作完成！");
                businessLogService.businessSaveLog(Business.phone_aduit, String.valueOf(us.getId()), us.getLoginName(),"", "号码稽核", map);
            } catch (Exception e) {
//                e.printStackTrace();
                throw new Exception("号码稽核失败!<br>" + e.getMessage());
            }finally {
                getLock(Long.valueOf(id)).unlock();
            }
        return restStatus;
    }
    
    /**
     * 开户号码取消操作，修改开户申请表和号码表
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus updateCardCancle(Integer id, Integer sourseId, User us) throws Exception {
        RestStatus restStatus = null;
        getLock(Long.valueOf(id)).lock();
            try {
                TNumber n = numberMapper.select(id);
                
                //以下是渠道主页获取渠道信息
                Channels fd = channelsService.findChannelByUserId(us.getId());
                if(fd == null || fd.getChannelType() == 1) {
                    restStatus = new RestStatus(Boolean.FALSE, "500", "取消失败，当前用户不是网点用户，不能取消取消！");
                    return restStatus;
                }
                
                if(StringUtils.equals(n.getCheckStatus(), "6")){
                    restStatus = new RestStatus(Boolean.FALSE, "500", "取消失败，该号码正在开户审核中！");
                    return restStatus;
                }

                if(!StringUtils.equals(n.getCheckStatus(), Check.audit_apply) && !StringUtils.equals(n.getStatus(), TNumber.STATUS_WAIT_ACTIVATE)){
                    restStatus = new RestStatus(Boolean.FALSE, "500", "取消失败，该号码不能取消开户！");
                    return restStatus;
                }
                
                // 从开卡申请表中获取业务金额
                ApplyIdentity applyIdentity = applyIdentityMapper.findByPhoneId(n.getId());
                BigDecimal money = new BigDecimal(0);
                if (null != applyIdentity) {
                    money = applyIdentity.getMoney().divide(new BigDecimal(100));
                } else {
                    money = n.getMoney().divide(new BigDecimal(100));
                }

                // 构造takeMoney入参
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("number", n);
                param.put("channelId", null);
                param.put("accountType", null);
                param.put("operationType", 19);
                param.put("money", money);
                param.put("busMoney", money);
                param.put("remark", null);
                param.put("transactionAccount", null);
                param.put("transId", null);
                param.put("transactionType", null);
                param.put("calcType", null);
                param.put("transactionFlow", null);
                param.put("payType", null);
                param.put("us", us);
                //开户取消，冻结金额回退给一级代理和网点
                RestStatus rs = takeMoney(param);
                if (!rs.getStatus()) {
                    return rs; // 上级预备金不足
                }
                
                // 查询调用调用BOSS接口是否打开
                String flag = SysConfig.getValue("SendToBoss");
                logger.error("接口配置：" + flag + "调用接口开始");
                if (flag != null && flag.equals("true") && n.getOperatorCode()==2){// 联通号接口调用
                    try {
                        RestStatus rsStatus = bossUnicomService.doDeleteOrder(applyIdentity.getCustOrderId(), us);
                        if(!rsStatus.getStatus()){
                            logger.error("号码调用取消接口错误：phone=" + n.getPhone() + "，原因："+rsStatus.getErrorMessage());
                            throw new Exception(rsStatus.getErrorMessage());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new Exception("号码调用取消接口错误！" + e.getMessage());
                    }
                }
                
                // 向审核表添加数据
                Check check = new Check();
                check.setSourceId(sourseId);
                check.setPhoneId(n.getId());
                check.setWayType("2");
                check.setStatusType("0");
                check.setCheckOpinion("开卡取消");
                check.setChannelId(n.getCurOpenChannelId());
                check.setCreateId(us.getId());
                check.setCreateTime(new Date());
                check.setUpdateId(us.getId());
                check.setUpdateTime(new Date());
                //删除开户申请记录
                applyIdentityMapper.deleteByPhoneId(n.getId());
                //删除代理商查看号码关系表
                bizSeeMapper.deleteByPhoneId(n.getId());
                checkMapper.insert(check);
                //还原号码待开户状态
                n.setSubCheckId(null);
                n.setCheckStatus(null);
                n.setUpdateId(us.getId());
                n.setUpdateTime(new Date());
                numberMapper.updateCanclePhone(n);
                
                restStatus = new RestStatus(Boolean.TRUE, "200", "取消成功，该号码已取消开户！");

                Map<String, String> map = new HashMap<String, String>();
                map.put("staff", us.getLoginName());
                map.put("channelName", fd.getChannelName());
                map.put("channelCode", fd.getChannelCode());
                map.put("phone", n.getPhone());
                map.put("whether", "开户取消");
                map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
                map.put("result", "号码开户取消操作完成！");
                businessLogService.businessSaveLog(Business.phone_cancle, String.valueOf(us.getId()), us.getLoginName(),"", "开户取消", map);
            } catch (Exception e) {
                e.printStackTrace();
                throw new Exception("号码稽核失败!");
            }finally {
                getLock(Long.valueOf(id)).unlock();
            }
        return restStatus;
    }
    
    
    
    
    /**
     * 预开号码开户审批
     * 
     * @param id   号码ID
     * @param option
     * @return
     * @throws Exception
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus preInsertIdentity(Integer id, String option, User us, ApplyIdentity d) throws Exception {
        try {
            
            Channels fd = channelsMapper.findByPhoneId(id);
            
            // 获得申请表信息
            //List<ApplyIdentity> applyIdentities = applyIdentityMapper.applyIdentityByPhoneId(id);
            
            /*Integer sourceId = 0;
            String mealNames = "";
            ApplyIdentity d = new ApplyIdentity(); // 开户表
            if(applyIdentities != null  && applyIdentities.size() > 0) {
                d = applyIdentities.get(0);
                if(d.getCode()==null || "".equals(d.getCode().trim())){
                    IdcardInfo info = JSONUtil.jsonToObject(d.getIdcardinfo(), IdcardInfo.class);
                    d.setCode(info.getIdNumber());
                    d.setName(info.getName());
                }
                sourceId = applyIdentities.get(0).getId();
                mealNames = applyIdentities.get(0).getMealNames();
            }*/
            Integer sourceId = d.getId();
            String mealNames = d.getMealNames();

            int nu = identityMapper.findIdentityNumByCode(d.getCode());
            int phoneCountMax = 0;
            try {
                phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
            } catch (Exception e1) {
                phoneCountMax = 5;
            }
            if (nu >= phoneCountMax) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，您已开户"+phoneCountMax+"个号码，不能再进行开户！");
            }

            TNumber n = numberMapper.select(id);

            // 构造takeMoney入参
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("number", n);
            param.put("channelId", fd.getId());
            param.put("accountType", null);
            param.put("operationType", 18);
            param.put("money", d.getMoney());
            param.put("busMoney", n.getMoney());
            param.put("remark", null);
            param.put("transactionAccount", null);
            param.put("transId", null);
            param.put("transactionType", null);
            param.put("calcType", null);
            param.put("transactionFlow", null);
            param.put("payType", null);
            param.put("us", us);
            // 扣款
            RestStatus rs = takeMoney(param);
            if (!rs.getStatus()) {
                return rs; // 上级预备金不足
            }
            
            // 增加开户信息
            Identity identity = new Identity();
            identity.setCode(d.getCode());
            identity.setName(d.getName());
            identity.setPhone(d.getPhone());
            identity.setPhoneId(d.getPhoneId());
            identity.setStatus(d.getStatus());
            identity.setContactPhone(d.getContactPhone());
            identity.setOpenDate(new Date());
            identity.setMeals(d.getMeals());
            identity.setChannelId(d.getChannelId());
            identity.setChannelIdLevel1(fd.getChannelIdLevel1());
            identity.setChannelIdLevel2(fd.getChannelIdLevel2());
            identity.setChannelIdLevel3(fd.getId());
            identity.setMoney(d.getMoney());
            identity.setOpenSources(d.getOpenSources());
            identity.setOrderMoney(d.getOrderMoney());
            identity.setOpenMealId(d.getOpenMealId());
            identity.setOpenMealCode(d.getOpenMealCode());
            identity.setHandleDate(new Date());
            identity.setCompleteDate(new Date());
            
            identity.setCreateId(us.getId());
            identity.setCreateTime(new Date());
            identity.setUpdateId(us.getId());
            identity.setUpdateTime(new Date());

            identityMapper.insert(identity);
            Integer identId = identity.getId();

            List<AttachedDocuments> attachmentList = documentsMapper.findBySourceIdAndSourceName(sourceId, "t_apply_identity");

            if (null != attachmentList && attachmentList.size() > 0) {
                List<AttachedDocuments> atts = new ArrayList<AttachedDocuments>();
                for (AttachedDocuments att : attachmentList) {
                    att.setSourceName("t_identity");
                    att.setSourceId(identId);
                    
                    atts.add(att);
                }
                
                insertFeAttachment(atts);
            }

            // 预开卡数据处理到已开户表
            PreSubs preSubs = preSubsMapper.findSubsByPhone(n.getPhone());
            
            PreSubsHis preSubsHis = new PreSubsHis();
            preSubsHis.setPhone(preSubs.getPhone());
            preSubsHis.setPasswd(preSubs.getPasswd());
            preSubsHis.setIccid(preSubs.getIccid());
            preSubsHis.setImsi(preSubs.getImsi());
            preSubsHis.setServCode(preSubs.getServCode());
            preSubsHis.setServName(preSubs.getServName());
            preSubsHis.setAdvanceTime(preSubs.getAdvanceTime());
            preSubsHis.setSource(preSubs.getSource());
            preSubsHis.setChannelId(fd.getId());
            preSubsHis.setOpenTime(new Date());
            preSubsHis.setCreateId(us.getId());
            preSubsHis.setCreateTime(new Date());
            preSubsHis.setUpdateId(us.getId());
            preSubsHis.setUpdateTime(new Date());
            //已完成的预开户记录表
            preSubsHisMapper.insert(preSubsHis);
            //已完成的预开户记录,删除预开户记录
            preSubsMapper.deleteSubsByPhone(n.getPhone());
            

            n.setStatus(PhoneStatus.US03.getId());
            n.setOpenTime(new Date());
            n.setOpenChannelId(fd.getId());
            n.setOpenChannelName(fd.getChannelName());
            n.setCheckStatus(Check.audit_yes);
            numberMapper.update(n);

            Packages packages = packagesMapper.findById(d.getOpenMealId());

            // 订购业务入消息推送表
            List<BuyServRecordDTO> buys = new ArrayList<BuyServRecordDTO>();
            if (!Utils.isEmptyString(d.getMeals())) {
                // 选择的增值套餐
                String meal[] = d.getMeals().split(",");
                List<String> mealList = new ArrayList<>();
                for (int i = 0; i < meal.length; i++) {
                    if (Utils.isEmptyString(meal[i])) {
                        continue;
                    }
                    if (!mealList.contains(meal[i])) {
                        mealList.add(meal[i]);
                    } else {
                        continue;
                    }
                    
                    BuyServRecordDTO recordDTO = new BuyServRecordDTO();
                    recordDTO.setPhone(n.getPhone());
                    recordDTO.setPhoneId(n.getId());
                    recordDTO.setServCode(meal[i]);
                    recordDTO.setNetwork(String.valueOf(n.getOperatorCode()));
                    recordDTO.setNowsType("1");
                    recordDTO.setStatus("1");
                    recordDTO.setPortNum(0);
                    StringBuffer parmStr = new StringBuffer();
                    Packages pac = packagesMapper.findByCode(meal[i]);
                    // 拼接参数内容
                    if ("1".equals(pac.getServType()) || "2".equals(pac.getServType())) {
                        parmStr.append("MSISDN:").append("86" + n.getPhone()).append(",");
                        parmStr.append("OperType:").append("0").append(",");
                        parmStr.append("ServiceCode:").append(meal[i]);
                        if ("420".equals(meal[i])) {
                            recordDTO.setOrderNum(4);
                            recordDTO.setMemo("来电显示");
                            recordDTO.setServName("来电显示");
                        } else {
                            recordDTO.setOrderNum(5);
                            recordDTO.setMemo("来电提醒");
                            recordDTO.setServName("来电提醒");
                        }
                        recordDTO.setBuyType("3");
                    }else if("3".equals(pac.getServType())){
                        //语音业务
//                        parmStr.append("MSISDN:").append("86" + n.getPhone()).append(",");
//                        parmStr.append("OperType:").append("0").append(",");
//                        parmStr.append("NewOfferId:").append(meal[i]);
//                        recordDTO.setOrderNum(7);
//                        recordDTO.setMemo("语音业务");
//                        recordDTO.setServName("语音业务");
//                        recordDTO.setBuyType("3");
                    } else if ("4".equals(pac.getServType())) {
                        parmStr.append("MSISDN:").append("86" + n.getPhone()).append(",");
                        parmStr.append("OperType:").append("0").append(",");
                        parmStr.append("NewOfferId:").append(meal[i]);
                        recordDTO.setOrderNum(2);
                        recordDTO.setMemo("流量包");
                        recordDTO.setServName("流量包");
                        recordDTO.setBuyType("6");
                    } else if ("5".equals(pac.getServType())) {
                        parmStr.append("MSISDN:").append("86" + n.getPhone()).append(",");
                        parmStr.append("OperType:").append("0").append(",");
                        parmStr.append("NewOfferId:").append(meal[i]);
                        recordDTO.setOrderNum(3);
                        recordDTO.setMemo("融合流量包 ");
                        recordDTO.setServName("融合流量包 ");
                        recordDTO.setBuyType("7");
                    }
                    recordDTO.setParmStr(parmStr.toString());
                    recordDTO.setChannelId(fd.getId());
                    recordDTO.setChannelName(fd.getChannelName());
                    recordDTO.setCertName(d.getName());
                    recordDTO.setCertNbr(d.getCode());
                    recordDTO.setSourceType(d.getOpenSources());
                    recordDTO.setCreateId(us.getId());
                    recordDTO.setUpdateId(us.getId());
                    recordDTO.setPushTime(new Date());
                    buys.add(recordDTO);
                    
                }
                
                if(mealList.size() >0){
                    List<Packages> ps  = packagesMapper.findByCodes(mealList);
                    if(ps != null && ps.size() >0){
                        if(ps.size() != mealList.size()){
                            logger.error("开户失败，您购买的增值业务无法订购");
                            throw new Exception("开户失败，您购买的增值业务无法订");
                        }else{
//                            for(Packages p:ps){
//                                
//                            }
                        }
                    }else{
                        logger.error("开户失败，您购买的增值业务无法订购");
                        throw new Exception("开户失败，您购买的增值业务无法订购");
                    }
                }
            }
            
            BuyServRecordDTO recordDTO = new BuyServRecordDTO();
            recordDTO.setPhone(n.getPhone());
            recordDTO.setPhoneId(n.getId());
            recordDTO.setBuyType("2");
            recordDTO.setMemo("号码复机");
            recordDTO.setNetwork(String.valueOf(n.getOperatorCode()));
            recordDTO.setServCode("");
            recordDTO.setServName("号码复机");
            recordDTO.setNowsType("1");
            recordDTO.setStatus("1");
            recordDTO.setPortNum(0);
            StringBuffer parmStr = new StringBuffer();
            parmStr.append("MSISDN:").append("86" + n.getPhone());
            recordDTO.setParmStr(parmStr.toString());
            recordDTO.setOrderNum(1);
            recordDTO.setChannelId(fd.getId());
            recordDTO.setChannelName(fd.getChannelName());
            recordDTO.setCertName(d.getName());
            recordDTO.setCertNbr(d.getCode());
            recordDTO.setSourceType(d.getOpenSources());
            recordDTO.setCreateId(us.getId());
            recordDTO.setUpdateId(us.getId());
            recordDTO.setPushTime(new Date());
            buys.add(recordDTO);
            buyService.busServRecordSave(buys);

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            if (flag != null && flag.equals("true")) {
                if (!("1".equals(preSubs.getStatus()) && d.getCode().equals(preSubs.getCode()))) {
                    TModCustomerBOSSBO bo = new TModCustomerBOSSBO();
                    bo.setMSISDN("86" + n.getPhone());
                    bo.setCertType("1");// 身份证
                    bo.setCertNbr(d.getCode());
                    // 身份证最后一位为字母转换为0
                    /*if (d.getCode().toUpperCase().indexOf("X") > 0) {
                        bo.setCertNbr(d.getCode().toUpperCase().replaceAll("X", "0"));
                    }*/
                    bo.setCustName(d.getName());
                    logger.error("----------------------------- 号码：" + n.getPhone() + "预开卡号码开户开始调用接口 ,时间："
                            + System.nanoTime() + "-----------------------------");
                    
                    RestStatus rs1 = bossNewBuyService.ModCustomerBOSS(bo, "1", us);

                    if(!rs1.getStatus()){
                        throw new Exception("预开卡号码开户调用接口错误！" + rs1.getErrorMessage());
                    }
                    logger.error("-----------------------------号码：" + n.getPhone() + "预开卡号码开户接口调用完成,时间："
                            + System.nanoTime() + "-----------------------------");
                }
            } 
            if (flag != null && flag.equals("true")) {
                if (d.getMoney().intValue() > 0) {
                    String rechargeId = SysConfig.getValue("RechargeId");
                    String rechargePwd = SysConfig.getValue("RechargePwd");
                    TRechargeBOSSBO rechargeBO = new TRechargeBOSSBO();
                    rechargeBO.setMSISDN("86" + n.getPhone());
                    rechargeBO.setAmount(Long.valueOf(d.getMoney().intValue()));
                    rechargeBO.setSN(n.getPhone() + System.currentTimeMillis());// 流水号唯一,规则：手机号+当前时间戳
                    rechargeBO.setOperateDate(dateToXmlDate(new Date()));// 调用方操作时间
                    rechargeBO.setChannalId(rechargeId);// 充值Id
                    rechargeBO.setChannalPwd(MD5.GetMD5Code(rechargePwd));// 充值密码

                    logger.error("-----------------------------号码：" + n.getPhone() + "预开卡充值开始调用接口,时间："
                            + System.nanoTime() + "-----------------------------");
                    
                    RestStatus rs1 = bossNewBuyService.RechargeBOSS(rechargeBO, us);

                    if(!rs1.getStatus()){
                        throw new Exception("充值调用接口错误！" + rs1.getErrorMessage());
                    }
                    
                    logger.error("-----------------------------号码：" + n.getPhone() + "预开卡充值接口调用完成,时间："
                            + System.nanoTime() + "-----------------------------");
                } else {
                    logger.error("-----------------------------号码：" + d.getPhone() + "预开卡充值金额为：" + d.getMoney()
                            + ",不调用充值接口，时间：" + System.nanoTime() + "-----------------------------");
                }
            }

            //记录维护库存数据
            stockService.phoneActivation(n,us);

            // 开户日志
            Map<String, String> map = new HashMap<String, String>();
            map.put("staff", us.getLoginName());
            map.put("channelName", fd.getChannelName());
            map.put("channelCode", fd.getChannelCode());
            map.put("phone", d.getPhone());
            map.put("money", String.valueOf(d.getMoney().divide(new BigDecimal(100)).setScale(2)));
            if(StringUtils.isBlank(mealNames)){
                map.put("servtype", "无，开户套餐：" + packages.getName());
            }else {
                map.put("servtype", mealNames + "，开户套餐：" + packages.getName());
            }
            map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            map.put("result", "开户成功！");
            businessLogService.businessSaveLog(Business.phone_open, String.valueOf(us.getId()), us.getLoginName(), "", "号码开户成功", map);
            // 审核日志
            Map<String, String> map2 = new HashMap<String, String>();
            map2.put("staff", us.getLoginName());
            map2.put("phone", n.getPhone());
            map2.put("whether", "审核通过");
            map2.put("opinion", option);
            map2.put("money", String.valueOf(d.getMoney().divide(new BigDecimal(100)).setScale(2)));
            if(StringUtils.isBlank(mealNames)){
                map2.put("servtype", "无，开户套餐：" + packages.getName());
            }else {
                map2.put("servtype", mealNames + "，开户套餐：" + packages.getName());
            }
            map2.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            map2.put("result", "号码审批操作完成！");
            businessLogService.businessSaveLog(Business.phone_check, String.valueOf(us.getId()), us.getLoginName(), "", "号码审批", map2);

            // 预开户日志
            Map<String, String> preMap = new HashMap<String, String>();
            preMap.put("staff", us.getLoginName());
            preMap.put("channelName", fd.getChannelName());
            preMap.put("channelCode", fd.getChannelCode());
            preMap.put("phone", d.getPhone());
            preMap.put("money", String.valueOf(d.getMoney().divide(new BigDecimal(100)).setScale(2)));
            if(StringUtils.isBlank(mealNames)){
                preMap.put("servtype", "无，开户套餐：" + packages.getName());
            }else {
                preMap.put("servtype", mealNames + "，开户套餐：" + packages.getName());
            }
            preMap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            preMap.put("result", "预开号码开户成功！");
            businessLogService.businessSaveLog(Business.phone_pre_open, String.valueOf(us.getId()), us.getLoginName(), "",
                    "预开号码开户", preMap);

            // 充值日志
            Map<String, String> rechargeMap = new HashMap<String, String>();
            rechargeMap.put("staff", fd.getChannelName());
            rechargeMap.put("phone", d.getPhone());
            rechargeMap.put("money", String.valueOf(d.getMoney().divide(new BigDecimal(100)).setScale(2)));
            rechargeMap.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            rechargeMap.put("result", "预开户号码充值成功！");
            businessLogService.businessSaveLog(Business.phone_recharge, String.valueOf(us.getId()), us.getLoginName(), "",
                    "预开户号码充值", map);
            return new RestStatus(Boolean.TRUE, "200", "申请号码开户审核通过，成功！");
        } catch (Exception e) {
            logger.error("开户调用接口错误,原因：" + e.getMessage(),e);
            e.printStackTrace();
            throw new Exception("开户调用接口错误！" + e.getMessage());
        } 
    }
    
    /**
     * 号码开户审批
     * 
     * @param id
     * @param option
     * @throws Exception
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public RestStatus insertIdentity(Integer id, String option, User us,ApplyIdentity d) throws Exception {
        try {

            // 获得开户名称
            Channels fd = channelsMapper.findByPhoneId(id);
            
            // 获得申请表信息
            //List<ApplyIdentity> applyIdentities = applyIdentityMapper.applyIdentityByPhoneId(id);
            
            Integer sourceId = d.getId();
            String mealNames = d.getMealNames();
            // 联通保存订单的回执单号
            String custOrderId = d.getCustOrderId();

            int nu = identityMapper.findIdentityNumByCode(d.getCode());
            int phoneCountMax = 0;
            try {
                phoneCountMax = Integer.parseInt(DicUtil.getMapDictionary("USER_PHONE_MAX_SUM").get("USER_PHONE_MAX_VAL"));
            } catch (Exception e1) {
                phoneCountMax = 5;
            }
            if (nu >= phoneCountMax) {
                return new RestStatus(Boolean.FALSE, "500", "开户失败，您已开户"+phoneCountMax+"个号码，不能再进行开户！");
            }

            TNumber n = numberMapper.select(id);
            
            // 构造takeMoney入参
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("number", n);
            param.put("channelId", fd.getId());
            param.put("accountType", null);
            param.put("operationType", 18);
            param.put("money", d.getMoney());
            param.put("busMoney", n.getMoney());
            param.put("remark", null);
            param.put("transactionAccount", null);
            param.put("transId", null);
            param.put("transactionType", null);
            param.put("calcType", null);
            param.put("transactionFlow", null);
            param.put("payType", null);
            param.put("us", us);
            // 扣款
            RestStatus rs = takeMoney(param);
            if (!rs.getStatus()) {
                return rs; // 上级预备金不足
            }

            // 获取IMSI 改IMSI一定存在 而且只有一条
            NumberIccidDTO dto = numberMapper.phoneIccidByPhoneId(n.getId());

            // 增加开户信息
            Identity identity = new Identity();
            identity.setCode(d.getCode());
            identity.setName(d.getName());
            identity.setPhone(d.getPhone());
            identity.setPhoneId(d.getPhoneId());
            identity.setStatus(d.getStatus());
            identity.setContactPhone(d.getContactPhone());
            identity.setOpenDate(new Date());
            identity.setMeals(d.getMeals());
            identity.setChannelId(d.getChannelId());
            identity.setChannelIdLevel1(fd.getChannelIdLevel1());
            identity.setChannelIdLevel2(fd.getChannelIdLevel2());
            identity.setChannelIdLevel3(fd.getId());
            identity.setMoney(d.getMoney());
            identity.setOpenSources(d.getOpenSources());
            identity.setOrderMoney(d.getOrderMoney());
            identity.setOpenMealId(d.getOpenMealId());
            identity.setOpenMealCode(d.getOpenMealCode());
            
            identity.setCreateId(us.getId());
            identity.setCreateTime(new Date());
            identity.setUpdateId(us.getId());
            identity.setUpdateTime(new Date());
            
            identity.setCustOrderId(custOrderId);

            identityMapper.insert(identity);
            Integer identId = identity.getId();

            List<AttachedDocuments> attachmentList = documentsMapper.findBySourceIdAndSourceName(sourceId, "t_apply_identity");

            if (null != attachmentList && attachmentList.size() > 0) {
                List<AttachedDocuments> atts = new ArrayList<AttachedDocuments>();
                for (AttachedDocuments att : attachmentList) {
                    att.setSourceName("t_identity");
                    att.setSourceId(identId);
                    
                    atts.add(att);
                }
                
                insertFeAttachment(atts);
            }

            // 查询调用调用BOSS接口是否打开
            String flag = SysConfig.getValue("SendToBoss");
            // 修改开户状态默认开户成功，打开接口状态为待开户确认
            n.setStatus(PhoneStatus.US10.getId());
            if (flag != null && flag.equals("true")) {
                n.setStatus(PhoneStatus.US03.getId());
            }
            n.setOpenTime(new Date());
            n.setOpenChannelId(fd.getId());
            n.setOpenChannelName(fd.getChannelName());
            n.setCheckStatus(Check.audit_yes);
            numberMapper.update(n);

            logger.error("接口配置：" + flag + "调用接口开始");
            if (flag != null && flag.equals("true")) {
                if(n.getOperatorCode()==1){// 移动号接口调用
                    TNewConnectionBOSSRequest connectionRequest = new TNewConnectionBOSSRequest();
                    connectionRequest.setMSISDN("86" + d.getPhone());
                    // 增加参数
                    connectionRequest.setSubsPlanCode(d.getOpenMealCode());// 订户套餐编码
                    connectionRequest.setCertType("1");// 证件类型编码
                    connectionRequest.setCertNbr(d.getCode());// 证件号
                    connectionRequest.setCustomerName(d.getName());// 客户名称
                    connectionRequest.setDefLang("1");// 用户语种，缺省为1
                    connectionRequest.setAccountCode(null);// 付费账户代表编码，可为空
                    connectionRequest.setIMSI(dto.getImsi());// SIMS卡号IMSI
                    connectionRequest.setICCID(dto.getSimCode());// ICCID 这个号不知道怎么取
                    // 和上面的IMSI有什么区别
                    // 身份证最后一位为字母转换为0
                    String creCode = d.getCode().toUpperCase().replaceAll("X", "0");
                    connectionRequest.setUserPwd(
                            MD5.GetMD5Code(creCode.substring(creCode.length() - 6, creCode.length())));// 身份证后6位
                    connectionRequest.setAgentId(fd.getChannelCode());// 代理商编码
                    connectionRequest.setAgentName(fd.getChannelName());// 代理商名称
                    connectionRequest.setOrderId(String.valueOf(identId));// 订单编号
                    connectionRequest.setAmount(String.valueOf(d.getMoney().intValue()));
                    connectionRequest.setReturnAmount("0");
                    
                    // 增值业务
                    if (!Utils.isEmptyString(d.getOpenMeals())) {
                        TServiceDto sdtos = new TServiceDto();
                        TServiceDtoBO dbo;
                        // 选择套餐
                        String meal[] = d.getOpenMeals().split(",");
                        List<String> mealList = new ArrayList<>();
                        for (int i = 0; i < meal.length; i++) {
                            if (Utils.isEmptyString(meal[i])) {
                                continue;
                            }
                            if (!mealList.contains(meal[i])) {
                                mealList.add(meal[i]);
                            } else {
                                continue;
                            }
                            dbo = new TServiceDtoBO();
                            dbo.setServiceCode(meal[i]);
                            sdtos.getServiceDto().add(dbo);
                        }
                        connectionRequest.setServiceDtoList(sdtos);
                    }
                    
                    logger.info("Meal=" + d.getMeals());
                    logger.info("----------------------------- 开户"+d.getPhone()+"开始调用接口 ,时间：" + DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyyMMddHHmmssSSS) + "-----------------------------");
                    try {
                        RestStatus r = bossNewBuyService.NewConnectionBOSS(connectionRequest, us); 
                        if(!r.getStatus()){
                            logger.error("开户调用接口错误：phone=" + d.getPhone() + "，原因：" + r.getErrorMessage());
                            throw new Exception("号码" + d.getPhone() +"开户调用接口错误！" + r.getErrorMessage());
                        }
                    } catch (Exception e) {
                        logger.error("开户调用接口错误：phone=" + d.getPhone() + "，原因：" + e.getMessage(), e);
                        e.printStackTrace();
                        throw new Exception("开户调用接口错误！" + e.getMessage());
                    }
                } else if(n.getOperatorCode()==2){// 联通号接口调用
                    try {
                        RestStatus rsStatus = bossUnicomService.doCompleteOrder(custOrderId, us);
                        if(!rsStatus.getStatus()){
                            logger.error("开户调用接口错误：phone=" + d.getPhone() + "，原因："+rsStatus.getErrorMessage());
                            throw new Exception(rsStatus.getErrorMessage());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new Exception("开户调用接口错误！" + e.getMessage());
                    }
                }
                logger.info("-----------------------------开户"+d.getPhone()+"接口调用完成,时间：" + DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyyMMddHHmmssSSS) + "-----------------------------");
            }

            //记录维护库存数据
            stockService.phoneActivation(n,us);
            
            Packages packages = packagesMapper.findById(d.getOpenMealId());

            // 开户日志
            Map<String, String> map = new HashMap<String, String>();
            map.put("staff", us.getLoginName());
            map.put("channelName", fd.getChannelName());
            map.put("channelCode", fd.getChannelCode());
            map.put("phone", d.getPhone());
            map.put("money", String.valueOf(d.getMoney().divide(new BigDecimal(100)).setScale(2)));
            
            if(StringUtils.isBlank(mealNames)){
                map.put("servtype", "无，开户套餐：" + packages.getName());
            }else {
                map.put("servtype", mealNames + "，开户套餐：" + packages.getName());
            }
            map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            map.put("result", "开户成功！");
            businessLogService.businessSaveLog(Business.phone_open, String.valueOf(us.getId()), us.getLoginName(), "", "号码开户成功", map);
            // 审核日志
            Map<String, String> map2 = new HashMap<String, String>();
            map2.put("staff", us.getLoginName());
            map2.put("phone", n.getPhone());
            map2.put("whether", "审核通过");
            map2.put("opinion", option);
            map2.put("money", String.valueOf(d.getMoney().divide(new BigDecimal(100)).setScale(2)));
            if(StringUtils.isBlank(mealNames)){
                map2.put("servtype", "无，开户套餐：" + packages.getName());
            }else {
                map2.put("servtype", mealNames + "，开户套餐：" + packages.getName());
            }
            map2.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            map2.put("result", "号码审批操作完成！");
            businessLogService.businessSaveLog(Business.phone_check, String.valueOf(us.getId()), us.getLoginName(), "",
                    "号码审批", map2);
            return new RestStatus(Boolean.TRUE, "200", "申请号码开户审核通过，成功！");
        } catch (Exception e) {
            numberMapper.udpateNumCheckStatus("1", id);
            logger.error("开户调用接口错误,原因：" + e.getMessage(),e);
            e.printStackTrace();
            throw new Exception("开户调用接口错误！" + e.getMessage());
        } 
    }
    
    /**
     * 查询改号码是否为boss预开户号码 是预开户号码：true，否：false
     */
    public Boolean findSubsByPhone(String phone) {
        try {
            PreSubs detail = preSubsMapper.findSubsByPhone(phone);
            if (null == detail) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            logger.error("查询改号码是否为boss预开户号码失败，原因：" + e.getMessage(), e);
        }
        return false;
    }
    
    /**
     * 充值失败修信息
     * 
     * @param phone
     * @param code
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void upPreSubs(String phone, String code) throws Exception{
        preSubsMapper.upPreSubs(phone, code);
    }
    
    /**
     * 号码是否有待审核或审核已通过数据
     * @param phone
     * @return
     * @throws Exception
     */
    private Boolean phoneIsApply(Integer phoneId) throws Exception{
        ApplyIdentity applyIdentity = applyIdentityMapper.findByPhoneId(phoneId);
        /*if(applyIdentity != null && (StringUtils.equals(applyIdentity.getCheckStatus(), "1") || StringUtils.equals(applyIdentity.getCheckStatus(), "2"))){
            return Boolean.TRUE;
        }*/
        // 不为空，并且审核状态不等于3（审核不通过）时，认为已经有数据
        if (applyIdentity!=null && !"3".equals(applyIdentity.getCheckStatus())) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }
    
    // 根据号码查询是否有开户的扣款记录
    public Boolean phoneIsOpen(String phone) {
        List<Account> result = accountMapper.findphoneIsOpen(phone);
        if (null != result && result.size() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    //订购套餐金额
    public BigDecimal mealealMoneyByCodes(String codes, Integer packageId) throws Exception {
        return packagesMapper.mealealMoneyByCodes(codes, packageId);
    }
    
    //开户号码是否已经申请审核
    public Integer isExitFeccheck(String phone){
        Integer str=0;
        Check check = checkMapper.isExitCheck(phone);
        
        if(null !=check ){
            if(StringUtils.equals(check.getStatusType(), "1")){
                str= 1;
            }else if(StringUtils.equals(check.getStatusType(), "2")){
                str= 2;
            }else{
                str= 3;
            }
        }
        return str;
    }
    
    //是否被稽核过
    public boolean exitAduit(Integer phoneId){
        boolean boo=false;
        TNumber num = numberMapper.isExitAduit(phoneId);
        if(null != num){
            boo=true;
        }
        return boo;
    }
    
    /**
     * 批量添加附件
     * 
     * @param attachment
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class) // 关闭只读,对数据库有操作
    public void insertFeAttachment(List<AttachedDocuments> attachment) {
        documentsMapper.batchInsert(attachment);
    }
    
    /**
     * 添加附件(app端是照片先上传，然后进行修改)
     * 
     * @param sId
     * @param sName
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class) // 关闭只读
                                                                    // ,对数据库有操作
    public void appUpFeAttachment(Integer sId, String sName, String sourceName) {
        documentsMapper.appUpFeAttachment(sId, sName, sourceName);
    }
    
    /**
     * 账户操作
     * @param channelId  渠道ID
     * @param n  号码信息
     * @param accountType 账户类型：1：开卡账户，2：划拨账户，3：直充账户，4：消费佣金账户，5：充值佣金账户，6：直充佣金账户
     * @param operationType 操作类型：1：划拨进，2：直充(支付宝、银行卡加值)，3：纠正进，4：开卡，5：充值(号码充值)，
     *          6：奖励，7：罚款，8：提现，9：划拨出，10，纠正出, 11:充流量，12:充流量回退，13:充话费，14:充话费回退, 15:补货
     *          16: 开卡冻结，17：开卡扣款，18开卡冻结解冻扣款，19开卡冻结解冻回退，20开卡充值佣金
     * @param money 交易金额(元)
     * @param busMoney  开户相关操作： 业务人设置金额 ，  其他操作：实际交易金额（含手续费）
     * @param remark  操作备注
     * @param transactionAccount  对方账户，交易账户
     * @param transactionId  交易ID,可以为null
     * @param transactionType  交易的表名，用于指定交易ID归属于那张表的主键，可以为null
     * @param calcType  账户交易正负类型，账户加款为正："+"，账户扣款为负："-"
     * @param transactionFlow  交易流水号，适用于外部转账银行流水号,可以为null
     * @param payType  支付方式，1：银行卡支付，2：支付宝支付，3：微信支付，4：佣金转账，5：手动加值,可以为null
     * @param us 操作人信息
     */
   @Transactional(readOnly = false, rollbackFor = Exception.class) 
   public RestStatus takeMoney(Map<String, Object> param) throws Exception {
       synchronized (NumberService.class) {
           TNumber n = (TNumber) param.get("number");
           Integer channelId = (Integer) param.get("channelId");
           Integer accountType = (Integer) param.get("accountType");
           Integer operationType = (Integer) param.get("operationType");
           BigDecimal money = (BigDecimal) param.get("money");
           BigDecimal busMoney = (BigDecimal) param.get("busMoney");
           String remark = (String) param.get("remark");
           String transactionAccount = (String) param.get("transactionAccount");
           //String transId = (String) param.get("transId");
           //String transactionType = (String) param.get("transactionType");
           String calcType = (String) param.get("calcType");
           String transactionFlow = (String) param.get("transactionFlow");
           Integer payType = (Integer) param.get("payType");
           User us = (User) param.get("us");
           if (us == null) {
               us = new User();
           }
           
           RestStatus rs = new RestStatus(Boolean.TRUE, "200", "扣减金额成功！");
           logger.info(
                   "takeMoney方法, channelId={}, money={}, phone={}, userId={}, userName={}, busMoney={}, operationType={}",
                   channelId, money, n == null ? "" : n.getPhone(), us == null ? "" : us.getId(), 
                   us == null ? "" : us.getLoginName(), busMoney, OperationType.getName(operationType));
           
           // 主订单
           Order order = new Order();
           order.setBusinessType(operationType);
           // 元转分
           if (null != money) {
               order.setMoney(money.multiply(new BigDecimal(100)));
           }
           order.setStatus(0);
           order.setCreateId(us.getId());
           order.setUpdateId(us.getId());
           
           // 开户冻结开卡面额（开卡前审核）
           if (OperationType.OPEN_ACCOUNT_FREEZE.getId() == operationType) {
               String orderNo = com.agent.util.Utils.getOrderNo("A");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("开卡前审核");
               // 开卡传过来的金额是分
               order.setMoney(money);
               orderService.insert(order);
               //transactionId交易ID，适用电话号码+时间戳组合格式，主要是为了方便判断开户时对那些账户操作（多次开户情况取组合格式最大值的数据）
               //String transactionId = n.getPhone() + System.currentTimeMillis();
               //网点开卡账户操作
               // 单位（分）
               BigDecimal moneyAA = money.subtract(busMoney);
               boolean flag = true;  //网点账户（直充、划拨账户）扣款，true时默认只从直充账户扣款
               BigDecimal moneyBB = BigDecimal.ZERO;  //当flag = false时，需要从划拨账户扣款多少
               Map<String, Object> para = new HashMap<String, Object>();
               para.put("channelId", channelId);
               para.put("accountType", 3);
               ChannelAccount zc = channelAccountMapper.findByChannelIdAndType(para);
               // 未处理的充值账户订单金额
               BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
               BigDecimal rechargeBalance = zc.getAccountBalanceYuan().subtract(freezeRechargeMoney);
               
               para.put("accountType", 2);
               ChannelAccount hb = channelAccountMapper.findByChannelIdAndType(para);
               // 未处理的划拨账户订单金额
               BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
               BigDecimal allotBalance = hb.getAccountBalanceYuan().subtract(freezeAllotMoney);
               
               // 判断订单金额是否大于等于充值账户和划拨账户的总额，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
               if (moneyAA.divide(new BigDecimal(100)).compareTo(rechargeBalance.add(allotBalance)) == 1) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", "开户失败，您的账户余额不足！");
               }
               
               if(rechargeBalance.compareTo(moneyAA.divide(new BigDecimal(100))) == -1) {
                   flag = false;
                   moneyBB = moneyAA.divide(new BigDecimal(100)).subtract(rechargeBalance);
                   
                   if(allotBalance.compareTo(moneyBB) == -1) {
                       orderService.delete(order.getId());
                       return new RestStatus(Boolean.FALSE, "500", "开户失败，您的账户余额不足！");
                   }
               }
               
               Channels c = channelsMapper.findById(channelId);
               
               String transAccount = "";
               //查询开卡账户余额
               Map<String, Object> params = new HashMap<String, Object>();
               // 一级开卡账户冻结开卡面额
               params.put("channelId", c.getChannelIdLevel1());
               params.put("accountType", 1);
               ChannelAccount accountKK = channelAccountMapper.findByChannelIdAndType(params);
               // 未处理的开卡账户订单金额
               BigDecimal freezeOpenMoney = orderDetailService.calcOrderMoney(params);
               BigDecimal openMoney = accountKK.getAccountBalanceYuan().subtract(freezeOpenMoney);
               
               remark = "开卡扣款";
               //如果开卡账户余额不足，则多出余额从直充账户扣款，直充账户余额还不足，则从划拨账户扣款
               if (openMoney.multiply(new BigDecimal(100)).compareTo(busMoney) < 0) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", "开户失败，您所属的一级代理商开卡账户余额不足！");
               } else {
                   // 转换为元
                   busMoney = busMoney.divide(BigDecimal.valueOf(100));
                   moneyAA = moneyAA.divide(BigDecimal.valueOf(100));
                   BigDecimal moneyzc = rechargeBalance;
                   
                   Map<String, Object> paramTmp = new HashMap<String, Object>();
                   paramTmp.put("channelId", c.getChannelIdLevel1());
                   paramTmp.put("accountType", 1);
                   paramTmp.put("operationType", 16);
                   paramTmp.put("money", busMoney);
                   paramTmp.put("realMoney", busMoney);
                   paramTmp.put("remark", remark);
                   paramTmp.put("transactionAccount", transAccount);
                   paramTmp.put("msisdn", n.getPhone());
                   paramTmp.put("transactionId", orderNo);
                   paramTmp.put("transactionType", "t_order");
                   paramTmp.put("calcType", "-");
                   paramTmp.put("transactionFlow", null);
                   paramTmp.put("payType", null);
                   paramTmp.put("us", us);
                   paramTmp.put("orderId", order.getId());
                   paramTmp.put("orderNo", orderNo);
                   
                   rs = channelsService.channelAccountChange(paramTmp);
                   if(!rs.getStatus()) {
                       orderService.delete(order.getId());
                       return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                   }
                   //网点开卡扣款
                   if (flag) {
                       paramTmp.put("channelId", channelId);
                       paramTmp.put("accountType", 3);
                       paramTmp.put("operationType", 16);
                       paramTmp.put("money", moneyAA);
                       paramTmp.put("realMoney", moneyAA);
                       rs = channelsService.channelAccountChange(paramTmp);
                       if(!rs.getStatus()) {
                           orderService.delete(order.getId());
                           return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                       }
                   } else {
                       paramTmp.put("channelId", channelId);
                       paramTmp.put("accountType", 3);
                       paramTmp.put("operationType", 16);
                       paramTmp.put("money", moneyzc);
                       paramTmp.put("realMoney", moneyzc);
                       rs = channelsService.channelAccountChange(paramTmp);
                       if(!rs.getStatus()) {
                           orderService.delete(order.getId());
                           return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                       }
                       paramTmp.put("channelId", channelId);
                       paramTmp.put("accountType", 2);
                       paramTmp.put("operationType", 16);
                       paramTmp.put("money", moneyBB);
                       paramTmp.put("realMoney", moneyBB);
                       rs = channelsService.channelAccountChange(paramTmp);
                       if(!rs.getStatus()) {
                           orderService.delete(order.getId());
                           return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                       }
                   }
               }
           } else if(OperationType.OPEN_ACCOUNT_DEDUCT.getId() == operationType) {  //开户扣除开卡面额（开卡后审核）
               String orderNo = com.agent.util.Utils.getOrderNo("B");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("开卡后审核");
               // 开卡传过来的金额是分
               order.setMoney(money);
               orderService.insert(order);
               //transactionId交易ID，适用电话号码+时间戳组合格式，主要是为了方便判断开户时对那些账户操作（多次开户情况取组合格式最大值的数据）
               //String transactionId = n.getPhone() + System.currentTimeMillis();
               
               //网点开卡账户操作
               BigDecimal moneyAA = money.subtract(busMoney);
               boolean flag = true;  //网点账户（直充、划拨账户）扣款，true时默认只从直充账户扣款
               BigDecimal moneyBB = BigDecimal.ZERO;  //当flag = false时，需要从划拨账户扣款多少
               Map<String, Object> paramsZC = new HashMap<String, Object>();
               paramsZC.put("channelId", channelId);
               paramsZC.put("accountType", 3);
               ChannelAccount zc = channelAccountMapper.findByChannelIdAndType(paramsZC);
               // 未处理的充值账户订单金额
               BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(paramsZC);
               BigDecimal rechargeBalance = zc.getAccountBalanceYuan().subtract(freezeRechargeMoney);
               if(rechargeBalance.multiply(new BigDecimal(100)).compareTo(moneyAA) == -1) {
                   flag = false;
                   moneyBB = moneyAA.subtract(rechargeBalance.multiply(new BigDecimal(100)));
                   Map<String, Object> paramsHB = new HashMap<String, Object>();
                   paramsHB.put("channelId", channelId);
                   paramsHB.put("accountType", 2);
                   ChannelAccount hb = channelAccountMapper.findByChannelIdAndType(paramsHB);
                   // 未处理的划拨账户订单金额
                   BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(paramsHB);
                   BigDecimal allotBalance = hb.getAccountBalanceYuan().subtract(freezeAllotMoney);
                   if(allotBalance.multiply(new BigDecimal(100)).compareTo(moneyBB) == -1) {
                       orderService.delete(order.getId());
                       return new RestStatus(Boolean.FALSE, "500", "开户失败，您的账户余额不足！");
                   }
               }
               
               Channels c = channelsMapper.findById(channelId);
               
               String transAccount = "";
               //查询开卡账户余额
               Map<String, Object> params = new HashMap<String, Object>();
               // 一级开卡账户冻结开卡面额
               params.put("channelId", c.getChannelIdLevel1());
               params.put("accountType", 1);
               ChannelAccount accountKK = channelAccountMapper.findByChannelIdAndType(params);
               // 未处理的开卡账户订单金额
               BigDecimal freezeOpenMoney = orderDetailService.calcOrderMoney(params);
               BigDecimal openMoney = accountKK.getAccountBalanceYuan().subtract(freezeOpenMoney);
               
               remark = "开卡扣款";
               //如果开卡账户余额不足，则多出余额从直充账户扣款，直充账户余额还不足，则从划拨账户扣款
               if(openMoney.multiply(new BigDecimal(100)).compareTo(busMoney) < 0) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", "开户失败，您所属的一级代理商开卡账户余额不足！");
               }else {
                   busMoney = busMoney.divide(BigDecimal.valueOf(100));
                   moneyAA = moneyAA.divide(BigDecimal.valueOf(100));
                   BigDecimal moneyzc = rechargeBalance;
                   moneyBB = moneyBB.divide(BigDecimal.valueOf(100));
                   
                   Map<String, Object> paramTmp = new HashMap<String, Object>();
                   paramTmp.put("channelId", c.getChannelIdLevel1());
                   paramTmp.put("accountType", 1);
                   paramTmp.put("operationType", 17);
                   paramTmp.put("money", busMoney);
                   paramTmp.put("realMoney", busMoney);
                   paramTmp.put("remark", remark);
                   paramTmp.put("transactionAccount", transAccount);
                   paramTmp.put("msisdn", n.getPhone());
                   paramTmp.put("transactionId", orderNo);
                   paramTmp.put("transactionType", null);
                   paramTmp.put("calcType", "-");
                   paramTmp.put("transactionFlow", null);
                   paramTmp.put("payType", null);
                   paramTmp.put("us", us);
                   paramTmp.put("orderId", order.getId());
                   paramTmp.put("orderNo", orderNo);
                   //rs = channelsService.channelAccountChange(c.getChannelIdLevel1(), 1, 17, busMoney, busMoney, remark, transAccount, n.getPhone(), transactionId, null, "-", null, null, us);
                   rs = channelsService.channelAccountChange(paramTmp);
                   if(!rs.getStatus()) {
                       orderService.delete(order.getId());
                       return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                   }
                   //网点开卡扣款
                   if (flag) {
                       paramTmp.put("channelId", channelId);
                       paramTmp.put("accountType", 3);
                       paramTmp.put("operationType", 17);
                       paramTmp.put("money", moneyAA);
                       paramTmp.put("realMoney", moneyAA);
                       //rs = channelsService.channelAccountChange(channelId, 3, 17, moneyAA, moneyAA, remark, transAccount, n.getPhone(), transactionId, null, "-", null, null, us);
                       rs = channelsService.channelAccountChange(paramTmp);
                       if(!rs.getStatus()) {
                           orderService.delete(order.getId());
                           return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                       }
                       calculateCommission(channelId, moneyAA, n, order, us);
                   } else {
                       paramTmp.put("channelId", channelId);
                       paramTmp.put("accountType", 3);
                       paramTmp.put("operationType", 17);
                       paramTmp.put("money", moneyzc);
                       paramTmp.put("realMoney", moneyzc);
                       //rs = channelsService.channelAccountChange(channelId, 3, 17, moneyzc, moneyzc, remark, transAccount, n.getPhone(), transactionId, null, "-", null, null, us);
                       rs = channelsService.channelAccountChange(paramTmp);
                       if(!rs.getStatus()) {
                           orderService.delete(order.getId());
                           return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                       }
                       calculateCommission(channelId, moneyzc, n, order, us);

                       paramTmp.put("channelId", channelId);
                       paramTmp.put("accountType", 2);
                       paramTmp.put("operationType", 17);
                       paramTmp.put("money", moneyBB);
                       paramTmp.put("realMoney", moneyBB);
                       //rs = channelsService.channelAccountChange(channelId, 2, 17, moneyBB, moneyBB, remark, transAccount, n.getPhone(), transactionId, null, "-", null, null, us);
                       rs = channelsService.channelAccountChange(paramTmp);
                       if(!rs.getStatus()) {
                           orderService.delete(order.getId());
                           return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                       }
                   }
               }
           } else if(OperationType.OPEN_ACCOUNT_UNFREEZE.getId() == operationType) {  // 18开卡冻结解冻扣款
               String orderNo = com.agent.util.Utils.getOrderNo("C");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("开卡冻结解冻扣款");
               // 开卡传过来的金额是分
               order.setMoney(money);
               orderService.insert(order);
               
               remark = "开卡冻结解冻扣款";
               List<ChannelAccountTransaction> list = transactionMapper.listTransationByPhone(n.getPhone());
               if(list != null && list.size() > 0) {
                   // 多次审核不通过或开户时，会产生多条记录，取最新的记录，已开卡账户为准，一旦找到了第二条开卡账户，就跳出循环
                   boolean flag = false;
                   for (ChannelAccountTransaction transaction : list) {
                       if(transaction.getOperationType() == 16) {
                           // 如果当前要处理的账户为开卡账户，并且flag=ture，表示之前已经处理过开卡账户，需要跳出循环
                           if (flag && transaction.getAccountType() == 1) {
                               break;
                           }
                           // 遇到开卡账户，把flag置为true
                           if (transaction.getAccountType() == 1) {
                               flag = true;
                           }
                           BigDecimal transactionMoney = transaction.getTransactionMoney().divide(BigDecimal.valueOf(100));
                           Map<String, Object> paramTmp = new HashMap<String, Object>();
                           paramTmp.put("channelId", transaction.getChannelId());
                           paramTmp.put("accountType", transaction.getAccountType());
                           paramTmp.put("operationType", 18);
                           paramTmp.put("money", transactionMoney);
                           paramTmp.put("realMoney", transactionMoney);
                           paramTmp.put("remark", remark);
                           paramTmp.put("transactionAccount", transaction.getTransactionAccount());
                           paramTmp.put("msisdn", n.getPhone());
                           paramTmp.put("transactionId", orderNo);
                           paramTmp.put("transactionType", null);
                           paramTmp.put("calcType", "-");
                           paramTmp.put("transactionFlow", null);
                           paramTmp.put("payType", null);
                           paramTmp.put("us", us);
                           paramTmp.put("orderId", order.getId());
                           paramTmp.put("orderNo", orderNo);
                           //rs = channelsService.channelAccountChange(transaction.getChannelId(), transaction.getAccountType(), 18, transactionMoney, transactionMoney, remark, transaction.getTransactionAccount(), n.getPhone(), transactionId, null, "-", null, null, us);
                           rs = channelsService.channelAccountChange(paramTmp);
                           if(!rs.getStatus()) {
                               orderService.delete(order.getId());
                               return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                           }
                           if(transaction.getAccountType() == 3){
                               calculateCommission(transaction.getChannelId(), transactionMoney, n, order, us);
                           }
                       }
                   }
               }else {
                   return new RestStatus(Boolean.FALSE, "201", "开卡冻结解冻扣款异常！");
               }
           } else if(OperationType.OPEN_ACCOUNT_UNFREEZE_BACK.getId() == operationType) {  // 19开卡冻结解冻回退
               String orderNo = com.agent.util.Utils.getOrderNo("D");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("开卡退款");
               orderService.insert(order);
               remark = "开卡退款";
               List<ChannelAccountTransaction> list = transactionMapper.listTransationByPhone(n.getPhone());
               if(list != null && list.size() > 0) {
                   // 多次审核不通过或开户时，会产生多条记录，取最新的记录，已开卡账户为准，一旦找到了第二条开卡账户，就跳出循环
                   boolean flag = false;
                   for (ChannelAccountTransaction transaction : list) {
                       if(transaction.getOperationType() == 16) {
                           // 如果当前要处理的账户为开卡账户，并且flag=ture，表示之前已经处理过开卡账户，需要跳出循环
                           if (flag && transaction.getAccountType() == 1) {
                               break;
                           }
                           // 遇到开卡账户，把flag置为true
                           if (transaction.getAccountType() == 1) {
                               flag = true;
                           }
                           BigDecimal transactionMoney = transaction.getTransactionMoney().divide(BigDecimal.valueOf(100));
                           Map<String, Object> paramTmp = new HashMap<String, Object>();
                           paramTmp.put("channelId", transaction.getChannelId());
                           paramTmp.put("accountType", transaction.getAccountType());
                           paramTmp.put("operationType", 19);
                           paramTmp.put("money", transactionMoney);
                           paramTmp.put("realMoney", transactionMoney);
                           paramTmp.put("remark", remark);
                           paramTmp.put("transactionAccount", transaction.getTransactionAccount());
                           paramTmp.put("msisdn", n.getPhone());
                           paramTmp.put("transactionId", orderNo);
                           paramTmp.put("transactionType", null);
                           paramTmp.put("calcType", "+");
                           paramTmp.put("transactionFlow", null);
                           paramTmp.put("payType", null);
                           paramTmp.put("us", us);
                           paramTmp.put("orderId", order.getId());
                           paramTmp.put("orderNo", orderNo);
                           //rs = channelsService.channelAccountChange(transaction.getChannelId(), transaction.getAccountType(), 19, transactionMoney, transactionMoney, remark, transaction.getTransactionAccount(), n.getPhone(), transactionId, null, "+", null, null, us);
                           rs = channelsService.channelAccountChange(paramTmp);
                           if(!rs.getStatus()) {
                               orderService.delete(order.getId());
                               return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                           }
                       }
                   }
               }else {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "201", "开卡冻结解冻扣款异常！");
               }
           } else if (OperationType.RECHARGE_FLOW.getId() == operationType) {
               // 充流量
               String orderNo = (String) param.get("orderNo");
               order.setOrderNo(orderNo);
               order.setScanStatus(0);
               order.setRemark("充流量");
               orderService.insert(order);
               // 关联订单ID和订单编号
               param.put("orderId", order.getId());
               param.put("orderNo", order.getOrderNo());
               Map<String, Object> map = rechargeFlow(param);
               if ((boolean)map.get("status") == false) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", (String)map.get("msg"));
               }
           } else if (OperationType.RECHARGE_COST.getId() == operationType) {
               // 充话费
               String orderNo = com.agent.util.Utils.getOrderNo("F");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("充话费");
               orderService.insert(order);
               // 关联订单ID和订单编号
               param.put("orderId", order.getId());
               param.put("orderNo", order.getOrderNo());
               Map<String, Object> map = recharge(param);
               if ((boolean)map.get("status") == false) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", (String)map.get("msg"));
               }
           } else if (OperationType.REPLENISH.getId() == operationType) {
               // 补货
               String orderNo = com.agent.util.Utils.getOrderNo("E");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("补货");
               orderService.insert(order);
               // 关联订单ID和订单编号
               param.put("orderId", order.getId());
               param.put("orderNo", order.getOrderNo());
               Map<String, Object> map = replenish(param);
               if ((boolean)map.get("status") == false) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", (String)map.get("msg"));
               }
           } else if (OperationType.CORRECT_OUT.getId() == operationType) {
               Channels channels = (Channels) param.get("channels");
               // 上级给下级纠正标识为1
               String isAgent = (String) param.get("isAgent");
               // 纠正
               String orderNo = com.agent.util.Utils.getOrderNo("G");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("纠正");
               orderService.insert(order);
               
               Map<String, Object> paramTmp = new HashMap<String, Object>();
               paramTmp.put("channelId", channelId);
               paramTmp.put("accountType", accountType);
               paramTmp.put("operationType", operationType);
               paramTmp.put("money", money);
               paramTmp.put("realMoney", busMoney);
               paramTmp.put("remark", remark);
               paramTmp.put("transactionAccount", transactionAccount);
               paramTmp.put("msisdn", null);
               paramTmp.put("transactionId", orderNo);
               paramTmp.put("transactionType", "t_order");
               paramTmp.put("calcType", calcType);
               paramTmp.put("transactionFlow", null);
               paramTmp.put("payType", null);
               paramTmp.put("us", us);
               paramTmp.put("orderId", order.getId());
               paramTmp.put("orderNo", orderNo);
               rs = channelsService.channelAccountChange(paramTmp);
               if (!rs.getStatus()) {
                   logger.error(rs.getErrorMessage());
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
               }
               if ("1".equals(isAgent) && channels.getParentChannelId()!=null) {
                   String transAccount = "[" + channels.getChannelCode() + "] " + channels.getChannelName();
                   paramTmp.put("channelId", channels.getParentChannelId());
                   paramTmp.put("accountType", 2);
                   paramTmp.put("operationType", 3);
                   paramTmp.put("money", channels.getAccountBalanceHb());
                   paramTmp.put("realMoney", channels.getAccountBalanceHb());
                   paramTmp.put("remark", "上级纠正(上级加款)");
                   paramTmp.put("transactionAccount", transAccount);
                   paramTmp.put("msisdn", null);
                   paramTmp.put("transactionId", orderNo);
                   paramTmp.put("transactionType", "t_order");
                   paramTmp.put("calcType", "+");
                   paramTmp.put("transactionFlow", null);
                   paramTmp.put("payType", null);
                   paramTmp.put("us", us);
                   paramTmp.put("orderId", order.getId());
                   paramTmp.put("orderNo", orderNo);
                   rs = channelsService.channelAccountChange(paramTmp);
                   if (!rs.getStatus()) {
                       logger.error(rs.getErrorMessage());
                       orderService.delete(order.getId());
                       return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                   }
               }
           } else if (OperationType.CORRECT_IN.getId() == operationType) {
               // 纠正进
               String orderNo = com.agent.util.Utils.getOrderNo("H");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("纠正进");
               orderService.insert(order);
               
               Map<String, Object> paramTmp = new HashMap<String, Object>();
               paramTmp.put("channelId", channelId);
               paramTmp.put("accountType", accountType);
               paramTmp.put("operationType", operationType);
               paramTmp.put("money", money);
               paramTmp.put("realMoney", busMoney);
               paramTmp.put("remark", remark);
               paramTmp.put("transactionAccount", transactionAccount);
               paramTmp.put("msisdn", null);
               paramTmp.put("transactionId", orderNo);
               paramTmp.put("transactionType", "t_order");
               paramTmp.put("calcType", calcType);
               paramTmp.put("transactionFlow", null);
               paramTmp.put("payType", null);
               paramTmp.put("us", us);
               paramTmp.put("orderId", order.getId());
               paramTmp.put("orderNo", orderNo);
               rs = channelsService.channelAccountChange(paramTmp);
               if (!rs.getStatus()) {
                   logger.error(rs.getErrorMessage());
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
               }
           } else if (OperationType.ALLOT_OUT.getId() == operationType) {
               // 划拨
               String orderNo = com.agent.util.Utils.getOrderNo("I");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark("划拨");
               orderService.insert(order);

               param.put("orderId", order.getId());
               param.put("orderNo", orderNo);
               rs = saveAccountHb(param);
               if (!rs.getStatus()) {
                   logger.error(rs.getErrorMessage());
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
               }
           } else if (OperationType.OCR_ANALYSE.getId() == operationType
                   || OperationType.OCR_ID_CHECK.getId() == operationType
                   || OperationType.FACE_DECRYPT.getId() == operationType) {
               // OCR识别
               String orderNo = (String) param.get("orderNo");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark(remark);
               orderService.insert(order);
               
               param.put("orderId", order.getId());
               param.put("orderNo", orderNo);
               Map<String, Object> map = ocrAnalyse(param);
               if ((boolean)map.get("status") == false) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", (String)map.get("msg"));
               }
           } else {
               String orderNo = com.agent.util.Utils.getOrderNo("Z");
               order.setOrderNo(orderNo);
               order.setScanStatus(1);
               order.setRemark(remark);
               orderService.insert(order);
               String phone = null;
               if (null != n) {
                   phone = n.getPhone();
               }
               
               Map<String, Object> paramTmp = new HashMap<String, Object>();
               paramTmp.put("channelId", channelId);
               paramTmp.put("accountType", accountType);
               paramTmp.put("operationType", operationType);
               paramTmp.put("money", money);
               paramTmp.put("realMoney", busMoney);
               paramTmp.put("remark", remark);
               paramTmp.put("transactionAccount", transactionAccount);
               paramTmp.put("msisdn", phone);
               paramTmp.put("transactionId", order.getOrderNo());
               paramTmp.put("transactionType", "t_order");
               paramTmp.put("calcType", calcType);
               paramTmp.put("transactionFlow", transactionFlow);
               paramTmp.put("payType", payType);
               paramTmp.put("us", us);
               paramTmp.put("orderId", order.getId());
               paramTmp.put("orderNo", orderNo);
               rs = channelsService.channelAccountChange(paramTmp);
               if(!rs.getStatus()) {
                   orderService.delete(order.getId());
                   return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
               }
           }
           
           logger.info("takeMoney, 操作类型为："+OperationType.getName(operationType)
                   + ", 时间：" + DateUtil.getNowDateTimeString(DateUtil.yyyy_MM_dd_HH_mm_ss) 
                   + ", 离开扣款方法："+ Thread.currentThread().getName() + ", money：" + money);
           return rs;
       }
   }
    
   /**
    * OCR识别
    * @param param
    * @return
    * @throws Exception
    */
   private Map<String, Object> ocrAnalyse(Map<String, Object> param) throws Exception {
       User us = (User) param.get("us");
       Channels channel = (Channels) param.get("channel");
       TNumber number = (TNumber) param.get("number");
       BigDecimal orderMoney = (BigDecimal) param.get("orderMoney");
       Integer orderId = (Integer) param.get("orderId");
       String orderNo = (String) param.get("orderNo");
       Integer operationType = (Integer) param.get("operationType");
       String remark = null;
       if (operationType.intValue() == OperationType.OCR_ANALYSE.getId()) {
           remark = "OCR识别";
       } else if (operationType.intValue() == OperationType.OCR_ID_CHECK.getId()) {
           remark = "身份核验";
       } else if (operationType.intValue() == OperationType.FACE_DECRYPT.getId()) {
           remark = "人像比对";
       }
       Map<String, Object> map = new HashMap<String, Object>();
       map.put("status", true);
       
       // 获取直充账户余额
       ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 3);
       // 获取划拨账户余额
       ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 2);
       // 未处理的划拨账户订单金额
       Map<String, Object> para = new HashMap<String, Object>();
       para.put("channelId", channel.getId());
       para.put("accountType", 2);
       BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
       // 未处理的充值账户订单金额
       para.put("accountType", 3);
       BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
       
       BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
       allotBalance = allotBalance.subtract(freezeAllotMoney);
       BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
       directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
       
       // 由于OCR功能的特殊性，允许账户余额被扣成一次负值，这里不用校验，因为在入口处已经校验过
       // 判断订单金额是否大于等于充值账户和划拨账户的总额，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
//       if (orderMoney.compareTo(directRechargeBalance.add(allotBalance)) == 1) {
//           map.put("status", false);
//           map.put("msg", "账户余额不足，"+remark+"扣款失败！");
//           return map;
//       }
       
       Map<String, Object> paramTmp = new HashMap<String, Object>();
       paramTmp.put("channelId", channel.getId());
       paramTmp.put("accountType", 3);
       paramTmp.put("operationType", operationType);
       paramTmp.put("money", orderMoney);
       paramTmp.put("realMoney", orderMoney);
       paramTmp.put("remark", remark);
       paramTmp.put("transactionAccount", "");
       paramTmp.put("msisdn", number.getPhone());
       paramTmp.put("transactionId", orderNo);
       paramTmp.put("transactionType", "t_order");
       paramTmp.put("calcType", "-");
       paramTmp.put("transactionFlow", null);
       paramTmp.put("payType", null);
       paramTmp.put("us", us);
       paramTmp.put("orderId", orderId);
       paramTmp.put("orderNo", orderNo);
       
       // 直充账户扣款值
       BigDecimal directMoney = null;
       if (directRechargeBalance.compareTo(orderMoney) > -1) {
           directMoney = orderMoney;
           channelsService.channelAccountChange(paramTmp);
       } else {
           // 订单总额-直充账户的金额，得到划拨账户应该扣除的金额
           BigDecimal allotOrderMoney = null;
           // 如果直充账户余额小于零，则不能用于计算
           if (directRechargeBalance.compareTo(new BigDecimal(0)) > 0) {
               allotOrderMoney = orderMoney.subtract(directRechargeBalance);
           } else {
               allotOrderMoney = orderMoney;
           }
           if (allotBalance.compareTo(allotOrderMoney) > -1) {
               // 如果直充账户余额为0，则不处理
               if (directRechargeBalance.compareTo(new BigDecimal(0)) > 0) {
                   directMoney = directRechargeBalance;
                   // 更新直充账户的可用余额
                   paramTmp.put("money", directRechargeBalance);
                   paramTmp.put("realMoney", directRechargeBalance);
                   channelsService.channelAccountChange(paramTmp);
               }
               // 更新划拨账户的可用余额
               paramTmp.put("accountType", 2);
               paramTmp.put("operationType", operationType);
               paramTmp.put("money", allotOrderMoney);
               paramTmp.put("realMoney", allotOrderMoney);
               channelsService.channelAccountChange(paramTmp);
           } else {
               map.put("status", false);
               map.put("msg", "账户余额不足，"+remark+"扣款失败！");
               return map;
           }
       }
       
       // 从数据字典中获取直充账户的佣金比例
       if (null != directMoney) {
           CodeDictionary code = codeDictionaryService.findByDickey("BROKERAGE_RATIO");
           if (null != code) {
               String dicValue = code.getDicValue();
               BigDecimal brokerageRatio = new BigDecimal(dicValue);
               // 计算充值账户的佣金
               brokerageRatio = directMoney.multiply(brokerageRatio).divide(new BigDecimal(100));
               // 更新充值佣金账户的余额
               paramTmp.put("channelId", channel.getId());
               paramTmp.put("accountType", 6);
               paramTmp.put("money", brokerageRatio);
               paramTmp.put("realMoney", brokerageRatio);
               paramTmp.put("calcType", "+");
               paramTmp.put("remark", "充值账户佣金");
               channelsService.channelAccountChange(paramTmp);
           }
       }
       return map;
   }
   
    public TNumber findByPhone(String phone) {
        return numberMapper.findByPhone(phone);
    }
    
    public TNumber findById(Integer id) {
        return numberMapper.select(id);
    }
    
    public TNumber findByChannelIdAndPhone(String phone, Integer channelId) {
        return numberMapper.findByChannelIdAndPhone(phone, channelId);
    }
    
    public int udpateNumCheckStatus(@Param("statusStr")String statusStr,@Param("phoneId") Integer phoneId) throws Exception{
         return numberMapper.udpateNumCheckStatus(statusStr, phoneId);
    }


    /**
     * 库存统计列表
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<NumberDTO> numPreList(DataTable<NumberDTO> dt,Map<String, Object> searchParams,Channels ch) throws Exception{
        List<NumberDTO> list = numberMapper.numPreList(searchParams);
        if(null != list && list.size() >0){
            for(NumberDTO d:list){
                d.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(d.getLevel()));
                if(null == ch){
                    //总部登录
                    if(TNumber.STATUS_WAIT_ALLOT.equals(d.getStatus())){
                        d.setStatus("待分配");
                    }else if(TNumber.STATUS_WAIT_ACTIVATE.equals(d.getStatus())){
                        d.setStatus("未开户");
                    }else{
                        d.setStatus("已开户");
                    }
                }else{
                    if(TNumber.STATUS_WAIT_FINISH.equals(d.getStatus())
                            || TNumber.STATUS_FINISH_ACTIVATE.equals(d.getStatus())) {
                        d.setStatus("已开户");
                    }else if(NumberChannel.STATUS_1.toString().equals(d.getNcStatus())) {
                        d.setStatus("待分配");
                    }else{
                        d.setStatus("未开户");
                    }
                }
            }
        }
        dt.setAaData(list);
        int count = numberMapper.numPreListCount(searchParams);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }

    /**
     * 库存统计列表
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<NumberDTO> numPreListExpor(DataTable<NumberDTO> dt,Map<String, Object> searchParams,Channels ch) throws Exception{
        List<NumberDTO> list = numberMapper.numPreList(searchParams);
        if(null != list && list.size() >0){
            for(NumberDTO d:list){
                d.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(d.getLevel()));
                if(null == ch){
                    //总部登录
                    if(TNumber.STATUS_WAIT_ALLOT.equals(d.getStatus())){
                        d.setStatus("待分配");
                    }else if(TNumber.STATUS_WAIT_ACTIVATE.equals(d.getStatus())){
                        d.setStatus("未开户");
                    }else{
                        d.setStatus("已开户");
                    }
                }else{
                    if(TNumber.STATUS_WAIT_FINISH.equals(d.getStatus())
                            || TNumber.STATUS_FINISH_ACTIVATE.equals(d.getStatus())) {
                        d.setStatus("已开户");
                    }else if(NumberChannel.STATUS_1.toString().equals(d.getNcStatus())) {
                        d.setStatus("待分配");
                    }else{
                        d.setStatus("未开户");
                    }
                }
            }
        }
        dt.setAaData(list);
        return dt;
    }
    
    /**
     * 将Date类转换为XMLGregorianCalendar
     * 
     * @param date
     * @return
     */
    public XMLGregorianCalendar dateToXmlDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        DatatypeFactory dtf = null;
        XMLGregorianCalendar dateType = null;
        try {
            dtf = DatatypeFactory.newInstance();
            dateType = dtf.newXMLGregorianCalendar();
            dateType.setYear(cal.get(Calendar.YEAR));
            // 由于Calendar.MONTH取值范围为0~11,需要加1
            dateType.setMonth(cal.get(Calendar.MONTH) + 1);
            dateType.setDay(cal.get(Calendar.DAY_OF_MONTH));
            dateType.setHour(cal.get(Calendar.HOUR_OF_DAY));
            dateType.setMinute(cal.get(Calendar.MINUTE));
            dateType.setSecond(cal.get(Calendar.SECOND));
        } catch (Exception e) {
            
        }
        return dateType;
    }
    
    public synchronized  ReentrantLock getLock(Long value){

        if(!locks.containsKey(value)){
            locks.put(value,new ReentrantLock());
        }

        return locks.get(value);

    }
    
    public int findAuditCountByChannelId(Integer channelLevel, Integer channelId) {
        return numberMapper.findAuditCountByChannelId(channelLevel, channelId);
    }
    
    //网点开卡佣金计算
    public RestStatus calculateCommission(Integer channelId, BigDecimal money, TNumber number, Order order, User user) throws Exception{
        RestStatus rs = new RestStatus(Boolean.TRUE, "200", "网点开卡佣金计算成功！");
        // 从数据字典中获取直充账户的佣金比例
        if (null != money) {
            int accountType=6;
            CodeDictionary code = codeDictionaryService.findByDickey("BROKERAGE_RATIO");
            // 联通号码(联通和移动的佣金计算逻辑一致，都计算在充值佣金账户中，暂时不区分)
//            if(number.getOperatorCode()==2){
//                code = codeDictionaryService.findByDickey("UNION_BROKERAGE_RATIO");
//                accountType = 206;
//            }
            if (null != code) {
                String dicValue = code.getDicValue();
                BigDecimal brokerageRatio = new BigDecimal(dicValue);
                // 计算直充账户的佣金
                brokerageRatio = money.multiply(brokerageRatio).divide(new BigDecimal(100));
                // 更新直充佣金账户的余额
                Map<String, Object> paramTmp = new HashMap<String, Object>();
                paramTmp.put("channelId", channelId);
                paramTmp.put("accountType", accountType);
                paramTmp.put("operationType", 20);
                paramTmp.put("money", brokerageRatio);
                paramTmp.put("realMoney", brokerageRatio);
                paramTmp.put("remark", "开卡佣金");
                paramTmp.put("transactionAccount", "");
                paramTmp.put("msisdn", number.getPhone());
                paramTmp.put("transactionId", order.getOrderNo());
                paramTmp.put("transactionType", null);
                paramTmp.put("calcType", "+");
                paramTmp.put("transactionFlow", null);
                paramTmp.put("payType", null);
                paramTmp.put("us", user);
                paramTmp.put("orderId", order.getId());
                paramTmp.put("orderNo", order.getOrderNo());
                //channelsService.channelAccountChange(channelId, 6, 20, brokerageRatio, brokerageRatio,  "开卡佣金", "", phone, transactionId, null, "+", null, null, user);
                rs = channelsService.channelAccountChange(paramTmp);
                if(!rs.getStatus()) {
                    return new RestStatus(Boolean.FALSE, "500", rs.getErrorMessage());
                }
            }
        }else {
            return new RestStatus(Boolean.FALSE, "500", "网点开卡佣金计算失败！");
        }
        
        return rs;
    }

    /**
     * 号码报峻
     * @param orderId
     * @param msisdn
     * @param completeDate
     * @throws Exception
     */
    public void notif(String orderId, String msisdn, Date completeDate) throws Exception{
        logger.info("号码"+msisdn+"报峻，参数为：orderId = [" + orderId + "], msisdn = [" + msisdn + "], completeDate = [" + completeDate + "]");
        String phone = msisdn.substring(msisdn.length()-11);
        TNumber t = new TNumber();
        t.setPhone(phone);
        numberMapper.updateComplete(t);
        Identity i = new Identity();
        i.setPhone(phone);
        i.setCompleteDate(completeDate);
        identityMapper.updateIdentityComplete(i);
    }
    
    /**
     * 批量号码回收
     * @param ids
     * @return
     * @throws Exception
     */
    public RestStatus batchCallback(List<Integer> ids,User us) throws Exception{
        RestStatus rs = new RestStatus(Boolean.TRUE, "200", "批量回收操作成功！");
        Map<String,Object> searchMap = new HashMap<String,Object>();
        Map<Integer,Map<Integer,StockNumDto>> stockMap = new HashMap<Integer,Map<Integer,StockNumDto>>();  //总库存：渠道id <商品id，类型数量>
        Map<Integer,Integer> chPhoneNum = new HashMap<Integer,Integer>();//各渠道回收数量
        Date date = new Date(); //当前时间
        List<TNumber> tns = new ArrayList<TNumber>(); //号码表修改
        List<TNumberHis> tnhis = new ArrayList<TNumberHis>(); //号码历史表修改
        List<String> delNumChs = new ArrayList<String>();//删除分配记录表信息
        List<String> upNumChs = new ArrayList<String>();//修改分配记录表信息
        List<NumberRecord> nbrRecords = new ArrayList<NumberRecord>();//号码信息变更记录表
        Channels loginCh = channelsService.findChannelByUserId(us.getId()); //当前登录渠道

        Set<Integer> lowerCId = new HashSet<Integer>();//当前登录渠道的下级id
        Map<Integer,Channels> lowerCIdMap = new HashMap<Integer,Channels>();//当前登录渠道的下级id
        if(null != loginCh){
            searchMap = new HashMap<String,Object>();
            searchMap.put("parentChannelId",loginCh.getId());
            List<Channels> channelsList = channelsService.listChannels(searchMap);
            if(channelsList != null && channelsList.size() >0){
                for(Channels c:channelsList){
                    lowerCId.add(c.getId());
                    lowerCIdMap.put(c.getId(),c);
                }
            }
        }else{
            searchMap = new HashMap<String,Object>();
            searchMap.put("channelLevelEq","1");
            List<Channels> channelsList = channelsService.listChannels(searchMap);
            if(channelsList != null && channelsList.size() >0){
                for(Channels c:channelsList){
                    lowerCId.add(c.getId());
                    lowerCIdMap.put(c.getId(),c);
                }
            }
        }
        searchMap = new HashMap<String,Object>();
        searchMap.put("phoneIds",ids);
        if(null != loginCh){
            searchMap.put("allChannelId",loginCh.getId());
        }else{
            searchMap.put("allChannelId",0);
        }
        
        List<NumberDTO> numberInfos = numberMapper.numPreList(searchMap); //查询号码信息
        if(ids.size() != numberInfos.size()){
            return rs = new RestStatus(Boolean.FALSE, "500", "号码回收参数错误，请联系管理员");
        }
        
        StringBuffer errStr = new StringBuffer();
        
        for(NumberDTO d:numberInfos){
            TNumberHis ths = new TNumberHis();
            BeanUtils.copyProperties(ths, d);
            ths.setOptionType("1");
            ths.setOptionTime(date);
            tnhis.add(ths);

            if(TNumber.STATUS_FINISH_ACTIVATE.equals(d.getStatus()) 
                    || TNumber.STATUS_WAIT_FINISH.equals(d.getStatus()) 
                    || TNumber.CHECK_STATUS_1.equals(d.getCheckStatus())
                    || TNumber.CHECK_STATUS_3.equals(d.getCheckStatus())){
                errStr.append("号码"+d.getPhone()+"当前状态不可回收，");
                continue;
            }
            if(chPhoneNum.containsKey(d.getChannelId())){
                chPhoneNum.put(d.getChannelId(),chPhoneNum.get(d.getChannelId())+1);
            }else{
                chPhoneNum.put(d.getChannelId(),1);
            }
            
            TNumber tn = new TNumber();
            tn.setStatus(TNumber.STATUS_WAIT_ALLOT);
            tn.setId(d.getId());
            tn.setUpdateId(us.getId());
            tn.setUpdateTime(date);

            delNumChs.add(d.getId()+""+d.getChannelId());

            //总部回收
            if(null == loginCh){
                tn.setChannelId(0);
                if(null == d.getChannelId()){
                    errStr.append("号码"+d.getPhone()+"当前属于总部不能回收，");
                    continue;
                }
                if(0 == d.getChannelId().intValue()){
                    errStr.append("号码"+d.getPhone()+"当前属于总部不能回收，");
                    continue;
                }
                if(Channels.CHANNEL_LEVEL_1.intValue() != d.getChannelLevel().intValue()){
                    errStr.append("号码"+d.getPhone()+"当前不归属一级代理商，不能进行回收，");
                    continue;
                }
                numberUtil.stockMapSet(stockMap, 0, null,null, Stock.statistics_type_2, 1,d.getOperatorCode());
                numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_1, -1,d.getOperatorCode());
                numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_2, -1,d.getOperatorCode());
                d.setChannelId(0);
                numberUtil.addNmbRecord(nbrRecords ,d, NmbRecordOptType.CALLBACK.getId() ,
                        d.getChannelName()+"["+d.getChannelCode()+"]回收到：总部" );
            }else{
                tn.setChannelId(loginCh.getId());
                tn.setChannelName(loginCh.getChannelName());
                tn.setStatus(TNumber.STATUS_WAIT_ACTIVATE);

                upNumChs.add(d.getId()+""+loginCh.getId());

                numberUtil.stockMapSet(stockMap, loginCh.getId(), null, null, Stock.statistics_type_2, 1,d.getOperatorCode());
                numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_1, -1,d.getOperatorCode());
                numberUtil.stockMapSet(stockMap, d.getChannelId(), null, null, Stock.statistics_type_2, -1,d.getOperatorCode());

                numberUtil.addNmbRecord(nbrRecords ,d, NmbRecordOptType.CALLBACK.getId() ,
                        d.getChannelName()+"["+d.getChannelCode()+"]回收到："
                +loginCh.getChannelName()+"["+loginCh.getChannelCode()+"]");
                
                //一级回收
                if(Channels.CHANNEL_LEVEL_1.intValue() == loginCh.getChannelLevel().intValue()){
                    if(null == d.getChannelId()){
                        errStr.append("号码"+d.getPhone()+"当前属于总部不能回收，");
                        continue;
                    }
                    if(0 == d.getChannelId().intValue()){
                        errStr.append("号码"+d.getPhone()+"当前属于总部不能回收，");
                        continue;
                    }
                    if(Channels.CHANNEL_LEVEL_2.intValue() != d.getChannelLevel().intValue()){
                        errStr.append("号码"+d.getPhone()+"当前不归属二级渠道，不能进行回收，");
                        continue;
                    }
                    if(!lowerCId.contains(d.getChannelId())){
                        errStr.append("号码"+d.getPhone()+"当前归属代理商不是您的下属代理商，不能进行回收，");
                        continue;
                        
                    }
                }
                //二级回收
                if(Channels.CHANNEL_LEVEL_2.intValue() == loginCh.getChannelLevel().intValue()){
                    if(null == d.getChannelId()){
                        errStr.append("号码"+d.getPhone()+"当前属于总部不能回收，");
                        continue;
                    }
                    if(0 == d.getChannelId().intValue()){
                        errStr.append("号码"+d.getPhone()+"当前属于总部不能回收，");
                        continue;
                    }
                    if(Channels.CHANNEL_LEVEL_3.intValue() != d.getChannelLevel().intValue()){
                        errStr.append("号码"+d.getPhone()+"当前不归属三级渠道，不能进行回收，");
                        continue;
                    }
                    if(!lowerCId.contains(d.getChannelId())){
                        errStr.append("号码"+d.getPhone()+"当前归属代理商不是您的下属代理商，不能进行回收，");
                        continue;
                    }
                }
            }
            tns.add(tn);
        }
        if(!Utils.isEmptyString(errStr)){
            return rs = new RestStatus(Boolean.FALSE, "500", "批量回收操作失败，错误信息"+errStr.toString());
        }
        
        //库存信息入库
        numberUtil.insertStock(stockMap, date, us);

        //记录库存导入批次表
        List<StockAllot> stockAllots = new ArrayList<StockAllot>();
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_2);
        stockAllot.setNum(ids.size());
        stockAllot.setAllotType(StockAllot.allot_type_3);
        if(null == loginCh){
            stockAllot.setChannelIdFrom(0);
            stockAllot.setChannelCodeFrom("0");
            stockAllot.setChannelNameFrom(StockAllot.com_name);
        }else {
            stockAllot.setChannelIdFrom(loginCh.getId());
            stockAllot.setChannelCodeFrom(loginCh.getChannelCode());
            stockAllot.setChannelNameFrom(loginCh.getChannelName());
        }
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);

        for(Integer s:chPhoneNum.keySet()){
            stockAllot = new StockAllot();
            stockAllot.setServType(StockAllot.serv_type_2);
            stockAllot.setNum(chPhoneNum.get(s));
            stockAllot.setAllotType(StockAllot.allot_type_3);
            if(null == loginCh){
                stockAllot.setChannelIdFrom(lowerCIdMap.get(s).getId());
                stockAllot.setChannelCodeFrom(lowerCIdMap.get(s).getChannelCode());
                stockAllot.setChannelNameFrom(lowerCIdMap.get(s).getChannelName());
                stockAllot.setChannelIdTo(0);
                stockAllot.setChannelCodeTo("0");
                stockAllot.setChannelNameTo(StockAllot.com_name);
            }else {
                stockAllot.setChannelIdFrom(lowerCIdMap.get(s).getId());
                stockAllot.setChannelCodeFrom(lowerCIdMap.get(s).getChannelCode());
                stockAllot.setChannelNameFrom(lowerCIdMap.get(s).getChannelName());
                stockAllot.setChannelIdTo(loginCh.getId());
                stockAllot.setChannelCodeTo(loginCh.getChannelCode());
                stockAllot.setChannelNameTo(loginCh.getChannelName());
            }
            stockAllot.setCreateId(us.getId());
            stockAllot.setCreateTime(date);
            stockAllot.setUpdateId(us.getId());
            stockAllot.setUpdateTime(date);
            stockAllots.add(stockAllot);
        }
        stockAllotMapper.batchInsert(stockAllots);
        //修改号码状态和号码当前渠道id
        numberUtil.updateNumList(tns,10000);

        //分配记录表修改数据
        if(null != upNumChs && upNumChs.size()>0){
            numChMapper.batchUpdateStatus1(upNumChs);
        }

        //分配记录表删除数据
        if(null != delNumChs && delNumChs.size()>0){
            numChMapper.batchDelPidAndCid(delNumChs);
        }
        numHisMapper.batchInsert(tnhis);
        
        //号码变动记录表入库
        numberUtil.saveNbrRecordList(nbrRecords,10000,"",us);
        
        businessLogService.takeBackImportLog(us,ids.size(),Business.stock_phone_back_batch); 
        return rs;
    }
    
    
    /**
     * 批量号码备注
     * @param ids
     * @return
     * @throws Exception
     */
    public RestStatus batchRemark(List<Integer> ids,User us,String remark) throws Exception{
        RestStatus rs = new RestStatus(Boolean.TRUE, "200", "号码批量备注操作成功！");
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap = new HashMap<String,Object>();
        searchMap.put("phoneIds",ids);
        List<TNumber> numberInfos = numberMapper.list(searchMap); //查询号码信息
        if(ids.size() != numberInfos.size()){
            return rs = new RestStatus(Boolean.FALSE, "500", "号码批量备注参数错误，请联系管理员");
        }
        numberMapper.batchRemark(ids, remark);
        businessLogService.batchRemark(us,ids.size(),remark); 
        return rs;
    }
    
    
    /**
     * 批量号码分配
     * @param ids
     * @return
     * @throws Exception
     */
    public RestStatus batchAllot(List<Integer> ids,User us,String channelCode) throws Exception{
        RestStatus rs = new RestStatus(Boolean.TRUE, "200", "号码批量分配操作成功！");
        Map<String,Object> searchMap = new HashMap<String,Object>();
        List<String> phoneList  = null;//号码
        List<String> chCodes = null;//channelCode
        Map<String,List<PhoneImportDto>> chNumMap = new HashMap<String,List<PhoneImportDto>>();
        List<TNumber> upNums = new ArrayList<TNumber>();//修改号码状态为待开户列表
        List<String> upNumChList = new ArrayList<String>();//修改号码分配记录表状态，结构：phone_idchannel_id 的字符串
        Map<Integer,Map<Integer,StockNumDto>> stockMap = new HashMap<Integer,Map<Integer,StockNumDto>>();  //总库存：渠道id  ，类型数量
        List<NumberRecord> nbrRecords = new ArrayList<NumberRecord>();//号码信息变更记录表
        Date date = new Date();//当前时间
        Channels loginCh = channelsService.findChannelByUserId(us.getId());//当前登录渠道
        if(null != loginCh && (Channels.CHANNEL_LEVEL_3.intValue() == loginCh.getChannelLevel().intValue() ||
                Channels.CHANNEL_TYPE_2.intValue() == loginCh.getChannelType().intValue())){
            return rs = new RestStatus(Boolean.FALSE, "500", "对不起，您的权限不足，不能进行号码分配！");
        }
        
        phoneList = new ArrayList<String>();//号码
        chCodes = new ArrayList<String>();//渠道编号
        
        searchMap = new HashMap<String,Object>();
        Channels allotChannel = channelsService.findByCode(channelCode);
        if(null == allotChannel){
            return rs = new RestStatus(Boolean.FALSE, "500", "渠道编号输入不正确，请重新输入!");
        }
        if(null == loginCh && Channels.CHANNEL_LEVEL_1.intValue() != allotChannel.getChannelLevel().intValue()){
            return rs = new RestStatus(Boolean.FALSE, "500", "对不起，该渠道不是一级渠道您不能进行分配");
        }else if(null != loginCh && null == allotChannel.getParentChannelId()){
            return rs = new RestStatus(Boolean.FALSE, "500", "对不起，该渠道不是您的下级渠道您不能进行分配");
        }else if(null != loginCh && loginCh.getId().intValue() != allotChannel.getParentChannelId().intValue()){
            return rs = new RestStatus(Boolean.FALSE, "500", "对不起，该渠道不是您的下级渠道您不能进行分配");
        }
        
        searchMap = new HashMap<String,Object>();
        searchMap.put("phoneIds",ids);
        List<TNumber> numberInfos = numberMapper.list(searchMap); //查询号码信息
        if(ids.size() != numberInfos.size()){
            return rs = new RestStatus(Boolean.FALSE, "500", "号码分配参数错误，请联系管理员");
        }
        List<PhoneImportDto> impList = new ArrayList<PhoneImportDto>();

        StringBuffer errStr = new StringBuffer();
        for(TNumber s:numberInfos){
            PhoneImportDto dto = new PhoneImportDto();
            dto.setPhone(s.getPhone());
            if(Channels.CHANNEL_LEVEL_1.intValue() == allotChannel.getChannelLevel().intValue()){
                //分配到一级
                if(null != loginCh){
                    errStr.append(s.getPhone()).append(",");
                    continue;
                }
                dto.setChannelCode1(channelCode);
                dto.setChannelId1(allotChannel.getId());
            }else if(Channels.CHANNEL_LEVEL_3.intValue() == allotChannel.getChannelLevel().intValue()){
                //分配到三级
                if(Channels.CHANNEL_LEVEL_2.intValue() != loginCh.getChannelLevel().intValue()
                        || Channels.CHANNEL_TYPE_1.intValue() != loginCh.getChannelType().intValue()){
                    errStr.append(s.getPhone()).append(",");
                    continue;
                }
                dto.setChannelCode3(channelCode);
                dto.setChannelId3(allotChannel.getId());
            }else if(Channels.CHANNEL_LEVEL_2.intValue() == allotChannel.getChannelLevel().intValue()
                    && Channels.CHANNEL_TYPE_1.intValue() == allotChannel.getChannelType().intValue()){
                //分配到二级代理商
                if(Channels.CHANNEL_LEVEL_1.intValue() != loginCh.getChannelLevel().intValue()){
                    errStr.append(s.getPhone()).append(",");
                    continue;
                }
                dto.setChannelCode2(channelCode);
                dto.setChannelId2(allotChannel.getId());
            }else if(Channels.CHANNEL_LEVEL_2.intValue() == allotChannel.getChannelLevel().intValue()
                    && Channels.CHANNEL_TYPE_2.intValue() == allotChannel.getChannelType().intValue()){
                //分配到二级网点
                if(Channels.CHANNEL_LEVEL_1.intValue() != loginCh.getChannelLevel().intValue()){
                    errStr.append(s.getPhone()).append(",");
                    continue;
                }
                dto.setChannelCode3(channelCode);
                dto.setChannelId3(allotChannel.getId());
            }
            impList.add(dto);
        }
        if(!Utils.isEmptyString(errStr)){
            return rs = new RestStatus(Boolean.FALSE, "500", "批量分配操作失败，错误信息。号码："+errStr.toString()+"您没有分配权限");
        }
        
        
        Map<String,Object> rtnMap = new HashMap<String,Object>();
        rtnMap = numberUtil.vaildAllotCheck(0, ids.size(), impList,chCodes, phoneList,loginCh);
        if("false".equals(String.valueOf(rtnMap.get("stat")))){
            return rs = new RestStatus(Boolean.FALSE, "500", "批量分配操作失败，错误信息："+rtnMap.get("msg"));
        }
        //数据库校验
        rtnMap = numberUtil.vaildDataAllotCheck(0,ids.size(),chNumMap,upNumChList,upNums, stockMap,impList,
                chCodes,phoneList,loginCh,date,us,nbrRecords);
        if("false".equals(String.valueOf(rtnMap.get("stat")))){
            return rs = new RestStatus(Boolean.FALSE, "500", "批量分配操作失败，错误信息："+rtnMap.get("msg"));
        }
        //库存信息入库
        numberUtil.insertStock(stockMap,date,us);

        //记录库存分配批次表
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_2);
        stockAllot.setNum(impList.size());
        stockAllot.setAllotType(StockAllot.allot_type_2);
        if(null == loginCh){
            stockAllot.setChannelIdFrom(0);
            stockAllot.setChannelCodeFrom("0");
            stockAllot.setChannelNameFrom(StockAllot.com_name);
        }else {
            stockAllot.setChannelIdFrom(loginCh.getId());
            stockAllot.setChannelCodeFrom(loginCh.getChannelCode());
            stockAllot.setChannelNameFrom(loginCh.getChannelName());
        }
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);

        //录入批次表和库存表信息  有进行分配的时候
        List<NumberChannel> numChs = new ArrayList<NumberChannel>();//入库数据list
        
        String importType = "";
        if(null == loginCh){
            importType = Constant.PHONE_ALLOT_COMP;
        }else if(Channels.CHANNEL_LEVEL_1.intValue() == loginCh.getChannelLevel().intValue()){
            importType = Constant.PHONE_ALLOT_1;
        }else if(Channels.CHANNEL_LEVEL_2.intValue() == loginCh.getChannelLevel().intValue()){
            importType = Constant.PHONE_ALLOT_2;
        }
        if(chNumMap.keySet().size() > 0){
            numberUtil.saveImportData(numChs,chNumMap,us,date,importType);
        }
        
        numChMapper.batchInsert(numChs);

        if(upNumChList.size() > 0){
            numChMapper.batchUpdateStatus2(upNumChList);
        }

        //修改号码状态和号码当前渠道id
        numberUtil.updateNumList(upNums,10000);
        //号码变动记录表入库
        numberUtil.saveNbrRecordList(nbrRecords,nbrRecords.size()+1,"",us);
        
        businessLogService.importAllotLog(us,ids.size(),Business.stock_phone_allot_batch); 
        return rs;
    }
    
    /**
     * 渠道号码详情
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<NumberDTO> stockPhoneList(DataTable<NumberDTO> dt,Map<String, Object> searchParams,Channels ch) throws Exception{
        List<NumberDTO> list = new ArrayList<>();
        if("1".equals(searchParams.get("isOpen"))){
            //查询已开户
            list = numberMapper.stockOpenPhoneList(searchParams);
        }else{
            //查询库存
            list = numberMapper.stockPhoneList(searchParams);
        }
        if(null != list && list.size() >0){
            for(NumberDTO d:list){
                d.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(d.getLevel()));
                if(null == ch){
                    //总部登录
                    d.setStatus(NumberStatus.getName(d.getStatus()));
                }else{
                    if(CommonUtil.numberStatusOpen.containsKey(d.getStatus())) {
                        d.setStatus(NumberStatus.getName(d.getStatus()));
                    }else if(NumberChannel.STATUS_1.toString().equals(d.getNcStatus())) {
                        d.setStatus("待分配");
                    }else {
                        d.setStatus("未开户");
                    }
                }
            }
        }
        dt.setAaData(list);
        int count = 0;
        if("1".equals(searchParams.get("isOpen"))){
            //查询已开户
            count = numberMapper.stockOpenPhoneListCount(searchParams);
        }else{
            //查询库存
            count = numberMapper.stockPhoneListCount(searchParams);
        }
        dt.setiTotalDisplayRecords(count);
        return dt;
    }

    
    /**
     * 渠道号码详情导出
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<NumberDTO> stockPhoneListExport(DataTable<NumberDTO> dt,Map<String, Object> searchParams,Channels ch) throws Exception{
        List<NumberDTO> list = new ArrayList<>();
        if("1".equals(searchParams.get("isOpen"))){
            //查询已开户
            list = numberMapper.stockOpenPhoneList(searchParams);
        }else{
            //查询库存
            list = numberMapper.stockPhoneList(searchParams);
        }
        if(null != list && list.size() >0){
            for(NumberDTO d:list){
                d.setLevel(DicUtil.getKeyNameMap("PHONE_LEVEL_CODE").get(d.getLevel()));
                if(null == ch){
                    //总部登录
                    if(TNumber.STATUS_CANCEL.equals(d.getStatus())){
                        d.setStatus("已销户");
                    }else if(TNumber.STATUS_WAIT_ALLOT.equals(d.getStatus())){
                        d.setStatus("待分配");
                    }else if(TNumber.STATUS_WAIT_ACTIVATE.equals(d.getStatus())){
                        d.setStatus("未开户");
                    }else{
                        d.setStatus("已开户");
                    }
                }else{
                    if(TNumber.STATUS_CANCEL.equals(d.getStatus())){
                        d.setStatus("已销户");
                    }else if(TNumber.STATUS_WAIT_FINISH.equals(d.getStatus())
                            || TNumber.STATUS_FINISH_ACTIVATE.equals(d.getStatus())) {
                        d.setStatus("已开户");
                    }else if(NumberChannel.STATUS_1.toString().equals(d.getNcStatus())) {
                        d.setStatus("待分配");
                    }else{
                        d.setStatus("未开户");
                    }
                }
            }
        }
        dt.setAaData(list);
        return dt;
    }
    
    /**
     * 充话费
     * @param param
     * @return
     * @throws Exception
     */
    private Map<String, Object> recharge(Map<String, Object> param) throws Exception {
        String productCode = (String) param.get("productCode");
        User us = (User) param.get("us");
        Channels channel = (Channels) param.get("channel");
        TNumber number = (TNumber) param.get("number");
        Product product = (Product) param.get("product");
        String productName = (String) param.get("productName");
        Integer productType = (Integer) param.get("productType");
        Integer orderId = (Integer) param.get("orderId");
        String orderNo = (String) param.get("orderNo");
        String ip = (String) param.get("ip");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        
        // 获取直充账户余额
        ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 3);
        // 获取划拨账户余额
        ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 2);
        // 未处理的划拨账户订单金额
        Map<String, Object> para = new HashMap<String, Object>();
        para.put("channelId", channel.getId());
        para.put("accountType", 2);
        BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(para);
        // 未处理的充值账户订单金额
        para.put("accountType", 3);
        BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(para);
        
        BigDecimal allotBalance = allotAccount.getAccountBalanceYuan();
        allotBalance = allotBalance.subtract(freezeAllotMoney);
        BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalanceYuan();
        directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
        
        BigDecimal orderMoney = product.getSalePrice();
        orderMoney = orderMoney.divide(new BigDecimal(100));
        // 判断订单金额是否大于等于充值账户和划拨账户的总额，大于的话，提示账户余额不足（大于返回1 等于返回0 小于返回-1）
        if (orderMoney.compareTo(directRechargeBalance.add(allotBalance)) == 1) {
            map.put("status", false);
            map.put("msg", "账户余额不足，充值失败!");
            return map;
        }
        
        // 先从总金额中计算出佣金(分1,2,3级，存放在充值佣金账户中)，再从直充账户中计算佣金(存放在直充佣金账户中)，得到的结果就是这笔业务的最终佣金
        // 总价减去成本价，得到总佣金，如果总价小于成本价，则佣金记录为0
        BigDecimal totalMoney = product.getSalePrice();
        BigDecimal costMoney = product.getCostPrice();
        
        Map<String, Object> paramTmp = new HashMap<String, Object>();
        paramTmp.put("channelId", channel.getId());
        paramTmp.put("accountType", 3);
        paramTmp.put("operationType", 13);
        paramTmp.put("money", orderMoney);
        paramTmp.put("realMoney", orderMoney);
        paramTmp.put("remark", "充话费");
        paramTmp.put("transactionAccount", "");
        paramTmp.put("msisdn", number.getPhone());
        paramTmp.put("transactionId", orderNo);
        paramTmp.put("transactionType", "t_recharge_record");
        paramTmp.put("calcType", "-");
        paramTmp.put("transactionFlow", null);
        paramTmp.put("payType", null);
        paramTmp.put("us", us);
        paramTmp.put("orderId", orderId);
        paramTmp.put("orderNo", orderNo);
        
        // 直充账户扣款值
        BigDecimal directMoney = null;
        if (directRechargeBalance.compareTo(orderMoney) > -1) {
            directMoney = orderMoney;
            channelsService.channelAccountChange(paramTmp);
        } else {
            // 订单总额-直充账户的金额，得到划拨账户应该扣除的金额
            BigDecimal allotOrderMoney = null;
            // 如果直充账户余额小于零，则不能用于计算
            if (directRechargeBalance.compareTo(new BigDecimal(0)) > 0) {
                allotOrderMoney = orderMoney.subtract(directRechargeBalance);
            } else {
                allotOrderMoney = orderMoney;
            }
            if (allotBalance.compareTo(allotOrderMoney) > -1) {
                // 如果直充账户余额为0，则不处理
                if (directRechargeBalance.compareTo(new BigDecimal(0)) > 0) {
                    directMoney = directRechargeBalance;
                    // 更新直充账户的可用余额
                    paramTmp.put("money", directRechargeBalance);
                    paramTmp.put("realMoney", directRechargeBalance);
                    channelsService.channelAccountChange(paramTmp);
                }
                // 更新划拨账户的可用余额
                paramTmp.put("accountType", 2);
                paramTmp.put("operationType", 13);
                paramTmp.put("money", allotOrderMoney);
                paramTmp.put("realMoney", allotOrderMoney);
                channelsService.channelAccountChange(paramTmp);
            } else {
                map.put("status", false);
                map.put("msg", "账户余额不足，充值失败!");
                return map;
            }
        }
        
        // 从数据字典中获取直充账户的佣金比例
        if (null != directMoney) {
            CodeDictionary code = codeDictionaryService.findByDickey("BROKERAGE_RATIO");
            if (null != code) {
                String dicValue = code.getDicValue();
                BigDecimal brokerageRatio = new BigDecimal(dicValue);
                // 计算充值账户的佣金
                brokerageRatio = directMoney.multiply(brokerageRatio).divide(new BigDecimal(100));
                // 更新充值佣金账户的余额
                paramTmp.put("channelId", channel.getId());
                paramTmp.put("accountType", 6);
                paramTmp.put("money", brokerageRatio);
                paramTmp.put("realMoney", brokerageRatio);
                paramTmp.put("calcType", "+");
                paramTmp.put("remark", "充值账户佣金");
                channelsService.channelAccountChange(paramTmp);
            }
        }
        
        // 充值成记录订单
        RechargeRecord rechargeRecord = new RechargeRecord();
        rechargeRecord.setOrderNo(orderNo);
        // 话费
        rechargeRecord.setOrderType(2);
        rechargeRecord.setMsisdn(number.getPhone());
        rechargeRecord.setChannelId(channel.getId());
        rechargeRecord.setProductCode(productCode);
        rechargeRecord.setProductType(productType);
        rechargeRecord.setProductName(productName);
        rechargeRecord.setOrderMoney(totalMoney);
        if (null != costMoney) {
            rechargeRecord.setCostMoney(costMoney);
        }
        rechargeRecord.setStatus(1);
        rechargeRecord.setSource("PC");
        rechargeRecord.setRemark("充值成功");
        rechargeRecord.setIp(ip);
        rechargeRecord.setCreateId(us.getId());
        rechargeRecord.setUpdateId(us.getId());
        // 订单入库
        rechargeRecordService.insertOrder(rechargeRecord);
        
        // 目前网点和掌网厅的充值不在一张表里，不方便统计，所以网点充值增加记录ol_recharge表，用于统一查询
        OlRecharge recharge = new OlRecharge();
        recharge.setOrderNo(orderNo);
        recharge.setBuyOrderNo(null);
        recharge.setUserIp(ip);
        recharge.setDctId(null);
        recharge.setPhone(number.getPhone());
        recharge.setrType("1");
        recharge.setPayType("agent_pc");
        recharge.setPayStatus("1");
        recharge.setrStatus("1");
        recharge.setMoney(totalMoney);
        recharge.setAccountBalance(totalMoney);
        recharge.setProId(product.getId());
        recharge.setProCode(productCode);
        recharge.setProName(productName);
        recharge.setProRemark("充话费"+productName);
        recharge.setLoginName(us.getLoginName());
        recharge.setSourceType("agent_pc");
        olRechargeMapper.insert(recharge);
        return map;
    }
    
    /**
     * 充流量
     * @param param
     * @return
     * @throws Exception
     */
    private Map<String, Object> rechargeFlow(Map<String, Object> param) throws Exception {
        User us = (User) param.get("us");
        Channels channel = (Channels) param.get("channel");
        BigDecimal directRechargeBalance = (BigDecimal) param.get("directRechargeBalance");
        BigDecimal allotBalance = (BigDecimal) param.get("allotBalance");
        BigDecimal orderMoney = (BigDecimal) param.get("orderMoney");
        Integer orderId = (Integer) param.get("orderId");
        String orderNo = (String) param.get("orderNo");
        TNumber number = (TNumber) param.get("number");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        
        // 构造channelAccountChange方法入参
        Map<String, Object> paramTmp = new HashMap<String, Object>();
        paramTmp.put("channelId", channel.getId());
        paramTmp.put("accountType", AccountType.RECHARGE_ACCOUNT.getValue());
        paramTmp.put("operationType", OperationType.RECHARGE_FLOW.getId());
        paramTmp.put("money", orderMoney);
        paramTmp.put("realMoney", orderMoney);
        paramTmp.put("remark", "充流量");
        paramTmp.put("transactionAccount", "");
        paramTmp.put("msisdn", number.getPhone());
        paramTmp.put("transactionId", orderNo);
        paramTmp.put("transactionType", "t_recharge_record");
        paramTmp.put("calcType", "-");
        paramTmp.put("transactionFlow", null);
        paramTmp.put("payType", null);
        paramTmp.put("us", us);
        paramTmp.put("orderId", orderId);
        paramTmp.put("orderNo", orderNo);
        if (directRechargeBalance.compareTo(orderMoney) > -1) {
            channelsService.channelAccountChange(paramTmp);
            // 目前的逻辑，不需要冻结账户
            /*Map<String, Object> params = new HashMap<String, Object>();
            params.put("freezeBalance", orderMoney.multiply(Constant.cnt100));
            params.put("channelId", channelId);
            params.put("accountType", 3);
            channelAccountService.updateFreezeBalance(params);*/
        } else {
            // 订单总额-直充账户的金额，得到划拨账户应该扣除的金额
            BigDecimal allotOrderMoney = null;
            if (directRechargeBalance.compareTo(new BigDecimal(0)) > 0) {
                allotOrderMoney = orderMoney.subtract(directRechargeBalance);
            } else {
                allotOrderMoney = orderMoney;
            }
            if (allotBalance.compareTo(allotOrderMoney) > -1) {
                // 如果直充账户余额为0，则不处理
                if (directRechargeBalance.compareTo(new BigDecimal(0)) > 0) {
                    // 更新直充账户的可用余额
                    paramTmp.put("money", directRechargeBalance);
                    paramTmp.put("realMoney", directRechargeBalance);
                    channelsService.channelAccountChange(paramTmp);
                    // 目前的逻辑，不需要冻结账户
                    /*params.put("freezeBalance", directRechargeBalance.multiply(Constant.cnt100));
                    params.put("channelId", channelId);
                    params.put("accountType", 3);
                    // 更新直充账户的冻结金额
                    channelAccountService.updateFreezeBalance(params);*/
                }
                // 更新划拨账户的可用余额
                paramTmp.put("accountType", AccountType.ALLOT_ACCOUNT.getValue());
                paramTmp.put("money", allotOrderMoney);
                paramTmp.put("realMoney", allotOrderMoney);
                channelsService.channelAccountChange(paramTmp);
                // 目前的逻辑，不需要冻结账户
               /* params.put("freezeBalance", allotOrderMoney.multiply(Constant.cnt100));
                params.put("channelId", channelId);
                params.put("accountType", 2);
                // 更新划拨账户的冻结金额
                channelAccountService.updateFreezeBalance(params);*/
            } else {
                map.put("status", false);
                map.put("msg", "账户余额不足，充值失败!");
                return map;
            }
        }
        return map;
    }
    
    /**
     * 补货
     * @param curUser
     * @param productInfo
     * @param channel
     * @param totalMoney
     * @throws Exception
     */
    private Map<String, Object> replenish(Map<String, Object> param) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        try {
            User us = (User) param.get("us");
            String productInfo = (String) param.get("productInfo");
            Channels channel = (Channels) param.get("channel");
            BigDecimal totalMoney = (BigDecimal) param.get("totalMoney");
            Integer orderId = (Integer) param.get("orderId");
            String orderNo = (String) param.get("orderNo");
            // 划拨账户
            ChannelAccount allotAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 2);
            BigDecimal allotBalance = allotAccount.getAccountBalance();
            // 直充账户
            ChannelAccount directRechargeAccount = channelAccountService.findByChannelIdAndType(channel.getId(), 3);
            BigDecimal directRechargeBalance = directRechargeAccount.getAccountBalance();
            
            Map<String, Object> param1 = new HashMap<String, Object>();
            param1.put("channelId", channel.getId());
            param1.put("accountType", 2);
            // 未处理的划拨账户订单金额（元）
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
            // 转换为分
            freezeAllotMoney = freezeAllotMoney.multiply(new BigDecimal(100));
            allotBalance = allotBalance.subtract(freezeAllotMoney);
            param1.put("accountType", 3);
            // 未处理的充值账户订单金额（元）
            BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
            // 转换为分
            freezeRechargeMoney = freezeRechargeMoney.multiply(new BigDecimal(100));
            directRechargeBalance = directRechargeBalance.subtract(freezeRechargeMoney);
            // 账户余额
            BigDecimal accountBalance = allotBalance.add(directRechargeBalance);
            // 扣款流程：先扣直充账户，不够再扣划拨账户，划拨账户也不够，则补货失败
            if (accountBalance.compareTo(totalMoney) > -1) {
                // 补货是从自己账户里扣钱，对方账户设置为空即可
                String channelAcct = "";
                BigDecimal totalmoney = totalMoney.divide(new BigDecimal(100));

                // 构造channelAccountChange方法入参
                Map<String, Object> paramTmp = new HashMap<String, Object>();
                paramTmp.put("channelId", channel.getId());
                paramTmp.put("operationType", 15);
                paramTmp.put("remark", "申请补货");
                paramTmp.put("transactionAccount", channelAcct);
                paramTmp.put("msisdn", null);
                paramTmp.put("transactionId", orderNo);
                paramTmp.put("transactionType", "t_order");
                paramTmp.put("calcType", "-");
                paramTmp.put("transactionFlow", null);
                paramTmp.put("payType", null);
                paramTmp.put("us", us);
                paramTmp.put("orderId", orderId);
                paramTmp.put("orderNo", orderNo);
                // 直充账户余额为负数时，计算时把直充账户置为零
                if (directRechargeBalance.compareTo(new BigDecimal(0)) == -1) {
                    directRechargeBalance = new BigDecimal(0);
                }
                // 直充账户余额为0，则直接从划拨账户扣款
                if (directRechargeBalance.compareTo(new BigDecimal(0)) == 0) {
                    paramTmp.put("accountType", 2);
                    paramTmp.put("money", totalmoney);
                    paramTmp.put("realMoney", totalmoney);
                    channelsService.channelAccountChange(paramTmp);
                } else if (directRechargeBalance.compareTo(totalMoney) > -1) {
                    paramTmp.put("accountType", 3);
                    paramTmp.put("money", totalmoney);
                    paramTmp.put("realMoney", totalmoney);
                    channelsService.channelAccountChange(paramTmp);
                } else {
                    paramTmp.put("accountType", 3);
                    paramTmp.put("money", directRechargeBalance.divide(new BigDecimal(100)));
                    paramTmp.put("realMoney", directRechargeBalance.divide(new BigDecimal(100)));
                    // 直充账户余额小商品总价，先扣直充账户，再扣划拨账户
                    channelsService.channelAccountChange(paramTmp);
                    BigDecimal money = totalMoney.subtract(directRechargeBalance).divide(new BigDecimal(100));
                    
                    paramTmp.put("accountType", 2);
                    paramTmp.put("money", money);
                    paramTmp.put("realMoney", money);
                    channelsService.channelAccountChange(paramTmp);
                }
                // 修改库存
                String[] productInfos = productInfo.split(";");
                for (int i = 0; i < productInfos.length; i++) {
                    String productId = productInfos[i].split(",")[0];
                    String productNum = productInfos[i].split(",")[2];
                    stockService.applyProduct(channel, Integer.parseInt(productNum), Integer.parseInt(productId), us);
                }
            }
        } catch (Exception e) {
            logger.error("补货失败:"+e.getMessage(), e);
            map.put("status", false);
            map.put("msg", "补货失败!");
            return map;
        }
        return map;
    }
    
    // 划拨
    public RestStatus saveAccountHb(Map<String, Object> param) throws Exception {
        Channels channels = (Channels) param.get("channels");
        String transactionAccount = (String) param.get("transactionAccount");
        User us = (User) param.get("us");
        Integer orderId = (Integer) param.get("orderId");
        String orderNo = (String) param.get("orderNo");
        RestStatus restStatus = new RestStatus(Boolean.TRUE);
        
        // 构造channelAccountChange方法入参
        Map<String, Object> paramTmp = new HashMap<String, Object>();
        paramTmp.put("operationType", 9);
        paramTmp.put("remark", "上级给下级划拨扣款");
        paramTmp.put("msisdn", null);
        paramTmp.put("transactionId", orderNo);
        paramTmp.put("transactionType", "t_order");
        paramTmp.put("calcType", "-");
        paramTmp.put("transactionFlow", null);
        paramTmp.put("payType", null);
        paramTmp.put("us", us);
        paramTmp.put("orderId", orderId);
        paramTmp.put("orderNo", orderNo);
        
        if (channels.getParentChannelId() != null) {
            ChannelAccount channelAccountHb = accountService.findByChannelIdAndType(channels.getParentChannelId(), 2);
            
            Map<String, Object> param1 = new HashMap<String, Object>();
            param1.put("channelId", channels.getParentChannelId());
            param1.put("accountType", 2);
            // 未处理的划拨账户订单金额
            BigDecimal freezeAllotMoney = orderDetailService.calcOrderMoney(param1);
            BigDecimal allotMoney = channelAccountHb.getAccountBalanceYuan().subtract(freezeAllotMoney);
            
            String transAccount = "[" + channels.getChannelCode() + "] " + channels.getChannelName();
            paramTmp.put("transactionAccount", transAccount);
            
            if (allotMoney.compareTo(channels.getAccountBalanceHb()) >= 0) {
                //当划拨账户的余额大于等于划拨金额时，直接从划拨账户扣款
                paramTmp.put("channelId", channels.getParentChannelId());
                paramTmp.put("accountType", 2);
                paramTmp.put("money", channels.getAccountBalanceHb());
                paramTmp.put("realMoney", channels.getAccountBalanceHb());
                restStatus = channelsService.channelAccountChange(paramTmp);
                if (!restStatus.getStatus()) {
                    logger.error(restStatus.getErrorMessage());
                    return new RestStatus(Boolean.FALSE, "500", restStatus.getErrorMessage());
                }
            } else {
                // 如果划拨账户余额为负数，则计算时置为零
                if (allotMoney.compareTo(new BigDecimal(0)) == -1) {
                    allotMoney = new BigDecimal(0);
                }
                BigDecimal moneyZc = channels.getAccountBalanceHb().subtract(allotMoney);
                //当划拨账户的余额小于划拨金额时，先从划拨账户扣款，剩余部分将从直充账户扣款
                ChannelAccount channelAccountZc = accountService.findByChannelIdAndType(channels.getParentChannelId(), 3);
                param1.put("accountType", 3);
                // 未处理的充值账户订单金额
                BigDecimal freezeRechargeMoney = orderDetailService.calcOrderMoney(param1);
                BigDecimal rechargeMoney = channelAccountZc.getAccountBalanceYuan().subtract(freezeRechargeMoney);
                if(rechargeMoney.compareTo(moneyZc) >= 0){
                    if(allotMoney.compareTo(BigDecimal.ZERO) > 0){
                        paramTmp.put("channelId", channels.getParentChannelId());
                        paramTmp.put("accountType", 2);
                        paramTmp.put("money", allotMoney);
                        paramTmp.put("realMoney", allotMoney);
                        restStatus = channelsService.channelAccountChange(paramTmp);
                        if(!restStatus.getStatus()){
                            logger.error(restStatus.getErrorMessage());
                            return new RestStatus(Boolean.FALSE, "500", restStatus.getErrorMessage());
                        }
                    }
                    paramTmp.put("channelId", channels.getParentChannelId());
                    paramTmp.put("accountType", 3);
                    paramTmp.put("money", moneyZc);
                    paramTmp.put("realMoney", moneyZc);
                    restStatus = channelsService.channelAccountChange(paramTmp);
                    if (!restStatus.getStatus()) {
                        logger.error(restStatus.getErrorMessage());
                        return new RestStatus(Boolean.FALSE, "500", restStatus.getErrorMessage());
                    }
                } else {
                    //账户余额不足，划拨操作不成功
                    logger.error("账户余额不足，划拨操作不成功");
                    return new RestStatus(Boolean.FALSE, "500", "账户余额不足，划拨操作不成功");
                }
            }
        }
        paramTmp.put("channelId", channels.getId());
        paramTmp.put("accountType", 2);
        paramTmp.put("operationType", 1);
        paramTmp.put("money", channels.getAccountBalanceHb());
        paramTmp.put("realMoney", channels.getAccountBalanceHb());
        paramTmp.put("remark", "上级划拨(加款)");
        paramTmp.put("transactionAccount", transactionAccount);
        paramTmp.put("calcType", "+");
        restStatus = channelsService.channelAccountChange(paramTmp);
        return restStatus;
    }
    
    /**
     * 修改号码iccid
     * @param pre
     * @throws Exception
     */
    public RestStatus upIccid(TNumber tn,User us) throws Exception{
        TNumber t = numberMapper.select(tn.getId());
        if(null == t){
            return new RestStatus(Boolean.FALSE,"500","号码选择错误");
        }
        if(tn.getIccid().equals(t.getIccid()) && tn.getImsi().equals(t.getImsi())){
            return new RestStatus(Boolean.FALSE,"500","信息和原数据一致，没有进行修改");
        }
        Map<String, Object> searchMap = new HashMap<>();
        searchMap = new HashMap<>();
        searchMap.put("iccid", tn.getIccid());
        List<IccidPool> icpool = iccidPoolMapper.list(searchMap);
        if(icpool == null){
            return new RestStatus(Boolean.FALSE,"500","ICCID系统中不存在，请重新输入");
        }else{
            if(icpool.size() == 0){
                return new RestStatus(Boolean.FALSE,"500","ICCID系统中不存在，请重新输入");
            }else if(icpool.get(0).getIcStatus().intValue() == 1){
                return new RestStatus(Boolean.FALSE,"500","ICCID已上架，请重新输入");
            }else if(!icpool.get(0).getArea().equals(t.getPhone().substring(0, 7))){
                return new RestStatus(Boolean.FALSE,"500","ICCID与号码的号段不匹配");
            }
        }
        searchMap = new HashMap<>();
        searchMap.put("imsi", tn.getImsi());
        List<IccidPool> impool = iccidPoolMapper.list(searchMap);
        if(impool == null){
            return new RestStatus(Boolean.FALSE,"500","IMSI系统中不存在，请重新输入");
        }else{
            if(impool.size() == 0){
                return new RestStatus(Boolean.FALSE,"500","IMSI系统中不存在，请重新输入");
            }else if(impool.get(0).getIcStatus().intValue() == 1){
                return new RestStatus(Boolean.FALSE,"500","IMSI已上架，请重新输入");
            }else if(!impool.get(0).getArea().equals(t.getPhone().substring(0, 7))){
                return new RestStatus(Boolean.FALSE,"500","IMSI与号码的号段不匹配");
            }
        }
        if(!icpool.get(0).getImsi().equals(tn.getImsi())){
            return new RestStatus(Boolean.FALSE,"500","ICCID,IMSI不匹配，请重新输入");
        }

        searchMap = new HashMap<>();
        searchMap.put("iccidEq", tn.getIccid());
        int cnt = numberMapper.count(searchMap);
        if(cnt >0){
            return new RestStatus(Boolean.FALSE,"500","ICCID已上架，请重新输入");
        }
        searchMap = new HashMap<>();
        searchMap.put("imsiEq", tn.getImsi());
        cnt = numberMapper.count(searchMap);
        if(cnt >0){
            return new RestStatus(Boolean.FALSE,"500","IMSI系统中已存在，请重新输入");
        }
        
        numberMapper.updateIccid(tn);
        IccidHis ih = new IccidHis();
        ih.setPhone(t.getPhone());
        ih.setPhoneId(t.getId());
        ih.setHisIccid(t.getIccid());
        ih.setIccid(tn.getIccid());
        ih.setHisImsi(t.getImsi());
        ih.setImsi(tn.getImsi());
        ih.setCreateId(us.getId());
        ih.setUpdateId(us.getId());
        iccidHisMapper.insert(ih);

        List<IccidRecord> irs = new ArrayList<IccidRecord>();
        IccidRecord ir = new IccidRecord();
        ir.setPhoneId(t.getId());
        ir.setPhone(t.getPhone());
        ir.setIccid(t.getIccid());
        ir.setImsi(t.getImsi());
        ir.setOptType(IccidRecord.OPT_TYPE_1);
        ir.setRemark("仓管操作变更iccid");
        ir.setCreateId(us.getId());
        ir.setUpdateId(us.getId());
        irs.add(ir);
        
        ir = new IccidRecord();
        ir.setPhoneId(t.getId());
        ir.setPhone(t.getPhone());
        ir.setIccid(tn.getIccid());
        ir.setImsi(tn.getImsi());
        ir.setOptType(IccidRecord.OPT_TYPE_0);
        ir.setRemark("仓管操作变更iccid");
        ir.setCreateId(us.getId());
        ir.setUpdateId(us.getId());
        irs.add(ir);
        //ICCID变动记录表入库
        iccidRecordMapper.batchInsert(irs);
        
        //新iccid上架
        List<String> upIcpUp = new ArrayList<String>();
        upIcpUp.add(tn.getIccid());
        iccidPoolMapper.updateStatusUp(upIcpUp);
        
        //旧iccid下架
        List<String> upIcpLower = new ArrayList<String>();
        upIcpLower.add(t.getIccid());
        iccidPoolMapper.updateStatusLower(upIcpLower);
        

        Map<String,String> logmap = new HashMap<String,String>();
        logmap.put("staff", us.getLoginName());
        logmap.put("phone", t.getPhone());
        logmap.put("hisIccid", t.getIccid());
        logmap.put("iccid", tn.getIccid());
        logmap.put("hisImsi", t.getImsi());
        logmap.put("imsi", tn.getImsi());
        logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
        logmap.put("result","成功！");
        businessLogService.businessSaveLog(Business.phone_mod_iccid,String.valueOf(us.getId()),us.getLoginName(),"0","修改号码iccid",logmap);
        return new RestStatus(Boolean.TRUE);
    }
    
    
    /**
     * 查询号码数量
     * @param searchParams
     * @return
     * @throws Exception
     */
    public int listCount(Map<String, Object> searchParams) throws Exception{
        int count = numberMapper.count(searchParams);
        return count;
    }
    
    /**
     * 号码延期
     * @param searchParams
     * @return
     * @throws Exception
     */
    public int numberDelay(Map<String, Object> searchParams,User us) throws Exception{
        int upCnt = numberMapper.count(searchParams);
        if(upCnt > 0){
            String dstr = DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss);
            List<NumberRecord> nbrRecords = new ArrayList<>();
            int pageCnt = 10000;
            if(upCnt > pageCnt){
                int dataCount = upCnt;
                int page = 0;//页数
                if(dataCount%pageCnt !=0){
                    page = dataCount/pageCnt +1;
                }else{
                    page = dataCount/pageCnt;
                }
                int start=0;
                for (int i = 1; i <= page; i++) {
                    if (i == 1) {
                        start = i - 1;
                    } else {
                        start = (i - 1) * pageCnt;
                    }
                    searchParams.put("limit", start);
                    searchParams.put("pageSize", pageCnt);
                    List<TNumber> tns = numberMapper.list(searchParams);
                    if(null != tns && tns.size() >0){
                        for(TNumber t:tns){
                            numberUtil.addNmbRecord(nbrRecords ,t, NmbRecordOptType.DELAY.getId() ,dstr+"进行延期,有效期由："+t.getValidTimeStr()+"延期到："+String.valueOf(searchParams.get("newValidTime"))); 
                        }
                    }
                }
            }else{
                List<TNumber> tns = numberMapper.list(searchParams);
                if(null != tns && tns.size() >0){
                    for(TNumber t:tns){
                        numberUtil.addNmbRecord(nbrRecords ,t, NmbRecordOptType.DELAY.getId() ,dstr+"进行延期,有效期由："+t.getValidTimeStr()+"延期到："+String.valueOf(searchParams.get("newValidTime"))); 
                    }
                }
            }
            //号码变动记录表入库
            numberUtil.saveNbrRecordList(nbrRecords,10000,"",us);
            numberMapper.updateNumValidTime(searchParams);
            
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("dataNum", upCnt+"");
            logmap.put("vTime", String.valueOf(searchParams.get("newValidTime")));
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessLogService.businessSaveLog(Business.stock_phone_delay,String.valueOf(us.getId()),us.getLoginName(),"0","号码延期",logmap);
        }
        return upCnt;
    }
    
    /**
     * 联通号码状态同步
     * @param param
     * @return
     */
    public int updatePhoneStatus(Map<String,Object> param) {
        Map<String,String> map = new HashMap<String,String>();
        try {
            // 查找号码是否存在
            String phone = (String) param.get("phone");
            String oldStatus = (String) param.get("oldStatus");
            map.put("phone", phone);
            map.put("createDate", DateUtil.getInstance().formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            TNumber number = numberMapper.findByPhone(phone);
            if (null != number) {
                // 判断酷商的状态是否跟boss原来的状态一致
                if (!number.getStatus().equals(UnicomAndAgentStatus.getAgentStatus(oldStatus))) {
                    // 不一致 记录异常日志
                    map.put("result", "号码"+phone+"原始状态为："+number.getStatus()+"，跟BOSS系统不一致");
                    businessLogService.businessSaveLog(Business.phone_status_sync, "", "", "", "联通号码状态同步", map);
                }
            } else {
                logger.error("联通号码状态同步：号码"+phone+"不存在");
                map.put("result", "号码不存在");
                businessLogService.businessSaveLog(Business.phone_status_sync, "", "", "", "联通号码状态同步", map);
                return 0;
            }
            // 把BOSS的状态转换位酷商的状态
            String newStatus = (String) param.get("newStatus");
            newStatus = UnicomAndAgentStatus.getAgentStatus(newStatus);
            param.put("newStatus", newStatus);
            numberMapper.updatePhoneStatus(param);
            map.put("result", "成功");
            businessLogService.businessSaveLog(Business.phone_status_sync, "", "", "", "联通号码状态同步", map);
        } catch (Exception e) {
            logger.error("联通号码状态同步异常："+e.getMessage(), e);
            map.put("result", "系统异常，失败");
            businessLogService.businessSaveLog(Business.phone_status_sync, "", "", "", "联通号码状态同步", map);
            return 0;
        }
        return 1;
    }
}

