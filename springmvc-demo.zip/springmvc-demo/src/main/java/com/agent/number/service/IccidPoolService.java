package com.agent.number.service;


import java.io.File;
import java.io.FileInputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.agent.businesslog.service.BusinessLogService;
import com.agent.businesslog.util.Business;
import com.agent.common.DataTable;
import com.agent.common.SessionData;
import com.agent.constant.Constant;
import com.agent.file.dto.PhoneImportDto;
import com.agent.file.entity.AttachFile;
import com.agent.file.mapper.AttachFileMapper;
import com.agent.file.utils.FileUtil;
import com.agent.file.utils.ReadExcelUtil;
import com.agent.number.dto.IccidPoolListDTO;
import com.agent.number.entity.IccidPool;
import com.agent.number.entity.IccidRecord;
import com.agent.number.mapper.IccidPoolMapper;
import com.agent.number.mapper.IccidRecordMapper;
import com.agent.stock.entity.StockAllot;
import com.agent.stock.mapper.StockAllotMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;
import com.agent.util.Utils;

@Transactional(rollbackFor=Exception.class)
@Service("iccidPoolService")
public class IccidPoolService {
    private static Logger logger = LoggerFactory.getLogger(IccidPoolService.class);
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Resource
    private IccidPoolMapper iccidPoolMapper;
    @Autowired
    private BusinessLogService businessLogService;
    @Resource
    private StockAllotMapper stockAllotMapper;
    @Resource
    private AttachFileMapper attachFileMapper;
    @Resource
    private IccidRecordMapper iccidRecordMapper;
   
    /**
     * ICCID出库
     * @param file
     * @param importType
     * @param request
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public Map<String,Object> iccidOutStock(MultipartFile file,String importType,String remark,HttpServletRequest request) throws Exception{
        Map<String,Object> rtnMap = new HashMap<String,Object>();
        rtnMap.put("stat",true);
        String fileExt= file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1).toLowerCase();//扩展名
        Date dt = new Date();
        String fileName = DateUtil.getInstance().getDateStr(dt,DateUtil.yyyyMMddHHmmssSSS)+importType+"."+fileExt;
        String filePatch = Constant.STOCK_ICCID + File.separator + DateUtil.getInstance().getYear(dt) + File.separator + DateUtil.getInstance().getMonth(dt);
        File upFile = new File(imageURL + File.separator +filePatch + File.separator + fileName);
        if(!upFile.getParentFile().exists()){
            upFile.getParentFile().mkdirs();
        }
        User us = SessionData.getInstance().getUser(request);
        //上传文件
        logger.error("ICCID出库导入保存上传文件");
        String rtStr = FileUtil.saveImageFile(file, imageURL, filePatch, fileName);
        //调用Excel解析
        logger.error("号码导入解析上传文件");
        Map<String, String> sysCnf =DicUtil.getMapDictionary("SYS_CONFIG");
        ReadExcelUtil ru = new ReadExcelUtil();
        Map<String,Object> map = ru.readOneSheet(upFile.getPath(),importType,Integer.valueOf(sysCnf.get("EXCEL_MAX")));
        if(Utils.isEmptyString(map.get("errorBack").toString())){
            List<PhoneImportDto> impList=(List<PhoneImportDto>)map.get("objTList");
            if(null != impList && impList.size() >0){
                //保存导入的数据
                logger.error("号码导入 共："+impList.size()+"条");
                rtnMap = iccidOutImp(impList,us ,rtStr,upFile,file.getOriginalFilename(),remark);
                if("false".equals(String.valueOf(rtnMap.get("stat")))){
                    upFile.delete();
                    rtnMap.put("stat",false);
                    rtnMap.put("msg",rtnMap.get("msg"));
                }
            }else{
                upFile.delete();
                rtnMap.put("stat",false);
                rtnMap.put("msg","请填写导入数据！");
            }
            iccidLog(us,impList.size());
        }else{
            upFile.delete();
            rtnMap.put("stat",false);
            rtnMap.put("msg",map.get("errorBack"));
        }
        return rtnMap;
    }
    /**
     * ICCID出库校验
     * @param impList
     * @return
     * @throws Exception
     */
    @SuppressWarnings("resource")
    public Map<String,Object> iccidOutImp(List<PhoneImportDto> impList,User us,String fileUrl,File file,String fileName,String remark) throws Exception{
        Map<String,Object> rtnMap = new HashMap<String,Object>();
        List<String> iccidList = new ArrayList<>();
        List<String> imsiList = new ArrayList<>();
        List<String> icms = new ArrayList<>();
        StringBuffer icErrStr = new StringBuffer();
        StringBuffer imErrStr = new StringBuffer();
        Map<String, Object> mapSearch = new HashMap<String, Object>();
        List<IccidRecord> irs = new ArrayList<IccidRecord>();
        for(PhoneImportDto d:impList){
            if(!iccidList.contains(d.getIccid())){
                iccidList.add(d.getIccid());
            }else{
                icErrStr.append(d.getIccid()).append(",");
            }
            if(!imsiList.contains(d.getImsi())){
                imsiList.add(d.getImsi());
            }else{
                imErrStr.append(d.getImsi()).append(",");
            }
            icms.add(d.getIccid()+"_"+d.getImsi());
            
            IccidRecord ir = new IccidRecord();
            ir.setIccid(d.getIccid());
            ir.setImsi(d.getImsi());
            ir.setOptType(IccidRecord.OPT_TYPE_2);
            ir.setRemark(remark);
            ir.setCreateId(us.getId());
            ir.setUpdateId(us.getId());
            irs.add(ir);
        }
        if(!Utils.isEmptyString(icErrStr)){
            rtnMap.put("stat",false);
            rtnMap.put("msg","ICCID："+icErrStr.toString()+ "在文件中重复");
            return rtnMap;
        }
        if(!Utils.isEmptyString(imErrStr)){
            rtnMap.put("stat",false);
            rtnMap.put("msg","IMSI："+imErrStr.toString()+ "在文件中重复");
            return rtnMap;
        }
        mapSearch.put("iccids",iccidList);
        mapSearch.put("icStatus",IccidPool.IC_STATUS_0);
        List<IccidPool> icList = iccidPoolMapper.list(mapSearch);
        if(null !=icList && icList.size() >0){
            if(iccidList.size() != icList.size()){
                icErrStr = new StringBuffer();
                Set<String> icSet = new HashSet<>();
                for(IccidPool c:icList){
                    icSet.add(c.getIccid());
                }
                for(String c:iccidList){
                    if(!icSet.contains(c)){
                        icErrStr.append(c).append(",");
                    }
                }
                rtnMap.put("stat",false);
                rtnMap.put("msg","ICCID："+icErrStr.toString()+" 系统不存在或已出库");
                return rtnMap;
            }
        }else{
            rtnMap.put("stat",false);
            rtnMap.put("msg","ICCID都不在系统或已出库");
            return rtnMap;
        }
        mapSearch = new HashMap<String, Object>();
        mapSearch.put("imsis",imsiList);
        mapSearch.put("icStatus",IccidPool.IC_STATUS_0);
        List<IccidPool> imList = iccidPoolMapper.list(mapSearch);
        if(null !=imList && imList.size() >0){
            if(imsiList.size() != imList.size()){
                icErrStr = new StringBuffer();
                Set<String> icSet = new HashSet<>();
                for(IccidPool c:imList){
                    icSet.add(c.getImsi());
                }
                for(String c:imsiList){
                    if(!icSet.contains(c)){
                        imErrStr.append(c).append(",");
                    }
                }
                rtnMap.put("stat",false);
                rtnMap.put("msg","IMSI："+imErrStr.toString()+" 系统不存在或已出库");
                return rtnMap;
            }
        }else{
            rtnMap.put("stat",false);
            rtnMap.put("msg","IMSI都不在系统");
            return rtnMap;
        }
        
        mapSearch = new HashMap<String, Object>();
        mapSearch.put("icms",icms);
        mapSearch.put("icStatus",IccidPool.IC_STATUS_0);
        List<IccidPool> icps = iccidPoolMapper.list(mapSearch);
        if(null != icps){
            if(icms.size() != icps.size()){
                Set<String> setP = new HashSet<>();
                for(IccidPool np:icps){
                    setP.add(np.getIccid()+"_"+np.getImsi());
                }
                StringBuffer errStr = new StringBuffer();
                for(String p:icms){
                    if(!setP.contains(p)){
                        errStr.append(p).append(",");
                    }
                }
                rtnMap.put("stat",false);
                rtnMap.put("msg","ICCID_IMSI："+errStr.toString()+ "ICCID和IMSI不匹配");
                return rtnMap;
            }
        }else{
            rtnMap.put("stat",false);
            rtnMap.put("msg","所有ICCID_IMSI都不在号码池");
            return rtnMap;
        }
        
        Date date = new Date();
        //记录库存导入批次表
        StockAllot stockAllot = new StockAllot();
        stockAllot.setServType(StockAllot.serv_type_4);
        stockAllot.setNum(impList.size());
        stockAllot.setAllotType(StockAllot.allot_type_7);
        stockAllot.setChannelIdFrom(0);
        stockAllot.setChannelCodeFrom("0");
        stockAllot.setChannelNameFrom(StockAllot.com_name);
        stockAllot.setChannelIdTo(0);
        stockAllot.setChannelCodeTo("0");
        stockAllot.setChannelNameTo(StockAllot.com_name);
        stockAllot.setRemark(remark);
        stockAllot.setCreateId(us.getId());
        stockAllot.setCreateTime(date);
        stockAllot.setUpdateId(us.getId());
        stockAllot.setUpdateTime(date);
        stockAllotMapper.insert(stockAllot);
        //附件信息表入库
        AttachFile af = new AttachFile();
        af.setAttachName(fileName);
        af.setAttachDesc("ICCID出库附件");
        af.setAttachUrl(fileUrl);
        af.setAttrachType(0);
        af.setSort(1);
        FileInputStream fis= new FileInputStream(file);
        FileChannel fc= fis.getChannel();
        af.setSize(fc.size());
        af.setSourceId(stockAllot.getId());
        af.setSourceType("t_stock_allot");
        af.setCreateId(us.getId());
        af.setCreateTime(date);
        af.setUpdateId(us.getId());
        af.setUpdateTime(date);
        attachFileMapper.insert(af);
        //修改ICCID池表信息
        iccidPoolMapper.updateStatusOut(iccidList);
        //ICCID变动记录表入库
        iccidRecordMapper.batchInsert(irs);
        rtnMap.put("stat",true);
        return rtnMap;
    }
    
    /**
     * ICCID出库
     * @param us
     */
    public void iccidLog(User us,Integer dataNum){
        try{
            Map<String,String> logmap = new HashMap<String,String>();
            logmap.put("staff", us.getLoginName());
            logmap.put("dataNum", String.valueOf(dataNum));
            logmap.put("createDate", DateUtil.getInstance().formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
            logmap.put("result","成功！");
            businessLogService.businessSaveLog(Business.iccid_out_stock,String.valueOf(us.getId()),us.getLoginName(),"0","ICCID出库",logmap);
        }catch (Exception  e){
            logger.error("ICCID出库错误：原因："+e.getMessage(),e);
        }
    }
    
    /**
     * ICCID变动记录列表查询
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<IccidRecord> numIccidListUp(DataTable<IccidRecord> dt,Map<String, Object> searchParams) throws Exception{
        List<IccidRecord> list = iccidRecordMapper.list(searchParams);
        dt.setAaData(list);
        int count = iccidRecordMapper.count(searchParams);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    /**
     * ICCID池变动记录列表查询
     * @param dt
     * @param searchParams
     * @return
     */
    public DataTable<IccidPoolListDTO> stockIccidPool(DataTable<IccidPoolListDTO> dt,Map<String, Object> searchParams) throws Exception{
        List<IccidPoolListDTO> list = iccidPoolMapper.infoList(searchParams);
        dt.setAaData(list);
        int count = iccidPoolMapper.infoCount(searchParams);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    /**
     * 号码池列表查询导出
     * @param dt
     * @param searchParams
     * @return
     */
    public List<IccidPoolListDTO> stockIccidPoolExpor(Map<String, Object> searchParams) throws Exception{
        List<IccidPoolListDTO> list = iccidPoolMapper.infoList(searchParams);
        return list;
    }
    
    /**
     * 获取SIM卡信息
     * @param map
     * @return
     */
    public List<IccidPoolListDTO> simInfoList(Map<String,Object> map) {
        return iccidPoolMapper.simInfoList(map);
    }
}

