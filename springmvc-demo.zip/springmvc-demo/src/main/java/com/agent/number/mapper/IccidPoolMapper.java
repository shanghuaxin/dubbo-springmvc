package com.agent.number.mapper;

import java.util.List;
import java.util.Map;

import com.agent.common.BaseMapper;
import com.agent.number.dto.IccidPoolListDTO;
import com.agent.number.entity.IccidPool;

public interface IccidPoolMapper extends BaseMapper<IccidPool, Integer> {
    public void batchInsert(List<IccidPool> list);
    //<!-- iccid上架修改状态 -->
    public void updateStatusUp(List<String> list);
    //<!-- iccid下架修改状态 -->
    public void updateStatusLower(List<String> list);
    //<!-- iccid出库修改状态 -->
    public void updateStatusOut(List<String> list);
    
    //查询ICCID池
    public List<IccidPoolListDTO> infoList(Map<String,Object> parment);
    public int infoCount(Map<String,Object> parment);
    
    /**
     * 获取SIM卡信息
     * @param map
     * @return
     */
    public List<IccidPoolListDTO> simInfoList(Map<String,Object> map);
}
