package com.agent.number.dto;


import java.math.BigDecimal;

/**
 * 业务办理DTO
 * @author zw
 *
 */
public class BuyServSaveDTO {
    //移动
	/** 强制复机 */
	public static final String CoerciveReact = "2";
	/** 来电提醒，来电显示 */
	public static final String SetIncomingCallService = "3";
	/** 流量包*/
	public static final String DataPlanService = "6";
    /** 基础语音包 */
    public static final String VOICE = "11";
	/** 融合流量包 */
	public static final String UnificationDataPlanService = "7";
	/** 号码开户 */
	public static final String NewConnection = "8";
    /** 呼转号码设置 */
    public static final String SHIFT_PHONE = "4";
    /** 套餐变更 */
    public static final String MEAL_EDIT = "14";
	
	private Integer buyId;
	private Integer recordId;
	private Integer ditchId;
	private String ditchName;//渠道名称
	private String certName;//用户姓名
	private String certNbr;//用户身份证
	private String phone;//号码
    private String network;//网络
  //移动   业务类型：1-强制停机，2-强制复机，3-来电提醒/来电显示，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理，8-开户，14-套餐变更
    //联通   业务类型：1-强制停机，2-强制复机，3-来电提醒，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理，8-开户，9-来电显示，
    //10-叠加月包，11-语音包，12-普通日包，13-自动续订日包，14-套餐变更
	private String buyType;
	private String status;//状态：0-发送成功，1-待发送，2-发送失败
	private String parmStr;//参数内容，格式：参数1:值,参数2:值
	private String memo;//备注内容
	private Integer portNum = 0;//推送次数
	private BigDecimal servMoney = new BigDecimal(0); //价格   分为单位
    private String orderNo;//订单编号
    private String optType;   //操作类型：0-订购，1-取消，2-变更


	public Integer getDitchId() {
		return ditchId;
	}

	public void setDitchId(Integer ditchId) {
		this.ditchId = ditchId;
	}

	public String getDitchName() {
		return ditchName;
	}

	public void setDitchName(String ditchName) {
		this.ditchName = ditchName;
	}

	public String getCertName() {
		return certName;
	}

	public void setCertName(String certName) {
		this.certName = certName;
	}

	public String getCertNbr() {
		return certNbr;
	}

	public void setCertNbr(String certNbr) {
		this.certNbr = certNbr;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBuyType() {
		return buyType;
	}

	public void setBuyType(String buyType) {
		this.buyType = buyType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getParmStr() {
		return parmStr;
	}

	public void setParmStr(String parmStr) {
		this.parmStr = parmStr;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public Integer getPortNum() {
		return portNum;
	}

	public void setPortNum(Integer portNum) {
		this.portNum = portNum;
	}

	public Integer getBuyId() {
		return buyId;
	}

	public void setBuyId(Integer buyId) {
		this.buyId = buyId;
	}

	public Integer getRecordId() {
		return recordId;
	}

	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	public BigDecimal getServMoney() {
		return servMoney;
	}

	public void setServMoney(BigDecimal servMoney) {
		this.servMoney = servMoney;
	}

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }
    

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType;
    }

    @Override
    public String toString() {
        return "BuyServSaveDTO [buyId=" + buyId + ", recordId=" + recordId + ", ditchId=" + ditchId + ", ditchName="
                + ditchName + ", certName=" + certName + ", certNbr=" + certNbr + ", phone=" + phone + ", network="
                + network + ", buyType=" + buyType + ", status=" + status + ", parmStr=" + parmStr + ", memo=" + memo
                + ", portNum=" + portNum + ", servMoney=" + servMoney + ", orderNo=" + orderNo + ", optType=" + optType
                + "]";
    }
}
