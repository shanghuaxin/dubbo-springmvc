package com.agent.number.mapper;

import java.util.List;

import com.agent.common.BaseMapper;
import com.agent.number.entity.NumberRecord;

public interface NumberRecordMapper extends BaseMapper<NumberRecord, Integer> {
    public void batchInsert(List<NumberRecord> list);
}
