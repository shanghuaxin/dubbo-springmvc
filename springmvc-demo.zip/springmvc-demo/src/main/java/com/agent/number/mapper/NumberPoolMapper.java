package com.agent.number.mapper;

import java.util.List;
import java.util.Map;

import com.agent.common.BaseMapper;
import com.agent.number.dto.NumberPoolListDTO;
import com.agent.number.entity.NumberPool;

public interface NumberPoolMapper extends BaseMapper<NumberPool, Integer> {
    public void batchInsert(List<NumberPool> list);
    //<!-- 号码上架修改状态 -->
    public void updateStatusUp(List<String> list);
    //<!-- 号码下架修改状态 -->
    public void updateStatusLower(List<String> list);
    //查询号码池
    public List<NumberPoolListDTO> infoList(Map<String,Object> parment);
    public int infoCount(Map<String,Object> parment);
}
