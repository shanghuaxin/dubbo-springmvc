package com.agent.number.dto;

/**
 * Created by zw on 2015/8/25.
 */
public class MealDTO{
    private Long id;//id
    private String code;//编号
    private String name;//名称
    private String serviceDesc;//业务描述
    private Float money;//预绑定面额
    private String defaultFlag;//默认选中 0-不选中，1-选中

    public MealDTO(){}

    public MealDTO(String code,Float money){
        this.code = code;
        this.money = money;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getServiceDesc() {
        return serviceDesc;
    }

    public void setServiceDesc(String serviceDesc) {
        this.serviceDesc = serviceDesc;
    }

    public Float getMoney() {
        return money;
    }

    public void setMoney(Float money) {
        this.money = money;
    }

    public String getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(String defaultFlag) {
        this.defaultFlag = defaultFlag;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
