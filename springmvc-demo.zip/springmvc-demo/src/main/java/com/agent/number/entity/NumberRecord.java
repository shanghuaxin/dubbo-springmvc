package com.agent.number.entity;

import com.agent.common.BaseDomain;
import com.agent.common.enumeration.NmbRecordOptType;

/**
 * 号码变更记录表
 */
public class NumberRecord extends BaseDomain {
    
    /**
     * 
     */
    private static final long serialVersionUID = -3686746686801680825L;
    private Integer phoneId ;// '号码id',
    private String phone ;// '号码',
    private Integer optType ;// '操作类型：  100-进入系统，  101-上架，102-分配，103-修改iccid，104-修改面额，105-延期，106-回收，107-下架，201-锁定，202-解锁，203-开户，204-激活，205-过户',
    private String optStr ;// '操作内容',
    private String remark ;// '备注',
    
    private String nickName;//操作人昵称
    
    public Integer getPhoneId() {
        return phoneId;
    }
    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getOptTypeStr() {
        if(null != optType){
            return NmbRecordOptType.getName(optType);
        }
        return "";
    }
    public Integer getOptType() {
        return optType;
    }
    public void setOptType(Integer optType) {
        this.optType = optType;
    }
    public String getOptStr() {
        return optStr;
    }
    public void setOptStr(String optStr) {
        this.optStr = optStr;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getNickName() {
        return nickName;
    }
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
}
