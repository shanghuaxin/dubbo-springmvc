package com.agent.number.mapper;

import com.agent.common.BaseMapper;
import com.agent.number.dto.NumberIccidDTO;
import com.agent.number.dto.NumberDTO;
import com.agent.number.entity.TNumber;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface NumberMapper extends BaseMapper<TNumber, Integer> {
    public List<TNumber> listOpenAccount(Map<String, Object> params);  
    public Integer countOpenAccount(Map<String, Object> params); 
    //批量查看照片
    public List<TNumber> batchViewPic(Map<String, Object> params); 
    public int batchInsert(List<TNumber> list);
    public TNumber findByPhone(@Param(value="phone") String phone);
    public NumberIccidDTO phoneIccidByPhoneId(@Param(value="phoneId") Integer phoneId);
    public List<NumberDTO> numPreList(Map<String,Object> parment);
    public int numPreListCount(Map<String,Object> parment);
    public int batchUpdateNumId(List<TNumber> list);
    public int batchDelById(List<Integer> list);
    public int batchUpdateCancle(List<Integer> phoneIdList);
    public int upPrePhone(List<Integer> list);
    public TNumber findByChannelIdAndPhone(@Param(value="phone")String phone, @Param(value="channelId")Integer channelId);
    public int maxId();
    
    public int udpateNumCheckStatus(@Param("statusStr")String statusStr,@Param("phoneId") Integer phoneId);
    //开户号码是否已经稽查
    public TNumber isExitAduit(@Param(value="id") Integer id);
    //开户待审核数
    public int findAuditCountByChannelId(@Param(value="channelLevel")Integer channelLevel, @Param(value="channelId")Integer channelId);

    //查询待推送复机业务号码
    public List<TNumber> listBuyPush();
    //修改已推送复机业务号码状态
    public int updateStatusComplete(List<TNumber> list);
    //号码报峻
    public int updateComplete(TNumber tNumber);
    //号码批量备注
    public int batchRemark(@Param("ids")List<Integer> ids,@Param("remark") String remark);
    //修改预开户
    public int updateIsPre(TNumber tNumber);
    //修改iccid
    public int updateIccid(TNumber tNumber);
    
    //查询渠道号码详情
    public List<NumberDTO> stockPhoneList(Map<String,Object> parment);
    public int stockPhoneListCount(Map<String,Object> parment);
    //开户取消修改号码状态
    public int updateCanclePhone(TNumber n);
    //查询渠道已开户号码详情
    public List<NumberDTO> stockOpenPhoneList(Map<String,Object> parment);
    public int stockOpenPhoneListCount(Map<String,Object> parment);
    //号码延期
    public int updateNumValidTime(Map<String,Object> parment);
    
    // 号码状态同步
    public int updatePhoneStatus(Map<String,Object> param);
}
