package com.agent.number.dto;

import java.util.List;

import com.agent.number.entity.NumberChannel;

/**
 * 号码分配记录表
 */
public class NumberChannelAllotDTO extends NumberChannel {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String phone;//号码id
    private String channelCode;//渠道id
    private List<Integer> ids;//分配记录表id List

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }
}
