package com.agent.number.entity;

import com.agent.common.BaseDomain;

/**
 * iccid变动记录表
 */
public class IccidRecord extends BaseDomain {
    /** 绑定 */
    public static final Integer OPT_TYPE_0 = 0;
    /** 解绑 */
    public static final Integer OPT_TYPE_1 = 1;
    /** 出库待用*/
    public static final Integer OPT_TYPE_2 = 2;
    /**
     * 
     */
    private static final long serialVersionUID = 712145921295151640L;
    private Integer phoneId ;//'号码id',
    private String phone ;// '号码',
    private Integer icId ;// 'ICCID表id',
    private String iccid ;//'ICCID',
    private String imsi ;// 'IMSI',
    private Integer optType ;// '操作类型：0-绑定，1-解绑,2-出库待用',
    private String remark ;// '备注',
    
    private String nickName;//操作人昵称
    
    public Integer getPhoneId() {
        return phoneId;
    }
    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public Integer getIcId() {
        return icId;
    }
    public void setIcId(Integer icId) {
        this.icId = icId;
    }
    public String getIccid() {
        return iccid;
    }
    public void setIccid(String iccid) {
        this.iccid = iccid;
    }
    public String getImsi() {
        return imsi;
    }
    public void setImsi(String imsi) {
        this.imsi = imsi;
    }
    public String getOptTypeStr() {
        if(null != optType){
            if(OPT_TYPE_0.intValue() == optType.intValue()){
                return "绑定";
            }else if(OPT_TYPE_1.intValue() == optType.intValue()){
                return "解绑";
            }else{
                return "出库待用";
            }
        }
        return "";
    }
    public Integer getOptType() {
        return optType;
    }
    public void setOptType(Integer optType) {
        this.optType = optType;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getNickName() {
        return nickName;
    }
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
}
