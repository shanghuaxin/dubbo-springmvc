package com.agent.number.dto;

import java.util.List;

import com.agent.common.RestStatus;

/**
 * Created by zw on 2015/8/25.
 */
public class PhoneMealDTO extends RestStatus {
    private List<MealDTO> addService;//增值业务
    private List<MealDTO> voicd;//语音业务
    private List<MealDTO> flows;//流量业务
    private MealDTO flow30;//0元30M
    private MealDTO giveVoicd;//酷话业务
    private String iccidCode;//iccid
    private Integer minFloat;//最低消费
    private Integer boosPrestore;//预存款
    private String mealName;//套餐名称
    private Integer mealMoney;//套餐金额
    private String certName;//用户名称
    private String balMoney;//余额

    public PhoneMealDTO(){}

    public PhoneMealDTO(Boolean status,String errorCode,String errorMessage){
        this.setStatus(status);
        this.setErrorCode(errorCode);
        this.setErrorMessage(errorMessage);
    }

    public List<MealDTO> getAddService() {
        return addService;
    }

    public void setAddService(List<MealDTO> addService) {
        this.addService = addService;
    }

    public List<MealDTO> getVoicd() {
        return voicd;
    }

    public void setVoicd(List<MealDTO> voicd) {
        this.voicd = voicd;
    }

    public List<MealDTO> getFlows() {
        return flows;
    }

    public void setFlows(List<MealDTO> flows) {
        this.flows = flows;
    }

    public MealDTO getFlow30() {
        return flow30;
    }

    public void setFlow30(MealDTO flow30) {
        this.flow30 = flow30;
    }

    public MealDTO getGiveVoicd() {
        return giveVoicd;
    }

    public void setGiveVoicd(MealDTO giveVoicd) {
        this.giveVoicd = giveVoicd;
    }

    public String getIccidCode() {
        return iccidCode;
    }

    public void setIccidCode(String iccidCode) {
        this.iccidCode = iccidCode;
    }

    public Integer getMinFloat() {
        return minFloat;
    }

    public void setMinFloat(Integer minFloat) {
        this.minFloat = minFloat;
    }

    public Integer getBoosPrestore() {
        return boosPrestore;
    }

    public void setBoosPrestore(Integer boosPrestore) {
        this.boosPrestore = boosPrestore;
    }

    public String getMealName() {
        return mealName;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }

    public Integer getMealMoney() {
        return mealMoney;
    }

    public void setMealMoney(Integer mealMoney) {
        this.mealMoney = mealMoney;
    }

    public String getCertName() {
        return certName;
    }

    public void setCertName(String certName) {
        this.certName = certName;
    }

    public String getBalMoney() {
        return balMoney;
    }

    public void setBalMoney(String balMoney) {
        this.balMoney = balMoney;
    }
}
