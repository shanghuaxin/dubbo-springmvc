package com.agent.number.entity;

import com.agent.common.BaseDomain;

/**
 * iccid池信息表
 */
public class IccidPool extends BaseDomain {
    //待上架
    public static final Integer IC_STATUS_0 = 0;
    //已上架
    public static final Integer IC_STATUS_1 = 1;
    //出库待用
    public static final Integer IC_STATUS_2 = 2;
    /**
     * 
     */
    private static final long serialVersionUID = 9143496443045835685L;
    private String iccid ;// 'ICCID',
    private String imsi ;// 'IMSI',
    private String area ;// '号段',
    private Integer icStatus;//状态：0-待上架，1-已上架，2-出库待用
    private Integer network;//网络：1-移动，2-联通，3-点血
    private Long instId;//源系统id
    private String puk1 ;
    private String puk2 ;
    private String pin1 ;
    private String pin2 ;
    
    public String getIccid() {
        return iccid;
    }
    public void setIccid(String iccid) {
        this.iccid = iccid;
    }
    public String getImsi() {
        return imsi;
    }
    public void setImsi(String imsi) {
        this.imsi = imsi;
    }
    public String getArea() {
        return area;
    }
    public void setArea(String area) {
        this.area = area;
    }
    public String getIcStatusStr() {
        if(null != icStatus){
            if(0 == icStatus.intValue()){
                return "待上架";
            }else if(1 == icStatus.intValue()){
                return "已上架";
            }else{
                return "出库待用";
            }
        }
        return "";
    }
    public Integer getIcStatus() {
        return icStatus;
    }
    public void setIcStatus(Integer icStatus) {
        this.icStatus = icStatus;
    }
    public String getNetworkStr() {
        if(null != network){
            if(1 == network.intValue()){
                return "移动";
            }else if(2 == network.intValue()){
                return "联通";
            }else{
                return "其他";
            }
        }
        return "";
    }
    public Integer getNetwork() {
        return network;
    }
    public void setNetwork(Integer network) {
        this.network = network;
    }
    public Long getInstId() {
        return instId;
    }
    public void setInstId(Long instId) {
        this.instId = instId;
    }
    public String getPuk1() {
        return puk1;
    }
    public void setPuk1(String puk1) {
        this.puk1 = puk1;
    }
    public String getPuk2() {
        return puk2;
    }
    public void setPuk2(String puk2) {
        this.puk2 = puk2;
    }
    public String getPin1() {
        return pin1;
    }
    public void setPin1(String pin1) {
        this.pin1 = pin1;
    }
    public String getPin2() {
        return pin2;
    }
    public void setPin2(String pin2) {
        this.pin2 = pin2;
    }
}
