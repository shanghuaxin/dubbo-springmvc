package com.agent.number.mapper;

import java.util.List;
import java.util.Map;

import com.agent.common.BaseMapper;
import com.agent.file.dto.PhoneImportDto;
import com.agent.number.entity.NumberChannel;

public interface NumberChannelMapper extends BaseMapper<NumberChannel, Integer> {
    public int batchInsert(List<NumberChannel> list);
    public int batchUpdateStatus2(List<String> numChIds);
    public int batchUpdateStatus1(List<String> numChIds);
    public int batchDelPidAndCid(List<String> numChIds);
    public int batchDelByPhoneId(List<Integer> numIds);

    //查询号码分配记录
    public List<PhoneImportDto> phoneAllotList(Map<String,Object> parment);
    
}
