package com.agent.number.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.agent.common.BaseDomain;

/**
 * 号码分配记录表
 */
public class NumberChannel extends BaseDomain {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    /* 待分配  ***/
    public static final Integer STATUS_1 = 1;
    /* 已分配  ***/
    public static final Integer STATUS_2 = 2;

    private Integer phoneId;//号码id
    private Integer channelId;//渠道id
    private Integer parChannelId;//父级渠道id  总部为0
    private Integer status;//状态 1-待分配，2-已分配
    private BigDecimal money;//金额
    private Integer channelIdLevel1;//分配一级id
    private Date createTimeLevel1;//分配一级时间
    private Integer channelIdLevel2;//分配二级id
    private Date createTimeLevel2;//分配二级时间


    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Integer getParChannelId() {
        return parChannelId;
    }

    public void setParChannelId(Integer parChannelId) {
        this.parChannelId = parChannelId;
    }

    public Integer getChannelIdLevel1() {
        return channelIdLevel1;
    }

    public void setChannelIdLevel1(Integer channelIdLevel1) {
        this.channelIdLevel1 = channelIdLevel1;
    }

    public Date getCreateTimeLevel1() {
        return createTimeLevel1;
    }

    public void setCreateTimeLevel1(Date createTimeLevel1) {
        this.createTimeLevel1 = createTimeLevel1;
    }

    public Integer getChannelIdLevel2() {
        return channelIdLevel2;
    }

    public void setChannelIdLevel2(Integer channelIdLevel2) {
        this.channelIdLevel2 = channelIdLevel2;
    }

    public Date getCreateTimeLevel2() {
        return createTimeLevel2;
    }

    public void setCreateTimeLevel2(Date createTimeLevel2) {
        this.createTimeLevel2 = createTimeLevel2;
    }
    
    
}
