package com.agent.product.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelProductService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.SessionData;
import com.agent.exception.SeeComException;
import com.agent.order.common.util.Utils;
import com.agent.product.dto.ChannelProductDto;
import com.agent.product.dto.ProductDto;
import com.agent.product.entity.Product;
import com.agent.product.entity.ProductDefBro;
import com.agent.product.service.ProductService;
import com.agent.system.entity.User;
import com.agent.system.service.CodeDictionaryService;

/**
 * 商品管理控制器
 * @author auto
 */
@Controller
@RequestMapping(value="product")
public class ProductController {
    private static Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Resource
    private ProductService proService;
    @Autowired
    private ChannelsService channelsService;
    @Resource
    private ChannelProductService cpService;
    @Autowired
    private CodeDictionaryService codeDictionaryService;

    /**
     * 进入COOL170商品管理页面
     * @param model
     * @return
     */
    @RequestMapping(value = "pro/cool/list", method = RequestMethod.GET)
    public String productCool170List(Model model) {
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("dicKey","PRO_TYPE");
        model.addAttribute("proType",codeDictionaryService.findChildByDickey(searchMap));
        return "/views/prod/cool/proList.jsp";
    }

    /**
     * 进入充值商品管理页面
     * @param model
     * @return
     */
    @RequestMapping(value = "pro/recharge/list", method = RequestMethod.GET)
    public String productRechargeList(Model model) {
        Map<String,Object> searchMap = new HashMap<String,Object>();
        searchMap.put("dicKey","PRO_TYPE");
        model.addAttribute("proType",codeDictionaryService.findChildByDickey(searchMap));
        return "/views/prod/recharge/proList.jsp";
    }

    /**
     * 查询商品列表
     * @return
     */
    @RequestMapping(value="pro/proList",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<Product> productList(DataTable<Product> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("productName", request.getParameter("productName"));
            searchMap.put("productType",request.getParameter("productType"));
            searchMap.put("productAttr",request.getParameter("productAttr"));
            searchMap.put("operator",request.getParameter("operator"));
            searchMap.put("category",request.getParameter("category"));
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return proService.productList(dt, searchMap);
        }catch(Exception e){
            logger.error("查看商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 查看商品详情
     * @param id
     * @return
     */
    @RequestMapping(value="pro/read/{id}",method=RequestMethod.POST)
    @ResponseBody
    public ProductDto read(@PathVariable String id){
        try{
            Product pro =  proService.findById(Integer.parseInt(id));
            ProductDto proDto = new ProductDto();
            BeanUtils.copyProperties(proDto, pro);

            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("dicKey", "PRO_TYPE");
            proDto.setProType(codeDictionaryService.findChildByDickey(searchMap));
            return proDto;
        }catch(Exception e){
            logger.error("查看商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 保存商品
     * @param product
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="pro/save", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> create(@Valid Product product,RedirectAttributes redirectAttributes,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Date dt = new Date();
            if(null == product.getId()){
                //新增
                product.setCreateId(us.getId());
                product.setCreateTime(dt);
            }
            product.setUpdateId(SessionData.getInstance().getUser(request).getId());
            product.setUpdateTime(dt);
            proService.saveProduct(product);
            //记录日志
            proService.saveProductLog(product,true,us);
            redirectAttributes.addFlashAttribute("message","保存商品成功");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("保存商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("保存商品失败，原因：" + e.getMessage(), e);
        }
        return map;
    }

    /**
     * Cool170关闭商品
     * @param productId
     * @return
     */
    @RequestMapping(value="pro/cool/close", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> coolClose(Integer productId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Product product = new Product();
            product.setId(productId);
            product.setUpdateId(us.getId());
            product.setUpdateTime(new Date());
            proService.closeProduct(product, us);
            logger.info("关闭商品成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("关闭商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("关闭商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 充值关闭商品
     * @param productId
     * @return
     */
    @RequestMapping(value="pro/recharge/close", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> rechargeClose(Integer productId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Product product = new Product();
            product.setId(productId);
            product.setUpdateId(us.getId());
            product.setUpdateTime(new Date());
            proService.closeProduct(product,us);
            logger.info("关闭商品成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("关闭商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("关闭商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * Cool170发布商品
     * @param productId
     * @return
     */
    @RequestMapping(value="pro/cool/release", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> coolRelease(Integer productId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Product product = new Product();
            product.setId(productId);
            product.setUpdateId(us.getId());
            product.setUpdateTime(new Date());
            proService.releaseProduct(product,us);
            logger.info("发布商品成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("发布商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("发布商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 充值发布商品
     * @param productId
     * @return
     */
    @RequestMapping(value="pro/recharge/release", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> rechargeRelease(Integer productId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Product product = new Product();
            product.setId(productId);
            product.setUpdateId(us.getId());
            product.setUpdateTime(new Date());
            proService.releaseProduct(product,us);
            logger.info("发布商品成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("发布商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("发布商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * Cool170进入商品分发页面
     * @param model
     * @return
     */
    @RequestMapping(value = "pro/cool/agentRelease", method = RequestMethod.GET)
    public String listChannelProsCool(@RequestParam("proId")Integer proId,Model model) {
        try{
            //获取商品
            Product pro = proService.findById(proId);
            model.addAttribute("proId",pro.getId());
            model.addAttribute("proName",pro.getProductName());
            //获取所有一级代理商
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("channelLevelEq", "1");
            List<Channels> channelsList = channelsService.listChannels(searchMap);
            model.addAttribute("channelsList",channelsList);
            model.addAttribute("proType","cool");
            model.addAttribute("proCategory",0);
            model.addAttribute("proTypeStr","商品管理COOL170业务");
            return "/views/prod/agentRelease.jsp";
        }catch(Exception e){
            logger.error("查看商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 充值进入商品分发页面
     * @param model
     * @return
     */
    @RequestMapping(value = "pro/recharge/agentRelease", method = RequestMethod.GET)
    public String listChannelProsRecharge(@RequestParam("proId")Integer proId,Model model) {
        try{
            //获取商品
            Product pro = proService.findById(proId);
            model.addAttribute("proId",pro.getId());
            model.addAttribute("proName",pro.getProductName());
            //获取所有一级代理商
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("channelLevelEq", "1");
            List<Channels> channelsList = channelsService.listChannels(searchMap);
            model.addAttribute("channelsList",channelsList);
            model.addAttribute("proType","recharge");
            model.addAttribute("proCategory",0);
            model.addAttribute("proTypeStr","商品管理充值业务");
            return "/views/prod/agentRelease.jsp";
        }catch(Exception e){
            logger.error("查看商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 设置商品可见性
     * @param model
     * @return
     */
    @RequestMapping(value = "pro/isShow", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> isShow(ChannelProductDto cpDto,Model model,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            cpService.proSave(cpDto,SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("设置商品可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("设置商品可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }
    


    /**
     * 批量设置商品可见性
     * @param model
     * @return
     */
    @RequestMapping(value = "batch/pro/isShow", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> batchIsShow(@RequestParam("chIds") String chIds, @RequestParam("isShow") Integer isShow, @RequestParam("proId") Integer proId, HttpServletRequest request) throws Exception {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            List<Integer> ids = Utils.listStrByint(chIds);
            ChannelProductDto cpDto = new ChannelProductDto();
            cpDto.setChannelIds(ids);
            cpDto.setIsShow(isShow);
            cpDto.setProId(proId);
            cpService.bacthProSave(cpDto,SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("设置商品可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("设置商品可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }
    

    /**
     * 查询商品分发列表
     * @return
     */
    @RequestMapping(value="pro/agentRelease",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<ChannelProductDto> listChannelPros(DataTable<ChannelProductDto> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("eqProId", request.getParameter("proId"));
            searchMap.put("channelId", request.getParameter("channelId"));
            searchMap.put("channelName", request.getParameter("channelName"));
            searchMap.put("channelLevel", "1");
            searchMap.put("proType","1" );//1 产品，2-套餐
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return cpService.listChannelPros(dt, searchMap);
        }catch(Exception e){
            logger.error("查看渠道商品授权失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 进入佣金设置页面
     * @param model
     * @return
     */
    @RequestMapping(value = "pro/brokerageUp", method = RequestMethod.GET)
    public String brokerageUp(@RequestParam("proId")Integer proId,@RequestParam("channelId")Integer channelId,@RequestParam("proCategory")Integer proCategory,Model model) {
        try{
            Product pro = proService.findById(proId);
            model.addAttribute("proType","cool");
            model.addAttribute("proTypeStr","商品管理COOL170业务");
            if(1 == pro.getCategory().intValue()){
                model.addAttribute("proType","recharge");
                model.addAttribute("proTypeStr","商品管理充值业务");
            }
            model.addAttribute("proId",proId);
            model.addAttribute("channelId",channelId);
            model.addAttribute("proCategory",proCategory);
            ProductDefBro defBor = proService.findProductDefBor(proId,channelId);
            model.addAttribute("defBor",defBor);
            return "/views/prod/rechargeUp.jsp";
        }catch(Exception e){
            logger.error("查看商品失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 佣金设置提交
     * @return
     */
    @RequestMapping(value = "pro/brokerageUp", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> brokerageUpSave(ProductDefBro pro,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            proService.brokerageUpSave(pro,SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("佣金设置失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("佣金设置失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }
    
    /**
     * 商品排序
     * @return
     */
    @RequestMapping(value = "pro/order", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> pacOrder(@RequestParam("proId")Integer proId,@RequestParam("isUp")String isUp,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            RestStatus r = proService.orderPro(proId,isUp,us);
            if(!r.getStatus()){
                map.put("status", false);
                map.put("msg", r.getErrorMessage());
            }
        }catch(Exception e){
            logger.error("设置商品排序失败，原因："+e.getMessage(),e);
            e.printStackTrace();
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
        }
        return map;
    }
}
