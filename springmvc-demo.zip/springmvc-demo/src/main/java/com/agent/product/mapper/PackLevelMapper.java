package com.agent.product.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.product.entity.PackLevel;

@Repository
public interface PackLevelMapper extends BaseMapper<PackLevel,Integer> {
    public int batchInsert(List<PackLevel> list);
    public int deleteByPacId(PackLevel pe);
    public List<PackLevel> packLevelList(Map<String, Object> obj);
}
