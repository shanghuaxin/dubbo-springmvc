package com.agent.product.entity;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;

import java.math.BigDecimal;
import java.util.List;

public class ProductDefBro extends BaseDomain {
    private static final long serialVersionUID = 8366879215377354186L;
    private Integer productId;
    private Integer channelId;
    private List<Integer> channelIds;
    private String channelStr;
    private String proType;        //商品类型：商品类型：1-产品，2-套餐
    private String servType;       //业务编码：201-语音，208-套餐低消，209-来电显示，202-短信，205-流量包，210-来电提醒，203-彩信，206-套餐月租，204-套外流量，101-国内流量，103-国内语音，102-国际流量，104-国际语音
    private BigDecimal channelBro1;//一级渠道佣金比例
    private BigDecimal channelBro2;//二级渠道佣金比例
    private BigDecimal channelBro3;//三级渠道佣金比例
    
    private BigDecimal channelBro4;//一级渠道佣金比例(170话费佣金使用)
    private BigDecimal channelBro5;//二级渠道佣金比例(170话费佣金使用)
    private BigDecimal channelBro6;//三级渠道佣金比例(170话费佣金使用)
    
    private BigDecimal channelBro7;//一级渠道佣金比例(联通流量充值佣金使用)
    private BigDecimal channelBro8;//二级渠道佣金比例(联通流量充值佣金使用)
    private BigDecimal channelBro9;//三级渠道佣金比例(联通流量充值佣金使用)
    
    private BigDecimal channelBro10;//一级渠道佣金比例(联通170话费佣金使用)
    private BigDecimal channelBro11;//二级渠道佣金比例(联通170话费佣金使用)
    private BigDecimal channelBro12;//三级渠道佣金比例(联通170话费佣金使用)
    
    //扩充字段
    private String cool1701;       //cool170 一级渠道商品佣金设置
    private String cool1702;       //cool170 二级渠道商品佣金设置
    private String cool1703;       //cool170 三级渠道商品佣金设置
    private String productCode; //商品编号
    private String productName; //商品编号
    private Integer proCategory;////产品类 别，0-cool170,1-充值
    private String servName; //业务名称
    private String packBro1; //一级佣金比例设置如：201=2,205=3
    private String packBro2; //二级佣金比例设置如：201=2,205=3
    private String packBro3; //三级佣金比例设置如：201=2,205=3

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType;
    }

    public String getServType() {
        return servType;
    }

    public void setServType(String servType) {
        this.servType = servType;
    }

    public BigDecimal getChannelBro1() {
        return channelBro1;
    }

    public void setChannelBro1(BigDecimal channelBro1) {
        this.channelBro1 = channelBro1;
    }

    public BigDecimal getChannelBro2() {
        return channelBro2;
    }

    public void setChannelBro2(BigDecimal channelBro2) {
        this.channelBro2 = channelBro2;
    }

    public BigDecimal getChannelBro3() {
        return channelBro3;
    }

    public void setChannelBro3(BigDecimal channelBro3) {
        this.channelBro3 = channelBro3;
    }

    public BigDecimal getChannelBro4() {
        return channelBro4;
    }

    public void setChannelBro4(BigDecimal channelBro4) {
        this.channelBro4 = channelBro4;
    }

    public BigDecimal getChannelBro5() {
        return channelBro5;
    }

    public void setChannelBro5(BigDecimal channelBro5) {
        this.channelBro5 = channelBro5;
    }

    public BigDecimal getChannelBro6() {
        return channelBro6;
    }

    public void setChannelBro6(BigDecimal channelBro6) {
        this.channelBro6 = channelBro6;
    }

    public BigDecimal getChannelBro7() {
        return channelBro7;
    }

    public void setChannelBro7(BigDecimal channelBro7) {
        this.channelBro7 = channelBro7;
    }

    public BigDecimal getChannelBro8() {
        return channelBro8;
    }

    public void setChannelBro8(BigDecimal channelBro8) {
        this.channelBro8 = channelBro8;
    }

    public BigDecimal getChannelBro9() {
        return channelBro9;
    }

    public void setChannelBro9(BigDecimal channelBro9) {
        this.channelBro9 = channelBro9;
    }

    public BigDecimal getChannelBro10() {
        return channelBro10;
    }

    public void setChannelBro10(BigDecimal channelBro10) {
        this.channelBro10 = channelBro10;
    }

    public BigDecimal getChannelBro11() {
        return channelBro11;
    }

    public void setChannelBro11(BigDecimal channelBro11) {
        this.channelBro11 = channelBro11;
    }

    public BigDecimal getChannelBro12() {
        return channelBro12;
    }

    public void setChannelBro12(BigDecimal channelBro12) {
        this.channelBro12 = channelBro12;
    }

    public String getChannelBro1Str() {
        if(null != channelBro1){
            if(channelBro1.intValue() > 0){
                return Constant.df00.format(channelBro1);
            }else if(channelBro1.intValue() < 0){
                return "0"+Constant.df0.format(channelBro1);
            }else{
                return "0.00";
            }
        }
        return "";
    }

    public String getChannelBro2Str() {
        if(null != channelBro2){
            if(channelBro2.intValue() > 0){
                return Constant.df00.format(channelBro2);
            }else if(channelBro2.intValue() < 0){
                return "0"+Constant.df0.format(channelBro2);
            }else{
                return "0.00";
            }
        }
        return "";
    }


    public String getChannelBro3Str() {
        if(null != channelBro3){
            if(channelBro3.intValue() > 0){
                return Constant.df00.format(channelBro3);
            }else if(channelBro3.intValue() < 0){
                return "0"+Constant.df0.format(channelBro3);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro4Str() {
        if(null != channelBro4){
            if(channelBro4.intValue() > 0){
                return Constant.df00.format(channelBro4);
            }else if(channelBro4.intValue() < 0){
                return "0"+Constant.df0.format(channelBro4);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro5Str() {
        if(null != channelBro5){
            if(channelBro5.intValue() > 0){
                return Constant.df00.format(channelBro5);
            }else if(channelBro5.intValue() < 0){
                return "0"+Constant.df0.format(channelBro5);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro6Str() {
        if(null != channelBro6){
            if(channelBro6.intValue() > 0){
                return Constant.df00.format(channelBro6);
            }else if(channelBro6.intValue() < 0){
                return "0"+Constant.df0.format(channelBro6);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro7Str() {
        if(null != channelBro7){
            if(channelBro7.intValue() > 0){
                return Constant.df00.format(channelBro7);
            }else if(channelBro7.intValue() < 0){
                return "0"+Constant.df0.format(channelBro7);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro8Str() {
        if(null != channelBro8){
            if(channelBro8.intValue() > 0){
                return Constant.df00.format(channelBro8);
            }else if(channelBro8.intValue() < 0){
                return "0"+Constant.df0.format(channelBro8);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro9Str() {
        if(null != channelBro9){
            if(channelBro9.intValue() > 0){
                return Constant.df00.format(channelBro9);
            }else if(channelBro9.intValue() < 0){
                return "0"+Constant.df0.format(channelBro9);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro10Str() {
        if(null != channelBro10){
            if(channelBro10.intValue() > 0){
                return Constant.df00.format(channelBro10);
            }else if(channelBro10.intValue() < 0){
                return "0"+Constant.df0.format(channelBro10);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro11Str() {
        if(null != channelBro11){
            if(channelBro11.intValue() > 0){
                return Constant.df00.format(channelBro11);
            }else if(channelBro11.intValue() < 0){
                return "0"+Constant.df0.format(channelBro11);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getChannelBro12Str() {
        if(null != channelBro12){
            if(channelBro12.intValue() > 0){
                return Constant.df00.format(channelBro12);
            }else if(channelBro12.intValue() < 0){
                return "0"+Constant.df0.format(channelBro12);
            }else{
                return "0.00";
            }
        }
        return "";
    }
    
    public String getCool1701() {
        return cool1701;
    }

    public void setCool1701(String cool1701) {
        this.cool1701 = cool1701;
    }

    public String getCool1702() {
        return cool1702;
    }

    public void setCool1702(String cool1702) {
        this.cool1702 = cool1702;
    }

    public String getCool1703() {
        return cool1703;
    }

    public void setCool1703(String cool1703) {
        this.cool1703 = cool1703;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getProCategory() {
        return proCategory;
    }

    public void setProCategory(Integer proCategory) {
        this.proCategory = proCategory;
    }

    public String getServName() {
        return servName;
    }

    public void setServName(String servName) {
        this.servName = servName;
    }

    public String getPackBro1() {
        return packBro1;
    }

    public void setPackBro1(String packBro1) {
        this.packBro1 = packBro1;
    }

    public String getPackBro2() {
        return packBro2;
    }

    public void setPackBro2(String packBro2) {
        this.packBro2 = packBro2;
    }

    public String getPackBro3() {
        return packBro3;
    }

    public void setPackBro3(String packBro3) {
        this.packBro3 = packBro3;
    }
    
    

    public List<Integer> getChannelIds() {
        return channelIds;
    }

    public void setChannelIds(List<Integer> channelIds) {
        this.channelIds = channelIds;
    }

    public String getChannelStr() {
        return channelStr;
    }

    public void setChannelStr(String channelStr) {
        this.channelStr = channelStr;
    }

    @Override
    public String toString() {
        return "ProductDefBor{" +
                "productId=" + productId +
                ", channelId=" + channelId +
                ", channelBro1=" + channelBro1 +
                ", channelBro2=" + channelBro2 +
                ", channelBro3=" + channelBro3 +
                ", cool1701='" + cool1701 + '\'' +
                ", cool1702='" + cool1702 + '\'' +
                ", cool1703='" + cool1703 + '\'' +
                ", productCode='" + productCode + '\'' +
                ", proCategory=" + proCategory +
                '}';
    }
}
