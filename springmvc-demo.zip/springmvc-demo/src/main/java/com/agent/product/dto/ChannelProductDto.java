package com.agent.product.dto;

import java.util.List;

/**
 * Created by Administrator on 2016/7/18.
 */
public class ChannelProductDto {
    private Integer id;
    private Integer channelId;//渠道id
    private List<Integer> channelIds;//渠道id  List
    private String channelCode;//渠道编号
    private String channelName;//渠道名称
    private String proType;//商品类型：商品类型：1-产品，2-套餐
    private String servType;//业务编码：201-语音，208-套餐低消，209-来电显示，202-短信，205-流量包，210-来电提醒，203-彩信，206-套餐月租，204-套外流量，101-国内流量，103-国内语音，102-国际流量，104-国际语音
    private Integer status;             //状态，1：正常，2：待审核，3：冻结开户，4：冻结
    private Integer isShow;        //是否可见，0：不可见，1：可见
    private Integer proId;//商品id
    private Integer broId;//默认佣金id
    private Integer proCategory;////产品类 别，0-cool170,1-充值
    private String proCode;//商品，套餐编号

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getStatusStr() {
        if(null != status){
            if(1 == status.intValue()){
                return "正常";
            }else  if(2 == status.intValue()){
                return "待审核";
            }else  if(3 == status.intValue()){
                return "冻结开户";
            }else  if(4 == status.intValue()){
                return "冻结";
            }
        }
        return "";
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getIsShowStr() {
        if(null != isShow){
            if(0 == isShow.intValue()){
                return "不可见";
            }else {
                return "可见";
            }
        }
        return "未设置";
    }

    public Integer getIsShow() {
        return isShow;
    }

    public void setIsShow(Integer isShow) {
        this.isShow = isShow;
    }

    public Integer getProId() {
        return proId;
    }

    public void setProId(Integer proId) {
        this.proId = proId;
    }

    public Integer getBroId() {
        return broId;
    }

    public void setBroId(Integer broId) {
        this.broId = broId;
    }

    public Integer getProCategory() {
        return proCategory;
    }

    public void setProCategory(Integer proCategory) {
        this.proCategory = proCategory;
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType;
    }

    public String getServType() {
        return servType;
    }

    public void setServType(String servType) {
        this.servType = servType;
    }

    public String getProCode() {
        return proCode;
    }

    public void setProCode(String proCode) {
        this.proCode = proCode;
    }
    
    

    public List<Integer> getChannelIds() {
        return channelIds;
    }

    public void setChannelIds(List<Integer> channelIds) {
        this.channelIds = channelIds;
    }

    @Override
    public String toString() {
        return "ChannelProductDto{" +
                "id=" + id +
                ", channelId=" + channelId +
                ", channelCode='" + channelCode + '\'' +
                ", channelName='" + channelName + '\'' +
                ", proType='" + proType + '\'' +
                ", servType='" + servType + '\'' +
                ", status=" + status +
                ", isShow=" + isShow +
                ", proId=" + proId +
                ", broId=" + broId +
                ", proCategory=" + proCategory +
                ", proCode=" + proCode +
                '}';
    }
}
