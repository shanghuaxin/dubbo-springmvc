package com.agent.product.entity;

import com.agent.common.BaseDomain;

/**
 * 套餐号码级别关系表
 * @author Administrator
 *
 */
public class PackLevel extends BaseDomain {
    /**
     * 
     */
    private static final long serialVersionUID = 1488196639206831426L;
    
    private Integer pacId;//套餐id
    private String pacName;//套餐名字
    private String pacCode;//套餐名字
    private String pacMoney;//套餐名字
    private String pacNotes;//套餐描述
    private Integer phoneLevel;//号码级别
    private Integer orderNum;//排序
    
    public Integer getPacId() {
        return pacId;
    }
    public void setPacId(Integer pacId) {
        this.pacId = pacId;
    }
    public String getPacName() {
        return pacName;
    }
    public void setPacName(String pacName) {
        this.pacName = pacName;
    }
    public String getPacCode() {
        return pacCode;
    }
    public void setPacCode(String pacCode) {
        this.pacCode = pacCode;
    }
    public String getPacMoney() {
        return pacMoney;
    }
    public void setPacMoney(String pacMoney) {
        this.pacMoney = pacMoney;
    }
    public String getPacNotes() {
        return pacNotes;
    }
    public void setPacNotes(String pacNotes) {
        this.pacNotes = pacNotes;
    }
    public Integer getPhoneLevel() {
        return phoneLevel;
    }
    public void setPhoneLevel(Integer phoneLevel) {
        this.phoneLevel = phoneLevel;
    }
    public Integer getOrderNum() {
        return orderNum;
    }
    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }
}
