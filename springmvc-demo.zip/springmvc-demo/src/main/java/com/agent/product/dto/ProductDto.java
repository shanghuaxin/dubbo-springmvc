package com.agent.product.dto;

import com.agent.product.entity.Product;
import com.agent.system.entity.CodeDictionary;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/8/12.
 */
public class ProductDto extends Product {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private List<CodeDictionary> proType = new ArrayList<CodeDictionary>(); //商品类型

    public List<CodeDictionary> getProType() {
        return proType;
    }

    public void setProType(List<CodeDictionary> proType) {
        this.proType = proType;
    }
}
