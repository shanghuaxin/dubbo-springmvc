package com.agent.product.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.agent.channel.entity.Channels;
import com.agent.channel.service.ChannelProductService;
import com.agent.channel.service.ChannelsService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.SessionData;
import com.agent.exception.SeeComException;
import com.agent.order.common.util.Utils;
import com.agent.product.dto.ChannelProductDto;
import com.agent.product.dto.PackagesDto;
import com.agent.product.entity.Packages;
import com.agent.product.entity.ProductDefBro;
import com.agent.product.service.PackagesService;
import com.agent.system.entity.User;
import com.agent.util.DicUtil;

/**
 * Created by Administrator on 2016/10/9.
 *  * 套餐管理控制器
 * @author auto
 */
@Controller
@RequestMapping(value="packages")
public class PackagesController {
    private static Logger logger = LoggerFactory.getLogger(PackagesController.class);
    @Resource
    private PackagesService pacService;
    @Resource
    private ChannelProductService cpService;
    @Autowired
    private ChannelsService channelsService;
    /**
     * 进入充值套餐管理页面
     * @param model
     * @return
     */
    @RequestMapping(value = "list", method = RequestMethod.GET)
    public String packagesList(Model model) {
        return "/views/packages/pacList.jsp";
    }

    /**
     * 查询套餐列表
     * @return
     */
    @RequestMapping(value="list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<PackagesDto> packagesList(DataTable<PackagesDto> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("network", request.getParameter("network"));
            searchMap.put("codeLike", Utils.isEmptyString(request.getParameter("codeLike")) ? "" : request.getParameter("codeLike"));
            searchMap.put("nameLike", Utils.isEmptyString(request.getParameter("nameLike")) ? "" : request.getParameter("nameLike"));
            searchMap.put("servType", Utils.isEmptyString(request.getParameter("servType")) ? "" : request.getParameter("servType"));
            searchMap.put("code", Utils.isEmptyString(request.getParameter("code")) ? "" : request.getParameter("code"));
            searchMap.put("servTypeNotEq", Utils.isEmptyString(request.getParameter("servTypeNotEq")) ? "" : request.getParameter("servTypeNotEq"));
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return pacService.packagesList(dt, searchMap);
        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 查询编号是否存在
     * @return
     */
    @RequestMapping(value="count_cnt",method=RequestMethod.POST)
    @ResponseBody
    public int packagesCodeCount(HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("servType", Utils.isEmptyString(request.getParameter("servType")) ? "" : request.getParameter("servType"));
            searchMap.put("code", Utils.isEmptyString(request.getParameter("code")) ? "" : request.getParameter("code"));
            searchMap.put("servTypeNotEq", Utils.isEmptyString(request.getParameter("servTypeNotEq")) ? "" : request.getParameter("servTypeNotEq"));
            searchMap.put("idNoEq", Utils.isEmptyString(request.getParameter("idNoEq")) ? "" : request.getParameter("idNoEq"));
            return pacService.packagesCodeCount(searchMap);
        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 进入充值套餐管增值业务理页面
     * @param model
     * @return
     */
    @RequestMapping(value = "list-low", method = RequestMethod.GET)
    public String packagesLowList(Model model) {
        return "/views/packages/pacLowList.jsp";
    }

    /**
     * 查询套餐增值业务列表
     * @return
     */
    @RequestMapping(value="list-low",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<PackagesDto> packagesLowList(DataTable<PackagesDto> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("servTypeNotEq", "0");
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return pacService.packagesList(dt, searchMap);
        }catch(Exception e){
            logger.error("查看套餐增值业务失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 查看套餐详情
     * @param id
     * @return
     */
    @RequestMapping(value="pacRead/{id}",method=RequestMethod.POST)
    @ResponseBody
    public PackagesDto pacRead(@PathVariable String id){
        try{
            return pacService.findPacInfo(id);
        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 查看套餐增值业务详情
     * @param id
     * @return
     */
    @RequestMapping(value="lowPacRead/{id}",method=RequestMethod.POST)
    @ResponseBody
    public PackagesDto lowPacRead(@PathVariable String id){
        try{
            PackagesDto pacDto = pacService.findLowServList();
            if(!Utils.isEmptyString(id) && !"0".equals(id)){ //有id才查询套餐信息
                PackagesDto findDto =  pacService.findById(Integer.parseInt(id));
                findDto.setFlowList(pacDto.getFlowList());
                findDto.setVoiceList(pacDto.getVoiceList());
                findDto.setRemindList(pacDto.getRemindList());
                findDto.setShowList(pacDto.getShowList());
                return findDto;
            }else{
                return pacDto;
            }

        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 进入套餐新增页面
     * @param model
     * @return
     */
    @RequestMapping(value = "pacSave", method = RequestMethod.GET)
    public String pacSave(Model model) {
        return "/views/packages/pacSave.jsp";
    }

    /**
     * 保存套餐
     * @param
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="pacSave", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> pacSave(@Valid PackagesDto dto,RedirectAttributes redirectAttributes,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            pacService.save(dto,us);
            redirectAttributes.addFlashAttribute("message","保存套餐成功");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("保存套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("保存套餐失败，原因：" + e.getMessage(), e);
        }
        return map;
    }

    /**
     * 发布套餐
     * @param pacId
     * @return
     */
    @RequestMapping(value="pac/release", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> pacRelease(Integer pacId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Packages pac = new Packages();
            pac.setId(pacId);
            pac.setUpdateId(us.getId());
            pac.setUpdateTime(new Date());
            pacService.releasePackages(pac, us);
            logger.info("发布套餐成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("发布套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("发布套餐失败，原因：" + e.getMessage(), e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 关闭套餐
     * @param pacId
     * @return
     */
    @RequestMapping(value="pac/close", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> pacClose(Integer pacId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            User us = SessionData.getInstance().getUser(request);
            Packages pac = new Packages();
            pac.setId(pacId);
            pac.setUpdateId(us.getId());
            pac.setUpdateTime(new Date());
            pacService.closePackages(pac, us);
            logger.info("关闭套餐成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("关闭失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("关闭套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }



    /**
     * 删除套餐
     * @param pacId
     * @return
     */
    @RequestMapping(value="delPac", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> delPac(Integer pacId,HttpServletRequest request){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            RestStatus res = pacService.delPac(pacId,SessionData.getInstance().getUser(request));
            if(!res.getStatus()){
                map.put("status", false);
                map.put("msg", res.getErrorMessage());
            }
            logger.info("删除套餐成功！");
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("删除套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("删除套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 充值进入套餐分发页面
     * @param model
     * @return
     */
    @RequestMapping(value = "agentRelease", method = RequestMethod.GET)
    public String listChannelProsRecharge(@RequestParam("pacId")Integer pacId,@RequestParam(value = "pageNum", required = false)Integer pageNum,Model model) {
        try{
            //获取套餐
            Packages pac = pacService.findById(pacId);
            model.addAttribute("pacId",pac.getId());
            model.addAttribute("pageNum",pageNum);
            model.addAttribute("pacName",pac.getName());
            //获取所有一级代理商
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("channelLevelEq", "1");
            List<Channels> channelsList = channelsService.listChannels(searchMap);
            model.addAttribute("channelsList",channelsList);
            return "/views/packages/agentRelease.jsp";
        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 查询商品分发列表
     * @return
     */
    @RequestMapping(value="agentRelease",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<ChannelProductDto> listChannelPros(DataTable<ChannelProductDto> dt, HttpServletRequest request){
        try{
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("eqProId", request.getParameter("pacId"));
            searchMap.put("channelId", request.getParameter("channelId"));
            searchMap.put("channelName", request.getParameter("channelName"));
            searchMap.put("channelLevel", "1");
            searchMap.put("proType","2" );//1 产品，2-套餐
            searchMap.put("limit",dt.getiDisplayStart());
            String pageNum= request.getParameter("pageNum");
            if(!Utils.isEmptyString(pageNum)){
                Integer pageNumInt = Integer.parseInt(pageNum);
                searchMap.put("limit",(pageNumInt-1)*dt.getiDisplayLength());
            }
            searchMap.put("pageSize",dt.getiDisplayLength());
            
            return cpService.listChannelPros(dt, searchMap);
        }catch(Exception e){
            logger.error("查看渠道商品授权失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 设置套餐可见性
     * @return
     */
    @RequestMapping(value = "pac/isShow", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> isShow(ChannelProductDto cpDto,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            cpService.pacSave(cpDto, SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("设置套餐可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("设置套餐可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }
    


    /**
     * 批量设置套餐可见性
     * @return
     */
    @RequestMapping(value = "batch/pac/isShow", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> batchIsShow(@RequestParam("chIds") String chIds, @RequestParam("isShow") Integer isShow, @RequestParam("proId") Integer proId, HttpServletRequest request) throws Exception {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            List<Integer> ids = Utils.listStrByint(chIds);
            ChannelProductDto cpDto = new ChannelProductDto();
            cpDto.setChannelIds(ids);
            cpDto.setIsShow(isShow);
            cpDto.setProId(proId);
            cpService.batchPacSave(cpDto, SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("设置套餐可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("设置套餐可见性失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 进入佣金设置页面
     * @param model
     * @return
     */
    @RequestMapping(value = "brokerageUp", method = RequestMethod.GET)
    public String brokerageUp(@RequestParam("pacId")Integer pacId,@RequestParam("channelIds")String channelIds,@RequestParam("type")String type,@RequestParam("pageNum")Integer pageNum,Model model) {
        try{
            Packages pac = pacService.findById(pacId);
            model.addAttribute("pacId",pac.getId());
            model.addAttribute("pacName",pac.getName());
            model.addAttribute("channelIds",channelIds);
            model.addAttribute("type",type);
            model.addAttribute("pageNum",pageNum);
            model.addAttribute("network",pac.getNetwork());
            return "/views/packages/rechargeUp.jsp";
        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 佣金设置查询
     * @param model
     * @return
     */
    @RequestMapping(value = "pacBroList", method = RequestMethod.POST)
    @ResponseBody
    public List<ProductDefBro> pacBroList(@RequestParam("pacId")Integer pacId,@RequestParam("channelId")Integer channelId,Model model) {
        try{
            List<ProductDefBro> bros = pacService.listPackagesDefBor(pacId, channelId);
            return bros;
        }catch(Exception e){
            logger.error("查看套餐失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
    /**
     * 佣金设置提交
     * @return
     */
    @RequestMapping(value = "pac/brokerageSave", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> brokerageUpSave(ProductDefBro pro,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "");
        try{
            if(Utils.isEmptyString(pro.getProductId()) || Utils.isEmptyString(pro.getChannelStr())){
                map.put("status", false);
                map.put("msg", "参数错误，请联系管理员");
                return map;
            }
            List<Integer> ids = null;
            if(pro.getChannelStr().indexOf(",") > -1){
                ids = Utils.listStrByint(pro.getChannelStr());
            }else{
                ids = new ArrayList<Integer>();
                ids.add(Integer.parseInt(pro.getChannelStr()));
            }
            if(ids.size() <1){
                map.put("status", false);
                map.put("msg", "请选择设置佣金渠道！");
                return map;
            }
            pro.setChannelIds(ids);
            pacService.batchBrokerageUpSave(pro,SessionData.getInstance().getUser(request));
        }catch(SeeComException e){
            map.put("status", false);
            map.put("msg", e.getMessage());
            logger.error("佣金设置失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "系统异常，请联系管理员！");
            logger.error("佣金设置失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 进入增值业务选择页面   互斥套餐
     * @param model
     * @return
     */
    @RequestMapping(value = "low-select-list", method = RequestMethod.GET)
    public String lowSelectList(Model model, HttpServletRequest request) {
        try{
            String servType =  request.getParameter("servType").toString();
            String network =  request.getParameter("network").toString();
            String pacId =  request.getParameter("pacId");
            String[] servTypesStr = servType.split(",");
            List<String> servTypes = new ArrayList<>();
            for(int i=0;i<servTypesStr.length;i++){
                servTypes.add(servTypesStr[i]);
            }
            if("101".equals(servType)){
                List<Packages> lowList = new ArrayList<Packages>();
                Map<String, String> map = DicUtil.getKeyNameMap("PHONE_LEVEL_CODE");
                if(map != null){
                    for(String s:map.keySet()){
                        Packages p = new Packages();
                        p.setId(Integer.valueOf(s));
                        p.setName(map.get(s));
                        lowList.add(p);
                    }
                }
                model.addAttribute("lowList",lowList);
            }else if("100".equals(servType)){
                //查询所有套餐，加载互斥套餐查询页面
                Map<String, Object> searchParams = new HashMap<String, Object>();
                searchParams.put("servType","0");
                searchParams.put("network",network);
                if(!Utils.isEmptyString(pacId)){
                    searchParams.put("idNoEq",pacId);
                }
                List<Packages> lowList = pacService.listPac(searchParams);
                model.addAttribute("lowList",lowList);
            }else{
                Map<String, Object> searchParams = new HashMap<String, Object>();
                searchParams.put("servTypeNotEq","0");
                searchParams.put("servTypes",servTypes);
                if(!Utils.isEmptyString(pacId)){
                    searchParams.put("idNoEq",pacId);
                }
                searchParams.put("network",network);
                List<Packages> lowList = pacService.listPac(searchParams);
                model.addAttribute("lowList",lowList);
            }
        }catch(Exception e){
            logger.error("进入增值业务选择页面失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return "/views/packages/lowSelectList.jsp";
    }
}