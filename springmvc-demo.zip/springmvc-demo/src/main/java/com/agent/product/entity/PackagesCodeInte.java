package com.agent.product.entity;

import java.io.Serializable;

/**
 * 增值业务编码对应接口表
 */
public class PackagesCodeInte implements Serializable {

    private static final long serialVersionUID = -2313445377552925101L;
    private Integer id;      //
    private String servCode;  //业务编号
    private String servname;  //业务名称
    private String servInte;  //调用接口
    private String inteType;  //调用接口类型：1-强制停机，2-强制复机，3-来电提醒/来电显示，4-呼叫号码设置，5-关闭上网功能，6-流量包管理，7-融合流量包管理
    private String memo;      //备注

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getServCode() {
        return servCode;
    }

    public void setServCode(String servCode) {
        this.servCode = servCode;
    }

    public String getServname() {
        return servname;
    }

    public void setServname(String servname) {
        this.servname = servname;
    }

    public String getServInte() {
        return servInte;
    }

    public void setServInte(String servInte) {
        this.servInte = servInte;
    }

    public String getInteType() {
        return inteType;
    }

    public void setInteType(String inteType) {
        this.inteType = inteType;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    @Override
    public String toString() {
        return "PackagesCodeInte [id=" + id + ", servCode=" + servCode + ", servname=" + servname + ", servInte="
                + servInte + ", inteType=" + inteType + ", memo=" + memo + "]";
    }

}
