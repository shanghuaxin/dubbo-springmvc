package com.agent.product.mapper;

import com.agent.common.BaseMapper;
import com.agent.product.entity.PackageBusiness;

public interface PackageBusinessMapper extends BaseMapper<PackageBusiness, Integer> {

}
