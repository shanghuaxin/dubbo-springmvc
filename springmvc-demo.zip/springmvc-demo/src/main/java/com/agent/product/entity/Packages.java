package com.agent.product.entity;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.agent.common.BaseDomain;
import com.agent.common.enumeration.ServiceType;
import com.agent.constant.Constant;
import com.agent.util.Utils;

/**
 * 套餐表
 * @author Administrator
 *
 */
public class Packages extends BaseDomain  implements Comparator<Packages>{

    private static final long serialVersionUID = 925445788244903214L;
    
    private String code;       //code
    private String newCode;    //新套餐编号（融合包专用）
    private String name;       //套餐名称
    private String network;    //归属网络：YD-移动，LT-联通
    private String packageNotes;    //套餐描述（开通的增值业务描述内容）
    private BigDecimal money;  //套餐金额：单位：分
    private BigDecimal lowConsume;   //套餐低消：单位：分
    private BigDecimal smsMoney;//短信价格
    private BigDecimal mmsMoney;//彩信价格
    private BigDecimal flowMoney;//流量价格
    private BigDecimal voiceMoney;//语音价格
    private String status;     //状态:0 关闭,1 待发布,2 已发布
    private String isGroup;     //是否已绑定组合套餐（boss测已绑定好的组合套餐）：1-是，0-否
    private String attr;     //套餐属性：多少分钟语音，多少M流量
    //业务类型:0 套餐  ,1 来电提醒，2 来电显示 ,3 语音业务 ,4流量业务 ,5组合业务，6-叠加包，7-通话语音包,
    //8-普通流量日包，9-自动续订流量日包，10-短信功能，11-呼转功能，12-上网功能,13-语音功能
    private String servType;   
    private String remark;//备注
    private String pacType;  //套餐类型：YD-移动，LTZYC-联通资源池，LTMZ-联通模组，LTMINIMZ-联通迷你模组     业务分类：PR-省内，CN-国内
    
    
    private List<Packages> fusionPackages;   //融合包
    private List<Packages> childPackages;    //自定义套餐
    private List<Packages> yuyinPackages;    //APP语音包
    private List<Packages> flowPackages;     //普通流量包
    private List<Packages> showPackages;     //来电显示
    private List<Packages> alertPackages;    //来电提醒
    
    private Map<String, List<Packages>> djFlowPackages;   //叠加流量包，月、季、半年
    
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNewCode() {
        return newCode;
    }

    public String getNewCodeStr() {
        if(Utils.isEmptyString(newCode)){
            return "";
        }
        return newCode;
    }

    public void setNewCode(String newCode) {
        this.newCode = newCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNetwork() {
        return network;
    }

    public Integer getNetworkInt() {
        if(StringUtils.equals(network, "YD")){
            return 1;
        }else if(StringUtils.equals(network, "LT")) {
            return 2;
        }
        return null;
    }

    public void setNetwork(String network) {
        this.network = network;
    }
    
    public String getNetworkStr() {
        if(StringUtils.equals(network, "YD")){
            return "移动";
        }else if(StringUtils.equals(network, "LT")) {
            return "联通";
        }
        return network;
    }

    public String getPackageNotes() {
        return packageNotes;
    }

    public void setPackageNotes(String packageNotes) {
        this.packageNotes = packageNotes;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public String getMoneyStr() {
        if(null != money){
            if(money.intValue() > 100){
                return Constant.df00.format(money.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(money.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public BigDecimal getLowConsume() {
        return lowConsume;
    }

    public String getLowConsumeStr0() {
        if(null != lowConsume){
            return String.valueOf(lowConsume.divide(Constant.cnt100));
        }
        return "";
    }

    public String getLowConsumeStr() {
        if(null != lowConsume){
            if(lowConsume.intValue() > 100){
                return Constant.df00.format(lowConsume.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(lowConsume.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setLowConsume(BigDecimal lowConsume) {
        this.lowConsume = lowConsume;
    }

    public String getStatusStr() {
        if(null != status){
            if("0".equals(status)){
                return "关闭";
            }else if("1".equals(status)){
                return "待发布";
            }else if("2".equals(status)){
                return "已发布";
            }
        }
        return "";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getServType() {
        return servType;
    }

    public String getServTypeStr() {
        if(!Utils.isEmptyString(servType)){
            return ServiceType.getName(servType);
        }
        return servType;
    }

    public void setServType(String servType) {
        this.servType = servType;
    }

    public String getSmsMoneyStr0() {
        if(null != smsMoney){
            return String.valueOf(smsMoney.divide(Constant.cnt100));
        }
        return "";
    }

    public BigDecimal getSmsMoney() {
        return smsMoney;
    }

    public String getSmsMoneyStr() {
        if(null != smsMoney){
            if(smsMoney.intValue() > 100){
                return Constant.df00.format(smsMoney.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(smsMoney.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setSmsMoney(BigDecimal smsMoney) {
        this.smsMoney = smsMoney;
    }

    public String getMmsMoneyStr0() {
        if(null != mmsMoney){
            return String.valueOf(mmsMoney.divide(Constant.cnt100));
        }
        return "";
    }

    public BigDecimal getMmsMoney() {
        return mmsMoney;
    }

    public String getMmsMoneyStr() {
        if(null != mmsMoney){
            if(mmsMoney.intValue() > 100){
                return Constant.df00.format(mmsMoney.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(mmsMoney.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setMmsMoney(BigDecimal mmsMoney) {
        this.mmsMoney = mmsMoney;
    }

    public String getFlowMoneyStr0() {
        if(null != flowMoney){
            return String.valueOf(flowMoney.divide(Constant.cnt100));
        }
        return "";
    }

    public BigDecimal getFlowMoney() {
        return flowMoney;
    }

    public String getFlowMoneyStr() {
        if(null != flowMoney){
            if(flowMoney.intValue() > 100){
                return Constant.df00.format(flowMoney.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(flowMoney.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setFlowMoney(BigDecimal flowMoney) {
        this.flowMoney = flowMoney;
    }

    public String getVoiceMoneyStr0() {
        if(null != voiceMoney){
            return String.valueOf(voiceMoney.divide(Constant.cnt100));
        }
        return "";
    }

    public BigDecimal getVoiceMoney() {
        return voiceMoney;
    }

    public String getVoiceMoneyStr() {
        if(null != voiceMoney){
            if(voiceMoney.intValue() > 100){
                return Constant.df00.format(voiceMoney.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(voiceMoney.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setVoiceMoney(BigDecimal voiceMoney) {
        this.voiceMoney = voiceMoney;
    }


    public String getAttrStr() {
        if(!Utils.isEmptyString(attr)){
            if("3".equals(servType) || "7".equals(servType)){
                return attr+"分钟";
            }else if("4".equals(servType) || "6".equals(servType) || "8".equals(servType) || "9".equals(servType)){
                return attr+"M";
            }else{
                return attr;
            }
        }
        return "";
    }
    public String getAttr() {
        return attr;
    }

    public void setAttr(String attr) {
        this.attr = attr;
    }

    public String getRemark() {
        return remark;
    }

    public String getRemarkStr() {
        if(Utils.isEmptyString(remark)){
            return "";
        }
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getIsGroup() {
        return isGroup;
    }

    public void setIsGroup(String isGroup) {
        this.isGroup = isGroup;
    }

    public List<Packages> getFusionPackages() {
        return fusionPackages;
    }

    public void setFusionPackages(List<Packages> fusionPackages) {
        this.fusionPackages = fusionPackages;
    }

    public List<Packages> getChildPackages() {
        return childPackages;
    }

    public void setChildPackages(List<Packages> childPackages) {
        this.childPackages = childPackages;
    }

    public List<Packages> getYuyinPackages() {
        return yuyinPackages;
    }

    public void setYuyinPackages(List<Packages> yuyinPackages) {
        this.yuyinPackages = yuyinPackages;
    }

    public List<Packages> getFlowPackages() {
        return flowPackages;
    }

    public void setFlowPackages(List<Packages> flowPackages) {
        this.flowPackages = flowPackages;
    }

    public List<Packages> getShowPackages() {
        return showPackages;
    }

    public void setShowPackages(List<Packages> showPackages) {
        this.showPackages = showPackages;
    }

    public List<Packages> getAlertPackages() {
        return alertPackages;
    }

    public void setAlertPackages(List<Packages> alertPackages) {
        this.alertPackages = alertPackages;
    }

    public Map<String, List<Packages>> getDjFlowPackages() {
        return djFlowPackages;
    }

    public void setDjFlowPackages(Map<String, List<Packages>> djFlowPackages) {
        this.djFlowPackages = djFlowPackages;
    }

    public String getPacType() {
        return pacType;
    }

    public void setPacType(String pacType) {
        this.pacType = pacType;
    }

    @Override
    public String toString() {
        return "{" +
                "编号='" + code +
                ", 新套餐编号='" + getNewCodeStr() +
                ", 名称='" + name +
                ", 金额(分)=" + getMoneyStr() +
                ", 套餐低消(分)=" + getLowConsumeStr() +
                ", 短信价格(分)=" + getSmsMoneyStr() +
                ", 短信价格(分)=" + getMmsMoneyStr() +
                ", 流量价格(分)=" + getFlowMoneyStr() +
                ", 语音价格(分)=" + getVoiceMoneyStr() +
                ", 状态='" + getStatusStr() +
                ", 套餐属性='" + getAttrStr() +
                ", 业务类型='" + getServTypeStr() +
                ", 备注='" + getRemarkStr() +
                '}';
    }
    @Override
    public int compare(Packages o2, Packages o1) {
        BigDecimal m1 = o1.money;
        BigDecimal m2 = o2.money;
        if(null == m1){
            m1 = new BigDecimal(0);
        }
        if(null == m2){
            m2 = new BigDecimal(0);
        }
        //0 表示相等,返回 1 表示金额1>金额2,返回 -1 表示金额1<金额2
        if(m1.intValue() == m2.intValue()){
            return 0;
        }else if(m1.intValue() > m2.intValue()){
            return -1;
        }else{
            return 1;
        }
    }
}
