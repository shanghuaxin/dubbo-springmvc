package com.agent.product.entity;

import com.agent.common.BaseDomain;

/**
 * 套餐互斥表
 * @author Administrator
 *
 */
public class PackExclude extends BaseDomain {
    /**
     * 
     */
    private static final long serialVersionUID = 4539298319399280769L;
    
    private Integer pacId;//套餐id
    private Integer excludeId;//排斥套餐id
    public Integer getPacId() {
        return pacId;
    }
    public void setPacId(Integer pacId) {
        this.pacId = pacId;
    }
    public Integer getExcludeId() {
        return excludeId;
    }
    public void setExcludeId(Integer excludeId) {
        this.excludeId = excludeId;
    }
    
    @Override
    public String toString() {
        return "PackExclude [pacId=" + pacId + ", excludeId=" + excludeId + "]";
    }
}
