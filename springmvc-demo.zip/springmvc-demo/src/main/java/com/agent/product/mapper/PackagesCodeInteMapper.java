package com.agent.product.mapper;

import java.util.List;

import com.agent.common.BaseMapper;
import com.agent.product.entity.PackagesCodeInte;

public interface PackagesCodeInteMapper extends BaseMapper<PackagesCodeInte, Integer> {
    
    public List<PackagesCodeInte> findAll();

}
