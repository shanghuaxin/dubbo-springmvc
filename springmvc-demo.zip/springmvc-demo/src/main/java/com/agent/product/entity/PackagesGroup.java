package com.agent.product.entity;

/**
 * 套餐子业务关系表
 * @author Administrator
 *
 */
public class PackagesGroup{

    private int packagesId;       //code
    private int lowerId;    //新套餐编号（融合包专用）

    public int getPackagesId() {
        return packagesId;
    }

    public void setPackagesId(int packagesId) {
        this.packagesId = packagesId;
    }

    public int getLowerId() {
        return lowerId;
    }

    public void setLowerId(int lowerId) {
        this.lowerId = lowerId;
    }
}
