package com.agent.product.entity;

import java.math.BigDecimal;

import com.agent.common.BaseDomain;
import com.agent.constant.Constant;
import com.agent.util.Utils;

public class Product extends BaseDomain {

    private static final long serialVersionUID = -5948385429219153222L;
    private Integer category; //商品类别 0-cool170商品，1-充值商品
    private String productType;//商品类型，1：运营商流量，2：运营商语音，3：COOL170实体卡密，4：COOL170虚拟卡密
    private String productCode;//商品编码
    private String productName;//商品名称
    private BigDecimal marketPrice;//商品价格 单位：分--没用
    private BigDecimal salePrice;  //出售价格 单位：分
    private BigDecimal costPrice;  //成本价 单位：分
    private Integer productAttr;//使用时长 ，产品附加属性1 年卡2 月卡3 体验卡
    private Integer status; //状态0-关闭,1-待发布,2-已发布
    private String productDesc;//商品描述
    private String supplier;//供应商
    private String operator;//运营商:移动，联通，电信
    private Integer isRed;//是否支持红包：0-不支持，1-支持
    private BigDecimal redMoney;//红包抵扣金额
    private String variety;//种类规格:如20M,2000min
    private Integer ranges;//范围：1-全国，2-本地，3-国际
    private Integer orderNum;//排序
    private String groupCode;//分组编号
    private String isDefault;//是否默认：1-否，2-默认
    
    private String productTypeStr;
    private String productAttrStr;
    
    private BigDecimal channelBro1;     //一级渠道佣金比例
    private BigDecimal channelBro2;     //二级渠道佣金比例
    private BigDecimal channelBro3;     //三级渠道佣金比例
    
    private Integer maxOrder=0;//最大排序
    private Integer minOrder=0;//最小排序

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getMarketPrice() {
        return marketPrice;
    }

    public String getMarketPriceStr0() {
        if(null != marketPrice){
            return String.valueOf(marketPrice.divide(Constant.cnt100));
        }
        return "";
    }
    public String getMarketPriceStr() {
        if(null != marketPrice){
            if (marketPrice.intValue() >= 100) {
                return Constant.df00.format(marketPrice.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(marketPrice.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public void setMarketPrice(BigDecimal marketPrice) {
        this.marketPrice = marketPrice;
    }

    public String getSalePriceStr0() {
        if(null != salePrice){
            return String.valueOf(salePrice.divide(Constant.cnt100));
        }
        return "";
    }

    public String getSalePriceStr() {
        if(null != salePrice){
            if (salePrice.intValue() >= 100) {
                return Constant.df00.format(salePrice.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(salePrice.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public String getCostPriceStr0() {
        if(null != costPrice){
            return String.valueOf(costPrice.divide(Constant.cnt100));
        }
        return "";
    }

    public String getCostPriceStr() {
        if(null != costPrice){
            if (costPrice.intValue() >= 100){
                return Constant.df00.format(costPrice.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(costPrice.divide(Constant.cnt100));
            }

        }
        return "0.00";
    }

    public BigDecimal getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(BigDecimal costPrice) {
        this.costPrice = costPrice;
    }

    public Integer getProductAttr() {
        return productAttr;
    }

    public void setProductAttr(Integer productAttr) {
        this.productAttr = productAttr;
    }

    public String getStatusStr() {
        if(null != status){
            if(0 == status.intValue()){
                return "关闭";
            }else if(1 == status.intValue()){
                return "待发布";
            }else if(2 == status.intValue()){
                return "已发布";
            }
        }
        return "";
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public String getProductDescStr() {
        if(Utils.isEmptyString(productDesc)){
            return "";
        }
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public Integer getIsRed() {
        return isRed;
    }

    public String getIsRedStr() {
        if(null != isRed){
            if(0 == isRed.intValue()){
                return "不支持";
            }else{
                return "支持";
            }
        }
        return "";
    }

    public void setIsRed(Integer isRed) {
        this.isRed = isRed;
    }

    public String getRedMoneyStr0() {
        if(null != redMoney){
            return String.valueOf(redMoney.divide(Constant.cnt100));
        }
        return "";
    }

    public String getRedMoneyStr() {
        if(null != redMoney){
            if (redMoney.intValue() >= 100) {
                return Constant.df00.format(redMoney.divide(Constant.cnt100));
            } else {
                return Constant.df0.format(redMoney.divide(Constant.cnt100));
            }
        }
        return "0.00";
    }

    public BigDecimal getRedMoney() {
        return redMoney;
    }

    public void setRedMoney(BigDecimal redMoney) {
        this.redMoney = redMoney;
    }

    public String getProductTypeStr() {
        return productTypeStr;
    }

    public void setProductTypeStr(String productTypeStr) {
        this.productTypeStr = productTypeStr;
    }

    public String getProductAttrStr() {
        return productAttrStr;
    }

    public void setProductAttrStr(String productAttrStr) {
        this.productAttrStr = productAttrStr;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getRangeStr() {
        if(null != ranges){
            if(1 == ranges.intValue()){
                return "全国";
            }else if(2 == ranges.intValue()){
                return "本地";
            }else if(3 == ranges.intValue()){
                return "国际";
            }
        }
        return "";
    }

    public Integer getRanges() {
        return ranges;
    }

    public void setRanges(Integer ranges) {
        this.ranges = ranges;
    }

    public BigDecimal getChannelBro1() {
        return channelBro1;
    }

    public void setChannelBro1(BigDecimal channelBro1) {
        this.channelBro1 = channelBro1;
    }

    public BigDecimal getChannelBro2() {
        return channelBro2;
    }

    public void setChannelBro2(BigDecimal channelBro2) {
        this.channelBro2 = channelBro2;
    }

    public BigDecimal getChannelBro3() {
        return channelBro3;
    }

    public void setChannelBro3(BigDecimal channelBro3) {
        this.channelBro3 = channelBro3;
    }

    public String getChannelBro1Str() {
        if(null != channelBro1){
            if (channelBro1.intValue() >= 100) {
                return Constant.df00.format(channelBro1);
            } else {
                return Constant.df0.format(channelBro1);
            }
        }
        return "0.00";
    }

    public String getChannelBro2Str() {
        if(null != channelBro2){
            if(channelBro2.intValue() >= 100){
                return Constant.df00.format(channelBro2);
            } else {
                return Constant.df0.format(channelBro2);
            }
        }
        return "0.00";
    }

    public String getChannelBro3Str() {
        if(null != channelBro3){
            if (channelBro3.intValue() >= 100) {
                return Constant.df00.format(channelBro3);
            } else {
                return Constant.df0.format(channelBro3);
            }
        }
        return "0.00";
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
    
    

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }
    
    

    public Integer getMaxOrder() {
        return maxOrder;
    }

    public void setMaxOrder(Integer maxOrder) {
        this.maxOrder = maxOrder;
    }

    public Integer getMinOrder() {
        return minOrder;
    }

    public void setMinOrder(Integer minOrder) {
        this.minOrder = minOrder;
    }
    
    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    @Override
    public String toString() {
        return "商品信息{" +
                ", 商品类型='" + productType + '\'' +
                ", 商品编号='" + productCode + '\'' +
                ", 商品名称='" + productName + '\'' +
                ", 商品价格=" + getMarketPriceStr0() +
                ", 售价=" + getSalePriceStr0() +
                ", 成本=" +  getCostPriceStr0() +
                ", 时长=" + productAttr +
                ", 状态=" + getStatusStr() +
                ", 备注='" + getProductDescStr() + '\'' +
                ", 供应商='" + supplier + '\'' +
                ", 是否支持红包=" + getIsRedStr() +
                ", 红包抵扣金额=" + redMoney +
                ", 种类='" + variety + '\'' +
                ", 范围=" + ranges +
                ", 排序=" + orderNum +
                '}';
    }
}
