package com.agent.product.entity;

import java.io.Serializable;

/**
 * 套餐业务关系表（主要用于170佣金设置）
 */
public class PackageBusiness implements Serializable {

    private static final long serialVersionUID = 6418741107074025580L;
    private Integer id;      //id
    private String businessType;   //业务类型
    private String businessName;   //类型名称
    private int sort;        //排序

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    @Override
    public String toString() {
        return "PackageBusiness [id=" + id + ", businessType=" + businessType + ", businessName=" + businessName
                + ", sort=" + sort + "]";
    }

}
