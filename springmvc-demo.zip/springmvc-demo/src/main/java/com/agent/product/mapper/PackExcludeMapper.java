package com.agent.product.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.product.entity.PackExclude;

@Repository
public interface PackExcludeMapper extends BaseMapper<PackExclude,Integer> {
    public int batchInsert(List<PackExclude> list);
    public int deleteByPacId(PackExclude pe);
}
