package com.agent.product.dto;

import com.agent.product.entity.Packages;
import com.agent.system.dto.SimpleDic;

import java.util.List;

/**
 * Created by Administrator on 2016/8/12.
 */
public class PackagesDto extends Packages {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    //增值业务用参数
    private String voice;//语音包id
    private String flow;//流量包id
    private String ldShow;//来电显示id
    private String remind;//来电提醒id
    private List<SimpleDic> voiceList; //增值业务-语音包
    private List<SimpleDic> flowList; //增值业务-流量包
    private List<SimpleDic> showList; //增值业务-来电显示
    private List<SimpleDic> remindList; //增值业务-来电提醒  1 来电提醒，2 来电显示 ,3 语音业务 ,4流量业务 ,5组合业务，6月包，7季包，8半年包

    //套餐用参数
    private List<PackagesDto> voiceListPac;//套餐-语音包
    private List<PackagesDto> flowListPac;//套餐-流量包
    private List<PackagesDto> lowListPac;//套餐-来显/来电
    private List<PackagesDto> groupListPac;//套餐-组合包
    private List<PackagesDto> addFlowListPac;//套餐-叠加流量包
    private List<PackagesDto> voiceListServ;//套餐-语音包
    private List<PackagesDto> dayFlowServ;//套餐-普通日包
    private List<PackagesDto> dayFlowKeepOnServ;//套餐-自动续订日包
    private List<PackagesDto> excludeServ;//互斥套餐
    private List<PackagesDto> phoneLevel;//号码级别
    private List<PackagesDto> smsServ;//短信功能
    private List<PackagesDto> hzServ;//呼转功能
    private List<PackagesDto> flowServ;//上网功能
    private List<PackagesDto> voiceServ;//语音功能
    private String isChecked;//是否选中  checked-选中 其他未选中
    private String isDisabled;//是否可以进行选择
    private String lowIds;//子业务id，逗号隔开id  1，2，2
    private String lowName;//子业务名称，逗号隔开id  1，2，2
    private String excludeIds;//互斥套餐id，逗号隔开id  1，2，2
    private String phoneLevelIds;//号码级别编号，逗号隔开id  1，2，2
    private Integer orderNum;//开户套餐变更排序

    public List<SimpleDic> getVoiceList() {
        return voiceList;
    }

    public void setVoiceList(List<SimpleDic> voiceList) {
        this.voiceList = voiceList;
    }

    public List<SimpleDic> getFlowList() {
        return flowList;
    }

    public void setFlowList(List<SimpleDic> flowList) {
        this.flowList = flowList;
    }

    public List<SimpleDic> getShowList() {
        return showList;
    }

    public void setShowList(List<SimpleDic> showList) {
        this.showList = showList;
    }

    public List<SimpleDic> getRemindList() {
        return remindList;
    }

    public void setRemindList(List<SimpleDic> remindList) {
        this.remindList = remindList;
    }

    public String getVoice() {
        return voice;
    }

    public void setVoice(String voice) {
        this.voice = voice;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public String getLdShow() {
        return ldShow;
    }

    public void setLdShow(String ldShow) {
        this.ldShow = ldShow;
    }

    public String getRemind() {
        return remind;
    }

    public void setRemind(String remind) {
        this.remind = remind;
    }

    public List<PackagesDto> getVoiceListPac() {
        return voiceListPac;
    }

    public void setVoiceListPac(List<PackagesDto> voiceListPac) {
        this.voiceListPac = voiceListPac;
    }

    public List<PackagesDto> getFlowListPac() {
        return flowListPac;
    }

    public void setFlowListPac(List<PackagesDto> flowListPac) {
        this.flowListPac = flowListPac;
    }

    public List<PackagesDto> getLowListPac() {
        return lowListPac;
    }

    public void setLowListPac(List<PackagesDto> lowListPac) {
        this.lowListPac = lowListPac;
    }

    public List<PackagesDto> getGroupListPac() {
        return groupListPac;
    }

    public void setGroupListPac(List<PackagesDto> groupListPac) {
        this.groupListPac = groupListPac;
    }

    public List<PackagesDto> getAddFlowListPac() {
        return addFlowListPac;
    }

    public void setAddFlowListPac(List<PackagesDto> addFlowListPac) {
        this.addFlowListPac = addFlowListPac;
    }

    public String getIsChecked() {
        return isChecked;
    }

    public void setIsChecked(String isChecked) {
        this.isChecked = isChecked;
    }

    public String getLowIds() {
        return lowIds;
    }

    public void setLowIds(String lowIds) {
        this.lowIds = lowIds;
    }

    public String getLowName() {
        return lowName;
    }

    public void setLowName(String lowName) {
        this.lowName = lowName;
    }

    public String getIsDisabled() {
        return isDisabled;
    }

    public void setIsDisabled(String isDisabled) {
        this.isDisabled = isDisabled;
    }

    public List<PackagesDto> getVoiceListServ() {
        return voiceListServ;
    }

    public void setVoiceListServ(List<PackagesDto> voiceListServ) {
        this.voiceListServ = voiceListServ;
    }

    public List<PackagesDto> getDayFlowServ() {
        return dayFlowServ;
    }

    public void setDayFlowServ(List<PackagesDto> dayFlowServ) {
        this.dayFlowServ = dayFlowServ;
    }

    public List<PackagesDto> getDayFlowKeepOnServ() {
        return dayFlowKeepOnServ;
    }

    public void setDayFlowKeepOnServ(List<PackagesDto> dayFlowKeepOnServ) {
        this.dayFlowKeepOnServ = dayFlowKeepOnServ;
    }

    public String getExcludeIds() {
        return excludeIds;
    }

    public void setExcludeIds(String excludeIds) {
        this.excludeIds = excludeIds;
    }

    public List<PackagesDto> getExcludeServ() {
        return excludeServ;
    }

    public void setExcludeServ(List<PackagesDto> excludeServ) {
        this.excludeServ = excludeServ;
    }

    public String getPhoneLevelIds() {
        return phoneLevelIds;
    }

    public void setPhoneLevelIds(String phoneLevelIds) {
        this.phoneLevelIds = phoneLevelIds;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public List<PackagesDto> getPhoneLevel() {
        return phoneLevel;
    }

    public void setPhoneLevel(List<PackagesDto> phoneLevel) {
        this.phoneLevel = phoneLevel;
    }

    public List<PackagesDto> getSmsServ() {
        return smsServ;
    }

    public void setSmsServ(List<PackagesDto> smsServ) {
        this.smsServ = smsServ;
    }

    public List<PackagesDto> getHzServ() {
        return hzServ;
    }

    public void setHzServ(List<PackagesDto> hzServ) {
        this.hzServ = hzServ;
    }

    public List<PackagesDto> getFlowServ() {
        return flowServ;
    }

    public void setFlowServ(List<PackagesDto> flowServ) {
        this.flowServ = flowServ;
    }

    public List<PackagesDto> getVoiceServ() {
        return voiceServ;
    }

    public void setVoiceServ(List<PackagesDto> voiceServ) {
        this.voiceServ = voiceServ;
    }
}
