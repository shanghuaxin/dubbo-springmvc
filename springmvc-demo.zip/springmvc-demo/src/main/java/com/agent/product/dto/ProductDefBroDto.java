package com.agent.product.dto;

import java.math.BigDecimal;

/**
 * Created by Administrator on 2016/10/12.
 */
public class ProductDefBroDto {
    private String servType;       //业务编码：201-语音，208-套餐低消，209-来电显示，202-短信，205-流量包，210-来电提醒，203-彩信，206-套餐月租，204-套外流量，101-国内流量，103-国内语音，102-国际流量，104-国际语音
    private BigDecimal channelBro1;//一级渠道佣金比例
    private BigDecimal channelBro2;//二级渠道佣金比例
    private BigDecimal channelBro3;//三级渠道佣金比例

    public String getServType() {
        return servType;
    }

    public void setServType(String servType) {
        this.servType = servType;
    }

    public BigDecimal getChannelBro1() {
        return channelBro1;
    }

    public void setChannelBro1(BigDecimal channelBro1) {
        this.channelBro1 = channelBro1;
    }

    public BigDecimal getChannelBro2() {
        return channelBro2;
    }

    public void setChannelBro2(BigDecimal channelBro2) {
        this.channelBro2 = channelBro2;
    }

    public BigDecimal getChannelBro3() {
        return channelBro3;
    }

    public void setChannelBro3(BigDecimal channelBro3) {
        this.channelBro3 = channelBro3;
    }
}
