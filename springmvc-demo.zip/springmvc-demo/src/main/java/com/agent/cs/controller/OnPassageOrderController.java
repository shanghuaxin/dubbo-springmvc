package com.agent.cs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.agent.online.dto.BizDTO;
import com.agent.online.service.BizService;

/**
 * 在途工单控制器
 * @author FengLu
 *
 */
@Controller
@RequestMapping("onpassage")
public class OnPassageOrderController {
    private static Logger logger = LoggerFactory.getLogger(OnPassageOrderController.class);
    
    @Autowired
    public BizService bizService;
    
    @RequestMapping("list")
    public String list(HttpServletRequest request, HttpServletResponse response, String phone, Integer status) {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            if (StringUtils.isNotEmpty(phone)) {
                map.put("phone", phone);
            }
            if (null != status) {
                map.put("status", status);
            }
            List<BizDTO> bizList = bizService.queryByPhone(map);
            request.setAttribute("bizList", bizList);
            request.setAttribute("status", status);
            request.setAttribute("phone", phone);
        } catch (Exception e) {
            logger.error("在途工单查询异常："+e.getMessage(), e);
        }
        return "/views/cs/onpassage/list.jsp";
    }
}
