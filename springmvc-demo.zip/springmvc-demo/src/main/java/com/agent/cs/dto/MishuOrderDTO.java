package com.agent.cs.dto;

/**
 * 漏电提醒类工单实体
 * @author FengLu
 *
 */
public class MishuOrderDTO extends OrderBaseDTO {
    
}
