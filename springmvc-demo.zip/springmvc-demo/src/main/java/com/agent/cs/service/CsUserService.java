package com.agent.cs.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.business.entity.MobileArea;
import com.agent.business.mapper.MobileAreaMapper;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.CommonService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.BossPhoneStatus;
import com.agent.common.enumeration.OrderNOEnum;
import com.agent.common.enumeration.StatusType;
import com.agent.cs.dto.CsReqPropertyDTO;
import com.agent.cs.dto.CsServHandDTO;
import com.agent.cs.dto.CsServHandVoDTO;
import com.agent.cs.dto.CsUserListDTO;
import com.agent.cs.dto.ReqCommonDTO;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.entity.Biz;
import com.agent.online.mapper.BizMapper;
import com.agent.openaccount.dto.BuyServRecordListDTO;
import com.agent.openaccount.entity.BuyServiceRecord;
import com.agent.openaccount.mapper.BuyServiceRecordMapper;
import com.agent.order.common.util.Utils;
import com.agent.product.entity.Packages;
import com.agent.product.mapper.PackagesMapper;
import com.agent.system.entity.User;
import com.agent.util.DateUtil;
import com.agent.util.DicUtil;

import namespace.webservice.crmsps.ContractRoot;
import namespace.webservice.crmsps.OfferWithStatus;
import namespace.webservice.crmsps.QueryUser;
import zsmart.ztesoft.com.xsd.TQueryUserProfile4BaseBOResponse;
import zsmart.ztesoft.com.xsd.TQueryUserProfileRequestBO;
import zsmart.ztesoft.com.xsd.TUserServiceQryRequest;
import zsmart.ztesoft.com.xsd.TUserServiceQryResponse;

@Service
@Transactional(rollbackFor=Exception.class)
public class CsUserService {
    private static Logger logger = LoggerFactory.getLogger(CsUserService.class);
    @Autowired
    private BOSSNewBuyService bossNewBuyService;
    @Autowired
    private BOSSUnicomService bOSSUnicomService;
    @Resource
    private PackagesMapper pacMapper;
    @Autowired
    private BuyServiceRecordMapper buyServiceRecordMapper;
    @Autowired
    private MobileAreaMapper mobileAreaMapper;
    @Autowired
    private BizMapper bizMapper;
  
    /**
     * 查询客服管理用户信息列表
     * @param dt
     * @return
     */
    @SuppressWarnings("unchecked")
    public DataTable<CsUserListDTO> userList(DataTable<CsUserListDTO> dt,User user,ReqCommonDTO dto) throws Exception{
        List<CsUserListDTO> listDto = new ArrayList<>();
        RestStatus rs = CommonService.common(dto, "cs/user/user-list", "查询用户信息", user);
        if(!rs.getStatus()){
            logger.error("客服查询用户信息失败，号码："+dto.getPhone()+",error="+rs.getErrorMessage());
        }else{
            listDto = (List<CsUserListDTO>)rs.getResponseData();
        }
        dt.setAaData(listDto);
        dt.setiTotalDisplayRecords(listDto.size());
        return dt;
    }
    
    /**
     * 移动查询可办理业务
     * @param phone
     * @return
     * @throws Exception
     */
    public RestStatus mobileServHand(String phone,User user) throws Exception{
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","查询可办理业务");
        CsServHandDTO handDto = new CsServHandDTO();
        handDto.getPack().setOptType("210");
        TQueryUserProfileRequestBO bo = new TQueryUserProfileRequestBO();
        bo.setMSISDN("86"+phone);
        RestStatus rs = bossNewBuyService.QueryUserProfileBOSS(bo, user);
        BigDecimal userBal; //用户余额
        String packCode = "";//套餐编号
        if(rs.getStatus()){
            TQueryUserProfile4BaseBOResponse res = (TQueryUserProfile4BaseBOResponse) rs.getResponseData();
            if(BossPhoneStatus.REPORT_LOSS.getValue().equals(res.getStateSet())){
                handDto.getLoss().setOptType("502");//挂失可解挂
            }else {
                handDto.getLoss().setOptType("501");
            }
            if(BossPhoneStatus.FORCED_STOP.getValue().equals(res.getStateSet())){
                handDto.getStop().setOptType("402");//强停状态可强开
            }else {
                handDto.getStop().setOptType("401");
            } 
            if(!BossPhoneStatus.REPORT_LOSS.getValue().equals(res.getStateSet()) &&
                    !BossPhoneStatus.FORCED_STOP.getValue().equals(res.getStateSet()) &&
                    !"A".equals(res.getState())){
                return new RestStatus(Boolean.FALSE,"500","号码："+phone+"当前状态为："+DicUtil.getMapDictionary("BOSS_STATUS").get(res.getState()) + "，不可订购业务");
            }
            userBal = new BigDecimal(res.getBal());
            handDto.setBal(userBal);
            packCode = res.getSubsPlanCode();
            handDto.getPack().setServCode(packCode);
        }else{
            return rs;
        }
        //当前用户订购套餐下所有子业务
        Map<String, Packages> lowMap = lowMap(packCode,handDto);
        //查询接口用户订购业务
        TUserServiceQryRequest qry = new TUserServiceQryRequest();
        qry.setMSISDN("86"+phone);
        RestStatus qryRs = bossNewBuyService.UserServiceQry(qry,user);
        if(qryRs.getStatus()){
            TUserServiceQryResponse res = (TUserServiceQryResponse) qryRs.getResponseData();
            if(null != res.getOrderedServiceList() && res.getOrderedServiceList().getService().size() >0){
                for(int i=0;i< res.getOrderedServiceList().getService().size();i++){
                    if(StringUtils.equals(res.getOrderedServiceList().getService().get(i).getServiceState(), "A")) {
                        String serviceCode = res.getOrderedServiceList().getService().get(i).getServiceCode();
                        if(lowMap.containsKey(serviceCode)){
                            Date effDate = DateUtil.getInstance().parseDate(res.getOrderedServiceList().getService().get(i).getServiceEffDate(), DateUtil.yyyy_MM_dd_HH_mm_ss);
                            if(null != effDate && DateUtil.getInstance().compareDate(effDate, new Date()) == 1){//未生效
                                //移动只有基础流量包变更才会有待生效
                                handDto.getServFlow().setOptType("230");
                            }
                            //移动只有  基础流量包，来显，来提  直接判断
                            if("4".equals(lowMap.get(serviceCode).getServType()) && !"230".equals(handDto.getServFlow().getOptType())){
                                //流量包没有待生效业务才可以被操作
                                handDto.getServFlow().setOptType("210");
                                handDto.getServFlow().setServCode(serviceCode);
                                handDto.getServFlow().setServId(lowMap.get(serviceCode).getId());
                                handDto.getServFlow().setServName(lowMap.get(serviceCode).getName());
                            }else if("1".equals(lowMap.get(serviceCode).getServType())){
                                handDto.getServCall().setOptType("310");
                                handDto.getServCall().setServCode(serviceCode);
                                handDto.getServCall().setServId(lowMap.get(serviceCode).getId());
                                handDto.getServCall().setServName(lowMap.get(serviceCode).getName());
                            }else if("2".equals(lowMap.get(serviceCode).getServType())){
                                handDto.getServShow().setOptType("310");
                                handDto.getServShow().setServCode(serviceCode);
                                handDto.getServShow().setServId(lowMap.get(serviceCode).getId());
                                handDto.getServShow().setServName(lowMap.get(serviceCode).getName());
                            }
                        }
                    }
                }
            }
        }else{
            return qryRs;
        }
        if(StringUtils.isEmpty(handDto.getServFlow().getOptType())){//没有可操作流量包
            handDto.getServFlow().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getServCall().getOptType())){//没有可操作来电提醒
            handDto.getServCall().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getServShow().getOptType())){//没有可操作来电显示
            handDto.getServShow().setOptType("110");
        }
        handDto(handDto,phone);
        
        restStatus.setResponseData(handDto);
        return restStatus; 
    }

    /**
     * 联通查询可办理业务
     * @param phone
     * @return
     * @throws Exception
     */
    public RestStatus unicomServHand(String phone,User user) throws Exception{
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","查询可办理业务");
        CsServHandDTO handDto = new CsServHandDTO();
        handDto.getPack().setOptType("210");
        QueryUser cd = new QueryUser();
        cd.setQueryValue(phone);
        cd.setQueryType("0");
        cd.setProductId("-1");
        cd.setCityCode("360");
        RestStatus  rs = bOSSUnicomService.queryUserService(cd,user);
        String packCode = "";
        if(rs.getStatus()){
            ContractRoot cr = (ContractRoot)rs.getResponseData();
            if("129996".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                handDto.getStop().setOptType("402");//强停状态可强开
            }else {
                handDto.getStop().setOptType("401");
            } 
            if(BossPhoneStatus.UNICOM_LOSS.getValue().equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                handDto.getLoss().setOptType("502");//挂失可解挂
            }else {
                handDto.getLoss().setOptType("501");
            }
            if(!"129996".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus()) && 
                    !BossPhoneStatus.UNICOM_LOSS.getValue().equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus()) && 
                    !"109999".equals(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus())){
                return new RestStatus(Boolean.FALSE, "1004", "号码："+phone+"当前状态为："+BossPhoneStatus.getName(cr.getSvcCont().getUserInfoView().getUserInfo().getServingStatus()) + "，不可订购业务");
            }
            packCode = cr.getSvcCont().getUserInfoView().getUserInfo().getProdOfferId();
            handDto.getPack().setServCode(packCode);
        }
        //当前用户订购套餐下所有子业务
        Map<String, Packages> lowMap = lowMap(packCode,handDto);
        //有效和预约销售品信息查询
        OfferWithStatus svcCont = new OfferWithStatus();
        svcCont.setAccNbr(phone);
        svcCont.setProductId("-1");
        svcCont.setCityCode("360");
        svcCont.setReserveStatus("1");
        RestStatus ows = bOSSUnicomService.offerWithStatus(svcCont,user);
        if(!ows.getStatus()){
            return ows;
        }
        ContractRoot crt = (ContractRoot)ows.getResponseData();
        if(null != crt.getSvcCont().getProdOfferList() && crt.getSvcCont().getProdOfferList().size() >0){
            for(int i=0;i< crt.getSvcCont().getProdOfferList().size();i++){
                if("1000".equals(crt.getSvcCont().getProdOfferList().get(i).getStatusCd())
                        && !"1".equals(crt.getSvcCont().getProdOfferList().get(i).getOfferTypeName())){//状态正常，并且非主套餐
                    String serviceCode = crt.getSvcCont().getProdOfferList().get(i).getProdOfferId();
                    if(lowMap.containsKey(serviceCode)){
                        String serviceEffDate = crt.getSvcCont().getProdOfferList().get(i).getEffDate();
                        Date effDate = DateUtil.getInstance().parseDate(serviceEffDate, DateUtil.yyyyMMddHHmmss);
                        if(null != effDate && DateUtil.getInstance().compareDate(effDate, new Date()) == 1){//未生效
                            if(lowMap.get(serviceCode) != null){
                                if("4".equals(lowMap.get(serviceCode).getServType())){//流量包待生效
                                    handDto.getServFlow().setOptType("230");
                                }else if("7".equals(lowMap.get(serviceCode).getServType())){//基础语音包待生效
                                    handDto.getServVoice().setOptType("230");
                                }else if("9".equals(lowMap.get(serviceCode).getServType())){//自动续订日包待生效
                                    handDto.getKeeyOnFlow().setOptType("230");
                                }
                            }
                        }
                        if("4".equals(lowMap.get(serviceCode).getServType()) && !"230".equals(handDto.getServFlow().getOptType())){
                            //流量包没有待生效业务才可以被操作
                            handDto.getServFlow().setOptType("210");
                            handDto.getServFlow().setServCode(serviceCode);
                            handDto.getServFlow().setServId(lowMap.get(serviceCode).getId());
                            handDto.getServFlow().setServName(lowMap.get(serviceCode).getName());
                        }else if("7".equals(lowMap.get(serviceCode).getServType()) && !"230".equals(handDto.getServVoice().getOptType())){
                            //基础语音包没有待生效业务才可以被操作
                            handDto.getServVoice().setOptType("210");
                            handDto.getServVoice().setServCode(serviceCode);
                            handDto.getServVoice().setServId(lowMap.get(serviceCode).getId());
                            handDto.getServVoice().setServName(lowMap.get(serviceCode).getName());
                        }else if("9".equals(lowMap.get(serviceCode).getServType()) && !"230".equals(handDto.getKeeyOnFlow().getOptType())){
                            //续订日包没有待生效业务才可以被操作
                            handDto.getKeeyOnFlow().setOptType("210");
                            handDto.getKeeyOnFlow().setServCode(serviceCode);
                            handDto.getKeeyOnFlow().setServId(lowMap.get(serviceCode).getId());
                            handDto.getKeeyOnFlow().setServName(lowMap.get(serviceCode).getName());
                        }else if("1".equals(lowMap.get(serviceCode).getServType())){
                            //来显来电没有待生效
                            handDto.getServCall().setOptType("310");
                            handDto.getServCall().setServCode(serviceCode);
                            handDto.getServCall().setServId(lowMap.get(serviceCode).getId());
                            handDto.getServCall().setServName(lowMap.get(serviceCode).getName());
                        }else if("2".equals(lowMap.get(serviceCode).getServType())){
                            handDto.getServShow().setOptType("310");
                            handDto.getServShow().setServCode(serviceCode);
                            handDto.getServShow().setServId(lowMap.get(serviceCode).getId());
                            handDto.getServShow().setServName(lowMap.get(serviceCode).getName());
                        }else if("10".equals(lowMap.get(serviceCode).getServType())  && !"603".equals(handDto.getSmsServ().getOptType())){
                            handDto.getSmsServ().setOptType("602");
                            handDto.getSmsServ().setServCode(serviceCode);
                            handDto.getSmsServ().setServId(lowMap.get(serviceCode).getId());
                            handDto.getSmsServ().setServName(lowMap.get(serviceCode).getName());
                        }else if("11".equals(lowMap.get(serviceCode).getServType())){
                            handDto.getHzServ().setOptType("602");
                            handDto.getHzServ().setServCode(serviceCode);
                            handDto.getHzServ().setServId(lowMap.get(serviceCode).getId());
                            handDto.getHzServ().setServName(lowMap.get(serviceCode).getName());
                        }else if("12".equals(lowMap.get(serviceCode).getServType())){
                            handDto.getFlowServ().setOptType("602");
                            handDto.getFlowServ().setServCode(serviceCode);
                            handDto.getFlowServ().setServId(lowMap.get(serviceCode).getId());
                            handDto.getFlowServ().setServName(lowMap.get(serviceCode).getName());
                        }
                    }
                }
            }
        }
        
        if(StringUtils.isEmpty(handDto.getServFlow().getOptType())){//没有可操作流量包
            handDto.getServFlow().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getServCall().getOptType())){//没有可操作来电提醒
            handDto.getServCall().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getServShow().getOptType())){//没有可操作来电显示
            handDto.getServShow().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getKeeyOnFlow().getOptType())){//没有可操作续订日包
            handDto.getKeeyOnFlow().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getServVoice().getOptType())){//没有可操作基础语音包
            handDto.getServVoice().setOptType("110");
        }
        if(StringUtils.isEmpty(handDto.getSmsServ().getOptType())){//没有短信功能
            handDto.getHzServ().setOptType("601");
        }
        if(StringUtils.isEmpty(handDto.getHzServ().getOptType())){//没有无条件呼叫转移功能
            handDto.getHzServ().setOptType("601");
        }
        if(StringUtils.isEmpty(handDto.getFlowServ().getOptType())){//没有上网功能
            handDto.getFlowServ().setOptType("601");
        }
        handDto.getServDayFlow().setOptType("110");
        handDto.getServAppendFlow().setOptType("110");
        handDto(handDto,phone);
        restStatus.setResponseData(handDto);
        return restStatus; 
    }
    
    /**
     * 获取可操作业务
     * @param handDto
     * @param phone
     * @throws Exception
     */
    private void handDto(CsServHandDTO handDto,String phone) throws Exception{
        //当月办理所有业务
        Map<String, Object> searchMap = new HashMap<>();
        List<String> statusIn = new ArrayList<>();
        statusIn.add("0");
        statusIn.add("1");
        statusIn.add("4");
        statusIn.add("5");
        searchMap.put("statusList", statusIn);
        searchMap.put("startdate", DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM)+"-01");
        searchMap.put("phone", phone);
        searchMap.put("nowsType","2");
        List<BuyServRecordListDTO> dtolist = buyServiceRecordMapper.listDto(searchMap);
        Map<String,BuyServRecordListDTO> orderMap = new HashMap<>();//订购业务对象
        Map<String,BuyServRecordListDTO> modMap = new HashMap<>();//变更业务对象
        Map<String,BuyServRecordListDTO> blackMap = new HashMap<>();//退订业务对象
        
        searchMap = new HashMap<>();
        searchMap.put("statusList", statusIn);
        searchMap.put("phone", phone);
        searchMap.put("nowsType","2");
        searchMap.put("servType",1);
        searchMap.put("limit",0);
        searchMap.put("pageSize",1);
        List<BuyServRecordListDTO> lt = buyServiceRecordMapper.listDto(searchMap);//漏电提醒
        
        searchMap = new HashMap<>();
        searchMap.put("statusList", statusIn);
        searchMap.put("phone", phone);
        searchMap.put("nowsType","2");
        searchMap.put("servType",2);
        searchMap.put("limit",0);
        searchMap.put("pageSize",1);
        List<BuyServRecordListDTO> lx = buyServiceRecordMapper.listDto(searchMap);//来显
        
        searchMap = new HashMap<>();
        searchMap.put("statusList", statusIn);
        searchMap.put("phone", phone);
        searchMap.put("nowsType","2");
        searchMap.put("servType",9);
        searchMap.put("limit",0);
        searchMap.put("pageSize",1);
        List<BuyServRecordListDTO> keepOnFlow = buyServiceRecordMapper.listDto(searchMap);//自动续订日包
        
        //呼转功能和上网功能特殊处理   10分以内有操作
        Date jstDate = DateUtil.getInstance().minusDateMinute(10);
        searchMap = new HashMap<>();
        searchMap.put("status", 1);
        searchMap.put("statusNo", "4");
        searchMap.put("begindate", DateUtil.getInstance().formatDate(jstDate, DateUtil.yyyy_MM_dd_HH_mm_ss));
        searchMap.put("phone", phone);
        List<Biz> bizlist= bizMapper.list(searchMap);
        Map<String, Biz> justMap = new HashMap<>();
        if(bizlist != null && bizlist.size() >0){
            for(Biz b:bizlist){
                justMap.put(b.getServCode(), b);
            }
        }
        
        if(null != dtolist && dtolist.size() >0){
            for(BuyServRecordListDTO d:dtolist){
                //操作类型：0-订购，1-取消，2-变更
                if("0".equals(d.getOptType())){
                    orderMap.put(d.getServType(), d);
                }else if("1".equals(d.getOptType())){
                    blackMap.put(d.getServType(), d);
                }else if("2".equals(d.getOptType())){
                    modMap.put(d.getServType(), d);
                }
                if("14".equals(d.getBuyType())){//套餐变更
                    if("1".equals(d.getStatus())){
                        handDto.getPack().setOptType("220");
                        handDto.getPack().setOrderNo(d.getOrderNo());
                    }else if("0".equals(d.getStatus())){
                        handDto.getPack().setOptType("230");
                    }
                }
            }
            if(!"230".equals(handDto.getServFlow().getOptType())){//流量包没有待生效业务，正常时候
                if(modMap.containsKey("4")){//变更流量
                    if("1".equals(modMap.get("4").getStatus())){//流量包变更未推送
                        handDto.getServFlow().setOptType("220");
                        handDto.getServFlow().setOrderNo(modMap.get("4").getOrderNo());
                    }else if("0".equals(modMap.get("4").getStatus())){//流量包变更已推送
                        handDto.getServFlow().setOptType("230");
                    }
                }else if(blackMap.containsKey("4")){//退订流量
                    if("1".equals(blackMap.get("4").getStatus())){//流量包退订未推送
                        handDto.getServFlow().setOptType("320");
                        handDto.getServFlow().setOrderNo(blackMap.get("4").getOrderNo());
                    }else if("0".equals(blackMap.get("4").getStatus())){//流量包退订已推送
                        handDto.getServFlow().setOptType("330");
                    }
                }else if(orderMap.containsKey("4")){//订购流量
                    if("1".equals(orderMap.get("4").getStatus())){//流量包订购未推送
                        handDto.getServFlow().setOptType("120");
                        handDto.getServFlow().setOrderNo(orderMap.get("4").getOrderNo());
                    }else if("0".equals(orderMap.get("4").getStatus())){//流量包订购已推送  并且次月生效
                        if("2".equals(orderMap.get("4").getValidType()) ||"3".equals(orderMap.get("4").getBizStatus()))
                        handDto.getServFlow().setOptType("130");
                    }
                }
            }
            
            if(!"230".equals(handDto.getServCall().getOptType())){//来电提醒没有待生效业务，正常时候
                if(null != lt && lt.size() >0){
                    if(BuyServiceRecord.opt_type_0.equals(lt.get(0).getOptType())){
                        if("1".equals(lt.get(0).getStatus())){//来电提醒订购未推送
                            handDto.getServCall().setOptType("120");
                        }else if("0".equals(lt.get(0).getStatus())){//来电提醒订购已推送  并且次月生效
                            if("2".equals(lt.get(0).getValidType()) || "3".equals(lt.get(0).getBizStatus())){
                                handDto.getServCall().setOptType("130");
                            }
                        }
                    }else if(BuyServiceRecord.opt_type_1.equals(lt.get(0).getOptType())){
                        if("1".equals(lt.get(0).getStatus())){//来电提醒退订未推送
                            handDto.getServCall().setOptType("320");
                            handDto.getServCall().setOrderNo(lt.get(0).getOrderNo());
                        }else if("0".equals(lt.get(0).getStatus())){//来电提醒退订已推送
                            if("2".equals(lt.get(0).getValidType()) || "3".equals(lt.get(0).getBizStatus())){
                                handDto.getServCall().setOptType("330");
                            }
                        }
                    }
                }
            }
            
            if(!"230".equals(handDto.getServShow().getOptType())){//来电显示没有待生效业务，正常时候
                if(null != lx && lx.size() >0){
                    if(BuyServiceRecord.opt_type_0.equals(lx.get(0).getOptType())){
                        if("1".equals(lx.get(0).getStatus())){//来电显示订购未推送
                            handDto.getServShow().setOptType("120");
                        }else if("0".equals(lx.get(0).getStatus())){//来电显示订购已推送  并且次月生效
                            if("2".equals(lx.get(0).getValidType()) || "3".equals(lx.get(0).getBizStatus())){
                                handDto.getServShow().setOptType("130");
                            }
                        }
                    }else if(BuyServiceRecord.opt_type_1.equals(lx.get(0).getOptType())){
                        if("1".equals(lx.get(0).getStatus())){//来电显示退订未推送
                            handDto.getServShow().setOptType("320");
                            handDto.getServShow().setOrderNo(lx.get(0).getOrderNo());
                        }else if("0".equals(lx.get(0).getStatus())){//来电显示退订已推送
                            if("2".equals(lx.get(0).getValidType()) || "3".equals(lx.get(0).getBizStatus())){
                                handDto.getServShow().setOptType("330");
                            }
                        }
                    }
                }
            }
            
            if(orderMap.containsKey("8") && "1".equals(orderMap.get("8").getStatus())){//订购普通日包并且未推送
                handDto.getServDayFlow().setServCode(orderMap.get("8").getNewServCode());
            }

            if(!"230".equals(handDto.getServVoice().getOptType())){//基础语音包没有待生效业务，正常时候
                if(modMap.containsKey("7")){//变更基础语音包
                    if("1".equals(modMap.get("7").getStatus())){//基础语音包变更未推送
                        handDto.getServVoice().setOptType("220");
                        handDto.getServVoice().setOrderNo(modMap.get("7").getOrderNo());
                    }else if("0".equals(modMap.get("7").getStatus())){//基础语音包变更已推送
                        handDto.getServVoice().setOptType("230");
                    }
                }else if(blackMap.containsKey("7")){//退订基础语音包
                    if("1".equals(blackMap.get("7").getStatus())){//基础语音包退订未推送
                        handDto.getServVoice().setOptType("320");
                        handDto.getServVoice().setOrderNo(blackMap.get("7").getOrderNo());
                    }else if("0".equals(blackMap.get("7").getStatus())){//基础语音包退订已推送
                        handDto.getServVoice().setOptType("330");
                    }
                }else if(orderMap.containsKey("7")){//订购基础语音包
                    if("1".equals(orderMap.get("7").getStatus())){//基础语音包订购未推送
                        handDto.getServVoice().setOptType("120");
                        handDto.getServVoice().setOrderNo(orderMap.get("7").getOrderNo());
                    }else if("0".equals(orderMap.get("7").getStatus())){//基础语音包订购已推送  并且次月生效
                        if("2".equals(orderMap.get("7").getValidType()) || "3".equals(orderMap.get("7").getBizStatus())){//或推送未报竣
                            handDto.getServVoice().setOptType("130");
                        }
                    }
                }
            }
            String newDateStr = DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd);//当天时间
            if(!"230".equals(handDto.getKeeyOnFlow().getOptType())){//续订日包没有待生效业务，正常时候
                if(null != keepOnFlow && keepOnFlow.size() >0){
                    if(BuyServiceRecord.opt_type_1.equals(keepOnFlow.get(0).getOptType())){
                        String dateStr = DateUtil.getInstance().formatDate(keepOnFlow.get(0).getCreateTime(), DateUtil.yyyy_MM_dd);
                        if("2".equals(keepOnFlow.get(0).getBizOptType())){  //续订日包变更为：退订和订购
                            if("1".equals(keepOnFlow.get(0).getStatus()) && "1".equals(keepOnFlow.get(0).getStatus())){//续订日包变更未推送
                                handDto.getKeeyOnFlow().setOptType("220");
                                handDto.getKeeyOnFlow().setOrderNo(keepOnFlow.get(0).getOrderNo());
                            }else if(newDateStr.equals(dateStr)){//续订日包变更已推送 并且是当天内
                                handDto.getKeeyOnFlow().setOptType("230");
                            }
                        }else{
                            if("1".equals(keepOnFlow.get(0).getStatus())){//续订日包退订未推送
                                handDto.getKeeyOnFlow().setOptType("320");
                                handDto.getKeeyOnFlow().setOrderNo(keepOnFlow.get(0).getOrderNo());
                            }else if("0".equals(keepOnFlow.get(0).getStatus()) && newDateStr.equals(dateStr)){//续订日包退订已推送
                                handDto.getKeeyOnFlow().setOptType("330");
                            }
                        }
                    }else if(BuyServiceRecord.opt_type_0.equals(keepOnFlow.get(0).getOptType())){
                        String dateStr = DateUtil.getInstance().formatDate(keepOnFlow.get(0).getCreateTime(), DateUtil.yyyy_MM_dd);
                        if("2".equals(keepOnFlow.get(0).getBizOptType())){  //续订日包变更为：退订和订购
                            if("1".equals(keepOnFlow.get(0).getStatus()) && "1".equals(keepOnFlow.get(0).getStatus())){//续订日包变更未推送
                                handDto.getKeeyOnFlow().setOptType("220");
                                handDto.getKeeyOnFlow().setOrderNo(keepOnFlow.get(0).getOrderNo());
                            }else if(newDateStr.equals(dateStr)){//续订日包变更已推送 并且是当天内
                                handDto.getKeeyOnFlow().setOptType("230");
                            }
                        }else{
                            if("1".equals(keepOnFlow.get(0).getStatus()) || "3".equals(keepOnFlow.get(0).getBizStatus())){//续订日包订购未推送或推送未报竣
                                handDto.getKeeyOnFlow().setOptType("120");
                            }
                        }
                    }
                }
            }
        }
        //挂失解挂
        searchMap = new HashMap<>();
        searchMap.put("bizType",BizType.LOST_OR_RESTORE.getCode());
        searchMap.put("phone", phone);
        searchMap.put("status", StatusType.SUCCESS.getCode());
        searchMap.put("limit", 0);
        searchMap.put("pageSize", 1);
        List<Biz> bizs = bizMapper.list(searchMap);
        if(null != bizs && bizs.size() >0){
            if(!"502".equals(handDto.getLoss().getOptType())){  //正常状态
                if("1".equals(bizs.get(0).getOperationType())){//已提交挂失 并且正常状态   状态还未更新时
                    handDto.getLoss().setOptType("503");
                }
            }else{
                if("0".equals(bizs.get(0).getOperationType())){
                    handDto.getLoss().setOptType("504");//已提交解挂 并且正常状态   状态还未更新时
                }
            }
        }
        //强停强开
        searchMap = new HashMap<>();
        List<String> bizTypes = new ArrayList<>();
        bizTypes.add(BizType.BLOCK_OPEN_CLOSE.getCode());
        searchMap.put("bizTypes", bizTypes);
        searchMap.put("phone", phone);
        searchMap.put("status", StatusType.SUCCESS.getCode());
        searchMap.put("limit", 0);
        searchMap.put("pageSize", 1);
        bizs = bizMapper.list(searchMap);
        if(null != bizs && bizs.size() >0){
            if(!"402".equals(handDto.getStop().getOptType())){  //正常状态
                if(BizType.BLOCK_OPEN_CLOSE.getCode().equals(bizs.get(0).getBizType()) && "1".equals(bizs.get(0).getOperationType())){//已提交强停并且正常状态   状态还未更新时
                    handDto.getStop().setOptType("403");
                }
            }else{
                if(BizType.BLOCK_OPEN_CLOSE.getCode().equals(bizs.get(0).getBizType()) && "0".equals(bizs.get(0).getOperationType())){
                    handDto.getStop().setOptType("404");//已提交强开 并且正常状态   状态还未更新时
                }
            }
        }
        //110-可订购，120-订购可取消，130-订购中
        //210-可变更，220-变更可取消，230-变更中
        //310-可退订，320-退订可取消，330-退订中
        //401-可强停，402-可强开，403-强停中，404-解强开
        //501-可挂失，502-可解挂，503-挂失中，504-解挂中
        //601-可开通，602-可关闭，603-操作中
        //业务类型:0 套餐  ,1 来电提醒，2 来电显示 ,3 app语音业务 ,4流量业务 ,5组合业务,6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包
        
        if(!"230".equals(handDto.getSmsServ().getOptType())){//短信功能
            if(justMap.containsKey(handDto.getSmsServ().getServCode())){
                if("601".equals(handDto.getSmsServ().getOptType()) && "0".equals(justMap.get(handDto.getSmsServ().getServCode()))){//可订购时，并且有订购记录
                    handDto.getSmsServ().setOptType("603");
                }
                if("602".equals(handDto.getSmsServ().getOptType()) && "1".equals(justMap.get(handDto.getSmsServ().getServCode()))){//可关闭时，并且有关闭记录
                    handDto.getSmsServ().setOptType("603");
                }
            }
        }
        if(!"230".equals(handDto.getHzServ().getOptType())){//呼叫转移
            if(justMap.containsKey(handDto.getHzServ().getServCode())){
                if("601".equals(handDto.getHzServ().getOptType()) && "0".equals(justMap.get(handDto.getHzServ().getServCode()).getOperationType())){//可订购时，并且有订购记录
                    handDto.getHzServ().setOptType("603");
                }
                if("602".equals(handDto.getHzServ().getOptType()) && "1".equals(justMap.get(handDto.getHzServ().getServCode()).getOperationType())){//可关闭时，并且有关闭记录
                    handDto.getHzServ().setOptType("603");
                }
            }
        }
        if(!"230".equals(handDto.getFlowServ().getOptType())){//上网功能
            if(justMap.containsKey(handDto.getFlowServ().getServCode())){
                if("601".equals(handDto.getFlowServ().getOptType()) && "0".equals(justMap.get(handDto.getFlowServ().getServCode()).getOperationType())){//可订购时，并且有订购记录
                    handDto.getFlowServ().setOptType("603");
                }
                if("602".equals(handDto.getFlowServ().getOptType()) && "1".equals(justMap.get(handDto.getFlowServ().getServCode()).getOperationType())){//可关闭时，并且有关闭记录
                    handDto.getFlowServ().setOptType("603");
                }
            }
        }
    }
    
    
    /**
     * 根据套餐编号查询子业务
     * @param packCode
     * @return
     * @throws Exception
     */
    private Map<String, Packages> lowMap(String packCode,CsServHandDTO handDto) throws Exception{
        if("cool2".equals(packCode)){
            packCode = "xcool2";
        }
        Map<String, Packages> rtMap = new HashMap<>();
        Map<String, Object> searchParams = new HashMap<String, Object>();
        searchParams.put("servType","0");
        searchParams.put("code",packCode);
        List<Packages> pacList = pacMapper.listPac(searchParams);//查询当前套餐
        handDto.getPack().setServId(pacList.get(0).getId());
        handDto.getPack().setServName(pacList.get(0).getName());
        
        searchParams = new HashMap<String, Object>();
        searchParams.put("servTypeNotEq","0");
        searchParams.put("parentCode",packCode);
        List<Packages> list = pacMapper.listPac(searchParams);//查询当前套餐子业务，非套餐
        if(null != list && list.size() >0){
            for(Packages s:list){
                rtMap.put(s.getCode(), s);
                //业务类型:0 套餐  ,1 来电提醒，2 来电显示 ,3 app语音业务 ,4流量业务 ,5组合业务,6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包
                if("1".equals(s.getServType()) && "2".equals(handDto.getServCall().getIsShow())){
                    handDto.getServCall().setServName("来电提醒");
                    handDto.getServCall().setIsShow("1");
                    handDto.getServCall().setServId(s.getId());
                }else if("2".equals(s.getServType()) && "2".equals(handDto.getServShow().getIsShow())){
                    handDto.getServShow().setServName("来电显示");
                    handDto.getServShow().setIsShow("1");
                    handDto.getServShow().setServId(s.getId());
                }else if("4".equals(s.getServType()) && "2".equals(handDto.getServFlow().getIsShow())){
                    handDto.getServFlow().setServName("基础流量包");
                    handDto.getServFlow().setIsShow("1");
                }else if("6".equals(s.getServType()) && "2".equals(handDto.getServAppendFlow().getIsShow())){
                    handDto.getServAppendFlow().setServName("叠加流量包");
                    handDto.getServAppendFlow().setIsShow("1");
                }else if("7".equals(s.getServType()) && "2".equals(handDto.getServVoice().getIsShow())){
                    handDto.getServVoice().setServName("基础语音包");
                    handDto.getServVoice().setIsShow("1");
                }else if("8".equals(s.getServType()) && "2".equals(handDto.getServDayFlow().getIsShow())){
                    handDto.getServDayFlow().setServName("普通流量日包");
                    handDto.getServDayFlow().setIsShow("1");
                }else if("9".equals(s.getServType()) && "2".equals(handDto.getKeeyOnFlow().getIsShow())){
                    handDto.getKeeyOnFlow().setServName("自动续订日包");
                    handDto.getKeeyOnFlow().setIsShow("1");
                }else if("10".equals(s.getServType()) && "2".equals(handDto.getSmsServ().getIsShow())){
                    handDto.getSmsServ().setServName("短信功能");
                    handDto.getSmsServ().setIsShow("1");
                }else if("11".equals(s.getServType())){
                    handDto.getHzServ().setServName("呼叫转移");
                    handDto.getHzServ().setIsShow("1");
                    handDto.getHzServ().setServCode(s.getCode());
                }else if("12".equals(s.getServType())){
                    handDto.getFlowServ().setServName("上网功能");
                    handDto.getFlowServ().setIsShow("1");
                    handDto.getFlowServ().setServCode(s.getCode());
                }
            }
        }
        return rtMap;
    }
    
    /**
     * 业务办理查询业务
     * @param packCode
     * @param servType
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public RestStatus listPac(CsReqPropertyDTO reqDto,User user) throws Exception{
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","查询可办理业务");
        //需要判断号码是中兴视通号码
        Map<String, Object> parment = new HashMap<>();
        parment.put("prefix", Integer.valueOf(reqDto.getPhone().substring(0, 7)));
        parment.put("virtualCode", MobileArea.virtual_code_zxst);
        MobileArea ps = mobileAreaMapper.findByPrefix(parment);
        if(ps == null){
           return new RestStatus(Boolean.FALSE,"500","非中兴视通号码不能进行该业务");
        }
        List<CsServHandVoDTO> list = new ArrayList<>();
        //业务类型:0 套餐  ,1 来电提醒，2 来电显示 ,3 app语音业务 ,4流量业务 ,5组合业务,6-叠加包，7-通话语音包,8-普通流量日包，9-自动续订流量日包
        if("0".equals(reqDto.getServType())){//查询套餐
            ReqCommonDTO dto = new ReqCommonDTO();
            dto.setPhone(reqDto.getPhone());
            RestStatus rs = CommonService.common(dto, "cs/user/packs", "查询套餐信息", user);
            if(!rs.getStatus()){
                logger.error("查询套餐信息失败,error="+rs.getErrorMessage());
                return new RestStatus(Boolean.FALSE,"500","查询套餐信息失败,原因："+rs.getErrorMessage());
            }
            Map<String, Object> packMap = (Map<String, Object>) rs.getResponseData();
            List<Object> listPac = (List<Object>) packMap.get("packList");
            if(null != listPac && listPac.size() >0){
                for(Object p:listPac){
                    Map<String,Object> entry = (Map<String,Object>)p;
                    CsServHandVoDTO vo = new CsServHandVoDTO();
                    vo.setServCode(String.valueOf(entry.get("code")));
                    vo.setServName(String.valueOf(entry.get("name")));
                    vo.setServId(Integer.valueOf(entry.get("id").toString()));
                    list.add(vo);
                }
            }
        }else {
            Map<String,Object> searchMap = new HashMap<String,Object>();
            searchMap.put("servType", reqDto.getServType());
            searchMap.put("parentCode", reqDto.getPacCode());
            searchMap.put("order", "money");
            searchMap.put("sort", "asc");
            searchMap.put("network",ps.getCarrier());
            List<Packages> listPac = pacMapper.listPac(searchMap);
            for(Packages p:listPac){
                CsServHandVoDTO vo = new CsServHandVoDTO();
                vo.setServCode(p.getCode());
                vo.setServName(p.getName());
                if("8".equals(reqDto.getServType())){
                    //普通日包 不能选其他的
                    if(!Utils.isEmptyString(reqDto.getServCode()) && !reqDto.getServCode().equals(p.getCode())){
                        vo.setIsDisabled("disabled");
                    }
                }else{
                    if(!Utils.isEmptyString(reqDto.getServCode()) && reqDto.getServCode().equals(p.getCode())){
                        vo.setIsDisabled("disabled");
                    }
                }
                vo.setServId(p.getId());
                list.add(vo);
            }
        }
        restStatus.setResponseData(list);
        return restStatus;
    }
    
    /**
     * 挂失解挂功能
     * 
     * @param obj
     * @return
     */
    public RestStatus lostOrRestore(ReqCommonDTO obj,User user) throws Exception {
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","挂失解挂成功");
        ReqCommonDTO dto = new ReqCommonDTO();
        dto.setOperType(obj.getOperType());
        dto.setPhone(obj.getPhone());
        dto.setReason(obj.getReason());
        RestStatus rs = CommonService.common(dto, "cs/user/saveLostOrRestore", "挂失解挂", user);
        if(!rs.getStatus()){
            logger.error("挂失解挂提交失败,error="+rs.getErrorMessage());
            return new RestStatus(Boolean.FALSE,"500","挂失解挂提交失败,原因："+rs.getErrorMessage());
        }
        return restStatus;
    }
    
    /**
     * 业务办理提交
     * 
     * @param obj
     * @return
     */
    public RestStatus saveFlowOrder(ReqCommonDTO obj,User user) throws Exception {
        ReqCommonDTO dto = new ReqCommonDTO();
        dto.setPhone(obj.getPhone());
        dto.setServId(obj.getServId());
        dto.setOldServId(obj.getOldServId());
        dto.setOperType(obj.getOperType());
        dto.setUserId(user.getId());
        if("0".equals(obj.getServType())){
            RestStatus rs = CommonService.common(dto, "cs/user/changeCourse", "套餐变更提交", user);
            if(!rs.getStatus()){
                logger.error("套餐变更提交失败,error="+rs.getErrorMessage());
                return new RestStatus(Boolean.FALSE,"500","套餐变更提交失败,原因："+rs.getErrorMessage());
            }
            return new RestStatus(Boolean.TRUE,"200","套餐变更提交成功");
        }else{
            RestStatus rs = CommonService.common(dto, "cs/user/saveFlowOrder", "业务办理提交", user);
            if(!rs.getStatus()){
                logger.error("业务办理提交失败,error="+rs.getErrorMessage());
                return new RestStatus(Boolean.FALSE,"500","业务办理提交失败,原因："+rs.getErrorMessage());
            }
            return new RestStatus(Boolean.TRUE,"200","业务办理提交成功");
        }
    }
    
    /**
     * 来显来提办理提交
     * 
     * @param obj
     * @return
     */
    public RestStatus incomingCall(ReqCommonDTO obj,User user) throws Exception {
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","来显来提成功");
        ReqCommonDTO dto = new ReqCommonDTO();
        dto.setOperType(obj.getOperType());
        dto.setServCode(obj.getServCode());
        dto.setServId(obj.getServId());
        dto.setPhone(obj.getPhone());
        dto.setUserId(user.getId());
        dto.setPacCode(obj.getPacCode());
        RestStatus rs = CommonService.common(dto, "cs/user/incomingCall", "业务办理提交", user);
        if(!rs.getStatus()){
            logger.error("来显来提办理提交失败,error="+rs.getErrorMessage());
            return new RestStatus(Boolean.FALSE,"500","来显来提办理提交失败,原因："+rs.getErrorMessage());
        }
        return restStatus;
    }
    
    /**
     * 业务办理取消提交
     * 
     * @param obj
     * @return
     */
    public RestStatus servBlack(CsReqPropertyDTO dto,User user) throws Exception {
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","业务办理取消成功");
        Map<String, Object> searchMap = new HashMap<>();
        searchMap.put("orderNo", dto.getOrderNo());
        List<BuyServRecordListDTO> listDto = buyServiceRecordMapper.listDto(searchMap);
        if(null != listDto && listDto.size() >0){
            if(!"1".equals(listDto.get(0).getStatus())){
                return new RestStatus(Boolean.FALSE,"500","业务已办理成功，如要取消，请联系BOSS系统");
            }
            Integer listPushCount = buyServiceRecordMapper.listPushCount(listDto.get(0).getId());
            if(listPushCount > 0){
                return new RestStatus(Boolean.FALSE,"500","业务已办理成功，如要取消，请联系BOSS系统");
            }
            for(BuyServRecordListDTO b:listDto){
                b.setUpdateId(user.getId());
                b.setUpdateTime(new Date());
                b.setStatus("3");
                buyServiceRecordMapper.updateStatus(b);
            }
            
            Biz b = new Biz();
            b.setOrderNo(listDto.get(0).getOrderNo());
            b.setStatus("4");
            bizMapper.updateByOrderNo(b);
        }else{
            return new RestStatus(Boolean.FALSE,"500","取消业务失败，没有查询到该业务");
        }
        return restStatus;
    }
    
    /**
     * 无条件呼转设置
     * 
     * @param obj
     * @return
     */
    public RestStatus hzPhone(CsReqPropertyDTO obj,User user) throws Exception {
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","无条件呼转设置成功");
        ReqCommonDTO dto = new ReqCommonDTO();
        dto.setOperType(obj.getOperType());
        dto.setPhone(obj.getPhone());
        dto.setUserId(user.getId());
        dto.setPacCode(obj.getPacCode());
        dto.setShiftPhone(obj.getHzPhone());
        dto.setServCode("147");
        dto.setNetwork("1");
        if("LT".equals(obj.getNetwork())){
            dto.setNetwork("2");
            dto.setServCode(obj.getServCode());
        }
        RestStatus rs = CommonService.common(dto, "cs/user/hzPhone", "无条件呼转设置提交", user);
        if(!rs.getStatus()){
            logger.error("来显来提办理提交失败,error="+rs.getErrorMessage());
            return new RestStatus(Boolean.FALSE,"500","无条件呼转设置失败,原因："+rs.getErrorMessage());
        }
        return restStatus;
    }
    
    /**
     * 上网功能设置
     * 
     * @param obj
     * @return
     */
    public RestStatus flowServ(CsReqPropertyDTO obj,User user) throws Exception {
        RestStatus restStatus = new RestStatus(Boolean.TRUE,"200","上网功能设置成功");
        ReqCommonDTO dto = new ReqCommonDTO();
        dto.setOperType(obj.getOperType());
        dto.setPhone(obj.getPhone());
        dto.setUserId(user.getId());
        dto.setPacCode(obj.getPacCode());
        RestStatus rs = CommonService.common(dto, "cs/user/flowServ", "上网功能设置提交", user);
        if(!rs.getStatus()){
            logger.error("来显来提办理提交失败,error="+rs.getErrorMessage());
            return new RestStatus(Boolean.FALSE,"500","上网功能设置失败,原因："+rs.getErrorMessage());
        }
        return restStatus;
    }
   
    
    
    /**
     * 查询客服管理用户信息列表
     * @param dt
     * @return
     */
    public RestStatus mobileWayOrder(String phone,User user) throws Exception{
        ReqCommonDTO dto = new ReqCommonDTO();
        dto.setPhone(phone);
        RestStatus rs = CommonService.common(dto, "cs/user/mobile-way-order", "查询移动在途工单", user);
        return rs;
    }
    
    public int insertBiz(Biz b) {
        //b.setPhone(dto.getPhone());
        b.setOrderNo(Utils.getOrderNo(OrderNOEnum.BUSINESS_NO.getCode()));
        //b.setBizType(BizType.USER_PWD_RESET.getCode());
        //b.setBizName(BizType.USER_PWD_RESET.getName());
        if(StringUtils.isEmpty(b.getServName())) b.setServName(b.getBizName());
        b.setValidType("1");
        b.setMoney(new BigDecimal(0));
        b.setFeeStyle("0");
        if(StringUtils.isEmpty(b.getOperationType())) b.setOperationType("2");
        //b.setStatus(StatusType.SUCCESS.getCode());
        b.setOperationTime(new Date());
        b.setWayType("KF");
        //b.setIp(IpUtil.getIp(request));
        //b.setReason(request.getAttribute("notes")==null?null:request.getAttribute("notes").toString());
        //b.setRemark(user.getId()+"");
        b.setCreateTime(new Date());
        b.setUpdateTime(new Date());
        
        return bizMapper.insert(b);
    }
    
}
