package com.agent.cs.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.cs.entity.BizBatch;
import com.agent.cs.mapper.BizBatchMapper;


@Transactional(rollbackFor=Exception.class)
@Service("bizBatchService")
public class BizBatchService {
    
    @Autowired
    private BizBatchMapper bizBatchMapper;
    
    public int insert(BizBatch biz) {
        return bizBatchMapper.insert(biz);
    }
    
    public List<BizBatch> list(Map<String, Object> params) {
        return bizBatchMapper.list(params);
    }
    
    public int count(Map<String, Object> params) {
        return bizBatchMapper.count(params);
    }
}
