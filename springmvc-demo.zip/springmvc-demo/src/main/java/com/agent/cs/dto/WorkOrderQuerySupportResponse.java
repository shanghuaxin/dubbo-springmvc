package com.agent.cs.dto;

/**
 * 查询工单进度
 * @author FengLu
 *
 */
public class WorkOrderQuerySupportResponse {
    private QuerySupportResultData data;
    
    public QuerySupportResultData getData() {
        return data;
    }

    public void setData(QuerySupportResultData data) {
        this.data = data;
    }
}
