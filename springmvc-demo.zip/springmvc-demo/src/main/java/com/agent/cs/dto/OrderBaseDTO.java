package com.agent.cs.dto;

/**
 * 实体类基类
 * @author FengLu
 *
 */
public class OrderBaseDTO {
    // 投诉问题描述
    private String issue_description;

    public String getIssue_description() {
        return issue_description;
    }

    public void setIssue_description(String issue_description) {
        this.issue_description = issue_description;
    }
}
