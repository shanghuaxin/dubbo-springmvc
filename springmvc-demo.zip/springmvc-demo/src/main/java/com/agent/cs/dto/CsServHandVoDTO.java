package com.agent.cs.dto;

import java.io.Serializable;

/**
 * 业务办理对象
 */
public class CsServHandVoDTO implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -8856476813767757609L;
   
    private String servName;//业务类型名称
    private String servCode;//业编号
    private Integer servId;//id
    //110-可订购，120-订购可取消，130-订购中
    //210-可变更，220-变更可取消，230-变更中
    //310-可退订，320-退订可取消，330-退订中
    //401-可强停，402-可强开，403-强停中，404-解强开
    //501-可挂失，502-可解挂，503-挂失中，504-解挂中
    //601-可开通，602-可关闭，603-操作中
    private String optType;
    private String isShow;//是否显示：1-显示，其他不显示
    private String isDisabled;//是否可操作：disabled 不可操作，其他可以
    private String orderNo;//订单号
    
    public CsServHandVoDTO(){
        
    }
    public CsServHandVoDTO(String isShow){
        this.isShow= isShow;
    }
    public String getServName() {
        return servName;
    }
    public void setServName(String servName) {
        this.servName = servName;
    }
    public String getServCode() {
        return servCode;
    }
    public void setServCode(String servCode) {
        this.servCode = servCode;
    }
    public String getOptType() {
        return optType;
    }
    public void setOptType(String optType) {
        this.optType = optType;
    }
    public String getIsShow() {
        return isShow;
    }
    public void setIsShow(String isShow) {
        this.isShow = isShow;
    }
    public String getIsDisabled() {
        return isDisabled;
    }
    public void setIsDisabled(String isDisabled) {
        this.isDisabled = isDisabled;
    }
    public Integer getServId() {
        return servId;
    }
    public void setServId(Integer servId) {
        this.servId = servId;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    @Override
    public String toString() {
        return "CsServHandVoDTO [servName=" + servName + ", servCode=" + servCode + ", servId=" + servId + ", optType="
                + optType + ", isShow=" + isShow + ", isDisabled=" + isDisabled + ", orderNo=" + orderNo + "]";
    }
}
