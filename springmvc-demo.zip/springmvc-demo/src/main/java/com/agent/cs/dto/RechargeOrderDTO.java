package com.agent.cs.dto;

/**
 * 充值类工单实体
 * @author FengLu
 *
 */
public class RechargeOrderDTO extends OrderBaseDTO {
    // 是否到帐 true：到帐 false：未到帐
    private boolean paying_arrive;
    // 充值号码
    private String phone_number;
    // 一卡充卡号
    private String card_number;
    // 充值时间
    private String recharge_date;
    // 业务流水号
    private String process_serial;
    // 充值金额 （单位厘）
    private Integer payamount;
    
    public boolean isPaying_arrive() {
        return paying_arrive;
    }
    public void setPaying_arrive(boolean paying_arrive) {
        this.paying_arrive = paying_arrive;
    }
    public String getPhone_number() {
        return phone_number;
    }
    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
    public String getCard_number() {
        return card_number;
    }
    public void setCard_number(String card_number) {
        this.card_number = card_number;
    }
    public String getRecharge_date() {
        return recharge_date;
    }
    public void setRecharge_date(String recharge_date) {
        this.recharge_date = recharge_date;
    }
    public String getProcess_serial() {
        return process_serial;
    }
    public void setProcess_serial(String process_serial) {
        this.process_serial = process_serial;
    }
    public Integer getPayamount() {
        return payamount;
    }
    public void setPayamount(Integer payamount) {
        this.payamount = payamount;
    }
}
