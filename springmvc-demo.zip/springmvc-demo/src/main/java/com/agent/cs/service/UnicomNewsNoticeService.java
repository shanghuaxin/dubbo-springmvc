package com.agent.cs.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.common.DataTable;
import com.agent.cs.entity.UnicomNewsNotice;
import com.agent.cs.mapper.UnicomNewsNoticeMapper;

/**
 * 联通消息通知
 * @author zhangwei
 *
 */
@Service("unicomNewsNoticeService")
@Transactional(rollbackFor=Exception.class)
public class UnicomNewsNoticeService {
    @Autowired
    private UnicomNewsNoticeMapper unicomNewsNoticeMapper;
    
    /**
     * 查询联通消息通知列表
     * @param dt
     * @param searchMap
     * @return
     */
    public DataTable<UnicomNewsNotice> list(DataTable<UnicomNewsNotice> dt,Map<String,Object> searchMap) throws Exception{
        List<UnicomNewsNotice> listDto = unicomNewsNoticeMapper.list(searchMap);
        int count = unicomNewsNoticeMapper.count(searchMap);
        dt.setAaData(listDto);
        dt.setiTotalDisplayRecords(count);
        return dt;
    }
    
    /**
     * 保存消息
     * @param u
     * @throws Exception
     */
    public int saveNotice(UnicomNewsNotice u) throws Exception{
        return unicomNewsNoticeMapper.insert(u);
    }
}
