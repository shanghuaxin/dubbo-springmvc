package com.agent.cs.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.common.DataTable;
import com.agent.cs.entity.UnicomNewsNotice;
import com.agent.cs.service.UnicomNewsNoticeService;

/**
 * 客服联通消息控制器
 * @author FengLu
 *
 */
@Controller
@RequestMapping("unicomNewsNotice")
public class UnicomNewsNoticeController {

    private static Logger logger = LoggerFactory.getLogger(UnicomNewsNoticeController.class);
    @Autowired
    private UnicomNewsNoticeService unicomNewsNoticeService;
    
    /**
     * 进入联通消息查询页面
     * @return
     */
    @RequestMapping(value = "notice-list", method = RequestMethod.GET)
    public String notice(Model model, HttpSession session) {
        return "/views/cs/notice/newsNoticeList.jsp";
    }
    
    /**
     * 查询联通消息列表
     * @return
     */
    @RequestMapping(value="notice-list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<UnicomNewsNotice> noticeList(DataTable<UnicomNewsNotice> dt, HttpServletRequest request, HttpSession session){
        try{
            Map<String,Object> searchMap = new HashMap<>();
            searchMap.put("pushContentLike", request.getParameter("pushContentLike"));
            searchMap.put("pushType", request.getParameter("pushType"));
            
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            return unicomNewsNoticeService.list(dt,searchMap);
        }catch(Exception e){
            logger.error("查询联通消息列表失败，原因："+e.getMessage(),e);
            e.printStackTrace();
        }
        return null;
    }
}
