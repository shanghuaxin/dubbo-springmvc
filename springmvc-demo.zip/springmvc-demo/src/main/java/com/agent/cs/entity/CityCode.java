package com.agent.cs.entity;

import com.agent.common.BaseDomain;

/**
 * 城市编码，用于联通客服工单时，匹配城市和省份编码
 * @author FengLu
 *
 */
public class CityCode extends BaseDomain {
    
    private static final long serialVersionUID = 3298121608724061205L;
    // 省份编码
    private String provinceCode;
    // 城市编码
    private String cityCode;
    // 城市名称
    private String cityName;
    // 区号
    private String zoneCode;
    
    public String getProvinceCode() {
        return provinceCode;
    }
    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }
    public String getCityCode() {
        return cityCode;
    }
    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }
    public String getCityName() {
        return cityName;
    }
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    public String getZoneCode() {
        return zoneCode;
    }
    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }
}
