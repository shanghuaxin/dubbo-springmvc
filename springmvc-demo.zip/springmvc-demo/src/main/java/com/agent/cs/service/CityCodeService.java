package com.agent.cs.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.cs.entity.CityCode;
import com.agent.cs.mapper.CityCodeMapper;

/**
 * 城市编码
 * @author FengLu
 *
 */
@Service("cityCodeService")
@Transactional(rollbackFor=Exception.class)
public class CityCodeService {
    
    @Autowired
    private CityCodeMapper cityCodeMapper;
    
    /**
     * 据名称获取城市编码
     * @param cityName
     * @return
     */
    public List<CityCode> findByName(String cityName) {
        return cityCodeMapper.findByName(cityName);
    }
    
    /**
     * 根据编码获取城市名称
     * @param map
     * @return
     */
    public CityCode findByCode(String cityCode) {
        return cityCodeMapper.findByCode(cityCode);
    }
}
