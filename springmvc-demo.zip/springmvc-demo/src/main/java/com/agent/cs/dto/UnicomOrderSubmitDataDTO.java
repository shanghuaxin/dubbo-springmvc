package com.agent.cs.dto;

/**
 * 联通工单提交data对象
 * @author FengLu
 *
 */
public class UnicomOrderSubmitDataDTO {
    // 工单ID
    private String support_id;
    // 工单类型 01:网络使用类 02:服务开通变更类 03:计费类 04:充值类 05:增值业务类  06:漏电提醒类
    private String support_type;
    // 用户姓名
    private String username;
    // 手机号码
    private Long phone_number;
    // 用户联系人姓名
    private String contact;
    // 用户联系人电话
    private String contact_number;
    // 转售企业联系人
    private String mvno_contact;
    // 转售企业联系电话
    private String mvno_contact_number;
    // 工单实体
    private SupportContent support_content;
    // 撤销原因
    private String reason;
    
    public String getSupport_id() {
        return support_id;
    }
    public void setSupport_id(String support_id) {
        this.support_id = support_id;
    }
    public String getSupport_type() {
        return support_type;
    }
    public void setSupport_type(String support_type) {
        this.support_type = support_type;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public Long getPhone_number() {
        return phone_number;
    }
    public void setPhone_number(Long phone_number) {
        this.phone_number = phone_number;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
    public String getContact_number() {
        return contact_number;
    }
    public void setContact_number(String contact_number) {
        this.contact_number = contact_number;
    }
    public String getMvno_contact() {
        return mvno_contact;
    }
    public void setMvno_contact(String mvno_contact) {
        this.mvno_contact = mvno_contact;
    }
    public String getMvno_contact_number() {
        return mvno_contact_number;
    }
    public void setMvno_contact_number(String mvno_contact_number) {
        this.mvno_contact_number = mvno_contact_number;
    }
    public SupportContent getSupport_content() {
        return support_content;
    }
    public void setSupport_content(SupportContent support_content) {
        this.support_content = support_content;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
}
