package com.agent.cs.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.api.InterfaceWorkOrderUtil;
import com.agent.business.entity.MobileArea;
import com.agent.business.service.MobileAreaService;
import com.agent.common.PageEntity;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.WorkOrderStatusType;
import com.agent.common.enumeration.WorkOrderSupportType;
import com.agent.constant.Constant;
import com.agent.cs.dto.AccountOrderDTO;
import com.agent.cs.dto.BillingOrderDTO;
import com.agent.cs.dto.MishuOrderDTO;
import com.agent.cs.dto.NetworkOrderDTO;
import com.agent.cs.dto.RechargeOrderDTO;
import com.agent.cs.dto.ResultData;
import com.agent.cs.dto.SupportContent;
import com.agent.cs.dto.UnicomOrderSubmitDTO;
import com.agent.cs.dto.UnicomOrderSubmitDataDTO;
import com.agent.cs.dto.VASOrderDTO;
import com.agent.cs.dto.WorkOrderDTO;
import com.agent.cs.dto.WorkOrderQuerySupportResponse;
import com.agent.cs.dto.WorkOrderSubmitResponse;
import com.agent.cs.entity.CityCode;
import com.agent.cs.entity.WorkOrder;
import com.agent.cs.service.CityCodeService;
import com.agent.cs.service.WorkOrderService;
import com.agent.order.common.util.JSONUtil;
import com.agent.system.entity.User;
import com.agent.system.service.UserService;
import com.agent.util.DateUtil;
import com.agent.util.SysConfig;
import com.agent.util.Utils;

/**
 * 客服工单控制器
 * @author FengLu
 *
 */
@Controller
@RequestMapping("workOrder")
public class WorkOrderController {
    
    private static Logger logger = LoggerFactory.getLogger(WorkOrderController.class);
    
    @Autowired
    private WorkOrderService workOrderService;
    @Autowired
    private CityCodeService cityCodeService;
    @Autowired
    private MobileAreaService mobileAreaService;
    @Autowired
    private UserService userService;
    
    @RequestMapping("list")
    public String list(HttpServletRequest request, HttpServletResponse response, WorkOrderDTO workOrderDTO) {
        //TODO 查询工单信息
        Map<String, Object> params = new HashMap<String, Object>();
        try {
            // 设置分页初始化数据
            PageEntity pageEntity = new PageEntity(workOrderDTO.getPageSize(), workOrderDTO.getPageIndex());
            int limit = 0;
            int offset = pageEntity.getPageSize();
            limit = (pageEntity.getPageIndex() - 1) * offset;
            params.put("limit", limit);
            params.put("offset", offset);
            if (null != workOrderDTO.getComplainPhone()) {
                params.put("complainPhone", workOrderDTO.getComplainPhone());
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getComplainName())) {
                params.put("complainName", workOrderDTO.getComplainName());
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getStartDate())) {
                params.put("startDate", workOrderDTO.getStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getEndDate())) {
                params.put("endDate", workOrderDTO.getEndDate() + " 23:59:59");
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getFeedbackStartDate())) {
                params.put("feedbackStartDate", workOrderDTO.getFeedbackStartDate() + " 00:00:00");
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getFeedbackEndDate())) {
                params.put("feedbackEndDate", workOrderDTO.getFeedbackEndDate() + " 23:59:59");
            }
            if (null != workOrderDTO.getStatus()) {
                params.put("status", workOrderDTO.getStatus());
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getFeedbackStatus())) {
                params.put("feedbackStatus", workOrderDTO.getFeedbackStatus());
            }
            if (StringUtils.isNotEmpty(workOrderDTO.getSupportId())) {
                params.put("supportIdLike", workOrderDTO.getSupportId());
            }
            List<WorkOrder> workOrderList = workOrderService.list(params);
            int total = workOrderService.count(params);
            pageEntity.setTotal(total);
            request.setAttribute("workOrderList", workOrderList);
            request.setAttribute("pageEntity", pageEntity);
            request.setAttribute("workOrderDTO", workOrderDTO);
        } catch (Exception e) {
            logger.error("查询工单信息异常："+e.getMessage(), e);
        }
        return "/views/cs/workorder/workOrderList.jsp";
    }
    
    @RequestMapping(value="add-init")
    public String addInit(HttpServletRequest request, HttpServletResponse response) {
        
        return "/views/cs/workorder/workOrderNew.jsp";
    }

    @RequestMapping(value="add", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> add(HttpServletRequest request, HttpServletResponse response, WorkOrderDTO workOrderDTO) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        try {
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            if (null == user) {
                map.put("status", false);
                map.put("errorMsg", "登录超时，请重新登录！");
                return map;
            }
            
            String serialNumber = Utils.getRandomOfChar(30);
            WorkOrder workOrder = new WorkOrder();
            workOrder.setSupportId(serialNumber+Utils.getRandomString(4));
            workOrder.setSupportType(workOrderDTO.getSupportType());
            workOrder.setComplainName(workOrderDTO.getComplainName());
            workOrder.setComplainPhone(workOrderDTO.getComplainPhone());
            workOrder.setComplainContactName(workOrderDTO.getComplainContactName());
            workOrder.setComplainContactPhone(workOrderDTO.getComplainContactPhone());
            workOrder.setMvnoContactName(workOrderDTO.getMvnoContactName());
            workOrder.setMvnoContactPhone(workOrderDTO.getMvnoContactPhone());
            workOrder.setSupportLevel(workOrderDTO.getSupportLevel());
            workOrder.setIssueDescription(workOrderDTO.getIssue_description());
            workOrder.setStatus(workOrderDTO.getStatus());
            workOrder.setCreateId(user.getId());
            workOrder.setUpdateId(user.getId());
            
            /**
             * 构造工单实体
             */
            SupportContent supportContent = new SupportContent();
            supportContent.setSupport_level(workOrderDTO.getSupportLevel());
            // 查找号码归属
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("prefix", workOrderDTO.getComplainPhone().toString().substring(0, 7));
            MobileArea mobileArea = mobileAreaService.findByPrefix(params);
            CityCode cityCode = cityCodeService.findByName(mobileArea.getCity()).get(0);
            // 查找号码出现问题的省份城市编码
            List<CityCode> cityCodeIssues = cityCodeService.findByName(workOrderDTO.getIssueCity());
            CityCode cityCodeIssue = null;
            if (null != cityCodeIssues && cityCodeIssues.size() >0) {
                if(cityCodeIssues.size() >1){
                    map.put("status", false);
                    map.put("errorMsg", "请输入准确城市名称");
                    return map;
                }
                cityCodeIssue = cityCodeIssues.get(0);
            }else{
                cityCodeIssue = cityCode;
            }
            supportContent.setIssue_province(cityCodeIssue.getProvinceCode());
            supportContent.setIssue_city(cityCodeIssue.getCityCode());
            supportContent.setPhone_number_province(cityCode.getProvinceCode());
            supportContent.setPhone_number_city(cityCode.getCityCode());
            // 重复投诉 0：非重复  1：重复
            if ("1".equals(workOrderDTO.getRepetition())) {
                supportContent.setRepetition(true);
                supportContent.setOriginal_support_id(workOrderDTO.getOriginal_support_id());
                supportContent.setRepetition_description(workOrderDTO.getRepetition_description());
            } else {
                supportContent.setRepetition(false);
            }
            supportContent.setPresent_condition(workOrderDTO.getPresent_condition());
            supportContent.setRequirements(workOrderDTO.getRequirements());
            
            if (WorkOrderSupportType.NETWORK.getId().equals(workOrderDTO.getSupportType())) {
                // 网络使用类
                NetworkOrderDTO networkOrder = new NetworkOrderDTO();
                networkOrder.setNetwork_type(workOrderDTO.getNetwork_type());
                networkOrder.setSignal(workOrderDTO.getSignal());
                networkOrder.setSymptom(workOrderDTO.getSymptom());
                networkOrder.setNot_calling(workOrderDTO.getNot_calling());
                networkOrder.setIssue_description(workOrderDTO.getIssue_description());
                supportContent.setNetwork_data(networkOrder);
            } else if (WorkOrderSupportType.ACCOUNT.getId().equals(workOrderDTO.getSupportType())) {
                // 服务开通类
                AccountOrderDTO accountOrder = new AccountOrderDTO();
                accountOrder.setApi_name(Constant.API_NAME_SUBMIT);
                accountOrder.setSerial_number(serialNumber);
                accountOrder.setOrder_id(workOrderDTO.getOrder_id());
                accountOrder.setIssue_description(workOrderDTO.getIssue_description());
                supportContent.setAccount_data(accountOrder);
            } else if (WorkOrderSupportType.BILLING.getId().equals(workOrderDTO.getSupportType())) {
                // 计费类
                BillingOrderDTO billingOrder = new BillingOrderDTO();
                billingOrder.setCdr_type(workOrderDTO.getCdr_type());
                billingOrder.setCdr_file(workOrderDTO.getCdr_file());
                billingOrder.setCdr_number(workOrderDTO.getCdr_number());
                billingOrder.setIssue_description(workOrderDTO.getIssue_description());
                supportContent.setBilling_data(billingOrder);
            } else if (WorkOrderSupportType.RECHARGE.getId().equals(workOrderDTO.getSupportType())) {
                // 充值类
                RechargeOrderDTO rechargeOrder = new RechargeOrderDTO();
                if ("1".equals(workOrderDTO.getPaying_arrive())) {
                    rechargeOrder.setPaying_arrive(true);
                } else {
                    rechargeOrder.setPaying_arrive(false);
                }
                rechargeOrder.setPhone_number(workOrderDTO.getPhone_number());
                rechargeOrder.setCard_number(workOrderDTO.getCard_number());
                if (null != workOrderDTO.getRecharge_date()) {
                    rechargeOrder.setRecharge_date(workOrderDTO.getRecharge_date().replaceAll("-", ""));
                }
                rechargeOrder.setProcess_serial(workOrderDTO.getProcess_serial());
                // 分转厘
                rechargeOrder.setPayamount(workOrderDTO.getPayamount()*10);
                rechargeOrder.setIssue_description(workOrderDTO.getIssue_description());
                supportContent.setRecharge_data(rechargeOrder);
            } else if (WorkOrderSupportType.VAS.getId().equals(workOrderDTO.getSupportType())) {
                // 增值业务类
                VASOrderDTO vasOrder = new VASOrderDTO();
                vasOrder.setSystem_type(workOrderDTO.getSystem_type());
                vasOrder.setVas_type(workOrderDTO.getVas_type());
                vasOrder.setVas_description(workOrderDTO.getVas_description());
                vasOrder.setIssue_description(workOrderDTO.getIssue_description());
                supportContent.setVas_data(vasOrder);
            } else if (WorkOrderSupportType.MISHU.getId().equals(workOrderDTO.getSupportType())) {
                // 漏电提醒类
                MishuOrderDTO mishuOrder = new MishuOrderDTO();
                mishuOrder.setIssue_description(workOrderDTO.getIssue_description());
                supportContent.setMishu_data(mishuOrder);
            }
            
            // 构造工单提交对象
            UnicomOrderSubmitDataDTO submitDataDTO = new UnicomOrderSubmitDataDTO();
            submitDataDTO.setSupport_id(workOrder.getSupportId());
            submitDataDTO.setSupport_type(workOrder.getSupportType());
            submitDataDTO.setUsername(workOrder.getComplainName());
            submitDataDTO.setPhone_number(workOrder.getComplainPhone());
            submitDataDTO.setContact(workOrder.getComplainContactName());
            submitDataDTO.setContact_number(workOrder.getComplainContactPhone());
            submitDataDTO.setMvno_contact(workOrder.getMvnoContactName());
            submitDataDTO.setMvno_contact_number(workOrder.getMvnoContactPhone());
            submitDataDTO.setSupport_content(supportContent);
            
            UnicomOrderSubmitDTO sumbitDTO = new UnicomOrderSubmitDTO();
            sumbitDTO.setMvnokey(Constant.MVNOKEY);
            sumbitDTO.setSerial_number(serialNumber);
            sumbitDTO.setTimestamp(DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss));
            sumbitDTO.setService_type(Constant.SERVICE_TYPE);
            sumbitDTO.setService_name(Constant.SERVICE_NAME_SUBMIT);
            sumbitDTO.setApi_name(Constant.API_NAME_SUBMIT);
            sumbitDTO.setData(submitDataDTO);
            // 记录工单的入参
            workOrder.setRequestContent(JSONUtil.objectToJson(sumbitDTO));
            
            // 提交时，才允许发送请求到VOP
            if (1 == workOrderDTO.getStatus().intValue()) {
                
                String backUrl = SysConfig.getValue("WorkOrderSubmit");
                String json = JSONUtil.objectToJson(sumbitDTO);
                logger.info("工单【"+submitDataDTO.getSupport_id()+"】提交入参--->"+json);
                Map<String, String> reqRes = new HashMap<String, String>();
                reqRes.put("Content-Type", "application/x-www-form-urlencoded");
                reqRes.put("Connection", "Keep-Alive");
                String result = InterfaceWorkOrderUtil.getInstance().callInvoke(backUrl, json, reqRes);
                logger.info("工单【"+submitDataDTO.getSupport_id()+"】提交出参--->"+result);
                // 记录出参
                workOrder.setResponseContent(result);
                WorkOrderSubmitResponse submitResponse = JSONUtil.jsonToObject(result, WorkOrderSubmitResponse.class);
                if (null != submitResponse.getError()) {
                    ResultData resultData = submitResponse.getError();
                    map.put("status", false);
                    if ("S-CE-001".equals(resultData.getStatus())) {
                        map.put("errorMsg", "工单提交超时，请重发工单");
                        workOrder.setStatus(WorkOrderStatusType.WAIT_RESUBMIT.getId());
                    } else {
                        map.put("errorMsg", resultData.getMessage());
                        logger.error(workOrderDTO.getComplainPhone()+"新建工单【"+submitDataDTO.getSupport_id()+"】异常:"+resultData.getMessage());
                        return map;
                    }
                }
            }
            
            // 插入工单表
            workOrderService.insert(workOrder);
        } catch (Exception e) {
            logger.error("新建工单异常："+e.getMessage(), e);
            map.put("status", false);
            map.put("errorMsg", "新建工单异常："+e.getMessage());
        }
        return map;
    }
    
    /**
     * 工单提交
     * @param request
     * @param response
     * @param id 工单主键
     * @return
     */
    @RequestMapping(value="submit", method = RequestMethod.POST)
    @ResponseBody
    public String submit(HttpServletRequest request, HttpServletResponse response, Integer id, Integer type) {
        try {
            WorkOrder workOrder = workOrderService.selectById(id);
            UnicomOrderSubmitDTO submitDTO = JSONUtil.jsonToObject(workOrder.getRequestContent(), UnicomOrderSubmitDTO.class);
            // 重发
            if (workOrder.getStatus().intValue() == WorkOrderStatusType.WAIT_RESUBMIT.getId().intValue()) {
                /**
                 * 1. 当天重发，报文只需要变更时间，其余不变，直接提交vop
                 * 2. 如果超过了当天，则需要变更报文的时间和流水号Serial_number，才能提交vop
                 */
                String nowDate = DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd);
                Date dateTime1 = DateUtil.getInstance().parseDate(submitDTO.getTimestamp(), DateUtil.yyyy_MM_dd_HH_mm_ss);
                Date dateTime2 = DateUtil.getInstance().parseDate(nowDate+" 23:59:59", DateUtil.yyyy_MM_dd_HH_mm_ss);
                if (DateUtil.getInstance().compareDate(dateTime1, dateTime2) > 1) {
                    submitDTO.setSerial_number(Utils.getRandomOfChar(30));
                }
                submitDTO.setTimestamp(nowDate);
            }
            
            SupportContent supportContent = submitDTO.getData().getSupport_content();
            // 构造工单提交对象
            UnicomOrderSubmitDataDTO submitDataDTO = new UnicomOrderSubmitDataDTO();
            submitDataDTO.setSupport_id(workOrder.getSupportId());
            submitDataDTO.setSupport_type(workOrder.getSupportType());
            submitDataDTO.setUsername(workOrder.getComplainName());
            submitDataDTO.setPhone_number(workOrder.getComplainPhone());
            submitDataDTO.setContact(workOrder.getComplainContactName());
            submitDataDTO.setContact_number(workOrder.getComplainContactPhone());
            submitDataDTO.setMvno_contact(workOrder.getMvnoContactName());
            submitDataDTO.setMvno_contact_number(workOrder.getMvnoContactPhone());
            submitDataDTO.setSupport_content(supportContent);
            
            UnicomOrderSubmitDTO sumbitDTO = new UnicomOrderSubmitDTO();
            //workOrder.get
            sumbitDTO.setMvnokey(Constant.MVNOKEY);
            sumbitDTO.setSerial_number(Utils.getRandomOfChar(30));
            sumbitDTO.setTimestamp(DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss));
            sumbitDTO.setService_type(Constant.SERVICE_TYPE);
            sumbitDTO.setService_name(Constant.SERVICE_NAME_SUBMIT);
            sumbitDTO.setApi_name(Constant.API_NAME_SUBMIT);
            sumbitDTO.setData(submitDataDTO);
            
        } catch (Exception e) {
            logger.error("查看工单信息异常："+e.getMessage(), e);
        }
        return "/views/cs/workorder/workOrderView.jsp";
    }
    
    @RequestMapping(value="view")
    public String view(HttpServletRequest request, HttpServletResponse response, Integer id) {
        try {
            WorkOrder workOrder = workOrderService.selectById(id);
            WorkOrderDTO workOrderDTO = conventDTO(workOrder);
            // 获取创建人名称
            User createUser = userService.findUserById(workOrderDTO.getCreateId());
            if (null != createUser) {
                workOrderDTO.setNickName(createUser.getNickName());
            }
            request.setAttribute("workOrderDTO", workOrderDTO);
        } catch (Exception e) {
            logger.error("查看工单信息异常："+e.getMessage(), e);
        }
        return "/views/cs/workorder/workOrderView.jsp";
    }
    
    /**
     * 工单撤销初始化
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value="revoke-init")
    public String revokeInit(HttpServletRequest request, HttpServletResponse response, Integer id) {
        try {
            WorkOrder workOrder = workOrderService.selectById(id);
            WorkOrderDTO workOrderDTO = conventDTO(workOrder);
            // 获取创建人名称
            User createUser = userService.findUserById(workOrderDTO.getCreateId());
            if (null != createUser) {
                workOrderDTO.setNickName(createUser.getNickName());
            }
            request.setAttribute("workOrderDTO", workOrderDTO);
        } catch (Exception e) {
            logger.error("工单撤销初始化页面异常："+e.getMessage(), e);
        }
        return "/views/cs/workorder/workOrderRevoke.jsp";
    }
    
    /**
     * 工单撤销
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value="revoke", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> revoke(HttpServletRequest request, HttpServletResponse response, Integer id, String revokeReason) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        try {
            String backUrl = SysConfig.getValue("WorkOrderRevoke");
            if (StringUtils.isEmpty(revokeReason)) {
                map.put("status", false);
                map.put("errorMsg", "工单撤销异常：原因不能为空");
                return map;
            }
            
            WorkOrder workOrder = workOrderService.selectById(id);
            
            // 构造工单提交对象
            UnicomOrderSubmitDataDTO submitDataDTO = new UnicomOrderSubmitDataDTO();
            submitDataDTO.setSupport_id(workOrder.getSupportId());
            submitDataDTO.setReason(revokeReason.trim());
            
            UnicomOrderSubmitDTO sumbitDTO = new UnicomOrderSubmitDTO();
            sumbitDTO.setMvnokey(Constant.MVNOKEY);
            sumbitDTO.setSerial_number(Utils.getRandomOfChar(30));
            sumbitDTO.setTimestamp(DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss));
            sumbitDTO.setService_type(Constant.SERVICE_TYPE);
            sumbitDTO.setService_name(Constant.SERVICE_NAME_REVOKE);
            sumbitDTO.setApi_name(Constant.API_NAME_REVOKE);
            sumbitDTO.setData(submitDataDTO);
            
            String json = JSONUtil.objectToJson(sumbitDTO);
            logger.info("工单撤销【"+workOrder.getSupportId()+"】入参--->"+json);
            Map<String, String> reqRes = new HashMap<String, String>();
            reqRes.put("Content-Type", "application/x-www-form-urlencoded");
            reqRes.put("Connection", "Keep-Alive");
            String result = InterfaceWorkOrderUtil.getInstance().callInvoke(backUrl, json, reqRes);
            logger.info("工单撤销【"+workOrder.getSupportId()+"】出参--->"+result);
            WorkOrderSubmitResponse submitResponse = JSONUtil.jsonToObject(result, WorkOrderSubmitResponse.class);
            if (null != submitResponse.getError()) {
                ResultData resultData = submitResponse.getError();
                map.put("status", false);
                map.put("errorMsg", resultData.getMessage());
                logger.error("工单撤销【"+workOrder.getSupportId()+"】异常:"+resultData.getMessage());
                return map;
            }
            
            // 修改工单的状态为已撤销
            WorkOrder wo = new WorkOrder();
            wo.setId(workOrder.getId());
            wo.setStatus(WorkOrderStatusType.REVOKE.getId());
            wo.setRevokeReason(revokeReason.trim());
            workOrderService.update(wo);
        } catch (Exception e) {
            logger.error("工单撤销异常：" + e.getMessage(), e);
            map.put("status", false);
            map.put("errorMsg", "工单撤销异常：" + e.getMessage());
        }
        return map;
    }
    
    /**
     * 工单进度查询
     * @param phone
     * @return
     */
    @RequestMapping(value = "query_support", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus querySupport(WorkOrderDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","工单进度查询成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            String backUrl = SysConfig.getValue("WorkOrderQuerySupport");
            StringBuffer parmentStr = new StringBuffer();
            parmentStr.append("&mvnokey=").append(Constant.MVNOKEY);
            String timestamp = DateUtil.getInstance().formatDate(new Date(), DateUtil.yyyy_MM_dd);
            timestamp= timestamp+"%20"+DateUtil.getInstance().formatDate(new Date(), DateUtil.HH_mm_ss);
            parmentStr.append("&timestamp=").append(timestamp);
            parmentStr.append("&serial_number=").append(Utils.getRandomOfChar(30));
            parmentStr.append("&service_type=").append(Constant.SERVICE_TYPE);
            parmentStr.append("&service_name=").append(Constant.SERVICE_NAME_SUPPORT);
            parmentStr.append("&api_name=").append(Constant.API_NAME_SUPPORT);
            parmentStr.append("&support_id=").append(dto.getSupportId());
            String requestUrl = backUrl = backUrl+parmentStr;
            logger.info("工单进度查询【"+dto.getSupportId()+"】入参--->"+requestUrl);
            String result = InterfaceWorkOrderUtil.getInstance().callInvokeGET(requestUrl);
            logger.info("工单进度查询【"+dto.getSupportId()+"】出参--->"+result);
            if (StringUtils.isNotEmpty(result) && result.contains("\n")) {
                result = result.replace("\n", "");
            }
            WorkOrderQuerySupportResponse support = JSONUtil.jsonToObject(result, WorkOrderQuerySupportResponse.class);
            rs.setResponseData(support);
        }catch (Exception e){
            logger.error("工单进度查询失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","工单进度查询失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 工单删除
     * @param request
     * @param response
     * @param id
     * @return
     */
    @RequestMapping(value="delete", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> delete(HttpServletRequest request, HttpServletResponse response, Integer id) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", true);
        try {
            WorkOrder workOrder = workOrderService.selectById(id);
            if (null == workOrder) {
                map.put("status", false);
                map.put("errorMsg", "工单删除异常：工单不存在!");
                return map;
            }
            if (workOrder.getStatus().intValue() != WorkOrderStatusType.WAIT_SUBMIT.getId().intValue()) {
                map.put("status", false);
                map.put("errorMsg", "工单删除异常：该工单不允许删除!");
                return map;
            }
            
            // 修改工单的状态为已删除
            WorkOrder wo = new WorkOrder();
            wo.setId(workOrder.getId());
            wo.setStatus(WorkOrderStatusType.DELETE.getId());
            workOrderService.update(wo);
        } catch (Exception e) {
            logger.error("工单撤销异常：" + e.getMessage(), e);
            map.put("status", false);
            map.put("errorMsg", "工单删除异常：" + e.getMessage());
        }
        return map;
    }
    
    /**
     * 转换
     * @param wo
     * @return
     */
    private WorkOrderDTO conventDTO(WorkOrder wo) {
        WorkOrderDTO dto = new WorkOrderDTO();
        try {
            dto.setId(wo.getId());
            dto.setSupportId(wo.getSupportId());
            dto.setSupportType(wo.getSupportType());
            dto.setComplainName(wo.getComplainName());
            dto.setComplainPhone(wo.getComplainPhone());
            dto.setComplainContactName(wo.getComplainContactName());
            dto.setComplainContactPhone(wo.getComplainContactPhone());
            dto.setMvnoContactName(wo.getMvnoContactName());
            dto.setMvnoContactPhone(wo.getMvnoContactPhone());
            dto.setSupportLevel(wo.getSupportLevel());
            dto.setStatus(wo.getStatus());
            
            // 工单实体
            UnicomOrderSubmitDTO sumbitDTO = JSONUtil.jsonToObject(wo.getRequestContent(), UnicomOrderSubmitDTO.class);
            SupportContent supportContent = sumbitDTO.getData().getSupport_content();
            dto.setOriginal_support_id(supportContent.getOriginal_support_id());
            dto.setRepetition_description(supportContent.getRepetition_description());
            dto.setPresent_condition(supportContent.getPresent_condition());
            dto.setRequirements(supportContent.getRequirements());
            CityCode cityCode = cityCodeService.findByCode(supportContent.getIssue_city());
            if (null != cityCode) {
                dto.setIssueCity(cityCode.getCityName());
            } else {
                dto.setIssueCity(supportContent.getIssue_city());
            }
            
            // 反馈信息
            dto.setFeedbackStatus(wo.getFeedbackStatus());
            dto.setFeedbackContent(wo.getFeedbackContent());
            dto.setFeedbackTime(wo.getFeedbackTime());
            dto.setFeedbackContactPhone(wo.getFeedbackContactPhone());
            dto.setFeedbackContactName(wo.getFeedbackContactName());
            dto.setFeedbackRemark(wo.getFeedbackRemark());
            
            if (WorkOrderSupportType.NETWORK.getId().equals(wo.getSupportType())) {
                // 网络使用类
                NetworkOrderDTO networkOrder = supportContent.getNetwork_data();
                dto.setNetwork_type(networkOrder.getNetwork_type());
                dto.setSignal(networkOrder.getSignal());
                dto.setSymptom(networkOrder.getSymptom());
                dto.setNot_calling(networkOrder.getNot_calling());
                dto.setIssueDescription(networkOrder.getIssue_description());
            } else if (WorkOrderSupportType.BILLING.getId().equals(wo.getSupportType())) {
                // 计费类
                BillingOrderDTO billingOrder = supportContent.getBilling_data();
                dto.setCdr_type(billingOrder.getCdr_type());
                dto.setCdr_file(billingOrder.getCdr_file());
                dto.setCdr_number(billingOrder.getCdr_number());
                dto.setIssueDescription(billingOrder.getIssue_description());
            } else if (WorkOrderSupportType.RECHARGE.getId().equals(wo.getSupportType())) {
                // 充值类
                RechargeOrderDTO rechargeOrder = supportContent.getRecharge_data();
                if (rechargeOrder.isPaying_arrive()) {
                    dto.setPaying_arrive("1");
                } else {
                    dto.setPaying_arrive("0");
                }
                dto.setPhone_number(rechargeOrder.getPhone_number());
                dto.setCard_number(rechargeOrder.getCard_number());
                dto.setRecharge_date(rechargeOrder.getRecharge_date());
                dto.setProcess_serial(rechargeOrder.getProcess_serial());
                // 厘转分
                dto.setPayamount(rechargeOrder.getPayamount()/10);
                dto.setIssueDescription(rechargeOrder.getIssue_description());
            } else if (WorkOrderSupportType.VAS.getId().equals(wo.getSupportType())) {
                // 增值业务类
                VASOrderDTO vasOrder = supportContent.getVas_data();
                dto.setSystem_type(vasOrder.getSystem_type());
                dto.setVas_type(vasOrder.getVas_type());
                dto.setVas_description(vasOrder.getVas_description());
                dto.setIssueDescription(vasOrder.getIssue_description());
            } else if (WorkOrderSupportType.ACCOUNT.getId().equals(wo.getSupportType())) {
                // 服务开通类
                AccountOrderDTO accountOrder = supportContent.getAccount_data();
                dto.setApi_name(accountOrder.getApi_name());
                dto.setSerial_number(accountOrder.getSerial_number());
                dto.setOrder_id(accountOrder.getOrder_id());
                dto.setIssueDescription(accountOrder.getIssue_description());
            } else if (WorkOrderSupportType.MISHU.getId().equals(wo.getSupportType())) {
                // 漏电提醒类
                MishuOrderDTO mishuOrder = supportContent.getMishu_data();
                dto.setIssueDescription(mishuOrder.getIssue_description());
            }
            dto.setCreateId(wo.getCreateId());
            dto.setUpdateId(wo.getUpdateId());
        } catch (Exception e) {
            logger.error("转换异常："+e.getMessage(), e);
        }
        return dto;
    }
}
