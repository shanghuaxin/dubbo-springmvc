package com.agent.cs.mapper;

import com.agent.common.BaseMapper;
import com.agent.cs.entity.BizBatch;

public interface BizBatchMapper extends BaseMapper<BizBatch, Integer> {
    
}
