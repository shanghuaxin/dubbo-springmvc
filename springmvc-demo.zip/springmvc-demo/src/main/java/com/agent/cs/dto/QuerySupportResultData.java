package com.agent.cs.dto;

import org.apache.commons.lang.StringUtils;

import com.agent.util.DateUtil;

/**
 * 查询工单进度返回对象
 * @author zhangwei
 *
 */
public class QuerySupportResultData {
    private String status;
    private String content;
    private String feedback_time;
    
    public String getStatusStr() {
        if(StringUtils.isNotEmpty(status)){
            if("not_exist".equals(status)){
                return "工单不存在";
            }else if("processing".equals(status)){
                return "处理中";
            }else if("complete".equals(status)){
                return "处理完成";
            }
        }
        return "";
    }
    
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getFeedback_time() {
        if(StringUtils.isNotEmpty(feedback_time)){
            try {
                return DateUtil.getInstance().formatDate(DateUtil.getInstance().parseDate(feedback_time, DateUtil.yyyyMMddHHmmss), DateUtil.yyyy_MM_dd_HH_mm_ss);
            } catch (Exception e) {
                return feedback_time;
            }
        }
        return feedback_time;
    }
    public void setFeedback_time(String feedback_time) {
        this.feedback_time = feedback_time;
    }
}
