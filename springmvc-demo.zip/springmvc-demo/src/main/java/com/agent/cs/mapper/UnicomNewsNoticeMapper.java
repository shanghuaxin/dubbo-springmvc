package com.agent.cs.mapper;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.cs.entity.UnicomNewsNotice;

/**
 * 联通消息通知
 * @author zhangwei
 */
@Repository
public interface UnicomNewsNoticeMapper extends BaseMapper<UnicomNewsNotice, Integer> {
    
}
