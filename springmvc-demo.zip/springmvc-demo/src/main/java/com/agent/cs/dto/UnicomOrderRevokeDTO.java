package com.agent.cs.dto;

/**
 * 联通工单实体
 * @author FengLu
 *
 */
public class UnicomOrderRevokeDTO {
    // 转售企业key
    private String mvnokey;
    // 序列号
    private String serial_number;
    // 时间戳
    private String timestamp;
    // 服务类型
    private String service_type;
    // 服务名称
    private String service_name;
    // 接口名
    private String api_name;
    // data类
    private UnicomOrderRevokeDataDTO data;
    
    public String getMvnokey() {
        return mvnokey;
    }
    public void setMvnokey(String mvnokey) {
        this.mvnokey = mvnokey;
    }
    public String getSerial_number() {
        return serial_number;
    }
    public void setSerial_number(String serial_number) {
        this.serial_number = serial_number;
    }
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    public String getService_type() {
        return service_type;
    }
    public void setService_type(String service_type) {
        this.service_type = service_type;
    }
    public String getService_name() {
        return service_name;
    }
    public void setService_name(String service_name) {
        this.service_name = service_name;
    }
    public String getApi_name() {
        return api_name;
    }
    public void setApi_name(String api_name) {
        this.api_name = api_name;
    }
    public UnicomOrderRevokeDataDTO getData() {
        return data;
    }
    public void setData(UnicomOrderRevokeDataDTO data) {
        this.data = data;
    }
}
