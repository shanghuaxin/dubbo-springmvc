package com.agent.cs.dto;

import java.io.Serializable;

/**
 * 客服用户信息查询列表对象
 * @author zhangwei
 *
 */
public class CsUserListDTO implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -3984508519892126345L;
    
    private String certName;//客户姓名
    private String certCode;//身份证号码
    private String phone;//手机号码
    private String phoneLevel;//号码级别
    private String phoneLevelStr;//号码级别说明
    private String openDate;//开户时间
    private String activationDate;//激活时间
    private String userStatus;//用户状态
    private String pacName;//套餐名称
    private String minMoney;//低消/元
    private String pacMoney;//套餐费用/元
    private String pacCode;//套餐编号
    private String bal;//余额/元
    private String balFlow;//剩余流量/M
    private String area;//归属地
    private String channelName;//代理商名称
    private String mobileModel;//终端手机型号
    private String network;//网络：LT,YD
    private Integer dataCnt;//总数据量
    
    public String getCertName() {
        return certName;
    }
    public void setCertName(String certName) {
        this.certName = certName;
    }
    public String getCertCode() {
        return certCode;
    }
    public void setCertCode(String certCode) {
        this.certCode = certCode;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getPhoneLevel() {
        return phoneLevel;
    }
    public void setPhoneLevel(String phoneLevel) {
        this.phoneLevel = phoneLevel;
    }
    public String getPhoneLevelStr() {
        return phoneLevelStr;
    }
    public void setPhoneLevelStr(String phoneLevelStr) {
        this.phoneLevelStr = phoneLevelStr;
    }
    public String getOpenDate() {
        return openDate;
    }
    public void setOpenDate(String openDate) {
        this.openDate = openDate;
    }
    public String getActivationDate() {
        return activationDate;
    }
    public void setActivationDate(String activationDate) {
        this.activationDate = activationDate;
    }
    public String getUserStatus() {
        return userStatus;
    }
    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }
    public String getPacName() {
        return pacName;
    }
    public void setPacName(String pacName) {
        this.pacName = pacName;
    }
    public String getMinMoney() {
        return minMoney;
    }
    public void setMinMoney(String minMoney) {
        this.minMoney = minMoney;
    }
    
    public String getPacMoney() {
        return pacMoney;
    }
    public void setPacMoney(String pacMoney) {
        this.pacMoney = pacMoney;
    }
    public String getBal() {
        return bal;
    }
    public void setBal(String bal) {
        this.bal = bal;
    }
    public String getBalFlow() {
        return balFlow;
    }
    public void setBalFlow(String balFlow) {
        this.balFlow = balFlow;
    }
    public String getArea() {
        return area;
    }
    public void setArea(String area) {
        this.area = area;
    }
    public String getChannelName() {
        return channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getMobileModel() {
        return mobileModel;
    }
    public void setMobileModel(String mobileModel) {
        this.mobileModel = mobileModel;
    }
    
    public String getPacCode() {
        return pacCode;
    }
    public void setPacCode(String pacCode) {
        this.pacCode = pacCode;
    }
    public String getNetwork() {
        return network;
    }
    public void setNetwork(String network) {
        this.network = network;
    }
    public Integer getDataCnt() {
        return dataCnt;
    }
    public void setDataCnt(Integer dataCnt) {
        this.dataCnt = dataCnt;
    }
}
