package com.agent.cs.dto;

/**
 * 工单提交返回值
 * @author FengLu
 *
 */
public class WorkOrderSubmitResponse {
    private ResultData data;
    private ResultData error;
    
    public ResultData getData() {
        return data;
    }
    public void setData(ResultData data) {
        this.data = data;
    }
    public ResultData getError() {
        return error;
    }
    public void setError(ResultData error) {
        this.error = error;
    }
}
