package com.agent.cs.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 基础DTO，接收类都继承它
 */
public class CsServHandDTO implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = -3248508493749458245L;

    private BigDecimal bal;//余额单位 分
    private CsServHandVoDTO pack = new CsServHandVoDTO("1");//套餐
    private CsServHandVoDTO servFlow = new CsServHandVoDTO("2");//基础流量包
    private CsServHandVoDTO servAppendFlow = new CsServHandVoDTO("2");//叠加流量包
    private CsServHandVoDTO servDayFlow = new CsServHandVoDTO("2");//流量包日包
    private CsServHandVoDTO keeyOnFlow = new CsServHandVoDTO("2");//流量包续订包
    private CsServHandVoDTO servVoice = new CsServHandVoDTO("2");//基础语音包
    private CsServHandVoDTO servShow = new CsServHandVoDTO("2");//来电显示
    private CsServHandVoDTO servCall = new CsServHandVoDTO("2");//来电提醒
    private CsServHandVoDTO stop = new CsServHandVoDTO("1");//强制停机
    private CsServHandVoDTO loss = new CsServHandVoDTO("1");//申请挂失
    private CsServHandVoDTO hzServ = new CsServHandVoDTO("1");//呼叫转移
    private CsServHandVoDTO smsServ = new CsServHandVoDTO("1");//短信功能
    private CsServHandVoDTO flowServ = new CsServHandVoDTO("1");//上网功能
    
    
    public BigDecimal getBal() {
        return bal;
    }
    public void setBal(BigDecimal bal) {
        this.bal = bal;
    }
    public CsServHandVoDTO getPack() {
        return pack;
    }
    public void setPack(CsServHandVoDTO pack) {
        this.pack = pack;
    }
    public CsServHandVoDTO getServFlow() {
        return servFlow;
    }
    public void setServFlow(CsServHandVoDTO servFlow) {
        this.servFlow = servFlow;
    }
    public CsServHandVoDTO getServAppendFlow() {
        return servAppendFlow;
    }
    public void setServAppendFlow(CsServHandVoDTO servAppendFlow) {
        this.servAppendFlow = servAppendFlow;
    }
    public CsServHandVoDTO getServDayFlow() {
        return servDayFlow;
    }
    public void setServDayFlow(CsServHandVoDTO servDayFlow) {
        this.servDayFlow = servDayFlow;
    }
    public CsServHandVoDTO getKeeyOnFlow() {
        return keeyOnFlow;
    }
    public void setKeeyOnFlow(CsServHandVoDTO keeyOnFlow) {
        this.keeyOnFlow = keeyOnFlow;
    }
    public CsServHandVoDTO getServVoice() {
        return servVoice;
    }
    public void setServVoice(CsServHandVoDTO servVoice) {
        this.servVoice = servVoice;
    }
    public CsServHandVoDTO getServShow() {
        return servShow;
    }
    public void setServShow(CsServHandVoDTO servShow) {
        this.servShow = servShow;
    }
    public CsServHandVoDTO getServCall() {
        return servCall;
    }
    public void setServCall(CsServHandVoDTO servCall) {
        this.servCall = servCall;
    }
    public CsServHandVoDTO getStop() {
        return stop;
    }
    public void setStop(CsServHandVoDTO stop) {
        this.stop = stop;
    }
    public CsServHandVoDTO getLoss() {
        return loss;
    }
    public void setLoss(CsServHandVoDTO loss) {
        this.loss = loss;
    }
    public CsServHandVoDTO getHzServ() {
        return hzServ;
    }
    public void setHzServ(CsServHandVoDTO hzServ) {
        this.hzServ = hzServ;
    }
    public CsServHandVoDTO getSmsServ() {
        return smsServ;
    }
    public void setSmsServ(CsServHandVoDTO smsServ) {
        this.smsServ = smsServ;
    }
    public CsServHandVoDTO getFlowServ() {
        return flowServ;
    }
    public void setFlowServ(CsServHandVoDTO flowServ) {
        this.flowServ = flowServ;
    }
}
