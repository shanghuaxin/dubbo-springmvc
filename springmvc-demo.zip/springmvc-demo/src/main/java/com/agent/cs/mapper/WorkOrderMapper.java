package com.agent.cs.mapper;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.cs.entity.WorkOrder;

/**
 * 工单管理
 * @author FengLu
 */
@Repository
public interface WorkOrderMapper extends BaseMapper<WorkOrder, Integer> {
    
}
