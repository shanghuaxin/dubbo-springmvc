package com.agent.cs.dto;

/**
 * 增值业务工单实体
 * @author FengLu
 *
 */
public class VASOrderDTO extends OrderBaseDTO {
    // 手机操作系统
    private String system_type;
    // 增值业务类型 1：炫铃 0：其他
    private Integer vas_type;
    // 业务描述
    private String vas_description;
    
    public String getSystem_type() {
        return system_type;
    }
    public void setSystem_type(String system_type) {
        this.system_type = system_type;
    }
    public Integer getVas_type() {
        return vas_type;
    }
    public void setVas_type(Integer vas_type) {
        this.vas_type = vas_type;
    }
    public String getVas_description() {
        return vas_description;
    }
    public void setVas_description(String vas_description) {
        this.vas_description = vas_description;
    }
}
