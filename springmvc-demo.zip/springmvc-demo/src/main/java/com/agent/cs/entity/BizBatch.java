package com.agent.cs.entity;

import java.io.Serializable;

public class BizBatch implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private int id ;
    private String bizType;
    private String bizName;
    private int operationType;
    private int userId;
    private String phone;
    private String filepath;
    private String reason;
    private String createtime;
    private int optType;
    
    private String nickName;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getBizType() {
        return bizType;
    }
    public void setBizType(String bizType) {
        this.bizType = bizType;
    }
    public String getBizName() {
        return bizName;
    }
    public void setBizName(String bizName) {
        this.bizName = bizName;
    }
    public int getOperationType() {
        return operationType;
    }
    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getFilepath() {
        return filepath;
    }
    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }
    public String getCreatetime() {
        return createtime;
    }
    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
    public String getNickName() {
        return nickName;
    }
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    public int getOptType() {
        return optType;
    }
    public void setOptType(int optType) {
        this.optType = optType;
    }
    
}
