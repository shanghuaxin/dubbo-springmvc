package com.agent.cs.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.example.forcestopdeal.ForceStopDealRequest;
import org.example.productusedquery.ProductFavour;
import org.example.productusedquery.ProductInfo;
import org.example.productusedquery.ProductUsedQueryRequest;
import org.example.productusedquery.ProductUsedQueryResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.agent.business.entity.MobileArea;
import com.agent.business.service.MobileAreaService;
import com.agent.common.BOSSNewBuyService;
import com.agent.common.BOSSUnicomService;
import com.agent.common.CommonService;
import com.agent.common.DataTable;
import com.agent.common.RestStatus;
import com.agent.common.enumeration.StatusType;
import com.agent.constant.Constant;
import com.agent.cs.dto.CsReqPropertyDTO;
import com.agent.cs.dto.CsUserListDTO;
import com.agent.cs.dto.ProductUsedDTO;
import com.agent.cs.dto.ReqCommonDTO;
import com.agent.cs.entity.BizBatch;
import com.agent.cs.service.BizBatchService;
import com.agent.cs.service.CsUserService;
import com.agent.online.common.enumeration.BizType;
import com.agent.online.entity.Biz;
import com.agent.order.common.util.DateUtil;
import com.agent.order.common.util.IpUtil;
import com.agent.order.common.util.Utils;
import com.agent.system.entity.User;
import com.agent.util.Setting;
import com.agent.util.images.FileUtil;

import namespace.webservice.crmsps.ProductChangeVO;
import zsmart.ztesoft.com.xsd.TCoerciveBlockBOSSBO;
import zsmart.ztesoft.com.xsd.TCoerciveReactBOSSBO;
import zsmart.ztesoft.com.xsd.TGPRSSwitchRequest;
import zsmart.ztesoft.com.xsd.TMMSSwitchRequest;
import zsmart.ztesoft.com.xsd.TSMSSwitchRequest;



/**
 * 客服管理-用户管理控制器
 * @author zhangwei
 *
 */
@Controller
@RequestMapping(value="cs/user")
public class CsUserController {
    private static Logger logger = LoggerFactory.getLogger(CsUserController.class);
    @Autowired
    private CsUserService csUserService;
    @Autowired
    private BOSSUnicomService bossService;
    @Autowired
    private BOSSNewBuyService bossMobileService;
    @Autowired
    private MobileAreaService mobileAreaService;
    @Autowired
    private BizBatchService bizBatchService;
    @Autowired
    private BOSSUnicomService bossUnicomService;
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP']}")
    private String resourceIP;
    
    /**
     * 客服系统所有页面的初始化进入 
     * @return
     */
    @RequestMapping(value = "{userReqUrl}", method = RequestMethod.GET)
    public String customer(@PathVariable("userReqUrl") String userReqUrl, 
            @RequestParam(value = "servType", required = false)String servType,
            @RequestParam(value = "servCode", required = false)String servCode,
            @RequestParam(value = "optType", required = false)String optType,
            @RequestParam(value = "servName", required = false)String servName,
            @RequestParam(value = "optName", required = false)String optName,
            @RequestParam(value = "phone", required = false)String phone,
            HttpSession session, HttpServletRequest request,Model model) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        if(user == null){
            //跳转到登录界面
            logger.error("session过期");
            return "login.jsp";
        }
        
        request.setAttribute("resourceIP", resourceIP);
        
        if(StringUtils.isNotEmpty(servType)){
            model.addAttribute(servType);
            model.addAttribute(servCode);
            model.addAttribute(optType);
            model.addAttribute(servName);
            model.addAttribute(optName);
        }
        if(StringUtils.isNotEmpty(phone)){
            model.addAttribute(phone);
        }
        
        return "/views/cs/user/"+userReqUrl+".jsp";
    }
    
    /**
     * 客服号码信息查询
     * @return
     */
    @RequestMapping(value="user-list",method=RequestMethod.POST)
    @ResponseBody
    public DataTable<CsUserListDTO> userList(DataTable<CsUserListDTO> dt, HttpServletRequest request, HttpSession session){
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            ReqCommonDTO dto = new ReqCommonDTO();
            dto.setPhone(request.getParameter("phone"));
            dto.setCertCode(request.getParameter("certCode"));
            return csUserService.userList(dt,user,dto);
        }catch(Exception e){
            logger.error("查看号码信息失败，原因："+e.getMessage(),e);
        }
        return null;
    }

    /**
     * 查询可办理业务
     * @param phone
     * @return
     */
    @RequestMapping(value = "serv-hand", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus servHand(String phone, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","查询可办理业务");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            if(StringUtils.isEmpty(phone)){
                return new RestStatus(Boolean.FALSE,"500","参数异常，号码不能为空");
            }
            //需要判断号码是中兴视通号码
            Map<String, Object> parment = new HashMap<>();
            parment.put("prefix", Integer.valueOf(phone.substring(0, 7)));
            parment.put("virtualCode", MobileArea.virtual_code_zxst);
            MobileArea ps = mobileAreaService.findByPrefix(parment);
            if(ps == null){
               return new RestStatus(Boolean.FALSE,"500","非中兴视通号码不能进行该业务");
            }
            if(MobileArea.carrier_YD.equals(ps.getCarrier())){
                //查询在途工单 ????????????
                /*RestStatus mobileWayOrder = csUserService.mobileWayOrder(phone,user);
                if(!mobileWayOrder.getStatus()){
                    return mobileWayOrder;
                }*/
                rs = csUserService.mobileServHand(phone,user);
            }else{
                rs = csUserService.unicomServHand(phone,user);
            }
        }catch (Exception e){
            logger.error("查询号码信息失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","查询可办理业务失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 业务查询
     * @param phone
     * @return
     */
    @RequestMapping(value = "serv-query", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus servQuery(CsReqPropertyDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","查询可办理业务");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            if(StringUtils.isEmpty(dto.getPhone()) &&StringUtils.isEmpty(dto.getServCode()) && StringUtils.isEmpty(dto.getServType())){
                return new RestStatus(Boolean.FALSE,"500","参数异常，参数不能为空");
            }
            rs = csUserService.listPac(dto,user);
        }catch (Exception e){
            logger.error("查询可办理业务失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","查询可办理业务失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 业务办理提交
     * @param phone
     * @return
     */
    @RequestMapping(value = "saveFlowOrder", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus saveFlowOrder(ReqCommonDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","业务办理提交成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            if(StringUtils.isEmpty(dto.getPhone()) &&StringUtils.isEmpty(dto.getOperType())){
                return new RestStatus(Boolean.FALSE,"500","参数异常，参数不能为空");
            }
            rs = csUserService.saveFlowOrder(dto,user);
        }catch (Exception e){
            logger.error("业务办理提交失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","业务办理提交失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 挂失解挂提交
     * @param phone
     * @return
     */
    @RequestMapping(value = "lostOrRestore", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus lostOrRestore(ReqCommonDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","挂失解挂提交成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            if(StringUtils.isEmpty(dto.getPhone()) &&StringUtils.isEmpty(dto.getOperType())){
                return new RestStatus(Boolean.FALSE,"500","参数异常，参数不能为空");
            }
            rs = csUserService.lostOrRestore(dto,user);
        }catch (Exception e){
            logger.error("挂失解挂提交失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","挂失解挂提交失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 来显来提
     * @param phone
     * @return
     */
    @RequestMapping(value = "incomingCall", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus incomingCall(ReqCommonDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","来显来提成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            if(StringUtils.isEmpty(dto.getPhone()) &&StringUtils.isEmpty(dto.getOperType())){
                return new RestStatus(Boolean.FALSE,"500","参数异常，参数不能为空");
            }
            rs = csUserService.incomingCall(dto,user);
        }catch (Exception e){
            logger.error("来显来提提交失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","挂来显来提提交失败，error="+e.getMessage());
        }
        return rs;
    }
    
    
    /**
     * 业务办理取消
     * @param phone
     * @return
     */
    @RequestMapping(value = "serv-black", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus servBlack(CsReqPropertyDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","业务办理成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            if(StringUtils.isEmpty(dto.getOrderNo())){
                return new RestStatus(Boolean.FALSE,"500","参数异常，参数不能为空");
            }
            rs = csUserService.servBlack(dto,user);
        }catch (Exception e){
            logger.error("业务办理失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","业务办理失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 无条件呼转设置
     * @param phone
     * @return
     */
    @RequestMapping(value = "hzPhone", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus hzPhone(CsReqPropertyDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","无条件呼转设置成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            rs = csUserService.hzPhone(dto,user);
        }catch (Exception e){
            logger.error("业务办理失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","无条件呼转设置失败，error="+e.getMessage());
        }
        return rs;
    }
    
    /**
     * 上网功能
     * @param phone
     * @return
     */
    @RequestMapping(value = "flowServ", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus flowServ(CsReqPropertyDTO dto, HttpSession session){
        RestStatus rs = new RestStatus(Boolean.TRUE,"200","上网功能设置成功");
        try{
            User user = (User) session.getAttribute(Constant.SESSION_USER);
            if(user == null){
                //跳转到登录界面
                logger.error("session过期");
                return new RestStatus(Boolean.FALSE,"500","登录超时，请重新登录");
            }
            rs = csUserService.flowServ(dto,user);
        }catch (Exception e){
            logger.error("上网功能办理失败，原因："+e.getMessage(),e);
            return new RestStatus(Boolean.FALSE,"500","上网功能设置失败，error="+e.getMessage());
        }
        return rs;
    }
    
    
    
    
    /**
     * 在用产品查询
     * @return
     * @author Shanghuaxin
     */
    @RequestMapping(value = "use-biz-query", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus useProgram(ReqCommonDTO dto, HttpServletRequest request) {
        
        return CommonService.common(dto, "cs/use-biz/query", "在用产品查询", (User) request.getSession().getAttribute(Constant.SESSION_USER));
    }
    
    /**
     * 业务消费查询
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "biz-query", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<Biz> bizQuery(DataTable<Biz> dt, ReqCommonDTO dto, HttpServletRequest request) {
        //分页
        dto.setPageNum(dt.getiDisplayStart());
        dto.setPageSize(dt.getiDisplayLength());
        RestStatus rs =CommonService.common(dto, "cs/biz/query", "业务查询", (User) request.getSession().getAttribute(Constant.SESSION_USER));
        List<Biz> list = (List<Biz>)rs.getResponseData();
        if(null !=list){
            dt.setAaData(list);
            dt.setiTotalDisplayRecords(Integer.parseInt(rs.getErrorCode()));
        }else{
            list = new ArrayList<>();
            dt.setAaData(list);
            dt.setiTotalDisplayRecords(0);
        }
        return dt;
    }
    
    /**
     * 消费查询/账单查询
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @RequestMapping(value = "bill-query", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus billQuery(ReqCommonDTO dto, HttpServletRequest request) {
        
        return CommonService.common(dto, "cs/bill/query", "消费查询/账单查询", (User) request.getSession().getAttribute(Constant.SESSION_USER));
    }
    
    /**
     * 详单查询
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "detail-query", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<Biz> detailOrder(DataTable<Biz> dt, ReqCommonDTO dto, HttpServletRequest request) {
        //分页
        dto.setPageNum(dt.getiDisplayStart());
        dto.setPageSize(dt.getiDisplayLength());
        RestStatus rs =CommonService.common(dto, "cs/detail/query", "详单查询", (User) request.getSession().getAttribute(Constant.SESSION_USER));
        dt.setAaData((List<Biz>)rs.getResponseData());
        if(StringUtils.isNotEmpty(rs.getErrorCode())) {
            dt.setiTotalDisplayRecords(Integer.parseInt(rs.getErrorCode()));
        } else {
            dt.setiTotalDisplayRecords(0);
        }
        
        return dt;
    }
    
    /**
     * 使用量查询
     * @param dto
     * @param request
     * @return
     * @author fenglu
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "remind-query", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<ProductUsedDTO> remindQuery(DataTable<ProductUsedDTO> dt, ReqCommonDTO dto, HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        dto.setPageNum(dt.getiDisplayStart());
        dto.setPageSize(dt.getiDisplayLength());
        RestStatus rs;
        // 需要判断号码是中兴视通号码
        Map<String, Object> parment = new HashMap<>();
        parment.put("prefix", Integer.valueOf(dto.getPhone().substring(0, 7)));
        parment.put("virtualCode", MobileArea.virtual_code_zxst);
        MobileArea ps = mobileAreaService.findByPrefix(parment);
        if (ps == null) {
           logger.error(dto.getPhone()+"非中兴视通号码");
           dt.setAaData(new ArrayList<ProductUsedDTO>());
           dt.setiTotalDisplayRecords(0);
        }
        List<ProductUsedDTO> productUsedList = new ArrayList<ProductUsedDTO>();
        if (MobileArea.carrier_YD.equals(ps.getCarrier())) {
            try {
                rs = CommonService.common(dto, "cs/queryFlow", "使用量查询", (User) request.getSession().getAttribute(Constant.SESSION_USER));
                Map<String, Object> map = (Map<String, Object>) rs.getResponseData();
                ProductUsedDTO productUsed = new ProductUsedDTO();
                productUsed.setProductName("流量");
                productUsed.setState("在用");
                productUsed.setUnitName("MB");
                productUsed.setTotalCount(map.get("totalFlow")+"(MB)");
                productUsed.setRestCount(map.get("remaindFlow")+"(MB)");
                productUsed.setUsedCount(map.get("usedFlow")+"(MB)");
                productUsed.setEffDate(com.agent.util.DateUtil.getFirstDateOfMonth());
                productUsed.setExpireDate(com.agent.util.DateUtil.getLastDateOfMonth());
                productUsedList.add(productUsed);
            } catch (Exception e) {
                logger.error("获取使用量异常："+e.getMessage(), e);
            }
            dt.setAaData(productUsedList);
            dt.setiTotalDisplayRecords(productUsedList.size());
        } else {
            String curMonth = DateUtil.getDateByFmt(new Date(), "yyyyMM");
            ProductUsedQueryRequest productUsedQuery = new ProductUsedQueryRequest();
            productUsedQuery.setRequestId(Utils.getRandomString(10));
            productUsedQuery.setSystemId(Constant.SYSTEM_ID);
            productUsedQuery.setServiceId(dto.getPhone());
            productUsedQuery.setUserId(0);
            productUsedQuery.setServiceKind(8);
            productUsedQuery.setFeeDate(curMonth);
            try {
                rs = bossUnicomService.productUsedQuery(productUsedQuery, user);
                if (rs.getStatus()) {
                    ProductUsedQueryResponse productUsered = (ProductUsedQueryResponse) rs.getResponseData();
                    List<ProductInfo> productInfoList = productUsered.getProductInfoGroup();
                    if (null!=productInfoList && productInfoList.size()>0) {
                        ProductInfo productInfo = productInfoList.get(0);
                        List<ProductFavour> productFavourList = productInfo.getProductFavourGroup();
                        for (int i = 0; null!=productFavourList && i<productFavourList.size(); i++) {
                            ProductFavour productFavour = productFavourList.get(i);
                            ProductUsedDTO productUsed = new ProductUsedDTO(); 
                            productUsed.setProductName(productFavour.getProductName());
                            productUsed.setState(productFavour.getState());
                            productUsed.setUnitName(productFavour.getUnitName());
                            Date effDate = com.agent.util.DateUtil.getInstance().parseDate(productFavour.getEffDate(), "yyyyMMddHHmmss");
                            Date expireDate = com.agent.util.DateUtil.getInstance().parseDate(productFavour.getExpireDate(), "yyyyMMddHHmmss");
                            productUsed.setEffDate(com.agent.util.DateUtil.getInstance().formatDate(effDate, "yyyy-MM-dd HH:mm:ss"));
                            productUsed.setExpireDate(com.agent.util.DateUtil.getInstance().formatDate(expireDate, "yyyy-MM-dd HH:mm:ss"));
                            if ("KB".equals(productFavour.getUnitName())) {
                                BigDecimal totalFlow = new BigDecimal(productFavour.getTotalCount());
                                totalFlow = totalFlow.divide(new BigDecimal(1024)).setScale(2,BigDecimal.ROUND_DOWN);
                                productUsed.setTotalCount(String.valueOf(totalFlow)+"(MB)");
                                // 剩余量
                                BigDecimal remaindFlow = new BigDecimal(productFavour.getRestCount());
                                remaindFlow = remaindFlow.divide(new BigDecimal(1024)).setScale(2,BigDecimal.ROUND_DOWN);
                                productUsed.setRestCount(String.valueOf(remaindFlow)+"(MB)");
                                // 使用量
                                BigDecimal usedFlow = new BigDecimal(productFavour.getUsedCount());
                                usedFlow = usedFlow.divide(new BigDecimal(1024)).setScale(2,BigDecimal.ROUND_DOWN);
                                productUsed.setUsedCount(String.valueOf(usedFlow)+"(MB)");
                            } else {
                                productUsed.setTotalCount(productFavour.getTotalCount()+"("+productFavour.getUnitName()+")");
                                productUsed.setRestCount(productFavour.getRestCount()+"("+productFavour.getUnitName()+")");
                                productUsed.setUsedCount(productFavour.getUsedCount()+"("+productFavour.getUnitName()+")");
                            }
                            productUsedList.add(productUsed);
                        }
                    }
                    dt.setAaData(productUsedList);
                    dt.setiTotalDisplayRecords(productUsedList.size());
                }
            } catch (Exception e) {
                logger.error("获取使用量异常："+e.getMessage(), e);
            }
        }
        return dt;
    }
    
    /**
     * 重置密码
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @RequestMapping(value = "pwd-reset", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus pwdReset(ReqCommonDTO dto, HttpServletRequest request) {
        
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        
        RestStatus rs = CommonService.common(dto, "cs/pwd/reset", "重置密码", user);
        
        //添加重置密码的记录到业务办理表中
        Biz b = new Biz();
        b.setBizType(BizType.USER_PWD_RESET.getCode());
        b.setBizName(BizType.USER_PWD_RESET.getName());
        b.setServName(BizType.USER_PWD_RESET.getName());
        b.setPhone(dto.getPhone());
        b.setIp(IpUtil.getIp(request));
        b.setReason(dto.getNotes());
        b.setRemark(user.getId()+"");
        b.setStatus(rs.getStatus()?StatusType.SUCCESS.getCode():StatusType.FAILURE.getCode());
        csUserService.insertBiz(b);
        
        return rs;
    }
    
    /**
     * 重置密码-历史记录
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "pwd-reset-history", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<Biz> pwdResetHistory(DataTable<Biz> dt, ReqCommonDTO dto, HttpServletRequest request) {
        //分页
        dto.setPageNum(dt.getiDisplayStart());
        dto.setPageSize(dt.getiDisplayLength());
        RestStatus r = CommonService.common(dto, "cs/pwd/reset-history", "重置密码历史操作记录", (User) request.getSession().getAttribute(Constant.SESSION_USER));
        
        dt.setAaData((List<Biz>)r.getResponseData());
        dt.setiTotalDisplayRecords(Integer.parseInt(r.getErrorCode()));
        
        return dt;
    }
    
    /**
     * 批量操作记录
     * @param dto
     * @param request
     * @return
     */
    @RequestMapping(value = "biz-batch-history", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<BizBatch> bizBatchHistory(DataTable<BizBatch> dt, ReqCommonDTO dto, HttpServletRequest request) {
        //RestStatus rs = new RestStatus(true);
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        try {
            Map<String, Object> searchMap = new HashMap<String, Object>();
            searchMap.put("phone", dto.getPhone());
            List<String> bizTypes = new ArrayList<>();
            
            /**参考 @link BizType.*/
            bizTypes.add(BizType.INTERNET_FUNCTION.getCode());
            bizTypes.add(BizType.SMS_FUNCTION.getCode());
            bizTypes.add(BizType.MMS_FUNCTION.getCode());
            bizTypes.add(BizType.BLOCK_OPEN_CLOSE.getCode());
            
            searchMap.put("userId", user.getId()+"");
            searchMap.put("bizTypes", bizTypes);
            // 分页
            searchMap.put("limit",dt.getiDisplayStart());
            searchMap.put("pageSize",dt.getiDisplayLength());
            
            List<BizBatch> list = bizBatchService.list(searchMap);
            dt.setAaData(list);
            dt.setiTotalDisplayRecords(bizBatchService.count(searchMap));
            
            //rs.setResponseData(list);
        } catch (Exception e) {
            e.printStackTrace();
            
            /*rs.setStatus(Boolean.FALSE);
            rs.setErrorCode("999");
            rs.setErrorMessage(e.getMessage());*/
        }
        
        return dt;
    }
    
    /**
     * 强停、强开
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @RequestMapping(value = "force-stop-deal", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus forceStopDeal(String network, ForceStopDealRequest forceStopDeal, HttpServletRequest request) {
        RestStatus rs = new RestStatus(true);
        
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        
        try {
            if("YD".equals(network)) {
                if("4".equals(forceStopDeal.getOperFlag())) {//4 强制停机
                    TCoerciveBlockBOSSBO blockbo = new TCoerciveBlockBOSSBO();
                    blockbo.setMSISDN("86" + forceStopDeal.getServiceId());
                    rs = bossMobileService.CoerciveBlockBOSS(blockbo , user);
                } else {//5 强制开机
                    TCoerciveReactBOSSBO recatbo = new TCoerciveReactBOSSBO();
                    recatbo.setMSISDN("86" + forceStopDeal.getServiceId());
                    rs = bossMobileService.CoerciveReactBOSS(recatbo , user);
                }
            } else {
                rs = bossService.forceStopDeal(forceStopDeal, user);
            }
            
            String bizType=BizType.BLOCK_OPEN_CLOSE.getCode(),bizName=BizType.BLOCK_OPEN_CLOSE.getName(),operationType="";
            if("4".equals(forceStopDeal.getOperFlag())) {//4 强制停机
                operationType = "1";
            } else if ("5".equals(forceStopDeal.getOperFlag())) {//5 强制开机
                operationType = "0";
            }
            if(rs.getStatus()) {
                //添加强停/强开的记录到业务办理表中
                Biz b = new Biz();
                b.setOperationType(operationType);
                b.setPhone(forceStopDeal.getServiceId());
                b.setBizType(bizType);
                b.setBizName(bizName);
                b.setServName(bizName);
                b.setIp(IpUtil.getIp(request));
                b.setRemark(user.getId()+"");
                b.setReason(rs.getErrorMessage());
                b.setStatus(StatusType.SUCCESS.getCode());
                csUserService.insertBiz(b);
            }
        } catch (Exception e) {
            e.printStackTrace();
            
            rs.setStatus(Boolean.FALSE);
            rs.setErrorCode("999");
            rs.setErrorMessage(e.getMessage());
        }
        
        return rs;
    }
    
    /**
     * 上传文件到服务器待定时任务扫描处理
     * @param file
     * @param request
     * @param biz
     * @return
     */
    @RequestMapping(value={"file-batch/upload"}, method={RequestMethod.POST},produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String fileBatch(String network, @RequestParam("uploadFile") MultipartFile file, HttpServletRequest request, BizBatch biz) {
        String result = "文件上传成功!";
        try {
            //FtpUtil.uploadFile(FtpUtil.getFtpClient(SysConfig.getValue("FtpIp"), Integer.parseInt(SysConfig.getValue("FtpPort")), SysConfig.getValue("FtpBossBiz"), SysConfig.getValue("FtpBossBizPwd")),
                    //SysConfig.getValue("FtpBossBizDatPatch"), file.getOriginalFilename(), file.getInputStream());
            
            User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream(), "UTF-8"));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if(line.trim().length()!=11) {
                    return "文件中存在不正确的数据格式，请修改正确后重新上传!";
                }
            }
            
            //上传文件到服务器
            String fileFullPath = com.agent.file.utils.FileUtil.saveImageFile(file, imageURL, Setting.KFFORCEBATCH, file.getOriginalFilename());
            
            String dirStr = imageURL + Setting.KFFORCEBATCHTASK + File.separator + network;
            File dir = new File(dirStr);
            if(!dir.exists()) {
                dir.mkdirs();
            }
            //复制服务器的文件到定时任务目录中
            FileUtil.copyFile(imageURL+fileFullPath, dirStr + File.separator + user.getId()+"@@"+user.getNickName()+"@@"+ biz.getBizType()+"@@"+ file.getOriginalFilename());
            
            String bizType="",bizName="",operationType="";
            if("1".equals(biz.getBizType())) {//开通短彩信
                bizType=BizType.SMS_FUNCTION.getCode();
                bizName=BizType.SMS_FUNCTION.getName();
                operationType = "0";
            } else if("2".equals(biz.getBizType())) {//关闭短彩信
                bizType=BizType.SMS_FUNCTION.getCode();
                bizName=BizType.SMS_FUNCTION.getName();
                operationType = "1";
            } else if("3".equals(biz.getBizType())) {//开通上网
                bizType=BizType.INTERNET_FUNCTION.getCode();
                bizName=BizType.INTERNET_FUNCTION.getName();
                operationType = "0";
            } else if("4".equals(biz.getBizType())) {//关闭上网
                bizType=BizType.INTERNET_FUNCTION.getCode();
                bizName=BizType.INTERNET_FUNCTION.getName();
                operationType = "1";
            } else if("5".equals(biz.getBizType())) {//强开
                bizType=BizType.BLOCK_OPEN_CLOSE.getCode();
                bizName=BizType.BLOCK_OPEN_CLOSE.getName();
                operationType = "0";
            } else if("6".equals(biz.getBizType())) {//强停
                bizType=BizType.BLOCK_OPEN_CLOSE.getCode();
                bizName=BizType.BLOCK_OPEN_CLOSE.getName();
                operationType = "1";
            }
            BizBatch bizBatch = new BizBatch();
            bizBatch.setOperationType(Integer.parseInt(operationType));
            bizBatch.setUserId(user.getId());
            bizBatch.setBizType(bizType);
            bizBatch.setBizName(bizName);
            bizBatch.setReason("");
            bizBatch.setPhone("文件上传号码");
            bizBatch.setFilepath(fileFullPath);
            bizBatch.setCreatetime(DateUtil.dateToStr(new Date(), "yyyy-MM-dd HH:mm:ss"));
            bizBatchService.insert(bizBatch);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            result = e.getMessage();
        }
        return result;
    }
    
    /**
     * 2.2.22   开通关闭短信，上网功能
     * @param dto
     * @param request
     * @return
     * @author Shanghuaxin
     */
    @RequestMapping(value = "do-product-change", method = RequestMethod.POST)
    @ResponseBody
    public RestStatus doProductChange(String network, int optType, String phoneBatch, ProductChangeVO vo, HttpServletRequest request) {
        RestStatus rs = new RestStatus(true);
        
        User user = (User) request.getSession().getAttribute(Constant.SESSION_USER);
        String uploadFileName = phoneBatch;
        try {
            //表示批文件上传处理
            if(optType==1) {
                File file = new File(imageURL + phoneBatch);
                if(!file.exists()) {
                    rs.setStatus(false);
                    rs.setErrorMessage("没有找到相应的批处理文件，请刷新页面重试!");
                    return rs;
                }
                //uploadFileName = phoneBatch;
                phoneBatch = com.agent.util.FileUtil.read(imageURL + phoneBatch, "UTF-8");
            }
            
            TSMSSwitchRequest smsRequest = new TSMSSwitchRequest();
            TMMSSwitchRequest mmsRequest = new TMMSSwitchRequest();
            TGPRSSwitchRequest gprsSwitchRequest = new TGPRSSwitchRequest();
            
            String bizType="", bizName="", operationType="";
            if("24".equals(vo.getProductId())) {//24 短信
                bizType = BizType.SMS_FUNCTION.getCode();
                bizName = BizType.SMS_FUNCTION.getName();
                if("0".equals(vo.getOperKind())) {//退
                    operationType = "1";
                    smsRequest.setOperType("0");
                } else {//开
                    operationType = "0";
                    smsRequest.setOperType("1");
                }
            } else if("25".equals(vo.getProductId())) {//25 彩信
                bizType = BizType.MMS_FUNCTION.getCode();
                bizName = BizType.MMS_FUNCTION.getName();
                if("LT".equals(network)) {
                    // 联通短信、彩信一样
                    vo.setProductId("24");
                }
                if("0".equals(vo.getOperKind())) {//退
                    operationType = "1";
                    mmsRequest.setOperType("0");
                } else {//开
                    operationType = "0";
                    mmsRequest.setOperType("1");
                }
            } else if ("102".equals(vo.getProductId())) {//102 上网
                bizType = BizType.INTERNET_FUNCTION.getCode();
                bizName = BizType.INTERNET_FUNCTION.getName();
                if("0".equals(vo.getOperKind())) {//退
                    operationType = "1";
                    gprsSwitchRequest.setOperType("0");
                } else {//开
                    operationType = "0";
                    gprsSwitchRequest.setOperType("1");
                }
            }
            
            
            //记录批处理信息
            int successCnt=0,failCnt=0;
            String failMsg = "";
            //if(phoneBatch.contains("\n")) {
                //批量处理
                String phones[] = phoneBatch.split("\n");
                for(String phone : phones) {
                    if(Utils.isEmptyString(phone)) continue;
                    
                    if("YD".equals(network)) {
                        if("24".equals(vo.getProductId())) {//短信
                            smsRequest.setMSISDN("86"+phone);
                            rs = bossMobileService.smsSwitch(smsRequest, user);
                        } else if("25".equals(vo.getProductId())) {//彩信
                            mmsRequest.setMSISDN("86"+phone);
                            rs = bossMobileService.mmsSwitch(mmsRequest, user);
                        } else if ("102".equals(vo.getProductId())) {//上网
                            gprsSwitchRequest.setMSISDN("86"+phone);
                            rs = bossMobileService.gprsSwitch(gprsSwitchRequest, user);
                        }
                    } else {
                        List<ProductChangeVO> list = new ArrayList<ProductChangeVO>();
                        list.add(vo);
                        //调用接口
                        rs = bossService.doProductChange(phone, list, user);
                    }
                    
                    if(rs.getStatus()) {
                        successCnt ++;
                    } else {
                        failCnt ++;
                        failMsg += "<br />&nbsp;&nbsp;&nbsp;&nbsp;"+phone+","+rs.getErrorMessage()+"<br />";
                    }
                    
                    //添加批开通/关闭的记录到业务办理表中
                    Biz b = new Biz();
                    b.setPhone(phone);
                    b.setBizType(bizType);
                    b.setBizName(bizName);
                    b.setServName(bizName);
                    b.setOperationType(operationType);
                    b.setIp(IpUtil.getIp(request));
                    b.setRemark(user.getId()+"");
                    b.setReason("");
                    b.setStatus(rs.getStatus()?StatusType.SUCCESS.getCode():StatusType.FAILURE.getCode());
                    csUserService.insertBiz(b);
                }
                
                String responseData = "合计处理个数："+(successCnt + failCnt)+"<br />";
                if(successCnt>0) {
                    responseData += "成功个数："+successCnt+"<br />";
                }
                if(failCnt>0) {
                    responseData += "失败个数："+failCnt+"<br />&nbsp;&nbsp;失败原因："+failMsg;
                }
                
                rs.setStatus(true);
                rs.setResponseData(responseData);
                phoneBatch = "手动输入号码";
            /*} else {
                if("YD".equals(network)) {
                    
                    smsRequest.setMSISDN("86"+phoneBatch);
                    gprsSwitchRequest.setMSISDN("86"+phoneBatch);
                    
                    if("24".equals(vo.getProductId())) {//短信
                        rs = bossMobileService.smsSwitch(smsRequest, user);
                    } else if ("102".equals(vo.getProductId())) {//上网
                        rs = bossMobileService.gprsSwitch(gprsSwitchRequest, user);
                    }
                } else {
                    //单个处理
                    List<ProductChangeVO> list = new ArrayList<ProductChangeVO>();
                    list.add(vo);
                    
                    rs = bossService.doProductChange(phoneBatch, list, user);
                }
                if(!rs.getStatus()) {
                    failMsg = phoneBatch+","+rs.getErrorMessage();
                }
                
                //添加批开通/关闭的记录到业务办理表中
                Biz b = new Biz();
                b.setOperationType(operationType);
                b.setPhone(phoneBatch);
                b.setBizType(bizType);
                b.setBizName(bizName);
                b.setIp(IpUtil.getIp(request));
                b.setRemark(user.getId()+"");
                b.setReason("");
                b.setStatus(rs.getStatus()?StatusType.SUCCESS.getCode():StatusType.FAILURE.getCode());
                csUserService.insertBiz(b);
            }*/
            
            BizBatch bizBatch = new BizBatch();
            bizBatch.setOperationType(Integer.parseInt(operationType));
            bizBatch.setUserId(user.getId());
            bizBatch.setBizType(bizType);
            bizBatch.setBizName(bizName);
            bizBatch.setReason(failMsg);
            bizBatch.setPhone(phoneBatch);
            bizBatch.setFilepath(uploadFileName);
            bizBatch.setCreatetime(DateUtil.dateToStr(new Date(), "yyyy-MM-dd HH:mm:ss"));
            bizBatchService.insert(bizBatch);
        } catch (Exception e) {
            e.printStackTrace();
            
            rs.setStatus(Boolean.FALSE);
            rs.setErrorCode("999");
            rs.setErrorMessage(e.getMessage());
        }
        
        return rs;
    }
    
    /**
     * 上传文件
     * 此方法已经过期，没有使用
     * @param file
     * @param response
     * @param request
     * @param imgType
     * @return
     * @throws java.io.IOException
     */
    @Deprecated
    @RequestMapping(value={"sms-internet/upload"}, method={RequestMethod.POST},produces={"text/html;charset=UTF-8"})
    @ResponseBody
    public String upload(@RequestParam("uploadFile") MultipartFile file) throws IOException {
        String result = "error@_@";
        try {
            String fileName = file.getOriginalFilename();
            if (!Utils.isEmptyString(fileName)) {
                fileName = DateUtil.dateToStr(new Date(), "yyyyMMddHHmmssSSS")+".txt";
                
                String filePath = Setting.KFBATCH;
                
                File upFile = new File(imageURL + File.separator +filePath + File.separator + fileName);
                if(!upFile.getParentFile().exists()){
                    upFile.getParentFile().mkdirs();
                }
                //上传文件
                String fileFullPath = com.agent.file.utils.FileUtil.saveImageFile(file, imageURL, filePath, fileName);
                
                return fileFullPath;
            } else {
                result += "上传的文件不能为空！";
            }
        } catch (Exception e) {
            logger.error("上传文件异常："+e.getMessage(), e);
            result += "系统异常，请联系客服！";
        }
        return result;
    }
    
}
