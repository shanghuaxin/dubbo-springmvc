package com.agent.cs.dto;

/**
 * 联通撤销工单实体data类
 * @author FengLu
 *
 */
public class UnicomOrderRevokeDataDTO {
    // 订单ID
    private String support_id;
    // 撤销原因
    private String reason;
    
    public String getSupport_id() {
        return support_id;
    }
    public void setSupport_id(String support_id) {
        this.support_id = support_id;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
}
