package com.agent.cs.dto;

/**
 * 工单实体
 * @author FengLu
 *
 */
public class SupportContent {
    // 工单级别 emergency：紧急  common：一般
    private String support_level;
    // 问题发生省份编码
    private String issue_province;
    // 问题发生地市编码
    private String issue_city;
    // 用户号码归属省编码
    private String phone_number_province;
    // 用户号码归属地市编码
    private String phone_number_city;
    // 重复派送工单标记 true：重复投诉 false：非重复投诉
    private boolean repetition;
    // 前期派送工单号码
    private String original_support_id;
    // 重复派单说明
    private String repetition_description;
    // 核查处理情况
    private String present_condition;
    // 协查处理需求
    private String requirements;
    // 投诉问题描述
    private String issue_description;
    // 网络使用类工单
    private NetworkOrderDTO network_data;
    // 计费业务类工单
    private BillingOrderDTO billing_data;
    // 充值类工单
    private RechargeOrderDTO recharge_data;
    // 增值业务类工单
    private VASOrderDTO vas_data;
    // 开通类工单
    private AccountOrderDTO account_data;
    // 漏电提醒类工单
    private MishuOrderDTO mishu_data;
    
    public String getSupport_level() {
        return support_level;
    }
    public void setSupport_level(String support_level) {
        this.support_level = support_level;
    }
    public String getIssue_province() {
        return issue_province;
    }
    public void setIssue_province(String issue_province) {
        this.issue_province = issue_province;
    }
    public String getIssue_city() {
        return issue_city;
    }
    public void setIssue_city(String issue_city) {
        this.issue_city = issue_city;
    }
    public String getPhone_number_province() {
        return phone_number_province;
    }
    public void setPhone_number_province(String phone_number_province) {
        this.phone_number_province = phone_number_province;
    }
    public String getPhone_number_city() {
        return phone_number_city;
    }
    public void setPhone_number_city(String phone_number_city) {
        this.phone_number_city = phone_number_city;
    }
    public boolean isRepetition() {
        return repetition;
    }
    public void setRepetition(boolean repetition) {
        this.repetition = repetition;
    }
    public String getOriginal_support_id() {
        return original_support_id;
    }
    public void setOriginal_support_id(String original_support_id) {
        this.original_support_id = original_support_id;
    }
    public String getRepetition_description() {
        return repetition_description;
    }
    public void setRepetition_description(String repetition_description) {
        this.repetition_description = repetition_description;
    }
    public String getPresent_condition() {
        return present_condition;
    }
    public void setPresent_condition(String present_condition) {
        this.present_condition = present_condition;
    }
    public String getRequirements() {
        return requirements;
    }
    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }
    public String getIssue_description() {
        return issue_description;
    }
    public void setIssue_description(String issue_description) {
        this.issue_description = issue_description;
    }
    public NetworkOrderDTO getNetwork_data() {
        return network_data;
    }
    public void setNetwork_data(NetworkOrderDTO network_data) {
        this.network_data = network_data;
    }
    public BillingOrderDTO getBilling_data() {
        return billing_data;
    }
    public void setBilling_data(BillingOrderDTO billing_data) {
        this.billing_data = billing_data;
    }
    public RechargeOrderDTO getRecharge_data() {
        return recharge_data;
    }
    public void setRecharge_data(RechargeOrderDTO recharge_data) {
        this.recharge_data = recharge_data;
    }
    public VASOrderDTO getVas_data() {
        return vas_data;
    }
    public void setVas_data(VASOrderDTO vas_data) {
        this.vas_data = vas_data;
    }
    public AccountOrderDTO getAccount_data() {
        return account_data;
    }
    public void setAccount_data(AccountOrderDTO account_data) {
        this.account_data = account_data;
    }
    public MishuOrderDTO getMishu_data() {
        return mishu_data;
    }
    public void setMishu_data(MishuOrderDTO mishu_data) {
        this.mishu_data = mishu_data;
    }
}
