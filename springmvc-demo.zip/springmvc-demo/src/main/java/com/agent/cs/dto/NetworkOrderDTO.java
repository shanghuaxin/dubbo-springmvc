package com.agent.cs.dto;

/**
 * 网络使用类工单
 * @author FengLu
 *
 */
public class NetworkOrderDTO extends OrderBaseDTO {
    // 业务类别 1：语音业务 2：数据业务 3：短信业务
    private Integer network_type;
    // 信号情况 1：正常 2：信号弱/不稳定 3：无信号 语音业务必填
    private Integer signal;
    // 故障现象 1：拨打特定号码有问题  2：拨打所有号码有问题 （语音业务必填）
    private Integer symptom;
    // 无法主叫 1：忙音 2：号码为空/错误 3：无法连接/呼叫失败  4：其他 （语音业务必填）
    private Integer not_calling;
    
    public Integer getNetwork_type() {
        return network_type;
    }
    public void setNetwork_type(Integer network_type) {
        this.network_type = network_type;
    }
    public Integer getSignal() {
        return signal;
    }
    public void setSignal(Integer signal) {
        this.signal = signal;
    }
    public Integer getSymptom() {
        return symptom;
    }
    public void setSymptom(Integer symptom) {
        this.symptom = symptom;
    }
    public Integer getNot_calling() {
        return not_calling;
    }
    public void setNot_calling(Integer not_calling) {
        this.not_calling = not_calling;
    }
}
