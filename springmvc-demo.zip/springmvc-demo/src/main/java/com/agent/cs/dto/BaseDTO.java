package com.agent.cs.dto;

import java.io.Serializable;

/**
 * 基础DTO，接收类都继承它
 */
public class BaseDTO implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 2313359379634560918L;
    private Integer pageNum;//页数
    private Integer pageSize;//每页数据条数
    
    
    public Integer getPageNum() {
        return pageNum;
    }
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
