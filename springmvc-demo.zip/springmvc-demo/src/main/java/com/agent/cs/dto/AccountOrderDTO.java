package com.agent.cs.dto;

/**
 * 开通类工单实体
 * @author FengLu
 *
 */
public class AccountOrderDTO extends OrderBaseDTO {
    // API名称
    private String api_name;
    // 流水号
    private String serial_number;
    // 订单ID（做开通类业务时boss返回的）
    private String order_id;
    
    public String getApi_name() {
        return api_name;
    }
    public void setApi_name(String api_name) {
        this.api_name = api_name;
    }
    public String getSerial_number() {
        return serial_number;
    }
    public void setSerial_number(String serial_number) {
        this.serial_number = serial_number;
    }
    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }
}
