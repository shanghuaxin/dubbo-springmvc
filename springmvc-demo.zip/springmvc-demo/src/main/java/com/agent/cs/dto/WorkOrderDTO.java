package com.agent.cs.dto;

import java.util.Date;

import com.agent.common.enumeration.WorkOrderStatusType;
import com.agent.common.enumeration.WorkOrderSupportType;
import com.agent.util.DateUtil;

public class WorkOrderDTO {
    
    // id
    private Integer id;
    // 订单ID
    private String supportId;
    // 工单类型 01：网络使用类 02：服务开通变更类 03：计费类 04：充值类 05：增值业务类 06：漏电提醒类
    private String supportType;
    // 用户手机姓名
    private String complainName;
    // 用户手机号码
    private Long complainPhone;
    // 用户联系人姓名
    private String complainContactName;
    // 用户联系人电话
    private String complainContactPhone;
    // 转售企业联系人
    private String mvnoContactName;
    // 转售企业联系电话
    private String mvnoContactPhone;
    // 问题发生城市
    private String issueCity;
    
    // 工单级别 emergency：紧急  common：一般
    private String supportLevel;
    // 重复派送工单标记 1：重复投诉 0：非重复投诉
    private String repetition;
    // 前原派送工单号码
    private String original_support_id;
    // 重复派单说明
    private String repetition_description;
    // 核查处理情况
    private String present_condition;
    // 协查处理需求
    private String requirements;
    // 投诉问题描述
    private String issueDescription;
    // 工单实体，存放实体对象的json格式
    private String supportContent;
    // 状态 0：待提交 1：待回复 2：已回复  3：已撤回 4:已删除  5:待重发
    private Integer status;
    // 反馈状态 01：已解决 02：退单
    private String feedbackStatus;
    // 反馈内容
    private String feedbackContent;
    // 反馈时间
    private Date feedbackTime;
    // 反馈联系人
    private String feedbackContactName;
    // 反馈联系人电话
    private String feedbackContactPhone;
    // 反馈备注
    private String feedbackRemark;
    // 撤回原因
    private String revokeReason;
    
    /**
     * 网络使用类工单
     */
    // 业务类别 1：语音业务 2：数据业务 3：短信业务
    private Integer network_type;
    // 信号情况 1：正常 2：信号弱/不稳定 3：无信号 语音业务必填
    private Integer signal;
    // 故障现象 1：拨打特定号码有问题  2：拨打所有号码有问题 （语音业务必填）
    private Integer symptom;
    // 无法主叫 1：忙音 2：号码为空/错误 3：无法连接/呼叫失败  4：其他 （语音业务必填）
    private Integer not_calling;
    
    /**
     * 计费类工单
     */
    // 话单类型  1：语音话单  2：数据话单  3：短信话单  4：增值业务话单
    private Integer cdr_type;
    // 话单文件名
    private String cdr_file;
    // 话单编号
    private String cdr_number;
    
    /**
     * 充值类工单
     */
    // 是否到帐 true：到帐 false：未到帐
    private String paying_arrive;
    // 充值号码
    private String phone_number;
    // 一卡充卡号
    private String card_number;
    // 充值时间
    private String recharge_date;
    // 业务流水号
    private String process_serial;
    // 充值金额 （单位厘）
    private Integer payamount;
    
    /**
     * 增值业务类工单
     */
    // 手机操作系统
    private String system_type;
    // 增值业务类型 1：炫铃 0：其他
    private Integer vas_type;
    // 业务描述
    private String vas_description;
    
    /**
     * 开通类工单
     */
    // API名称
    private String api_name;
    // 流水号
    private String serial_number;
    // 订单ID（做开通类业务时boss返回的）
    private String order_id;
    
    /**
     * 漏电提醒类工单
     */
    
    // 投诉问题描述
    private String issue_description;
    
    private Integer createId;
    private Date createTime;
    private Integer updateId;
    private Date updateTime;
    
    /* 扩展属性 begin */
    // 当前页
    private Integer pageIndex;
    // 页面大小
    private Integer pageSize;
    // 创建人姓名
    private String nickName;
    // 工单提交开始时间
    private String startDate;
    // 工单提交结束时间
    private String endDate;
    // 工单反馈开始时间
    private String feedbackStartDate;
    // 工单反馈结束时间
    private String feedbackEndDate;
    /* 扩展属性 end */
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getSupportId() {
        return supportId;
    }
    public void setSupportId(String supportId) {
        this.supportId = supportId;
    }
    public String getSupportType() {
        return supportType;
    }
    public String getSupportTypeStr() {
        if (null != supportType) {
            return WorkOrderSupportType.getName(supportType);
        }
        return "";
    }
    public void setSupportType(String supportType) {
        this.supportType = supportType;
    }
    public String getComplainName() {
        return complainName;
    }
    public void setComplainName(String complainName) {
        this.complainName = complainName;
    }
    public Long getComplainPhone() {
        return complainPhone;
    }
    public void setComplainPhone(Long complainPhone) {
        this.complainPhone = complainPhone;
    }
    public String getComplainContactName() {
        return complainContactName;
    }
    public void setComplainContactName(String complainContactName) {
        this.complainContactName = complainContactName;
    }
    public String getComplainContactPhone() {
        return complainContactPhone;
    }
    public void setComplainContactPhone(String complainContactPhone) {
        this.complainContactPhone = complainContactPhone;
    }
    public String getMvnoContactName() {
        return mvnoContactName;
    }
    public void setMvnoContactName(String mvnoContactName) {
        this.mvnoContactName = mvnoContactName;
    }
    public String getMvnoContactPhone() {
        return mvnoContactPhone;
    }
    public void setMvnoContactPhone(String mvnoContactPhone) {
        this.mvnoContactPhone = mvnoContactPhone;
    }
    public String getIssueCity() {
        return issueCity;
    }
    public void setIssueCity(String issueCity) {
        this.issueCity = issueCity;
    }
    public String getSupportLevel() {
        return supportLevel;
    }
    public String getSupportLevelStr() {
        String supportLevelStr = "";
        if (null != supportLevel) {
            if ("common".equals(supportLevel)) {
                supportLevelStr = "一般";
            } else if ("emergency".equals(supportLevel)) {
                supportLevelStr = "紧急";
            }
        }
        return supportLevelStr;
    }
    public void setSupportLevel(String supportLevel) {
        this.supportLevel = supportLevel;
    }
    public String getRepetition() {
        return repetition;
    }
    public void setRepetition(String repetition) {
        this.repetition = repetition;
    }
    public String getOriginal_support_id() {
        return original_support_id;
    }
    public void setOriginal_support_id(String original_support_id) {
        this.original_support_id = original_support_id;
    }
    public String getRepetition_description() {
        return repetition_description;
    }
    public void setRepetition_description(String repetition_description) {
        this.repetition_description = repetition_description;
    }
    public String getPresent_condition() {
        return present_condition;
    }
    public void setPresent_condition(String present_condition) {
        this.present_condition = present_condition;
    }
    public String getRequirements() {
        return requirements;
    }
    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }
    public String getIssueDescription() {
        return issueDescription;
    }
    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }
    public String getSupportContent() {
        return supportContent;
    }
    public void setSupportContent(String supportContent) {
        this.supportContent = supportContent;
    }
    public Integer getStatus() {
        return status;
    }
    public String getStatusStr() {
        if (null != status) {
            return WorkOrderStatusType.getName(status);
        }
        return "";
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getFeedbackStatus() {
        return feedbackStatus;
    }
    public String getFeedbackStatusStr() {
        if (null != feedbackStatus) {
            if ("01".equals(feedbackStatus)) {
                return "已解决";
            } else if ("02".equals(feedbackStatus)) {
                return "退单";
            }
        }
        return "";
    }
    public void setFeedbackStatus(String feedbackStatus) {
        this.feedbackStatus = feedbackStatus;
    }
    public String getFeedbackContent() {
        return feedbackContent;
    }
    public void setFeedbackContent(String feedbackContent) {
        this.feedbackContent = feedbackContent;
    }
    public Date getFeedbackTime() {
        return feedbackTime;
    }
    public String getFeedbackTimeStr() {
        return feedbackTime !=null ? DateUtil.getInstance().getDateStr(feedbackTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setFeedbackTime(Date feedbackTime) {
        this.feedbackTime = feedbackTime;
    }
    public String getFeedbackContactName() {
        return feedbackContactName;
    }
    public void setFeedbackContactName(String feedbackContactName) {
        this.feedbackContactName = feedbackContactName;
    }
    public String getFeedbackContactPhone() {
        return feedbackContactPhone;
    }
    public void setFeedbackContactPhone(String feedbackContactPhone) {
        this.feedbackContactPhone = feedbackContactPhone;
    }
    public String getFeedbackRemark() {
        return feedbackRemark;
    }
    public void setFeedbackRemark(String feedbackRemark) {
        this.feedbackRemark = feedbackRemark;
    }
    public String getRevokeReason() {
        return revokeReason;
    }
    public void setRevokeReason(String revokeReason) {
        this.revokeReason = revokeReason;
    }
    public Integer getNetwork_type() {
        return network_type;
    }
    public void setNetwork_type(Integer network_type) {
        this.network_type = network_type;
    }
    public Integer getSignal() {
        return signal;
    }
    public void setSignal(Integer signal) {
        this.signal = signal;
    }
    public Integer getSymptom() {
        return symptom;
    }
    public void setSymptom(Integer symptom) {
        this.symptom = symptom;
    }
    public Integer getNot_calling() {
        return not_calling;
    }
    public void setNot_calling(Integer not_calling) {
        this.not_calling = not_calling;
    }
    public Integer getCdr_type() {
        return cdr_type;
    }
    public void setCdr_type(Integer cdr_type) {
        this.cdr_type = cdr_type;
    }
    public String getCdr_file() {
        return cdr_file;
    }
    public void setCdr_file(String cdr_file) {
        this.cdr_file = cdr_file;
    }
    public String getCdr_number() {
        return cdr_number;
    }
    public void setCdr_number(String cdr_number) {
        this.cdr_number = cdr_number;
    }
    public String getPaying_arrive() {
        return paying_arrive;
    }
    public void setPaying_arrive(String paying_arrive) {
        this.paying_arrive = paying_arrive;
    }
    public String getPhone_number() {
        return phone_number;
    }
    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
    public String getCard_number() {
        return card_number;
    }
    public void setCard_number(String card_number) {
        this.card_number = card_number;
    }
    public String getRecharge_date() {
        return recharge_date;
    }
    public void setRecharge_date(String recharge_date) {
        this.recharge_date = recharge_date;
    }
    public String getProcess_serial() {
        return process_serial;
    }
    public void setProcess_serial(String process_serial) {
        this.process_serial = process_serial;
    }
    public Integer getPayamount() {
        return payamount;
    }
    public void setPayamount(Integer payamount) {
        this.payamount = payamount;
    }
    public String getSystem_type() {
        return system_type;
    }
    public void setSystem_type(String system_type) {
        this.system_type = system_type;
    }
    public Integer getVas_type() {
        return vas_type;
    }
    public void setVas_type(Integer vas_type) {
        this.vas_type = vas_type;
    }
    public String getVas_description() {
        return vas_description;
    }
    public void setVas_description(String vas_description) {
        this.vas_description = vas_description;
    }
    public String getApi_name() {
        return api_name;
    }
    public void setApi_name(String api_name) {
        this.api_name = api_name;
    }
    public String getSerial_number() {
        return serial_number;
    }
    public void setSerial_number(String serial_number) {
        this.serial_number = serial_number;
    }
    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }
    public String getIssue_description() {
        return issue_description;
    }
    public void setIssue_description(String issue_description) {
        this.issue_description = issue_description;
    }
    public Integer getCreateId() {
        return createId;
    }
    public void setCreateId(Integer createId) {
        this.createId = createId;
    }
    public Date getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    public Integer getUpdateId() {
        return updateId;
    }
    public void setUpdateId(Integer updateId) {
        this.updateId = updateId;
    }
    public Date getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    public Integer getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public String getNickName() {
        return nickName;
    }
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public String getFeedbackStartDate() {
        return feedbackStartDate;
    }
    public void setFeedbackStartDate(String feedbackStartDate) {
        this.feedbackStartDate = feedbackStartDate;
    }
    public String getFeedbackEndDate() {
        return feedbackEndDate;
    }
    public void setFeedbackEndDate(String feedbackEndDate) {
        this.feedbackEndDate = feedbackEndDate;
    }
}
