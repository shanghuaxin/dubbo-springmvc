package com.agent.cs.dto;

public class ReqCommonDTO extends CsReqPropertyDTO {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    //详单类型
    private String type;
    //号码对应的套餐
    private String subsPlanName;
    //查询日期
    private String beginDate;
    //业务办理状态
    private String status;
    
    //查询历史日志类型
    private String bizType;
    
    //重置密码
    private String newPwd;
    private String notes;
    //业务办理
    private String servId = "";    //业务id
    private String oldServId = "";    //历史业务id
    private String shiftPhone; //呼叫转移号码
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubsPlanName() {
        return subsPlanName;
    }

    public void setSubsPlanName(String subsPlanName) {
        this.subsPlanName = subsPlanName;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNewPwd() {
        return newPwd;
    }

    public void setNewPwd(String newPwd) {
        this.newPwd = newPwd;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getServId() {
        return servId;
    }

    public void setServId(String servId) {
        this.servId = servId;
    }

    public String getOldServId() {
        return oldServId;
    }

    public void setOldServId(String oldServId) {
        this.oldServId = oldServId;
    }

    public String getShiftPhone() {
        return shiftPhone;
    }

    public void setShiftPhone(String shiftPhone) {
        this.shiftPhone = shiftPhone;
    }
}
