package com.agent.cs.dto;

/**
 * 联通工单反馈
 * @author FengLu
 */
public class UnicomOrderFeedbackDTO {
    // 调用的API
    private String api_name;
    // 推送时的时间戳
    private String timestamp;
    // 反馈数据
    private UnicomOrderFeedbackDataDTO data;
    
    public String getApi_name() {
        return api_name;
    }
    public void setApi_name(String api_name) {
        this.api_name = api_name;
    }
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    public UnicomOrderFeedbackDataDTO getData() {
        return data;
    }
    public void setData(UnicomOrderFeedbackDataDTO data) {
        this.data = data;
    }
}
