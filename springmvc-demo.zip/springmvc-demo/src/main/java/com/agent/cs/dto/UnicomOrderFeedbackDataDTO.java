package com.agent.cs.dto;

/**
 * 联通工单反馈数据类
 * @author FengLu
 */
public class UnicomOrderFeedbackDataDTO {
    // 工单ID
    private String support_id;
    // 反馈状态  01:已解决  02:退单
    private String status;
    // 反馈内容
    private String content;
    // 反馈时间
    private String feedback_time;
    // 联系电话
    private String phone_number;
    // 联系人
    private String contact;
    // 附件实体
    private String attachment;
    // 备注
    private String remark;
    
    public String getSupport_id() {
        return support_id;
    }
    public void setSupport_id(String support_id) {
        this.support_id = support_id;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getFeedback_time() {
        return feedback_time;
    }
    public void setFeedback_time(String feedback_time) {
        this.feedback_time = feedback_time;
    }
    public String getPhone_number() {
        return phone_number;
    }
    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
    public String getAttachment() {
        return attachment;
    }
    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
