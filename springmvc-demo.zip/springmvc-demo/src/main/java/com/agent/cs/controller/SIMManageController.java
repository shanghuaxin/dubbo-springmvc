package com.agent.cs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.agent.number.dto.IccidPoolListDTO;
import com.agent.number.service.IccidPoolService;

/**
 * SIM卡管理控制器
 * @author FengLu
 *
 */
@Controller
@RequestMapping("simManage")
public class SIMManageController {
    private static Logger logger = LoggerFactory.getLogger(SIMManageController.class);
    
    @Autowired
    public IccidPoolService iccidPoolService;
    
    @RequestMapping("list")
    public String list(HttpServletRequest request, HttpServletResponse response, String iccid, String phone) {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            if (StringUtils.isNotEmpty(iccid)) {
                map.put("iccid", iccid);
            }
            if (StringUtils.isNotEmpty(phone)) {
                map.put("phone", phone);
            }
            // 条件为空，不允许查询
            if (!map.isEmpty()) {
                List<IccidPoolListDTO> iccidPoolList = iccidPoolService.simInfoList(map);
                request.setAttribute("simList", iccidPoolList);
                request.setAttribute("iccid", iccid);
                request.setAttribute("phone", phone);
            }
        } catch (Exception e) {
            logger.error("查询SIM卡信息异常："+e.getMessage(), e);
        }
        return "/views/cs/sim/simList.jsp";
    }
}
