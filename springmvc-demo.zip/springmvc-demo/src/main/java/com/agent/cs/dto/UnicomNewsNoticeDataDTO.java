package com.agent.cs.dto;

/**
 * 联通消息通知
 * @author zhangwei
 *
 */
public class UnicomNewsNoticeDataDTO {
    private String push_id ;// '推送ID',
    private String push_type ;// '推送类型；system_failure：IT故障类,system_cutover：IT割接类,network_failure：网络故障类,network_cutover：网络割接类,notice：通知类,other：其他类',
    private String push_content ;// '信息内容',
    private String push_time ;// '信息时间',
    private String phone_number ;// '联系电话',
    private String contact ;// '联系人',
    private String remark ;// '备注'
    
    public String getPush_id() {
        return push_id;
    }
    public void setPush_id(String push_id) {
        this.push_id = push_id;
    }
    public String getPush_type() {
        return push_type;
    }
    public void setPush_type(String push_type) {
        this.push_type = push_type;
    }
    public String getPush_content() {
        return push_content;
    }
    public void setPush_content(String push_content) {
        this.push_content = push_content;
    }
    public String getPush_time() {
        return push_time;
    }
    public void setPush_time(String push_time) {
        this.push_time = push_time;
    }
    public String getPhone_number() {
        return phone_number;
    }
    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
