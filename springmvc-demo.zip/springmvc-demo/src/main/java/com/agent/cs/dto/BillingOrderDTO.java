package com.agent.cs.dto;

/**
 * 计费类工单实体
 * @author FengLu
 *
 */
public class BillingOrderDTO extends OrderBaseDTO {
    // 话单类型  1：语音话单  2：数据话单  3：短信话单  4：增值业务话单
    private Integer cdr_type;
    // 话单文件名
    private String cdr_file;
    // 话单编号
    private String cdr_number;
    
    public Integer getCdr_type() {
        return cdr_type;
    }
    public void setCdr_type(Integer cdr_type) {
        this.cdr_type = cdr_type;
    }
    public String getCdr_file() {
        return cdr_file;
    }
    public void setCdr_file(String cdr_file) {
        this.cdr_file = cdr_file;
    }
    public String getCdr_number() {
        return cdr_number;
    }
    public void setCdr_number(String cdr_number) {
        this.cdr_number = cdr_number;
    }
}
