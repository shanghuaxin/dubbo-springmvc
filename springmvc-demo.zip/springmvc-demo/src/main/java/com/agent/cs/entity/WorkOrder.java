package com.agent.cs.entity;

import java.util.Date;

import com.agent.common.BaseDomain;
import com.agent.common.enumeration.WorkOrderStatusType;
import com.agent.common.enumeration.WorkOrderSupportType;
import com.agent.util.DateUtil;

public class WorkOrder extends BaseDomain {
    
    private static final long serialVersionUID = -3024931035761922010L;
    // 订单ID
    private String supportId;
    // 工单类型 01：网络使用类 02：服务开通变更类 03：计费类 04：充值类 05：增值业务类 06：漏电提醒类
    private String supportType;
    // 用户手机姓名
    private String complainName;
    // 用户手机号码
    private Long complainPhone;
    // 用户联系人姓名
    private String complainContactName;
    // 用户联系人电话
    private String complainContactPhone;
    // 转售企业联系人
    private String mvnoContactName;
    // 转售企业联系电话
    private String mvnoContactPhone;
    // 工单级别 emergency：紧急  common：一般
    private String supportLevel;
    // 投诉问题描述
    private String issueDescription;
    // 工单实体，存放实体对象的json格式
    private String requestContent;
    // VOP返回的参数json格式
    private String responseContent;
    // 状态 0：待提交 1：待回复 2：已回复  3：已撤回 4:已删除  5:待重发
    private Integer status;
    // 反馈状态 01：已解决 02：退单
    private String feedbackStatus;
    // 反馈内容
    private String feedbackContent;
    // 反馈时间
    private Date feedbackTime;
    // 反馈联系人
    private String feedbackContactName;
    // 反馈联系人电话
    private String feedbackContactPhone;
    // 反馈备注
    private String feedbackRemark;
    // 撤回原因
    private String revokeReason;
    
    public String getSupportId() {
        return supportId;
    }
    public void setSupportId(String supportId) {
        this.supportId = supportId;
    }
    public String getSupportType() {
        return supportType;
    }
    public String getSupportTypeStr() {
        if (null != supportType) {
            return WorkOrderSupportType.getName(supportType);
        }
        return "";
    }
    public void setSupportType(String supportType) {
        this.supportType = supportType;
    }
    public String getComplainName() {
        return complainName;
    }
    public void setComplainName(String complainName) {
        this.complainName = complainName;
    }
    public Long getComplainPhone() {
        return complainPhone;
    }
    public void setComplainPhone(Long complainPhone) {
        this.complainPhone = complainPhone;
    }
    public String getComplainContactName() {
        return complainContactName;
    }
    public void setComplainContactName(String complainContactName) {
        this.complainContactName = complainContactName;
    }
    public String getComplainContactPhone() {
        return complainContactPhone;
    }
    public void setComplainContactPhone(String complainContactPhone) {
        this.complainContactPhone = complainContactPhone;
    }
    public String getMvnoContactName() {
        return mvnoContactName;
    }
    public void setMvnoContactName(String mvnoContactName) {
        this.mvnoContactName = mvnoContactName;
    }
    public String getMvnoContactPhone() {
        return mvnoContactPhone;
    }
    public void setMvnoContactPhone(String mvnoContactPhone) {
        this.mvnoContactPhone = mvnoContactPhone;
    }
    public String getSupportLevel() {
        return supportLevel;
    }
    public String getSupportLevelStr() {
        String supportLevelStr = "";
        if (null != supportLevel) {
            if ("common".equals(supportLevel)) {
                supportLevelStr = "一般";
            } else if ("emergency".equals(supportLevel)) {
                supportLevelStr = "紧急";
            }
        }
        return supportLevelStr;
    }
    public void setSupportLevel(String supportLevel) {
        this.supportLevel = supportLevel;
    }
    public String getIssueDescription() {
        return issueDescription;
    }
    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }
    public String getRequestContent() {
        return requestContent;
    }
    public void setRequestContent(String requestContent) {
        this.requestContent = requestContent;
    }
    public String getResponseContent() {
        return responseContent;
    }
    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }
    public Integer getStatus() {
        return status;
    }
    public String getStatusStr() {
        if (null != status) {
            return WorkOrderStatusType.getName(status);
        }
        return "";
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getFeedbackStatus() {
        return feedbackStatus;
    }
    public String getFeedbackStatusStr() {
        if (null != feedbackStatus) {
            if ("01".equals(feedbackStatus)) {
                return "已解决";
            } else if ("02".equals(feedbackStatus)) {
                return "退单";
            }
        }
        return feedbackStatus;
    }
    public void setFeedbackStatus(String feedbackStatus) {
        this.feedbackStatus = feedbackStatus;
    }
    public String getFeedbackContent() {
        return feedbackContent;
    }
    public void setFeedbackContent(String feedbackContent) {
        this.feedbackContent = feedbackContent;
    }
    public Date getFeedbackTime() {
        return feedbackTime;
    }
    public String getFeedbackTimeStr() {
        return feedbackTime !=null ? DateUtil.getInstance().getDateStr(feedbackTime, DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public void setFeedbackTime(Date feedbackTime) {
        this.feedbackTime = feedbackTime;
    }
    public String getFeedbackContactName() {
        return feedbackContactName;
    }
    public void setFeedbackContactName(String feedbackContactName) {
        this.feedbackContactName = feedbackContactName;
    }
    public String getFeedbackContactPhone() {
        return feedbackContactPhone;
    }
    public void setFeedbackContactPhone(String feedbackContactPhone) {
        this.feedbackContactPhone = feedbackContactPhone;
    }
    public String getFeedbackRemark() {
        return feedbackRemark;
    }
    public void setFeedbackRemark(String feedbackRemark) {
        this.feedbackRemark = feedbackRemark;
    }
    public String getRevokeReason() {
        return revokeReason;
    }
    public void setRevokeReason(String revokeReason) {
        this.revokeReason = revokeReason;
    }
}
