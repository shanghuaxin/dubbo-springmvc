package com.agent.cs.entity;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.agent.common.BaseDomain;
import com.agent.util.DateUtil;

/**
 * 联通消息通知
 * @author zhangwei
 *
 */
public class UnicomNewsNotice extends BaseDomain{

    /**
     * 
     */
    private static final long serialVersionUID = -2471613073301124681L;
    
    private String apiName ;//'调用的API',
    private Date timestamp ;//'推送时的时间戳',
    private String pushId ;// '推送ID',
    private String pushType ;// '推送类型；system_failure：IT故障类,system_cutover：IT割接类,network_failure：网络故障类,network_cutover：网络割接类,notice：通知类,other：其他类',
    private String pushContent ;// '信息内容',
    private Date pushTime ;// '信息时间',
    private String phoneNumber ;// '联系电话',
    private String contact ;// '联系人',
    private String remark ;// '备注'
    
    public String getApiName() {
        return apiName;
    }
    public void setApiName(String apiName) {
        this.apiName = apiName;
    }
    public Date getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
    public String getPushId() {
        return pushId;
    }
    public void setPushId(String pushId) {
        this.pushId = pushId;
    }
    public String getPushType() {
        return pushType;
    }
    public String getPushTypeStr() {
        if(StringUtils.isNotEmpty(pushType)){
            if("system_failure".equals(pushType)){
                return "IT故障类";
            }else if("system_cutover".equals(pushType)){
                return "IT割接类";
            }else if("network_failure".equals(pushType)){
                return "网络故障类";
            }else if("network_cutover".equals(pushType)){
                return "网络割接类";
            }else if("notice".equals(pushType)){
                return "通知类";
            }else if("other".equals(pushType)){
                return "其他类";
            }
        }
        return "";
    }
    public void setPushType(String pushType) {
        this.pushType = pushType;
    }
    public String getPushContentStr() {
        if(!StringUtils.isEmpty(pushContent)){
            if(pushContent.length() > 20){
                return pushContent.substring(1, 15)+"...";
            }else{
                return pushContent;
            }
        }
        return "";
    }
    public String getPushContent() {
        return pushContent;
    }
    public void setPushContent(String pushContent) {
        this.pushContent = pushContent;
    }
    public String getPushTimeStr() {
        return pushTime !=null ? DateUtil.getInstance().getDateStr(pushTime,DateUtil.yyyy_MM_dd_HH_mm_ss) : "";
    }
    public Date getPushTime() {
        return pushTime;
    }
    public void setPushTime(Date pushTime) {
        this.pushTime = pushTime;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
