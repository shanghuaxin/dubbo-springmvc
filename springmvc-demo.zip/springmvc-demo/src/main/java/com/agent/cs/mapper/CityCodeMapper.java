package com.agent.cs.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.agent.common.BaseMapper;
import com.agent.cs.entity.CityCode;

/**
 * 城市编码
 * @author FengLu
 */
@Repository
public interface CityCodeMapper extends BaseMapper<CityCode, Integer> {
    
    /**
     * 根据名称获取城市编码
     * @param map
     * @return
     */
    public List<CityCode> findByName(String cityName);
    
    /**
     * 根据编码获取城市名称
     * @param map
     * @return
     */
    public CityCode findByCode(String cityCode);
}
