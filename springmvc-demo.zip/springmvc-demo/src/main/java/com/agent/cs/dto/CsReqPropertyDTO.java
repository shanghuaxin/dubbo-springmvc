package com.agent.cs.dto;


/**
 * 客服系统请求公共参数类型
 * @author zhangwei
 *
 */
public class CsReqPropertyDTO extends BaseDTO{
    private static final long serialVersionUID = 1L;
    
    private String phone;//号码
    private String network;//网络
    private String certCode;//身份证号
    
    private Integer userId;//操作者ID

    //挂失解挂
    private String operType;  //操作类型：1-挂失 ,0-解挂  //操作类型，0：订购，1：取消，2：变更
    private String reason;    //操作原因
    //业务办理
    private String servType;//业务类型
    private String pacCode;//套餐编号
    private String servCode;//业务编号
    private String orderNo;//订单号
    private String hzPhone;//呼转号码设置
    
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getNetwork() {
        return network;
    }
    public void setNetwork(String network) {
        this.network = network;
    }
    public String getCertCode() {
        return certCode;
    }
    public void setCertCode(String certCode) {
        this.certCode = certCode;
    }
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public String getServType() {
        return servType;
    }
    public void setServType(String servType) {
        this.servType = servType;
    }
    public String getServCode() {
        return servCode;
    }
    public void setServCode(String servCode) {
        this.servCode = servCode;
    }
    
    public String getPacCode() {
        return pacCode;
    }
    public void setPacCode(String pacCode) {
        this.pacCode = pacCode;
    }
    public String getOperType() {
        return operType;
    }
    public void setOperType(String operType) {
        this.operType = operType;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public String getHzPhone() {
        return hzPhone;
    }
    public void setHzPhone(String hzPhone) {
        this.hzPhone = hzPhone;
    }
}
