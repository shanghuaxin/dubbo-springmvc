package com.agent.cs.dto;

/**
 * 联通消息通知
 * @author zhangwei
 *
 */
public class UnicomNewsNoticeDTO {
    // 调用的API
    private String api_name;
    // 推送时的时间戳
    private String timestamp;
    // 消息通知数据
    private UnicomNewsNoticeDataDTO data;
    
    public String getApi_name() {
        return api_name;
    }
    public void setApi_name(String api_name) {
        this.api_name = api_name;
    }
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    public UnicomNewsNoticeDataDTO getData() {
        return data;
    }
    public void setData(UnicomNewsNoticeDataDTO data) {
        this.data = data;
    }
}
