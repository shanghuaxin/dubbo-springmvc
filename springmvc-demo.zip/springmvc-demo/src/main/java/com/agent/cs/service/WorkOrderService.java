package com.agent.cs.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.cs.entity.WorkOrder;
import com.agent.cs.mapper.WorkOrderMapper;

/**
 * 客服工单
 * @author FengLu
 *
 */
@Service("workOrderService")
@Transactional(rollbackFor=Exception.class)
public class WorkOrderService {
    @Autowired
    private WorkOrderMapper workOrderMapper;
    
    public WorkOrder selectById(Integer key) {
        return workOrderMapper.select(key);
    }
    
    /**
     * 查找工单集合
     * @param map
     * @return
     */
    public List<WorkOrder> list(Map<String, Object> map) {
        return workOrderMapper.list(map);
    }
    
    /**
     * 查询数量
     * @param map
     * @return
     */
    public int count(Map<String, Object> map) {
        return workOrderMapper.count(map);
    }
    /**
     * 新增工单
     * @param workOrder
     * @return
     */
    public int insert(WorkOrder workOrder) {
        return workOrderMapper.insert(workOrder);
    }
    
    /**
     * 更新状态
     * @param workOrder
     * @return
     */
    public int update(WorkOrder workOrder) {
        return workOrderMapper.update(workOrder);
    }
}
