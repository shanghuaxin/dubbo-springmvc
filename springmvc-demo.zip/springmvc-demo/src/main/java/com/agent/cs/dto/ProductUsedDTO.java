package com.agent.cs.dto;

public class ProductUsedDTO {
    private String productName;
    private String totalCount;
    private String usedCount;
    private String restCount;
    private String state;
    private String unitName;
    private String effDate;
    private String expireDate;
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(String totalCount) {
        this.totalCount = totalCount;
    }
    public String getUsedCount() {
        return usedCount;
    }
    public void setUsedCount(String usedCount) {
        this.usedCount = usedCount;
    }
    public String getRestCount() {
        return restCount;
    }
    public void setRestCount(String restCount) {
        this.restCount = restCount;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getUnitName() {
        return unitName;
    }
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    public String getEffDate() {
        return effDate;
    }
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }
    public String getExpireDate() {
        return expireDate;
    }
    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }
}
