package com.agent.debug.mapper;

import java.util.List;

import com.agent.common.BaseMapper;
import com.agent.debug.entity.PhoneTemp;

public interface PhoneTempMapper extends BaseMapper<PhoneTemp, Integer> {
    
    //查找所有号码，并获取号码ID
    public List<PhoneTemp> listPhone();

}
