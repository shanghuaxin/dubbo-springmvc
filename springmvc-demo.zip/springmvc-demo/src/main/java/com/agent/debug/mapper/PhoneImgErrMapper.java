package com.agent.debug.mapper;

import org.apache.ibatis.annotations.Param;

import com.agent.common.BaseMapper;
import com.agent.debug.entity.PhoneImgErr;

public interface PhoneImgErrMapper extends BaseMapper<PhoneImgErr, Integer> {
    
    public PhoneImgErr findByPhone(@Param(value="phone")String phone);

}
