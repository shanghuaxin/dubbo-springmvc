package com.agent.debug.entity;

public class PhoneImgErr {
    
    private Integer id;
    private String phone;
    private Integer cardHand;
    private Integer cardFront;
    private Integer cardRear;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getCardHand() {
        return cardHand;
    }

    public void setCardHand(Integer cardHand) {
        this.cardHand = cardHand;
    }

    public Integer getCardFront() {
        return cardFront;
    }

    public void setCardFront(Integer cardFront) {
        this.cardFront = cardFront;
    }

    public Integer getCardRear() {
        return cardRear;
    }

    public void setCardRear(Integer cardRear) {
        this.cardRear = cardRear;
    }

    @Override
    public String toString() {
        return "PhoneImgErr [id=" + id + ", phone=" + phone + ", cardHand=" + cardHand + ", cardFront=" + cardFront
                + ", cardRear=" + cardRear + "]";
    }

}
