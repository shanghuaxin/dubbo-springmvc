package com.agent.debug.controller;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.agent.debug.entity.PhoneBossTemp;
import com.agent.debug.entity.PhoneImgErr;
import com.agent.debug.entity.PhoneTemp;
import com.agent.debug.service.DebugService;

/**
 *  * 测试类
 * @author auto
 */
@Controller
@RequestMapping(value="debug")
public class DebugController {
    private static Logger logger = LoggerFactory.getLogger(DebugController.class);
    @Value("#{configProperties['imageURL']}")
    private String imageURL;
    @Value("#{configProperties['resourceIP_phone']}")
    private String resourceIP;
    @Autowired
    private DebugService debugService;

    /**
     * 进入测试页面
     * @param model
     * @return
     */
    @RequestMapping(value = "dto", method = RequestMethod.GET)
    public String packagesList(Model model) {
        return "/views/debug/debugDto.jsp";
    }

    /**
     * 酷商实名制图片下载测试
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value="test-img", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> imgUpload(HttpServletResponse response,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "实名制图片下载成功");
        try{
            List<PhoneTemp> list = debugService.listPhone();
            if(list != null && list.size() > 0) {
                for (PhoneTemp p : list) {
                    String fileName = "";
                    String imgType = "";
                    if(StringUtils.isNotBlank(p.getAttachmentUrl())) {
                        imgType = p.getAttachmentUrl().substring(p.getAttachmentUrl().lastIndexOf("."), p.getAttachmentUrl().length());
                        if(StringUtils.equals(p.getSourceType(), "cardHand")){
                            fileName = "zxst_" + p.getPhone() + "_17" + imgType;
                            System.out.println("---------------" + fileName);
                            savePic(resourceIP + p.getAttachmentUrl(), fileName, p.getPhone(), p.getSourceType(), "phoneImg");
                        }else if(StringUtils.equals(p.getSourceType(), "cardFront")){
                            fileName = "zxst_" + p.getPhone() + "_14" + imgType;
                            System.out.println("---------------" + fileName);
                            savePic(resourceIP + p.getAttachmentUrl(), fileName, p.getPhone(), p.getSourceType(), "phoneImg");
                        }else if(StringUtils.equals(p.getSourceType(), "cardRear")){
                            fileName = "zxst_" + p.getPhone() + "_15" + imgType;
                            System.out.println("---------------" + fileName);
                            savePic(resourceIP + p.getAttachmentUrl(), fileName, p.getPhone(), p.getSourceType(), "phoneImg");
                        }
                    }else {
                        PhoneImgErr err = new PhoneImgErr();
                        err.setPhone(p.getPhone());
                        err.setCardHand(1);
                        err.setCardFront(1);
                        err.setCardRear(1);
                        
                        debugService.imgErrSaveOrUpdate(err);
                    }
                }
            }else {
                //
                logger.info("--------------开户号码不存在---------------");
            }
            
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "实名制图片下载测试失败，原因：" + e.getMessage());
            logger.error("实名制图片下载测试失败，原因：" + e.getMessage(), e);
        }
        return map;
    }
    
    /**
     * BOSS实名制图片下载测试
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value="test-img-boss", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> imgUploadBOSS(HttpServletResponse response,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "实名制图片下载成功");
        try{
            List<PhoneBossTemp> temps = debugService.listBossPhone();
            if(temps != null && temps.size() > 0) {
                for (PhoneBossTemp p : temps) {
                    String fileName = "";
                    String imgType = "";
                    String sourceType = "";
                    if(StringUtils.isNotBlank(p.getUrl())) {
                        
                        File file = new File(imageURL + "/" + p.getUrl());
                        if (file.exists()) {
                            LinkedList<File> list = new LinkedList<File>();
                            File[] files = file.listFiles();
                            for (int i = 0; i < files.length; i++) {
                                File file2 = files[i];
                                if (file2.isDirectory()) {
                                    System.out.println("文件夹:" + file2.getAbsolutePath());
                                    list.add(file2);
                                } else {
                                    
                                    if(file2.getName().lastIndexOf(".") > 0) {
                                        imgType = file2.getName().substring(file2.getName().lastIndexOf("."), file2.getName().length());
                                        if(i == 2){
                                            fileName = "zxst_" + p.getPhone() + "_17" + imgType;
                                            sourceType = "cardHand";
                                        }else if(i == 0){
                                            fileName = "zxst_" + p.getPhone() + "_14" + imgType;
                                            sourceType = "cardFront";
                                        }else if(i == 1){
                                            fileName = "zxst_" + p.getPhone() + "_15" + imgType;
                                            sourceType = "cardRear";
                                        }
                                        savePic(resourceIP + p.getUrl() + "/" + file2.getName(), fileName, p.getPhone(), sourceType, "bossPhoneImg");
                                    }else {
                                        PhoneImgErr err = new PhoneImgErr();
                                        err.setPhone(p.getPhone());
                                        err.setCardHand(0);
                                        err.setCardFront(0);
                                        err.setCardRear(0);
                                        
                                        if(i == 2){
                                            err.setCardHand(1);
                                        }else if(i == 0){
                                            err.setCardFront(1);
                                        }else if(i == 1){
                                            err.setCardRear(1);
                                        }
                                        
                                        debugService.imgErrSaveOrUpdate(err);
                                    }
                                }
                            }
                            File temp_file;
                            while (!list.isEmpty()) {
                                temp_file = list.removeFirst();
                                files = temp_file.listFiles();
                                for (File file2 : files) {
                                    if (file2.isDirectory()) {
                                        System.out.println("文件夹:" + file2.getAbsolutePath());
                                        list.add(file2);
                                    } else {
                                        System.out.println("文件:" + file2.getAbsolutePath());
                                    }
                                }
                            }
                        } else {
                            PhoneImgErr err = new PhoneImgErr();
                            err.setPhone(p.getPhone());
                            err.setCardHand(1);
                            err.setCardFront(1);
                            err.setCardRear(1);
                            
                            debugService.imgErrSaveOrUpdate(err);
                        }
                    }else {
                        PhoneImgErr err = new PhoneImgErr();
                        err.setPhone(p.getPhone());
                        err.setCardHand(1);
                        err.setCardFront(1);
                        err.setCardRear(1);
                        
                        debugService.imgErrSaveOrUpdate(err);
                    }
                }
            }else {
                //
                logger.info("--------------开户号码不存在---------------");
            }
            
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "实名制图片下载测试失败，原因：" + e.getMessage());
            logger.error("实名制图片下载测试失败，原因：" + e.getMessage(), e);
        }
        return map;
    }
    
    private void savePic(String urlString, String fileName, String phone, String type, String doc) {
        URL url = null;  
        try {  
            logger.info("----" + phone + "---------------" + urlString + "--------------");
            url = new URL(urlString);  
            DataInputStream dataInputStream = new DataInputStream(url.openStream());  
            String path = imageURL + "/" + doc;
            File tempFile = new File(path);
            if (!tempFile.exists()) {
                tempFile.mkdirs();
            }
            FileOutputStream os = new FileOutputStream(tempFile.getPath() + File.separator + fileName);

            byte[] buffer = new byte[1024];  
            int length;  

            while ((length = dataInputStream.read(buffer)) > 0) {  
                os.write(buffer, 0, length);  
            }  

            dataInputStream.close();  
            os.close();  
        } catch (MalformedURLException e) {  
            PhoneImgErr err = new PhoneImgErr();
            err.setPhone(phone);
            err.setCardHand(0);
            err.setCardFront(0);
            err.setCardRear(0);
            if(StringUtils.equals(type, "cardHand")){
                err.setCardHand(1);
            }else if(StringUtils.equals(type, "cardFront")){
                err.setCardFront(1);
            }if(StringUtils.equals(type, "cardRear")){
                err.setCardRear(1);
            }
            debugService.imgErrSaveOrUpdate(err);
            
            logger.error("-------" + phone + "-------照片不存在---------------", e);
        } catch (IOException e) { 
            PhoneImgErr err = new PhoneImgErr();
            err.setPhone(phone);
            err.setCardHand(0);
            err.setCardFront(0);
            err.setCardRear(0);
            if(StringUtils.equals(type, "cardHand")){
                err.setCardHand(1);
            }else if(StringUtils.equals(type, "cardFront")){
                err.setCardFront(1);
            }if(StringUtils.equals(type, "cardRear")){
                err.setCardRear(1);
            }
            debugService.imgErrSaveOrUpdate(err);
            
            logger.error("-------" + phone + "-------照片不存在---------------", e);
        }  
    }
    
    /**
     * 根据号码生成文件
     * @param response
     * @param request
     * @return
     */
    /*@RequestMapping(value="ascii-txt", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> asciiTxt(HttpServletResponse response,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("status", true);
        map.put("msg", "根据号码生成文件成功");
        try{
            debugService.asciiTxt(imageURL);
        }catch(Exception e){
            map.put("status", false);
            map.put("msg", "根据号码生成文件失败，原因：" + e.getMessage());
            logger.error("根据号码生成文件失败，原因：" + e.getMessage(), e);
        }
        return map;
    }*/
}