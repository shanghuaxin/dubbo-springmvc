package com.agent.debug.entity;

public class PhoneTemp {
    
    private Integer id;
    private String phone;      //号码
    private Integer phoneId;   //号码ID
    private String attachmentName;   //图片名称
    private String attachmentUrl;    //存储路径
    private String sourceType;       //来源类型

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getAttachmentName() {
        return attachmentName;
    }

    public void setAttachmentName(String attachmentName) {
        this.attachmentName = attachmentName;
    }

    public String getAttachmentUrl() {
        return attachmentUrl;
    }

    public void setAttachmentUrl(String attachmentUrl) {
        this.attachmentUrl = attachmentUrl;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    @Override
    public String toString() {
        return "PhoneTemp [id=" + id + ", phone=" + phone + ", phoneId=" + phoneId + ", attachmentName="
                + attachmentName + ", attachmentUrl=" + attachmentUrl + ", sourceType=" + sourceType + "]";
    }

}
