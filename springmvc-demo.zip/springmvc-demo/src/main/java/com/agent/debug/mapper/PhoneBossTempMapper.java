package com.agent.debug.mapper;

import java.util.List;

import com.agent.common.BaseMapper;
import com.agent.debug.entity.PhoneBossTemp;

public interface PhoneBossTempMapper extends BaseMapper<PhoneBossTemp, Integer> {
    
    //查找所有号码对应的文件路径
    public List<PhoneBossTemp> listBossPhone();

}
