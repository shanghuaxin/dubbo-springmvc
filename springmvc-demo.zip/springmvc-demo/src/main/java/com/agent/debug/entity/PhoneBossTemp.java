package com.agent.debug.entity;

public class PhoneBossTemp {
    
    private Integer id;
    private String phone;      //号码
    private String url;        //存储路径
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "PhoneBossTemp [id=" + id + ", phone=" + phone + ", url=" + url + "]";
    }

}
