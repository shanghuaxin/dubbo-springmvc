package com.agent.debug.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.agent.businesslog.entity.InterfaceData;
import com.agent.businesslog.mapper.InterfaceDataMapper;
import com.agent.debug.entity.PhoneBossTemp;
import com.agent.debug.entity.PhoneImgErr;
import com.agent.debug.entity.PhoneTemp;
import com.agent.debug.mapper.PhoneBossTempMapper;
import com.agent.debug.mapper.PhoneImgErrMapper;
import com.agent.debug.mapper.PhoneTempMapper;
import com.agent.order.common.util.Utils;

@Transactional(rollbackFor=Exception.class)
@Service("debugService")
public class DebugService {
    @Autowired
    private PhoneTempMapper phoneTempMapper;
    @Autowired
    private PhoneImgErrMapper errMapper;
    @Autowired
    private PhoneBossTempMapper phoneBossTempMapper;
    @Autowired
    private InterfaceDataMapper interfaceDataMapper;
    
    public List<PhoneTemp> listPhone(){
        return phoneTempMapper.listPhone();
    }
    
    public List<PhoneBossTemp> listBossPhone(){
        return phoneBossTempMapper.listBossPhone();
    }
    
    /**
     * 实名制图片下载测试
     * @param us
     */
    public void imgErrSaveOrUpdate(PhoneImgErr p) {
        PhoneImgErr err = errMapper.findByPhone(p.getPhone());
        if(err != null) {
            errMapper.update(p);
        }else {
            errMapper.insert(p);
        }
    }
    
    /**
     * 根据号码生成文件
     * @throws Exception
     */
    public void asciiTxt(String imageURL) throws Exception{
        Map<String, Object> ot = new HashMap<>();
        List<InterfaceData> tt = interfaceDataMapper.listAsciiTxt(ot);
        if(null != tt && tt.size() >0){
            File localFile=new File(imageURL + File.separator + "asciiLog");
            if(localFile.exists()){
                localFile.delete();
            }
            if(!localFile.exists()){
                localFile.mkdirs();
            }
            for(InterfaceData t:tt){
                if(!Utils.isEmptyString(t.getResponseContent())){
                    String file = imageURL + File.separator + "asciiLog" + File.separator + "Log_" + t.getMsisdn() + "_" + t.getInterfaceName()+ ".txt";
                    FileOutputStream writerStream = new FileOutputStream(file);    
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(writerStream, "GB2312")); 
                    writer.write(t.getResponseContent());
                    writer.close();  
                }
            }
        }
    }
}
