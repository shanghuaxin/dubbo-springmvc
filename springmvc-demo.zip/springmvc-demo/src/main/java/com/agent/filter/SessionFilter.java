package com.agent.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * session过滤器，失效跳转到登录页面
 * @author fenglu
 */
public class SessionFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession();
        // 登陆url
        String loginUrl = httpRequest.getContextPath() + "/login.jsp";
        String url = httpRequest.getRequestURI();
        if(!(url.toLowerCase().contains(".png") || url.toLowerCase().contains("jpg") || url.toLowerCase().contains("gif"))){
            System.out.println("+++++++++++++++++++当前 "+httpRequest.getMethod()+" 请求地址："+url);
        }
        String path = url.substring(url.lastIndexOf("/"));
        // 超时处理，ajax请求超时设置超时状态，页面请求超时则返回提示并重定向
        if (path.indexOf("login") == -1
                && url.indexOf("alipayPayment") == -1 // 支付宝支付
                && url.indexOf("weixinPay") == -1 // 微信扫码支付
                && path.indexOf("paySuccess") == -1 // 支付成功
                && path.indexOf("payFail") == -1 // 支付失败
                && path.indexOf("notify") == -1 //查看报峻接口
                && path.indexOf("phoneStatusSync") == -1 // 联通号码状态同步接口
                && path.indexOf("workOrderFeecback") == -1 // 联通工单反馈接口
                && path.indexOf("unicomNewsNotice") == -1 // 联通消息通知接口
                && !path.endsWith(".js")
                && !path.endsWith(".css")
                && !path.endsWith(".png")
                && session.getAttribute("user") == null) {
            // 判断是否为ajax请求
            if (httpRequest.getHeader("x-requested-with") != null
                    && httpRequest.getHeader("x-requested-with")
                            .equalsIgnoreCase("XMLHttpRequest")) {
                httpResponse.addHeader("sessionstatus", "timeOut");
                httpResponse.addHeader("loginPath", loginUrl);
                chain.doFilter(request, response);// 不可少，否则请求会出错
            } else {
                String str = "<script language='javascript'>"
                        + "try{top.layer.alert('会话过期,请重新登录');}catch(e){}"
                        + "window.top.location.href='"
                        + loginUrl
                        + "';</script>";
                response.setContentType("text/html;charset=UTF-8");// 解决中文乱码
                try {
                    PrintWriter writer = response.getWriter();
                    writer.write(str);
                    writer.flush();
                    writer.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {

    }

}
