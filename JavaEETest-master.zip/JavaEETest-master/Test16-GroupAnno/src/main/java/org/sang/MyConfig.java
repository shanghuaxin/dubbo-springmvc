package org.sang;

/**
 * Created by sang on 16-12-14.
 */
@WiselyConfiguration("org.sang")
public class MyConfig {
}
