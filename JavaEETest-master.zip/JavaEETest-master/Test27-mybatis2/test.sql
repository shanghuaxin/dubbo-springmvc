INSERT INTO user(username,password,address) values("张三","111","西安");
INSERT INTO user(username,password,address) values("lisi","222","长沙");
INSERT INTO user(username,password,address) values("昂无","333","厦门");
INSERT INTO user(username,password,address) values("赵柳","444","北京");