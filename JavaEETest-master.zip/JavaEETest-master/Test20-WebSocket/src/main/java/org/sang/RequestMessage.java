package org.sang;

/**
 * Created by sang on 16-12-22.
 */
public class RequestMessage {

    private String name;

    public String getName() {
        return name;
    }
}
