package com.coolagent.boss.service;

import java.io.Serializable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(prefix="boss.charge")
@PropertySource("classpath:define.properties")
public class Define implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String unionUrl;
	
	private String mobileUrl;
	/*private String mobileChargeId;
	private String mobileChargePwd;*/
}
