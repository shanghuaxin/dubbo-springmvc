package com.coolagent.boss.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coolagent.boss.bean.InterfaceData;

@Repository
public interface InterfaceDataDao extends JpaRepository<InterfaceData, Long> {
}
