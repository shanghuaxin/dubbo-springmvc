package com.coolagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages = {"com.coolagent.*.config", "com.coolagent.*.control", "com.coolagent.*.service"})
@EnableCaching//使用缓存
@EnableTransactionManagement // 开启注解事务管理
public class KcApplication {

	public static void main(String[] args) {
		SpringApplication.run(KcApplication.class, args);
	}
}
