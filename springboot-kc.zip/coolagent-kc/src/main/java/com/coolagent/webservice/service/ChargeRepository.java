package com.coolagent.webservice.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.Charge;
import com.coolagent.jpa.service.AirChargeRecordRedisService;
import com.coolagent.webservice.bean.GetChargeRequest;
import com.coolagent.webservice.bean.GetChargeResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ChargeRepository {

	@Autowired
	private AirChargeRecordRedisService recordService;

	/**
	 * 充值接口操作
	 * 
	 * @param req
	 * @return
	 * @throws Exception
	 */
	public GetChargeResponse charge(GetChargeRequest req) throws Exception {
		GetChargeResponse rsp = new GetChargeResponse();
		Charge c = new Charge();
		//将webservice的对象封装成扩展类
		BeanUtils.copyProperties(req.getCharge(), c);
		c.setRandom(UUID.randomUUID().hashCode());
		RestStatus rs = recordService.chargeActivemq(c);
		//RestStatus rs = recordService.chargeWebService(c);
		if (rs.getStatus()) {
			rsp.setCode("200");
			rsp.setMsg("充值完成，稍后请留意充值短信");
		} else {
			rsp.setCode(rs.getErrorCode());
			rsp.setMsg(rs.getErrorMessage());
		}
		log.info("充值操作完成");

		return rsp;
	}

	/**
	 * webservice调用，进行充值
	 */
	public String webserviceInvokeCharge() {
		InputStream is = null;
		OutputStream os = null;
		HttpURLConnection conn = null;
		String s = "";
		// 服务的地址
		try {
			// 通过PostUI工具生成的URL
			URL wsUrl = new URL("http://localhost:9000/ws");

			conn = (HttpURLConnection) wsUrl.openConnection();

			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");

			os = conn.getOutputStream();

			// 请求体,可通过PostUI工具生成
			String soap = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://www.seecom.com.cn/webservice\">\r\n"
					+ "   <soapenv:Header/>\r\n" + "   <soapenv:Body>\r\n" + "      <web:getChargeRequest>\r\n"
					+ "         <web:charge>\r\n" + "            <web:channel>card_dx</web:channel>\r\n"
					+ "            <web:pwd>123</web:pwd>\r\n" + "            <web:phone>17057000068</web:phone>\r\n"
					+ "            <web:money>2000</web:money>\r\n" + "         </web:charge>\r\n"
					+ "      </web:getChargeRequest>\r\n" + "   </soapenv:Body>\r\n" + "</soapenv:Envelope>";

			os.write(soap.getBytes());

			is = conn.getInputStream();

			byte[] b = new byte[1024];
			int len = 0;
			
			while ((len = is.read(b)) != -1) {
				String ss = new String(b, 0, len, "UTF-8");
				s += ss;
			}
			log.info("webserviceInvokeCharge==========="+s);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (is != null)
					is.close();
				if (os != null)
					os.close();
				if (conn != null)
					conn.disconnect();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return s;
	}
	
	public static void main(String[] args) {
		System.out.println(new ChargeRepository().webserviceInvokeCharge());
	}
}
