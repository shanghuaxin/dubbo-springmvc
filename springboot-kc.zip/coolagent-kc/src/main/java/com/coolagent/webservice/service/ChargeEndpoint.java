package com.coolagent.webservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.coolagent.webservice.bean.GetChargeRequest;
import com.coolagent.webservice.bean.GetChargeResponse;

/**
 * http://localhost:9000/ws/charge.wsdl
 * @author Shanghuaxin
 *
 */
@Endpoint
public class ChargeEndpoint {
    private static final String NAMESPACE_URI = "http://www.seecom.com.cn/webservice";

    private ChargeRepository chargeRepository;

    @Autowired
    public ChargeEndpoint(ChargeRepository chargeRepository) {
        this.chargeRepository = chargeRepository;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getChargeRequest")
    @ResponsePayload
    public GetChargeResponse charge(@RequestPayload GetChargeRequest request) {
        GetChargeResponse response = null;
		try {
			response = chargeRepository.charge(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return response;
    }
}
