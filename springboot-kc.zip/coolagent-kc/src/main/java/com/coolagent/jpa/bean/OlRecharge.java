package com.coolagent.jpa.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name = "ol_recharge")
@Data
@ToString
public class OlRecharge implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="order_no", columnDefinition="varchar(50) comment '订单编号'")
	private String orderNo;//订单编号
	@Column(name="buy_order_no", columnDefinition="varchar(50) comment '流量平台订单编号'")
    private String buyOrderNo;//流量平台订单编号
	@Column(name="user_ip", columnDefinition="varchar(50) comment '操作ip'")
    private String userIp;//操作ip
	@Column(name="dct_id", columnDefinition="int(11) comment '折扣id'")
    private Integer dctId;//优惠表id
	@Column(name="phone", columnDefinition="varchar(11) comment '充值号码'")
    private String phone;//充值号码
	@Column(name="r_type", columnDefinition="int(3) comment '充值类型：1-充值，2-充流量'")
    private Integer rType;//充值类型：1-充值，2-充流量
	@Column(name="pay_type", columnDefinition="varchar(20) comment '支付方：alipay_ol：支付宝，wx_ol：微信，yeepay_card:易宝支付，pay_card:19PAY支付，dx_card:鼎信支付支付'")
    private String payType;//支付方：alipay_ol：支付宝，wx_ol：微信，card_yeepay:易宝支付，card_pay:19PAY支付，card_dx:鼎信支付支付
	@Column(name="pay_status", columnDefinition="int(3) comment '支付状态：1-成功，2-待支付，3-失败'")
    private Integer payStatus;//支付状态：1-成功，2-待支付，3-失败
	@Column(name="r_status", columnDefinition="int(3) comment '充值状态：1-成功，2-待充值，3-接口失败，4-充值失败'")
    private Integer rStatus;//充值状态：1-成功，2-待充值，3-接口失败，4-充值失败
	@Column(name="money", columnDefinition="decimal(10,2) comment '充值金额'")
    private BigDecimal money;//充值金额
	@Column(name="account_balance", columnDefinition="decimal(10,2) comment '实际支付金额'")
    private BigDecimal accountBalance;//实际支付金额
	@Column(name="pro_id", columnDefinition="int(11) comment '产品id'")
    private Integer proId;//产品id
	@Column(name="pro_code", columnDefinition="varchar(50) comment '产品编号'")
    private String proCode;//产品编号
	@Column(name="pro_name", columnDefinition="varchar(50) comment '商品名称（30元话费，500M流量）'")
    private String proName;//商品名称（30元话费，500M流量）
	@Column(name="pro_remark", columnDefinition="varchar(200) comment '商品描述（充30元省0.99元）'")
    private String proRemark;//商品描述（充30元省0.99元）
	@Column(name="error_msg", columnDefinition="varchar(1000) comment '错误信息'")
    private String errorMsg;//错误信息
	@Column(name="remark", columnDefinition="varchar(2000) comment '备注'")
    private String remark;//备注
	@Column(name="source_type", columnDefinition="varchar(20) comment '充值来源：online-网厅，wap-掌厅'")
    private String sourceType;//充值来源：online-网厅，wap-掌厅
    @Column(name="login_name", columnDefinition="varchar(20) comment '登录账户'")
    private String loginName;//登录账号
 	@Column(name="create_time", length = 20)// 开始时间
    private String createTime;
 	@Column(name="update_time", length = 20)// 结束时间
    private String updateTime;
}
