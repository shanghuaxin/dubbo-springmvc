package com.coolagent.jpa.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.coolagent.jpa.bean.MobileArea;

@Repository
public interface MobileAreaDao extends JpaRepository<MobileArea, Long> {

	/**
	 * 所属网络，移动还是联通
	 * @param prefix,virtualCode
	 * @return
	 */
	public MobileArea findByPrefixAndVirtualCode(@Param("prefix")Integer prefix, @Param("virtualCode")String virtualCode);
}
