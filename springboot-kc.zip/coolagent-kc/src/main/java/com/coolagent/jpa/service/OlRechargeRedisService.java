package com.coolagent.jpa.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coolagent.cache.service.RedisHandle;
import com.coolagent.common.Constants;
import com.coolagent.jpa.bean.OlRecharge;

import lombok.extern.slf4j.Slf4j;

/**
 * 代理商的代码转换
 * @author Shanghuaxin
 *
 */
@Service
@Slf4j
@Transactional(rollbackFor=Exception.class)
public class OlRechargeRedisService extends RedisHandle<OlRecharge>{
	
	private String REDIS_KEY = "REDIS_KEY_OLRECHARGE";
	
	@Autowired
	private OlRechargeDao dao;
	
	@Override
	protected String getRedisKey() {
		// TODO Auto-generated method stub
		return this.REDIS_KEY;
	}
	
	/**
	 * 查找当前的订单号是否已经在库中
	 * @param code
	 * @return
	 */
	public OlRecharge findByOrderNo(@Param("orderNo")String orderNo) {
		OlRecharge bean = new OlRecharge();
		
		Object obj = get(orderNo);
		if(obj == null) {
			bean = dao.findByOrderNo(orderNo);
			put(orderNo, bean, Constants.REDIS_EXPIRE);
		} else {
			BeanUtils.copyProperties(get(orderNo), bean);
		}
		log.info(bean.toString());
		
		return bean;
	}
	
}
