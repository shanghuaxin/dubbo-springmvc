package com.coolagent.jpa.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.xml.bind.JAXBElement;

import org.example.paymentbank.ObjectFactory;
import org.example.paymentbank.PaymentBankRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coolagent.activemq.service.Producer;
import com.coolagent.boss.service.BOSSService;
import com.coolagent.cache.service.BaseRedisHandle;
import com.coolagent.cache.service.RedisHandle;
import com.coolagent.common.Constants;
import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.AirChargeAgentCode;
import com.coolagent.jpa.bean.AirChargeAgentInfo;
import com.coolagent.jpa.bean.AirChargeRecord;
import com.coolagent.jpa.bean.Charge;
import com.coolagent.jpa.bean.MobileArea;
import com.coolagent.jpa.bean.OlRecharge;
import com.coolagent.util.DateUtils;
import com.coolagent.util.JSONUtil;
import com.coolagent.util.Utils;

import lombok.extern.slf4j.Slf4j;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBO;

/**
 * 代理商充值记录
 * 
 * @author Shanghuaxin
 *
 */
@Service
@Slf4j
@Transactional(rollbackFor = Exception.class)
public class AirChargeRecordRedisService extends RedisHandle<Object> {

	private String REDIS_KEY = "REDIS_KEY_AIRCHARGERECORD";

	@Autowired
	private Producer producer;
	@Autowired
	private AirChargeRecordDao dao;
	@Autowired
	private AirChargeAgentCodeRedisService codeService;
	@Autowired
	private AirChargeAgentInfoRedisService infoService;
	@Autowired
	private OlRechargeDao rechargeDao;
	@Autowired
	private MobileAreaRedisService mrService;
	@Autowired
	private BOSSService bossService;
	@Autowired
	private BaseRedisHandle baseRedisHandle;

	/**
	 * 根据KEY删除redis中的指定缓存
	 * @param key
	 * @return
	 */
	public Set<String> removeRedisByKey(String key) {
		baseRedisHandle.removeByMainKey(key);
		
		return baseRedisHandle.popAllKeysByMainKey();
	}
	
	/**
	 * 清除所有缓存
	 * @param key
	 * @return
	 */
	public void removeRedisKeys() {
		
		baseRedisHandle.emptyByMainKey();
	}
	/**
	 * 查看redis中的余额
	 * @param agentId
	 * @return
	 */
	public BigDecimal getBalanceRedis(Integer agentId) {
		
		BigDecimal balance = new BigDecimal(0);
		//获取redis缓存，存放的是最新的
		Object obj = get(agentId+"-balance");
		if(obj != null) {
			balance = new BigDecimal(obj.toString());
		}
		
		return balance;
	}
	
	@Override
	protected String getRedisKey() {
		return this.REDIS_KEY;
	}

	/**
	 * 消息activemq方式调用，进行充值
	 * @param charge
	 * @return
	 * @throws Exception
	 */
	public RestStatus chargeActivemq(Charge c) throws Exception {
		
		RestStatus rs = new RestStatus(true);
		synchronized (this) {//防止并发时产生异常或垃圾数据
			rs = checkFrontChargeActivemq(c);
			if(!rs.getStatus()) {
				return rs;
			}
			
			String sendMsg = JSONUtil.objectToJson(c).toString();
			
			//将消息内容放在redis中，防止异常后数据丢失
			put(Constants.ACTIVEMQ_CHARGE_VALUE+c.getRandom(), c, Constants.REDIS_EXPIRE);
			
			log.info("发送消息的报文为:" + sendMsg);
			// 发消息进行数据操作
			producer.sendMessageConvert(Constants.ACTIVEMQ_CHARGE_VALUE, JSONUtil.objectToJson(c).toString());
		}
		
		return rs;
	}
	
	/**
	 * 消息activemq方式调用前进行检查
	 * @param charge
	 * @return
	 * @throws Exception
	 */
	public RestStatus checkFrontChargeActivemq(Charge c) {
		RestStatus rs = mrService.findNetWork(c.getPhone());
		if (!rs.getStatus()) {
			return rs;
		}
		
		rs = findAirChargeAgentInfo(c.getChannel(), c.getPwd());
		if (!rs.getStatus()) {
			return rs;
		}
		
		AirChargeAgentInfo agentInfo = (AirChargeAgentInfo) rs.getResponseData();
		c.setAgentId(agentInfo.getAgentId());
		// 账户余额
		//BigDecimal balance = agentInfo.getBalance();
		BigDecimal balance = new BigDecimal(0);
		//获取redis缓存，存放的是最新的
		Object obj = get(agentInfo.getAgentId()+"-balance");
		if(obj != null) {
			balance = new BigDecimal(obj.toString());
		} else {
			balance = agentInfo.getBalance();
		}
		BigDecimal newBalance = balance.subtract(new BigDecimal(c.getMoney()));//都是以分为单位，所以就不用转换.divide(Constants.FINAL_100)
		if (newBalance.doubleValue() < 0) {
			rs.setStatus(false);
			rs.setErrorCode("500");
			rs.setErrorMessage("账户余额不足");
			return rs;
		}
		//存放此次充值后的余额
		chargedPutRedisNewBalance(agentInfo.getAgentId(), newBalance);
		
		return rs;
	}
	
	/**
	 * 加值或充值后需要把agentId+"-balance"余额更新
	 * 这个缓存是用来处理并发数据时，余额判断使用
	 * @param agentId
	 * @param newBalance
	 */
	public void chargedPutRedisNewBalance(Integer agentId, BigDecimal newBalance) {
		//存放此次加值后的余额
		put(agentId+"-balance", newBalance, Constants.REDIS_EXPIRE);
	}
	
	/**
	 * 直接调用，请求操作进行充值
	 * @param charge
	 * @return
	 * @throws Exception
	 */
	public RestStatus chargeWebService(Charge charge) throws Exception {
		log.info("请求进行充值操作=================="+charge.getPhone());
		
		RestStatus rs = new RestStatus(true);
		try {
			rs = mrService.findNetWork(charge.getPhone());
			if (!rs.getStatus()) {
				return rs;
			}
			
			rs = findAirChargeAgentInfo(charge.getChannel(), charge.getPwd());
			if (!rs.getStatus()) {
				return rs;
			}
			
			AirChargeAgentInfo agentInfo = (AirChargeAgentInfo) rs.getResponseData();
			//如何账户信息正确，需要把agentid存入进去
			charge.setAgentId(agentInfo.getAgentId());
			
			rs = deductMoney(agentInfo, charge);
			if (!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
			
			rs = boss(charge);
			if (!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
			
			//所有操作都是成功的
			rs = addAirChargeRecode(charge, 1, 2);
			if (!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
		} catch (Exception e) {
			// 扣款后会把这两个字段更新，需要还原
			charge.setChargedBalance(charge.getChargedBalance().add(new BigDecimal(charge.getMoney())));
			infoService.updateRedisInfo(charge.getAgentId(), charge.getChargedBalance());
			
			//并发中的redis中的余额更新
			BigDecimal balance = getBalanceRedis(charge.getAgentId());
			balance = balance.add(new BigDecimal(charge.getMoney()));
			chargedPutRedisNewBalance(charge.getAgentId(), balance);
			
			throw new Exception(e.getMessage());
		}

		return rs;
	}

	/**
	 * 查询账户信息
	 * 
	 * @param agentCode
	 * @return
	 */
	public RestStatus findAirChargeAgentInfo(String agentCode, String agentPwd) {
		RestStatus rs = new RestStatus(true);
		rs = codeService.findByAgentCodeAndPwd(agentCode, agentPwd);
		if(!rs.getStatus()) {
			return rs;
		}
		
		AirChargeAgentCode code = (AirChargeAgentCode)rs.getResponseData();
		//验证状态查出账户信息
		rs = infoService.findByAgentId(code.getAgentId(), true);
		if(!rs.getStatus()) {
			return rs;
		}

		return rs;
	}

	/**
	 * 扣钱操作
	 */
	public RestStatus deductMoney(AirChargeAgentInfo agentInfo, Charge charge) throws Exception {
		RestStatus rs = new RestStatus(true);
		try {
			//充值金额
			BigDecimal money = new BigDecimal(charge.getMoney());
			// 账户余额
			BigDecimal balance = agentInfo.getBalance();
			BigDecimal newBalance = balance.subtract(money);//都是以分为单位，所以就不用转换
			charge.setChargedBalance(newBalance);
			if (newBalance.doubleValue() >= 0) {
				log.info("开始扣款，扣款金额：￥"+money.divide(Constants.FINAL_100)+"，扣款后的余额为：￥"+newBalance.divide(Constants.FINAL_100));
				rs = infoService.updateBalance(newBalance, agentInfo.getAgentId());
				
				infoService.updateRedisInfo(agentInfo.getAgentId(), newBalance);
			} else {
				throw new Exception("扣款金额：￥"+money.divide(Constants.FINAL_100)+"，当前账户余额不足：￥"+balance.divide(Constants.FINAL_100));
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return rs;
	}
	
	/**
	 * 调用boss接口
	 * 
	 * @return
	 */
	public RestStatus boss(Charge charge) throws Exception {
		RestStatus rs = new RestStatus(true);
		try {
			rs = mrService.findNetWork(charge.getPhone());
			if(!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
			MobileArea bean = (MobileArea)rs.getResponseData();
			String network = bean.getCarrier();
			
			if ("YD".equals(network)) {
				TRechargeBOSSBO rechargeBO = new TRechargeBOSSBO();
				rechargeBO.setMSISDN("86"+charge.getPhone());
				rechargeBO.setAmount(charge.getMoney());
				rechargeBO.setSN(Utils.getOrderNo("F"));// 流水号唯一
				rechargeBO.setOperateDate(DateUtils.dateToXmlDate(new Date()));// 调用方操作时间
				rechargeBO.setChannalId(charge.getAgentId().toString());// 充值Id
				//rechargeBO.setChannalPwd(com.coolagent.util.MD5.GetMD5Code(rechargePwd));// 充值密码
				rechargeBO.setChannalPwd(charge.getPwd());// 充值密码
				rs = bossService.RechargeBOSS(rechargeBO, 0);
			} else {
				PaymentBankRequest paymentBank = new PaymentBankRequest();
				paymentBank.setRequestId(Utils.getRandomString(10));
				paymentBank.setSystemId("0001");
				paymentBank.setServiceId(charge.getPhone());
				paymentBank.setServiceKind(8);
				paymentBank.setPayFee(charge.getMoney());
				ObjectFactory objFac = new ObjectFactory();
				JAXBElement<String> flowNumber = objFac.createPaymentBankRequestFlowNumber("");
				JAXBElement<String> notifyDate = objFac.createPaymentBankRequestNotifyDate("");
				paymentBank.setFlowNumber(flowNumber);
				paymentBank.setNotifyDate(notifyDate);
				paymentBank.setPayWay(4);
				paymentBank.setPayKind(1);
				paymentBank.setIfContinue(false);
				// 充值类型
				paymentBank.setDealerId(Constants.SOURCE_TYPE_KC);
				// 充值渠道ID
				paymentBank.setWorkNo(charge.getAgentId().toString());
				paymentBank.setPresentFee(0);
				rs = bossService.paymentBank(paymentBank, 0);
			}
			
			if(!rs.getStatus()) {
				throw new Exception("调用接口失败："+rs.getErrorMessage());
			}
		} catch (Exception e) {
			throw new Exception("BOSS方法有异常，"+e.getMessage());
		}

		return rs;
	}

	/**
	 * 写充值记录:AirChargeRecord/OlRecharge
	 * @param charge
	 * @param rStatus充值状态：1-成功，2-待充值，3-接口失败，4-充值失败
	 * @param operationType类型：1-空充，2-充值
	 * @return
	 * @throws Exception
	 */
	public RestStatus addAirChargeRecode(Charge charge, Integer rStatus, Integer operationType) throws Exception {
		RestStatus rs = new RestStatus(true);
		try {
			AirChargeRecord record = new AirChargeRecord();
			record.setAgentId(charge.getAgentId());
			record.setRStatus(rStatus.intValue()==1?1:2);//t_airchargerecord中的r_status,1表示成功2表示失败
			record.setOperationType(operationType);
			record.setOperationMoney(new BigDecimal(charge.getMoney()));
			record.setRemark((operationType.intValue()==1?"加值":"充值")+"，金额：￥" + new BigDecimal(charge.getMoney()).divide(Constants.FINAL_100).doubleValue()+"，"+(rStatus.intValue()==1?"成功":"失败回退")+"后的余额为：￥"+charge.getChargedBalance().divide(Constants.FINAL_100));
			record.setPhone(charge.getPhone());
			record.setCreateId(charge.getUserId());
			record.setCreateTime(DateUtils.getInstance().formatDate(new Date(), null));
			record.setUpdateId(charge.getUserId());
			record.setUpdateTime(DateUtils.getInstance().formatDate(new Date(), null));

			AirChargeRecord newRecord = dao.save(record);
			if (newRecord == null) {
				throw new Exception("写充值记录失败");
			}

			//只有充值才写ol-recharge记录
			if(operationType.intValue()==2) {
				rs = olRechargeSave(rStatus, charge);
			}
			
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return rs;
	}
	
	/**
	 * 写olrecharge充值记录表
	 * @param rStatus 充值状态：1-成功，2-待充值，3-接口失败，4-充值失败
	 * @param charge
	 * @return
	 * @throws Exception
	 */
	public RestStatus olRechargeSave(Integer rStatus, Charge charge) throws Exception {
		RestStatus rs = new RestStatus(true);
		try {
			OlRecharge re = new OlRecharge();
			
			re.setLoginName(charge.getChannel());
			re.setPhone(charge.getPhone());
			re.setRStatus(rStatus);//充值状态：1-成功，2-待充值，3-接口失败，4-充值失败
			re.setMoney(new BigDecimal(charge.getMoney())/* .divide(Constants.FINAL_100) */);
			re.setAccountBalance(new BigDecimal(charge.getMoney()));
			re.setPayType(charge.getChannel());
			
			re.setSourceType(Constants.SOURCE_TYPE_KC);
			re.setOrderNo(Utils.getOrderNo("F"));
			re.setUserIp("");
			re.setDctId(0);
			re.setPayStatus(1);
			re.setRType(1);
			re.setProId(0);
			re.setProCode("");
			re.setProName("");
			re.setProRemark("");
			re.setCreateTime(DateUtils.getInstance().formatDate(new Date(), null));
			re.setUpdateTime(DateUtils.getInstance().formatDate(new Date(), null));

			OlRecharge newRecharge = rechargeDao.save(re);
			if (newRecharge == null) {
				throw new Exception("写充值记录失败");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		
		return rs;
	}
}
