package com.coolagent.jpa.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.coolagent.jpa.bean.OlRecharge;

@Repository
public interface OlRechargeDao extends JpaRepository<OlRecharge, Long> {

	/**
	 * 查询数据中是否存在当前的定单号
	 * @param orderNo
	 * @return
	 */
	public OlRecharge findByOrderNo(@Param("orderNo")String orderNo);
}
