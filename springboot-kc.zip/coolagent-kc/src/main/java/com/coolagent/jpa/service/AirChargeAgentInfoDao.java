package com.coolagent.jpa.service;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.coolagent.jpa.bean.AirChargeAgentInfo;

@Transactional(rollbackFor = Exception.class)
public interface AirChargeAgentInfoDao extends Repository<AirChargeAgentInfo, Long> {

	/**
	 * 根据代理商ID查询账户信息
	 * @param agentId
	 * @return
	 */
	public AirChargeAgentInfo findByAgentId(@Param("agentId") Integer agentId);
	
	/*@Query(value="select i from AirChargeAgentInfo as i,AirChargeAgentCode as c where i.agentId=c.agentId and c.agentCode=:agentCode and c.agentPwd=:agentPwd")
	public AirChargeAgentInfo findByCodeAndPwd(@Param("agentCode") String agentCode, @Param("agentPwd") String agentPwd);*/
	
	/*@Query(value="select i from AirChargeAgentInfo as i,AirChargeAgentCode as c where i.agentId=c.agentId and c.agentCode=:agentCode")
	public AirChargeAgentInfo findByCode(@Param("agentCode") String agentCode);*/
	
	@Modifying
	@Query("update AirChargeAgentInfo set balance=?1 where agentId=?2 ")
	public int updateBalance(BigDecimal balance, Integer agentId) throws Exception;
	
	@Modifying
	@Query("update AirChargeAgentInfo set status=?1 where agentId=?2 ")
	public int updateStatus(Integer status, Integer agentId) throws Exception;
}