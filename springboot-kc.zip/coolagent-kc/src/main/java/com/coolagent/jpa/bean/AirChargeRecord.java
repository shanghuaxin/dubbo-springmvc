package com.coolagent.jpa.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.ToString;

@Entity//把当前类映射到数据库中
@Table(name="t_aircharge_add_record")
@Data
@ToString
public class AirChargeRecord implements Serializable {

	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = 1L;

	@Id// 解决org.hibernate.AnnotationException: No identifier specified for entity异常
	@GeneratedValue
	private Long id;
	
	// 充值代理商ID
	@Basic//默认就添加这个注解
	@Column(name="agent_id", length = 20)
    private Integer agentId;
	
	//类型
	@Column(name="r_status", columnDefinition="int(3) DEFAULT 1 comment '充值状态:1成功2失败'")
	private Integer rStatus;
	//类型
	@Column(name="operation_type", columnDefinition="int(3) comment '类型:1加值2充值'")
	private Integer operationType;
	
	//充值号码
	@Column(name="phone", columnDefinition="varchar(11) comment '充值号码'")
	private String phone;
	
    // 操作金额
	@Column(name="operation_money", columnDefinition="decimal(10,2) comment '充值金额'")
	private BigDecimal operationMoney;
	
    // 备注
	@Column(name="remark", length = 100)
    private String remark;
	
	//操作ID
	@Column(name="create_id", length = 20)
    private Integer createId;
	
    // 开始时间
	@Column(name="create_time", length = 20)
    private String createTime;
	
	//操作ID
	@Column(name="update_id", length = 20)
    private Integer updateId;
	
    // 结束时间
	@Column(name="update_time", length = 20)
    private String updateTime;
    
    /* 扩展属性 begin */
    // 充值代理商名称
	@Basic
	@Transient	//表示不生成数据库字段
    private String agentName;
    // 操作人
	@Basic
	@Transient	//表示不生成数据库字段
    private String createName;
	@Basic
	@Transient	//表示不生成数据库字段
	private String updateName;
    /* 扩展属性 end */
}
