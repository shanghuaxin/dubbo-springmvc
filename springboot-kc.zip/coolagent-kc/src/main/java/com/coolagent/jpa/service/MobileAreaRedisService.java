package com.coolagent.jpa.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coolagent.cache.service.RedisHandle;
import com.coolagent.common.Constants;
import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.MobileArea;

/**
 * 代理商的代码转换
 * @author Shanghuaxin
 *
 */
@Service
@Transactional(rollbackFor=Exception.class)
public class MobileAreaRedisService extends RedisHandle<MobileArea>{
	
	private String REDIS_KEY = "REDIS_KEY_MOBILE_AREA";
	
	@Autowired
	private MobileAreaDao dao;
	
	@Override
	protected String getRedisKey() {
		// TODO Auto-generated method stub
		return this.REDIS_KEY;
	}
	
	/**
	 * 查询所属网络
	 */
	public RestStatus findNetWork(String phone) {
		RestStatus rs = new RestStatus(true);
		
		if(phone==null || phone.length()!=11) {
			rs.setStatus(false);
			rs.setErrorCode("500");
			rs.setErrorMessage("号码不正确，请核查");
			return rs;
		}
		
		String prefix = phone.substring(0, 7);
		
		MobileArea bean = new MobileArea();
		Object obj = get(prefix);
		if(obj == null) {
			bean = dao.findByPrefixAndVirtualCode(Integer.parseInt(prefix), "ZXST");
			if(bean!=null) {
				put(prefix, bean, Constants.REDIS_EXPIRE);
			}
			else {
				rs.setStatus(false);
				rs.setErrorCode("500");
				rs.setErrorMessage("非中兴视通号码，请核查");
				return rs;
			}
		} else {
			BeanUtils.copyProperties(obj, bean);
		}
		
		rs.setResponseData(bean);
		
		return rs;
	}
}
