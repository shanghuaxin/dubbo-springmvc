package com.coolagent.jpa.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="t_mobile_area")
@Data
@ToString
public class MobileArea implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long id;
	@Column(name="prefix", columnDefinition="int(7) comment '号段'")
	private Integer prefix;//号段
	@Column(name="carrier", columnDefinition="char(2) comment '手机号码运营商(YD：移动   LT：联通   DX：电信   OT：其他)'")
    private String carrier;//手机号码运营商(YD：移动   LT：联通   DX：电信   OT：其他)
	@Column(name="corp", columnDefinition="varchar(15) comment '手机运营商'")
    private String corp;//手机运营商
	@Column(name="province_py", columnDefinition="varchar(15) comment '手机归属省份拼音'")
    private String provincePy;//手机归属省份拼音
	@Column(name="province", columnDefinition="varchar(15) comment '手机归属省份'")
    private String province;//手机归属省份
	@Column(name="city", columnDefinition="varchar(30) comment '手机归属城市'")
    private String city;//手机归属城市
	@Column(name="virtual_corp", columnDefinition="varchar(30) comment '虚商名称'")
    private String virtualCorp;//虚商名称
	@Column(name="virtual_code", columnDefinition="varchar(30) comment '虚商编码'")
    private String virtualCode;//虚商编码
}
