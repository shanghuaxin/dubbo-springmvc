package com.coolagent.jpa.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="t_aircharge_agent_info")
@Data
@ToString
public class AirChargeAgentInfo implements Serializable {

	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	// 充值代理商ID
	@Basic//默认就添加这个注解
	@Column(name="agent_id", length = 20)
	private Integer agentId;
	
	//充值代理商名称
	@Column(name="agent_name", columnDefinition="varchar(20) comment '充值代理商名称'")
	private String agentName;
	
	@Column(name="balance", columnDefinition="decimal(10,2) comment '充值代理商余额'")
	private BigDecimal balance;
	
	@Column(name="warning_status", columnDefinition="int(3) comment '是否已经余额阈值告警 0:未告警 1:告警'")
	private Integer warningStatus;
	
	@Column(name="status", columnDefinition="int(3) comment '状态 1:关闭 0:正常'")
	private Integer status;
	
	//操作ID
	@Column(name="create_id", length = 20)
    private String createId;
	
    // 开始时间
	@Column(name="create_time", length = 20)
    private String createTime;
	
	//操作ID
	@Column(name="update_id", length = 20)
    private String updateId;
	
    // 结束时间
	@Column(name="update_time", length = 20)
    private String updateTime;
}
