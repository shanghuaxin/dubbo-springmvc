package com.coolagent.common;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPool {

	private static ExecutorService threadPool;

	public static void getInstance() {
		if(threadPool == null) {
			threadPool = Executors.newFixedThreadPool(5);
		}
	}
	
	public static void start(Runnable runnable) {
		getInstance();
		
		threadPool.execute(runnable);
	}
	
}
