package com.coolagent.common;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RestStatus {

	private Boolean status;
    private String errorCode;
    private String errorMessage;
    private Object responseData;
    
	public RestStatus(Boolean status) {
		super();
		this.status = status;
	}
	public RestStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
}
