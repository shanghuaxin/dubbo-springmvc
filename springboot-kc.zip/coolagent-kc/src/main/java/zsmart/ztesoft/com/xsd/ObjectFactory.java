
package zsmart.ztesoft.com.xsd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the zsmart.ztesoft.com.xsd package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {
	private final static QName _RechargeBOSSBO_QNAME = new QName("http://com.ztesoft.zsmart/xsd", "RechargeBOSSBO");
    private final static QName _RechargeBOSSBOResponse_QNAME = new QName("http://com.ztesoft.zsmart/xsd", "RechargeBOSSBOResponse");
    /**
     * Create an instance of {@link TRechargeBOSSBO }
     *
     */
    public TRechargeBOSSBO createTRechargeBOSSBO() {
        return new TRechargeBOSSBO();
    }

    /**
     * Create an instance of {@link TRechargeBOSSBOResponse }
     *
     */
    public TRechargeBOSSBOResponse createTRechargeBOSSBOResponse() {
        return new TRechargeBOSSBOResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TRechargeBOSSBO }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://com.ztesoft.zsmart/xsd", name = "RechargeBOSSBO")
    public JAXBElement<TRechargeBOSSBO> createRechargeBOSSBO(TRechargeBOSSBO value) {
        return new JAXBElement<TRechargeBOSSBO>(_RechargeBOSSBO_QNAME, TRechargeBOSSBO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TRechargeBOSSBOResponse }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://com.ztesoft.zsmart/xsd", name = "RechargeBOSSBOResponse")
    public JAXBElement<TRechargeBOSSBOResponse> createRechargeBOSSBOResponse(TRechargeBOSSBOResponse value) {
        return new JAXBElement<TRechargeBOSSBOResponse>(_RechargeBOSSBOResponse_QNAME, TRechargeBOSSBOResponse.class, null, value);
    }
}
