@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/PaymentBank/")
package org.example.paymentbank;
