package org.example.paymentbank;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "responseId",
    "resultCode",
    "resultInfo",
    "payDate",
    "flowNumber",
    "writeoffDate"
})
@XmlRootElement(name = "PaymentBankResponse")
public class PaymentBankResponse {

    @XmlElement(name = "ResponseId", required = true, nillable = true)
    protected String responseId;
    @XmlElement(name = "ResultCode", required = true, nillable = true)
    protected String resultCode;
    @XmlElementRef(name = "ResultInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> resultInfo;
    @XmlElementRef(name = "PayDate", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payDate;
    @XmlElementRef(name = "FlowNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> flowNumber;
    @XmlElementRef(name = "WriteoffDate", type = JAXBElement.class, required = false)
    protected JAXBElement<String> writeoffDate;

    public String getResponseId() {
        return responseId;
    }

    public void setResponseId(String value) {
        this.responseId = value;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String value) {
        this.resultCode = value;
    }

    public JAXBElement<String> getResultInfo() {
        return resultInfo;
    }

    public void setResultInfo(JAXBElement<String> value) {
        this.resultInfo = value;
    }

    public JAXBElement<String> getPayDate() {
        return payDate;
    }

    public void setPayDate(JAXBElement<String> value) {
        this.payDate = value;
    }

    public JAXBElement<String> getFlowNumber() {
        return flowNumber;
    }

    public void setFlowNumber(JAXBElement<String> value) {
        this.flowNumber = value;
    }

    public JAXBElement<String> getWriteoffDate() {
        return writeoffDate;
    }

    public void setWriteoffDate(JAXBElement<String> value) {
        this.writeoffDate = value;
    }

}
