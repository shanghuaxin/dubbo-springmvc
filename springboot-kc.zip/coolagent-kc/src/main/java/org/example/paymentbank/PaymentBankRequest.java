package org.example.paymentbank;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "requestId",
    "systemId",
    "serviceId",
    "serviceKind",
    "payFee",
    "flowNumber",
    "notifyDate",
    "payWay",
    "payKind",
    "ifContinue",
    "dealerId",
    "workNo",
    "presentFee"
})
@XmlRootElement(name = "PaymentBankRequest")
public class PaymentBankRequest {

    @XmlElement(name = "RequestId", required = true, nillable = true)
    protected String requestId;
    @XmlElement(name = "SystemId", required = true, nillable = true)
    protected String systemId;
    @XmlElement(name = "ServiceId", required = true, nillable = true)
    protected String serviceId;
    @XmlElement(name = "ServiceKind")
    protected int serviceKind;
    @XmlElement(name = "PayFee")
    protected long payFee;
    @XmlElementRef(name = "FlowNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> flowNumber;
    @XmlElementRef(name = "NotifyDate", type = JAXBElement.class, required = false)
    protected JAXBElement<String> notifyDate;
    @XmlElement(name = "PayWay")
    protected int payWay;
    @XmlElement(name = "PayKind", required = true, type = Integer.class, nillable = true)
    protected Integer payKind;
    @XmlElement(name = "IfContinue")
    protected boolean ifContinue;
    @XmlElement(name = "DealerId", required = true, nillable = true)
    protected String dealerId;
    @XmlElement(name = "WorkNo", required = true, nillable = true)
    protected String workNo;
    @XmlElement(name = "PresentFee")
    protected long presentFee;

    /**
     * ��ȡrequestId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * ����requestId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestId(String value) {
        this.requestId = value;
    }

    /**
     * ��ȡsystemId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemId() {
        return systemId;
    }

    /**
     * ����systemId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemId(String value) {
        this.systemId = value;
    }

    /**
     * ��ȡserviceId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceId() {
        return serviceId;
    }

    /**
     * ����serviceId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceId(String value) {
        this.serviceId = value;
    }

    /**
     * ��ȡserviceKind���Ե�ֵ��
     * 
     */
    public int getServiceKind() {
        return serviceKind;
    }

    /**
     * ����serviceKind���Ե�ֵ��
     * 
     */
    public void setServiceKind(int value) {
        this.serviceKind = value;
    }

    /**
     * ��ȡpayFee���Ե�ֵ��
     * 
     */
    public long getPayFee() {
        return payFee;
    }

    /**
     * ����payFee���Ե�ֵ��
     * 
     */
    public void setPayFee(long value) {
        this.payFee = value;
    }

    /**
     * ��ȡflowNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFlowNumber() {
        return flowNumber;
    }

    /**
     * ����flowNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFlowNumber(JAXBElement<String> value) {
        this.flowNumber = value;
    }

    /**
     * ��ȡnotifyDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNotifyDate() {
        return notifyDate;
    }

    /**
     * ����notifyDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNotifyDate(JAXBElement<String> value) {
        this.notifyDate = value;
    }

    /**
     * ��ȡpayWay���Ե�ֵ��
     * 
     */
    public int getPayWay() {
        return payWay;
    }

    /**
     * ����payWay���Ե�ֵ��
     * 
     */
    public void setPayWay(int value) {
        this.payWay = value;
    }

    /**
     * ��ȡpayKind���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPayKind() {
        return payKind;
    }

    /**
     * ����payKind���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPayKind(Integer value) {
        this.payKind = value;
    }

    /**
     * ��ȡifContinue���Ե�ֵ��
     * 
     */
    public boolean isIfContinue() {
        return ifContinue;
    }

    /**
     * ����ifContinue���Ե�ֵ��
     * 
     */
    public void setIfContinue(boolean value) {
        this.ifContinue = value;
    }

    /**
     * ��ȡdealerId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerId() {
        return dealerId;
    }

    /**
     * ����dealerId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerId(String value) {
        this.dealerId = value;
    }

    /**
     * ��ȡworkNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkNo() {
        return workNo;
    }

    /**
     * ����workNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkNo(String value) {
        this.workNo = value;
    }

    /**
     * ��ȡpresentFee���Ե�ֵ��
     * 
     */
    public long getPresentFee() {
        return presentFee;
    }

    /**
     * ����presentFee���Ե�ֵ��
     * 
     */
    public void setPresentFee(long value) {
        this.presentFee = value;
    }

}
