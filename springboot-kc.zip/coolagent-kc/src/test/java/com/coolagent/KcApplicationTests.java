package com.coolagent;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coolagent.activemq.service.Producer;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class KcApplicationTests {

	@Test
	public void contextLoads() {
	}

	//private MockMvc mockMvc; // 模拟MVC对象，通过MockMvcBuilders.webAppContextSetup(this.wac).build()初始化。

    //@Autowired
    //private WebApplicationContext wac; // 注入WebApplicationContext  

//    @Autowired  
//    private MockHttpSession session;// 注入模拟的http session  
//      
//    @Autowired  
//    private MockHttpServletRequest request;// 注入模拟的http request\  

    /*@Before // 在测试开始前初始化工作  
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }*/

    /*@Test
    public void testFindAll() throws Exception {
        MvcResult result = mockMvc.perform(post("/jpa/findone/4"))
                .andExpect(status().isOk())// 模拟向testRest发送get请求
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))// 预期返回值的媒体类型text/plain; charset=UTF-8
                .andReturn();// 返回执行请求的结果

        System.out.println(result.getResponse().getContentAsString());
    }*/
    
    @Value("${spring.mail.username}")
    private String username;
    @Autowired
    private MailSender javaMailSender;
    @Test
    public void testSendSimple(String mailTitle, String mailTxt) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(username);
        message.setTo("shanghuaxin@seecom.com.cn");
        message.setSubject("title");
        message.setText("title-test");
        javaMailSender.send(message);
    }
    
    /*@Resource
    BaseRedisDaoImpl rs;
    @Test
    public void RedisTest() throws Exception {
         rs.set(1, "11");
            System.out.println(rs.get(1));  
    }*/
    
    //@Autowired  
	//private Producer producer;
    //@Autowired
    //private ConfigProducer cp;

	/*@Test  
	public void testActivemq() {  
		//Destination destination = new ActiveMQQueue("mytest.queue");  
		for(int i=0; i<10; i++){  
			//producer.sendMessage("mq.queue", "sendMessage "+i);  
			producer.sendMessageConvert("mq.return.queue", "sendMessageConvert "+i);
		}
		try {
			Thread.sleep(1000*1000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Destination topic = new ActiveMQTopic("mytest.topic");
		//producer.sendTopicMessage(topic, "topic msg");
	}*/
	
	/*@Test
	public void testWs() throws Exception{
		log.info("testWs=============");
		JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
		Client client = dcf.createClient("http://localhost:9000/soap/charge?wsdl");
		Object[] objects = client.invoke("charge", "phone", 10002L);
		//输出调用结果
		System.out.println(objects[0].getClass());
		System.out.println(objects[0].toString());
	}*/
}
