package com.coolagent.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class XMLUtil {

	// public XMLUtil()
	// {
	// }

	public static Document parseText(String xmlText) {
		try {
			if (null != xmlText) {
				return DocumentHelper.parseText(xmlText);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return null;
	}

	/**
	 * 从文件名初始化，如初始化成功返回ROOT，否则返回NULL
	 * 
	 * @param xmlSource
	 */
	public static Document parseXml(String xmlSource) {
		try {
			if (null != xmlSource) {
				InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(xmlSource);
				return parseXml(in);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return null;
	}

	/**
	 * 从文件名初始化，如初始化成功返回ROOT，否则返回NULL
	 * 
	 * @param xmlData
	 */
	static public Document parseXml(byte[] xmlData) throws Exception {
		if (xmlData == null)
			return null;

		ByteArrayInputStream in = new ByteArrayInputStream(xmlData);
		return parseXml(in);
	}

	/**
	 * 从XML文件输入流初始化，如初始化成功返回true，否则返回false
	 */
	static public Document parseXml(File xmlFile) throws Exception {
		if (xmlFile == null || !xmlFile.exists())
			return null;
		Document root = null;
		try {
			SAXReader saxReader = new SAXReader();
			saxReader.setValidation(false);
			root = saxReader.read(xmlFile);
			return root;
		} catch (Exception e) {
			log.error("解析XML输入流出现异常，请检查XML输入流是否正确:" + xmlFile.getName());
			throw e;
		}
	}

	/**
	 * 从XML文件输入流初始化，如初始化成功返回true，否则返回false
	 */
	static public Document parseXml(InputStream in) throws Exception {
		if (in == null)
			return null;
		Document root = null;
		try {
			SAXReader saxReader = new SAXReader();
			saxReader.setValidation(false);
			root = saxReader.read(in);
			return root;
		} catch (Exception e) {
			log.error("解析XML输入流出现异常，请检查XML输入流是否正确:" + in);
			throw e;
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e) {
				}
		}
	}

	/**
	 * 检查某路径的节点配置是否存在
	 * 
	 * @param xql
	 * @return
	 */
	static public boolean isNodeExists(Node startNode, String xql) {
		if (startNode == null || xql == null) {
			return false;
		}

		Node node = startNode.selectSingleNode(xql);
		return (node != null);
	}

	/**
	 * 根据相对节点，获取配置项值。
	 * 
	 * @param startNode
	 *            相对节点
	 * @param xql
	 *            相对startNode表示的配置项路径
	 */
	static public String getString(Node startNode, String xql) {
		if (startNode == null || xql == null) {
			return null;
		}

		Node node = startNode.selectSingleNode(xql);
		if (node != null) {
			return node.getText();
		} else {
			return null;
		}
	}

	/**
	 * 获取配置项
	 * 
	 * @param xql
	 * @return
	 */
	static public String getString(Node startNode, String xql, String def) {
		if (startNode == null || xql == null) {
			return def;
		}

		Node node = startNode.selectSingleNode(xql);
		if (node != null) {
			return node.getText();
		} else {
			return def;
		}
	}

	/**
	 * 获取int类型的配置项，如该项不存在或不能转为int，则返回默认值。
	 *
	 * @param xql
	 *            XPATH表示的配置项路径
	 * @param def
	 *            默认值
	 * @return
	 */
	static public int getInt(Node startNode, String xql, int def) {
		String nValue = getString(startNode, xql);
		try {
			return Integer.parseInt(nValue);
		} catch (Exception e) {
			return def;
		}
	}

	/**
	 * 获取float类型的配置项，如该项不存在或不能转为float，则返回默认值。
	 *
	 * @param xql
	 *            XPATH表示的配置项路径
	 * @param def
	 *            默认值
	 * @return
	 */
	static public float getFloat(Node startNode, String xql, float def) {
		String nValue = getString(startNode, xql);
		try {
			return Float.parseFloat(nValue);
		} catch (Exception e) {
			return def;
		}
	}

	/**
	 * 获取long类型的配置项，如该项不存在或不能转为long，则返回默认值。
	 *
	 * @param xql
	 *            XPATH表示的配置项路径
	 * @param def
	 *            默认值
	 * @return
	 */
	static public long getLong(Node startNode, String xql, long def) {
		String nValue = getString(startNode, xql);
		try {
			return Long.parseLong(nValue);
		} catch (Exception e) {
			return def;
		}
	}

	/**
	 * 设置节点的值
	 * 
	 * @param startNode
	 *            相对节点
	 * @param xql
	 *            相对startNode表示的配置项路径
	 */
	static public boolean setNodeValue(Node startNode, String xql, String nodeValue) {
		if (startNode == null || xql == null) {
			return false;
		}

		Node node = startNode.selectSingleNode(xql);
		if (node != null) {
			node.setText(nodeValue);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 设置节点的值
	 * 
	 * @param startNode
	 *            相对节点
	 * @param xql
	 *            相对startNode表示的配置项路径
	 */
	static public boolean setNodePropertyValue(Node startNode, String xql, String propertyName, String nodeValue) {
		if (startNode == null || xql == null) {
			return false;
		}

		Element node = (Element) startNode.selectSingleNode(xql);
		if (node != null) {
			node.attribute(propertyName).setText(nodeValue);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 输出节点的内容并关闭输出流
	 * 
	 * @param out
	 *            OutputStream
	 * @param indent
	 *            boolean 是否要输出空格
	 * @param newLine
	 *            boolean 是否要换行
	 */
	static public void printAndClose(Document document, OutputStream out, boolean indent, boolean newLine) {
		XMLWriter writer = null;
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("GBK");
			format.setIndent(indent);
			format.setNewlines(newLine);
			// 以下两行设为TRUE则没有<?xml version="1.0" encoding="GBK"?>
			format.setOmitEncoding(false);
			format.setSuppressDeclaration(false);
			/*
			 * System.out.println(format.isExpandEmptyElements());
			 * System.out.println(format.isNewlines());
			 * System.out.println(format.isOmitEncoding());
			 * System.out.println(format.isPadText());
			 * System.out.println(format.isSuppressDeclaration());
			 * System.out.println(format.isTrimText());
			 * System.out.println(format.isXHTML());
			 */
			writer = new XMLWriter(out, format);
			writer.write(document);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (out != null)
				try {
					out.close();
				} catch (Exception e) {
				}
		}
	}

	/**
	 * 输出节点的内容并关闭输出流
	 * 
	 * @param out
	 *            OutputStream
	 */
	static public void printAndClose(Document document, OutputStream out) {
		XMLWriter writer = null;
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("GBK");
			format.setTrimText(true);
			format.setIndent(true);
			format.setNewlines(true);
			// 以下两行设为TRUE则没有<?xml version="1.0" encoding="GBK"?>
			format.setOmitEncoding(false);
			format.setSuppressDeclaration(false);
			writer = new XMLWriter(out, format);
			writer.write(document);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (out != null)
				try {
					out.close();
				} catch (Exception e) {
				}
		}
	}

	/**
	 * 输出节点的内容并关闭输出流
	 * 
	 * @param root
	 *            Node
	 * @param out
	 *            OutputStream
	 */
	static public void printAndClose(Node root, OutputStream out, String charSet) {
		XMLWriter writer = null;
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding(charSet);
			writer = new XMLWriter(out, format);
			writer.write(root);
		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			if (out != null)
				try {
					out.close();
				} catch (Exception e) {
				}
		}
	}

	/**
	 * 输出节点的内容
	 * 
	 * @param out
	 *            OutputStream
	 */
	static public void print(Document document, OutputStream out) {
		XMLWriter writer = null;
		OutputFormat format = new OutputFormat();
		format.setEncoding("GBK");
		format.setTrimText(true);
		format.setIndent(false);
		// 以下两行设为TRUE则没有<?xml version="1.0" encoding="GBK"?>
		format.setOmitEncoding(false);
		format.setSuppressDeclaration(false);
		try {
			writer = new XMLWriter(out, format);
			writer.write(document);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				out.flush();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * 输出节点的内容
	 * 
	 * @param out
	 *            OutputStream
	 */
	static public void print(Document document, OutputStream out, String charSet) {
		XMLWriter writer = null;
		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setNewlines(true);
		format.setEncoding(charSet);
		format.setTrimText(true);
		format.setIndent(true);
		// 以下两行设为TRUE则没有<?xml version="1.0" encoding="GBK"?>
		format.setOmitEncoding(false);
		format.setSuppressDeclaration(false);

		try {
			writer = new XMLWriter(out, format);
			writer.write(document);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				out.flush();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * 写入xml文件地址
	 * 
	 * @param document
	 *            所属要写入的内容
	 * @param outFile
	 *            文件存放的地址
	 */
	public static void writeDocument(Document document, String outFile) {
		try {
			// 读取文件
			// FileWriter fileWriter = new FileWriter(outFile);
			// 设置文件编码
			OutputFormat xmlFormat = OutputFormat.createPrettyPrint();
			xmlFormat.setEncoding("UTF-8");
			// 创建写文件方法
			// XMLWriter xmlWriter = new XMLWriter(fileWriter, xmlFormat);
			XMLWriter xmlWriter = new XMLWriter(new FileOutputStream(outFile), xmlFormat);
			// 写入文件
			xmlWriter.write(document);
			// 关闭
			xmlWriter.close();
		} catch (Exception e) {
			log.error("WriteDocument", e);
		}
	}

	@SuppressWarnings("rawtypes")
	static public void main(String[] args) {
		try {
			Document document = DocumentHelper.createDocument();// .parseText("<?xml version=\"1.0\"
																// encoding=\"GBK\"?><system/>") ;
			Element root = document.addElement("system");

			java.util.Properties properties = System.getProperties();
			for (java.util.Enumeration elements = properties.propertyNames(); elements.hasMoreElements();) {
				String name = (String) elements.nextElement();
				String value = properties.getProperty(name);
				Element element = root.addElement("property");
				element.addAttribute("name", name);
				element.addText(value);
			}
			root.addElement("tree").addAttribute("text", "测试").addAttribute("src", "./admin/createMenu.do?pId=12");
			XMLUtil.printAndClose(document, System.out, true, true);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// static private Document createDocument()
	// {
	// try
	// {
	// Document document = DocumentHelper.createDocument();// .parseText("<?xml
	// version=\"1.0\" encoding=\"GBK\"?><system/>") ;
	// Element root = document.addElement("system");
	//
	// java.util.Properties properties = System.getProperties();
	// for (java.util.Enumeration elements = properties.propertyNames(); elements
	// .hasMoreElements();)
	// {
	// String name = (String) elements.nextElement();
	// String value = properties.getProperty(name);
	// Element element = root.addElement("property");
	// element.addAttribute("name", name);
	// element.addText(value);
	// }
	// root.addElement("tree").addAttribute("text", "测试")
	// .addAttribute("src", "./admin/createMenu.do?pId=12");
	//
	// return document;
	// } catch (Exception ex)
	// {
	// return null;
	// }
	// }

	/**
	 * 把java对象转换成XML的格式字符串
	 * 
	 * @param obj
	 *            要转换的java对象，注意对象中必须要包括@XmlRootElement注解
	 * @return
	 */
	@SuppressWarnings("hiding")
	public <T> String tranObjToXML(T obj) {
		try {
			StringWriter sw = new StringWriter();
			JAXBContext jAXBContext = JAXBContext.newInstance(obj.getClass());
			Marshaller marshaller = jAXBContext.createMarshaller();
			marshaller.marshal(obj, sw);
			return sw.toString();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return "";
	}
}
