package com.coolagent.util;

import java.util.Date;
import java.util.Random;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

public class Utils {
	private static final Random RND = new Random(UUID.randomUUID().hashCode());
	private static final char[] chars = new char[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	
	public static String getOrderNo(String ditchId) {
    	String no = getPrefix(ditchId);
    	
    	StringBuilder sb = new StringBuilder();
		sb.append(no)
		  .append(DateUtils.getInstance().formatDate(new Date(), DateUtils.yyyyMMddHHmmssSSS))
		  .append(generateRandomString(6));
		return sb.toString();
    }
    
    /**
     * 根据渠道获取3位数字前缀
     * @param ditchId
     * @return
     */
    private static String getPrefix(String ditchId){
    	String resultV = "888888";
    	if(StringUtils.isEmpty(ditchId)){
    		return resultV;
    	}
    	String data = org.apache.commons.codec.digest.DigestUtils.md5Hex(ditchId);
    	data = data.replaceAll("[^1-9]", "");
    	if(data.length()>=5){
    		return data.substring(0,5);
    	}else{
    		return data.toString() + generateRandomString(5-data.length());
    	}
    }
    
    /**
	 * 生成len长度的随机数序列
	 * 
	 * @param len 长度
	 * @return String 随机数字符
	 */
	public static String generateRandomString(int len) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < len; i++) {
			sb.append(chars[RND.nextInt(chars.length)]);
		}
		return sb.toString();
	}
	
	/**
     * 获取随机数
     * @param length 随机数的长度
     * @return
     */
    public static String getRandomString(int length) {
        String base = "0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
}
