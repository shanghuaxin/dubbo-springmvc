package com.coolagent.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;

public class DateUtils {
	private static DateUtils dateUtil;
	/**时间格式 yyyy_MM_dd_HH_mm_ss*/
    public static final String yyyy_MM_dd_HH_mm_ss = "yyyy-MM-dd HH:mm:ss";
    /**时间格式 yyyy_MM_dd*/
    public static final String yyyy_MM_dd = "yyyy-MM-dd";
    /**时间格式 yyyy_MM_dd*/
    public static final String yyyy_MM_dd_2 = "yyyy年MM月dd日";
    /**时间格式 yyyy_MM_dd*/
    public static final String yyyyMM = "yyyyMM";
    /**时间格式 yyyy_MM_dd*/
    public static final String yyyy_MM = "yyyy-MM";
    /**时间格式 HH_mm_ss*/
    public static final String HH_mm_ss = "HH:mm:ss";
    /**时间格式 yyyyMMddHHmmss*/
    public static final String yyyyMMddHHmmss = "yyyyMMddHHmmss";
    public static final String yyyyMMddHHmmssSSS = "yyyyMMddHHmmssSSS";
    
    private DateUtils(){
    }
    /**
     * 获取DateUtil实例
     */
    public static DateUtils getInstance(){
        synchronized(DateUtils.class){
            if(dateUtil==null){
                dateUtil=new DateUtils();
            }
        }
        return dateUtil;
    }
    
    /**
     * 根据传入的日期格式化输出
     * yyyy-MM-dd 的字符串时间
     *
     * @param date      时间
     * @param formatStr yyyy-MM-dd等时间串
     *
     * @return
     */
    public String formatDate(Date date,String formatStr){
        if (StringUtils.isEmpty(formatStr)) {
            formatStr = "yyyy-MM-dd HH:mm:ss";
        }
        SimpleDateFormat formatter = new SimpleDateFormat(formatStr);
        String outDate = formatter.format(date);
        return outDate;
    }
    
    /**
     * 将Date类转换为XMLGregorianCalendar
     * 
     * @param date
     * @return
     */
    public static XMLGregorianCalendar dateToXmlDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        DatatypeFactory dtf = null;
        XMLGregorianCalendar dateType = null;
        try {
            dtf = DatatypeFactory.newInstance();
            dateType = dtf.newXMLGregorianCalendar();
            dateType.setYear(cal.get(Calendar.YEAR));
            // 由于Calendar.MONTH取值范围为0~11,需要加1
            dateType.setMonth(cal.get(Calendar.MONTH) + 1);
            dateType.setDay(cal.get(Calendar.DAY_OF_MONTH));
            dateType.setHour(cal.get(Calendar.HOUR_OF_DAY));
            dateType.setMinute(cal.get(Calendar.MINUTE));
            dateType.setSecond(cal.get(Calendar.SECOND));
        } catch (DatatypeConfigurationException e) {
        }
        return dateType;
    }
}
