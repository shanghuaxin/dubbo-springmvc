package com.coolagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoolagentAirchargeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoolagentAirchargeApplication.class, args);
	}
}
