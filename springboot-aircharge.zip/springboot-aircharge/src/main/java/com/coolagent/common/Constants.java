package com.coolagent.common;

import java.math.BigDecimal;

public class Constants {
	/** BigDecimal--->100 */
	public static final BigDecimal FINAL_100 = new BigDecimal(100);
	
	/** 充值发消息的KEY */
	public static final String ACTIVEMQ_CHARGE_VALUE = "mq.queue.db.charge.webservice";
	/** 加值发消息的KEY */
	public static final String ACTIVEMQ_ADD_CHARGE_VALUE = "mq.queue.db.add.charge.webservice";
	/** 修改状态发消息的KEY */
	public static final String ACTIVEMQ_STATUS_CHARGE_VALUE = "mq.queue.db.status.charge.webservice";
	
	/** redis过期时间，秒为单位，60*60*5缓存5小时 */
	public static final long REDIS_EXPIRE = 60*60*5;
	
	/** sourceType */
	public static final String SOURCE_TYPE_KC = "air_charge";
	
}
