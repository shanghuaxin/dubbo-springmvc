package com.coolagent.jpa.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coolagent.cache.service.RedisHandle;
import com.coolagent.common.Constants;
import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.AirChargeAgentCode;

/**
 * 代理商的代码转换
 * @author Shanghuaxin
 *
 */
@Service
@Transactional(rollbackFor=Exception.class)
public class AirChargeAgentCodeRedisService extends RedisHandle<AirChargeAgentCode>{
	
	private String REDIS_KEY = "REDIS_KEY_AIRCHARGEAGENTCODE";
	
	@Autowired
	private AirChargeAgentCodeDao dao;
	
	@Override
	protected String getRedisKey() {
		// TODO Auto-generated method stub
		return this.REDIS_KEY;
	}
	
	/**
	 * 代理商的码转为酷商码，并验证密码
	 * 根据CODE查找AGENT_ID
	 * @param code，pwd
	 * @return
	 */
	public RestStatus findByAgentCodeAndPwd(@Param("agentCode")String agentCode, String agentPwd) {
		RestStatus rs = new RestStatus(true);
		
		AirChargeAgentCode bean = new AirChargeAgentCode();
		
		Object obj = get(agentCode);
		if(obj == null) {
			bean = dao.findByAgentCode(agentCode);
			if(bean!=null) {
				if (!bean.getAgentPwd().equals(agentPwd)) {
					rs.setErrorCode("500");
					rs.setStatus(false);
					rs.setErrorMessage("充值渠道密码不正确，请核对");
					return rs;
				}
				
				put(agentCode, bean, Constants.REDIS_EXPIRE);
			} else {
				rs.setStatus(false);
				rs.setErrorCode("500");
				rs.setErrorMessage("充值渠道账户不存在，请核对");
				return rs;
			}
		} else {
			BeanUtils.copyProperties(obj, bean);
			
			//密码不相同，表示修改过或者错误
			if (!bean.getAgentPwd().equals(agentPwd)) {
				bean = dao.findByAgentCode(agentCode);
				if(bean!=null) {
					if (!bean.getAgentPwd().equals(agentPwd)) {
						rs.setErrorCode("500");
						rs.setStatus(false);
						rs.setErrorMessage("充值渠道密码不正确，请核对");
						return rs;
					}
					//修改过,重新存放
					put(agentCode, bean, Constants.REDIS_EXPIRE);
				} else {
					rs.setStatus(false);
					rs.setErrorCode("500");
					rs.setErrorMessage("充值渠道账户不存在，请核对");
					return rs;
				}
			}
		}
		
		rs.setResponseData(bean);
		
		return rs;
	}
	
	/**
	 * 代理商的码转为酷商码
	 * 根据CODE查找AGENT_ID
	 * @param code
	 * @return
	 */
	public RestStatus findByAgentCode(@Param("agentCode")String agentCode) {
		RestStatus rs = new RestStatus(true);
		
		AirChargeAgentCode bean = new AirChargeAgentCode();
		
		Object obj = get(agentCode);
		if(obj == null) {
			bean = dao.findByAgentCode(agentCode);
			if(bean!=null) {
				put(agentCode, bean, Constants.REDIS_EXPIRE);
			} else {
				rs.setStatus(false);
				rs.setErrorCode("500");
				rs.setErrorMessage("充值渠道账户不存在，请核对");
				return rs;
			}
		} else {
			BeanUtils.copyProperties(obj, bean);
		}
		
		rs.setResponseData(bean);
		
		return rs;
	}
	
}
