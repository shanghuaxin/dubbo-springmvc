package com.coolagent.jpa.control;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.AirCharge;
import com.coolagent.jpa.service.AirChargeAgentInfoRedisService;
import com.coolagent.jpa.service.AirChargeRecordRedisService;
import com.coolagent.webservice.service.ChargeRepository;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ChargeControl {

	@Autowired
	private ChargeRepository chargeRes;
	@Autowired
	private AirChargeRecordRedisService recordService;
	@Autowired
	private AirChargeAgentInfoRedisService infoService;
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	@ResponseBody
	public RestStatus test() {
		
		RestStatus rs = recordService.findAirChargeAgentInfo("card_dx", "123");
		
		return rs;
	}
	
	@RequestMapping(value = "/test-charge")
	@ResponseBody
	public String chargeTest() {
		return chargeRes.webserviceInvokeCharge();
	}
	
	/**
	 * 加值操作
	 * @return
	 */
	@RequestMapping(value = "/add-charge")
	@ResponseBody
	public RestStatus addCharge(AirCharge c) {
		/*
		//测试数据
		c.setAgentId(700);
		c.setMoney(new BigDecimal(10000));
		*/
		log.info("加值操作:"+c.toString());
		RestStatus rs = infoService.producerAddAirCharge(c);
		
		return rs;
	}
	
	/**
	 * 修改状态
	 * @return
	 */
	@RequestMapping(value = "/update-status-charge")
	@ResponseBody
	public RestStatus updateStatus(AirCharge c) {
		RestStatus rs = new RestStatus(true);
		try {
			/*
			//测试数据
			c.setCode("card_dx");
			c.setStatus(0);
			*/
			log.info("修改状态操作:"+c.toString());
			rs = infoService.producerUpdateAirChargeStatus(c);
		} catch (Exception e) {
			rs.setStatus(false);
			rs.setErrorCode("500");
			rs.setErrorMessage(e.getMessage());
		}
		
		return rs;
	}
	
	@RequestMapping(value = "/remove-redis-key/{key}")
	@ResponseBody
	public Set<String> removeRedisByKey(@PathVariable String key) {
		log.info("========removeRedisByKey======="+key);
		return recordService.removeRedisByKey(key);
	}
	
	@RequestMapping(value = "/remove-redis-keys")
	@ResponseBody
	public String removeRedisKeys() {
		log.info("========removeRedisKeys=======");
		recordService.removeRedisKeys();
		
		return "success";
	}
	
	@RequestMapping(value = "/find-redis-balance/{agentId}")
	@ResponseBody
	public Double findRedisBalanceByAgentId(@PathVariable Integer agentId) {
		log.info("========findRedisBalanceByAgentId======="+agentId);
		recordService.getBalanceRedis(agentId);
		
		return recordService.getBalanceRedis(agentId).doubleValue();
	}
}
