package com.coolagent.jpa.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coolagent.jpa.bean.AirChargeRecord;

@Repository
public interface AirChargeRecordDao extends JpaRepository<AirChargeRecord, Long> {

}
