package com.coolagent.jpa.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.ToString;

/**
 * webservice的实体进行字段扩展
 * @author Shanghuaxin
 *
 */
@ToString
public class Charge extends com.coolagent.webservice.bean.WsCharge implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer agentId;
	//随机数据
	private Integer random;
	//充值后的余额,记录日志时使用
	private BigDecimal chargedBalance;
	//操作ID
	private Integer userId;

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public Integer getRandom() {
		return random;
	}

	public void setRandom(Integer random) {
		this.random = random;
	}

	public BigDecimal getChargedBalance() {
		return chargedBalance;
	}

	public void setChargedBalance(BigDecimal chargedBalance) {
		this.chargedBalance = chargedBalance;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}
