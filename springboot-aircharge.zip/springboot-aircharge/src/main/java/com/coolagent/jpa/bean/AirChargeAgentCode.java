package com.coolagent.jpa.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="t_aircharge_agent_code")
@ToString
@Data
public class AirChargeAgentCode implements Serializable{

	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	//充值代理商ID
	@Column(name="agent_id", nullable=true, columnDefinition="int comment '充值代理商ID'")
	private Integer agentId;
	
	//充值代理商编码
	@Column(name="agent_code", columnDefinition="varchar(20) comment '充值代理商编码'")
	private String agentCode;
	
	//充值代理商名称
	@Column(name="agent_name", columnDefinition="varchar(20) comment '充值代理商名称'")
	private String agentName;
	
	//充值代理商登录密码
	@Column(name="agent_pwd", columnDefinition="varchar(50) comment '充值代理商登录密码'")
	private String agentPwd;
	
}
