package com.coolagent.jpa.service;

import java.math.BigDecimal;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coolagent.activemq.service.Producer;
import com.coolagent.cache.service.RedisHandle;
import com.coolagent.common.Constants;
import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.AirCharge;
import com.coolagent.jpa.bean.AirChargeAgentInfo;
import com.coolagent.jpa.bean.Charge;
import com.coolagent.util.JSONUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 代理商的账户信息
 * @author Shanghuaxin
 *
 */
@Service
@Slf4j
@Transactional(rollbackFor=Exception.class)
public class AirChargeAgentInfoRedisService extends RedisHandle<Object>{
	
	private String REDIS_KEY = "REDIS_KEY_AIRCHARGEAGENTINFO";
	
	@Autowired
	private AirChargeAgentInfoDao dao;
	@Autowired
	private AirChargeRecordRedisService recordService;
	@Autowired
	private Producer producer;
	
	@Override
	protected String getRedisKey() {
		return this.REDIS_KEY;
	}
	
	/**
	 * 根据代理商ID查询账户信息
	 * @param agentId
	 * @return
	 */
	public RestStatus findByAgentId(@Param("agentId") Integer agentId, boolean checkStatus) {
		RestStatus rs = new RestStatus(true);
		//AirChargeAgentInfo bean = dao.findByAgentId(agentId);
		
		AirChargeAgentInfo bean = new AirChargeAgentInfo();
		Object obj = get(agentId.toString());
		if(obj == null) {
			bean = dao.findByAgentId(agentId);
			if(bean!=null) {
				if (bean.getStatus() != 1) {
					if(checkStatus) {
						rs.setErrorCode("500");
						rs.setStatus(false);
						rs.setErrorMessage("充值渠道账户非正常状态，请核对");
						return rs;
					}
				} else {
					put(agentId.toString(), bean, Constants.REDIS_EXPIRE);
				}
			} else {
				rs.setErrorCode("500");
				rs.setStatus(false);
				rs.setErrorMessage("充值渠道账户不存在，请核对");
				return rs;
			}
		} else {
			BeanUtils.copyProperties(obj, bean);
			if (bean.getStatus() != 1) {
				if(checkStatus) {
					rs.setErrorCode("500");
					rs.setStatus(false);
					rs.setErrorMessage("充值渠道账户非正常状态，请核对");
					return rs;
				}
			}
		}
		
		rs.setResponseData(bean);
		
		return rs;
	}
	
	/**
	 * 发消息进行加值操作
	 * @param charge
	 */
	public RestStatus producerAddAirCharge(AirCharge charge) {
		RestStatus rs = new RestStatus(true);
		
		String sendMsg = JSONUtil.objectToJson(charge).toString();
		
		producer.sendMessageConvert(Constants.ACTIVEMQ_ADD_CHARGE_VALUE, sendMsg);
		
		rs.setResponseData("加值操作完成");
		return rs;
	}
	
	/**
	 * 发消息进行修改状态操作
	 * @param charge
	 */
	public RestStatus producerUpdateAirChargeStatus(AirCharge charge) {
		RestStatus rs = new RestStatus(true);
		if(charge.getStatus().intValue()!=0 || charge.getStatus().intValue()!=1) {
			rs.setStatus(false);
			rs.setErrorCode("500");
			rs.setErrorMessage("状态值不正确，请参数（0表示正常，1表示停用）");
		}
		
		String sendMsg = JSONUtil.objectToJson(charge).toString();
		
		producer.sendMessageConvert(Constants.ACTIVEMQ_STATUS_CHARGE_VALUE, sendMsg);
		
		rs.setResponseData("修改状态操作完成");
		return rs;
	}
	
	/**
	 * 真正的加值业务处理
	 * @param charge
	 * @return
	 * @throws Exception
	 */
	public RestStatus addAirCharge(AirCharge charge) throws Exception {
		//不验证状态查出账户信息
		RestStatus rs = findByAgentId(charge.getAgentId(), false);
		if(!rs.getStatus()) {
			return rs;
		}
		
		AirChargeAgentInfo info = (AirChargeAgentInfo)rs.getResponseData();
		
		//加值后的余额
		BigDecimal chargedBalance = info.getBalance().add(charge.getMoney());
		rs = updateBalance(chargedBalance, info.getAgentId());
		if(!rs.getStatus()) {
			return rs;
		}
		
		//加值后更新redis的余额
		recordService.chargedPutRedisNewBalance(info.getAgentId(), chargedBalance);
		updateRedisInfo(info.getAgentId(), chargedBalance);
		
		Charge c = new Charge();
		c.setAgentId(info.getAgentId());
		c.setMoney(charge.getMoney().intValue());
		c.setChargedBalance(chargedBalance);
		c.setUserId(charge.getUserId());
		rs = recordService.addAirChargeRecode(c, 1, 1);
		
		return rs;
	}
	
	/**
	 * 真正的修改渠道状态
	 * @param charge
	 * @return
	 * @throws Exception
	 */
	public RestStatus updateAirChargeStatus(AirCharge charge) throws Exception {
		RestStatus rs = new RestStatus(true);
		int flag = dao.updateStatus(charge.getStatus(), charge.getAgentId());
		if(flag == 0) {
			rs.setStatus(false);
			rs.setErrorCode("500");
			rs.setErrorMessage("数据没有做更新操作,扣款失败");
			
			throw new Exception("数据没有做更新操作,扣款失败");
		}
		
		Object obj = get(charge.getAgentId().toString());
		if(obj != null) {
			AirChargeAgentInfo bean = new AirChargeAgentInfo();
			BeanUtils.copyProperties(obj, bean);
			bean.setStatus(charge.getStatus());
			log.info("修改后的状态为："+(charge.getStatus().intValue()==0?"正常":"停用"));
			put(charge.getAgentId().toString(), bean, Constants.REDIS_EXPIRE);
		}
		
		return rs;
	}
	
	/**
	 * 扣款/加值,此方法直接修改数据库中的余额字段
	 * @param balance
	 * @param id
	 * @return
	 */
	public RestStatus updateBalance(BigDecimal balance, Integer agentId) throws Exception{
		RestStatus rs = new RestStatus(true);
		
		try {
			int flag = dao.updateBalance(balance, agentId);
			if(flag == 0) {
				throw new Exception("数据没有做更新操作,扣款失败");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return rs;
	}
	
	/**
	 * 扣款后需要把缓存中AirChargeAgentInfo的余额进行更新
	 * @param agentId
	 * @param balance
	 */
	public void updateRedisInfo(Integer agentId, BigDecimal balance) {
		Object obj = get(agentId.toString());
		if(obj != null) {
			AirChargeAgentInfo bean = new AirChargeAgentInfo();
			BeanUtils.copyProperties(obj, bean);
			bean.setBalance(balance);
			log.info("扣款/加值后redis中的余额：￥"+bean.getBalance().divide(Constants.FINAL_100).doubleValue());
			put(agentId.toString(), bean, Constants.REDIS_EXPIRE);
		}
	}
}
