package com.coolagent.jpa.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.coolagent.jpa.bean.AirChargeAgentCode;

@Repository
public interface AirChargeAgentCodeDao extends JpaRepository<AirChargeAgentCode, Long> {

	//@Select("select * from AirChargeAgentCode where agentCode=#{agentCode}")//可以不写，JPA会生成这条语句
	public AirChargeAgentCode findByAgentCode(@Param("agentCode")String agentCode);
}
