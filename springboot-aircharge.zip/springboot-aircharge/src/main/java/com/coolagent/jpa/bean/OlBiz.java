package com.coolagent.jpa.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="ol_biz")
@Data
@ToString
public class OlBiz implements Serializable {

	private static final long serialVersionUID = -7772674453405274296L;
	@Id
	@GeneratedValue
	private Long id;
	@Column(name="phone", columnDefinition="varchar(11) comment '手机号码'")
    private String phone;      //手机号码
	
	@Column(name="order_no", columnDefinition="varchar(50) comment '订单编号'")
    private String orderNo;    //订单编号
	
	@Column(name="serv_code", columnDefinition="varchar(50) comment '业务编码'")
    private String servCode;   //业务编码
	
	@Column(name="serv_name", columnDefinition="varchar(100) comment '业务名称'")
    private String servName;   //业务名称
	
    //业务类型：1-流量订购 ，2-来电提醒 ，3-来电显示，4-无条件呼叫转移，5-炫铃服务，6-语音呼入，7-上网功能，8-短信功能，9-实名补录,10-补换卡,11-挂失解挂,
    //12-停机保号停复机,13-销户申请,14-套餐变更，15-叠加包,16-语音包，17-普通日包，18-自动续订日包
	@Column(name="biz_type", columnDefinition="int(3) comment '业务类型：1-流量订购 ，2-来电提醒 ，3-来电显示，4-无条件呼叫转移，5-炫铃服务，6-语音呼入，7-上网功能，8-短信功能,9-实名补录，10-补换卡，11-挂失解挂，12-强制停机，13-强制复机，14-销户申请'")
    private Integer bizType;
	
	@Column(name="biz_name", columnDefinition="varchar(50) comment '订单名称'")
    private String bizName;
	
	@Column(name="operation_type", columnDefinition="int(3) comment '操作类型：0-订购，1-取消，2-变更'")
    private Integer operationType;   //操作类型：0-订购，1-取消，2-变更
    
	@Column(name="status", columnDefinition="int(3) comment '订单编号'")
	private Integer status;          //状态 1-成功，2-失败，3-处理中
    
	@Column(name="check_status", columnDefinition="int(3) comment '审核状态'")
	private String checkStatus;     //审核状态
	
	@Column(name="check_time", columnDefinition="varchar(20) comment '审核时间'")
	private String checkTime;     //审核时间
    
	@Column(name="operation_time", columnDefinition="varchar(20) comment '受理时间'")
	private Date operationTime;     //受理时间
    
	@Column(name="valid_type", columnDefinition="int(3) comment '生效方式：1-实时生效， 2-次月生效,3-次日生效'")
	private Integer validType;       //生效方式：1-实时生效， 2-次月生效,3-次日生效
    
	@Column(name="valid_time", columnDefinition="varchar(50) comment '生效时间'")
	private Date validTime;         //生效时间
	
	@Column(name="money", columnDefinition="decimal(10,2) comment '金额'")
    private BigDecimal money;       //金额
	
	@Column(name="fee_style", columnDefinition="int(3) comment '收费模式：1-一次性收费，2，按月收费，3-实时收费,4-按天收费'")
    private Integer feeStyle;        //收费模式：1-一次性收费，2，按月收费，3-实时收费,4-按天收费
	
	@Column(name="way_type", columnDefinition="varchar(20) comment '渠道类型：AGENT-酷商，ONLINE-网厅，AGENTAPP-酷商APP，WAP-掌厅，KF-客服'")
    private String wayType;         //渠道类型：AGENT-酷商，ONLINE-网厅，AGENTAPP-酷商APP，WAP-掌厅，KF-客服
	
	@Column(name="ip", columnDefinition="varchar(50) comment '操作IP'")
    private String ip;              //操作IP
    
	@Column(name="reason", columnDefinition="varchar(50) comment '操作原因'")
	private String reason;          //操作原因
    
	@Column(name="remark", columnDefinition="varchar(50) comment '备注'")
    private String remark;          //备注
	
	@Column(name="new_serv_code", columnDefinition="varchar(50) comment '新业务编码'")
    private String newServCode;   //新业务编码
    
	@Column(name="new_serv_name", columnDefinition="varchar(50) comment '新业务名称'")
	private String newServName;   //新业务名称
	
	@Column(name="old_serv_code", columnDefinition="varchar(50) comment '旧业务编码'")
    private String oldServCode;   //旧业务编码
	
	@Column(name="old_serv_name", columnDefinition="varchar(50) comment '旧业务名称'")
    private String oldServName;   //旧业务名称
	
	@Column(name="create_time", columnDefinition="varchar(20) comment '时间'")
	private String createTime;     //时间
	@Column(name="update_time", columnDefinition="varchar(20) comment '时间'")
	private String updateTime;     //时间
	
}
