package com.coolagent.jpa.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AirCharge implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//酷商系统渠道码
	private Integer agentId;
	//加值金额
	private BigDecimal money;
	//渠道状态 0关闭 1正常
	private Integer status;
	//操作ID
	private Integer userId;
}
