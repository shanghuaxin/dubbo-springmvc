package com.coolagent.boss.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="t_interface_data")
@Data
@ToString
public class InterfaceData implements Serializable{
    private static final long serialVersionUID = 1312624807250961570L;
    
    @Id
    @GeneratedValue
    private Integer id;               // id
    @Column(name="msisdn", columnDefinition="varchar(11) comment '号码'")
    private String msisdn;            // 号码
    @Column(name="operator_id", columnDefinition="int(11) comment '当前登录的操作员id'")
    private Integer operatorId;        // 当前登录的操作员id
    // 接口名称:recharge-充值，opensim-开户，complete-报峻，modCustomer -过户，详见接口协议
    @Column(name="interface_name", columnDefinition="varchar(50) comment '接口名称'")
    private String interfaceName;    // 接口名称:recharge-充值，opensim-开户，complete-报峻，modCustomer -过户
    @Column(name="request_content", columnDefinition="text comment '请求报文'")
    private String requestContent;    // 请求报文
    @Column(name="request_time", columnDefinition="varchar(20) comment '请求时间'")
    private String requestTime;        // 请求时间
    @Column(name="status", columnDefinition="int(3) comment '状态：0：失败，1：成功'")
    private Integer status;           // status 0：失败 1：成功
    @Column(name="response_content", columnDefinition="text comment '请求时间'")
    private String responseContent;  // 响应报文
    @Column(name="response_time", columnDefinition="varchar(20) comment '响应时间'")
    private String responseTime;       // 响应时间
}
