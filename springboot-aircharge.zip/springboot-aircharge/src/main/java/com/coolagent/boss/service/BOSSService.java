package com.coolagent.boss.service;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.example.paymentbank.PaymentBankRequest;
import org.example.paymentbank.PaymentBankResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coolagent.boss.bean.InterfaceData;
import com.coolagent.common.RestStatus;
import com.coolagent.util.DateUtils;
import com.coolagent.util.XMLUtil;

import lombok.extern.slf4j.Slf4j;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBO;
import zsmart.ztesoft.com.xsd.TRechargeBOSSBOResponse;

@Service
@Slf4j
public class BOSSService {
	private static final String SUCCESS = "0000";
	@Autowired
	private Define define;
	@Autowired
	private InterfaceDataDao dao;
	
	/**
     * 号码充话费
     * 
     * @param rechargeBO
     * @return
     */
    public RestStatus RechargeBOSS(TRechargeBOSSBO rechargeBO, Integer operatorId) throws Exception {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        log.error("----------------------------- 号码：" + rechargeBO.getMSISDN() + "号码充话费BOSS接口调用 ,时间：" + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(rechargeBO);
            interfaceData.setMsisdn(rechargeBO.getMSISDN());
            interfaceData.setInterfaceName("RechargeBOSS");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(DateUtils.getInstance().formatDate(new Date(), null));
            interfaceData.setOperatorId(operatorId);
            // 成功
            interfaceData.setStatus(1);
            
            String url = define.getMobileUrl();
            log.info("================="+url);
            Client client = getClient(url);
            Object[] r = client.invoke("RechargeBOSS", rechargeBO);
            TRechargeBOSSBOResponse resp = (TRechargeBOSSBOResponse)r[0];
            if (!SUCCESS.equals(resp.getResultCode())) {
                res.setStatus(Boolean.FALSE);
                if(StringUtils.isEmpty(resp.getOpraDesc())){
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                }else{
                    res.setErrorMessage(resp.getOpraDesc());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            log.error("号码充话费BOSS接口调用接口错误：phone=" + rechargeBO.getMSISDN() + "，原因：" + e.getMessage(), e);
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        } 
        // 记录接口调用日志，抓异常处理，不能影响正常的业务流程
        interfaceData.setResponseTime(DateUtils.getInstance().formatDate(new Date(), null));
        dao.save(interfaceData);
        log.error("-----------------------------号码：" + rechargeBO.getMSISDN() + "号码充话费BOSS接口调用完成,时间：" + System.nanoTime() + "-----------------------------");
        return res;
    }
	
	/**
     * 联通账务充值接口
     * @param request
     * @return
     */
    public RestStatus paymentBank(PaymentBankRequest request, Integer operatorId) {
        RestStatus res = new RestStatus();
        res.setStatus(true);
        log.error("----------------------------- 号码：" + request.getServiceId() + "账务充值接口调用 ,时间："
                + System.nanoTime() + "-----------------------------");
        InterfaceData interfaceData = new InterfaceData();
        try {
            // 组装接口日志对象
            XMLUtil xMLUtil = new XMLUtil();
            // 把入参对象转换成xml格式的字符串
            String reqeustContent = xMLUtil.tranObjToXML(request);
            interfaceData.setMsisdn(request.getServiceId());
            interfaceData.setInterfaceName("PaymentBank");
            interfaceData.setRequestContent(reqeustContent);
            interfaceData.setRequestTime(DateUtils.getInstance().formatDate(new Date(), null));
            interfaceData.setOperatorId(operatorId);
            // 成功
            interfaceData.setStatus(1);
            String url = define.getUnionUrl();
            // 这里的url里有变量，需要根据不同的业务进行格式化
            url = String.format(url, "PaymentBankSOAP");
            Client client = getClient(url);
            Object[] obj = client.invoke("execute", request);
            PaymentBankResponse resp = (PaymentBankResponse) obj[0];
            if ("0".equals(resp.getResultCode())) {
                res.setResponseData(resp);
            } else {
                res.setStatus(false);
                if (StringUtils.isEmpty(resp.getResultCode())) {
                    res.setErrorMessage("接口错误码："+resp.getResultCode());
                } else {
                    res.setErrorMessage(resp.getResultInfo().getValue());
                }
            }
        } catch (Exception e) {
            res.setStatus(Boolean.FALSE);
            res.setErrorMessage(e.getMessage());
            // 失败
            interfaceData.setStatus(0);
            interfaceData.setResponseContent(e.getMessage());
        }
        
        // 把出参对象转换成xml格式的字符串
        interfaceData.setResponseTime(DateUtils.getInstance().formatDate(new Date(), null));
        dao.save(interfaceData);
        log.error("-----------------------------号码：" + request.getServiceId() + "账务充值接口调用完成,时间：" + System.nanoTime() + "-----------------------------");
        return res;
    }
    
    private Client getClient(String url) {
        JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
        Client client = factory.createClient(url);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());
        return client;
    }
    
    public static void main(String[] args) {
    	/*String rechargeId = define.getMobileChargeId();
        String rechargePwd = define.getMobileChargePwd();
        log.info(rechargeId+"=============="+rechargePwd);
		TRechargeBOSSBO rechargeBO = new TRechargeBOSSBO();
        rechargeBO.setMSISDN("8617057000068");
        rechargeBO.setAmount(1000);
        rechargeBO.setSN(Utils.getOrderNo("F"));// 流水号唯一
        rechargeBO.setOperateDate(DateUtils.dateToXmlDate(new Date()));// 调用方操作时间
        rechargeBO.setChannalId(rechargeId);// 充值Id
        rechargeBO.setChannalPwd(com.coolagent.util.MD5.GetMD5Code(rechargePwd));// 充值密码
        try {
			RestStatus restStatus = bossService.RechargeBOSS(rechargeBO, 0);
			log.info(restStatus.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
		/*PaymentBankRequest paymentBank = new PaymentBankRequest();
        paymentBank.setRequestId(Utils.getRandomString(10));
        paymentBank.setSystemId("0001");
        paymentBank.setServiceId("17057000068");
        paymentBank.setServiceKind(8);
        paymentBank.setPayFee(1000);
        ObjectFactory objFac=new ObjectFactory();  
        JAXBElement<String> flowNumber = objFac.createPaymentBankRequestFlowNumber("");
        JAXBElement<String> notifyDate = objFac.createPaymentBankRequestNotifyDate("");
        paymentBank.setFlowNumber(flowNumber);
        paymentBank.setNotifyDate(notifyDate);
        paymentBank.setPayWay(4);
        paymentBank.setPayKind(1);
        paymentBank.setIfContinue(false);
        // 充值类型
        paymentBank.setDealerId("kc");
        // 充值渠道ID
        paymentBank.setWorkNo("3008638");
        paymentBank.setPresentFee(0);
        RestStatus restStatus = bossService.paymentBank(paymentBank, 0);
        log.info(restStatus.toString());*/
	}
}
