package com.coolagent.activemq.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

import com.coolagent.common.ThreadPool;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SendEmail {

	@Autowired
	private MailSender javaMailSender;
	@Value("${spring.mail.username}")
    private String username;
	@Value("${mail.to}")
	private String mailTo;
	
	public void sendSimple(final String mailTitle, final String mailTxt) {
		
		ThreadPool.start(new Runnable() {
			@Override
			public void run() {
				try {
					SimpleMailMessage message = new SimpleMailMessage();
					message.setFrom(username);
					message.setTo(mailTo);
					message.setSubject(mailTitle);
					message.setText(mailTxt);
					
					log.error(message.toString());
					javaMailSender.send(message);
				} catch (MailException e) {
					log.error("发送邮件异常："+e.getMessage());
				}
			}
		});
        
    }
}
