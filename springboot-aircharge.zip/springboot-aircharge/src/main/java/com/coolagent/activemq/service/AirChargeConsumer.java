package com.coolagent.activemq.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.coolagent.common.Constants;
import com.coolagent.common.RestStatus;
import com.coolagent.jpa.bean.AirCharge;
import com.coolagent.jpa.bean.Charge;
import com.coolagent.jpa.service.AirChargeAgentInfoRedisService;
import com.coolagent.jpa.service.AirChargeRecordRedisService;
import com.coolagent.util.DateUtils;
import com.coolagent.util.JSONUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AirChargeConsumer {

	@Autowired
	private AirChargeAgentInfoRedisService infoService;
	@Autowired
	private AirChargeRecordRedisService recordService;
	@Autowired
	private SendEmail sendEmail;
	
	/**
	 * 接收到消息，进行真正意义上的 充值 业务
	 * @param message
	 * @return
	 */
	@JmsListener(destination = Constants.ACTIVEMQ_CHARGE_VALUE)
	public void receiveQueue(String msg) throws Exception{
		Charge c = new Charge();
		try {
			log.info(Constants.ACTIVEMQ_CHARGE_VALUE+"收到的报文为:" + msg);
			c = JSONUtil.jsonToObject(msg, Charge.class);
			
			RestStatus rs = recordService.chargeWebService(c);
			
			if(!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
		} catch (Exception e) {
			log.error("接收消息处理出错了，找原因解决问题=============="+e.getMessage());
			//e.printStackTrace();
			
			//写站内消息，记录充值失败
			recordService.addAirChargeRecode(c, 4, 2);
			
			String errorEmailStr = DateUtils.getInstance().formatDate(new Date(), null)+"\r\n\r\n"+msg+"\r\n\r\n"+e.getMessage(); 
			sendEmail.sendSimple("充值业务处理异常", errorEmailStr);
		}
		
		// 处理完成后把redis中的消息数据清除
		if(recordService.isKeyExists(Constants.ACTIVEMQ_CHARGE_VALUE+c.getRandom())) {
			recordService.remove(Constants.ACTIVEMQ_CHARGE_VALUE+c.getRandom());
		}
	}
	
	/**
	 * 接收到消息，进行真正意义上的 加值 业务
	 * @param text
	 * @throws Exception
	 */
	@JmsListener(destination = Constants.ACTIVEMQ_ADD_CHARGE_VALUE)
	public void receiveAddAirChargeQueue(String msg) throws Exception{
		AirCharge c = new AirCharge();
		try {
			log.info(Thread.currentThread().getName()+","+Constants.ACTIVEMQ_ADD_CHARGE_VALUE+"收到的报文为:" + msg);
			c = JSONUtil.jsonToObject(msg, AirCharge.class);
			
			RestStatus rs = infoService.addAirCharge(c);
			if(!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
		} catch (Exception e) {
			log.error("接收消息处理出错了，找原因解决问题==============");
			e.printStackTrace();
			
			// 发邮件
			String errorEmailStr = DateUtils.getInstance().formatDate(new Date(), null)+"\r\n\r\n"+msg+"\r\n\r\n"+e.getMessage(); 
			sendEmail.sendSimple("加值业务处理异常", errorEmailStr);
		}
	}
	
	/**
	 * 接收到消息，进行真正意义上的 修改状态 业务
	 * @param text
	 * @throws Exception
	 */
	@JmsListener(destination = Constants.ACTIVEMQ_STATUS_CHARGE_VALUE)
	public void receiveUpdateStatusAirChargeQueue(String msg) throws Exception{
		AirCharge c = new AirCharge();
		try {
			log.info(Constants.ACTIVEMQ_STATUS_CHARGE_VALUE+"收到的报文为:" + msg);
			c = JSONUtil.jsonToObject(msg, AirCharge.class);
			
			RestStatus rs = infoService.updateAirChargeStatus(c);
			if(!rs.getStatus()) {
				throw new Exception(rs.getErrorMessage());
			}
		} catch (Exception e) {
			log.error("接收消息处理出错了，找原因解决问题==============");
			e.printStackTrace();
			
			String errorEmailStr = DateUtils.getInstance().formatDate(new Date(), null)+"\r\n\r\n"+msg+"\r\n\r\n"+e.getMessage(); 
			sendEmail.sendSimple("修改状态业务处理异常", errorEmailStr);
		}
	}

}
