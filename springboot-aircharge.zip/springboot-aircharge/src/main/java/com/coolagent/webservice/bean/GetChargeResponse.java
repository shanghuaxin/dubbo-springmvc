package com.coolagent.webservice.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
	"code",
    "msg"
})
@XmlRootElement(name = "getChargeResponse", namespace = "http://www.seecom.com.cn/webservice")
@Data
public class GetChargeResponse {

	@XmlElement(namespace = "http://www.seecom.com.cn/webservice", required = true)
	protected String code;
    @XmlElement(namespace = "http://www.seecom.com.cn/webservice", required = true)
    protected String msg;

}
