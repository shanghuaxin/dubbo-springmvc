package com.coolagent.webservice.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;
import lombok.ToString;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "charge"
})
@XmlRootElement(name = "getChargeRequest", namespace = "http://www.seecom.com.cn/webservice")
@Data
@ToString
public class GetChargeRequest {

	@XmlElement(namespace = "http://www.seecom.com.cn/webservice", required = true)
    protected WsCharge charge;
}
