package com.example.swagger.bean;

import java.util.HashMap;

public class Map2 extends HashMap<String,Object> {

}
